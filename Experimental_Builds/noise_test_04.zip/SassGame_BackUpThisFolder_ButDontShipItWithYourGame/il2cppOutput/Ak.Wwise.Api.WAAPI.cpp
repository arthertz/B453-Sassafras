﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"

template <typename R>
struct VirtFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3>
struct VirtFuncInvoker3
{
	typedef R (*Func)(void*, T1, T2, T3, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2, T3 p3)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, invokeData.method);
	}
};
struct VirtActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename R, typename T1, typename T2>
struct VirtFuncInvoker2
{
	typedef R (*Func)(void*, T1, T2, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};
template <typename R, typename T1>
struct VirtFuncInvoker1
{
	typedef R (*Func)(void*, T1, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3, typename T4>
struct VirtFuncInvoker4
{
	typedef R (*Func)(void*, T1, T2, T3, T4, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, p4, invokeData.method);
	}
};
template <typename T1>
struct VirtActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
struct GenericVirtActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_virtual_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename T1>
struct GenericVirtActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_virtual_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
struct InterfaceActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename T1>
struct InterfaceActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
struct GenericInterfaceActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_interface_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename T1>
struct GenericInterfaceActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_interface_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};

// AkWaapiClient
struct AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1;
// Args
struct Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D;
// ArgsCommand
struct ArgsCommand_t675212B8DFD4A88AFF6A0484842254A82CBCAFD2;
// ArgsDisplayName
struct ArgsDisplayName_tB0504FC27F9B3A43933A54C7CE48C2480CD36DCD;
// ArgsObject
struct ArgsObject_t58DE1003F3AF0D598690ED9208AC6BF67819D832;
// ArgsPlay
struct ArgsPlay_t5EA1BD810BBA204223D66BA4E6650B78FB2BDDDB;
// ArgsRename
struct ArgsRename_tDD8FBA42725ABDCAEA48D8EFEDEAC1E343BFA414;
// ArgsTransport
struct ArgsTransport_t924F2C28D1C132CA258F1C6F1E7236DC0DF76CD2;
// ErrorDetails
struct ErrorDetails_t21A26837A9AD74120E02D79946F6D3B03EC5AAA2;
// ErrorMessage
struct ErrorMessage_tED7633C6802CF0672E6C52EB479D17926BDCCEBC;
// JsonSerializable
struct JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B;
// Options
struct Options_t36565DDE7EEC80CC7827D71EEC8E99E37411D050;
// ReturnOptions
struct ReturnOptions_tBED022AD296CD58A16E37C3DBC9D07089EA289FD;
// ReturnTransport
struct ReturnTransport_tB91DDDE10CD868C4AA03BEF7F4AA95E78E54F2DD;
// ReturnWwiseObjects
struct ReturnWwiseObjects_t4AC346E1F2794A85FF82A3E8463A838E2D90B4B8;
// SelectedWwiseObjects
struct SelectedWwiseObjects_t4B9895C68B1B11B76DC69F9C6DB2E69BB714E7A0;
// System.Action
struct Action_t591D2A86165F896B4B800BB5C25CE18672A55579;
// System.Action`1<System.Object>
struct Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0;
// System.AggregateException
struct AggregateException_t9217B9E89DF820D5632411F2BD92F444B17BD60E;
// System.AsyncCallback
struct AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4;
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Concurrent.ConcurrentDictionary`2/Tables<System.UInt32,Wamp/PublishHandler>
struct Tables_t87424CB0A55B8483F163AC041DEB12CCB629B7A4;
// System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,System.Object>
struct ConcurrentDictionary_2_t2CAAD473DB8373A614581938716FED5D21A1DEC1;
// System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,Wamp/PublishHandler>
struct ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0;
// System.Collections.Generic.Dictionary`2/Entry<System.String,System.String>[]
struct EntryU5BU5D_t034347107F1D23C91DE1D712EA637D904789415C;
// System.Collections.Generic.Dictionary`2/Entry<System.String,WwiseObjectType>[]
struct EntryU5BU5D_t75456DA7869220FFE8699CBAB590660094FBFE65;
// System.Collections.Generic.Dictionary`2/Entry<WwiseObjectType,System.String>[]
struct EntryU5BU5D_t0F5AD1E97902ED91447307E40433A27CC9D08FB2;
// System.Collections.Generic.Dictionary`2/KeyCollection<System.String,System.String>
struct KeyCollection_tC73654392B284B89334464107B696C9BD89776D9;
// System.Collections.Generic.Dictionary`2/KeyCollection<System.String,WwiseObjectType>
struct KeyCollection_t52478C64ED19521AEA3ECDE6A4E8F2A48DD894E4;
// System.Collections.Generic.Dictionary`2/KeyCollection<WwiseObjectType,System.String>
struct KeyCollection_tFC544D692DFDD6334D2301D61DFF17C07B2A9F7C;
// System.Collections.Generic.Dictionary`2/ValueCollection<System.String,System.String>
struct ValueCollection_tA3B972EF56F7C97E35054155C33556C55FAAFD43;
// System.Collections.Generic.Dictionary`2/ValueCollection<System.String,WwiseObjectType>
struct ValueCollection_t4FE98A9B48A13CEE31D805E33CE479D57B82F7E0;
// System.Collections.Generic.Dictionary`2/ValueCollection<WwiseObjectType,System.String>
struct ValueCollection_t5489901F3AFE8B14EC1C0E39B9224C1DB0EF0D78;
// System.Collections.Generic.Dictionary`2<System.Int32,System.String>
struct Dictionary_2_t4EFE6A1D6502662B911688316C6920444A18CF0C;
// System.Collections.Generic.Dictionary`2<System.Int32,System.Threading.Tasks.Task>
struct Dictionary_2_t70161CFEB8DA3C79E19E31D0ED948D3C2925095F;
// System.Collections.Generic.Dictionary`2<System.Int32Enum,System.Object>
struct Dictionary_2_t0D7F3A50EB302696E4E5A19D582D99A8C7F70060;
// System.Collections.Generic.Dictionary`2<System.Object,System.Int32Enum>
struct Dictionary_2_t15935BA59D5EDF22B5075E957C7C05DEE12E3B57;
// System.Collections.Generic.Dictionary`2<System.Object,System.Object>
struct Dictionary_2_t32F25F093828AA9F93CB11C2A2B4648FD62A09BA;
// System.Collections.Generic.Dictionary`2<System.String,System.String>
struct Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC;
// System.Collections.Generic.Dictionary`2<System.String,WwiseObjectType>
struct Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F;
// System.Collections.Generic.Dictionary`2<WwiseObjectType,System.String>
struct Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD;
// System.Collections.Generic.IDictionary`2<System.Int32Enum,System.Object>
struct IDictionary_2_t39C510F103FF5718B5827EC64B4B503E16F162EE;
// System.Collections.Generic.IDictionary`2<System.Object,System.Int32Enum>
struct IDictionary_2_t3F3B6EC5BA7AAA5FBD7C0E375F03B8AAE0F96C07;
// System.Collections.Generic.IDictionary`2<System.Object,System.Object>
struct IDictionary_2_tF77278125F2C7A401884F0168E974ADB442020AF;
// System.Collections.Generic.IDictionary`2<System.String,System.String>
struct IDictionary_2_t8D4B47914EFD2300DFBC7D9626F3D538CFA7CA53;
// System.Collections.Generic.IDictionary`2<System.String,WwiseObjectType>
struct IDictionary_2_t8E867567BD1C0A38AC69F67017DADDF28E7CA965;
// System.Collections.Generic.IDictionary`2<WwiseObjectType,System.String>
struct IDictionary_2_t83977D0962B22DB43501BBF73EA3BA0E2D1F4D59;
// System.Collections.Generic.IEnumerable`1<System.Byte>
struct IEnumerable_1_t5A38FCC3E9F64286F2A624D6571AF9EA7844398E;
// System.Collections.Generic.IEnumerable`1<System.Byte>[]
struct IEnumerable_1U5BU5D_tF249225453DF491E891C68DF212C88B54C1329FD;
// System.Collections.Generic.IEnumerable`1<System.Collections.Generic.IEnumerable`1<System.Byte>>
struct IEnumerable_1_t39ED83A0F021EC3D287BBCE23DDD0F25AB1385D8;
// System.Collections.Generic.IEnumerable`1<System.Object>
struct IEnumerable_1_t2F75FCBEC68AFE08982DA43985F9D04056E2BE73;
// System.Collections.Generic.IEqualityComparer`1<System.String>
struct IEqualityComparer_1_t1F07EAC22CC1D4F279164B144240E4718BD7E7A9;
// System.Collections.Generic.IEqualityComparer`1<System.UInt32>
struct IEqualityComparer_1_tA74C9F2C80A3BFA5A7BE17C48871B702741C8733;
// System.Collections.Generic.IEqualityComparer`1<WwiseObjectType>
struct IEqualityComparer_1_t3CC025C1C2C86074585678A3CBD2CB7C395F7BA2;
// System.Collections.Generic.List`1<System.Collections.Generic.IEnumerable`1<System.Byte>>
struct List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814;
// System.Collections.Generic.List`1<System.Object>
struct List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D;
// System.Collections.Generic.List`1<WwiseObjectInfoJsonObject>
struct List_1_t25289DD7DBC4B7586876E46CE6DD88E181CE2D31;
// System.Collections.Hashtable
struct Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9;
// System.Collections.IDictionary
struct IDictionary_t1BD5C1546718A374EA8122FBD6C6EE45331E8CE7;
// System.Collections.ObjectModel.ReadOnlyCollection`1<System.Exception>
struct ReadOnlyCollection_1_t6D5AC6FC0BF91A16C9E9159F577DEDA4DD3414C8;
// System.Collections.ObjectModel.ReadOnlyDictionary`2<System.Int32Enum,System.Object>
struct ReadOnlyDictionary_2_t783ED61F94C7CD46B849752D8E5670724794017E;
// System.Collections.ObjectModel.ReadOnlyDictionary`2<System.Object,System.Int32Enum>
struct ReadOnlyDictionary_2_tAF15F0D29D44A0C3C9331BB32AE9F536CF149D7C;
// System.Collections.ObjectModel.ReadOnlyDictionary`2<System.Object,System.Object>
struct ReadOnlyDictionary_2_t9AB03C58D299BE81D151A5B23097049F7106820C;
// System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,System.String>
struct ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE;
// System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,WwiseObjectType>
struct ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3;
// System.Collections.ObjectModel.ReadOnlyDictionary`2<WwiseObjectType,System.String>
struct ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D;
// System.Delegate
struct Delegate_t;
// System.DelegateData
struct DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE;
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
// System.Diagnostics.StackTrace[]
struct StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196;
// System.Exception
struct Exception_t;
// System.Func`1<System.Threading.Tasks.Task/ContingentProperties>
struct Func_1_t48C2978A48CE3F2F6EB5B6DE269D00746483BB1F;
// System.Func`2<System.Collections.Generic.IEnumerable`1<System.Byte>,System.Collections.Generic.IEnumerable`1<System.Byte>>
struct Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094;
// System.Func`2<System.Object,System.Collections.Generic.IEnumerable`1<System.Byte>>
struct Func_2_tD8DF63D6AF9940CC3BA20B6FAA14B2570E3DEDBE;
// System.Func`2<System.Object,System.Object>
struct Func_2_tE9A60F007AC624EA27BF19DEF4242B7DA2F1C2A4;
// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<System.Net.WebSockets.WebSocketReceiveResult>>
struct Func_2_tB79A1A7EFDEF01527B20591B4E1AE44882105895;
// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<System.Object>>
struct Func_2_tDAE4310E42C13AE378CDF0371BD31D6BF4E61EBD;
// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<System.String>>
struct Func_2_tD5DD82F807AA57BEB7EC482428FCFADD3E3EDF93;
// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>>
struct Func_2_t9183BE7C6FB5EAED091785FC3E1D3D41DB3497F7;
// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<System.UInt32>>
struct Func_2_t2DE17BAAB7C8A395FFA1D553866D96ABC5F46C97;
// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<Wamp/Response>>
struct Func_2_t5107249833618B5A8333140C3ED98F63AEE60F82;
// System.Globalization.CodePageDataItem
struct CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB;
// System.IAsyncResult
struct IAsyncResult_t8E194308510B375B42432981AE5E7488C458D598;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.Int32[][]
struct Int32U5BU5DU5BU5D_tCA34E042D233821D51B4DAFB480EE602F2DBEF43;
// System.IntPtr[]
struct IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD;
// System.Net.WebSockets.ClientWebSocket
struct ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90;
// System.Net.WebSockets.ClientWebSocketOptions
struct ClientWebSocketOptions_tF11DCFB8EAF9AE630CC5D0BF1EAA701EEE769166;
// System.Net.WebSockets.WebSocketException
struct WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B;
// System.Net.WebSockets.WebSocketHandle
struct WebSocketHandle_tCE1E5F6E1A2965D082A46F2BB340F76F09AD78FF;
// System.Net.WebSockets.WebSocketReceiveResult
struct WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5;
// System.Object[]
struct ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A;
// System.Predicate`1<System.Object>
struct Predicate_1_t4AA10EFD4C5497CA1CD0FE35A6AF5990FF5D0979;
// System.Predicate`1<System.Threading.Tasks.Task>
struct Predicate_1_tF4286C34BB184CE5690FDCEBA7F09FC68D229335;
// System.Reflection.Binder
struct Binder_t4D5CB06963501D32847C057B57157D6DC49CA759;
// System.Reflection.MemberFilter
struct MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Runtime.CompilerServices.IAsyncStateMachine
struct IAsyncStateMachine_tEFDFBE18E061A6065AB2FF735F1425FB59F919BC;
// System.Runtime.Serialization.SafeSerializationManager
struct SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770;
// System.Security.Cryptography.RandomNumberGenerator
struct RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2;
// System.String
struct String_t;
// System.String[]
struct StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E;
// System.Text.DecoderFallback
struct DecoderFallback_t128445EB7676870485230893338EF044F6B72F60;
// System.Text.EncoderFallback
struct EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63;
// System.Text.Encoding
struct Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4;
// System.Text.RegularExpressions.Capture
struct Capture_tF4475248CCF3EFF914844BE2C993FC609D41DB73;
// System.Text.RegularExpressions.Group
struct Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443;
// System.Text.RegularExpressions.GroupCollection
struct GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F;
// System.Text.RegularExpressions.Group[]
struct GroupU5BU5D_t40CFA194F8EE1BF5E560B7C1E2C8F48220C93910;
// System.Text.RegularExpressions.Match
struct Match_tE447871AB59EED3642F31EB9559D162C2977EBB5;
// System.Text.RegularExpressions.Regex
struct Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF;
// System.Threading.CancellationCallbackInfo
struct CancellationCallbackInfo_t8CDEA0AA9C9D1A2321FE2F88878F4B5E0901CF36;
// System.Threading.CancellationTokenRegistration[]
struct CancellationTokenRegistrationU5BU5D_t4B36771A6344CFC66696BB16419C664E286DAF1B;
// System.Threading.CancellationTokenSource
struct CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE;
// System.Threading.ContextCallback
struct ContextCallback_t8AE8A965AC6C7ECD396F527F15CDC8E683BE1676;
// System.Threading.ManualResetEvent
struct ManualResetEvent_tDFAF117B200ECA4CCF4FD09593F949A016D55408;
// System.Threading.SparselyPopulatedArray`1<System.Threading.CancellationCallbackInfo>[]
struct SparselyPopulatedArray_1U5BU5D_tF1A5F348104DB1ECF18799250B41740FCAA77813;
// System.Threading.Tasks.StackGuard
struct StackGuard_tE431ED3BBD1A18705FEE6F948EBF7FA2E99D64A9;
// System.Threading.Tasks.Task
struct Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2;
// System.Threading.Tasks.Task/ContingentProperties
struct ContingentProperties_t7149A27D01507C74E8BDAAA3848B45D2644FDF08;
// System.Threading.Tasks.TaskCompletionSource`1<System.Object>
struct TaskCompletionSource_1_t6C02642279BC7BF03091A8CB685FC6B4E68BED12;
// System.Threading.Tasks.TaskCompletionSource`1<Wamp/Response>
struct TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0;
// System.Threading.Tasks.TaskFactory
struct TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155;
// System.Threading.Tasks.TaskFactory`1<System.Net.WebSockets.WebSocketReceiveResult>
struct TaskFactory_1_t3B55C10C95A5E61DE2966CF61F2BD32F5C1525F6;
// System.Threading.Tasks.TaskFactory`1<System.Object>
struct TaskFactory_1_tA50D9207CAE2C505277DD5F03CBE64700177257C;
// System.Threading.Tasks.TaskFactory`1<System.String>
struct TaskFactory_1_tC464EE87A6CB7838666431AFB8761D134A690E8D;
// System.Threading.Tasks.TaskFactory`1<System.Threading.Tasks.Task>
struct TaskFactory_1_t58FE324C5DC18B5ED9A0E49CA8543DEEA65B4462;
// System.Threading.Tasks.TaskFactory`1<System.UInt32>
struct TaskFactory_1_t4B1CB177FC575AD49A8B6BDA308F06C7075F366B;
// System.Threading.Tasks.TaskFactory`1<Wamp/Response>
struct TaskFactory_1_tDE72F158A631009A5BFCAA2A5B363BE9A3E98F7E;
// System.Threading.Tasks.TaskScheduler
struct TaskScheduler_t966F2798F198FA90A0DA8EFC92BAC08297793114;
// System.Threading.Tasks.Task[]
struct TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE;
// System.Threading.Tasks.Task`1<System.Net.WebSockets.WebSocketReceiveResult>
struct Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F;
// System.Threading.Tasks.Task`1<System.Object>
struct Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09;
// System.Threading.Tasks.Task`1<System.String>
struct Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286;
// System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>
struct Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138;
// System.Threading.Tasks.Task`1<System.Threading.Tasks.VoidTaskResult>
struct Task_1_t1359D75350E9D976BFA28AD96E417450DE277673;
// System.Threading.Tasks.Task`1<System.UInt32>
struct Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F;
// System.Threading.Tasks.Task`1<Wamp/Response>
struct Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA;
// System.Threading.Timer
struct Timer_t67FAB8E41573B4FA09CA56AE30725AF4297C2553;
// System.Threading.TimerCallback
struct TimerCallback_tC89F2FB1294A86F64DEB2C1F68024954018AA219;
// System.Type
struct Type_t;
// System.Type[]
struct TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F;
// System.Uri
struct Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E;
// System.Uri/UriInfo
struct UriInfo_t9FCC6BD4EC1EA14D75209E6A35417057BF6EDC5E;
// System.UriParser
struct UriParser_t07C77D673CCE8D2DA253B8A7ACCB010147F1A4AC;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// TransportOptions
struct TransportOptions_t9EEC93A2E911B9D1A386999782BE3168373A2527;
// TransportState
struct TransportState_t1F81EF9D2597F1351B60E6530C77973DA92DC7AD;
// WaapiKeywords
struct WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE;
// Wamp
struct Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24;
// Wamp/<>c
struct U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7;
// Wamp/<>c__DisplayClass32_0
struct U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63;
// Wamp/DisconnectedHandler
struct DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3;
// Wamp/ErrorException
struct ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46;
// Wamp/PublishHandler
struct PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682;
// Wamp/Response
struct Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8;
// Wamp/TimeoutException
struct TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0;
// Wamp/WampNotConnectedException
struct WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F;
// WaqlArgs
struct WaqlArgs_t5604E26ED22F0E7787E1D7B4CF81594F2E72FEFE;
// WwiseChildModifiedInfo
struct WwiseChildModifiedInfo_t3C189D93FA4E1E9D3E7798FA5FF9644BA5241B7D;
// WwiseObjectInfoJsonObject
struct WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17;
// WwiseObjectInfoParent
struct WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C;
// WwiseRenameInfo
struct WwiseRenameInfo_t08FA05A48049742662096652F0A5B40DDE5B4C31;
// ak
struct ak_tF511177EEAEB475EB78D68D19AE992F862CBB2A6;
// ak/soundengine
struct soundengine_t694E3972DE713D444B64B412B97B7108DC843BA2;
// ak/soundengine/error
struct error_tCDE597E016300C016A3FEE568638DC713C2EDF61;
// ak/wwise
struct wwise_t7068E32CB53B72B95D1B19CE31764F556F895B73;
// ak/wwise/core
struct core_t2A82E032B006312497032C96741453A5F70ECA74;
// ak/wwise/core/audio
struct audio_t47E4E106B54C9DF68C91887F06C3898310F2C0F3;
// ak/wwise/core/audioSourcePeaks
struct audioSourcePeaks_t503D3CB9E73B4338F31A0060F5008944D2B4E1D7;
// ak/wwise/core/log
struct log_tA74FD121C946B190C887AEDDF632EFE00D4F8C8C;
// ak/wwise/core/object
struct object_t0FDE90CA89444F5B6103DBBE4484C4C404CBEF13;
// ak/wwise/core/plugin
struct plugin_t6477174149106EA1CA08712CEDFAC6028FDC5DE4;
// ak/wwise/core/profiler
struct profiler_tB89DC98B050F1E087FB89C6DDB20BC381FB7CA65;
// ak/wwise/core/project
struct project_t245E31FDE836DE1D2F40961C29EE21036450FC8A;
// ak/wwise/core/remote
struct remote_t4C4F4EEBAC03CF408E3C74E936EC87563F2FEA09;
// ak/wwise/core/soundbank
struct soundbank_tCC9926C7815C27A6209BB97EA23E27B302300771;
// ak/wwise/core/switchContainer
struct switchContainer_tDDDB01C44DF50EFEF268CA874FCD80FE21B0E346;
// ak/wwise/core/transport
struct transport_tB8EF7287199C52452B7B8154131F2B26537C1905;
// ak/wwise/core/undo
struct undo_t5CF6EE76079FD0E24252206687B55766055EAB46;
// ak/wwise/debug
struct debug_t829D0F86B78CE3E43CF489CD32C09DAB255C271E;
// ak/wwise/error
struct error_tCD7560328D4A46FEB23E1B161450E7A6F8107172;
// ak/wwise/ui
struct ui_t294C9D5BA24A6473CA0945190027352134FD517A;
// ak/wwise/ui/commands
struct commands_tFC4F4BB98976F182CFEA291E7E8962B7AB92B0E7;
// ak/wwise/ui/project
struct project_tC709A78C52B6A1C3E7E4A3F46A84163E22F00868;
// ak/wwise/waapi
struct waapi_tB7251965C2BF8D27DD071A5757C5A547D41EED68;

IL2CPP_EXTERN_C RuntimeClass* Action_t591D2A86165F896B4B800BB5C25CE18672A55579_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Exception_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Guid_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Messages_tD25B555D7E0152EFD72FB82E6E3843CCCDA276B3_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* String_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TaskCanceledException_tB1E5209054F302F814E18BBCACDF6546BAF2EC48_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Type_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral01BA7992F85DE477E8E630428EB5ED14769F9155;
IL2CPP_EXTERN_C String_t* _stringLiteral0A5A3986DAA2141AA71AD79F5BE515664FC07A37;
IL2CPP_EXTERN_C String_t* _stringLiteral0CF128F0185D0AAF2854CFBC0EDB34460E5F529E;
IL2CPP_EXTERN_C String_t* _stringLiteral0DA57E388A3E0B2139C06600A6C796230AB8B5D7;
IL2CPP_EXTERN_C String_t* _stringLiteral0EE291B9316432879664DDEFE015DA3D0D04C664;
IL2CPP_EXTERN_C String_t* _stringLiteral1100C278A2149AE25E6C9D115CC40383875DA328;
IL2CPP_EXTERN_C String_t* _stringLiteral13A372FA1ADE32B3077F2878063E147B5490768D;
IL2CPP_EXTERN_C String_t* _stringLiteral1439A06384A159CD45C0CCDE53F72F30FD15FD22;
IL2CPP_EXTERN_C String_t* _stringLiteral21D989A541A872BB9D3762D9DFFF0F3072DE0445;
IL2CPP_EXTERN_C String_t* _stringLiteral29F0D275C3CF8BD94A296DB72E80EA061DF558D6;
IL2CPP_EXTERN_C String_t* _stringLiteral2BDA1C5D2E633249BBEE7BECBAE728747171CCF2;
IL2CPP_EXTERN_C String_t* _stringLiteral2DAABBE443140677B21642B084FB0DDFF84904B7;
IL2CPP_EXTERN_C String_t* _stringLiteral2DEB67EF43F9E641C7455D80D92FC48227D84C6C;
IL2CPP_EXTERN_C String_t* _stringLiteral30BAA24967E08965D1594408031F0324AE11CCAC;
IL2CPP_EXTERN_C String_t* _stringLiteral32C70CEBF110EEDB8637B5E875A6C94F1EF6E8C5;
IL2CPP_EXTERN_C String_t* _stringLiteral34EBDF208667B8C52EA799739D7D859B466DE3D1;
IL2CPP_EXTERN_C String_t* _stringLiteral3A2800F24C7C2D7C9500D358F429B9DBB39A229A;
IL2CPP_EXTERN_C String_t* _stringLiteral3E3989AB04E4455D509DAA6CD05571B080E4D7F6;
IL2CPP_EXTERN_C String_t* _stringLiteral3E44C920427E845DF4958295EB8C3045B55FCFD5;
IL2CPP_EXTERN_C String_t* _stringLiteral4FD19FAE88F259405F9AE652A1A77583AC534FB2;
IL2CPP_EXTERN_C String_t* _stringLiteral5006ED0248A019713B762563076292379DAF07B4;
IL2CPP_EXTERN_C String_t* _stringLiteral521FB7097B70476A3E1F5E4B812E25F28991CB8F;
IL2CPP_EXTERN_C String_t* _stringLiteral56070A568367D5A4E9970CFFF19CB97578CE1361;
IL2CPP_EXTERN_C String_t* _stringLiteral5E82BDD9CD88FBA2F846334A2D213A3199C5C73E;
IL2CPP_EXTERN_C String_t* _stringLiteral63D62D4AEE9A5D4FE8539E53A9E3D05FFC210C9B;
IL2CPP_EXTERN_C String_t* _stringLiteral64D2F058B2C616C8EFED8152F4A527D3F4A3F56F;
IL2CPP_EXTERN_C String_t* _stringLiteral65068281F583818187F997A36D242A89750AC7F9;
IL2CPP_EXTERN_C String_t* _stringLiteral6E6975211C2EC5DF87ECA6F10522B61408628C47;
IL2CPP_EXTERN_C String_t* _stringLiteral6EEF6648406C333A4035CD5E60D0BF2ECF2606D7;
IL2CPP_EXTERN_C String_t* _stringLiteral78272321B843EDB866543FEA772D57A3E1AB374E;
IL2CPP_EXTERN_C String_t* _stringLiteral7AAB67A524EC369B9D708D84DC85A9E10DDAD247;
IL2CPP_EXTERN_C String_t* _stringLiteral7B7C3753BD237A59A89DDD31B04B4253900F7101;
IL2CPP_EXTERN_C String_t* _stringLiteral81A699D4D87542144D512C24A1862E6E0C575602;
IL2CPP_EXTERN_C String_t* _stringLiteral841E058CC2C285F32E177EC99D0203C01BAE625D;
IL2CPP_EXTERN_C String_t* _stringLiteral884405D16B0748FF736292F6E63C4CB9411E73B4;
IL2CPP_EXTERN_C String_t* _stringLiteral975FA903026B31A9F131D79CA7D5A3C419167BE3;
IL2CPP_EXTERN_C String_t* _stringLiteral98F54143AB4E86B28C3AFEE0F50F2F51CFB2ED38;
IL2CPP_EXTERN_C String_t* _stringLiteral9A53A1188CADA337FB136F35F09E145211EA6D33;
IL2CPP_EXTERN_C String_t* _stringLiteral9E4CA27B355FD460812EA4B5B4A70907455DB5EC;
IL2CPP_EXTERN_C String_t* _stringLiteralA5DA2189ECA4EFF57E0D70FFAD03138FACBEA493;
IL2CPP_EXTERN_C String_t* _stringLiteralA61F5E4AE96501BEBBC6733EE1441E23E592881B;
IL2CPP_EXTERN_C String_t* _stringLiteralA72502067518684F9DEEEC70CF119FD26326CD33;
IL2CPP_EXTERN_C String_t* _stringLiteralA75543DB956397B3AAF3798633E311C2C2352857;
IL2CPP_EXTERN_C String_t* _stringLiteralA85865E9EE2503B850D7E7E0EB3ACFCC242A0C27;
IL2CPP_EXTERN_C String_t* _stringLiteralAA4A5F8125F234182E2DEA92805AFDFB747A86BE;
IL2CPP_EXTERN_C String_t* _stringLiteralAAF42B55E4D31D4476DEB2C93D749D172FB6A78E;
IL2CPP_EXTERN_C String_t* _stringLiteralAD8919ACE091B14011C6439CFD5E1707B58F5ABD;
IL2CPP_EXTERN_C String_t* _stringLiteralADD50DC32B886BB91B26CB80CF5526F3F9CFBCE0;
IL2CPP_EXTERN_C String_t* _stringLiteralAF655BFDF69FC9B2FF11EAC5ACC69C16AE7AB9D5;
IL2CPP_EXTERN_C String_t* _stringLiteralAFFFDD08D81DD168981D9A0DCCEB2FB24C2AB56A;
IL2CPP_EXTERN_C String_t* _stringLiteralB57149B2CB8478D76FBB48F89ED551B22A913C4A;
IL2CPP_EXTERN_C String_t* _stringLiteralBF21A9E8FBC5A3846FB05B4FA0859E0917B2202F;
IL2CPP_EXTERN_C String_t* _stringLiteralC03C9E03EF9031F1884F64E7D2C4CECE8066943D;
IL2CPP_EXTERN_C String_t* _stringLiteralC1711278AE69E1916962F0754E0D596566858442;
IL2CPP_EXTERN_C String_t* _stringLiteralC3A12CF2C913253F799D73280079AB3A6ABEF3B4;
IL2CPP_EXTERN_C String_t* _stringLiteralC5497BCA58468AE64AED6C0FD921109217988DB3;
IL2CPP_EXTERN_C String_t* _stringLiteralCA8156011050BBBC5972C9E5388071F8374EDEF4;
IL2CPP_EXTERN_C String_t* _stringLiteralD3F06A581B2B66FA7A3965DDEB6FB307F7BE20BA;
IL2CPP_EXTERN_C String_t* _stringLiteralD6720DD1056FA18CDA232DCEE48F2C7F93C5498A;
IL2CPP_EXTERN_C String_t* _stringLiteralD9842BE6592DBAC6DB4096D01408D6F0BB6D295A;
IL2CPP_EXTERN_C String_t* _stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709;
IL2CPP_EXTERN_C String_t* _stringLiteralDAD9C4182CF9862CDD00BFB8ABC34EE355283AA2;
IL2CPP_EXTERN_C String_t* _stringLiteralDF91E4F832891C6C2664A695B7C49E72D5414B8F;
IL2CPP_EXTERN_C String_t* _stringLiteralE28DCD4D264C656D8E287F57412D38AB4732B1F4;
IL2CPP_EXTERN_C String_t* _stringLiteralE7BFD0F7AF4EBF7DA118143137EA49D776896104;
IL2CPP_EXTERN_C String_t* _stringLiteralE8EFD34D217B4D3B444529914BD6F8F32330D85A;
IL2CPP_EXTERN_C String_t* _stringLiteralEA82829F65F92FD02BFF592AF541585CBFBDA281;
IL2CPP_EXTERN_C String_t* _stringLiteralEDF719C70211ED45FD8CC49FBF0B6EDB7D79DA78;
IL2CPP_EXTERN_C String_t* _stringLiteralF4BB5287F1F7F06D43442AB7E16E48611FEF2CA7;
IL2CPP_EXTERN_C String_t* _stringLiteralF68BE0CD5F76E3FB04BD01BC622726AA56A16DB8;
IL2CPP_EXTERN_C String_t* _stringLiteralF6F4DA8D93E88A08220E03B7810451D3BA540A34;
IL2CPP_EXTERN_C String_t* _stringLiteralF8A33074742E5DB761623D7FA8CFF61C2BFE483E;
IL2CPP_EXTERN_C String_t* _stringLiteralFA0B17AAE9869D691F0902955D0B60D61440D765;
IL2CPP_EXTERN_C String_t* _stringLiteralFCFC80212C4D07D824FB2CF6431A65784130AEBB;
IL2CPP_EXTERN_C const RuntimeMethod* AkWaapiClient_Wamp_Disconnected_mA53BAA173A2BFE01B0BD97F5BF3A2D1EC9E0113F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySegment_1__ctor_m6305655CDE2F6E154BA79003B66CF61795462804_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySegment_1__ctor_mC699D21C137279D4D9A501143A898CCB0971D382_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySegment_1_get_Offset_m6651443913CC50A02AE5D7C4CDC6F6744D39B483_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_mD1999A0F69B3FB48161783859F369FDCA943E7ED_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_mABEC0D792F8A5AC3256DBC194D55631CC98783FB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mF490191D1E3DB080FB623CECA0FE22B25E9F298D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m2EB1C430D6D5413CB1A2A876F98D2F34F4C9BEF3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_mDC84E980D918760546764180E8EFF9C820AC03B2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_mC22DC39F316BF248F38A8A452016A5A992B8C5EF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_mA44D0B4B5FB1613D34ACD01F6D6F1E99E95AD4C8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mE41874465445B27A74796D0922012A53154AC9C3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m7F46BD9D275C21386FD4E0DA80512950AFC6587E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Create_m4CACDA7CCC96C431E5426E670B268CC6FDF86695_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Create_m94B4F919FEC6BCB096ECA1FD0DE9594CBBD14576_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Create_mFA0E603D8EEE094438B0465D1E57747E2E12FC70_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetException_m4BCFE40068BC66F1C48B5C7C7C9F93F5E48EF00B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetException_m7EC0D7D4B3431CA02400760ADA732A416EAEFB2D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetException_m89F128C1E1A0F0E16A1FFA86AD6A96E8997DB857_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetResult_m013485E27C036058F955FBFB38CB72C8390A9C92_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetResult_m44836E9953D99A304CCB8725A8E47453725FFE9B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetResult_m887E134B6FD52D8CA2116A466F69BC8E1EA6ED5E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetStateMachine_m2C2B09AB812EDEDAB3C9E89B8A2BF19C4EC8B45F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetStateMachine_m5EF4BCC5A6E298F61AF578E53EAF3AD0FEE6C5D3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_SetStateMachine_m83945BA8843F53C1C9ED18D4B312FFF9A24BB9EB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_m1109EFCCABBD7FBE73DF89539EA069F7803F4CA2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_mF1115D2856D6D60A689700396433A6E0BFEF1B44_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Start_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m8CA846E439DFA4D8D21C28CF451D501736903735_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Start_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_m2B93F2B8EC2D264EE75A4DF55225BCC2F83A7E3B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Start_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_m2642B44518F49E595EC0F58CBE4876BB59B52DBB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m4CFDDD929A9A264EF81EAA747130B8946DD69999_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_m9E8504336F653A9061842B0CE589D6072249F798_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_get_Task_m157191133E216D7561AD02E894BCA819FD5F98FF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_get_Task_m7CB437A60103DC49A5C02014C51B0684D0E3E69C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_1_get_Task_mB005567F7203FC44DD0AE1150FFC92706B8E2BB4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m67D96E6CEEDCD41F4AD94298BF70CFB2EBA1D917_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_mCD9168B1DF026CB3BB6DEF84647D3DAD1BA186A6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m04E32B234DB4F762A2F7D6F2540BA392DBC0EF2A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mDAC2ADF8AB1E52888B4479666D626F617937E900_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mA764FAAB815FCF8AE6EEDC1517B93BDDDA7D35E6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m393F31C0EF4CBF441A486F7C6A0D4AB4B58B4286_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_m86930540C6C3B639FB8E3043C372E6B46488F0AD_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m0996EC60B40B2090B23E54881415F88FBE155480_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_mD436987D09427E1D06EC26E219AD2D10638951B6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m553F9508C8EF12D8C31A1E1B935D79855E6FF52C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m014E726B3574D52F7F9E118E1B7A58DF73336783_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mC26FDDD09F7C37DC8CCAB604721FE4F6DC561F89_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m83286F1C813B3EF711EFFF20F60DF019DD0EF82A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_mF16437EE3964A0173C4ACD6C55A8A527F10F6357_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_Start_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m3BE2ACD6057BFEC9516FD5CA2EC71DD1F46E95FB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_m8DCB5F69062BBD1684327A53545EED187BDE62C7_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m9B9904F2786C63840AA72106EF2A750CB549AEA3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConcurrentDictionary_2_TryAdd_mE2925CDD203464DF30191E99B8FC7F6FBD10420B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConcurrentDictionary_2_TryGetValue_mB8CB5BED33D46B4F69E7967FA50455B66E08A421_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConcurrentDictionary_2_TryRemove_m69838C15D68F91E4E959F18061311021A99D41FB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ConcurrentDictionary_2__ctor_mAE7C80BE83DA4BF21D02463F2AEC2BDA59704B2F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2__ctor_m5B1C279E77422BB0B2C7B0374ECF89E3224AF62B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2__ctor_m9457A48CCEE984A72083457DACF6F3F0C97E4AA5_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2__ctor_mF9BF70BC1501E2DD8B1B8928E3920BF963A562A5_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_SelectMany_TisIEnumerable_1_t5A38FCC3E9F64286F2A624D6571AF9EA7844398E_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m90F6F46EB605689C56C3A8F2667983FB5C70265A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_Skip_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m73025D0C956827AA7A6EA962A50C8B63F69FBBBE_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_Take_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_mFBC4D57366E255AFC2F139800ABAD01A519B2B05_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_ToArray_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m48AFCA8923688797114AA384B978E290AAAF206B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ErrorException_FromResponse_m7F3FD8A84BC8AEF0BC62A4CD5203DF961BC803C9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Func_2__ctor_m71F83ACB080E1E97771766B7F659BD1B091831B7_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_m4454ADA74D82DCE063A15F0A54CE55D3CDFAA382_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_mB7D4AB3F605E57A961003A9975A9DD9E3023B769_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyDictionary_2_ContainsKey_m3D72DE0E00E5930D0399B05F47DDED2CBFA58D7A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyDictionary_2__ctor_m09C7C2FF3D8EC8592F1E582191C2F95970CA4D0F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyDictionary_2__ctor_mB2D19FDF7E2760F6CD503397D0395FBD27E877FF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyDictionary_2__ctor_mC837B9F33F33A0BA69860897896746402C48619E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ReadOnlyDictionary_2_get_Item_m2872DF7EB7C71DD1A8E217C9FACA183F7AD5A02C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_GetResult_m09DDE7E4E666D55579B249C10764EFC380DAB78B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_GetResult_m814E69FC46668F93FB02713896269AAACBD01F06_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_GetResult_mA33716D8F7BAE3970F8307C41CE96B2A452FCF5A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_GetResult_mD575FD03753A3FD916DFF7C9834342D3EEEB0EE8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_get_IsCompleted_m1B663832F61F0CC68E324522D851F61F4D9DCE13_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_get_IsCompleted_m65B87815F65EECDC664D3CD37DA73A87E753258A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_get_IsCompleted_mBD5D88440DBE5104B7AEF7A11D549FE39008740D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskAwaiter_1_get_IsCompleted_mD9FB168E3D6034701DE4736347E1B30AE6CCE70F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskCompletionSource_1_SetException_mB10C34767496AC4F8A94CA8ABA1462B2EC81C6B8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskCompletionSource_1_SetResult_mC00E900D0DF47C8A8E1AC8126E8CF9E545516EFE_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TaskCompletionSource_1_get_Task_mDC9ED85B68696CD8BD9DE3A757F317BA5C6417A4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Task_1_GetAwaiter_m67228F27784EA8C9DF71B165FAB7072A46C28A9E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Task_1_GetAwaiter_m7A7CC7C265752869A4FE28A21A3780AE1814DC56_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Task_1_GetAwaiter_m9814C67F6EAD25792CF76E9A4C961FD4704B2965_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Task_1_GetAwaiter_mAFED2623EE194913D17CD104EE32E077A0BD324E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec_U3CReceiveMessageU3Eb__24_0_m239F0211E8D016A1ACCFF6005B536DECEE383B10_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec__DisplayClass32_0_U3CStartListenU3Eb__0_mB184AA45B5F3D79923AF3B9DEAB1E06956F8D6E9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Wamp_ParseEvent_m21C36EAE091AB9B20402C75770048AA5FC9F9020_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Wamp_ParseGoodbye_m62130B50323A9CDC2F8182BA1E492B5F182A958A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Wamp_ParseResult_m1ED4173FAF19510DA46B93BCA58DAA6FE0140634_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Wamp_ParseSubscribed_m705D9E4D5465BAF013A92740D8D822AF448B1F23_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Wamp_ParseUnsubscribed_m21AF2D9070DE4E49F5CC7C53A164C1A5C2D7040E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Wamp_ParseWelcome_mDC04C238E5A69F16500F3C9A7678B10185601B58_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Wamp_ProcessEvent_mB6BA36EA16F2375692017561F09D725C6D2E6E35_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeType* WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B_0_0_0_var;
IL2CPP_EXTERN_C const uint32_t AkWaapiClient_Call_m228E834AEDE74F68F26208B1073183014B984763_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkWaapiClient_Close_mE0747AE29CCE6D2F9367E62C7748CD02B2586A8B_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkWaapiClient_Connect_m7B36FAFC8A88A778B1976073C457ACAFAD495374_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkWaapiClient_Subscribe_m4E52D19C0C845D3CCA1A1DA5CA9A77DAB7BDF996_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkWaapiClient_Unsubscribe_m1B4867EC231A6315D787905D00FCD8E6A249EC25_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkWaapiClient_add_Disconnected_m23455C48DF662205286001B85808AB1D4A8306E9_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkWaapiClient_remove_Disconnected_m0B10E01BB8B37C4FEF60591D0AA9F8943EE7345D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t ErrorException_FromResponse_m7F3FD8A84BC8AEF0BC62A4CD5203DF961BC803C9_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Task_get_Factory_m31F1298E08390A4AD46B85AB060F1FAD4CE12112Ak_Wwise_Api_WAAPI_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t TimeoutException__ctor_m2AD6BA4E69FE5415F5E571171A0346292B84E0D4_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CCallU3Ed__34_MoveNext_mFE458EC82A6FE04034653EFACBCDF773333888F1_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CCallU3Ed__34_SetStateMachine_mC98B572BE8C143D41DF3D54466223A92F1F1D6B8_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CCallU3Ed__8_SetStateMachine_mD2692F6222738E5FB87B23429B8DD0B43F651FDC_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CCloseU3Ed__30_MoveNext_mAB43192731588E3CF72C9F96212C641FB1A0184D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CConnectU3Ed__4_MoveNext_m13F3495E6D4BDE5F1C839110864B68AB3F5B7BB6_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CReceiveExpectU3Ed__26_SetStateMachine_mFDCB7BA62E930894AC2A0A7A5100EE36A256FD7B_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CReceiveMessageU3Ed__24_SetStateMachine_m1A3F556E61365751BF72BC7C8C95F8DEDBF12C3C_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CReceiveU3Ed__25_SetStateMachine_m1DFEA710015A7E2BA876C1837E14781B6BC5E68F_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CSubscribeU3Ed__35_MoveNext_m871F84E5292DE81E13BE9C94AB0EA8765E1D5285_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CSubscribeU3Ed__35_SetStateMachine_mDAD9620ACF150FAED21040DF4EAC8D41588BD7C6_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CSubscribeU3Ed__9_SetStateMachine_m5AD4A356DAE70F2EC5F1BB8257BEEF5008C4117F_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CU3Ec__DisplayClass32_0_U3CStartListenU3Eb__0_mB184AA45B5F3D79923AF3B9DEAB1E06956F8D6E9_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CU3Ec__cctor_mDD40621A39ED2248A9CD84ED04CFF64820655B0C_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t U3CUnsubscribeU3Ed__36_MoveNext_m342B13779519EDA18D70E718177AFB7256C1CB54_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t WaapiHelper_GetWwiseObjectTypeFromString_m04C5DF50A1EA2E0B0188B3C71B94B2BB406A58DE_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t WaapiKeywords__cctor_m98F6325EE529F42B2E47B71504811F517DB2059C_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_Call_mAE552B01EB08CE7275EEDD97710E512589D61B33_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_Close_m8607EFADFFC175CC0825312F7EFA8E175FA39B74_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_Connect_m091D964EE6A72E12FA0905681BF78AD05D9D7FAB_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_ParseEvent_m21C36EAE091AB9B20402C75770048AA5FC9F9020_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_ParseGoodbye_m62130B50323A9CDC2F8182BA1E492B5F182A958A_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_ParseResult_m1ED4173FAF19510DA46B93BCA58DAA6FE0140634_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_ParseSubscribed_m705D9E4D5465BAF013A92740D8D822AF448B1F23_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_ParseUnsubscribed_m21AF2D9070DE4E49F5CC7C53A164C1A5C2D7040E_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_ParseWelcome_mDC04C238E5A69F16500F3C9A7678B10185601B58_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_ProcessEvent_mB6BA36EA16F2375692017561F09D725C6D2E6E35_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_ReceiveMessage_m333714DD38A3BEBB92BA90A416BC053CDC1158BC_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_Receive_m7B47E5C25B601C3C446B02A97117ACAA3FA3BF13_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_StartListen_mD58F9728B82A7A344E95BA20A462450F5725CEB8_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_Subscribe_mC841A9CDF1DA84F41596A6E4E087CB13C8AF4F40_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_Unsubscribe_m185B046DAF9E4293617E8A512747B768958ABA6C_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp__ctor_mCD0D3AC4AB87B0AC898D448724AB0568594D6193_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_add_Disconnected_mBAA1A70AD8CE39B3A45DB824FB26FF9C2C11F143_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Wamp_remove_Disconnected_m733F63A5B3D9B63CA05DB0B31C6BE3C9456D7D9F_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t WwiseObjectInfoJsonObject_ToObjectInfo_m34217D48C83C57B40D1772E3C02CA43DCAE739E1_MetadataUsageId;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;
struct Exception_t_marshaled_com;
struct Exception_t_marshaled_pinvoke;

struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
struct ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A;
struct StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E;
struct TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t4D1B86AD95A443D328F635F46CB8E29E23BBB14F 
{
public:

public:
};


// System.Object


// AkWaapiClient
struct  AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1  : public RuntimeObject
{
public:
	// Wamp AkWaapiClient::wamp
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___wamp_0;
	// Wamp_DisconnectedHandler AkWaapiClient::Disconnected
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * ___Disconnected_1;

public:
	inline static int32_t get_offset_of_wamp_0() { return static_cast<int32_t>(offsetof(AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1, ___wamp_0)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_wamp_0() const { return ___wamp_0; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_wamp_0() { return &___wamp_0; }
	inline void set_wamp_0(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___wamp_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___wamp_0), (void*)value);
	}

	inline static int32_t get_offset_of_Disconnected_1() { return static_cast<int32_t>(offsetof(AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1, ___Disconnected_1)); }
	inline DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * get_Disconnected_1() const { return ___Disconnected_1; }
	inline DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 ** get_address_of_Disconnected_1() { return &___Disconnected_1; }
	inline void set_Disconnected_1(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * value)
	{
		___Disconnected_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Disconnected_1), (void*)value);
	}
};


// JsonSerializable
struct  JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B  : public RuntimeObject
{
public:

public:
};

struct Il2CppArrayBounds;

// System.Array


// System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,Wamp_PublishHandler>
struct  ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0  : public RuntimeObject
{
public:
	// System.Collections.Concurrent.ConcurrentDictionary`2_Tables<TKey,TValue> modreq(System.Runtime.CompilerServices.IsVolatile) System.Collections.Concurrent.ConcurrentDictionary`2::_tables
	Tables_t87424CB0A55B8483F163AC041DEB12CCB629B7A4 * ____tables_0;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Concurrent.ConcurrentDictionary`2::_comparer
	RuntimeObject* ____comparer_1;
	// System.Boolean System.Collections.Concurrent.ConcurrentDictionary`2::_growLockArray
	bool ____growLockArray_2;
	// System.Int32 System.Collections.Concurrent.ConcurrentDictionary`2::_budget
	int32_t ____budget_3;

public:
	inline static int32_t get_offset_of__tables_0() { return static_cast<int32_t>(offsetof(ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0, ____tables_0)); }
	inline Tables_t87424CB0A55B8483F163AC041DEB12CCB629B7A4 * get__tables_0() const { return ____tables_0; }
	inline Tables_t87424CB0A55B8483F163AC041DEB12CCB629B7A4 ** get_address_of__tables_0() { return &____tables_0; }
	inline void set__tables_0(Tables_t87424CB0A55B8483F163AC041DEB12CCB629B7A4 * value)
	{
		____tables_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____tables_0), (void*)value);
	}

	inline static int32_t get_offset_of__comparer_1() { return static_cast<int32_t>(offsetof(ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0, ____comparer_1)); }
	inline RuntimeObject* get__comparer_1() const { return ____comparer_1; }
	inline RuntimeObject** get_address_of__comparer_1() { return &____comparer_1; }
	inline void set__comparer_1(RuntimeObject* value)
	{
		____comparer_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____comparer_1), (void*)value);
	}

	inline static int32_t get_offset_of__growLockArray_2() { return static_cast<int32_t>(offsetof(ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0, ____growLockArray_2)); }
	inline bool get__growLockArray_2() const { return ____growLockArray_2; }
	inline bool* get_address_of__growLockArray_2() { return &____growLockArray_2; }
	inline void set__growLockArray_2(bool value)
	{
		____growLockArray_2 = value;
	}

	inline static int32_t get_offset_of__budget_3() { return static_cast<int32_t>(offsetof(ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0, ____budget_3)); }
	inline int32_t get__budget_3() const { return ____budget_3; }
	inline int32_t* get_address_of__budget_3() { return &____budget_3; }
	inline void set__budget_3(int32_t value)
	{
		____budget_3 = value;
	}
};

struct ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0_StaticFields
{
public:
	// System.Boolean System.Collections.Concurrent.ConcurrentDictionary`2::s_isValueWriteAtomic
	bool ___s_isValueWriteAtomic_4;

public:
	inline static int32_t get_offset_of_s_isValueWriteAtomic_4() { return static_cast<int32_t>(offsetof(ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0_StaticFields, ___s_isValueWriteAtomic_4)); }
	inline bool get_s_isValueWriteAtomic_4() const { return ___s_isValueWriteAtomic_4; }
	inline bool* get_address_of_s_isValueWriteAtomic_4() { return &___s_isValueWriteAtomic_4; }
	inline void set_s_isValueWriteAtomic_4(bool value)
	{
		___s_isValueWriteAtomic_4 = value;
	}
};


// System.Collections.Generic.Dictionary`2<System.String,System.String>
struct  Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::buckets
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___buckets_0;
	// System.Collections.Generic.Dictionary`2_Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::entries
	EntryU5BU5D_t034347107F1D23C91DE1D712EA637D904789415C* ___entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::version
	int32_t ___version_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeList
	int32_t ___freeList_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeCount
	int32_t ___freeCount_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::comparer
	RuntimeObject* ___comparer_6;
	// System.Collections.Generic.Dictionary`2_KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::keys
	KeyCollection_tC73654392B284B89334464107B696C9BD89776D9 * ___keys_7;
	// System.Collections.Generic.Dictionary`2_ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::values
	ValueCollection_tA3B972EF56F7C97E35054155C33556C55FAAFD43 * ___values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject * ____syncRoot_9;

public:
	inline static int32_t get_offset_of_buckets_0() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ___buckets_0)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_buckets_0() const { return ___buckets_0; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_buckets_0() { return &___buckets_0; }
	inline void set_buckets_0(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___buckets_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___buckets_0), (void*)value);
	}

	inline static int32_t get_offset_of_entries_1() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ___entries_1)); }
	inline EntryU5BU5D_t034347107F1D23C91DE1D712EA637D904789415C* get_entries_1() const { return ___entries_1; }
	inline EntryU5BU5D_t034347107F1D23C91DE1D712EA637D904789415C** get_address_of_entries_1() { return &___entries_1; }
	inline void set_entries_1(EntryU5BU5D_t034347107F1D23C91DE1D712EA637D904789415C* value)
	{
		___entries_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___entries_1), (void*)value);
	}

	inline static int32_t get_offset_of_count_2() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ___count_2)); }
	inline int32_t get_count_2() const { return ___count_2; }
	inline int32_t* get_address_of_count_2() { return &___count_2; }
	inline void set_count_2(int32_t value)
	{
		___count_2 = value;
	}

	inline static int32_t get_offset_of_version_3() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ___version_3)); }
	inline int32_t get_version_3() const { return ___version_3; }
	inline int32_t* get_address_of_version_3() { return &___version_3; }
	inline void set_version_3(int32_t value)
	{
		___version_3 = value;
	}

	inline static int32_t get_offset_of_freeList_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ___freeList_4)); }
	inline int32_t get_freeList_4() const { return ___freeList_4; }
	inline int32_t* get_address_of_freeList_4() { return &___freeList_4; }
	inline void set_freeList_4(int32_t value)
	{
		___freeList_4 = value;
	}

	inline static int32_t get_offset_of_freeCount_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ___freeCount_5)); }
	inline int32_t get_freeCount_5() const { return ___freeCount_5; }
	inline int32_t* get_address_of_freeCount_5() { return &___freeCount_5; }
	inline void set_freeCount_5(int32_t value)
	{
		___freeCount_5 = value;
	}

	inline static int32_t get_offset_of_comparer_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ___comparer_6)); }
	inline RuntimeObject* get_comparer_6() const { return ___comparer_6; }
	inline RuntimeObject** get_address_of_comparer_6() { return &___comparer_6; }
	inline void set_comparer_6(RuntimeObject* value)
	{
		___comparer_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___comparer_6), (void*)value);
	}

	inline static int32_t get_offset_of_keys_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ___keys_7)); }
	inline KeyCollection_tC73654392B284B89334464107B696C9BD89776D9 * get_keys_7() const { return ___keys_7; }
	inline KeyCollection_tC73654392B284B89334464107B696C9BD89776D9 ** get_address_of_keys_7() { return &___keys_7; }
	inline void set_keys_7(KeyCollection_tC73654392B284B89334464107B696C9BD89776D9 * value)
	{
		___keys_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___keys_7), (void*)value);
	}

	inline static int32_t get_offset_of_values_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ___values_8)); }
	inline ValueCollection_tA3B972EF56F7C97E35054155C33556C55FAAFD43 * get_values_8() const { return ___values_8; }
	inline ValueCollection_tA3B972EF56F7C97E35054155C33556C55FAAFD43 ** get_address_of_values_8() { return &___values_8; }
	inline void set_values_8(ValueCollection_tA3B972EF56F7C97E35054155C33556C55FAAFD43 * value)
	{
		___values_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___values_8), (void*)value);
	}

	inline static int32_t get_offset_of__syncRoot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC, ____syncRoot_9)); }
	inline RuntimeObject * get__syncRoot_9() const { return ____syncRoot_9; }
	inline RuntimeObject ** get_address_of__syncRoot_9() { return &____syncRoot_9; }
	inline void set__syncRoot_9(RuntimeObject * value)
	{
		____syncRoot_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_9), (void*)value);
	}
};


// System.Collections.Generic.Dictionary`2<System.String,WwiseObjectType>
struct  Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::buckets
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___buckets_0;
	// System.Collections.Generic.Dictionary`2_Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::entries
	EntryU5BU5D_t75456DA7869220FFE8699CBAB590660094FBFE65* ___entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::version
	int32_t ___version_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeList
	int32_t ___freeList_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeCount
	int32_t ___freeCount_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::comparer
	RuntimeObject* ___comparer_6;
	// System.Collections.Generic.Dictionary`2_KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::keys
	KeyCollection_t52478C64ED19521AEA3ECDE6A4E8F2A48DD894E4 * ___keys_7;
	// System.Collections.Generic.Dictionary`2_ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::values
	ValueCollection_t4FE98A9B48A13CEE31D805E33CE479D57B82F7E0 * ___values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject * ____syncRoot_9;

public:
	inline static int32_t get_offset_of_buckets_0() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ___buckets_0)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_buckets_0() const { return ___buckets_0; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_buckets_0() { return &___buckets_0; }
	inline void set_buckets_0(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___buckets_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___buckets_0), (void*)value);
	}

	inline static int32_t get_offset_of_entries_1() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ___entries_1)); }
	inline EntryU5BU5D_t75456DA7869220FFE8699CBAB590660094FBFE65* get_entries_1() const { return ___entries_1; }
	inline EntryU5BU5D_t75456DA7869220FFE8699CBAB590660094FBFE65** get_address_of_entries_1() { return &___entries_1; }
	inline void set_entries_1(EntryU5BU5D_t75456DA7869220FFE8699CBAB590660094FBFE65* value)
	{
		___entries_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___entries_1), (void*)value);
	}

	inline static int32_t get_offset_of_count_2() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ___count_2)); }
	inline int32_t get_count_2() const { return ___count_2; }
	inline int32_t* get_address_of_count_2() { return &___count_2; }
	inline void set_count_2(int32_t value)
	{
		___count_2 = value;
	}

	inline static int32_t get_offset_of_version_3() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ___version_3)); }
	inline int32_t get_version_3() const { return ___version_3; }
	inline int32_t* get_address_of_version_3() { return &___version_3; }
	inline void set_version_3(int32_t value)
	{
		___version_3 = value;
	}

	inline static int32_t get_offset_of_freeList_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ___freeList_4)); }
	inline int32_t get_freeList_4() const { return ___freeList_4; }
	inline int32_t* get_address_of_freeList_4() { return &___freeList_4; }
	inline void set_freeList_4(int32_t value)
	{
		___freeList_4 = value;
	}

	inline static int32_t get_offset_of_freeCount_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ___freeCount_5)); }
	inline int32_t get_freeCount_5() const { return ___freeCount_5; }
	inline int32_t* get_address_of_freeCount_5() { return &___freeCount_5; }
	inline void set_freeCount_5(int32_t value)
	{
		___freeCount_5 = value;
	}

	inline static int32_t get_offset_of_comparer_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ___comparer_6)); }
	inline RuntimeObject* get_comparer_6() const { return ___comparer_6; }
	inline RuntimeObject** get_address_of_comparer_6() { return &___comparer_6; }
	inline void set_comparer_6(RuntimeObject* value)
	{
		___comparer_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___comparer_6), (void*)value);
	}

	inline static int32_t get_offset_of_keys_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ___keys_7)); }
	inline KeyCollection_t52478C64ED19521AEA3ECDE6A4E8F2A48DD894E4 * get_keys_7() const { return ___keys_7; }
	inline KeyCollection_t52478C64ED19521AEA3ECDE6A4E8F2A48DD894E4 ** get_address_of_keys_7() { return &___keys_7; }
	inline void set_keys_7(KeyCollection_t52478C64ED19521AEA3ECDE6A4E8F2A48DD894E4 * value)
	{
		___keys_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___keys_7), (void*)value);
	}

	inline static int32_t get_offset_of_values_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ___values_8)); }
	inline ValueCollection_t4FE98A9B48A13CEE31D805E33CE479D57B82F7E0 * get_values_8() const { return ___values_8; }
	inline ValueCollection_t4FE98A9B48A13CEE31D805E33CE479D57B82F7E0 ** get_address_of_values_8() { return &___values_8; }
	inline void set_values_8(ValueCollection_t4FE98A9B48A13CEE31D805E33CE479D57B82F7E0 * value)
	{
		___values_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___values_8), (void*)value);
	}

	inline static int32_t get_offset_of__syncRoot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F, ____syncRoot_9)); }
	inline RuntimeObject * get__syncRoot_9() const { return ____syncRoot_9; }
	inline RuntimeObject ** get_address_of__syncRoot_9() { return &____syncRoot_9; }
	inline void set__syncRoot_9(RuntimeObject * value)
	{
		____syncRoot_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_9), (void*)value);
	}
};


// System.Collections.Generic.Dictionary`2<WwiseObjectType,System.String>
struct  Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::buckets
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___buckets_0;
	// System.Collections.Generic.Dictionary`2_Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::entries
	EntryU5BU5D_t0F5AD1E97902ED91447307E40433A27CC9D08FB2* ___entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::version
	int32_t ___version_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeList
	int32_t ___freeList_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeCount
	int32_t ___freeCount_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::comparer
	RuntimeObject* ___comparer_6;
	// System.Collections.Generic.Dictionary`2_KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::keys
	KeyCollection_tFC544D692DFDD6334D2301D61DFF17C07B2A9F7C * ___keys_7;
	// System.Collections.Generic.Dictionary`2_ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::values
	ValueCollection_t5489901F3AFE8B14EC1C0E39B9224C1DB0EF0D78 * ___values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject * ____syncRoot_9;

public:
	inline static int32_t get_offset_of_buckets_0() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ___buckets_0)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_buckets_0() const { return ___buckets_0; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_buckets_0() { return &___buckets_0; }
	inline void set_buckets_0(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___buckets_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___buckets_0), (void*)value);
	}

	inline static int32_t get_offset_of_entries_1() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ___entries_1)); }
	inline EntryU5BU5D_t0F5AD1E97902ED91447307E40433A27CC9D08FB2* get_entries_1() const { return ___entries_1; }
	inline EntryU5BU5D_t0F5AD1E97902ED91447307E40433A27CC9D08FB2** get_address_of_entries_1() { return &___entries_1; }
	inline void set_entries_1(EntryU5BU5D_t0F5AD1E97902ED91447307E40433A27CC9D08FB2* value)
	{
		___entries_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___entries_1), (void*)value);
	}

	inline static int32_t get_offset_of_count_2() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ___count_2)); }
	inline int32_t get_count_2() const { return ___count_2; }
	inline int32_t* get_address_of_count_2() { return &___count_2; }
	inline void set_count_2(int32_t value)
	{
		___count_2 = value;
	}

	inline static int32_t get_offset_of_version_3() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ___version_3)); }
	inline int32_t get_version_3() const { return ___version_3; }
	inline int32_t* get_address_of_version_3() { return &___version_3; }
	inline void set_version_3(int32_t value)
	{
		___version_3 = value;
	}

	inline static int32_t get_offset_of_freeList_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ___freeList_4)); }
	inline int32_t get_freeList_4() const { return ___freeList_4; }
	inline int32_t* get_address_of_freeList_4() { return &___freeList_4; }
	inline void set_freeList_4(int32_t value)
	{
		___freeList_4 = value;
	}

	inline static int32_t get_offset_of_freeCount_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ___freeCount_5)); }
	inline int32_t get_freeCount_5() const { return ___freeCount_5; }
	inline int32_t* get_address_of_freeCount_5() { return &___freeCount_5; }
	inline void set_freeCount_5(int32_t value)
	{
		___freeCount_5 = value;
	}

	inline static int32_t get_offset_of_comparer_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ___comparer_6)); }
	inline RuntimeObject* get_comparer_6() const { return ___comparer_6; }
	inline RuntimeObject** get_address_of_comparer_6() { return &___comparer_6; }
	inline void set_comparer_6(RuntimeObject* value)
	{
		___comparer_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___comparer_6), (void*)value);
	}

	inline static int32_t get_offset_of_keys_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ___keys_7)); }
	inline KeyCollection_tFC544D692DFDD6334D2301D61DFF17C07B2A9F7C * get_keys_7() const { return ___keys_7; }
	inline KeyCollection_tFC544D692DFDD6334D2301D61DFF17C07B2A9F7C ** get_address_of_keys_7() { return &___keys_7; }
	inline void set_keys_7(KeyCollection_tFC544D692DFDD6334D2301D61DFF17C07B2A9F7C * value)
	{
		___keys_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___keys_7), (void*)value);
	}

	inline static int32_t get_offset_of_values_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ___values_8)); }
	inline ValueCollection_t5489901F3AFE8B14EC1C0E39B9224C1DB0EF0D78 * get_values_8() const { return ___values_8; }
	inline ValueCollection_t5489901F3AFE8B14EC1C0E39B9224C1DB0EF0D78 ** get_address_of_values_8() { return &___values_8; }
	inline void set_values_8(ValueCollection_t5489901F3AFE8B14EC1C0E39B9224C1DB0EF0D78 * value)
	{
		___values_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___values_8), (void*)value);
	}

	inline static int32_t get_offset_of__syncRoot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD, ____syncRoot_9)); }
	inline RuntimeObject * get__syncRoot_9() const { return ____syncRoot_9; }
	inline RuntimeObject ** get_address_of__syncRoot_9() { return &____syncRoot_9; }
	inline void set__syncRoot_9(RuntimeObject * value)
	{
		____syncRoot_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_9), (void*)value);
	}
};


// System.Collections.Generic.List`1<System.Collections.Generic.IEnumerable`1<System.Byte>>
struct  List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	IEnumerable_1U5BU5D_tF249225453DF491E891C68DF212C88B54C1329FD* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814, ____items_1)); }
	inline IEnumerable_1U5BU5D_tF249225453DF491E891C68DF212C88B54C1329FD* get__items_1() const { return ____items_1; }
	inline IEnumerable_1U5BU5D_tF249225453DF491E891C68DF212C88B54C1329FD** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(IEnumerable_1U5BU5D_tF249225453DF491E891C68DF212C88B54C1329FD* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____items_1), (void*)value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____syncRoot_4), (void*)value);
	}
};

struct List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	IEnumerable_1U5BU5D_tF249225453DF491E891C68DF212C88B54C1329FD* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814_StaticFields, ____emptyArray_5)); }
	inline IEnumerable_1U5BU5D_tF249225453DF491E891C68DF212C88B54C1329FD* get__emptyArray_5() const { return ____emptyArray_5; }
	inline IEnumerable_1U5BU5D_tF249225453DF491E891C68DF212C88B54C1329FD** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(IEnumerable_1U5BU5D_tF249225453DF491E891C68DF212C88B54C1329FD* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptyArray_5), (void*)value);
	}
};


// System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,System.String>
struct  ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE  : public RuntimeObject
{
public:
	// System.Collections.Generic.IDictionary`2<TKey,TValue> System.Collections.ObjectModel.ReadOnlyDictionary`2::m_dictionary
	RuntimeObject* ___m_dictionary_0;

public:
	inline static int32_t get_offset_of_m_dictionary_0() { return static_cast<int32_t>(offsetof(ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE, ___m_dictionary_0)); }
	inline RuntimeObject* get_m_dictionary_0() const { return ___m_dictionary_0; }
	inline RuntimeObject** get_address_of_m_dictionary_0() { return &___m_dictionary_0; }
	inline void set_m_dictionary_0(RuntimeObject* value)
	{
		___m_dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_dictionary_0), (void*)value);
	}
};


// System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,WwiseObjectType>
struct  ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3  : public RuntimeObject
{
public:
	// System.Collections.Generic.IDictionary`2<TKey,TValue> System.Collections.ObjectModel.ReadOnlyDictionary`2::m_dictionary
	RuntimeObject* ___m_dictionary_0;

public:
	inline static int32_t get_offset_of_m_dictionary_0() { return static_cast<int32_t>(offsetof(ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3, ___m_dictionary_0)); }
	inline RuntimeObject* get_m_dictionary_0() const { return ___m_dictionary_0; }
	inline RuntimeObject** get_address_of_m_dictionary_0() { return &___m_dictionary_0; }
	inline void set_m_dictionary_0(RuntimeObject* value)
	{
		___m_dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_dictionary_0), (void*)value);
	}
};


// System.Collections.ObjectModel.ReadOnlyDictionary`2<WwiseObjectType,System.String>
struct  ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D  : public RuntimeObject
{
public:
	// System.Collections.Generic.IDictionary`2<TKey,TValue> System.Collections.ObjectModel.ReadOnlyDictionary`2::m_dictionary
	RuntimeObject* ___m_dictionary_0;

public:
	inline static int32_t get_offset_of_m_dictionary_0() { return static_cast<int32_t>(offsetof(ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D, ___m_dictionary_0)); }
	inline RuntimeObject* get_m_dictionary_0() const { return ___m_dictionary_0; }
	inline RuntimeObject** get_address_of_m_dictionary_0() { return &___m_dictionary_0; }
	inline void set_m_dictionary_0(RuntimeObject* value)
	{
		___m_dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_dictionary_0), (void*)value);
	}
};


// System.Net.WebSockets.WebSocket
struct  WebSocket_tED193A2E3239A732E23EF89376A08B1428EF0B39  : public RuntimeObject
{
public:

public:
};


// System.Reflection.MemberInfo
struct  MemberInfo_t  : public RuntimeObject
{
public:

public:
};


// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::m_stringLength
	int32_t ___m_stringLength_0;
	// System.Char System.String::m_firstChar
	Il2CppChar ___m_firstChar_1;

public:
	inline static int32_t get_offset_of_m_stringLength_0() { return static_cast<int32_t>(offsetof(String_t, ___m_stringLength_0)); }
	inline int32_t get_m_stringLength_0() const { return ___m_stringLength_0; }
	inline int32_t* get_address_of_m_stringLength_0() { return &___m_stringLength_0; }
	inline void set_m_stringLength_0(int32_t value)
	{
		___m_stringLength_0 = value;
	}

	inline static int32_t get_offset_of_m_firstChar_1() { return static_cast<int32_t>(offsetof(String_t, ___m_firstChar_1)); }
	inline Il2CppChar get_m_firstChar_1() const { return ___m_firstChar_1; }
	inline Il2CppChar* get_address_of_m_firstChar_1() { return &___m_firstChar_1; }
	inline void set_m_firstChar_1(Il2CppChar value)
	{
		___m_firstChar_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_5;

public:
	inline static int32_t get_offset_of_Empty_5() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_5)); }
	inline String_t* get_Empty_5() const { return ___Empty_5; }
	inline String_t** get_address_of_Empty_5() { return &___Empty_5; }
	inline void set_Empty_5(String_t* value)
	{
		___Empty_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Empty_5), (void*)value);
	}
};


// System.Text.Encoding
struct  Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4  : public RuntimeObject
{
public:
	// System.Int32 System.Text.Encoding::m_codePage
	int32_t ___m_codePage_9;
	// System.Globalization.CodePageDataItem System.Text.Encoding::dataItem
	CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB * ___dataItem_10;
	// System.Boolean System.Text.Encoding::m_deserializedFromEverett
	bool ___m_deserializedFromEverett_11;
	// System.Boolean System.Text.Encoding::m_isReadOnly
	bool ___m_isReadOnly_12;
	// System.Text.EncoderFallback System.Text.Encoding::encoderFallback
	EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63 * ___encoderFallback_13;
	// System.Text.DecoderFallback System.Text.Encoding::decoderFallback
	DecoderFallback_t128445EB7676870485230893338EF044F6B72F60 * ___decoderFallback_14;

public:
	inline static int32_t get_offset_of_m_codePage_9() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___m_codePage_9)); }
	inline int32_t get_m_codePage_9() const { return ___m_codePage_9; }
	inline int32_t* get_address_of_m_codePage_9() { return &___m_codePage_9; }
	inline void set_m_codePage_9(int32_t value)
	{
		___m_codePage_9 = value;
	}

	inline static int32_t get_offset_of_dataItem_10() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___dataItem_10)); }
	inline CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB * get_dataItem_10() const { return ___dataItem_10; }
	inline CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB ** get_address_of_dataItem_10() { return &___dataItem_10; }
	inline void set_dataItem_10(CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB * value)
	{
		___dataItem_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___dataItem_10), (void*)value);
	}

	inline static int32_t get_offset_of_m_deserializedFromEverett_11() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___m_deserializedFromEverett_11)); }
	inline bool get_m_deserializedFromEverett_11() const { return ___m_deserializedFromEverett_11; }
	inline bool* get_address_of_m_deserializedFromEverett_11() { return &___m_deserializedFromEverett_11; }
	inline void set_m_deserializedFromEverett_11(bool value)
	{
		___m_deserializedFromEverett_11 = value;
	}

	inline static int32_t get_offset_of_m_isReadOnly_12() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___m_isReadOnly_12)); }
	inline bool get_m_isReadOnly_12() const { return ___m_isReadOnly_12; }
	inline bool* get_address_of_m_isReadOnly_12() { return &___m_isReadOnly_12; }
	inline void set_m_isReadOnly_12(bool value)
	{
		___m_isReadOnly_12 = value;
	}

	inline static int32_t get_offset_of_encoderFallback_13() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___encoderFallback_13)); }
	inline EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63 * get_encoderFallback_13() const { return ___encoderFallback_13; }
	inline EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63 ** get_address_of_encoderFallback_13() { return &___encoderFallback_13; }
	inline void set_encoderFallback_13(EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63 * value)
	{
		___encoderFallback_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encoderFallback_13), (void*)value);
	}

	inline static int32_t get_offset_of_decoderFallback_14() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___decoderFallback_14)); }
	inline DecoderFallback_t128445EB7676870485230893338EF044F6B72F60 * get_decoderFallback_14() const { return ___decoderFallback_14; }
	inline DecoderFallback_t128445EB7676870485230893338EF044F6B72F60 ** get_address_of_decoderFallback_14() { return &___decoderFallback_14; }
	inline void set_decoderFallback_14(DecoderFallback_t128445EB7676870485230893338EF044F6B72F60 * value)
	{
		___decoderFallback_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___decoderFallback_14), (void*)value);
	}
};

struct Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields
{
public:
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::defaultEncoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___defaultEncoding_0;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::unicodeEncoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___unicodeEncoding_1;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::bigEndianUnicode
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___bigEndianUnicode_2;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf7Encoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___utf7Encoding_3;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf8Encoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___utf8Encoding_4;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf32Encoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___utf32Encoding_5;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::asciiEncoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___asciiEncoding_6;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::latin1Encoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___latin1Encoding_7;
	// System.Collections.Hashtable modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::encodings
	Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 * ___encodings_8;
	// System.Object System.Text.Encoding::s_InternalSyncObject
	RuntimeObject * ___s_InternalSyncObject_15;

public:
	inline static int32_t get_offset_of_defaultEncoding_0() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___defaultEncoding_0)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_defaultEncoding_0() const { return ___defaultEncoding_0; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_defaultEncoding_0() { return &___defaultEncoding_0; }
	inline void set_defaultEncoding_0(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___defaultEncoding_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___defaultEncoding_0), (void*)value);
	}

	inline static int32_t get_offset_of_unicodeEncoding_1() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___unicodeEncoding_1)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_unicodeEncoding_1() const { return ___unicodeEncoding_1; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_unicodeEncoding_1() { return &___unicodeEncoding_1; }
	inline void set_unicodeEncoding_1(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___unicodeEncoding_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___unicodeEncoding_1), (void*)value);
	}

	inline static int32_t get_offset_of_bigEndianUnicode_2() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___bigEndianUnicode_2)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_bigEndianUnicode_2() const { return ___bigEndianUnicode_2; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_bigEndianUnicode_2() { return &___bigEndianUnicode_2; }
	inline void set_bigEndianUnicode_2(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___bigEndianUnicode_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bigEndianUnicode_2), (void*)value);
	}

	inline static int32_t get_offset_of_utf7Encoding_3() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___utf7Encoding_3)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_utf7Encoding_3() const { return ___utf7Encoding_3; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_utf7Encoding_3() { return &___utf7Encoding_3; }
	inline void set_utf7Encoding_3(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___utf7Encoding_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf7Encoding_3), (void*)value);
	}

	inline static int32_t get_offset_of_utf8Encoding_4() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___utf8Encoding_4)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_utf8Encoding_4() const { return ___utf8Encoding_4; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_utf8Encoding_4() { return &___utf8Encoding_4; }
	inline void set_utf8Encoding_4(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___utf8Encoding_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf8Encoding_4), (void*)value);
	}

	inline static int32_t get_offset_of_utf32Encoding_5() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___utf32Encoding_5)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_utf32Encoding_5() const { return ___utf32Encoding_5; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_utf32Encoding_5() { return &___utf32Encoding_5; }
	inline void set_utf32Encoding_5(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___utf32Encoding_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___utf32Encoding_5), (void*)value);
	}

	inline static int32_t get_offset_of_asciiEncoding_6() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___asciiEncoding_6)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_asciiEncoding_6() const { return ___asciiEncoding_6; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_asciiEncoding_6() { return &___asciiEncoding_6; }
	inline void set_asciiEncoding_6(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___asciiEncoding_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___asciiEncoding_6), (void*)value);
	}

	inline static int32_t get_offset_of_latin1Encoding_7() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___latin1Encoding_7)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_latin1Encoding_7() const { return ___latin1Encoding_7; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_latin1Encoding_7() { return &___latin1Encoding_7; }
	inline void set_latin1Encoding_7(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___latin1Encoding_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___latin1Encoding_7), (void*)value);
	}

	inline static int32_t get_offset_of_encodings_8() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___encodings_8)); }
	inline Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 * get_encodings_8() const { return ___encodings_8; }
	inline Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 ** get_address_of_encodings_8() { return &___encodings_8; }
	inline void set_encodings_8(Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 * value)
	{
		___encodings_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___encodings_8), (void*)value);
	}

	inline static int32_t get_offset_of_s_InternalSyncObject_15() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___s_InternalSyncObject_15)); }
	inline RuntimeObject * get_s_InternalSyncObject_15() const { return ___s_InternalSyncObject_15; }
	inline RuntimeObject ** get_address_of_s_InternalSyncObject_15() { return &___s_InternalSyncObject_15; }
	inline void set_s_InternalSyncObject_15(RuntimeObject * value)
	{
		___s_InternalSyncObject_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_InternalSyncObject_15), (void*)value);
	}
};


// System.Text.RegularExpressions.Capture
struct  Capture_tF4475248CCF3EFF914844BE2C993FC609D41DB73  : public RuntimeObject
{
public:
	// System.String System.Text.RegularExpressions.Capture::_text
	String_t* ____text_0;
	// System.Int32 System.Text.RegularExpressions.Capture::_index
	int32_t ____index_1;
	// System.Int32 System.Text.RegularExpressions.Capture::_length
	int32_t ____length_2;

public:
	inline static int32_t get_offset_of__text_0() { return static_cast<int32_t>(offsetof(Capture_tF4475248CCF3EFF914844BE2C993FC609D41DB73, ____text_0)); }
	inline String_t* get__text_0() const { return ____text_0; }
	inline String_t** get_address_of__text_0() { return &____text_0; }
	inline void set__text_0(String_t* value)
	{
		____text_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____text_0), (void*)value);
	}

	inline static int32_t get_offset_of__index_1() { return static_cast<int32_t>(offsetof(Capture_tF4475248CCF3EFF914844BE2C993FC609D41DB73, ____index_1)); }
	inline int32_t get__index_1() const { return ____index_1; }
	inline int32_t* get_address_of__index_1() { return &____index_1; }
	inline void set__index_1(int32_t value)
	{
		____index_1 = value;
	}

	inline static int32_t get_offset_of__length_2() { return static_cast<int32_t>(offsetof(Capture_tF4475248CCF3EFF914844BE2C993FC609D41DB73, ____length_2)); }
	inline int32_t get__length_2() const { return ____length_2; }
	inline int32_t* get_address_of__length_2() { return &____length_2; }
	inline void set__length_2(int32_t value)
	{
		____length_2 = value;
	}
};


// System.Text.RegularExpressions.GroupCollection
struct  GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F  : public RuntimeObject
{
public:
	// System.Text.RegularExpressions.Match System.Text.RegularExpressions.GroupCollection::_match
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * ____match_0;
	// System.Collections.Hashtable System.Text.RegularExpressions.GroupCollection::_captureMap
	Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 * ____captureMap_1;
	// System.Text.RegularExpressions.Group[] System.Text.RegularExpressions.GroupCollection::_groups
	GroupU5BU5D_t40CFA194F8EE1BF5E560B7C1E2C8F48220C93910* ____groups_2;

public:
	inline static int32_t get_offset_of__match_0() { return static_cast<int32_t>(offsetof(GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F, ____match_0)); }
	inline Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * get__match_0() const { return ____match_0; }
	inline Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 ** get_address_of__match_0() { return &____match_0; }
	inline void set__match_0(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * value)
	{
		____match_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____match_0), (void*)value);
	}

	inline static int32_t get_offset_of__captureMap_1() { return static_cast<int32_t>(offsetof(GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F, ____captureMap_1)); }
	inline Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 * get__captureMap_1() const { return ____captureMap_1; }
	inline Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 ** get_address_of__captureMap_1() { return &____captureMap_1; }
	inline void set__captureMap_1(Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 * value)
	{
		____captureMap_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____captureMap_1), (void*)value);
	}

	inline static int32_t get_offset_of__groups_2() { return static_cast<int32_t>(offsetof(GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F, ____groups_2)); }
	inline GroupU5BU5D_t40CFA194F8EE1BF5E560B7C1E2C8F48220C93910* get__groups_2() const { return ____groups_2; }
	inline GroupU5BU5D_t40CFA194F8EE1BF5E560B7C1E2C8F48220C93910** get_address_of__groups_2() { return &____groups_2; }
	inline void set__groups_2(GroupU5BU5D_t40CFA194F8EE1BF5E560B7C1E2C8F48220C93910* value)
	{
		____groups_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____groups_2), (void*)value);
	}
};


// System.Threading.Tasks.TaskCompletionSource`1<System.Object>
struct  TaskCompletionSource_1_t6C02642279BC7BF03091A8CB685FC6B4E68BED12  : public RuntimeObject
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Threading.Tasks.TaskCompletionSource`1::m_task
	Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * ___m_task_0;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(TaskCompletionSource_1_t6C02642279BC7BF03091A8CB685FC6B4E68BED12, ___m_task_0)); }
	inline Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}
};


// System.Threading.Tasks.TaskCompletionSource`1<Wamp_Response>
struct  TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0  : public RuntimeObject
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Threading.Tasks.TaskCompletionSource`1::m_task
	Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * ___m_task_0;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0, ___m_task_0)); }
	inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}
};


// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};

// WaapiHelper
struct  WaapiHelper_t6B6736609E504481D82FCA15F3313B4A92FB4635  : public RuntimeObject
{
public:

public:
};


// WaapiKeywords
struct  WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE  : public RuntimeObject
{
public:

public:
};

struct WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields
{
public:
	// System.Collections.ObjectModel.ReadOnlyDictionary`2<WwiseObjectType,System.String> WaapiKeywords::WwiseObjectTypeStrings
	ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D * ___WwiseObjectTypeStrings_82;
	// System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,System.String> WaapiKeywords::FolderDisplaynames
	ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE * ___FolderDisplaynames_83;
	// System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,WwiseObjectType> WaapiKeywords::typeStringDict
	ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * ___typeStringDict_84;

public:
	inline static int32_t get_offset_of_WwiseObjectTypeStrings_82() { return static_cast<int32_t>(offsetof(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields, ___WwiseObjectTypeStrings_82)); }
	inline ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D * get_WwiseObjectTypeStrings_82() const { return ___WwiseObjectTypeStrings_82; }
	inline ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D ** get_address_of_WwiseObjectTypeStrings_82() { return &___WwiseObjectTypeStrings_82; }
	inline void set_WwiseObjectTypeStrings_82(ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D * value)
	{
		___WwiseObjectTypeStrings_82 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectTypeStrings_82), (void*)value);
	}

	inline static int32_t get_offset_of_FolderDisplaynames_83() { return static_cast<int32_t>(offsetof(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields, ___FolderDisplaynames_83)); }
	inline ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE * get_FolderDisplaynames_83() const { return ___FolderDisplaynames_83; }
	inline ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE ** get_address_of_FolderDisplaynames_83() { return &___FolderDisplaynames_83; }
	inline void set_FolderDisplaynames_83(ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE * value)
	{
		___FolderDisplaynames_83 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FolderDisplaynames_83), (void*)value);
	}

	inline static int32_t get_offset_of_typeStringDict_84() { return static_cast<int32_t>(offsetof(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields, ___typeStringDict_84)); }
	inline ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * get_typeStringDict_84() const { return ___typeStringDict_84; }
	inline ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 ** get_address_of_typeStringDict_84() { return &___typeStringDict_84; }
	inline void set_typeStringDict_84(ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * value)
	{
		___typeStringDict_84 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___typeStringDict_84), (void*)value);
	}
};


// Wamp
struct  Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24  : public RuntimeObject
{
public:
	// Wamp_DisconnectedHandler Wamp::Disconnected
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * ___Disconnected_0;
	// System.Net.WebSockets.ClientWebSocket Wamp::ws
	ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * ___ws_1;
	// System.Int32 Wamp::sessionId
	int32_t ___sessionId_2;
	// System.Int32 Wamp::currentRequestId
	int32_t ___currentRequestId_3;
	// System.Threading.CancellationTokenSource Wamp::stopServerTokenSource
	CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * ___stopServerTokenSource_4;
	// System.Threading.Tasks.TaskCompletionSource`1<Wamp_Response> Wamp::taskCompletion
	TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * ___taskCompletion_5;
	// System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,Wamp_PublishHandler> Wamp::subscriptions
	ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * ___subscriptions_6;

public:
	inline static int32_t get_offset_of_Disconnected_0() { return static_cast<int32_t>(offsetof(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24, ___Disconnected_0)); }
	inline DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * get_Disconnected_0() const { return ___Disconnected_0; }
	inline DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 ** get_address_of_Disconnected_0() { return &___Disconnected_0; }
	inline void set_Disconnected_0(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * value)
	{
		___Disconnected_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Disconnected_0), (void*)value);
	}

	inline static int32_t get_offset_of_ws_1() { return static_cast<int32_t>(offsetof(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24, ___ws_1)); }
	inline ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * get_ws_1() const { return ___ws_1; }
	inline ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 ** get_address_of_ws_1() { return &___ws_1; }
	inline void set_ws_1(ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * value)
	{
		___ws_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ws_1), (void*)value);
	}

	inline static int32_t get_offset_of_sessionId_2() { return static_cast<int32_t>(offsetof(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24, ___sessionId_2)); }
	inline int32_t get_sessionId_2() const { return ___sessionId_2; }
	inline int32_t* get_address_of_sessionId_2() { return &___sessionId_2; }
	inline void set_sessionId_2(int32_t value)
	{
		___sessionId_2 = value;
	}

	inline static int32_t get_offset_of_currentRequestId_3() { return static_cast<int32_t>(offsetof(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24, ___currentRequestId_3)); }
	inline int32_t get_currentRequestId_3() const { return ___currentRequestId_3; }
	inline int32_t* get_address_of_currentRequestId_3() { return &___currentRequestId_3; }
	inline void set_currentRequestId_3(int32_t value)
	{
		___currentRequestId_3 = value;
	}

	inline static int32_t get_offset_of_stopServerTokenSource_4() { return static_cast<int32_t>(offsetof(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24, ___stopServerTokenSource_4)); }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * get_stopServerTokenSource_4() const { return ___stopServerTokenSource_4; }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE ** get_address_of_stopServerTokenSource_4() { return &___stopServerTokenSource_4; }
	inline void set_stopServerTokenSource_4(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * value)
	{
		___stopServerTokenSource_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___stopServerTokenSource_4), (void*)value);
	}

	inline static int32_t get_offset_of_taskCompletion_5() { return static_cast<int32_t>(offsetof(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24, ___taskCompletion_5)); }
	inline TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * get_taskCompletion_5() const { return ___taskCompletion_5; }
	inline TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 ** get_address_of_taskCompletion_5() { return &___taskCompletion_5; }
	inline void set_taskCompletion_5(TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * value)
	{
		___taskCompletion_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___taskCompletion_5), (void*)value);
	}

	inline static int32_t get_offset_of_subscriptions_6() { return static_cast<int32_t>(offsetof(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24, ___subscriptions_6)); }
	inline ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * get_subscriptions_6() const { return ___subscriptions_6; }
	inline ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 ** get_address_of_subscriptions_6() { return &___subscriptions_6; }
	inline void set_subscriptions_6(ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * value)
	{
		___subscriptions_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___subscriptions_6), (void*)value);
	}
};


// Wamp_<>c
struct  U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_StaticFields
{
public:
	// Wamp_<>c Wamp_<>c::<>9
	U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 * ___U3CU3E9_0;
	// System.Func`2<System.Collections.Generic.IEnumerable`1<System.Byte>,System.Collections.Generic.IEnumerable`1<System.Byte>> Wamp_<>c::<>9__24_0
	Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * ___U3CU3E9__24_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__24_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_StaticFields, ___U3CU3E9__24_0_1)); }
	inline Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * get_U3CU3E9__24_0_1() const { return ___U3CU3E9__24_0_1; }
	inline Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 ** get_address_of_U3CU3E9__24_0_1() { return &___U3CU3E9__24_0_1; }
	inline void set_U3CU3E9__24_0_1(Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * value)
	{
		___U3CU3E9__24_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__24_0_1), (void*)value);
	}
};


// WwiseObjectInfoJsonObject
struct  WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17  : public RuntimeObject
{
public:
	// System.String WwiseObjectInfoJsonObject::id
	String_t* ___id_0;
	// WwiseObjectInfoParent WwiseObjectInfoJsonObject::parent
	WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C * ___parent_1;
	// System.String WwiseObjectInfoJsonObject::name
	String_t* ___name_2;
	// System.String WwiseObjectInfoJsonObject::type
	String_t* ___type_3;
	// System.Int32 WwiseObjectInfoJsonObject::childrenCount
	int32_t ___childrenCount_4;
	// System.String WwiseObjectInfoJsonObject::path
	String_t* ___path_5;
	// System.String WwiseObjectInfoJsonObject::filePath
	String_t* ___filePath_6;
	// System.String WwiseObjectInfoJsonObject::workunitType
	String_t* ___workunitType_7;
	// System.String WwiseObjectInfoJsonObject::soundbankBnkFilePath
	String_t* ___soundbankBnkFilePath_8;

public:
	inline static int32_t get_offset_of_id_0() { return static_cast<int32_t>(offsetof(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17, ___id_0)); }
	inline String_t* get_id_0() const { return ___id_0; }
	inline String_t** get_address_of_id_0() { return &___id_0; }
	inline void set_id_0(String_t* value)
	{
		___id_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___id_0), (void*)value);
	}

	inline static int32_t get_offset_of_parent_1() { return static_cast<int32_t>(offsetof(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17, ___parent_1)); }
	inline WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C * get_parent_1() const { return ___parent_1; }
	inline WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C ** get_address_of_parent_1() { return &___parent_1; }
	inline void set_parent_1(WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C * value)
	{
		___parent_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___parent_1), (void*)value);
	}

	inline static int32_t get_offset_of_name_2() { return static_cast<int32_t>(offsetof(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17, ___name_2)); }
	inline String_t* get_name_2() const { return ___name_2; }
	inline String_t** get_address_of_name_2() { return &___name_2; }
	inline void set_name_2(String_t* value)
	{
		___name_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___name_2), (void*)value);
	}

	inline static int32_t get_offset_of_type_3() { return static_cast<int32_t>(offsetof(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17, ___type_3)); }
	inline String_t* get_type_3() const { return ___type_3; }
	inline String_t** get_address_of_type_3() { return &___type_3; }
	inline void set_type_3(String_t* value)
	{
		___type_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___type_3), (void*)value);
	}

	inline static int32_t get_offset_of_childrenCount_4() { return static_cast<int32_t>(offsetof(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17, ___childrenCount_4)); }
	inline int32_t get_childrenCount_4() const { return ___childrenCount_4; }
	inline int32_t* get_address_of_childrenCount_4() { return &___childrenCount_4; }
	inline void set_childrenCount_4(int32_t value)
	{
		___childrenCount_4 = value;
	}

	inline static int32_t get_offset_of_path_5() { return static_cast<int32_t>(offsetof(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17, ___path_5)); }
	inline String_t* get_path_5() const { return ___path_5; }
	inline String_t** get_address_of_path_5() { return &___path_5; }
	inline void set_path_5(String_t* value)
	{
		___path_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___path_5), (void*)value);
	}

	inline static int32_t get_offset_of_filePath_6() { return static_cast<int32_t>(offsetof(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17, ___filePath_6)); }
	inline String_t* get_filePath_6() const { return ___filePath_6; }
	inline String_t** get_address_of_filePath_6() { return &___filePath_6; }
	inline void set_filePath_6(String_t* value)
	{
		___filePath_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___filePath_6), (void*)value);
	}

	inline static int32_t get_offset_of_workunitType_7() { return static_cast<int32_t>(offsetof(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17, ___workunitType_7)); }
	inline String_t* get_workunitType_7() const { return ___workunitType_7; }
	inline String_t** get_address_of_workunitType_7() { return &___workunitType_7; }
	inline void set_workunitType_7(String_t* value)
	{
		___workunitType_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___workunitType_7), (void*)value);
	}

	inline static int32_t get_offset_of_soundbankBnkFilePath_8() { return static_cast<int32_t>(offsetof(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17, ___soundbankBnkFilePath_8)); }
	inline String_t* get_soundbankBnkFilePath_8() const { return ___soundbankBnkFilePath_8; }
	inline String_t** get_address_of_soundbankBnkFilePath_8() { return &___soundbankBnkFilePath_8; }
	inline void set_soundbankBnkFilePath_8(String_t* value)
	{
		___soundbankBnkFilePath_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___soundbankBnkFilePath_8), (void*)value);
	}
};


// WwiseObjectInfoParent
struct  WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C  : public RuntimeObject
{
public:
	// System.String WwiseObjectInfoParent::id
	String_t* ___id_0;

public:
	inline static int32_t get_offset_of_id_0() { return static_cast<int32_t>(offsetof(WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C, ___id_0)); }
	inline String_t* get_id_0() const { return ___id_0; }
	inline String_t** get_address_of_id_0() { return &___id_0; }
	inline void set_id_0(String_t* value)
	{
		___id_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___id_0), (void*)value);
	}
};


// ak
struct  ak_tF511177EEAEB475EB78D68D19AE992F862CBB2A6  : public RuntimeObject
{
public:

public:
};


// ak_soundengine
struct  soundengine_t694E3972DE713D444B64B412B97B7108DC843BA2  : public RuntimeObject
{
public:

public:
};


// ak_soundengine_error
struct  error_tCDE597E016300C016A3FEE568638DC713C2EDF61  : public RuntimeObject
{
public:

public:
};


// ak_wwise
struct  wwise_t7068E32CB53B72B95D1B19CE31764F556F895B73  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core
struct  core_t2A82E032B006312497032C96741453A5F70ECA74  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_audio
struct  audio_t47E4E106B54C9DF68C91887F06C3898310F2C0F3  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_audioSourcePeaks
struct  audioSourcePeaks_t503D3CB9E73B4338F31A0060F5008944D2B4E1D7  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_log
struct  log_tA74FD121C946B190C887AEDDF632EFE00D4F8C8C  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_object
struct  object_t0FDE90CA89444F5B6103DBBE4484C4C404CBEF13  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_plugin
struct  plugin_t6477174149106EA1CA08712CEDFAC6028FDC5DE4  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_profiler
struct  profiler_tB89DC98B050F1E087FB89C6DDB20BC381FB7CA65  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_project
struct  project_t245E31FDE836DE1D2F40961C29EE21036450FC8A  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_remote
struct  remote_t4C4F4EEBAC03CF408E3C74E936EC87563F2FEA09  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_soundbank
struct  soundbank_tCC9926C7815C27A6209BB97EA23E27B302300771  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_switchContainer
struct  switchContainer_tDDDB01C44DF50EFEF268CA874FCD80FE21B0E346  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_transport
struct  transport_tB8EF7287199C52452B7B8154131F2B26537C1905  : public RuntimeObject
{
public:

public:
};


// ak_wwise_core_undo
struct  undo_t5CF6EE76079FD0E24252206687B55766055EAB46  : public RuntimeObject
{
public:

public:
};


// ak_wwise_debug
struct  debug_t829D0F86B78CE3E43CF489CD32C09DAB255C271E  : public RuntimeObject
{
public:

public:
};


// ak_wwise_error
struct  error_tCD7560328D4A46FEB23E1B161450E7A6F8107172  : public RuntimeObject
{
public:

public:
};


// ak_wwise_ui
struct  ui_t294C9D5BA24A6473CA0945190027352134FD517A  : public RuntimeObject
{
public:

public:
};


// ak_wwise_ui_commands
struct  commands_tFC4F4BB98976F182CFEA291E7E8962B7AB92B0E7  : public RuntimeObject
{
public:

public:
};


// ak_wwise_ui_project
struct  project_tC709A78C52B6A1C3E7E4A3F46A84163E22F00868  : public RuntimeObject
{
public:

public:
};


// ak_wwise_waapi
struct  waapi_tB7251965C2BF8D27DD071A5757C5A547D41EED68  : public RuntimeObject
{
public:

public:
};


// Args
struct  Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:

public:
};


// ErrorDetails
struct  ErrorDetails_t21A26837A9AD74120E02D79946F6D3B03EC5AAA2  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:
	// System.String[] ErrorDetails::reasons
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___reasons_0;
	// System.String ErrorDetails::procedureUri
	String_t* ___procedureUri_1;

public:
	inline static int32_t get_offset_of_reasons_0() { return static_cast<int32_t>(offsetof(ErrorDetails_t21A26837A9AD74120E02D79946F6D3B03EC5AAA2, ___reasons_0)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get_reasons_0() const { return ___reasons_0; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of_reasons_0() { return &___reasons_0; }
	inline void set_reasons_0(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		___reasons_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___reasons_0), (void*)value);
	}

	inline static int32_t get_offset_of_procedureUri_1() { return static_cast<int32_t>(offsetof(ErrorDetails_t21A26837A9AD74120E02D79946F6D3B03EC5AAA2, ___procedureUri_1)); }
	inline String_t* get_procedureUri_1() const { return ___procedureUri_1; }
	inline String_t** get_address_of_procedureUri_1() { return &___procedureUri_1; }
	inline void set_procedureUri_1(String_t* value)
	{
		___procedureUri_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___procedureUri_1), (void*)value);
	}
};


// ErrorMessage
struct  ErrorMessage_tED7633C6802CF0672E6C52EB479D17926BDCCEBC  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:
	// System.String ErrorMessage::message
	String_t* ___message_0;
	// ErrorDetails ErrorMessage::details
	ErrorDetails_t21A26837A9AD74120E02D79946F6D3B03EC5AAA2 * ___details_1;

public:
	inline static int32_t get_offset_of_message_0() { return static_cast<int32_t>(offsetof(ErrorMessage_tED7633C6802CF0672E6C52EB479D17926BDCCEBC, ___message_0)); }
	inline String_t* get_message_0() const { return ___message_0; }
	inline String_t** get_address_of_message_0() { return &___message_0; }
	inline void set_message_0(String_t* value)
	{
		___message_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___message_0), (void*)value);
	}

	inline static int32_t get_offset_of_details_1() { return static_cast<int32_t>(offsetof(ErrorMessage_tED7633C6802CF0672E6C52EB479D17926BDCCEBC, ___details_1)); }
	inline ErrorDetails_t21A26837A9AD74120E02D79946F6D3B03EC5AAA2 * get_details_1() const { return ___details_1; }
	inline ErrorDetails_t21A26837A9AD74120E02D79946F6D3B03EC5AAA2 ** get_address_of_details_1() { return &___details_1; }
	inline void set_details_1(ErrorDetails_t21A26837A9AD74120E02D79946F6D3B03EC5AAA2 * value)
	{
		___details_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___details_1), (void*)value);
	}
};


// Options
struct  Options_t36565DDE7EEC80CC7827D71EEC8E99E37411D050  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:

public:
};


// ReturnTransport
struct  ReturnTransport_tB91DDDE10CD868C4AA03BEF7F4AA95E78E54F2DD  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:
	// System.Int32 ReturnTransport::transport
	int32_t ___transport_0;

public:
	inline static int32_t get_offset_of_transport_0() { return static_cast<int32_t>(offsetof(ReturnTransport_tB91DDDE10CD868C4AA03BEF7F4AA95E78E54F2DD, ___transport_0)); }
	inline int32_t get_transport_0() const { return ___transport_0; }
	inline int32_t* get_address_of_transport_0() { return &___transport_0; }
	inline void set_transport_0(int32_t value)
	{
		___transport_0 = value;
	}
};


// ReturnWwiseObjects
struct  ReturnWwiseObjects_t4AC346E1F2794A85FF82A3E8463A838E2D90B4B8  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:
	// System.Collections.Generic.List`1<WwiseObjectInfoJsonObject> ReturnWwiseObjects::return
	List_1_t25289DD7DBC4B7586876E46CE6DD88E181CE2D31 * ___return_0;

public:
	inline static int32_t get_offset_of_return_0() { return static_cast<int32_t>(offsetof(ReturnWwiseObjects_t4AC346E1F2794A85FF82A3E8463A838E2D90B4B8, ___return_0)); }
	inline List_1_t25289DD7DBC4B7586876E46CE6DD88E181CE2D31 * get_return_0() const { return ___return_0; }
	inline List_1_t25289DD7DBC4B7586876E46CE6DD88E181CE2D31 ** get_address_of_return_0() { return &___return_0; }
	inline void set_return_0(List_1_t25289DD7DBC4B7586876E46CE6DD88E181CE2D31 * value)
	{
		___return_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___return_0), (void*)value);
	}
};


// SelectedWwiseObjects
struct  SelectedWwiseObjects_t4B9895C68B1B11B76DC69F9C6DB2E69BB714E7A0  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:
	// System.Collections.Generic.List`1<WwiseObjectInfoJsonObject> SelectedWwiseObjects::objects
	List_1_t25289DD7DBC4B7586876E46CE6DD88E181CE2D31 * ___objects_0;

public:
	inline static int32_t get_offset_of_objects_0() { return static_cast<int32_t>(offsetof(SelectedWwiseObjects_t4B9895C68B1B11B76DC69F9C6DB2E69BB714E7A0, ___objects_0)); }
	inline List_1_t25289DD7DBC4B7586876E46CE6DD88E181CE2D31 * get_objects_0() const { return ___objects_0; }
	inline List_1_t25289DD7DBC4B7586876E46CE6DD88E181CE2D31 ** get_address_of_objects_0() { return &___objects_0; }
	inline void set_objects_0(List_1_t25289DD7DBC4B7586876E46CE6DD88E181CE2D31 * value)
	{
		___objects_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___objects_0), (void*)value);
	}
};


// System.ArraySegment`1<System.Byte>
struct  ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA 
{
public:
	// T[] System.ArraySegment`1::_array
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ____array_0;
	// System.Int32 System.ArraySegment`1::_offset
	int32_t ____offset_1;
	// System.Int32 System.ArraySegment`1::_count
	int32_t ____count_2;

public:
	inline static int32_t get_offset_of__array_0() { return static_cast<int32_t>(offsetof(ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA, ____array_0)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get__array_0() const { return ____array_0; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of__array_0() { return &____array_0; }
	inline void set__array_0(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		____array_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____array_0), (void*)value);
	}

	inline static int32_t get_offset_of__offset_1() { return static_cast<int32_t>(offsetof(ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA, ____offset_1)); }
	inline int32_t get__offset_1() const { return ____offset_1; }
	inline int32_t* get_address_of__offset_1() { return &____offset_1; }
	inline void set__offset_1(int32_t value)
	{
		____offset_1 = value;
	}

	inline static int32_t get_offset_of__count_2() { return static_cast<int32_t>(offsetof(ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA, ____count_2)); }
	inline int32_t get__count_2() const { return ____count_2; }
	inline int32_t* get_address_of__count_2() { return &____count_2; }
	inline void set__count_2(int32_t value)
	{
		____count_2 = value;
	}
};


// System.Boolean
struct  Boolean_tB53F6830F670160873277339AA58F15CAED4399C 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Byte
struct  Byte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07 
{
public:
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Byte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07, ___m_value_0)); }
	inline uint8_t get_m_value_0() const { return ___m_value_0; }
	inline uint8_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint8_t value)
	{
		___m_value_0 = value;
	}
};


// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};

// System.Guid
struct  Guid_t 
{
public:
	// System.Int32 System.Guid::_a
	int32_t ____a_1;
	// System.Int16 System.Guid::_b
	int16_t ____b_2;
	// System.Int16 System.Guid::_c
	int16_t ____c_3;
	// System.Byte System.Guid::_d
	uint8_t ____d_4;
	// System.Byte System.Guid::_e
	uint8_t ____e_5;
	// System.Byte System.Guid::_f
	uint8_t ____f_6;
	// System.Byte System.Guid::_g
	uint8_t ____g_7;
	// System.Byte System.Guid::_h
	uint8_t ____h_8;
	// System.Byte System.Guid::_i
	uint8_t ____i_9;
	// System.Byte System.Guid::_j
	uint8_t ____j_10;
	// System.Byte System.Guid::_k
	uint8_t ____k_11;

public:
	inline static int32_t get_offset_of__a_1() { return static_cast<int32_t>(offsetof(Guid_t, ____a_1)); }
	inline int32_t get__a_1() const { return ____a_1; }
	inline int32_t* get_address_of__a_1() { return &____a_1; }
	inline void set__a_1(int32_t value)
	{
		____a_1 = value;
	}

	inline static int32_t get_offset_of__b_2() { return static_cast<int32_t>(offsetof(Guid_t, ____b_2)); }
	inline int16_t get__b_2() const { return ____b_2; }
	inline int16_t* get_address_of__b_2() { return &____b_2; }
	inline void set__b_2(int16_t value)
	{
		____b_2 = value;
	}

	inline static int32_t get_offset_of__c_3() { return static_cast<int32_t>(offsetof(Guid_t, ____c_3)); }
	inline int16_t get__c_3() const { return ____c_3; }
	inline int16_t* get_address_of__c_3() { return &____c_3; }
	inline void set__c_3(int16_t value)
	{
		____c_3 = value;
	}

	inline static int32_t get_offset_of__d_4() { return static_cast<int32_t>(offsetof(Guid_t, ____d_4)); }
	inline uint8_t get__d_4() const { return ____d_4; }
	inline uint8_t* get_address_of__d_4() { return &____d_4; }
	inline void set__d_4(uint8_t value)
	{
		____d_4 = value;
	}

	inline static int32_t get_offset_of__e_5() { return static_cast<int32_t>(offsetof(Guid_t, ____e_5)); }
	inline uint8_t get__e_5() const { return ____e_5; }
	inline uint8_t* get_address_of__e_5() { return &____e_5; }
	inline void set__e_5(uint8_t value)
	{
		____e_5 = value;
	}

	inline static int32_t get_offset_of__f_6() { return static_cast<int32_t>(offsetof(Guid_t, ____f_6)); }
	inline uint8_t get__f_6() const { return ____f_6; }
	inline uint8_t* get_address_of__f_6() { return &____f_6; }
	inline void set__f_6(uint8_t value)
	{
		____f_6 = value;
	}

	inline static int32_t get_offset_of__g_7() { return static_cast<int32_t>(offsetof(Guid_t, ____g_7)); }
	inline uint8_t get__g_7() const { return ____g_7; }
	inline uint8_t* get_address_of__g_7() { return &____g_7; }
	inline void set__g_7(uint8_t value)
	{
		____g_7 = value;
	}

	inline static int32_t get_offset_of__h_8() { return static_cast<int32_t>(offsetof(Guid_t, ____h_8)); }
	inline uint8_t get__h_8() const { return ____h_8; }
	inline uint8_t* get_address_of__h_8() { return &____h_8; }
	inline void set__h_8(uint8_t value)
	{
		____h_8 = value;
	}

	inline static int32_t get_offset_of__i_9() { return static_cast<int32_t>(offsetof(Guid_t, ____i_9)); }
	inline uint8_t get__i_9() const { return ____i_9; }
	inline uint8_t* get_address_of__i_9() { return &____i_9; }
	inline void set__i_9(uint8_t value)
	{
		____i_9 = value;
	}

	inline static int32_t get_offset_of__j_10() { return static_cast<int32_t>(offsetof(Guid_t, ____j_10)); }
	inline uint8_t get__j_10() const { return ____j_10; }
	inline uint8_t* get_address_of__j_10() { return &____j_10; }
	inline void set__j_10(uint8_t value)
	{
		____j_10 = value;
	}

	inline static int32_t get_offset_of__k_11() { return static_cast<int32_t>(offsetof(Guid_t, ____k_11)); }
	inline uint8_t get__k_11() const { return ____k_11; }
	inline uint8_t* get_address_of__k_11() { return &____k_11; }
	inline void set__k_11(uint8_t value)
	{
		____k_11 = value;
	}
};

struct Guid_t_StaticFields
{
public:
	// System.Guid System.Guid::Empty
	Guid_t  ___Empty_0;
	// System.Object System.Guid::_rngAccess
	RuntimeObject * ____rngAccess_12;
	// System.Security.Cryptography.RandomNumberGenerator System.Guid::_rng
	RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2 * ____rng_13;

public:
	inline static int32_t get_offset_of_Empty_0() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ___Empty_0)); }
	inline Guid_t  get_Empty_0() const { return ___Empty_0; }
	inline Guid_t * get_address_of_Empty_0() { return &___Empty_0; }
	inline void set_Empty_0(Guid_t  value)
	{
		___Empty_0 = value;
	}

	inline static int32_t get_offset_of__rngAccess_12() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rngAccess_12)); }
	inline RuntimeObject * get__rngAccess_12() const { return ____rngAccess_12; }
	inline RuntimeObject ** get_address_of__rngAccess_12() { return &____rngAccess_12; }
	inline void set__rngAccess_12(RuntimeObject * value)
	{
		____rngAccess_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____rngAccess_12), (void*)value);
	}

	inline static int32_t get_offset_of__rng_13() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rng_13)); }
	inline RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2 * get__rng_13() const { return ____rng_13; }
	inline RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2 ** get_address_of__rng_13() { return &____rng_13; }
	inline void set__rng_13(RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2 * value)
	{
		____rng_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____rng_13), (void*)value);
	}
};


// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// System.Net.WebSockets.ClientWebSocket
struct  ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90  : public WebSocket_tED193A2E3239A732E23EF89376A08B1428EF0B39
{
public:
	// System.Net.WebSockets.ClientWebSocketOptions System.Net.WebSockets.ClientWebSocket::_options
	ClientWebSocketOptions_tF11DCFB8EAF9AE630CC5D0BF1EAA701EEE769166 * ____options_0;
	// System.Net.WebSockets.WebSocketHandle System.Net.WebSockets.ClientWebSocket::_innerWebSocket
	WebSocketHandle_tCE1E5F6E1A2965D082A46F2BB340F76F09AD78FF * ____innerWebSocket_1;
	// System.Int32 System.Net.WebSockets.ClientWebSocket::_state
	int32_t ____state_2;

public:
	inline static int32_t get_offset_of__options_0() { return static_cast<int32_t>(offsetof(ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90, ____options_0)); }
	inline ClientWebSocketOptions_tF11DCFB8EAF9AE630CC5D0BF1EAA701EEE769166 * get__options_0() const { return ____options_0; }
	inline ClientWebSocketOptions_tF11DCFB8EAF9AE630CC5D0BF1EAA701EEE769166 ** get_address_of__options_0() { return &____options_0; }
	inline void set__options_0(ClientWebSocketOptions_tF11DCFB8EAF9AE630CC5D0BF1EAA701EEE769166 * value)
	{
		____options_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____options_0), (void*)value);
	}

	inline static int32_t get_offset_of__innerWebSocket_1() { return static_cast<int32_t>(offsetof(ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90, ____innerWebSocket_1)); }
	inline WebSocketHandle_tCE1E5F6E1A2965D082A46F2BB340F76F09AD78FF * get__innerWebSocket_1() const { return ____innerWebSocket_1; }
	inline WebSocketHandle_tCE1E5F6E1A2965D082A46F2BB340F76F09AD78FF ** get_address_of__innerWebSocket_1() { return &____innerWebSocket_1; }
	inline void set__innerWebSocket_1(WebSocketHandle_tCE1E5F6E1A2965D082A46F2BB340F76F09AD78FF * value)
	{
		____innerWebSocket_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____innerWebSocket_1), (void*)value);
	}

	inline static int32_t get_offset_of__state_2() { return static_cast<int32_t>(offsetof(ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90, ____state_2)); }
	inline int32_t get__state_2() const { return ____state_2; }
	inline int32_t* get_address_of__state_2() { return &____state_2; }
	inline void set__state_2(int32_t value)
	{
		____state_2 = value;
	}
};


// System.Runtime.CompilerServices.AsyncMethodBuilderCore
struct  AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01 
{
public:
	// System.Runtime.CompilerServices.IAsyncStateMachine System.Runtime.CompilerServices.AsyncMethodBuilderCore::m_stateMachine
	RuntimeObject* ___m_stateMachine_0;
	// System.Action System.Runtime.CompilerServices.AsyncMethodBuilderCore::m_defaultContextAction
	Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * ___m_defaultContextAction_1;

public:
	inline static int32_t get_offset_of_m_stateMachine_0() { return static_cast<int32_t>(offsetof(AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01, ___m_stateMachine_0)); }
	inline RuntimeObject* get_m_stateMachine_0() const { return ___m_stateMachine_0; }
	inline RuntimeObject** get_address_of_m_stateMachine_0() { return &___m_stateMachine_0; }
	inline void set_m_stateMachine_0(RuntimeObject* value)
	{
		___m_stateMachine_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_stateMachine_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_defaultContextAction_1() { return static_cast<int32_t>(offsetof(AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01, ___m_defaultContextAction_1)); }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * get_m_defaultContextAction_1() const { return ___m_defaultContextAction_1; }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 ** get_address_of_m_defaultContextAction_1() { return &___m_defaultContextAction_1; }
	inline void set_m_defaultContextAction_1(Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * value)
	{
		___m_defaultContextAction_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_defaultContextAction_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Runtime.CompilerServices.AsyncMethodBuilderCore
struct AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01_marshaled_pinvoke
{
	RuntimeObject* ___m_stateMachine_0;
	Il2CppMethodPointer ___m_defaultContextAction_1;
};
// Native definition for COM marshalling of System.Runtime.CompilerServices.AsyncMethodBuilderCore
struct AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01_marshaled_com
{
	RuntimeObject* ___m_stateMachine_0;
	Il2CppMethodPointer ___m_defaultContextAction_1;
};

// System.Runtime.CompilerServices.TaskAwaiter
struct  TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F 
{
public:
	// System.Threading.Tasks.Task System.Runtime.CompilerServices.TaskAwaiter::m_task
	Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * ___m_task_0;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F, ___m_task_0)); }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * get_m_task_0() const { return ___m_task_0; }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Runtime.CompilerServices.TaskAwaiter
struct TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_marshaled_pinvoke
{
	Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * ___m_task_0;
};
// Native definition for COM marshalling of System.Runtime.CompilerServices.TaskAwaiter
struct TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_marshaled_com
{
	Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * ___m_task_0;
};

// System.Runtime.CompilerServices.TaskAwaiter`1<System.Net.WebSockets.WebSocketReceiveResult>
struct  TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD 
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.TaskAwaiter`1::m_task
	Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F * ___m_task_0;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD, ___m_task_0)); }
	inline Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>
struct  TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.TaskAwaiter`1::m_task
	Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * ___m_task_0;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977, ___m_task_0)); }
	inline Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.TaskAwaiter`1<System.String>
struct  TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.TaskAwaiter`1::m_task
	Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * ___m_task_0;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214, ___m_task_0)); }
	inline Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.TaskAwaiter`1<System.Threading.Tasks.Task>
struct  TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A 
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.TaskAwaiter`1::m_task
	Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138 * ___m_task_0;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A, ___m_task_0)); }
	inline Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138 * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138 ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138 * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.TaskAwaiter`1<System.UInt32>
struct  TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.TaskAwaiter`1::m_task
	Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * ___m_task_0;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830, ___m_task_0)); }
	inline Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.TaskAwaiter`1<Wamp_Response>
struct  TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.TaskAwaiter`1::m_task
	Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * ___m_task_0;

public:
	inline static int32_t get_offset_of_m_task_0() { return static_cast<int32_t>(offsetof(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9, ___m_task_0)); }
	inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * get_m_task_0() const { return ___m_task_0; }
	inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA ** get_address_of_m_task_0() { return &___m_task_0; }
	inline void set_m_task_0(Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * value)
	{
		___m_task_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_0), (void*)value);
	}
};


// System.Text.RegularExpressions.Group
struct  Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443  : public Capture_tF4475248CCF3EFF914844BE2C993FC609D41DB73
{
public:
	// System.Int32[] System.Text.RegularExpressions.Group::_caps
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ____caps_4;
	// System.Int32 System.Text.RegularExpressions.Group::_capcount
	int32_t ____capcount_5;
	// System.String System.Text.RegularExpressions.Group::_name
	String_t* ____name_6;

public:
	inline static int32_t get_offset_of__caps_4() { return static_cast<int32_t>(offsetof(Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443, ____caps_4)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get__caps_4() const { return ____caps_4; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of__caps_4() { return &____caps_4; }
	inline void set__caps_4(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		____caps_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____caps_4), (void*)value);
	}

	inline static int32_t get_offset_of__capcount_5() { return static_cast<int32_t>(offsetof(Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443, ____capcount_5)); }
	inline int32_t get__capcount_5() const { return ____capcount_5; }
	inline int32_t* get_address_of__capcount_5() { return &____capcount_5; }
	inline void set__capcount_5(int32_t value)
	{
		____capcount_5 = value;
	}

	inline static int32_t get_offset_of__name_6() { return static_cast<int32_t>(offsetof(Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443, ____name_6)); }
	inline String_t* get__name_6() const { return ____name_6; }
	inline String_t** get_address_of__name_6() { return &____name_6; }
	inline void set__name_6(String_t* value)
	{
		____name_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____name_6), (void*)value);
	}
};

struct Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443_StaticFields
{
public:
	// System.Text.RegularExpressions.Group System.Text.RegularExpressions.Group::_emptygroup
	Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * ____emptygroup_3;

public:
	inline static int32_t get_offset_of__emptygroup_3() { return static_cast<int32_t>(offsetof(Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443_StaticFields, ____emptygroup_3)); }
	inline Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * get__emptygroup_3() const { return ____emptygroup_3; }
	inline Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 ** get_address_of__emptygroup_3() { return &____emptygroup_3; }
	inline void set__emptygroup_3(Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * value)
	{
		____emptygroup_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____emptygroup_3), (void*)value);
	}
};


// System.Threading.CancellationToken
struct  CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB 
{
public:
	// System.Threading.CancellationTokenSource System.Threading.CancellationToken::m_source
	CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * ___m_source_0;

public:
	inline static int32_t get_offset_of_m_source_0() { return static_cast<int32_t>(offsetof(CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB, ___m_source_0)); }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * get_m_source_0() const { return ___m_source_0; }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE ** get_address_of_m_source_0() { return &___m_source_0; }
	inline void set_m_source_0(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * value)
	{
		___m_source_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_source_0), (void*)value);
	}
};

struct CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB_StaticFields
{
public:
	// System.Action`1<System.Object> System.Threading.CancellationToken::s_ActionToActionObjShunt
	Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 * ___s_ActionToActionObjShunt_1;

public:
	inline static int32_t get_offset_of_s_ActionToActionObjShunt_1() { return static_cast<int32_t>(offsetof(CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB_StaticFields, ___s_ActionToActionObjShunt_1)); }
	inline Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 * get_s_ActionToActionObjShunt_1() const { return ___s_ActionToActionObjShunt_1; }
	inline Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 ** get_address_of_s_ActionToActionObjShunt_1() { return &___s_ActionToActionObjShunt_1; }
	inline void set_s_ActionToActionObjShunt_1(Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 * value)
	{
		___s_ActionToActionObjShunt_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_ActionToActionObjShunt_1), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Threading.CancellationToken
struct CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB_marshaled_pinvoke
{
	CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * ___m_source_0;
};
// Native definition for COM marshalling of System.Threading.CancellationToken
struct CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB_marshaled_com
{
	CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * ___m_source_0;
};

// System.UInt32
struct  UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};


// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};


// TransportState
struct  TransportState_t1F81EF9D2597F1351B60E6530C77973DA92DC7AD  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:
	// System.String TransportState::gameObject
	String_t* ___gameObject_0;
	// System.String TransportState::state
	String_t* ___state_1;
	// System.String TransportState::object
	String_t* ___object_2;
	// System.Int32 TransportState::transport
	int32_t ___transport_3;

public:
	inline static int32_t get_offset_of_gameObject_0() { return static_cast<int32_t>(offsetof(TransportState_t1F81EF9D2597F1351B60E6530C77973DA92DC7AD, ___gameObject_0)); }
	inline String_t* get_gameObject_0() const { return ___gameObject_0; }
	inline String_t** get_address_of_gameObject_0() { return &___gameObject_0; }
	inline void set_gameObject_0(String_t* value)
	{
		___gameObject_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___gameObject_0), (void*)value);
	}

	inline static int32_t get_offset_of_state_1() { return static_cast<int32_t>(offsetof(TransportState_t1F81EF9D2597F1351B60E6530C77973DA92DC7AD, ___state_1)); }
	inline String_t* get_state_1() const { return ___state_1; }
	inline String_t** get_address_of_state_1() { return &___state_1; }
	inline void set_state_1(String_t* value)
	{
		___state_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___state_1), (void*)value);
	}

	inline static int32_t get_offset_of_object_2() { return static_cast<int32_t>(offsetof(TransportState_t1F81EF9D2597F1351B60E6530C77973DA92DC7AD, ___object_2)); }
	inline String_t* get_object_2() const { return ___object_2; }
	inline String_t** get_address_of_object_2() { return &___object_2; }
	inline void set_object_2(String_t* value)
	{
		___object_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___object_2), (void*)value);
	}

	inline static int32_t get_offset_of_transport_3() { return static_cast<int32_t>(offsetof(TransportState_t1F81EF9D2597F1351B60E6530C77973DA92DC7AD, ___transport_3)); }
	inline int32_t get_transport_3() const { return ___transport_3; }
	inline int32_t* get_address_of_transport_3() { return &___transport_3; }
	inline void set_transport_3(int32_t value)
	{
		___transport_3 = value;
	}
};


// ArgsCommand
struct  ArgsCommand_t675212B8DFD4A88AFF6A0484842254A82CBCAFD2  : public Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D
{
public:
	// System.String[] ArgsCommand::objects
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___objects_0;
	// System.String ArgsCommand::command
	String_t* ___command_1;

public:
	inline static int32_t get_offset_of_objects_0() { return static_cast<int32_t>(offsetof(ArgsCommand_t675212B8DFD4A88AFF6A0484842254A82CBCAFD2, ___objects_0)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get_objects_0() const { return ___objects_0; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of_objects_0() { return &___objects_0; }
	inline void set_objects_0(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		___objects_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___objects_0), (void*)value);
	}

	inline static int32_t get_offset_of_command_1() { return static_cast<int32_t>(offsetof(ArgsCommand_t675212B8DFD4A88AFF6A0484842254A82CBCAFD2, ___command_1)); }
	inline String_t* get_command_1() const { return ___command_1; }
	inline String_t** get_address_of_command_1() { return &___command_1; }
	inline void set_command_1(String_t* value)
	{
		___command_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___command_1), (void*)value);
	}
};


// ArgsDisplayName
struct  ArgsDisplayName_tB0504FC27F9B3A43933A54C7CE48C2480CD36DCD  : public Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D
{
public:
	// System.String ArgsDisplayName::displayName
	String_t* ___displayName_0;

public:
	inline static int32_t get_offset_of_displayName_0() { return static_cast<int32_t>(offsetof(ArgsDisplayName_tB0504FC27F9B3A43933A54C7CE48C2480CD36DCD, ___displayName_0)); }
	inline String_t* get_displayName_0() const { return ___displayName_0; }
	inline String_t** get_address_of_displayName_0() { return &___displayName_0; }
	inline void set_displayName_0(String_t* value)
	{
		___displayName_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___displayName_0), (void*)value);
	}
};


// ArgsObject
struct  ArgsObject_t58DE1003F3AF0D598690ED9208AC6BF67819D832  : public Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D
{
public:
	// System.String ArgsObject::object
	String_t* ___object_0;

public:
	inline static int32_t get_offset_of_object_0() { return static_cast<int32_t>(offsetof(ArgsObject_t58DE1003F3AF0D598690ED9208AC6BF67819D832, ___object_0)); }
	inline String_t* get_object_0() const { return ___object_0; }
	inline String_t** get_address_of_object_0() { return &___object_0; }
	inline void set_object_0(String_t* value)
	{
		___object_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___object_0), (void*)value);
	}
};


// ArgsPlay
struct  ArgsPlay_t5EA1BD810BBA204223D66BA4E6650B78FB2BDDDB  : public Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D
{
public:
	// System.String ArgsPlay::action
	String_t* ___action_0;
	// System.Int32 ArgsPlay::transport
	int32_t ___transport_1;

public:
	inline static int32_t get_offset_of_action_0() { return static_cast<int32_t>(offsetof(ArgsPlay_t5EA1BD810BBA204223D66BA4E6650B78FB2BDDDB, ___action_0)); }
	inline String_t* get_action_0() const { return ___action_0; }
	inline String_t** get_address_of_action_0() { return &___action_0; }
	inline void set_action_0(String_t* value)
	{
		___action_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___action_0), (void*)value);
	}

	inline static int32_t get_offset_of_transport_1() { return static_cast<int32_t>(offsetof(ArgsPlay_t5EA1BD810BBA204223D66BA4E6650B78FB2BDDDB, ___transport_1)); }
	inline int32_t get_transport_1() const { return ___transport_1; }
	inline int32_t* get_address_of_transport_1() { return &___transport_1; }
	inline void set_transport_1(int32_t value)
	{
		___transport_1 = value;
	}
};


// ArgsRename
struct  ArgsRename_tDD8FBA42725ABDCAEA48D8EFEDEAC1E343BFA414  : public Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D
{
public:
	// System.String ArgsRename::object
	String_t* ___object_0;
	// System.String ArgsRename::value
	String_t* ___value_1;

public:
	inline static int32_t get_offset_of_object_0() { return static_cast<int32_t>(offsetof(ArgsRename_tDD8FBA42725ABDCAEA48D8EFEDEAC1E343BFA414, ___object_0)); }
	inline String_t* get_object_0() const { return ___object_0; }
	inline String_t** get_address_of_object_0() { return &___object_0; }
	inline void set_object_0(String_t* value)
	{
		___object_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___object_0), (void*)value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ArgsRename_tDD8FBA42725ABDCAEA48D8EFEDEAC1E343BFA414, ___value_1)); }
	inline String_t* get_value_1() const { return ___value_1; }
	inline String_t** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(String_t* value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___value_1), (void*)value);
	}
};


// ArgsTransport
struct  ArgsTransport_t924F2C28D1C132CA258F1C6F1E7236DC0DF76CD2  : public Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D
{
public:
	// System.Int32 ArgsTransport::transport
	int32_t ___transport_0;

public:
	inline static int32_t get_offset_of_transport_0() { return static_cast<int32_t>(offsetof(ArgsTransport_t924F2C28D1C132CA258F1C6F1E7236DC0DF76CD2, ___transport_0)); }
	inline int32_t get_transport_0() const { return ___transport_0; }
	inline int32_t* get_address_of_transport_0() { return &___transport_0; }
	inline void set_transport_0(int32_t value)
	{
		___transport_0 = value;
	}
};


// ReturnOptions
struct  ReturnOptions_tBED022AD296CD58A16E37C3DBC9D07089EA289FD  : public Options_t36565DDE7EEC80CC7827D71EEC8E99E37411D050
{
public:
	// System.String[] ReturnOptions::return
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___return_0;

public:
	inline static int32_t get_offset_of_return_0() { return static_cast<int32_t>(offsetof(ReturnOptions_tBED022AD296CD58A16E37C3DBC9D07089EA289FD, ___return_0)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get_return_0() const { return ___return_0; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of_return_0() { return &___return_0; }
	inline void set_return_0(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		___return_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___return_0), (void*)value);
	}
};


// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_target_2), (void*)value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___method_info_7), (void*)value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___original_method_info_8), (void*)value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * get_data_9() const { return ___data_9; }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___data_9), (void*)value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};

// System.Exception
struct  Exception_t  : public RuntimeObject
{
public:
	// System.String System.Exception::_className
	String_t* ____className_1;
	// System.String System.Exception::_message
	String_t* ____message_2;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_3;
	// System.Exception System.Exception::_innerException
	Exception_t * ____innerException_4;
	// System.String System.Exception::_helpURL
	String_t* ____helpURL_5;
	// System.Object System.Exception::_stackTrace
	RuntimeObject * ____stackTrace_6;
	// System.String System.Exception::_stackTraceString
	String_t* ____stackTraceString_7;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_8;
	// System.Int32 System.Exception::_remoteStackIndex
	int32_t ____remoteStackIndex_9;
	// System.Object System.Exception::_dynamicMethods
	RuntimeObject * ____dynamicMethods_10;
	// System.Int32 System.Exception::_HResult
	int32_t ____HResult_11;
	// System.String System.Exception::_source
	String_t* ____source_12;
	// System.Runtime.Serialization.SafeSerializationManager System.Exception::_safeSerializationManager
	SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * ____safeSerializationManager_13;
	// System.Diagnostics.StackTrace[] System.Exception::captured_traces
	StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* ___captured_traces_14;
	// System.IntPtr[] System.Exception::native_trace_ips
	IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD* ___native_trace_ips_15;

public:
	inline static int32_t get_offset_of__className_1() { return static_cast<int32_t>(offsetof(Exception_t, ____className_1)); }
	inline String_t* get__className_1() const { return ____className_1; }
	inline String_t** get_address_of__className_1() { return &____className_1; }
	inline void set__className_1(String_t* value)
	{
		____className_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____className_1), (void*)value);
	}

	inline static int32_t get_offset_of__message_2() { return static_cast<int32_t>(offsetof(Exception_t, ____message_2)); }
	inline String_t* get__message_2() const { return ____message_2; }
	inline String_t** get_address_of__message_2() { return &____message_2; }
	inline void set__message_2(String_t* value)
	{
		____message_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____message_2), (void*)value);
	}

	inline static int32_t get_offset_of__data_3() { return static_cast<int32_t>(offsetof(Exception_t, ____data_3)); }
	inline RuntimeObject* get__data_3() const { return ____data_3; }
	inline RuntimeObject** get_address_of__data_3() { return &____data_3; }
	inline void set__data_3(RuntimeObject* value)
	{
		____data_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____data_3), (void*)value);
	}

	inline static int32_t get_offset_of__innerException_4() { return static_cast<int32_t>(offsetof(Exception_t, ____innerException_4)); }
	inline Exception_t * get__innerException_4() const { return ____innerException_4; }
	inline Exception_t ** get_address_of__innerException_4() { return &____innerException_4; }
	inline void set__innerException_4(Exception_t * value)
	{
		____innerException_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____innerException_4), (void*)value);
	}

	inline static int32_t get_offset_of__helpURL_5() { return static_cast<int32_t>(offsetof(Exception_t, ____helpURL_5)); }
	inline String_t* get__helpURL_5() const { return ____helpURL_5; }
	inline String_t** get_address_of__helpURL_5() { return &____helpURL_5; }
	inline void set__helpURL_5(String_t* value)
	{
		____helpURL_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____helpURL_5), (void*)value);
	}

	inline static int32_t get_offset_of__stackTrace_6() { return static_cast<int32_t>(offsetof(Exception_t, ____stackTrace_6)); }
	inline RuntimeObject * get__stackTrace_6() const { return ____stackTrace_6; }
	inline RuntimeObject ** get_address_of__stackTrace_6() { return &____stackTrace_6; }
	inline void set__stackTrace_6(RuntimeObject * value)
	{
		____stackTrace_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____stackTrace_6), (void*)value);
	}

	inline static int32_t get_offset_of__stackTraceString_7() { return static_cast<int32_t>(offsetof(Exception_t, ____stackTraceString_7)); }
	inline String_t* get__stackTraceString_7() const { return ____stackTraceString_7; }
	inline String_t** get_address_of__stackTraceString_7() { return &____stackTraceString_7; }
	inline void set__stackTraceString_7(String_t* value)
	{
		____stackTraceString_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____stackTraceString_7), (void*)value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_8() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackTraceString_8)); }
	inline String_t* get__remoteStackTraceString_8() const { return ____remoteStackTraceString_8; }
	inline String_t** get_address_of__remoteStackTraceString_8() { return &____remoteStackTraceString_8; }
	inline void set__remoteStackTraceString_8(String_t* value)
	{
		____remoteStackTraceString_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____remoteStackTraceString_8), (void*)value);
	}

	inline static int32_t get_offset_of__remoteStackIndex_9() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackIndex_9)); }
	inline int32_t get__remoteStackIndex_9() const { return ____remoteStackIndex_9; }
	inline int32_t* get_address_of__remoteStackIndex_9() { return &____remoteStackIndex_9; }
	inline void set__remoteStackIndex_9(int32_t value)
	{
		____remoteStackIndex_9 = value;
	}

	inline static int32_t get_offset_of__dynamicMethods_10() { return static_cast<int32_t>(offsetof(Exception_t, ____dynamicMethods_10)); }
	inline RuntimeObject * get__dynamicMethods_10() const { return ____dynamicMethods_10; }
	inline RuntimeObject ** get_address_of__dynamicMethods_10() { return &____dynamicMethods_10; }
	inline void set__dynamicMethods_10(RuntimeObject * value)
	{
		____dynamicMethods_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____dynamicMethods_10), (void*)value);
	}

	inline static int32_t get_offset_of__HResult_11() { return static_cast<int32_t>(offsetof(Exception_t, ____HResult_11)); }
	inline int32_t get__HResult_11() const { return ____HResult_11; }
	inline int32_t* get_address_of__HResult_11() { return &____HResult_11; }
	inline void set__HResult_11(int32_t value)
	{
		____HResult_11 = value;
	}

	inline static int32_t get_offset_of__source_12() { return static_cast<int32_t>(offsetof(Exception_t, ____source_12)); }
	inline String_t* get__source_12() const { return ____source_12; }
	inline String_t** get_address_of__source_12() { return &____source_12; }
	inline void set__source_12(String_t* value)
	{
		____source_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____source_12), (void*)value);
	}

	inline static int32_t get_offset_of__safeSerializationManager_13() { return static_cast<int32_t>(offsetof(Exception_t, ____safeSerializationManager_13)); }
	inline SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * get__safeSerializationManager_13() const { return ____safeSerializationManager_13; }
	inline SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 ** get_address_of__safeSerializationManager_13() { return &____safeSerializationManager_13; }
	inline void set__safeSerializationManager_13(SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * value)
	{
		____safeSerializationManager_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____safeSerializationManager_13), (void*)value);
	}

	inline static int32_t get_offset_of_captured_traces_14() { return static_cast<int32_t>(offsetof(Exception_t, ___captured_traces_14)); }
	inline StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* get_captured_traces_14() const { return ___captured_traces_14; }
	inline StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196** get_address_of_captured_traces_14() { return &___captured_traces_14; }
	inline void set_captured_traces_14(StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* value)
	{
		___captured_traces_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___captured_traces_14), (void*)value);
	}

	inline static int32_t get_offset_of_native_trace_ips_15() { return static_cast<int32_t>(offsetof(Exception_t, ___native_trace_ips_15)); }
	inline IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD* get_native_trace_ips_15() const { return ___native_trace_ips_15; }
	inline IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD** get_address_of_native_trace_ips_15() { return &___native_trace_ips_15; }
	inline void set_native_trace_ips_15(IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD* value)
	{
		___native_trace_ips_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___native_trace_ips_15), (void*)value);
	}
};

struct Exception_t_StaticFields
{
public:
	// System.Object System.Exception::s_EDILock
	RuntimeObject * ___s_EDILock_0;

public:
	inline static int32_t get_offset_of_s_EDILock_0() { return static_cast<int32_t>(offsetof(Exception_t_StaticFields, ___s_EDILock_0)); }
	inline RuntimeObject * get_s_EDILock_0() const { return ___s_EDILock_0; }
	inline RuntimeObject ** get_address_of_s_EDILock_0() { return &___s_EDILock_0; }
	inline void set_s_EDILock_0(RuntimeObject * value)
	{
		___s_EDILock_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_EDILock_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Exception
struct Exception_t_marshaled_pinvoke
{
	char* ____className_1;
	char* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_pinvoke* ____innerException_4;
	char* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	char* ____stackTraceString_7;
	char* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	char* ____source_12;
	SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * ____safeSerializationManager_13;
	StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
};
// Native definition for COM marshalling of System.Exception
struct Exception_t_marshaled_com
{
	Il2CppChar* ____className_1;
	Il2CppChar* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_com* ____innerException_4;
	Il2CppChar* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	Il2CppChar* ____stackTraceString_7;
	Il2CppChar* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	Il2CppChar* ____source_12;
	SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * ____safeSerializationManager_13;
	StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
};

// System.Int32Enum
struct  Int32Enum_t6312CE4586C17FE2E2E513D2E7655B574F10FDCD 
{
public:
	// System.Int32 System.Int32Enum::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Int32Enum_t6312CE4586C17FE2E2E513D2E7655B574F10FDCD, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Net.WebSockets.WebSocketCloseStatus
struct  WebSocketCloseStatus_tA9A53A917EED177DCA785A0B9055317D4414F39E 
{
public:
	// System.Int32 System.Net.WebSockets.WebSocketCloseStatus::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WebSocketCloseStatus_tA9A53A917EED177DCA785A0B9055317D4414F39E, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Net.WebSockets.WebSocketError
struct  WebSocketError_t7230439418DCC6668B48A704894FF3A1E3D94AD3 
{
public:
	// System.Int32 System.Net.WebSockets.WebSocketError::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WebSocketError_t7230439418DCC6668B48A704894FF3A1E3D94AD3, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Net.WebSockets.WebSocketMessageType
struct  WebSocketMessageType_t94D0FB4B42FD4F572E52666DE20D75A94A63B1BB 
{
public:
	// System.Int32 System.Net.WebSockets.WebSocketMessageType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WebSocketMessageType_t94D0FB4B42FD4F572E52666DE20D75A94A63B1BB, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Net.WebSockets.WebSocketState
struct  WebSocketState_t41B718072995BDC8721054054400337F6FC27AEC 
{
public:
	// System.Int32 System.Net.WebSockets.WebSocketState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WebSocketState_t41B718072995BDC8721054054400337F6FC27AEC, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Reflection.BindingFlags
struct  BindingFlags_tE35C91D046E63A1B92BB9AB909FCF9DA84379ED0 
{
public:
	// System.Int32 System.Reflection.BindingFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(BindingFlags_tE35C91D046E63A1B92BB9AB909FCF9DA84379ED0, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>
struct  AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 
{
public:
	// System.Runtime.CompilerServices.AsyncMethodBuilderCore System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_coreState
	AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  ___m_coreState_1;
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_task
	Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * ___m_task_2;

public:
	inline static int32_t get_offset_of_m_coreState_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663, ___m_coreState_1)); }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  get_m_coreState_1() const { return ___m_coreState_1; }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01 * get_address_of_m_coreState_1() { return &___m_coreState_1; }
	inline void set_m_coreState_1(AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  value)
	{
		___m_coreState_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_task_2() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663, ___m_task_2)); }
	inline Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * get_m_task_2() const { return ___m_task_2; }
	inline Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 ** get_address_of_m_task_2() { return &___m_task_2; }
	inline void set_m_task_2(Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * value)
	{
		___m_task_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_2), (void*)value);
	}
};

struct AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::s_defaultResultTask
	Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * ___s_defaultResultTask_0;

public:
	inline static int32_t get_offset_of_s_defaultResultTask_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663_StaticFields, ___s_defaultResultTask_0)); }
	inline Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * get_s_defaultResultTask_0() const { return ___s_defaultResultTask_0; }
	inline Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 ** get_address_of_s_defaultResultTask_0() { return &___s_defaultResultTask_0; }
	inline void set_s_defaultResultTask_0(Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * value)
	{
		___s_defaultResultTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultResultTask_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>
struct  AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C 
{
public:
	// System.Runtime.CompilerServices.AsyncMethodBuilderCore System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_coreState
	AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  ___m_coreState_1;
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_task
	Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * ___m_task_2;

public:
	inline static int32_t get_offset_of_m_coreState_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C, ___m_coreState_1)); }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  get_m_coreState_1() const { return ___m_coreState_1; }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01 * get_address_of_m_coreState_1() { return &___m_coreState_1; }
	inline void set_m_coreState_1(AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  value)
	{
		___m_coreState_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_task_2() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C, ___m_task_2)); }
	inline Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * get_m_task_2() const { return ___m_task_2; }
	inline Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 ** get_address_of_m_task_2() { return &___m_task_2; }
	inline void set_m_task_2(Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * value)
	{
		___m_task_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_2), (void*)value);
	}
};

struct AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::s_defaultResultTask
	Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * ___s_defaultResultTask_0;

public:
	inline static int32_t get_offset_of_s_defaultResultTask_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C_StaticFields, ___s_defaultResultTask_0)); }
	inline Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * get_s_defaultResultTask_0() const { return ___s_defaultResultTask_0; }
	inline Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 ** get_address_of_s_defaultResultTask_0() { return &___s_defaultResultTask_0; }
	inline void set_s_defaultResultTask_0(Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * value)
	{
		___s_defaultResultTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultResultTask_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Threading.Tasks.VoidTaskResult>
struct  AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9 
{
public:
	// System.Runtime.CompilerServices.AsyncMethodBuilderCore System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_coreState
	AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  ___m_coreState_1;
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_task
	Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 * ___m_task_2;

public:
	inline static int32_t get_offset_of_m_coreState_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9, ___m_coreState_1)); }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  get_m_coreState_1() const { return ___m_coreState_1; }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01 * get_address_of_m_coreState_1() { return &___m_coreState_1; }
	inline void set_m_coreState_1(AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  value)
	{
		___m_coreState_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_task_2() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9, ___m_task_2)); }
	inline Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 * get_m_task_2() const { return ___m_task_2; }
	inline Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 ** get_address_of_m_task_2() { return &___m_task_2; }
	inline void set_m_task_2(Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 * value)
	{
		___m_task_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_2), (void*)value);
	}
};

struct AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::s_defaultResultTask
	Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 * ___s_defaultResultTask_0;

public:
	inline static int32_t get_offset_of_s_defaultResultTask_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9_StaticFields, ___s_defaultResultTask_0)); }
	inline Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 * get_s_defaultResultTask_0() const { return ___s_defaultResultTask_0; }
	inline Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 ** get_address_of_s_defaultResultTask_0() { return &___s_defaultResultTask_0; }
	inline void set_s_defaultResultTask_0(Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 * value)
	{
		___s_defaultResultTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultResultTask_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>
struct  AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED 
{
public:
	// System.Runtime.CompilerServices.AsyncMethodBuilderCore System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_coreState
	AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  ___m_coreState_1;
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_task
	Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * ___m_task_2;

public:
	inline static int32_t get_offset_of_m_coreState_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED, ___m_coreState_1)); }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  get_m_coreState_1() const { return ___m_coreState_1; }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01 * get_address_of_m_coreState_1() { return &___m_coreState_1; }
	inline void set_m_coreState_1(AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  value)
	{
		___m_coreState_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_task_2() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED, ___m_task_2)); }
	inline Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * get_m_task_2() const { return ___m_task_2; }
	inline Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F ** get_address_of_m_task_2() { return &___m_task_2; }
	inline void set_m_task_2(Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * value)
	{
		___m_task_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_2), (void*)value);
	}
};

struct AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::s_defaultResultTask
	Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * ___s_defaultResultTask_0;

public:
	inline static int32_t get_offset_of_s_defaultResultTask_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED_StaticFields, ___s_defaultResultTask_0)); }
	inline Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * get_s_defaultResultTask_0() const { return ___s_defaultResultTask_0; }
	inline Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F ** get_address_of_s_defaultResultTask_0() { return &___s_defaultResultTask_0; }
	inline void set_s_defaultResultTask_0(Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * value)
	{
		___s_defaultResultTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultResultTask_0), (void*)value);
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp_Response>
struct  AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD 
{
public:
	// System.Runtime.CompilerServices.AsyncMethodBuilderCore System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_coreState
	AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  ___m_coreState_1;
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::m_task
	Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * ___m_task_2;

public:
	inline static int32_t get_offset_of_m_coreState_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD, ___m_coreState_1)); }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  get_m_coreState_1() const { return ___m_coreState_1; }
	inline AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01 * get_address_of_m_coreState_1() { return &___m_coreState_1; }
	inline void set_m_coreState_1(AsyncMethodBuilderCore_t4CE6C1E4B0621A6EC45CF6E0E8F1F633FFF9FF01  value)
	{
		___m_coreState_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_m_task_2() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD, ___m_task_2)); }
	inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * get_m_task_2() const { return ___m_task_2; }
	inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA ** get_address_of_m_task_2() { return &___m_task_2; }
	inline void set_m_task_2(Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * value)
	{
		___m_task_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_task_2), (void*)value);
	}
};

struct AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<TResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::s_defaultResultTask
	Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * ___s_defaultResultTask_0;

public:
	inline static int32_t get_offset_of_s_defaultResultTask_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD_StaticFields, ___s_defaultResultTask_0)); }
	inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * get_s_defaultResultTask_0() const { return ___s_defaultResultTask_0; }
	inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA ** get_address_of_s_defaultResultTask_0() { return &___s_defaultResultTask_0; }
	inline void set_s_defaultResultTask_0(Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * value)
	{
		___s_defaultResultTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_defaultResultTask_0), (void*)value);
	}
};


// System.RuntimeTypeHandle
struct  RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D 
{
public:
	// System.IntPtr System.RuntimeTypeHandle::value
	intptr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D, ___value_0)); }
	inline intptr_t get_value_0() const { return ___value_0; }
	inline intptr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(intptr_t value)
	{
		___value_0 = value;
	}
};


// System.Text.RegularExpressions.Match
struct  Match_tE447871AB59EED3642F31EB9559D162C2977EBB5  : public Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443
{
public:
	// System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::_groupcoll
	GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * ____groupcoll_8;
	// System.Text.RegularExpressions.Regex System.Text.RegularExpressions.Match::_regex
	Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF * ____regex_9;
	// System.Int32 System.Text.RegularExpressions.Match::_textbeg
	int32_t ____textbeg_10;
	// System.Int32 System.Text.RegularExpressions.Match::_textpos
	int32_t ____textpos_11;
	// System.Int32 System.Text.RegularExpressions.Match::_textend
	int32_t ____textend_12;
	// System.Int32 System.Text.RegularExpressions.Match::_textstart
	int32_t ____textstart_13;
	// System.Int32[][] System.Text.RegularExpressions.Match::_matches
	Int32U5BU5DU5BU5D_tCA34E042D233821D51B4DAFB480EE602F2DBEF43* ____matches_14;
	// System.Int32[] System.Text.RegularExpressions.Match::_matchcount
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ____matchcount_15;
	// System.Boolean System.Text.RegularExpressions.Match::_balancing
	bool ____balancing_16;

public:
	inline static int32_t get_offset_of__groupcoll_8() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5, ____groupcoll_8)); }
	inline GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * get__groupcoll_8() const { return ____groupcoll_8; }
	inline GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F ** get_address_of__groupcoll_8() { return &____groupcoll_8; }
	inline void set__groupcoll_8(GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * value)
	{
		____groupcoll_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____groupcoll_8), (void*)value);
	}

	inline static int32_t get_offset_of__regex_9() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5, ____regex_9)); }
	inline Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF * get__regex_9() const { return ____regex_9; }
	inline Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF ** get_address_of__regex_9() { return &____regex_9; }
	inline void set__regex_9(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF * value)
	{
		____regex_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____regex_9), (void*)value);
	}

	inline static int32_t get_offset_of__textbeg_10() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5, ____textbeg_10)); }
	inline int32_t get__textbeg_10() const { return ____textbeg_10; }
	inline int32_t* get_address_of__textbeg_10() { return &____textbeg_10; }
	inline void set__textbeg_10(int32_t value)
	{
		____textbeg_10 = value;
	}

	inline static int32_t get_offset_of__textpos_11() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5, ____textpos_11)); }
	inline int32_t get__textpos_11() const { return ____textpos_11; }
	inline int32_t* get_address_of__textpos_11() { return &____textpos_11; }
	inline void set__textpos_11(int32_t value)
	{
		____textpos_11 = value;
	}

	inline static int32_t get_offset_of__textend_12() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5, ____textend_12)); }
	inline int32_t get__textend_12() const { return ____textend_12; }
	inline int32_t* get_address_of__textend_12() { return &____textend_12; }
	inline void set__textend_12(int32_t value)
	{
		____textend_12 = value;
	}

	inline static int32_t get_offset_of__textstart_13() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5, ____textstart_13)); }
	inline int32_t get__textstart_13() const { return ____textstart_13; }
	inline int32_t* get_address_of__textstart_13() { return &____textstart_13; }
	inline void set__textstart_13(int32_t value)
	{
		____textstart_13 = value;
	}

	inline static int32_t get_offset_of__matches_14() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5, ____matches_14)); }
	inline Int32U5BU5DU5BU5D_tCA34E042D233821D51B4DAFB480EE602F2DBEF43* get__matches_14() const { return ____matches_14; }
	inline Int32U5BU5DU5BU5D_tCA34E042D233821D51B4DAFB480EE602F2DBEF43** get_address_of__matches_14() { return &____matches_14; }
	inline void set__matches_14(Int32U5BU5DU5BU5D_tCA34E042D233821D51B4DAFB480EE602F2DBEF43* value)
	{
		____matches_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____matches_14), (void*)value);
	}

	inline static int32_t get_offset_of__matchcount_15() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5, ____matchcount_15)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get__matchcount_15() const { return ____matchcount_15; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of__matchcount_15() { return &____matchcount_15; }
	inline void set__matchcount_15(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		____matchcount_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____matchcount_15), (void*)value);
	}

	inline static int32_t get_offset_of__balancing_16() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5, ____balancing_16)); }
	inline bool get__balancing_16() const { return ____balancing_16; }
	inline bool* get_address_of__balancing_16() { return &____balancing_16; }
	inline void set__balancing_16(bool value)
	{
		____balancing_16 = value;
	}
};

struct Match_tE447871AB59EED3642F31EB9559D162C2977EBB5_StaticFields
{
public:
	// System.Text.RegularExpressions.Match System.Text.RegularExpressions.Match::_empty
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * ____empty_7;

public:
	inline static int32_t get_offset_of__empty_7() { return static_cast<int32_t>(offsetof(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5_StaticFields, ____empty_7)); }
	inline Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * get__empty_7() const { return ____empty_7; }
	inline Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 ** get_address_of__empty_7() { return &____empty_7; }
	inline void set__empty_7(Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * value)
	{
		____empty_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____empty_7), (void*)value);
	}
};


// System.Text.RegularExpressions.RegexOptions
struct  RegexOptions_t9A6138CDA9C60924D503C584095349F008C52EA1 
{
public:
	// System.Int32 System.Text.RegularExpressions.RegexOptions::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(RegexOptions_t9A6138CDA9C60924D503C584095349F008C52EA1, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Threading.CancellationTokenSource
struct  CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE  : public RuntimeObject
{
public:
	// System.Threading.ManualResetEvent modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.CancellationTokenSource::m_kernelEvent
	ManualResetEvent_tDFAF117B200ECA4CCF4FD09593F949A016D55408 * ___m_kernelEvent_3;
	// System.Threading.SparselyPopulatedArray`1<System.Threading.CancellationCallbackInfo>[] modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.CancellationTokenSource::m_registeredCallbacksLists
	SparselyPopulatedArray_1U5BU5D_tF1A5F348104DB1ECF18799250B41740FCAA77813* ___m_registeredCallbacksLists_4;
	// System.Int32 modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.CancellationTokenSource::m_state
	int32_t ___m_state_5;
	// System.Int32 modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.CancellationTokenSource::m_threadIDExecutingCallbacks
	int32_t ___m_threadIDExecutingCallbacks_6;
	// System.Boolean System.Threading.CancellationTokenSource::m_disposed
	bool ___m_disposed_7;
	// System.Threading.CancellationTokenRegistration[] System.Threading.CancellationTokenSource::m_linkingRegistrations
	CancellationTokenRegistrationU5BU5D_t4B36771A6344CFC66696BB16419C664E286DAF1B* ___m_linkingRegistrations_8;
	// System.Threading.CancellationCallbackInfo modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.CancellationTokenSource::m_executingCallback
	CancellationCallbackInfo_t8CDEA0AA9C9D1A2321FE2F88878F4B5E0901CF36 * ___m_executingCallback_10;
	// System.Threading.Timer modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.CancellationTokenSource::m_timer
	Timer_t67FAB8E41573B4FA09CA56AE30725AF4297C2553 * ___m_timer_11;

public:
	inline static int32_t get_offset_of_m_kernelEvent_3() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE, ___m_kernelEvent_3)); }
	inline ManualResetEvent_tDFAF117B200ECA4CCF4FD09593F949A016D55408 * get_m_kernelEvent_3() const { return ___m_kernelEvent_3; }
	inline ManualResetEvent_tDFAF117B200ECA4CCF4FD09593F949A016D55408 ** get_address_of_m_kernelEvent_3() { return &___m_kernelEvent_3; }
	inline void set_m_kernelEvent_3(ManualResetEvent_tDFAF117B200ECA4CCF4FD09593F949A016D55408 * value)
	{
		___m_kernelEvent_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_kernelEvent_3), (void*)value);
	}

	inline static int32_t get_offset_of_m_registeredCallbacksLists_4() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE, ___m_registeredCallbacksLists_4)); }
	inline SparselyPopulatedArray_1U5BU5D_tF1A5F348104DB1ECF18799250B41740FCAA77813* get_m_registeredCallbacksLists_4() const { return ___m_registeredCallbacksLists_4; }
	inline SparselyPopulatedArray_1U5BU5D_tF1A5F348104DB1ECF18799250B41740FCAA77813** get_address_of_m_registeredCallbacksLists_4() { return &___m_registeredCallbacksLists_4; }
	inline void set_m_registeredCallbacksLists_4(SparselyPopulatedArray_1U5BU5D_tF1A5F348104DB1ECF18799250B41740FCAA77813* value)
	{
		___m_registeredCallbacksLists_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_registeredCallbacksLists_4), (void*)value);
	}

	inline static int32_t get_offset_of_m_state_5() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE, ___m_state_5)); }
	inline int32_t get_m_state_5() const { return ___m_state_5; }
	inline int32_t* get_address_of_m_state_5() { return &___m_state_5; }
	inline void set_m_state_5(int32_t value)
	{
		___m_state_5 = value;
	}

	inline static int32_t get_offset_of_m_threadIDExecutingCallbacks_6() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE, ___m_threadIDExecutingCallbacks_6)); }
	inline int32_t get_m_threadIDExecutingCallbacks_6() const { return ___m_threadIDExecutingCallbacks_6; }
	inline int32_t* get_address_of_m_threadIDExecutingCallbacks_6() { return &___m_threadIDExecutingCallbacks_6; }
	inline void set_m_threadIDExecutingCallbacks_6(int32_t value)
	{
		___m_threadIDExecutingCallbacks_6 = value;
	}

	inline static int32_t get_offset_of_m_disposed_7() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE, ___m_disposed_7)); }
	inline bool get_m_disposed_7() const { return ___m_disposed_7; }
	inline bool* get_address_of_m_disposed_7() { return &___m_disposed_7; }
	inline void set_m_disposed_7(bool value)
	{
		___m_disposed_7 = value;
	}

	inline static int32_t get_offset_of_m_linkingRegistrations_8() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE, ___m_linkingRegistrations_8)); }
	inline CancellationTokenRegistrationU5BU5D_t4B36771A6344CFC66696BB16419C664E286DAF1B* get_m_linkingRegistrations_8() const { return ___m_linkingRegistrations_8; }
	inline CancellationTokenRegistrationU5BU5D_t4B36771A6344CFC66696BB16419C664E286DAF1B** get_address_of_m_linkingRegistrations_8() { return &___m_linkingRegistrations_8; }
	inline void set_m_linkingRegistrations_8(CancellationTokenRegistrationU5BU5D_t4B36771A6344CFC66696BB16419C664E286DAF1B* value)
	{
		___m_linkingRegistrations_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_linkingRegistrations_8), (void*)value);
	}

	inline static int32_t get_offset_of_m_executingCallback_10() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE, ___m_executingCallback_10)); }
	inline CancellationCallbackInfo_t8CDEA0AA9C9D1A2321FE2F88878F4B5E0901CF36 * get_m_executingCallback_10() const { return ___m_executingCallback_10; }
	inline CancellationCallbackInfo_t8CDEA0AA9C9D1A2321FE2F88878F4B5E0901CF36 ** get_address_of_m_executingCallback_10() { return &___m_executingCallback_10; }
	inline void set_m_executingCallback_10(CancellationCallbackInfo_t8CDEA0AA9C9D1A2321FE2F88878F4B5E0901CF36 * value)
	{
		___m_executingCallback_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_executingCallback_10), (void*)value);
	}

	inline static int32_t get_offset_of_m_timer_11() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE, ___m_timer_11)); }
	inline Timer_t67FAB8E41573B4FA09CA56AE30725AF4297C2553 * get_m_timer_11() const { return ___m_timer_11; }
	inline Timer_t67FAB8E41573B4FA09CA56AE30725AF4297C2553 ** get_address_of_m_timer_11() { return &___m_timer_11; }
	inline void set_m_timer_11(Timer_t67FAB8E41573B4FA09CA56AE30725AF4297C2553 * value)
	{
		___m_timer_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_timer_11), (void*)value);
	}
};

struct CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_StaticFields
{
public:
	// System.Threading.CancellationTokenSource System.Threading.CancellationTokenSource::_staticSource_Set
	CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * ____staticSource_Set_0;
	// System.Threading.CancellationTokenSource System.Threading.CancellationTokenSource::_staticSource_NotCancelable
	CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * ____staticSource_NotCancelable_1;
	// System.Int32 System.Threading.CancellationTokenSource::s_nLists
	int32_t ___s_nLists_2;
	// System.Action`1<System.Object> System.Threading.CancellationTokenSource::s_LinkedTokenCancelDelegate
	Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 * ___s_LinkedTokenCancelDelegate_9;
	// System.Threading.TimerCallback System.Threading.CancellationTokenSource::s_timerCallback
	TimerCallback_tC89F2FB1294A86F64DEB2C1F68024954018AA219 * ___s_timerCallback_12;

public:
	inline static int32_t get_offset_of__staticSource_Set_0() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_StaticFields, ____staticSource_Set_0)); }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * get__staticSource_Set_0() const { return ____staticSource_Set_0; }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE ** get_address_of__staticSource_Set_0() { return &____staticSource_Set_0; }
	inline void set__staticSource_Set_0(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * value)
	{
		____staticSource_Set_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____staticSource_Set_0), (void*)value);
	}

	inline static int32_t get_offset_of__staticSource_NotCancelable_1() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_StaticFields, ____staticSource_NotCancelable_1)); }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * get__staticSource_NotCancelable_1() const { return ____staticSource_NotCancelable_1; }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE ** get_address_of__staticSource_NotCancelable_1() { return &____staticSource_NotCancelable_1; }
	inline void set__staticSource_NotCancelable_1(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * value)
	{
		____staticSource_NotCancelable_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____staticSource_NotCancelable_1), (void*)value);
	}

	inline static int32_t get_offset_of_s_nLists_2() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_StaticFields, ___s_nLists_2)); }
	inline int32_t get_s_nLists_2() const { return ___s_nLists_2; }
	inline int32_t* get_address_of_s_nLists_2() { return &___s_nLists_2; }
	inline void set_s_nLists_2(int32_t value)
	{
		___s_nLists_2 = value;
	}

	inline static int32_t get_offset_of_s_LinkedTokenCancelDelegate_9() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_StaticFields, ___s_LinkedTokenCancelDelegate_9)); }
	inline Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 * get_s_LinkedTokenCancelDelegate_9() const { return ___s_LinkedTokenCancelDelegate_9; }
	inline Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 ** get_address_of_s_LinkedTokenCancelDelegate_9() { return &___s_LinkedTokenCancelDelegate_9; }
	inline void set_s_LinkedTokenCancelDelegate_9(Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 * value)
	{
		___s_LinkedTokenCancelDelegate_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_LinkedTokenCancelDelegate_9), (void*)value);
	}

	inline static int32_t get_offset_of_s_timerCallback_12() { return static_cast<int32_t>(offsetof(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_StaticFields, ___s_timerCallback_12)); }
	inline TimerCallback_tC89F2FB1294A86F64DEB2C1F68024954018AA219 * get_s_timerCallback_12() const { return ___s_timerCallback_12; }
	inline TimerCallback_tC89F2FB1294A86F64DEB2C1F68024954018AA219 ** get_address_of_s_timerCallback_12() { return &___s_timerCallback_12; }
	inline void set_s_timerCallback_12(TimerCallback_tC89F2FB1294A86F64DEB2C1F68024954018AA219 * value)
	{
		___s_timerCallback_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_timerCallback_12), (void*)value);
	}
};


// System.Threading.Tasks.Task
struct  Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2  : public RuntimeObject
{
public:
	// System.Int32 modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.Tasks.Task::m_taskId
	int32_t ___m_taskId_4;
	// System.Object System.Threading.Tasks.Task::m_action
	RuntimeObject * ___m_action_5;
	// System.Object System.Threading.Tasks.Task::m_stateObject
	RuntimeObject * ___m_stateObject_6;
	// System.Threading.Tasks.TaskScheduler System.Threading.Tasks.Task::m_taskScheduler
	TaskScheduler_t966F2798F198FA90A0DA8EFC92BAC08297793114 * ___m_taskScheduler_7;
	// System.Threading.Tasks.Task System.Threading.Tasks.Task::m_parent
	Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * ___m_parent_8;
	// System.Int32 modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.Tasks.Task::m_stateFlags
	int32_t ___m_stateFlags_9;
	// System.Object modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.Tasks.Task::m_continuationObject
	RuntimeObject * ___m_continuationObject_10;
	// System.Threading.Tasks.Task_ContingentProperties modreq(System.Runtime.CompilerServices.IsVolatile) System.Threading.Tasks.Task::m_contingentProperties
	ContingentProperties_t7149A27D01507C74E8BDAAA3848B45D2644FDF08 * ___m_contingentProperties_15;

public:
	inline static int32_t get_offset_of_m_taskId_4() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2, ___m_taskId_4)); }
	inline int32_t get_m_taskId_4() const { return ___m_taskId_4; }
	inline int32_t* get_address_of_m_taskId_4() { return &___m_taskId_4; }
	inline void set_m_taskId_4(int32_t value)
	{
		___m_taskId_4 = value;
	}

	inline static int32_t get_offset_of_m_action_5() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2, ___m_action_5)); }
	inline RuntimeObject * get_m_action_5() const { return ___m_action_5; }
	inline RuntimeObject ** get_address_of_m_action_5() { return &___m_action_5; }
	inline void set_m_action_5(RuntimeObject * value)
	{
		___m_action_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_action_5), (void*)value);
	}

	inline static int32_t get_offset_of_m_stateObject_6() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2, ___m_stateObject_6)); }
	inline RuntimeObject * get_m_stateObject_6() const { return ___m_stateObject_6; }
	inline RuntimeObject ** get_address_of_m_stateObject_6() { return &___m_stateObject_6; }
	inline void set_m_stateObject_6(RuntimeObject * value)
	{
		___m_stateObject_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_stateObject_6), (void*)value);
	}

	inline static int32_t get_offset_of_m_taskScheduler_7() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2, ___m_taskScheduler_7)); }
	inline TaskScheduler_t966F2798F198FA90A0DA8EFC92BAC08297793114 * get_m_taskScheduler_7() const { return ___m_taskScheduler_7; }
	inline TaskScheduler_t966F2798F198FA90A0DA8EFC92BAC08297793114 ** get_address_of_m_taskScheduler_7() { return &___m_taskScheduler_7; }
	inline void set_m_taskScheduler_7(TaskScheduler_t966F2798F198FA90A0DA8EFC92BAC08297793114 * value)
	{
		___m_taskScheduler_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_taskScheduler_7), (void*)value);
	}

	inline static int32_t get_offset_of_m_parent_8() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2, ___m_parent_8)); }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * get_m_parent_8() const { return ___m_parent_8; }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 ** get_address_of_m_parent_8() { return &___m_parent_8; }
	inline void set_m_parent_8(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * value)
	{
		___m_parent_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_parent_8), (void*)value);
	}

	inline static int32_t get_offset_of_m_stateFlags_9() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2, ___m_stateFlags_9)); }
	inline int32_t get_m_stateFlags_9() const { return ___m_stateFlags_9; }
	inline int32_t* get_address_of_m_stateFlags_9() { return &___m_stateFlags_9; }
	inline void set_m_stateFlags_9(int32_t value)
	{
		___m_stateFlags_9 = value;
	}

	inline static int32_t get_offset_of_m_continuationObject_10() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2, ___m_continuationObject_10)); }
	inline RuntimeObject * get_m_continuationObject_10() const { return ___m_continuationObject_10; }
	inline RuntimeObject ** get_address_of_m_continuationObject_10() { return &___m_continuationObject_10; }
	inline void set_m_continuationObject_10(RuntimeObject * value)
	{
		___m_continuationObject_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_continuationObject_10), (void*)value);
	}

	inline static int32_t get_offset_of_m_contingentProperties_15() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2, ___m_contingentProperties_15)); }
	inline ContingentProperties_t7149A27D01507C74E8BDAAA3848B45D2644FDF08 * get_m_contingentProperties_15() const { return ___m_contingentProperties_15; }
	inline ContingentProperties_t7149A27D01507C74E8BDAAA3848B45D2644FDF08 ** get_address_of_m_contingentProperties_15() { return &___m_contingentProperties_15; }
	inline void set_m_contingentProperties_15(ContingentProperties_t7149A27D01507C74E8BDAAA3848B45D2644FDF08 * value)
	{
		___m_contingentProperties_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_contingentProperties_15), (void*)value);
	}
};

struct Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields
{
public:
	// System.Int32 System.Threading.Tasks.Task::s_taskIdCounter
	int32_t ___s_taskIdCounter_2;
	// System.Threading.Tasks.TaskFactory System.Threading.Tasks.Task::s_factory
	TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155 * ___s_factory_3;
	// System.Object System.Threading.Tasks.Task::s_taskCompletionSentinel
	RuntimeObject * ___s_taskCompletionSentinel_11;
	// System.Boolean System.Threading.Tasks.Task::s_asyncDebuggingEnabled
	bool ___s_asyncDebuggingEnabled_12;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Threading.Tasks.Task> System.Threading.Tasks.Task::s_currentActiveTasks
	Dictionary_2_t70161CFEB8DA3C79E19E31D0ED948D3C2925095F * ___s_currentActiveTasks_13;
	// System.Object System.Threading.Tasks.Task::s_activeTasksLock
	RuntimeObject * ___s_activeTasksLock_14;
	// System.Action`1<System.Object> System.Threading.Tasks.Task::s_taskCancelCallback
	Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 * ___s_taskCancelCallback_16;
	// System.Func`1<System.Threading.Tasks.Task_ContingentProperties> System.Threading.Tasks.Task::s_createContingentProperties
	Func_1_t48C2978A48CE3F2F6EB5B6DE269D00746483BB1F * ___s_createContingentProperties_17;
	// System.Threading.Tasks.Task System.Threading.Tasks.Task::s_completedTask
	Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * ___s_completedTask_18;
	// System.Predicate`1<System.Threading.Tasks.Task> System.Threading.Tasks.Task::s_IsExceptionObservedByParentPredicate
	Predicate_1_tF4286C34BB184CE5690FDCEBA7F09FC68D229335 * ___s_IsExceptionObservedByParentPredicate_19;
	// System.Threading.ContextCallback System.Threading.Tasks.Task::s_ecCallback
	ContextCallback_t8AE8A965AC6C7ECD396F527F15CDC8E683BE1676 * ___s_ecCallback_20;
	// System.Predicate`1<System.Object> System.Threading.Tasks.Task::s_IsTaskContinuationNullPredicate
	Predicate_1_t4AA10EFD4C5497CA1CD0FE35A6AF5990FF5D0979 * ___s_IsTaskContinuationNullPredicate_21;

public:
	inline static int32_t get_offset_of_s_taskIdCounter_2() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_taskIdCounter_2)); }
	inline int32_t get_s_taskIdCounter_2() const { return ___s_taskIdCounter_2; }
	inline int32_t* get_address_of_s_taskIdCounter_2() { return &___s_taskIdCounter_2; }
	inline void set_s_taskIdCounter_2(int32_t value)
	{
		___s_taskIdCounter_2 = value;
	}

	inline static int32_t get_offset_of_s_factory_3() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_factory_3)); }
	inline TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155 * get_s_factory_3() const { return ___s_factory_3; }
	inline TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155 ** get_address_of_s_factory_3() { return &___s_factory_3; }
	inline void set_s_factory_3(TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155 * value)
	{
		___s_factory_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_factory_3), (void*)value);
	}

	inline static int32_t get_offset_of_s_taskCompletionSentinel_11() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_taskCompletionSentinel_11)); }
	inline RuntimeObject * get_s_taskCompletionSentinel_11() const { return ___s_taskCompletionSentinel_11; }
	inline RuntimeObject ** get_address_of_s_taskCompletionSentinel_11() { return &___s_taskCompletionSentinel_11; }
	inline void set_s_taskCompletionSentinel_11(RuntimeObject * value)
	{
		___s_taskCompletionSentinel_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_taskCompletionSentinel_11), (void*)value);
	}

	inline static int32_t get_offset_of_s_asyncDebuggingEnabled_12() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_asyncDebuggingEnabled_12)); }
	inline bool get_s_asyncDebuggingEnabled_12() const { return ___s_asyncDebuggingEnabled_12; }
	inline bool* get_address_of_s_asyncDebuggingEnabled_12() { return &___s_asyncDebuggingEnabled_12; }
	inline void set_s_asyncDebuggingEnabled_12(bool value)
	{
		___s_asyncDebuggingEnabled_12 = value;
	}

	inline static int32_t get_offset_of_s_currentActiveTasks_13() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_currentActiveTasks_13)); }
	inline Dictionary_2_t70161CFEB8DA3C79E19E31D0ED948D3C2925095F * get_s_currentActiveTasks_13() const { return ___s_currentActiveTasks_13; }
	inline Dictionary_2_t70161CFEB8DA3C79E19E31D0ED948D3C2925095F ** get_address_of_s_currentActiveTasks_13() { return &___s_currentActiveTasks_13; }
	inline void set_s_currentActiveTasks_13(Dictionary_2_t70161CFEB8DA3C79E19E31D0ED948D3C2925095F * value)
	{
		___s_currentActiveTasks_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_currentActiveTasks_13), (void*)value);
	}

	inline static int32_t get_offset_of_s_activeTasksLock_14() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_activeTasksLock_14)); }
	inline RuntimeObject * get_s_activeTasksLock_14() const { return ___s_activeTasksLock_14; }
	inline RuntimeObject ** get_address_of_s_activeTasksLock_14() { return &___s_activeTasksLock_14; }
	inline void set_s_activeTasksLock_14(RuntimeObject * value)
	{
		___s_activeTasksLock_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_activeTasksLock_14), (void*)value);
	}

	inline static int32_t get_offset_of_s_taskCancelCallback_16() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_taskCancelCallback_16)); }
	inline Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 * get_s_taskCancelCallback_16() const { return ___s_taskCancelCallback_16; }
	inline Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 ** get_address_of_s_taskCancelCallback_16() { return &___s_taskCancelCallback_16; }
	inline void set_s_taskCancelCallback_16(Action_1_t551A279CEADCF6EEAE8FA2B1E1E757D0D15290D0 * value)
	{
		___s_taskCancelCallback_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_taskCancelCallback_16), (void*)value);
	}

	inline static int32_t get_offset_of_s_createContingentProperties_17() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_createContingentProperties_17)); }
	inline Func_1_t48C2978A48CE3F2F6EB5B6DE269D00746483BB1F * get_s_createContingentProperties_17() const { return ___s_createContingentProperties_17; }
	inline Func_1_t48C2978A48CE3F2F6EB5B6DE269D00746483BB1F ** get_address_of_s_createContingentProperties_17() { return &___s_createContingentProperties_17; }
	inline void set_s_createContingentProperties_17(Func_1_t48C2978A48CE3F2F6EB5B6DE269D00746483BB1F * value)
	{
		___s_createContingentProperties_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_createContingentProperties_17), (void*)value);
	}

	inline static int32_t get_offset_of_s_completedTask_18() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_completedTask_18)); }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * get_s_completedTask_18() const { return ___s_completedTask_18; }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 ** get_address_of_s_completedTask_18() { return &___s_completedTask_18; }
	inline void set_s_completedTask_18(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * value)
	{
		___s_completedTask_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_completedTask_18), (void*)value);
	}

	inline static int32_t get_offset_of_s_IsExceptionObservedByParentPredicate_19() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_IsExceptionObservedByParentPredicate_19)); }
	inline Predicate_1_tF4286C34BB184CE5690FDCEBA7F09FC68D229335 * get_s_IsExceptionObservedByParentPredicate_19() const { return ___s_IsExceptionObservedByParentPredicate_19; }
	inline Predicate_1_tF4286C34BB184CE5690FDCEBA7F09FC68D229335 ** get_address_of_s_IsExceptionObservedByParentPredicate_19() { return &___s_IsExceptionObservedByParentPredicate_19; }
	inline void set_s_IsExceptionObservedByParentPredicate_19(Predicate_1_tF4286C34BB184CE5690FDCEBA7F09FC68D229335 * value)
	{
		___s_IsExceptionObservedByParentPredicate_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_IsExceptionObservedByParentPredicate_19), (void*)value);
	}

	inline static int32_t get_offset_of_s_ecCallback_20() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_ecCallback_20)); }
	inline ContextCallback_t8AE8A965AC6C7ECD396F527F15CDC8E683BE1676 * get_s_ecCallback_20() const { return ___s_ecCallback_20; }
	inline ContextCallback_t8AE8A965AC6C7ECD396F527F15CDC8E683BE1676 ** get_address_of_s_ecCallback_20() { return &___s_ecCallback_20; }
	inline void set_s_ecCallback_20(ContextCallback_t8AE8A965AC6C7ECD396F527F15CDC8E683BE1676 * value)
	{
		___s_ecCallback_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_ecCallback_20), (void*)value);
	}

	inline static int32_t get_offset_of_s_IsTaskContinuationNullPredicate_21() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields, ___s_IsTaskContinuationNullPredicate_21)); }
	inline Predicate_1_t4AA10EFD4C5497CA1CD0FE35A6AF5990FF5D0979 * get_s_IsTaskContinuationNullPredicate_21() const { return ___s_IsTaskContinuationNullPredicate_21; }
	inline Predicate_1_t4AA10EFD4C5497CA1CD0FE35A6AF5990FF5D0979 ** get_address_of_s_IsTaskContinuationNullPredicate_21() { return &___s_IsTaskContinuationNullPredicate_21; }
	inline void set_s_IsTaskContinuationNullPredicate_21(Predicate_1_t4AA10EFD4C5497CA1CD0FE35A6AF5990FF5D0979 * value)
	{
		___s_IsTaskContinuationNullPredicate_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_IsTaskContinuationNullPredicate_21), (void*)value);
	}
};

struct Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_ThreadStaticFields
{
public:
	// System.Threading.Tasks.Task System.Threading.Tasks.Task::t_currentTask
	Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * ___t_currentTask_0;
	// System.Threading.Tasks.StackGuard System.Threading.Tasks.Task::t_stackGuard
	StackGuard_tE431ED3BBD1A18705FEE6F948EBF7FA2E99D64A9 * ___t_stackGuard_1;

public:
	inline static int32_t get_offset_of_t_currentTask_0() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_ThreadStaticFields, ___t_currentTask_0)); }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * get_t_currentTask_0() const { return ___t_currentTask_0; }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 ** get_address_of_t_currentTask_0() { return &___t_currentTask_0; }
	inline void set_t_currentTask_0(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * value)
	{
		___t_currentTask_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___t_currentTask_0), (void*)value);
	}

	inline static int32_t get_offset_of_t_stackGuard_1() { return static_cast<int32_t>(offsetof(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_ThreadStaticFields, ___t_stackGuard_1)); }
	inline StackGuard_tE431ED3BBD1A18705FEE6F948EBF7FA2E99D64A9 * get_t_stackGuard_1() const { return ___t_stackGuard_1; }
	inline StackGuard_tE431ED3BBD1A18705FEE6F948EBF7FA2E99D64A9 ** get_address_of_t_stackGuard_1() { return &___t_stackGuard_1; }
	inline void set_t_stackGuard_1(StackGuard_tE431ED3BBD1A18705FEE6F948EBF7FA2E99D64A9 * value)
	{
		___t_stackGuard_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___t_stackGuard_1), (void*)value);
	}
};


// System.Threading.Tasks.TaskContinuationOptions
struct  TaskContinuationOptions_t749581ABDD24D74BD051F09EC4E3408C209121A2 
{
public:
	// System.Int32 System.Threading.Tasks.TaskContinuationOptions::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TaskContinuationOptions_t749581ABDD24D74BD051F09EC4E3408C209121A2, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Threading.Tasks.TaskCreationOptions
struct  TaskCreationOptions_t73D75E64925AACDF2A90DDB3D508192A8E74D375 
{
public:
	// System.Int32 System.Threading.Tasks.TaskCreationOptions::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TaskCreationOptions_t73D75E64925AACDF2A90DDB3D508192A8E74D375, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Uri_Flags
struct  Flags_tEBE7CABEBD13F16920D6950B384EB8F988250A2A 
{
public:
	// System.UInt64 System.Uri_Flags::value__
	uint64_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Flags_tEBE7CABEBD13F16920D6950B384EB8F988250A2A, ___value___2)); }
	inline uint64_t get_value___2() const { return ___value___2; }
	inline uint64_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint64_t value)
	{
		___value___2 = value;
	}
};


// System.UriFormat
struct  UriFormat_t4355763D39FF6F0FAA2B43E3A209BA8500730992 
{
public:
	// System.Int32 System.UriFormat::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(UriFormat_t4355763D39FF6F0FAA2B43E3A209BA8500730992, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.UriIdnScope
struct  UriIdnScope_tE1574B39C7492C761EFE2FC12DDE82DE013AC9D1 
{
public:
	// System.Int32 System.UriIdnScope::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(UriIdnScope_tE1574B39C7492C761EFE2FC12DDE82DE013AC9D1, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.UriKind
struct  UriKind_t26D0760DDF148ADC939FECD934C0B9FF5C71EA08 
{
public:
	// System.Int32 System.UriKind::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(UriKind_t26D0760DDF148ADC939FECD934C0B9FF5C71EA08, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// TransportOptions
struct  TransportOptions_t9EEC93A2E911B9D1A386999782BE3168373A2527  : public Options_t36565DDE7EEC80CC7827D71EEC8E99E37411D050
{
public:
	// System.Int32 TransportOptions::transport
	int32_t ___transport_0;

public:
	inline static int32_t get_offset_of_transport_0() { return static_cast<int32_t>(offsetof(TransportOptions_t9EEC93A2E911B9D1A386999782BE3168373A2527, ___transport_0)); }
	inline int32_t get_transport_0() const { return ___transport_0; }
	inline int32_t* get_address_of_transport_0() { return &___transport_0; }
	inline void set_transport_0(int32_t value)
	{
		___transport_0 = value;
	}
};


// Wamp_<>c__DisplayClass32_0
struct  U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63  : public RuntimeObject
{
public:
	// System.Threading.CancellationToken Wamp_<>c__DisplayClass32_0::ct
	CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  ___ct_0;
	// Wamp Wamp_<>c__DisplayClass32_0::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_1;

public:
	inline static int32_t get_offset_of_ct_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63, ___ct_0)); }
	inline CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  get_ct_0() const { return ___ct_0; }
	inline CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB * get_address_of_ct_0() { return &___ct_0; }
	inline void set_ct_0(CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  value)
	{
		___ct_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___ct_0))->___m_source_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63, ___U3CU3E4__this_1)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_1() const { return ___U3CU3E4__this_1; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_1() { return &___U3CU3E4__this_1; }
	inline void set_U3CU3E4__this_1(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_1), (void*)value);
	}
};


// Wamp_Messages
struct  Messages_tD25B555D7E0152EFD72FB82E6E3843CCCDA276B3 
{
public:
	// System.Int32 Wamp_Messages::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Messages_tD25B555D7E0152EFD72FB82E6E3843CCCDA276B3, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// WaqlArgs
struct  WaqlArgs_t5604E26ED22F0E7787E1D7B4CF81594F2E72FEFE  : public Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D
{
public:
	// System.String WaqlArgs::waql
	String_t* ___waql_0;

public:
	inline static int32_t get_offset_of_waql_0() { return static_cast<int32_t>(offsetof(WaqlArgs_t5604E26ED22F0E7787E1D7B4CF81594F2E72FEFE, ___waql_0)); }
	inline String_t* get_waql_0() const { return ___waql_0; }
	inline String_t** get_address_of_waql_0() { return &___waql_0; }
	inline void set_waql_0(String_t* value)
	{
		___waql_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___waql_0), (void*)value);
	}
};


// WwiseObjectType
struct  WwiseObjectType_t44E6AEBBAC5EB4F06796CC09EE0388208EF9D216 
{
public:
	// System.Int32 WwiseObjectType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WwiseObjectType_t44E6AEBBAC5EB4F06796CC09EE0388208EF9D216, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkWaapiClient_<Call>d__8
struct  U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 
{
public:
	// System.Int32 AkWaapiClient_<Call>d__8::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String> AkWaapiClient_<Call>d__8::<>t__builder
	AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  ___U3CU3Et__builder_1;
	// AkWaapiClient AkWaapiClient_<Call>d__8::<>4__this
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * ___U3CU3E4__this_2;
	// System.String AkWaapiClient_<Call>d__8::args
	String_t* ___args_3;
	// System.String AkWaapiClient_<Call>d__8::options
	String_t* ___options_4;
	// System.String AkWaapiClient_<Call>d__8::uri
	String_t* ___uri_5;
	// System.Int32 AkWaapiClient_<Call>d__8::timeout
	int32_t ___timeout_6;
	// System.Runtime.CompilerServices.TaskAwaiter`1<System.String> AkWaapiClient_<Call>d__8::<>u__1
	TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214  ___U3CU3Eu__1_7;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Et__builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31, ___U3CU3E4__this_2)); }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_args_3() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31, ___args_3)); }
	inline String_t* get_args_3() const { return ___args_3; }
	inline String_t** get_address_of_args_3() { return &___args_3; }
	inline void set_args_3(String_t* value)
	{
		___args_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___args_3), (void*)value);
	}

	inline static int32_t get_offset_of_options_4() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31, ___options_4)); }
	inline String_t* get_options_4() const { return ___options_4; }
	inline String_t** get_address_of_options_4() { return &___options_4; }
	inline void set_options_4(String_t* value)
	{
		___options_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___options_4), (void*)value);
	}

	inline static int32_t get_offset_of_uri_5() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31, ___uri_5)); }
	inline String_t* get_uri_5() const { return ___uri_5; }
	inline String_t** get_address_of_uri_5() { return &___uri_5; }
	inline void set_uri_5(String_t* value)
	{
		___uri_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___uri_5), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_6() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31, ___timeout_6)); }
	inline int32_t get_timeout_6() const { return ___timeout_6; }
	inline int32_t* get_address_of_timeout_6() { return &___timeout_6; }
	inline void set_timeout_6(int32_t value)
	{
		___timeout_6 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_7() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31, ___U3CU3Eu__1_7)); }
	inline TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214  get_U3CU3Eu__1_7() const { return ___U3CU3Eu__1_7; }
	inline TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 * get_address_of_U3CU3Eu__1_7() { return &___U3CU3Eu__1_7; }
	inline void set_U3CU3Eu__1_7(TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214  value)
	{
		___U3CU3Eu__1_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_7))->___m_task_0), (void*)NULL);
	}
};


// AkWaapiClient_<Subscribe>d__9
struct  U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C 
{
public:
	// System.Int32 AkWaapiClient_<Subscribe>d__9::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32> AkWaapiClient_<Subscribe>d__9::<>t__builder
	AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  ___U3CU3Et__builder_1;
	// AkWaapiClient AkWaapiClient_<Subscribe>d__9::<>4__this
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * ___U3CU3E4__this_2;
	// System.String AkWaapiClient_<Subscribe>d__9::options
	String_t* ___options_3;
	// System.String AkWaapiClient_<Subscribe>d__9::topic
	String_t* ___topic_4;
	// Wamp_PublishHandler AkWaapiClient_<Subscribe>d__9::publishHandler
	PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * ___publishHandler_5;
	// System.Int32 AkWaapiClient_<Subscribe>d__9::timeout
	int32_t ___timeout_6;
	// System.Runtime.CompilerServices.TaskAwaiter`1<System.UInt32> AkWaapiClient_<Subscribe>d__9::<>u__1
	TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  ___U3CU3Eu__1_7;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Et__builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C, ___U3CU3E4__this_2)); }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_options_3() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C, ___options_3)); }
	inline String_t* get_options_3() const { return ___options_3; }
	inline String_t** get_address_of_options_3() { return &___options_3; }
	inline void set_options_3(String_t* value)
	{
		___options_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___options_3), (void*)value);
	}

	inline static int32_t get_offset_of_topic_4() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C, ___topic_4)); }
	inline String_t* get_topic_4() const { return ___topic_4; }
	inline String_t** get_address_of_topic_4() { return &___topic_4; }
	inline void set_topic_4(String_t* value)
	{
		___topic_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___topic_4), (void*)value);
	}

	inline static int32_t get_offset_of_publishHandler_5() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C, ___publishHandler_5)); }
	inline PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * get_publishHandler_5() const { return ___publishHandler_5; }
	inline PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 ** get_address_of_publishHandler_5() { return &___publishHandler_5; }
	inline void set_publishHandler_5(PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * value)
	{
		___publishHandler_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___publishHandler_5), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_6() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C, ___timeout_6)); }
	inline int32_t get_timeout_6() const { return ___timeout_6; }
	inline int32_t* get_address_of_timeout_6() { return &___timeout_6; }
	inline void set_timeout_6(int32_t value)
	{
		___timeout_6 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_7() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C, ___U3CU3Eu__1_7)); }
	inline TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  get_U3CU3Eu__1_7() const { return ___U3CU3Eu__1_7; }
	inline TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 * get_address_of_U3CU3Eu__1_7() { return &___U3CU3Eu__1_7; }
	inline void set_U3CU3Eu__1_7(TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  value)
	{
		___U3CU3Eu__1_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_7))->___m_task_0), (void*)NULL);
	}
};


// System.AggregateException
struct  AggregateException_t9217B9E89DF820D5632411F2BD92F444B17BD60E  : public Exception_t
{
public:
	// System.Collections.ObjectModel.ReadOnlyCollection`1<System.Exception> System.AggregateException::m_innerExceptions
	ReadOnlyCollection_1_t6D5AC6FC0BF91A16C9E9159F577DEDA4DD3414C8 * ___m_innerExceptions_17;

public:
	inline static int32_t get_offset_of_m_innerExceptions_17() { return static_cast<int32_t>(offsetof(AggregateException_t9217B9E89DF820D5632411F2BD92F444B17BD60E, ___m_innerExceptions_17)); }
	inline ReadOnlyCollection_1_t6D5AC6FC0BF91A16C9E9159F577DEDA4DD3414C8 * get_m_innerExceptions_17() const { return ___m_innerExceptions_17; }
	inline ReadOnlyCollection_1_t6D5AC6FC0BF91A16C9E9159F577DEDA4DD3414C8 ** get_address_of_m_innerExceptions_17() { return &___m_innerExceptions_17; }
	inline void set_m_innerExceptions_17(ReadOnlyCollection_1_t6D5AC6FC0BF91A16C9E9159F577DEDA4DD3414C8 * value)
	{
		___m_innerExceptions_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_innerExceptions_17), (void*)value);
	}
};


// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___delegates_11), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};

// System.Nullable`1<System.Net.WebSockets.WebSocketCloseStatus>
struct  Nullable_1_tD09391AA7DA79953C91A6F93F3E19269CE3D7D57 
{
public:
	// T System.Nullable`1::value
	int32_t ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_tD09391AA7DA79953C91A6F93F3E19269CE3D7D57, ___value_0)); }
	inline int32_t get_value_0() const { return ___value_0; }
	inline int32_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(int32_t value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_tD09391AA7DA79953C91A6F93F3E19269CE3D7D57, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};


// System.Runtime.CompilerServices.AsyncTaskMethodBuilder
struct  AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 
{
public:
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Threading.Tasks.VoidTaskResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder::m_builder
	AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9  ___m_builder_1;

public:
	inline static int32_t get_offset_of_m_builder_1() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487, ___m_builder_1)); }
	inline AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9  get_m_builder_1() const { return ___m_builder_1; }
	inline AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9 * get_address_of_m_builder_1() { return &___m_builder_1; }
	inline void set_m_builder_1(AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9  value)
	{
		___m_builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}
};

struct AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_StaticFields
{
public:
	// System.Threading.Tasks.Task`1<System.Threading.Tasks.VoidTaskResult> System.Runtime.CompilerServices.AsyncTaskMethodBuilder::s_cachedCompleted
	Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 * ___s_cachedCompleted_0;

public:
	inline static int32_t get_offset_of_s_cachedCompleted_0() { return static_cast<int32_t>(offsetof(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_StaticFields, ___s_cachedCompleted_0)); }
	inline Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 * get_s_cachedCompleted_0() const { return ___s_cachedCompleted_0; }
	inline Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 ** get_address_of_s_cachedCompleted_0() { return &___s_cachedCompleted_0; }
	inline void set_s_cachedCompleted_0(Task_1_t1359D75350E9D976BFA28AD96E417450DE277673 * value)
	{
		___s_cachedCompleted_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_cachedCompleted_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Runtime.CompilerServices.AsyncTaskMethodBuilder
struct AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_marshaled_pinvoke
{
	AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9  ___m_builder_1;
};
// Native definition for COM marshalling of System.Runtime.CompilerServices.AsyncTaskMethodBuilder
struct AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_marshaled_com
{
	AsyncTaskMethodBuilder_1_t66ED1808B26B8081A2804D6A750D13386E360BD9  ___m_builder_1;
};

// System.SystemException
struct  SystemException_t5380468142AA850BE4A341D7AF3EAB9C78746782  : public Exception_t
{
public:

public:
};


// System.Threading.Tasks.TaskFactory
struct  TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155  : public RuntimeObject
{
public:
	// System.Threading.CancellationToken System.Threading.Tasks.TaskFactory::m_defaultCancellationToken
	CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  ___m_defaultCancellationToken_0;
	// System.Threading.Tasks.TaskScheduler System.Threading.Tasks.TaskFactory::m_defaultScheduler
	TaskScheduler_t966F2798F198FA90A0DA8EFC92BAC08297793114 * ___m_defaultScheduler_1;
	// System.Threading.Tasks.TaskCreationOptions System.Threading.Tasks.TaskFactory::m_defaultCreationOptions
	int32_t ___m_defaultCreationOptions_2;
	// System.Threading.Tasks.TaskContinuationOptions System.Threading.Tasks.TaskFactory::m_defaultContinuationOptions
	int32_t ___m_defaultContinuationOptions_3;

public:
	inline static int32_t get_offset_of_m_defaultCancellationToken_0() { return static_cast<int32_t>(offsetof(TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155, ___m_defaultCancellationToken_0)); }
	inline CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  get_m_defaultCancellationToken_0() const { return ___m_defaultCancellationToken_0; }
	inline CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB * get_address_of_m_defaultCancellationToken_0() { return &___m_defaultCancellationToken_0; }
	inline void set_m_defaultCancellationToken_0(CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  value)
	{
		___m_defaultCancellationToken_0 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_defaultCancellationToken_0))->___m_source_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_m_defaultScheduler_1() { return static_cast<int32_t>(offsetof(TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155, ___m_defaultScheduler_1)); }
	inline TaskScheduler_t966F2798F198FA90A0DA8EFC92BAC08297793114 * get_m_defaultScheduler_1() const { return ___m_defaultScheduler_1; }
	inline TaskScheduler_t966F2798F198FA90A0DA8EFC92BAC08297793114 ** get_address_of_m_defaultScheduler_1() { return &___m_defaultScheduler_1; }
	inline void set_m_defaultScheduler_1(TaskScheduler_t966F2798F198FA90A0DA8EFC92BAC08297793114 * value)
	{
		___m_defaultScheduler_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_defaultScheduler_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_defaultCreationOptions_2() { return static_cast<int32_t>(offsetof(TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155, ___m_defaultCreationOptions_2)); }
	inline int32_t get_m_defaultCreationOptions_2() const { return ___m_defaultCreationOptions_2; }
	inline int32_t* get_address_of_m_defaultCreationOptions_2() { return &___m_defaultCreationOptions_2; }
	inline void set_m_defaultCreationOptions_2(int32_t value)
	{
		___m_defaultCreationOptions_2 = value;
	}

	inline static int32_t get_offset_of_m_defaultContinuationOptions_3() { return static_cast<int32_t>(offsetof(TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155, ___m_defaultContinuationOptions_3)); }
	inline int32_t get_m_defaultContinuationOptions_3() const { return ___m_defaultContinuationOptions_3; }
	inline int32_t* get_address_of_m_defaultContinuationOptions_3() { return &___m_defaultContinuationOptions_3; }
	inline void set_m_defaultContinuationOptions_3(int32_t value)
	{
		___m_defaultContinuationOptions_3 = value;
	}
};


// System.Threading.Tasks.Task`1<System.Net.WebSockets.WebSocketReceiveResult>
struct  Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F  : public Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2
{
public:
	// TResult System.Threading.Tasks.Task`1::m_result
	WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * ___m_result_22;

public:
	inline static int32_t get_offset_of_m_result_22() { return static_cast<int32_t>(offsetof(Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F, ___m_result_22)); }
	inline WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * get_m_result_22() const { return ___m_result_22; }
	inline WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 ** get_address_of_m_result_22() { return &___m_result_22; }
	inline void set_m_result_22(WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * value)
	{
		___m_result_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_result_22), (void*)value);
	}
};

struct Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F_StaticFields
{
public:
	// System.Threading.Tasks.TaskFactory`1<TResult> System.Threading.Tasks.Task`1::s_Factory
	TaskFactory_1_t3B55C10C95A5E61DE2966CF61F2BD32F5C1525F6 * ___s_Factory_23;
	// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<TResult>> System.Threading.Tasks.Task`1::TaskWhenAnyCast
	Func_2_tB79A1A7EFDEF01527B20591B4E1AE44882105895 * ___TaskWhenAnyCast_24;

public:
	inline static int32_t get_offset_of_s_Factory_23() { return static_cast<int32_t>(offsetof(Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F_StaticFields, ___s_Factory_23)); }
	inline TaskFactory_1_t3B55C10C95A5E61DE2966CF61F2BD32F5C1525F6 * get_s_Factory_23() const { return ___s_Factory_23; }
	inline TaskFactory_1_t3B55C10C95A5E61DE2966CF61F2BD32F5C1525F6 ** get_address_of_s_Factory_23() { return &___s_Factory_23; }
	inline void set_s_Factory_23(TaskFactory_1_t3B55C10C95A5E61DE2966CF61F2BD32F5C1525F6 * value)
	{
		___s_Factory_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Factory_23), (void*)value);
	}

	inline static int32_t get_offset_of_TaskWhenAnyCast_24() { return static_cast<int32_t>(offsetof(Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F_StaticFields, ___TaskWhenAnyCast_24)); }
	inline Func_2_tB79A1A7EFDEF01527B20591B4E1AE44882105895 * get_TaskWhenAnyCast_24() const { return ___TaskWhenAnyCast_24; }
	inline Func_2_tB79A1A7EFDEF01527B20591B4E1AE44882105895 ** get_address_of_TaskWhenAnyCast_24() { return &___TaskWhenAnyCast_24; }
	inline void set_TaskWhenAnyCast_24(Func_2_tB79A1A7EFDEF01527B20591B4E1AE44882105895 * value)
	{
		___TaskWhenAnyCast_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TaskWhenAnyCast_24), (void*)value);
	}
};


// System.Threading.Tasks.Task`1<System.Object>
struct  Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09  : public Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2
{
public:
	// TResult System.Threading.Tasks.Task`1::m_result
	RuntimeObject * ___m_result_22;

public:
	inline static int32_t get_offset_of_m_result_22() { return static_cast<int32_t>(offsetof(Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09, ___m_result_22)); }
	inline RuntimeObject * get_m_result_22() const { return ___m_result_22; }
	inline RuntimeObject ** get_address_of_m_result_22() { return &___m_result_22; }
	inline void set_m_result_22(RuntimeObject * value)
	{
		___m_result_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_result_22), (void*)value);
	}
};

struct Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09_StaticFields
{
public:
	// System.Threading.Tasks.TaskFactory`1<TResult> System.Threading.Tasks.Task`1::s_Factory
	TaskFactory_1_tA50D9207CAE2C505277DD5F03CBE64700177257C * ___s_Factory_23;
	// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<TResult>> System.Threading.Tasks.Task`1::TaskWhenAnyCast
	Func_2_tDAE4310E42C13AE378CDF0371BD31D6BF4E61EBD * ___TaskWhenAnyCast_24;

public:
	inline static int32_t get_offset_of_s_Factory_23() { return static_cast<int32_t>(offsetof(Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09_StaticFields, ___s_Factory_23)); }
	inline TaskFactory_1_tA50D9207CAE2C505277DD5F03CBE64700177257C * get_s_Factory_23() const { return ___s_Factory_23; }
	inline TaskFactory_1_tA50D9207CAE2C505277DD5F03CBE64700177257C ** get_address_of_s_Factory_23() { return &___s_Factory_23; }
	inline void set_s_Factory_23(TaskFactory_1_tA50D9207CAE2C505277DD5F03CBE64700177257C * value)
	{
		___s_Factory_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Factory_23), (void*)value);
	}

	inline static int32_t get_offset_of_TaskWhenAnyCast_24() { return static_cast<int32_t>(offsetof(Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09_StaticFields, ___TaskWhenAnyCast_24)); }
	inline Func_2_tDAE4310E42C13AE378CDF0371BD31D6BF4E61EBD * get_TaskWhenAnyCast_24() const { return ___TaskWhenAnyCast_24; }
	inline Func_2_tDAE4310E42C13AE378CDF0371BD31D6BF4E61EBD ** get_address_of_TaskWhenAnyCast_24() { return &___TaskWhenAnyCast_24; }
	inline void set_TaskWhenAnyCast_24(Func_2_tDAE4310E42C13AE378CDF0371BD31D6BF4E61EBD * value)
	{
		___TaskWhenAnyCast_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TaskWhenAnyCast_24), (void*)value);
	}
};


// System.Threading.Tasks.Task`1<System.String>
struct  Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286  : public Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2
{
public:
	// TResult System.Threading.Tasks.Task`1::m_result
	String_t* ___m_result_22;

public:
	inline static int32_t get_offset_of_m_result_22() { return static_cast<int32_t>(offsetof(Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286, ___m_result_22)); }
	inline String_t* get_m_result_22() const { return ___m_result_22; }
	inline String_t** get_address_of_m_result_22() { return &___m_result_22; }
	inline void set_m_result_22(String_t* value)
	{
		___m_result_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_result_22), (void*)value);
	}
};

struct Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286_StaticFields
{
public:
	// System.Threading.Tasks.TaskFactory`1<TResult> System.Threading.Tasks.Task`1::s_Factory
	TaskFactory_1_tC464EE87A6CB7838666431AFB8761D134A690E8D * ___s_Factory_23;
	// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<TResult>> System.Threading.Tasks.Task`1::TaskWhenAnyCast
	Func_2_tD5DD82F807AA57BEB7EC482428FCFADD3E3EDF93 * ___TaskWhenAnyCast_24;

public:
	inline static int32_t get_offset_of_s_Factory_23() { return static_cast<int32_t>(offsetof(Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286_StaticFields, ___s_Factory_23)); }
	inline TaskFactory_1_tC464EE87A6CB7838666431AFB8761D134A690E8D * get_s_Factory_23() const { return ___s_Factory_23; }
	inline TaskFactory_1_tC464EE87A6CB7838666431AFB8761D134A690E8D ** get_address_of_s_Factory_23() { return &___s_Factory_23; }
	inline void set_s_Factory_23(TaskFactory_1_tC464EE87A6CB7838666431AFB8761D134A690E8D * value)
	{
		___s_Factory_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Factory_23), (void*)value);
	}

	inline static int32_t get_offset_of_TaskWhenAnyCast_24() { return static_cast<int32_t>(offsetof(Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286_StaticFields, ___TaskWhenAnyCast_24)); }
	inline Func_2_tD5DD82F807AA57BEB7EC482428FCFADD3E3EDF93 * get_TaskWhenAnyCast_24() const { return ___TaskWhenAnyCast_24; }
	inline Func_2_tD5DD82F807AA57BEB7EC482428FCFADD3E3EDF93 ** get_address_of_TaskWhenAnyCast_24() { return &___TaskWhenAnyCast_24; }
	inline void set_TaskWhenAnyCast_24(Func_2_tD5DD82F807AA57BEB7EC482428FCFADD3E3EDF93 * value)
	{
		___TaskWhenAnyCast_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TaskWhenAnyCast_24), (void*)value);
	}
};


// System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>
struct  Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138  : public Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2
{
public:
	// TResult System.Threading.Tasks.Task`1::m_result
	Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * ___m_result_22;

public:
	inline static int32_t get_offset_of_m_result_22() { return static_cast<int32_t>(offsetof(Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138, ___m_result_22)); }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * get_m_result_22() const { return ___m_result_22; }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 ** get_address_of_m_result_22() { return &___m_result_22; }
	inline void set_m_result_22(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * value)
	{
		___m_result_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_result_22), (void*)value);
	}
};

struct Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138_StaticFields
{
public:
	// System.Threading.Tasks.TaskFactory`1<TResult> System.Threading.Tasks.Task`1::s_Factory
	TaskFactory_1_t58FE324C5DC18B5ED9A0E49CA8543DEEA65B4462 * ___s_Factory_23;
	// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<TResult>> System.Threading.Tasks.Task`1::TaskWhenAnyCast
	Func_2_t9183BE7C6FB5EAED091785FC3E1D3D41DB3497F7 * ___TaskWhenAnyCast_24;

public:
	inline static int32_t get_offset_of_s_Factory_23() { return static_cast<int32_t>(offsetof(Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138_StaticFields, ___s_Factory_23)); }
	inline TaskFactory_1_t58FE324C5DC18B5ED9A0E49CA8543DEEA65B4462 * get_s_Factory_23() const { return ___s_Factory_23; }
	inline TaskFactory_1_t58FE324C5DC18B5ED9A0E49CA8543DEEA65B4462 ** get_address_of_s_Factory_23() { return &___s_Factory_23; }
	inline void set_s_Factory_23(TaskFactory_1_t58FE324C5DC18B5ED9A0E49CA8543DEEA65B4462 * value)
	{
		___s_Factory_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Factory_23), (void*)value);
	}

	inline static int32_t get_offset_of_TaskWhenAnyCast_24() { return static_cast<int32_t>(offsetof(Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138_StaticFields, ___TaskWhenAnyCast_24)); }
	inline Func_2_t9183BE7C6FB5EAED091785FC3E1D3D41DB3497F7 * get_TaskWhenAnyCast_24() const { return ___TaskWhenAnyCast_24; }
	inline Func_2_t9183BE7C6FB5EAED091785FC3E1D3D41DB3497F7 ** get_address_of_TaskWhenAnyCast_24() { return &___TaskWhenAnyCast_24; }
	inline void set_TaskWhenAnyCast_24(Func_2_t9183BE7C6FB5EAED091785FC3E1D3D41DB3497F7 * value)
	{
		___TaskWhenAnyCast_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TaskWhenAnyCast_24), (void*)value);
	}
};


// System.Threading.Tasks.Task`1<System.UInt32>
struct  Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F  : public Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2
{
public:
	// TResult System.Threading.Tasks.Task`1::m_result
	uint32_t ___m_result_22;

public:
	inline static int32_t get_offset_of_m_result_22() { return static_cast<int32_t>(offsetof(Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F, ___m_result_22)); }
	inline uint32_t get_m_result_22() const { return ___m_result_22; }
	inline uint32_t* get_address_of_m_result_22() { return &___m_result_22; }
	inline void set_m_result_22(uint32_t value)
	{
		___m_result_22 = value;
	}
};

struct Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F_StaticFields
{
public:
	// System.Threading.Tasks.TaskFactory`1<TResult> System.Threading.Tasks.Task`1::s_Factory
	TaskFactory_1_t4B1CB177FC575AD49A8B6BDA308F06C7075F366B * ___s_Factory_23;
	// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<TResult>> System.Threading.Tasks.Task`1::TaskWhenAnyCast
	Func_2_t2DE17BAAB7C8A395FFA1D553866D96ABC5F46C97 * ___TaskWhenAnyCast_24;

public:
	inline static int32_t get_offset_of_s_Factory_23() { return static_cast<int32_t>(offsetof(Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F_StaticFields, ___s_Factory_23)); }
	inline TaskFactory_1_t4B1CB177FC575AD49A8B6BDA308F06C7075F366B * get_s_Factory_23() const { return ___s_Factory_23; }
	inline TaskFactory_1_t4B1CB177FC575AD49A8B6BDA308F06C7075F366B ** get_address_of_s_Factory_23() { return &___s_Factory_23; }
	inline void set_s_Factory_23(TaskFactory_1_t4B1CB177FC575AD49A8B6BDA308F06C7075F366B * value)
	{
		___s_Factory_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Factory_23), (void*)value);
	}

	inline static int32_t get_offset_of_TaskWhenAnyCast_24() { return static_cast<int32_t>(offsetof(Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F_StaticFields, ___TaskWhenAnyCast_24)); }
	inline Func_2_t2DE17BAAB7C8A395FFA1D553866D96ABC5F46C97 * get_TaskWhenAnyCast_24() const { return ___TaskWhenAnyCast_24; }
	inline Func_2_t2DE17BAAB7C8A395FFA1D553866D96ABC5F46C97 ** get_address_of_TaskWhenAnyCast_24() { return &___TaskWhenAnyCast_24; }
	inline void set_TaskWhenAnyCast_24(Func_2_t2DE17BAAB7C8A395FFA1D553866D96ABC5F46C97 * value)
	{
		___TaskWhenAnyCast_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TaskWhenAnyCast_24), (void*)value);
	}
};


// System.Threading.Tasks.Task`1<Wamp_Response>
struct  Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA  : public Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2
{
public:
	// TResult System.Threading.Tasks.Task`1::m_result
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * ___m_result_22;

public:
	inline static int32_t get_offset_of_m_result_22() { return static_cast<int32_t>(offsetof(Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA, ___m_result_22)); }
	inline Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * get_m_result_22() const { return ___m_result_22; }
	inline Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 ** get_address_of_m_result_22() { return &___m_result_22; }
	inline void set_m_result_22(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * value)
	{
		___m_result_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_result_22), (void*)value);
	}
};

struct Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA_StaticFields
{
public:
	// System.Threading.Tasks.TaskFactory`1<TResult> System.Threading.Tasks.Task`1::s_Factory
	TaskFactory_1_tDE72F158A631009A5BFCAA2A5B363BE9A3E98F7E * ___s_Factory_23;
	// System.Func`2<System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>,System.Threading.Tasks.Task`1<TResult>> System.Threading.Tasks.Task`1::TaskWhenAnyCast
	Func_2_t5107249833618B5A8333140C3ED98F63AEE60F82 * ___TaskWhenAnyCast_24;

public:
	inline static int32_t get_offset_of_s_Factory_23() { return static_cast<int32_t>(offsetof(Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA_StaticFields, ___s_Factory_23)); }
	inline TaskFactory_1_tDE72F158A631009A5BFCAA2A5B363BE9A3E98F7E * get_s_Factory_23() const { return ___s_Factory_23; }
	inline TaskFactory_1_tDE72F158A631009A5BFCAA2A5B363BE9A3E98F7E ** get_address_of_s_Factory_23() { return &___s_Factory_23; }
	inline void set_s_Factory_23(TaskFactory_1_tDE72F158A631009A5BFCAA2A5B363BE9A3E98F7E * value)
	{
		___s_Factory_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_Factory_23), (void*)value);
	}

	inline static int32_t get_offset_of_TaskWhenAnyCast_24() { return static_cast<int32_t>(offsetof(Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA_StaticFields, ___TaskWhenAnyCast_24)); }
	inline Func_2_t5107249833618B5A8333140C3ED98F63AEE60F82 * get_TaskWhenAnyCast_24() const { return ___TaskWhenAnyCast_24; }
	inline Func_2_t5107249833618B5A8333140C3ED98F63AEE60F82 ** get_address_of_TaskWhenAnyCast_24() { return &___TaskWhenAnyCast_24; }
	inline void set_TaskWhenAnyCast_24(Func_2_t5107249833618B5A8333140C3ED98F63AEE60F82 * value)
	{
		___TaskWhenAnyCast_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TaskWhenAnyCast_24), (void*)value);
	}
};


// System.Type
struct  Type_t  : public MemberInfo_t
{
public:
	// System.RuntimeTypeHandle System.Type::_impl
	RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D  ____impl_9;

public:
	inline static int32_t get_offset_of__impl_9() { return static_cast<int32_t>(offsetof(Type_t, ____impl_9)); }
	inline RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D  get__impl_9() const { return ____impl_9; }
	inline RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D * get_address_of__impl_9() { return &____impl_9; }
	inline void set__impl_9(RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D  value)
	{
		____impl_9 = value;
	}
};

struct Type_t_StaticFields
{
public:
	// System.Reflection.MemberFilter System.Type::FilterAttribute
	MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * ___FilterAttribute_0;
	// System.Reflection.MemberFilter System.Type::FilterName
	MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * ___FilterName_1;
	// System.Reflection.MemberFilter System.Type::FilterNameIgnoreCase
	MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * ___FilterNameIgnoreCase_2;
	// System.Object System.Type::Missing
	RuntimeObject * ___Missing_3;
	// System.Char System.Type::Delimiter
	Il2CppChar ___Delimiter_4;
	// System.Type[] System.Type::EmptyTypes
	TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F* ___EmptyTypes_5;
	// System.Reflection.Binder System.Type::defaultBinder
	Binder_t4D5CB06963501D32847C057B57157D6DC49CA759 * ___defaultBinder_6;

public:
	inline static int32_t get_offset_of_FilterAttribute_0() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterAttribute_0)); }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * get_FilterAttribute_0() const { return ___FilterAttribute_0; }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 ** get_address_of_FilterAttribute_0() { return &___FilterAttribute_0; }
	inline void set_FilterAttribute_0(MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * value)
	{
		___FilterAttribute_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FilterAttribute_0), (void*)value);
	}

	inline static int32_t get_offset_of_FilterName_1() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterName_1)); }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * get_FilterName_1() const { return ___FilterName_1; }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 ** get_address_of_FilterName_1() { return &___FilterName_1; }
	inline void set_FilterName_1(MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * value)
	{
		___FilterName_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FilterName_1), (void*)value);
	}

	inline static int32_t get_offset_of_FilterNameIgnoreCase_2() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterNameIgnoreCase_2)); }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * get_FilterNameIgnoreCase_2() const { return ___FilterNameIgnoreCase_2; }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 ** get_address_of_FilterNameIgnoreCase_2() { return &___FilterNameIgnoreCase_2; }
	inline void set_FilterNameIgnoreCase_2(MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * value)
	{
		___FilterNameIgnoreCase_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FilterNameIgnoreCase_2), (void*)value);
	}

	inline static int32_t get_offset_of_Missing_3() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___Missing_3)); }
	inline RuntimeObject * get_Missing_3() const { return ___Missing_3; }
	inline RuntimeObject ** get_address_of_Missing_3() { return &___Missing_3; }
	inline void set_Missing_3(RuntimeObject * value)
	{
		___Missing_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Missing_3), (void*)value);
	}

	inline static int32_t get_offset_of_Delimiter_4() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___Delimiter_4)); }
	inline Il2CppChar get_Delimiter_4() const { return ___Delimiter_4; }
	inline Il2CppChar* get_address_of_Delimiter_4() { return &___Delimiter_4; }
	inline void set_Delimiter_4(Il2CppChar value)
	{
		___Delimiter_4 = value;
	}

	inline static int32_t get_offset_of_EmptyTypes_5() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___EmptyTypes_5)); }
	inline TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F* get_EmptyTypes_5() const { return ___EmptyTypes_5; }
	inline TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F** get_address_of_EmptyTypes_5() { return &___EmptyTypes_5; }
	inline void set_EmptyTypes_5(TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F* value)
	{
		___EmptyTypes_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___EmptyTypes_5), (void*)value);
	}

	inline static int32_t get_offset_of_defaultBinder_6() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___defaultBinder_6)); }
	inline Binder_t4D5CB06963501D32847C057B57157D6DC49CA759 * get_defaultBinder_6() const { return ___defaultBinder_6; }
	inline Binder_t4D5CB06963501D32847C057B57157D6DC49CA759 ** get_address_of_defaultBinder_6() { return &___defaultBinder_6; }
	inline void set_defaultBinder_6(Binder_t4D5CB06963501D32847C057B57157D6DC49CA759 * value)
	{
		___defaultBinder_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___defaultBinder_6), (void*)value);
	}
};


// System.Uri
struct  Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E  : public RuntimeObject
{
public:
	// System.String System.Uri::m_String
	String_t* ___m_String_16;
	// System.String System.Uri::m_originalUnicodeString
	String_t* ___m_originalUnicodeString_17;
	// System.UriParser System.Uri::m_Syntax
	UriParser_t07C77D673CCE8D2DA253B8A7ACCB010147F1A4AC * ___m_Syntax_18;
	// System.String System.Uri::m_DnsSafeHost
	String_t* ___m_DnsSafeHost_19;
	// System.Uri_Flags System.Uri::m_Flags
	uint64_t ___m_Flags_20;
	// System.Uri_UriInfo System.Uri::m_Info
	UriInfo_t9FCC6BD4EC1EA14D75209E6A35417057BF6EDC5E * ___m_Info_21;
	// System.Boolean System.Uri::m_iriParsing
	bool ___m_iriParsing_22;

public:
	inline static int32_t get_offset_of_m_String_16() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E, ___m_String_16)); }
	inline String_t* get_m_String_16() const { return ___m_String_16; }
	inline String_t** get_address_of_m_String_16() { return &___m_String_16; }
	inline void set_m_String_16(String_t* value)
	{
		___m_String_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_String_16), (void*)value);
	}

	inline static int32_t get_offset_of_m_originalUnicodeString_17() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E, ___m_originalUnicodeString_17)); }
	inline String_t* get_m_originalUnicodeString_17() const { return ___m_originalUnicodeString_17; }
	inline String_t** get_address_of_m_originalUnicodeString_17() { return &___m_originalUnicodeString_17; }
	inline void set_m_originalUnicodeString_17(String_t* value)
	{
		___m_originalUnicodeString_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_originalUnicodeString_17), (void*)value);
	}

	inline static int32_t get_offset_of_m_Syntax_18() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E, ___m_Syntax_18)); }
	inline UriParser_t07C77D673CCE8D2DA253B8A7ACCB010147F1A4AC * get_m_Syntax_18() const { return ___m_Syntax_18; }
	inline UriParser_t07C77D673CCE8D2DA253B8A7ACCB010147F1A4AC ** get_address_of_m_Syntax_18() { return &___m_Syntax_18; }
	inline void set_m_Syntax_18(UriParser_t07C77D673CCE8D2DA253B8A7ACCB010147F1A4AC * value)
	{
		___m_Syntax_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Syntax_18), (void*)value);
	}

	inline static int32_t get_offset_of_m_DnsSafeHost_19() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E, ___m_DnsSafeHost_19)); }
	inline String_t* get_m_DnsSafeHost_19() const { return ___m_DnsSafeHost_19; }
	inline String_t** get_address_of_m_DnsSafeHost_19() { return &___m_DnsSafeHost_19; }
	inline void set_m_DnsSafeHost_19(String_t* value)
	{
		___m_DnsSafeHost_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DnsSafeHost_19), (void*)value);
	}

	inline static int32_t get_offset_of_m_Flags_20() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E, ___m_Flags_20)); }
	inline uint64_t get_m_Flags_20() const { return ___m_Flags_20; }
	inline uint64_t* get_address_of_m_Flags_20() { return &___m_Flags_20; }
	inline void set_m_Flags_20(uint64_t value)
	{
		___m_Flags_20 = value;
	}

	inline static int32_t get_offset_of_m_Info_21() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E, ___m_Info_21)); }
	inline UriInfo_t9FCC6BD4EC1EA14D75209E6A35417057BF6EDC5E * get_m_Info_21() const { return ___m_Info_21; }
	inline UriInfo_t9FCC6BD4EC1EA14D75209E6A35417057BF6EDC5E ** get_address_of_m_Info_21() { return &___m_Info_21; }
	inline void set_m_Info_21(UriInfo_t9FCC6BD4EC1EA14D75209E6A35417057BF6EDC5E * value)
	{
		___m_Info_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Info_21), (void*)value);
	}

	inline static int32_t get_offset_of_m_iriParsing_22() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E, ___m_iriParsing_22)); }
	inline bool get_m_iriParsing_22() const { return ___m_iriParsing_22; }
	inline bool* get_address_of_m_iriParsing_22() { return &___m_iriParsing_22; }
	inline void set_m_iriParsing_22(bool value)
	{
		___m_iriParsing_22 = value;
	}
};

struct Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields
{
public:
	// System.String System.Uri::UriSchemeFile
	String_t* ___UriSchemeFile_0;
	// System.String System.Uri::UriSchemeFtp
	String_t* ___UriSchemeFtp_1;
	// System.String System.Uri::UriSchemeGopher
	String_t* ___UriSchemeGopher_2;
	// System.String System.Uri::UriSchemeHttp
	String_t* ___UriSchemeHttp_3;
	// System.String System.Uri::UriSchemeHttps
	String_t* ___UriSchemeHttps_4;
	// System.String System.Uri::UriSchemeWs
	String_t* ___UriSchemeWs_5;
	// System.String System.Uri::UriSchemeWss
	String_t* ___UriSchemeWss_6;
	// System.String System.Uri::UriSchemeMailto
	String_t* ___UriSchemeMailto_7;
	// System.String System.Uri::UriSchemeNews
	String_t* ___UriSchemeNews_8;
	// System.String System.Uri::UriSchemeNntp
	String_t* ___UriSchemeNntp_9;
	// System.String System.Uri::UriSchemeNetTcp
	String_t* ___UriSchemeNetTcp_10;
	// System.String System.Uri::UriSchemeNetPipe
	String_t* ___UriSchemeNetPipe_11;
	// System.String System.Uri::SchemeDelimiter
	String_t* ___SchemeDelimiter_12;
	// System.Boolean modreq(System.Runtime.CompilerServices.IsVolatile) System.Uri::s_ConfigInitialized
	bool ___s_ConfigInitialized_23;
	// System.Boolean modreq(System.Runtime.CompilerServices.IsVolatile) System.Uri::s_ConfigInitializing
	bool ___s_ConfigInitializing_24;
	// System.UriIdnScope modreq(System.Runtime.CompilerServices.IsVolatile) System.Uri::s_IdnScope
	int32_t ___s_IdnScope_25;
	// System.Boolean modreq(System.Runtime.CompilerServices.IsVolatile) System.Uri::s_IriParsing
	bool ___s_IriParsing_26;
	// System.Boolean System.Uri::useDotNetRelativeOrAbsolute
	bool ___useDotNetRelativeOrAbsolute_27;
	// System.Boolean System.Uri::IsWindowsFileSystem
	bool ___IsWindowsFileSystem_29;
	// System.Object System.Uri::s_initLock
	RuntimeObject * ___s_initLock_30;
	// System.Char[] System.Uri::HexLowerChars
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___HexLowerChars_34;
	// System.Char[] System.Uri::_WSchars
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ____WSchars_35;

public:
	inline static int32_t get_offset_of_UriSchemeFile_0() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeFile_0)); }
	inline String_t* get_UriSchemeFile_0() const { return ___UriSchemeFile_0; }
	inline String_t** get_address_of_UriSchemeFile_0() { return &___UriSchemeFile_0; }
	inline void set_UriSchemeFile_0(String_t* value)
	{
		___UriSchemeFile_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeFile_0), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeFtp_1() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeFtp_1)); }
	inline String_t* get_UriSchemeFtp_1() const { return ___UriSchemeFtp_1; }
	inline String_t** get_address_of_UriSchemeFtp_1() { return &___UriSchemeFtp_1; }
	inline void set_UriSchemeFtp_1(String_t* value)
	{
		___UriSchemeFtp_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeFtp_1), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeGopher_2() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeGopher_2)); }
	inline String_t* get_UriSchemeGopher_2() const { return ___UriSchemeGopher_2; }
	inline String_t** get_address_of_UriSchemeGopher_2() { return &___UriSchemeGopher_2; }
	inline void set_UriSchemeGopher_2(String_t* value)
	{
		___UriSchemeGopher_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeGopher_2), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeHttp_3() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeHttp_3)); }
	inline String_t* get_UriSchemeHttp_3() const { return ___UriSchemeHttp_3; }
	inline String_t** get_address_of_UriSchemeHttp_3() { return &___UriSchemeHttp_3; }
	inline void set_UriSchemeHttp_3(String_t* value)
	{
		___UriSchemeHttp_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeHttp_3), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeHttps_4() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeHttps_4)); }
	inline String_t* get_UriSchemeHttps_4() const { return ___UriSchemeHttps_4; }
	inline String_t** get_address_of_UriSchemeHttps_4() { return &___UriSchemeHttps_4; }
	inline void set_UriSchemeHttps_4(String_t* value)
	{
		___UriSchemeHttps_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeHttps_4), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeWs_5() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeWs_5)); }
	inline String_t* get_UriSchemeWs_5() const { return ___UriSchemeWs_5; }
	inline String_t** get_address_of_UriSchemeWs_5() { return &___UriSchemeWs_5; }
	inline void set_UriSchemeWs_5(String_t* value)
	{
		___UriSchemeWs_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeWs_5), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeWss_6() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeWss_6)); }
	inline String_t* get_UriSchemeWss_6() const { return ___UriSchemeWss_6; }
	inline String_t** get_address_of_UriSchemeWss_6() { return &___UriSchemeWss_6; }
	inline void set_UriSchemeWss_6(String_t* value)
	{
		___UriSchemeWss_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeWss_6), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeMailto_7() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeMailto_7)); }
	inline String_t* get_UriSchemeMailto_7() const { return ___UriSchemeMailto_7; }
	inline String_t** get_address_of_UriSchemeMailto_7() { return &___UriSchemeMailto_7; }
	inline void set_UriSchemeMailto_7(String_t* value)
	{
		___UriSchemeMailto_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeMailto_7), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeNews_8() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeNews_8)); }
	inline String_t* get_UriSchemeNews_8() const { return ___UriSchemeNews_8; }
	inline String_t** get_address_of_UriSchemeNews_8() { return &___UriSchemeNews_8; }
	inline void set_UriSchemeNews_8(String_t* value)
	{
		___UriSchemeNews_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeNews_8), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeNntp_9() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeNntp_9)); }
	inline String_t* get_UriSchemeNntp_9() const { return ___UriSchemeNntp_9; }
	inline String_t** get_address_of_UriSchemeNntp_9() { return &___UriSchemeNntp_9; }
	inline void set_UriSchemeNntp_9(String_t* value)
	{
		___UriSchemeNntp_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeNntp_9), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeNetTcp_10() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeNetTcp_10)); }
	inline String_t* get_UriSchemeNetTcp_10() const { return ___UriSchemeNetTcp_10; }
	inline String_t** get_address_of_UriSchemeNetTcp_10() { return &___UriSchemeNetTcp_10; }
	inline void set_UriSchemeNetTcp_10(String_t* value)
	{
		___UriSchemeNetTcp_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeNetTcp_10), (void*)value);
	}

	inline static int32_t get_offset_of_UriSchemeNetPipe_11() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___UriSchemeNetPipe_11)); }
	inline String_t* get_UriSchemeNetPipe_11() const { return ___UriSchemeNetPipe_11; }
	inline String_t** get_address_of_UriSchemeNetPipe_11() { return &___UriSchemeNetPipe_11; }
	inline void set_UriSchemeNetPipe_11(String_t* value)
	{
		___UriSchemeNetPipe_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___UriSchemeNetPipe_11), (void*)value);
	}

	inline static int32_t get_offset_of_SchemeDelimiter_12() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___SchemeDelimiter_12)); }
	inline String_t* get_SchemeDelimiter_12() const { return ___SchemeDelimiter_12; }
	inline String_t** get_address_of_SchemeDelimiter_12() { return &___SchemeDelimiter_12; }
	inline void set_SchemeDelimiter_12(String_t* value)
	{
		___SchemeDelimiter_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___SchemeDelimiter_12), (void*)value);
	}

	inline static int32_t get_offset_of_s_ConfigInitialized_23() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___s_ConfigInitialized_23)); }
	inline bool get_s_ConfigInitialized_23() const { return ___s_ConfigInitialized_23; }
	inline bool* get_address_of_s_ConfigInitialized_23() { return &___s_ConfigInitialized_23; }
	inline void set_s_ConfigInitialized_23(bool value)
	{
		___s_ConfigInitialized_23 = value;
	}

	inline static int32_t get_offset_of_s_ConfigInitializing_24() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___s_ConfigInitializing_24)); }
	inline bool get_s_ConfigInitializing_24() const { return ___s_ConfigInitializing_24; }
	inline bool* get_address_of_s_ConfigInitializing_24() { return &___s_ConfigInitializing_24; }
	inline void set_s_ConfigInitializing_24(bool value)
	{
		___s_ConfigInitializing_24 = value;
	}

	inline static int32_t get_offset_of_s_IdnScope_25() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___s_IdnScope_25)); }
	inline int32_t get_s_IdnScope_25() const { return ___s_IdnScope_25; }
	inline int32_t* get_address_of_s_IdnScope_25() { return &___s_IdnScope_25; }
	inline void set_s_IdnScope_25(int32_t value)
	{
		___s_IdnScope_25 = value;
	}

	inline static int32_t get_offset_of_s_IriParsing_26() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___s_IriParsing_26)); }
	inline bool get_s_IriParsing_26() const { return ___s_IriParsing_26; }
	inline bool* get_address_of_s_IriParsing_26() { return &___s_IriParsing_26; }
	inline void set_s_IriParsing_26(bool value)
	{
		___s_IriParsing_26 = value;
	}

	inline static int32_t get_offset_of_useDotNetRelativeOrAbsolute_27() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___useDotNetRelativeOrAbsolute_27)); }
	inline bool get_useDotNetRelativeOrAbsolute_27() const { return ___useDotNetRelativeOrAbsolute_27; }
	inline bool* get_address_of_useDotNetRelativeOrAbsolute_27() { return &___useDotNetRelativeOrAbsolute_27; }
	inline void set_useDotNetRelativeOrAbsolute_27(bool value)
	{
		___useDotNetRelativeOrAbsolute_27 = value;
	}

	inline static int32_t get_offset_of_IsWindowsFileSystem_29() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___IsWindowsFileSystem_29)); }
	inline bool get_IsWindowsFileSystem_29() const { return ___IsWindowsFileSystem_29; }
	inline bool* get_address_of_IsWindowsFileSystem_29() { return &___IsWindowsFileSystem_29; }
	inline void set_IsWindowsFileSystem_29(bool value)
	{
		___IsWindowsFileSystem_29 = value;
	}

	inline static int32_t get_offset_of_s_initLock_30() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___s_initLock_30)); }
	inline RuntimeObject * get_s_initLock_30() const { return ___s_initLock_30; }
	inline RuntimeObject ** get_address_of_s_initLock_30() { return &___s_initLock_30; }
	inline void set_s_initLock_30(RuntimeObject * value)
	{
		___s_initLock_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_initLock_30), (void*)value);
	}

	inline static int32_t get_offset_of_HexLowerChars_34() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ___HexLowerChars_34)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_HexLowerChars_34() const { return ___HexLowerChars_34; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_HexLowerChars_34() { return &___HexLowerChars_34; }
	inline void set_HexLowerChars_34(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___HexLowerChars_34 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___HexLowerChars_34), (void*)value);
	}

	inline static int32_t get_offset_of__WSchars_35() { return static_cast<int32_t>(offsetof(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_StaticFields, ____WSchars_35)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get__WSchars_35() const { return ____WSchars_35; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of__WSchars_35() { return &____WSchars_35; }
	inline void set__WSchars_35(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		____WSchars_35 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____WSchars_35), (void*)value);
	}
};


// Wamp_<Call>d__34
struct  U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D 
{
public:
	// System.Int32 Wamp_<Call>d__34::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String> Wamp_<Call>d__34::<>t__builder
	AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  ___U3CU3Et__builder_1;
	// Wamp Wamp_<Call>d__34::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_2;
	// System.String Wamp_<Call>d__34::options
	String_t* ___options_3;
	// System.String Wamp_<Call>d__34::uri
	String_t* ___uri_4;
	// System.String Wamp_<Call>d__34::args
	String_t* ___args_5;
	// System.Int32 Wamp_<Call>d__34::timeout
	int32_t ___timeout_6;
	// System.Int32 Wamp_<Call>d__34::<requestId>5__2
	int32_t ___U3CrequestIdU3E5__2_7;
	// System.Runtime.CompilerServices.TaskAwaiter Wamp_<Call>d__34::<>u__1
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  ___U3CU3Eu__1_8;
	// System.Runtime.CompilerServices.TaskAwaiter`1<Wamp_Response> Wamp_<Call>d__34::<>u__2
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  ___U3CU3Eu__2_9;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Et__builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___U3CU3E4__this_2)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_options_3() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___options_3)); }
	inline String_t* get_options_3() const { return ___options_3; }
	inline String_t** get_address_of_options_3() { return &___options_3; }
	inline void set_options_3(String_t* value)
	{
		___options_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___options_3), (void*)value);
	}

	inline static int32_t get_offset_of_uri_4() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___uri_4)); }
	inline String_t* get_uri_4() const { return ___uri_4; }
	inline String_t** get_address_of_uri_4() { return &___uri_4; }
	inline void set_uri_4(String_t* value)
	{
		___uri_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___uri_4), (void*)value);
	}

	inline static int32_t get_offset_of_args_5() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___args_5)); }
	inline String_t* get_args_5() const { return ___args_5; }
	inline String_t** get_address_of_args_5() { return &___args_5; }
	inline void set_args_5(String_t* value)
	{
		___args_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___args_5), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_6() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___timeout_6)); }
	inline int32_t get_timeout_6() const { return ___timeout_6; }
	inline int32_t* get_address_of_timeout_6() { return &___timeout_6; }
	inline void set_timeout_6(int32_t value)
	{
		___timeout_6 = value;
	}

	inline static int32_t get_offset_of_U3CrequestIdU3E5__2_7() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___U3CrequestIdU3E5__2_7)); }
	inline int32_t get_U3CrequestIdU3E5__2_7() const { return ___U3CrequestIdU3E5__2_7; }
	inline int32_t* get_address_of_U3CrequestIdU3E5__2_7() { return &___U3CrequestIdU3E5__2_7; }
	inline void set_U3CrequestIdU3E5__2_7(int32_t value)
	{
		___U3CrequestIdU3E5__2_7 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_8() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___U3CU3Eu__1_8)); }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  get_U3CU3Eu__1_8() const { return ___U3CU3Eu__1_8; }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * get_address_of_U3CU3Eu__1_8() { return &___U3CU3Eu__1_8; }
	inline void set_U3CU3Eu__1_8(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  value)
	{
		___U3CU3Eu__1_8 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_8))->___m_task_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CU3Eu__2_9() { return static_cast<int32_t>(offsetof(U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D, ___U3CU3Eu__2_9)); }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  get_U3CU3Eu__2_9() const { return ___U3CU3Eu__2_9; }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * get_address_of_U3CU3Eu__2_9() { return &___U3CU3Eu__2_9; }
	inline void set_U3CU3Eu__2_9(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  value)
	{
		___U3CU3Eu__2_9 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__2_9))->___m_task_0), (void*)NULL);
	}
};


// Wamp_<Receive>d__25
struct  U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC 
{
public:
	// System.Int32 Wamp_<Receive>d__25::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp_Response> Wamp_<Receive>d__25::<>t__builder
	AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  ___U3CU3Et__builder_1;
	// Wamp Wamp_<Receive>d__25::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_2;
	// System.Int32 Wamp_<Receive>d__25::timeout
	int32_t ___timeout_3;
	// System.Runtime.CompilerServices.TaskAwaiter`1<System.Threading.Tasks.Task> Wamp_<Receive>d__25::<>u__1
	TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A  ___U3CU3Eu__1_4;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Et__builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC, ___U3CU3E4__this_2)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_3() { return static_cast<int32_t>(offsetof(U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC, ___timeout_3)); }
	inline int32_t get_timeout_3() const { return ___timeout_3; }
	inline int32_t* get_address_of_timeout_3() { return &___timeout_3; }
	inline void set_timeout_3(int32_t value)
	{
		___timeout_3 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_4() { return static_cast<int32_t>(offsetof(U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC, ___U3CU3Eu__1_4)); }
	inline TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A  get_U3CU3Eu__1_4() const { return ___U3CU3Eu__1_4; }
	inline TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A * get_address_of_U3CU3Eu__1_4() { return &___U3CU3Eu__1_4; }
	inline void set_U3CU3Eu__1_4(TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A  value)
	{
		___U3CU3Eu__1_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_4))->___m_task_0), (void*)NULL);
	}
};


// Wamp_<ReceiveExpect>d__26
struct  U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F 
{
public:
	// System.Int32 Wamp_<ReceiveExpect>d__26::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp_Response> Wamp_<ReceiveExpect>d__26::<>t__builder
	AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  ___U3CU3Et__builder_1;
	// Wamp Wamp_<ReceiveExpect>d__26::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_2;
	// System.Int32 Wamp_<ReceiveExpect>d__26::timeout
	int32_t ___timeout_3;
	// Wamp_Messages Wamp_<ReceiveExpect>d__26::message
	int32_t ___message_4;
	// System.Int32 Wamp_<ReceiveExpect>d__26::requestId
	int32_t ___requestId_5;
	// System.Runtime.CompilerServices.TaskAwaiter`1<Wamp_Response> Wamp_<ReceiveExpect>d__26::<>u__1
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  ___U3CU3Eu__1_6;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Et__builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F, ___U3CU3E4__this_2)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_3() { return static_cast<int32_t>(offsetof(U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F, ___timeout_3)); }
	inline int32_t get_timeout_3() const { return ___timeout_3; }
	inline int32_t* get_address_of_timeout_3() { return &___timeout_3; }
	inline void set_timeout_3(int32_t value)
	{
		___timeout_3 = value;
	}

	inline static int32_t get_offset_of_message_4() { return static_cast<int32_t>(offsetof(U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F, ___message_4)); }
	inline int32_t get_message_4() const { return ___message_4; }
	inline int32_t* get_address_of_message_4() { return &___message_4; }
	inline void set_message_4(int32_t value)
	{
		___message_4 = value;
	}

	inline static int32_t get_offset_of_requestId_5() { return static_cast<int32_t>(offsetof(U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F, ___requestId_5)); }
	inline int32_t get_requestId_5() const { return ___requestId_5; }
	inline int32_t* get_address_of_requestId_5() { return &___requestId_5; }
	inline void set_requestId_5(int32_t value)
	{
		___requestId_5 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_6() { return static_cast<int32_t>(offsetof(U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F, ___U3CU3Eu__1_6)); }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  get_U3CU3Eu__1_6() const { return ___U3CU3Eu__1_6; }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * get_address_of_U3CU3Eu__1_6() { return &___U3CU3Eu__1_6; }
	inline void set_U3CU3Eu__1_6(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  value)
	{
		___U3CU3Eu__1_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_6))->___m_task_0), (void*)NULL);
	}
};


// Wamp_<ReceiveMessage>d__24
struct  U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C 
{
public:
	// System.Int32 Wamp_<ReceiveMessage>d__24::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp_Response> Wamp_<ReceiveMessage>d__24::<>t__builder
	AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  ___U3CU3Et__builder_1;
	// Wamp Wamp_<ReceiveMessage>d__24::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_2;
	// System.Collections.Generic.List`1<System.Collections.Generic.IEnumerable`1<System.Byte>> Wamp_<ReceiveMessage>d__24::<segments>5__2
	List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * ___U3CsegmentsU3E5__2_3;
	// System.ArraySegment`1<System.Byte> Wamp_<ReceiveMessage>d__24::<segment>5__3
	ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA  ___U3CsegmentU3E5__3_4;
	// System.Runtime.CompilerServices.TaskAwaiter`1<System.Net.WebSockets.WebSocketReceiveResult> Wamp_<ReceiveMessage>d__24::<>u__1
	TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD  ___U3CU3Eu__1_5;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Et__builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C, ___U3CU3E4__this_2)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CsegmentsU3E5__2_3() { return static_cast<int32_t>(offsetof(U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C, ___U3CsegmentsU3E5__2_3)); }
	inline List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * get_U3CsegmentsU3E5__2_3() const { return ___U3CsegmentsU3E5__2_3; }
	inline List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 ** get_address_of_U3CsegmentsU3E5__2_3() { return &___U3CsegmentsU3E5__2_3; }
	inline void set_U3CsegmentsU3E5__2_3(List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * value)
	{
		___U3CsegmentsU3E5__2_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CsegmentsU3E5__2_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CsegmentU3E5__3_4() { return static_cast<int32_t>(offsetof(U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C, ___U3CsegmentU3E5__3_4)); }
	inline ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA  get_U3CsegmentU3E5__3_4() const { return ___U3CsegmentU3E5__3_4; }
	inline ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * get_address_of_U3CsegmentU3E5__3_4() { return &___U3CsegmentU3E5__3_4; }
	inline void set_U3CsegmentU3E5__3_4(ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA  value)
	{
		___U3CsegmentU3E5__3_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CsegmentU3E5__3_4))->____array_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_5() { return static_cast<int32_t>(offsetof(U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C, ___U3CU3Eu__1_5)); }
	inline TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD  get_U3CU3Eu__1_5() const { return ___U3CU3Eu__1_5; }
	inline TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD * get_address_of_U3CU3Eu__1_5() { return &___U3CU3Eu__1_5; }
	inline void set_U3CU3Eu__1_5(TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD  value)
	{
		___U3CU3Eu__1_5 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_5))->___m_task_0), (void*)NULL);
	}
};


// Wamp_<Subscribe>d__35
struct  U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 
{
public:
	// System.Int32 Wamp_<Subscribe>d__35::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32> Wamp_<Subscribe>d__35::<>t__builder
	AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  ___U3CU3Et__builder_1;
	// Wamp Wamp_<Subscribe>d__35::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_2;
	// System.String Wamp_<Subscribe>d__35::options
	String_t* ___options_3;
	// System.String Wamp_<Subscribe>d__35::topic
	String_t* ___topic_4;
	// System.Int32 Wamp_<Subscribe>d__35::timeout
	int32_t ___timeout_5;
	// Wamp_PublishHandler Wamp_<Subscribe>d__35::publishEvent
	PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * ___publishEvent_6;
	// System.Int32 Wamp_<Subscribe>d__35::<requestId>5__2
	int32_t ___U3CrequestIdU3E5__2_7;
	// System.Runtime.CompilerServices.TaskAwaiter Wamp_<Subscribe>d__35::<>u__1
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  ___U3CU3Eu__1_8;
	// System.Runtime.CompilerServices.TaskAwaiter`1<Wamp_Response> Wamp_<Subscribe>d__35::<>u__2
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  ___U3CU3Eu__2_9;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Et__builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___U3CU3E4__this_2)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_options_3() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___options_3)); }
	inline String_t* get_options_3() const { return ___options_3; }
	inline String_t** get_address_of_options_3() { return &___options_3; }
	inline void set_options_3(String_t* value)
	{
		___options_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___options_3), (void*)value);
	}

	inline static int32_t get_offset_of_topic_4() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___topic_4)); }
	inline String_t* get_topic_4() const { return ___topic_4; }
	inline String_t** get_address_of_topic_4() { return &___topic_4; }
	inline void set_topic_4(String_t* value)
	{
		___topic_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___topic_4), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_5() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___timeout_5)); }
	inline int32_t get_timeout_5() const { return ___timeout_5; }
	inline int32_t* get_address_of_timeout_5() { return &___timeout_5; }
	inline void set_timeout_5(int32_t value)
	{
		___timeout_5 = value;
	}

	inline static int32_t get_offset_of_publishEvent_6() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___publishEvent_6)); }
	inline PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * get_publishEvent_6() const { return ___publishEvent_6; }
	inline PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 ** get_address_of_publishEvent_6() { return &___publishEvent_6; }
	inline void set_publishEvent_6(PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * value)
	{
		___publishEvent_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___publishEvent_6), (void*)value);
	}

	inline static int32_t get_offset_of_U3CrequestIdU3E5__2_7() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___U3CrequestIdU3E5__2_7)); }
	inline int32_t get_U3CrequestIdU3E5__2_7() const { return ___U3CrequestIdU3E5__2_7; }
	inline int32_t* get_address_of_U3CrequestIdU3E5__2_7() { return &___U3CrequestIdU3E5__2_7; }
	inline void set_U3CrequestIdU3E5__2_7(int32_t value)
	{
		___U3CrequestIdU3E5__2_7 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_8() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___U3CU3Eu__1_8)); }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  get_U3CU3Eu__1_8() const { return ___U3CU3Eu__1_8; }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * get_address_of_U3CU3Eu__1_8() { return &___U3CU3Eu__1_8; }
	inline void set_U3CU3Eu__1_8(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  value)
	{
		___U3CU3Eu__1_8 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_8))->___m_task_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CU3Eu__2_9() { return static_cast<int32_t>(offsetof(U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9, ___U3CU3Eu__2_9)); }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  get_U3CU3Eu__2_9() const { return ___U3CU3Eu__2_9; }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * get_address_of_U3CU3Eu__2_9() { return &___U3CU3Eu__2_9; }
	inline void set_U3CU3Eu__2_9(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  value)
	{
		___U3CU3Eu__2_9 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__2_9))->___m_task_0), (void*)NULL);
	}
};


// Wamp_ErrorException
struct  ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46  : public Exception_t
{
public:
	// System.String Wamp_ErrorException::<Json>k__BackingField
	String_t* ___U3CJsonU3Ek__BackingField_17;
	// Wamp_Messages Wamp_ErrorException::<MessageId>k__BackingField
	int32_t ___U3CMessageIdU3Ek__BackingField_18;
	// System.Int32 Wamp_ErrorException::<RequestId>k__BackingField
	int32_t ___U3CRequestIdU3Ek__BackingField_19;
	// System.String Wamp_ErrorException::<Uri>k__BackingField
	String_t* ___U3CUriU3Ek__BackingField_20;

public:
	inline static int32_t get_offset_of_U3CJsonU3Ek__BackingField_17() { return static_cast<int32_t>(offsetof(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46, ___U3CJsonU3Ek__BackingField_17)); }
	inline String_t* get_U3CJsonU3Ek__BackingField_17() const { return ___U3CJsonU3Ek__BackingField_17; }
	inline String_t** get_address_of_U3CJsonU3Ek__BackingField_17() { return &___U3CJsonU3Ek__BackingField_17; }
	inline void set_U3CJsonU3Ek__BackingField_17(String_t* value)
	{
		___U3CJsonU3Ek__BackingField_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CJsonU3Ek__BackingField_17), (void*)value);
	}

	inline static int32_t get_offset_of_U3CMessageIdU3Ek__BackingField_18() { return static_cast<int32_t>(offsetof(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46, ___U3CMessageIdU3Ek__BackingField_18)); }
	inline int32_t get_U3CMessageIdU3Ek__BackingField_18() const { return ___U3CMessageIdU3Ek__BackingField_18; }
	inline int32_t* get_address_of_U3CMessageIdU3Ek__BackingField_18() { return &___U3CMessageIdU3Ek__BackingField_18; }
	inline void set_U3CMessageIdU3Ek__BackingField_18(int32_t value)
	{
		___U3CMessageIdU3Ek__BackingField_18 = value;
	}

	inline static int32_t get_offset_of_U3CRequestIdU3Ek__BackingField_19() { return static_cast<int32_t>(offsetof(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46, ___U3CRequestIdU3Ek__BackingField_19)); }
	inline int32_t get_U3CRequestIdU3Ek__BackingField_19() const { return ___U3CRequestIdU3Ek__BackingField_19; }
	inline int32_t* get_address_of_U3CRequestIdU3Ek__BackingField_19() { return &___U3CRequestIdU3Ek__BackingField_19; }
	inline void set_U3CRequestIdU3Ek__BackingField_19(int32_t value)
	{
		___U3CRequestIdU3Ek__BackingField_19 = value;
	}

	inline static int32_t get_offset_of_U3CUriU3Ek__BackingField_20() { return static_cast<int32_t>(offsetof(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46, ___U3CUriU3Ek__BackingField_20)); }
	inline String_t* get_U3CUriU3Ek__BackingField_20() const { return ___U3CUriU3Ek__BackingField_20; }
	inline String_t** get_address_of_U3CUriU3Ek__BackingField_20() { return &___U3CUriU3Ek__BackingField_20; }
	inline void set_U3CUriU3Ek__BackingField_20(String_t* value)
	{
		___U3CUriU3Ek__BackingField_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CUriU3Ek__BackingField_20), (void*)value);
	}
};


// Wamp_Response
struct  Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8  : public RuntimeObject
{
public:
	// Wamp_Messages Wamp_Response::<MessageId>k__BackingField
	int32_t ___U3CMessageIdU3Ek__BackingField_0;
	// System.Int32 Wamp_Response::<RequestId>k__BackingField
	int32_t ___U3CRequestIdU3Ek__BackingField_1;
	// System.Int32 Wamp_Response::<ContextSpecificResultId>k__BackingField
	int32_t ___U3CContextSpecificResultIdU3Ek__BackingField_2;
	// System.UInt32 Wamp_Response::<SubscriptionId>k__BackingField
	uint32_t ___U3CSubscriptionIdU3Ek__BackingField_3;
	// System.String Wamp_Response::<Json>k__BackingField
	String_t* ___U3CJsonU3Ek__BackingField_4;

public:
	inline static int32_t get_offset_of_U3CMessageIdU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8, ___U3CMessageIdU3Ek__BackingField_0)); }
	inline int32_t get_U3CMessageIdU3Ek__BackingField_0() const { return ___U3CMessageIdU3Ek__BackingField_0; }
	inline int32_t* get_address_of_U3CMessageIdU3Ek__BackingField_0() { return &___U3CMessageIdU3Ek__BackingField_0; }
	inline void set_U3CMessageIdU3Ek__BackingField_0(int32_t value)
	{
		___U3CMessageIdU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_U3CRequestIdU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8, ___U3CRequestIdU3Ek__BackingField_1)); }
	inline int32_t get_U3CRequestIdU3Ek__BackingField_1() const { return ___U3CRequestIdU3Ek__BackingField_1; }
	inline int32_t* get_address_of_U3CRequestIdU3Ek__BackingField_1() { return &___U3CRequestIdU3Ek__BackingField_1; }
	inline void set_U3CRequestIdU3Ek__BackingField_1(int32_t value)
	{
		___U3CRequestIdU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CContextSpecificResultIdU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8, ___U3CContextSpecificResultIdU3Ek__BackingField_2)); }
	inline int32_t get_U3CContextSpecificResultIdU3Ek__BackingField_2() const { return ___U3CContextSpecificResultIdU3Ek__BackingField_2; }
	inline int32_t* get_address_of_U3CContextSpecificResultIdU3Ek__BackingField_2() { return &___U3CContextSpecificResultIdU3Ek__BackingField_2; }
	inline void set_U3CContextSpecificResultIdU3Ek__BackingField_2(int32_t value)
	{
		___U3CContextSpecificResultIdU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CSubscriptionIdU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8, ___U3CSubscriptionIdU3Ek__BackingField_3)); }
	inline uint32_t get_U3CSubscriptionIdU3Ek__BackingField_3() const { return ___U3CSubscriptionIdU3Ek__BackingField_3; }
	inline uint32_t* get_address_of_U3CSubscriptionIdU3Ek__BackingField_3() { return &___U3CSubscriptionIdU3Ek__BackingField_3; }
	inline void set_U3CSubscriptionIdU3Ek__BackingField_3(uint32_t value)
	{
		___U3CSubscriptionIdU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_U3CJsonU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8, ___U3CJsonU3Ek__BackingField_4)); }
	inline String_t* get_U3CJsonU3Ek__BackingField_4() const { return ___U3CJsonU3Ek__BackingField_4; }
	inline String_t** get_address_of_U3CJsonU3Ek__BackingField_4() { return &___U3CJsonU3Ek__BackingField_4; }
	inline void set_U3CJsonU3Ek__BackingField_4(String_t* value)
	{
		___U3CJsonU3Ek__BackingField_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CJsonU3Ek__BackingField_4), (void*)value);
	}
};


// Wamp_TimeoutException
struct  TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0  : public Exception_t
{
public:

public:
};


// Wamp_WampNotConnectedException
struct  WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F  : public Exception_t
{
public:

public:
};


// WwiseObjectInfo
struct  WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562 
{
public:
	// System.Guid WwiseObjectInfo::objectGUID
	Guid_t  ___objectGUID_0;
	// System.Guid WwiseObjectInfo::parentID
	Guid_t  ___parentID_1;
	// System.String WwiseObjectInfo::name
	String_t* ___name_2;
	// WwiseObjectType WwiseObjectInfo::type
	int32_t ___type_3;
	// System.Int32 WwiseObjectInfo::childrenCount
	int32_t ___childrenCount_4;
	// System.String WwiseObjectInfo::path
	String_t* ___path_5;
	// System.String WwiseObjectInfo::workUnitType
	String_t* ___workUnitType_6;
	// System.String WwiseObjectInfo::filePath
	String_t* ___filePath_7;
	// System.String WwiseObjectInfo::soundbankBnkFilePath
	String_t* ___soundbankBnkFilePath_8;

public:
	inline static int32_t get_offset_of_objectGUID_0() { return static_cast<int32_t>(offsetof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562, ___objectGUID_0)); }
	inline Guid_t  get_objectGUID_0() const { return ___objectGUID_0; }
	inline Guid_t * get_address_of_objectGUID_0() { return &___objectGUID_0; }
	inline void set_objectGUID_0(Guid_t  value)
	{
		___objectGUID_0 = value;
	}

	inline static int32_t get_offset_of_parentID_1() { return static_cast<int32_t>(offsetof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562, ___parentID_1)); }
	inline Guid_t  get_parentID_1() const { return ___parentID_1; }
	inline Guid_t * get_address_of_parentID_1() { return &___parentID_1; }
	inline void set_parentID_1(Guid_t  value)
	{
		___parentID_1 = value;
	}

	inline static int32_t get_offset_of_name_2() { return static_cast<int32_t>(offsetof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562, ___name_2)); }
	inline String_t* get_name_2() const { return ___name_2; }
	inline String_t** get_address_of_name_2() { return &___name_2; }
	inline void set_name_2(String_t* value)
	{
		___name_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___name_2), (void*)value);
	}

	inline static int32_t get_offset_of_type_3() { return static_cast<int32_t>(offsetof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562, ___type_3)); }
	inline int32_t get_type_3() const { return ___type_3; }
	inline int32_t* get_address_of_type_3() { return &___type_3; }
	inline void set_type_3(int32_t value)
	{
		___type_3 = value;
	}

	inline static int32_t get_offset_of_childrenCount_4() { return static_cast<int32_t>(offsetof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562, ___childrenCount_4)); }
	inline int32_t get_childrenCount_4() const { return ___childrenCount_4; }
	inline int32_t* get_address_of_childrenCount_4() { return &___childrenCount_4; }
	inline void set_childrenCount_4(int32_t value)
	{
		___childrenCount_4 = value;
	}

	inline static int32_t get_offset_of_path_5() { return static_cast<int32_t>(offsetof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562, ___path_5)); }
	inline String_t* get_path_5() const { return ___path_5; }
	inline String_t** get_address_of_path_5() { return &___path_5; }
	inline void set_path_5(String_t* value)
	{
		___path_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___path_5), (void*)value);
	}

	inline static int32_t get_offset_of_workUnitType_6() { return static_cast<int32_t>(offsetof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562, ___workUnitType_6)); }
	inline String_t* get_workUnitType_6() const { return ___workUnitType_6; }
	inline String_t** get_address_of_workUnitType_6() { return &___workUnitType_6; }
	inline void set_workUnitType_6(String_t* value)
	{
		___workUnitType_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___workUnitType_6), (void*)value);
	}

	inline static int32_t get_offset_of_filePath_7() { return static_cast<int32_t>(offsetof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562, ___filePath_7)); }
	inline String_t* get_filePath_7() const { return ___filePath_7; }
	inline String_t** get_address_of_filePath_7() { return &___filePath_7; }
	inline void set_filePath_7(String_t* value)
	{
		___filePath_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___filePath_7), (void*)value);
	}

	inline static int32_t get_offset_of_soundbankBnkFilePath_8() { return static_cast<int32_t>(offsetof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562, ___soundbankBnkFilePath_8)); }
	inline String_t* get_soundbankBnkFilePath_8() const { return ___soundbankBnkFilePath_8; }
	inline String_t** get_address_of_soundbankBnkFilePath_8() { return &___soundbankBnkFilePath_8; }
	inline void set_soundbankBnkFilePath_8(String_t* value)
	{
		___soundbankBnkFilePath_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___soundbankBnkFilePath_8), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of WwiseObjectInfo
struct WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshaled_pinvoke
{
	Guid_t  ___objectGUID_0;
	Guid_t  ___parentID_1;
	char* ___name_2;
	int32_t ___type_3;
	int32_t ___childrenCount_4;
	char* ___path_5;
	char* ___workUnitType_6;
	char* ___filePath_7;
	char* ___soundbankBnkFilePath_8;
};
// Native definition for COM marshalling of WwiseObjectInfo
struct WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshaled_com
{
	Guid_t  ___objectGUID_0;
	Guid_t  ___parentID_1;
	Il2CppChar* ___name_2;
	int32_t ___type_3;
	int32_t ___childrenCount_4;
	Il2CppChar* ___path_5;
	Il2CppChar* ___workUnitType_6;
	Il2CppChar* ___filePath_7;
	Il2CppChar* ___soundbankBnkFilePath_8;
};

// AkWaapiClient_<Close>d__6
struct  U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D 
{
public:
	// System.Int32 AkWaapiClient_<Close>d__6::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder AkWaapiClient_<Close>d__6::<>t__builder
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  ___U3CU3Et__builder_1;
	// AkWaapiClient AkWaapiClient_<Close>d__6::<>4__this
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * ___U3CU3E4__this_2;
	// System.Int32 AkWaapiClient_<Close>d__6::timeout
	int32_t ___timeout_3;
	// System.Runtime.CompilerServices.TaskAwaiter AkWaapiClient_<Close>d__6::<>u__1
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  ___U3CU3Eu__1_4;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D, ___U3CU3E4__this_2)); }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_3() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D, ___timeout_3)); }
	inline int32_t get_timeout_3() const { return ___timeout_3; }
	inline int32_t* get_address_of_timeout_3() { return &___timeout_3; }
	inline void set_timeout_3(int32_t value)
	{
		___timeout_3 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_4() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D, ___U3CU3Eu__1_4)); }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  get_U3CU3Eu__1_4() const { return ___U3CU3Eu__1_4; }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * get_address_of_U3CU3Eu__1_4() { return &___U3CU3Eu__1_4; }
	inline void set_U3CU3Eu__1_4(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  value)
	{
		___U3CU3Eu__1_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_4))->___m_task_0), (void*)NULL);
	}
};


// AkWaapiClient_<Connect>d__4
struct  U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 
{
public:
	// System.Int32 AkWaapiClient_<Connect>d__4::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder AkWaapiClient_<Connect>d__4::<>t__builder
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  ___U3CU3Et__builder_1;
	// AkWaapiClient AkWaapiClient_<Connect>d__4::<>4__this
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * ___U3CU3E4__this_2;
	// System.String AkWaapiClient_<Connect>d__4::uri
	String_t* ___uri_3;
	// System.Int32 AkWaapiClient_<Connect>d__4::timeout
	int32_t ___timeout_4;
	// System.Runtime.CompilerServices.TaskAwaiter AkWaapiClient_<Connect>d__4::<>u__1
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  ___U3CU3Eu__1_5;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248, ___U3CU3E4__this_2)); }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_uri_3() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248, ___uri_3)); }
	inline String_t* get_uri_3() const { return ___uri_3; }
	inline String_t** get_address_of_uri_3() { return &___uri_3; }
	inline void set_uri_3(String_t* value)
	{
		___uri_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___uri_3), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_4() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248, ___timeout_4)); }
	inline int32_t get_timeout_4() const { return ___timeout_4; }
	inline int32_t* get_address_of_timeout_4() { return &___timeout_4; }
	inline void set_timeout_4(int32_t value)
	{
		___timeout_4 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_5() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248, ___U3CU3Eu__1_5)); }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  get_U3CU3Eu__1_5() const { return ___U3CU3Eu__1_5; }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * get_address_of_U3CU3Eu__1_5() { return &___U3CU3Eu__1_5; }
	inline void set_U3CU3Eu__1_5(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  value)
	{
		___U3CU3Eu__1_5 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_5))->___m_task_0), (void*)NULL);
	}
};


// AkWaapiClient_<Unsubscribe>d__10
struct  U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D 
{
public:
	// System.Int32 AkWaapiClient_<Unsubscribe>d__10::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder AkWaapiClient_<Unsubscribe>d__10::<>t__builder
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  ___U3CU3Et__builder_1;
	// AkWaapiClient AkWaapiClient_<Unsubscribe>d__10::<>4__this
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * ___U3CU3E4__this_2;
	// System.UInt32 AkWaapiClient_<Unsubscribe>d__10::subscriptionId
	uint32_t ___subscriptionId_3;
	// System.Int32 AkWaapiClient_<Unsubscribe>d__10::timeout
	int32_t ___timeout_4;
	// System.Runtime.CompilerServices.TaskAwaiter AkWaapiClient_<Unsubscribe>d__10::<>u__1
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  ___U3CU3Eu__1_5;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D, ___U3CU3E4__this_2)); }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_subscriptionId_3() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D, ___subscriptionId_3)); }
	inline uint32_t get_subscriptionId_3() const { return ___subscriptionId_3; }
	inline uint32_t* get_address_of_subscriptionId_3() { return &___subscriptionId_3; }
	inline void set_subscriptionId_3(uint32_t value)
	{
		___subscriptionId_3 = value;
	}

	inline static int32_t get_offset_of_timeout_4() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D, ___timeout_4)); }
	inline int32_t get_timeout_4() const { return ___timeout_4; }
	inline int32_t* get_address_of_timeout_4() { return &___timeout_4; }
	inline void set_timeout_4(int32_t value)
	{
		___timeout_4 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_5() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D, ___U3CU3Eu__1_5)); }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  get_U3CU3Eu__1_5() const { return ___U3CU3Eu__1_5; }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * get_address_of_U3CU3Eu__1_5() { return &___U3CU3Eu__1_5; }
	inline void set_U3CU3Eu__1_5(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  value)
	{
		___U3CU3Eu__1_5 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_5))->___m_task_0), (void*)NULL);
	}
};


// System.Action
struct  Action_t591D2A86165F896B4B800BB5C25CE18672A55579  : public MulticastDelegate_t
{
public:

public:
};


// System.AsyncCallback
struct  AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4  : public MulticastDelegate_t
{
public:

public:
};


// System.Func`2<System.Collections.Generic.IEnumerable`1<System.Byte>,System.Collections.Generic.IEnumerable`1<System.Byte>>
struct  Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094  : public MulticastDelegate_t
{
public:

public:
};


// System.Net.WebSockets.WebSocketReceiveResult
struct  WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5  : public RuntimeObject
{
public:
	// System.Int32 System.Net.WebSockets.WebSocketReceiveResult::<Count>k__BackingField
	int32_t ___U3CCountU3Ek__BackingField_0;
	// System.Boolean System.Net.WebSockets.WebSocketReceiveResult::<EndOfMessage>k__BackingField
	bool ___U3CEndOfMessageU3Ek__BackingField_1;
	// System.Net.WebSockets.WebSocketMessageType System.Net.WebSockets.WebSocketReceiveResult::<MessageType>k__BackingField
	int32_t ___U3CMessageTypeU3Ek__BackingField_2;
	// System.Nullable`1<System.Net.WebSockets.WebSocketCloseStatus> System.Net.WebSockets.WebSocketReceiveResult::<CloseStatus>k__BackingField
	Nullable_1_tD09391AA7DA79953C91A6F93F3E19269CE3D7D57  ___U3CCloseStatusU3Ek__BackingField_3;
	// System.String System.Net.WebSockets.WebSocketReceiveResult::<CloseStatusDescription>k__BackingField
	String_t* ___U3CCloseStatusDescriptionU3Ek__BackingField_4;

public:
	inline static int32_t get_offset_of_U3CCountU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5, ___U3CCountU3Ek__BackingField_0)); }
	inline int32_t get_U3CCountU3Ek__BackingField_0() const { return ___U3CCountU3Ek__BackingField_0; }
	inline int32_t* get_address_of_U3CCountU3Ek__BackingField_0() { return &___U3CCountU3Ek__BackingField_0; }
	inline void set_U3CCountU3Ek__BackingField_0(int32_t value)
	{
		___U3CCountU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_U3CEndOfMessageU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5, ___U3CEndOfMessageU3Ek__BackingField_1)); }
	inline bool get_U3CEndOfMessageU3Ek__BackingField_1() const { return ___U3CEndOfMessageU3Ek__BackingField_1; }
	inline bool* get_address_of_U3CEndOfMessageU3Ek__BackingField_1() { return &___U3CEndOfMessageU3Ek__BackingField_1; }
	inline void set_U3CEndOfMessageU3Ek__BackingField_1(bool value)
	{
		___U3CEndOfMessageU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CMessageTypeU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5, ___U3CMessageTypeU3Ek__BackingField_2)); }
	inline int32_t get_U3CMessageTypeU3Ek__BackingField_2() const { return ___U3CMessageTypeU3Ek__BackingField_2; }
	inline int32_t* get_address_of_U3CMessageTypeU3Ek__BackingField_2() { return &___U3CMessageTypeU3Ek__BackingField_2; }
	inline void set_U3CMessageTypeU3Ek__BackingField_2(int32_t value)
	{
		___U3CMessageTypeU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CCloseStatusU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5, ___U3CCloseStatusU3Ek__BackingField_3)); }
	inline Nullable_1_tD09391AA7DA79953C91A6F93F3E19269CE3D7D57  get_U3CCloseStatusU3Ek__BackingField_3() const { return ___U3CCloseStatusU3Ek__BackingField_3; }
	inline Nullable_1_tD09391AA7DA79953C91A6F93F3E19269CE3D7D57 * get_address_of_U3CCloseStatusU3Ek__BackingField_3() { return &___U3CCloseStatusU3Ek__BackingField_3; }
	inline void set_U3CCloseStatusU3Ek__BackingField_3(Nullable_1_tD09391AA7DA79953C91A6F93F3E19269CE3D7D57  value)
	{
		___U3CCloseStatusU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_U3CCloseStatusDescriptionU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5, ___U3CCloseStatusDescriptionU3Ek__BackingField_4)); }
	inline String_t* get_U3CCloseStatusDescriptionU3Ek__BackingField_4() const { return ___U3CCloseStatusDescriptionU3Ek__BackingField_4; }
	inline String_t** get_address_of_U3CCloseStatusDescriptionU3Ek__BackingField_4() { return &___U3CCloseStatusDescriptionU3Ek__BackingField_4; }
	inline void set_U3CCloseStatusDescriptionU3Ek__BackingField_4(String_t* value)
	{
		___U3CCloseStatusDescriptionU3Ek__BackingField_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CCloseStatusDescriptionU3Ek__BackingField_4), (void*)value);
	}
};


// System.OperationCanceledException
struct  OperationCanceledException_tD28B1AE59ACCE4D46333BFE398395B8D75D76A90  : public SystemException_t5380468142AA850BE4A341D7AF3EAB9C78746782
{
public:
	// System.Threading.CancellationToken System.OperationCanceledException::_cancellationToken
	CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  ____cancellationToken_17;

public:
	inline static int32_t get_offset_of__cancellationToken_17() { return static_cast<int32_t>(offsetof(OperationCanceledException_tD28B1AE59ACCE4D46333BFE398395B8D75D76A90, ____cancellationToken_17)); }
	inline CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  get__cancellationToken_17() const { return ____cancellationToken_17; }
	inline CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB * get_address_of__cancellationToken_17() { return &____cancellationToken_17; }
	inline void set__cancellationToken_17(CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  value)
	{
		____cancellationToken_17 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&____cancellationToken_17))->___m_source_0), (void*)NULL);
	}
};


// System.Runtime.InteropServices.ExternalException
struct  ExternalException_t68841FD169C0CB00CC950EDA7E2A59540D65B1CE  : public SystemException_t5380468142AA850BE4A341D7AF3EAB9C78746782
{
public:

public:
};


// Wamp_<Close>d__30
struct  U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 
{
public:
	// System.Int32 Wamp_<Close>d__30::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder Wamp_<Close>d__30::<>t__builder
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  ___U3CU3Et__builder_1;
	// Wamp Wamp_<Close>d__30::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_2;
	// System.Int32 Wamp_<Close>d__30::timeout
	int32_t ___timeout_3;
	// System.Runtime.CompilerServices.TaskAwaiter Wamp_<Close>d__30::<>u__1
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  ___U3CU3Eu__1_4;
	// System.Runtime.CompilerServices.TaskAwaiter`1<Wamp_Response> Wamp_<Close>d__30::<>u__2
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  ___U3CU3Eu__2_5;
	// System.Threading.CancellationTokenSource Wamp_<Close>d__30::<cts>5__2
	CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * ___U3CctsU3E5__2_6;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5, ___U3CU3E4__this_2)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_3() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5, ___timeout_3)); }
	inline int32_t get_timeout_3() const { return ___timeout_3; }
	inline int32_t* get_address_of_timeout_3() { return &___timeout_3; }
	inline void set_timeout_3(int32_t value)
	{
		___timeout_3 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_4() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5, ___U3CU3Eu__1_4)); }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  get_U3CU3Eu__1_4() const { return ___U3CU3Eu__1_4; }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * get_address_of_U3CU3Eu__1_4() { return &___U3CU3Eu__1_4; }
	inline void set_U3CU3Eu__1_4(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  value)
	{
		___U3CU3Eu__1_4 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_4))->___m_task_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CU3Eu__2_5() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5, ___U3CU3Eu__2_5)); }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  get_U3CU3Eu__2_5() const { return ___U3CU3Eu__2_5; }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * get_address_of_U3CU3Eu__2_5() { return &___U3CU3Eu__2_5; }
	inline void set_U3CU3Eu__2_5(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  value)
	{
		___U3CU3Eu__2_5 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__2_5))->___m_task_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CctsU3E5__2_6() { return static_cast<int32_t>(offsetof(U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5, ___U3CctsU3E5__2_6)); }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * get_U3CctsU3E5__2_6() const { return ___U3CctsU3E5__2_6; }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE ** get_address_of_U3CctsU3E5__2_6() { return &___U3CctsU3E5__2_6; }
	inline void set_U3CctsU3E5__2_6(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * value)
	{
		___U3CctsU3E5__2_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CctsU3E5__2_6), (void*)value);
	}
};


// Wamp_<Connect>d__27
struct  U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 
{
public:
	// System.Int32 Wamp_<Connect>d__27::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder Wamp_<Connect>d__27::<>t__builder
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  ___U3CU3Et__builder_1;
	// System.String Wamp_<Connect>d__27::host
	String_t* ___host_2;
	// Wamp Wamp_<Connect>d__27::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_3;
	// System.Int32 Wamp_<Connect>d__27::timeout
	int32_t ___timeout_4;
	// System.Threading.CancellationTokenSource Wamp_<Connect>d__27::<cts>5__2
	CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * ___U3CctsU3E5__2_5;
	// System.Runtime.CompilerServices.TaskAwaiter Wamp_<Connect>d__27::<>u__1
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  ___U3CU3Eu__1_6;
	// System.Runtime.CompilerServices.TaskAwaiter`1<Wamp_Response> Wamp_<Connect>d__27::<>u__2
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  ___U3CU3Eu__2_7;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_host_2() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6, ___host_2)); }
	inline String_t* get_host_2() const { return ___host_2; }
	inline String_t** get_address_of_host_2() { return &___host_2; }
	inline void set_host_2(String_t* value)
	{
		___host_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___host_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_3() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6, ___U3CU3E4__this_3)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_3() const { return ___U3CU3E4__this_3; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_3() { return &___U3CU3E4__this_3; }
	inline void set_U3CU3E4__this_3(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_3), (void*)value);
	}

	inline static int32_t get_offset_of_timeout_4() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6, ___timeout_4)); }
	inline int32_t get_timeout_4() const { return ___timeout_4; }
	inline int32_t* get_address_of_timeout_4() { return &___timeout_4; }
	inline void set_timeout_4(int32_t value)
	{
		___timeout_4 = value;
	}

	inline static int32_t get_offset_of_U3CctsU3E5__2_5() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6, ___U3CctsU3E5__2_5)); }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * get_U3CctsU3E5__2_5() const { return ___U3CctsU3E5__2_5; }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE ** get_address_of_U3CctsU3E5__2_5() { return &___U3CctsU3E5__2_5; }
	inline void set_U3CctsU3E5__2_5(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * value)
	{
		___U3CctsU3E5__2_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CctsU3E5__2_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_6() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6, ___U3CU3Eu__1_6)); }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  get_U3CU3Eu__1_6() const { return ___U3CU3Eu__1_6; }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * get_address_of_U3CU3Eu__1_6() { return &___U3CU3Eu__1_6; }
	inline void set_U3CU3Eu__1_6(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  value)
	{
		___U3CU3Eu__1_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_6))->___m_task_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CU3Eu__2_7() { return static_cast<int32_t>(offsetof(U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6, ___U3CU3Eu__2_7)); }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  get_U3CU3Eu__2_7() const { return ___U3CU3Eu__2_7; }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * get_address_of_U3CU3Eu__2_7() { return &___U3CU3Eu__2_7; }
	inline void set_U3CU3Eu__2_7(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  value)
	{
		___U3CU3Eu__2_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__2_7))->___m_task_0), (void*)NULL);
	}
};


// Wamp_<Send>d__16
struct  U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A 
{
public:
	// System.Int32 Wamp_<Send>d__16::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder Wamp_<Send>d__16::<>t__builder
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  ___U3CU3Et__builder_1;
	// System.Int32 Wamp_<Send>d__16::timeout
	int32_t ___timeout_2;
	// System.String Wamp_<Send>d__16::msg
	String_t* ___msg_3;
	// Wamp Wamp_<Send>d__16::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_4;
	// System.Threading.CancellationTokenSource Wamp_<Send>d__16::<cts>5__2
	CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * ___U3CctsU3E5__2_5;
	// System.Runtime.CompilerServices.TaskAwaiter Wamp_<Send>d__16::<>u__1
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  ___U3CU3Eu__1_6;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_timeout_2() { return static_cast<int32_t>(offsetof(U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A, ___timeout_2)); }
	inline int32_t get_timeout_2() const { return ___timeout_2; }
	inline int32_t* get_address_of_timeout_2() { return &___timeout_2; }
	inline void set_timeout_2(int32_t value)
	{
		___timeout_2 = value;
	}

	inline static int32_t get_offset_of_msg_3() { return static_cast<int32_t>(offsetof(U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A, ___msg_3)); }
	inline String_t* get_msg_3() const { return ___msg_3; }
	inline String_t** get_address_of_msg_3() { return &___msg_3; }
	inline void set_msg_3(String_t* value)
	{
		___msg_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___msg_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_4() { return static_cast<int32_t>(offsetof(U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A, ___U3CU3E4__this_4)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_4() const { return ___U3CU3E4__this_4; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_4() { return &___U3CU3E4__this_4; }
	inline void set_U3CU3E4__this_4(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_4), (void*)value);
	}

	inline static int32_t get_offset_of_U3CctsU3E5__2_5() { return static_cast<int32_t>(offsetof(U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A, ___U3CctsU3E5__2_5)); }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * get_U3CctsU3E5__2_5() const { return ___U3CctsU3E5__2_5; }
	inline CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE ** get_address_of_U3CctsU3E5__2_5() { return &___U3CctsU3E5__2_5; }
	inline void set_U3CctsU3E5__2_5(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * value)
	{
		___U3CctsU3E5__2_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CctsU3E5__2_5), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_6() { return static_cast<int32_t>(offsetof(U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A, ___U3CU3Eu__1_6)); }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  get_U3CU3Eu__1_6() const { return ___U3CU3Eu__1_6; }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * get_address_of_U3CU3Eu__1_6() { return &___U3CU3Eu__1_6; }
	inline void set_U3CU3Eu__1_6(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  value)
	{
		___U3CU3Eu__1_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_6))->___m_task_0), (void*)NULL);
	}
};


// Wamp_<Unsubscribe>d__36
struct  U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 
{
public:
	// System.Int32 Wamp_<Unsubscribe>d__36::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder Wamp_<Unsubscribe>d__36::<>t__builder
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  ___U3CU3Et__builder_1;
	// Wamp Wamp_<Unsubscribe>d__36::<>4__this
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * ___U3CU3E4__this_2;
	// System.UInt32 Wamp_<Unsubscribe>d__36::subscriptionId
	uint32_t ___subscriptionId_3;
	// System.Int32 Wamp_<Unsubscribe>d__36::timeout
	int32_t ___timeout_4;
	// System.Int32 Wamp_<Unsubscribe>d__36::<requestId>5__2
	int32_t ___U3CrequestIdU3E5__2_5;
	// System.Runtime.CompilerServices.TaskAwaiter Wamp_<Unsubscribe>d__36::<>u__1
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  ___U3CU3Eu__1_6;
	// System.Runtime.CompilerServices.TaskAwaiter`1<Wamp_Response> Wamp_<Unsubscribe>d__36::<>u__2
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  ___U3CU3Eu__2_7;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3Et__builder_1() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2, ___U3CU3Et__builder_1)); }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  get_U3CU3Et__builder_1() const { return ___U3CU3Et__builder_1; }
	inline AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * get_address_of_U3CU3Et__builder_1() { return &___U3CU3Et__builder_1; }
	inline void set_U3CU3Et__builder_1(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  value)
	{
		___U3CU3Et__builder_1 = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_stateMachine_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_coreState_1))->___m_defaultContextAction_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((&(((&___U3CU3Et__builder_1))->___m_builder_1))->___m_task_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2, ___U3CU3E4__this_2)); }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_subscriptionId_3() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2, ___subscriptionId_3)); }
	inline uint32_t get_subscriptionId_3() const { return ___subscriptionId_3; }
	inline uint32_t* get_address_of_subscriptionId_3() { return &___subscriptionId_3; }
	inline void set_subscriptionId_3(uint32_t value)
	{
		___subscriptionId_3 = value;
	}

	inline static int32_t get_offset_of_timeout_4() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2, ___timeout_4)); }
	inline int32_t get_timeout_4() const { return ___timeout_4; }
	inline int32_t* get_address_of_timeout_4() { return &___timeout_4; }
	inline void set_timeout_4(int32_t value)
	{
		___timeout_4 = value;
	}

	inline static int32_t get_offset_of_U3CrequestIdU3E5__2_5() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2, ___U3CrequestIdU3E5__2_5)); }
	inline int32_t get_U3CrequestIdU3E5__2_5() const { return ___U3CrequestIdU3E5__2_5; }
	inline int32_t* get_address_of_U3CrequestIdU3E5__2_5() { return &___U3CrequestIdU3E5__2_5; }
	inline void set_U3CrequestIdU3E5__2_5(int32_t value)
	{
		___U3CrequestIdU3E5__2_5 = value;
	}

	inline static int32_t get_offset_of_U3CU3Eu__1_6() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2, ___U3CU3Eu__1_6)); }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  get_U3CU3Eu__1_6() const { return ___U3CU3Eu__1_6; }
	inline TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * get_address_of_U3CU3Eu__1_6() { return &___U3CU3Eu__1_6; }
	inline void set_U3CU3Eu__1_6(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  value)
	{
		___U3CU3Eu__1_6 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__1_6))->___m_task_0), (void*)NULL);
	}

	inline static int32_t get_offset_of_U3CU3Eu__2_7() { return static_cast<int32_t>(offsetof(U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2, ___U3CU3Eu__2_7)); }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  get_U3CU3Eu__2_7() const { return ___U3CU3Eu__2_7; }
	inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * get_address_of_U3CU3Eu__2_7() { return &___U3CU3Eu__2_7; }
	inline void set_U3CU3Eu__2_7(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  value)
	{
		___U3CU3Eu__2_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___U3CU3Eu__2_7))->___m_task_0), (void*)NULL);
	}
};


// Wamp_DisconnectedHandler
struct  DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3  : public MulticastDelegate_t
{
public:

public:
};


// Wamp_PublishHandler
struct  PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682  : public MulticastDelegate_t
{
public:

public:
};


// WwiseChildModifiedInfo
struct  WwiseChildModifiedInfo_t3C189D93FA4E1E9D3E7798FA5FF9644BA5241B7D  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:
	// WwiseObjectInfoJsonObject WwiseChildModifiedInfo::parent
	WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * ___parent_0;
	// WwiseObjectInfoJsonObject WwiseChildModifiedInfo::child
	WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * ___child_1;
	// WwiseObjectInfo WwiseChildModifiedInfo::parentInfo
	WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  ___parentInfo_2;
	// WwiseObjectInfo WwiseChildModifiedInfo::childInfo
	WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  ___childInfo_3;

public:
	inline static int32_t get_offset_of_parent_0() { return static_cast<int32_t>(offsetof(WwiseChildModifiedInfo_t3C189D93FA4E1E9D3E7798FA5FF9644BA5241B7D, ___parent_0)); }
	inline WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * get_parent_0() const { return ___parent_0; }
	inline WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 ** get_address_of_parent_0() { return &___parent_0; }
	inline void set_parent_0(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * value)
	{
		___parent_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___parent_0), (void*)value);
	}

	inline static int32_t get_offset_of_child_1() { return static_cast<int32_t>(offsetof(WwiseChildModifiedInfo_t3C189D93FA4E1E9D3E7798FA5FF9644BA5241B7D, ___child_1)); }
	inline WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * get_child_1() const { return ___child_1; }
	inline WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 ** get_address_of_child_1() { return &___child_1; }
	inline void set_child_1(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * value)
	{
		___child_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___child_1), (void*)value);
	}

	inline static int32_t get_offset_of_parentInfo_2() { return static_cast<int32_t>(offsetof(WwiseChildModifiedInfo_t3C189D93FA4E1E9D3E7798FA5FF9644BA5241B7D, ___parentInfo_2)); }
	inline WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  get_parentInfo_2() const { return ___parentInfo_2; }
	inline WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562 * get_address_of_parentInfo_2() { return &___parentInfo_2; }
	inline void set_parentInfo_2(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  value)
	{
		___parentInfo_2 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___parentInfo_2))->___name_2), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___parentInfo_2))->___path_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___parentInfo_2))->___workUnitType_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___parentInfo_2))->___filePath_7), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___parentInfo_2))->___soundbankBnkFilePath_8), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_childInfo_3() { return static_cast<int32_t>(offsetof(WwiseChildModifiedInfo_t3C189D93FA4E1E9D3E7798FA5FF9644BA5241B7D, ___childInfo_3)); }
	inline WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  get_childInfo_3() const { return ___childInfo_3; }
	inline WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562 * get_address_of_childInfo_3() { return &___childInfo_3; }
	inline void set_childInfo_3(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  value)
	{
		___childInfo_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___childInfo_3))->___name_2), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___childInfo_3))->___path_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___childInfo_3))->___workUnitType_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___childInfo_3))->___filePath_7), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___childInfo_3))->___soundbankBnkFilePath_8), (void*)NULL);
		#endif
	}
};


// WwiseRenameInfo
struct  WwiseRenameInfo_t08FA05A48049742662096652F0A5B40DDE5B4C31  : public JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B
{
public:
	// WwiseObjectInfoJsonObject WwiseRenameInfo::object
	WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * ___object_0;
	// System.String WwiseRenameInfo::newName
	String_t* ___newName_1;
	// System.String WwiseRenameInfo::oldName
	String_t* ___oldName_2;
	// WwiseObjectInfo WwiseRenameInfo::objectInfo
	WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  ___objectInfo_3;

public:
	inline static int32_t get_offset_of_object_0() { return static_cast<int32_t>(offsetof(WwiseRenameInfo_t08FA05A48049742662096652F0A5B40DDE5B4C31, ___object_0)); }
	inline WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * get_object_0() const { return ___object_0; }
	inline WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 ** get_address_of_object_0() { return &___object_0; }
	inline void set_object_0(WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * value)
	{
		___object_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___object_0), (void*)value);
	}

	inline static int32_t get_offset_of_newName_1() { return static_cast<int32_t>(offsetof(WwiseRenameInfo_t08FA05A48049742662096652F0A5B40DDE5B4C31, ___newName_1)); }
	inline String_t* get_newName_1() const { return ___newName_1; }
	inline String_t** get_address_of_newName_1() { return &___newName_1; }
	inline void set_newName_1(String_t* value)
	{
		___newName_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___newName_1), (void*)value);
	}

	inline static int32_t get_offset_of_oldName_2() { return static_cast<int32_t>(offsetof(WwiseRenameInfo_t08FA05A48049742662096652F0A5B40DDE5B4C31, ___oldName_2)); }
	inline String_t* get_oldName_2() const { return ___oldName_2; }
	inline String_t** get_address_of_oldName_2() { return &___oldName_2; }
	inline void set_oldName_2(String_t* value)
	{
		___oldName_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___oldName_2), (void*)value);
	}

	inline static int32_t get_offset_of_objectInfo_3() { return static_cast<int32_t>(offsetof(WwiseRenameInfo_t08FA05A48049742662096652F0A5B40DDE5B4C31, ___objectInfo_3)); }
	inline WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  get_objectInfo_3() const { return ___objectInfo_3; }
	inline WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562 * get_address_of_objectInfo_3() { return &___objectInfo_3; }
	inline void set_objectInfo_3(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  value)
	{
		___objectInfo_3 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___objectInfo_3))->___name_2), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___objectInfo_3))->___path_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___objectInfo_3))->___workUnitType_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___objectInfo_3))->___filePath_7), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___objectInfo_3))->___soundbankBnkFilePath_8), (void*)NULL);
		#endif
	}
};


// System.ComponentModel.Win32Exception
struct  Win32Exception_tB05BE97AB4CADD54DF96C0109689F0ECA7517668  : public ExternalException_t68841FD169C0CB00CC950EDA7E2A59540D65B1CE
{
public:
	// System.Int32 System.ComponentModel.Win32Exception::nativeErrorCode
	int32_t ___nativeErrorCode_17;

public:
	inline static int32_t get_offset_of_nativeErrorCode_17() { return static_cast<int32_t>(offsetof(Win32Exception_tB05BE97AB4CADD54DF96C0109689F0ECA7517668, ___nativeErrorCode_17)); }
	inline int32_t get_nativeErrorCode_17() const { return ___nativeErrorCode_17; }
	inline int32_t* get_address_of_nativeErrorCode_17() { return &___nativeErrorCode_17; }
	inline void set_nativeErrorCode_17(int32_t value)
	{
		___nativeErrorCode_17 = value;
	}
};

struct Win32Exception_tB05BE97AB4CADD54DF96C0109689F0ECA7517668_StaticFields
{
public:
	// System.Boolean System.ComponentModel.Win32Exception::s_ErrorMessagesInitialized
	bool ___s_ErrorMessagesInitialized_18;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.String> System.ComponentModel.Win32Exception::s_ErrorMessage
	Dictionary_2_t4EFE6A1D6502662B911688316C6920444A18CF0C * ___s_ErrorMessage_19;

public:
	inline static int32_t get_offset_of_s_ErrorMessagesInitialized_18() { return static_cast<int32_t>(offsetof(Win32Exception_tB05BE97AB4CADD54DF96C0109689F0ECA7517668_StaticFields, ___s_ErrorMessagesInitialized_18)); }
	inline bool get_s_ErrorMessagesInitialized_18() const { return ___s_ErrorMessagesInitialized_18; }
	inline bool* get_address_of_s_ErrorMessagesInitialized_18() { return &___s_ErrorMessagesInitialized_18; }
	inline void set_s_ErrorMessagesInitialized_18(bool value)
	{
		___s_ErrorMessagesInitialized_18 = value;
	}

	inline static int32_t get_offset_of_s_ErrorMessage_19() { return static_cast<int32_t>(offsetof(Win32Exception_tB05BE97AB4CADD54DF96C0109689F0ECA7517668_StaticFields, ___s_ErrorMessage_19)); }
	inline Dictionary_2_t4EFE6A1D6502662B911688316C6920444A18CF0C * get_s_ErrorMessage_19() const { return ___s_ErrorMessage_19; }
	inline Dictionary_2_t4EFE6A1D6502662B911688316C6920444A18CF0C ** get_address_of_s_ErrorMessage_19() { return &___s_ErrorMessage_19; }
	inline void set_s_ErrorMessage_19(Dictionary_2_t4EFE6A1D6502662B911688316C6920444A18CF0C * value)
	{
		___s_ErrorMessage_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_ErrorMessage_19), (void*)value);
	}
};


// System.Threading.Tasks.TaskCanceledException
struct  TaskCanceledException_tB1E5209054F302F814E18BBCACDF6546BAF2EC48  : public OperationCanceledException_tD28B1AE59ACCE4D46333BFE398395B8D75D76A90
{
public:
	// System.Threading.Tasks.Task System.Threading.Tasks.TaskCanceledException::m_canceledTask
	Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * ___m_canceledTask_18;

public:
	inline static int32_t get_offset_of_m_canceledTask_18() { return static_cast<int32_t>(offsetof(TaskCanceledException_tB1E5209054F302F814E18BBCACDF6546BAF2EC48, ___m_canceledTask_18)); }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * get_m_canceledTask_18() const { return ___m_canceledTask_18; }
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 ** get_address_of_m_canceledTask_18() { return &___m_canceledTask_18; }
	inline void set_m_canceledTask_18(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * value)
	{
		___m_canceledTask_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_canceledTask_18), (void*)value);
	}
};


// System.Net.WebSockets.WebSocketException
struct  WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B  : public Win32Exception_tB05BE97AB4CADD54DF96C0109689F0ECA7517668
{
public:
	// System.Net.WebSockets.WebSocketError System.Net.WebSockets.WebSocketException::_webSocketErrorCode
	int32_t ____webSocketErrorCode_20;

public:
	inline static int32_t get_offset_of__webSocketErrorCode_20() { return static_cast<int32_t>(offsetof(WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B, ____webSocketErrorCode_20)); }
	inline int32_t get__webSocketErrorCode_20() const { return ____webSocketErrorCode_20; }
	inline int32_t* get_address_of__webSocketErrorCode_20() { return &____webSocketErrorCode_20; }
	inline void set__webSocketErrorCode_20(int32_t value)
	{
		____webSocketErrorCode_20 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// System.String[]
struct StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) String_t* m_Items[1];

public:
	inline String_t* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline String_t** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, String_t* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline String_t* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline String_t** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, String_t* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// System.Object[]
struct ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) RuntimeObject * m_Items[1];

public:
	inline RuntimeObject * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, RuntimeObject * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline RuntimeObject * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, RuntimeObject * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// System.Threading.Tasks.Task[]
struct TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * m_Items[1];

public:
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) uint8_t m_Items[1];

public:
	inline uint8_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline uint8_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, uint8_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline uint8_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline uint8_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, uint8_t value)
	{
		m_Items[index] = value;
	}
};
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Delegate_t * m_Items[1];

public:
	inline Delegate_t * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Delegate_t ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Delegate_t * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Delegate_t * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Delegate_t ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Delegate_t * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};


// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<AkWaapiClient/<Connect>d__4>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_mF16437EE3964A0173C4ACD6C55A8A527F10F6357_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<AkWaapiClient/<Close>d__6>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mC26FDDD09F7C37DC8CCAB604721FE4F6DC561F89_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * ___stateMachine0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::Create()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663  AsyncTaskMethodBuilder_1_Create_mC7806A5C115ED2239A5073313AA3564D8244156E_gshared (const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::Start<AkWaapiClient/<Call>d__8>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_m362FF7DEAF1731C68DADD5FE96A0C37771765483_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * ___stateMachine0, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::get_Task()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * AsyncTaskMethodBuilder_1_get_Task_m19C5664D70C4FC799BEFB8D0FC98E687F97059FA_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, const RuntimeMethod* method);
// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::Create()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  AsyncTaskMethodBuilder_1_Create_mFA0E603D8EEE094438B0465D1E57747E2E12FC70_gshared (const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::Start<AkWaapiClient/<Subscribe>d__9>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_m9E8504336F653A9061842B0CE589D6072249F798_gshared (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * ___stateMachine0, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::get_Task()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * AsyncTaskMethodBuilder_1_get_Task_m157191133E216D7561AD02E894BCA819FD5F98FF_gshared (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<AkWaapiClient/<Unsubscribe>d__10>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_m8DCB5F69062BBD1684327A53545EED187BDE62C7_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * ___stateMachine0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.TaskAwaiter`1<!0> System.Threading.Tasks.Task`1<System.Object>::GetAwaiter()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977  Task_1_GetAwaiter_m9C50610C6F05C1DA9BFA67201CB570F1DE040817_gshared (Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * __this, const RuntimeMethod* method);
// System.Boolean System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>::get_IsCompleted()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TaskAwaiter_1_get_IsCompleted_mBF435C7EFD03FCF7810FC08EEDC5945F80FF88F9_gshared (TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>,AkWaapiClient/<Call>d__8>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_m9F7D25375BCA21356F2661784C82F8518E79B13D_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * ___awaiter0, U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * ___stateMachine1, const RuntimeMethod* method);
// !0 System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>::GetResult()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * TaskAwaiter_1_GetResult_m9E148849CD4747E1BDD831E4FB2D7ECFA13C11C8_gshared (TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::SetException(System.Exception)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetException_m4C0B5462ECCB520FACA3C90B353DF596DAAF586D_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, Exception_t * ___exception0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::SetResult(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetResult_mD7DA7A17DC0610B11A0AAA364C3CA51FEC1271DB_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, RuntimeObject * ___result0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetStateMachine_m5CC21A02320CF3D2DD7894A31123DFD82A428E4C_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AkWaapiClient/<Close>d__6>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mA764FAAB815FCF8AE6EEDC1517B93BDDDA7D35E6_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AkWaapiClient/<Connect>d__4>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_m86930540C6C3B639FB8E3043C372E6B46488F0AD_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * ___stateMachine1, const RuntimeMethod* method);
// System.Runtime.CompilerServices.TaskAwaiter`1<!0> System.Threading.Tasks.Task`1<System.UInt32>::GetAwaiter()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  Task_1_GetAwaiter_m67228F27784EA8C9DF71B165FAB7072A46C28A9E_gshared (Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * __this, const RuntimeMethod* method);
// System.Boolean System.Runtime.CompilerServices.TaskAwaiter`1<System.UInt32>::get_IsCompleted()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TaskAwaiter_1_get_IsCompleted_mD9FB168E3D6034701DE4736347E1B30AE6CCE70F_gshared (TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.UInt32>,AkWaapiClient/<Subscribe>d__9>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_mABEC0D792F8A5AC3256DBC194D55631CC98783FB_gshared (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 * ___awaiter0, U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * ___stateMachine1, const RuntimeMethod* method);
// !0 System.Runtime.CompilerServices.TaskAwaiter`1<System.UInt32>::GetResult()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t TaskAwaiter_1_GetResult_mD575FD03753A3FD916DFF7C9834342D3EEEB0EE8_gshared (TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::SetException(System.Exception)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetException_m4BCFE40068BC66F1C48B5C7C7C9F93F5E48EF00B_gshared (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, Exception_t * ___exception0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::SetResult(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetResult_m887E134B6FD52D8CA2116A466F69BC8E1EA6ED5E_gshared (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, uint32_t ___result0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_SetStateMachine_m2C2B09AB812EDEDAB3C9E89B8A2BF19C4EC8B45F_gshared (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AkWaapiClient/<Unsubscribe>d__10>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_mD436987D09427E1D06EC26E219AD2D10638951B6_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * ___stateMachine1, const RuntimeMethod* method);
// System.Boolean System.Collections.ObjectModel.ReadOnlyDictionary`2<System.Object,System.Int32Enum>::ContainsKey(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ReadOnlyDictionary_2_ContainsKey_mE2D8481B8A943A4DFD191B44B3AA5350CEC7BF1E_gshared (ReadOnlyDictionary_2_tAF15F0D29D44A0C3C9331BB32AE9F536CF149D7C * __this, RuntimeObject * ___key0, const RuntimeMethod* method);
// !1 System.Collections.ObjectModel.ReadOnlyDictionary`2<System.Object,System.Int32Enum>::get_Item(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ReadOnlyDictionary_2_get_Item_mEA07B2EBEC5714297A157CA478B224C0076CF428_gshared (ReadOnlyDictionary_2_tAF15F0D29D44A0C3C9331BB32AE9F536CF149D7C * __this, RuntimeObject * ___key0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Int32Enum,System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dictionary_2__ctor_m80B728B0F4A8176CF1F62C2768D31E6F7838B232_gshared (Dictionary_2_t0D7F3A50EB302696E4E5A19D582D99A8C7F70060 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Int32Enum,System.Object>::Add(!0,!1)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dictionary_2_Add_mB3D9D66F9CFB6CB7013F547768CAE89834974B8F_gshared (Dictionary_2_t0D7F3A50EB302696E4E5A19D582D99A8C7F70060 * __this, int32_t ___key0, RuntimeObject * ___value1, const RuntimeMethod* method);
// System.Void System.Collections.ObjectModel.ReadOnlyDictionary`2<System.Int32Enum,System.Object>::.ctor(System.Collections.Generic.IDictionary`2<!0,!1>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ReadOnlyDictionary_2__ctor_m8B628482E1B0A2958F5997A978B90DF7C316A869_gshared (ReadOnlyDictionary_2_t783ED61F94C7CD46B849752D8E5670724794017E * __this, RuntimeObject* ___dictionary0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dictionary_2__ctor_m2C7E51568033239B506E15E7804A0B8658246498_gshared (Dictionary_2_t32F25F093828AA9F93CB11C2A2B4648FD62A09BA * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Object>::Add(!0,!1)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dictionary_2_Add_mC741BBB0A647C814227953DB9B23CB1BDF571C5B_gshared (Dictionary_2_t32F25F093828AA9F93CB11C2A2B4648FD62A09BA * __this, RuntimeObject * ___key0, RuntimeObject * ___value1, const RuntimeMethod* method);
// System.Void System.Collections.ObjectModel.ReadOnlyDictionary`2<System.Object,System.Object>::.ctor(System.Collections.Generic.IDictionary`2<!0,!1>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ReadOnlyDictionary_2__ctor_mC417F57C7FB9D62B2F8388B52FD3E45955BA160A_gshared (ReadOnlyDictionary_2_t9AB03C58D299BE81D151A5B23097049F7106820C * __this, RuntimeObject* ___dictionary0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Int32Enum>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dictionary_2__ctor_m1C8D9B685C8406F92F3C063FCA11D9AB5F56493E_gshared (Dictionary_2_t15935BA59D5EDF22B5075E957C7C05DEE12E3B57 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Int32Enum>::set_Item(!0,!1)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dictionary_2_set_Item_m0065D5FD414B2D11BC53F897CDDFEEFE8B93875B_gshared (Dictionary_2_t15935BA59D5EDF22B5075E957C7C05DEE12E3B57 * __this, RuntimeObject * ___key0, int32_t ___value1, const RuntimeMethod* method);
// System.Void System.Collections.ObjectModel.ReadOnlyDictionary`2<System.Object,System.Int32Enum>::.ctor(System.Collections.Generic.IDictionary`2<!0,!1>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ReadOnlyDictionary_2__ctor_m8BE1FBD324F6E964BF77911D0EF7F6F41FCC91DA_gshared (ReadOnlyDictionary_2_tAF15F0D29D44A0C3C9331BB32AE9F536CF149D7C * __this, RuntimeObject* ___dictionary0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<Wamp/<Send>d__16>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_Start_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m3BE2ACD6057BFEC9516FD5CA2EC71DD1F46E95FB_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::Start<Wamp/<ReceiveMessage>d__24>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_Start_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_m9E877DEA04729613615309850E05CF23E91A118F_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::Start<Wamp/<Receive>d__25>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_Start_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_mA2E7E1F0956096CE8D81B18FF70AD60203E1B505_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::Start<Wamp/<ReceiveExpect>d__26>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_Start_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_mF6049B47708FBB29E1BDFEE6AF464C1ECC931A8B_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<Wamp/<Connect>d__27>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m83286F1C813B3EF711EFFF20F60DF019DD0EF82A_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<Wamp/<Close>d__30>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m014E726B3574D52F7F9E118E1B7A58DF73336783_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * ___stateMachine0, const RuntimeMethod* method);
// System.Boolean System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,System.Object>::TryGetValue(!0,!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ConcurrentDictionary_2_TryGetValue_m89C9CF866355F7BB41EDDCBB0F1D3026CE7273D6_gshared (ConcurrentDictionary_2_t2CAAD473DB8373A614581938716FED5D21A1DEC1 * __this, uint32_t ___key0, RuntimeObject ** ___value1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::Start<Wamp/<Call>d__34>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mCFD1635DF5FF1599EC400ED06D2D816C3E5A519A_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::Start<Wamp/<Subscribe>d__35>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m4CFDDD929A9A264EF81EAA747130B8946DD69999_gshared (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<Wamp/<Unsubscribe>d__36>(!!0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m9B9904F2786C63840AA72106EF2A750CB549AEA3_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Threading.Tasks.TaskCompletionSource`1<System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TaskCompletionSource_1__ctor_m3A77018A60870C828E549796E331896683B62705_gshared (TaskCompletionSource_1_t6C02642279BC7BF03091A8CB685FC6B4E68BED12 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ConcurrentDictionary_2__ctor_m9A6F57EF5BA973054F37AE56E6B40E944DD4FDA5_gshared (ConcurrentDictionary_2_t2CAAD473DB8373A614581938716FED5D21A1DEC1 * __this, const RuntimeMethod* method);
// !0 System.Threading.Tasks.Task`1<System.Object>::get_Result()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * Task_1_get_Result_m653E95E70604B69D29BC9679AA4588ED82AD01D7_gshared (Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * __this, const RuntimeMethod* method);
// System.Void System.Threading.Tasks.TaskCompletionSource`1<System.Object>::SetResult(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TaskCompletionSource_1_SetResult_m86E11C99226F2BF07334B344F36EE443271B9070_gshared (TaskCompletionSource_1_t6C02642279BC7BF03091A8CB685FC6B4E68BED12 * __this, RuntimeObject * ___result0, const RuntimeMethod* method);
// System.Void System.Threading.Tasks.TaskCompletionSource`1<System.Object>::SetException(System.Exception)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TaskCompletionSource_1_SetException_m32F878B5587E7DA84F6EAD84D297488C300B16E1_gshared (TaskCompletionSource_1_t6C02642279BC7BF03091A8CB685FC6B4E68BED12 * __this, Exception_t * ___exception0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Call>d__34>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mF6AFBF00E8067F0CE905589AB9C5D14D1F83810B_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>,Wamp/<Call>d__34>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mB7E7D2A87A1F10FB3B6927F6EC0D42EEF627DA62_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * ___awaiter0, U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Close>d__30>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mDAC2ADF8AB1E52888B4479666D626F617937E900_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>,Wamp/<Close>d__30>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mF5BBC9EFF014107E99EBF16D634F06C760ADE6E7_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * ___awaiter0, U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Connect>d__27>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m393F31C0EF4CBF441A486F7C6A0D4AB4B58B4286_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>,Wamp/<Connect>d__27>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m220B7939F9FD150B558C3EEC33C5646B580DF4A7_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * ___awaiter0, U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * ___stateMachine1, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<!0> System.Threading.Tasks.TaskCompletionSource`1<System.Object>::get_Task()
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * TaskCompletionSource_1_get_Task_mE3DDBDE4F3FB8A530456D158F4C460E85A4974B9_gshared_inline (TaskCompletionSource_1_t6C02642279BC7BF03091A8CB685FC6B4E68BED12 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>,Wamp/<Receive>d__25>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_m30AEB03D457566947B991E758054ACE94DB895A3_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * ___awaiter0, U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>,Wamp/<ReceiveExpect>d__26>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m515F307519C1D6D6BAC17C9BEB0F2107B1556B48_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * ___awaiter0, U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_mC832F1AC0F814BAEB19175F5D7972A7507508BC3_gshared (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, const RuntimeMethod* method);
// System.Void System.ArraySegment`1<System.Byte>::.ctor(!0[],System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArraySegment_1__ctor_m6305655CDE2F6E154BA79003B66CF61795462804_gshared (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * __this, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___array0, int32_t ___offset1, int32_t ___count2, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.Object>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>,Wamp/<ReceiveMessage>d__24>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_m869EB03758A4A1D5D4EBFB4374B8C354F04E3AAE_gshared (AsyncTaskMethodBuilder_1_t2A9513A084F4B19851B91EF1F22BB57776D35663 * __this, TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * ___awaiter0, U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * ___stateMachine1, const RuntimeMethod* method);
// System.Int32 System.ArraySegment`1<System.Byte>::get_Offset()
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR int32_t ArraySegment_1_get_Offset_m6651443913CC50A02AE5D7C4CDC6F6744D39B483_gshared_inline (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * __this, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerable`1<!!0> System.Linq.Enumerable::Skip<System.Byte>(System.Collections.Generic.IEnumerable`1<!!0>,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Enumerable_Skip_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m73025D0C956827AA7A6EA962A50C8B63F69FBBBE_gshared (RuntimeObject* ___source0, int32_t ___count1, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerable`1<!!0> System.Linq.Enumerable::Take<System.Byte>(System.Collections.Generic.IEnumerable`1<!!0>,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Enumerable_Take_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_mFBC4D57366E255AFC2F139800ABAD01A519B2B05_gshared (RuntimeObject* ___source0, int32_t ___count1, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::Add(!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_Add_m6930161974C7504C80F52EC379EF012387D43138_gshared (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, RuntimeObject * ___item0, const RuntimeMethod* method);
// System.Void System.Func`2<System.Object,System.Object>::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Func_2__ctor_mE2AF7615AD18E9CD92B1909285F5EC5DA8D180C8_gshared (Func_2_tE9A60F007AC624EA27BF19DEF4242B7DA2F1C2A4 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerable`1<!!1> System.Linq.Enumerable::SelectMany<System.Object,System.Byte>(System.Collections.Generic.IEnumerable`1<!!0>,System.Func`2<!!0,System.Collections.Generic.IEnumerable`1<!!1>>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Enumerable_SelectMany_TisRuntimeObject_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_mEF1CD215BE4CF70D3F66FF364C0B2778CA5EB598_gshared (RuntimeObject* ___source0, Func_2_tD8DF63D6AF9940CC3BA20B6FAA14B2570E3DEDBE * ___selector1, const RuntimeMethod* method);
// !!0[] System.Linq.Enumerable::ToArray<System.Byte>(System.Collections.Generic.IEnumerable`1<!!0>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* Enumerable_ToArray_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m48AFCA8923688797114AA384B978E290AAAF206B_gshared (RuntimeObject* ___source0, const RuntimeMethod* method);
// System.Void System.ArraySegment`1<System.Byte>::.ctor(!0[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArraySegment_1__ctor_mC699D21C137279D4D9A501143A898CCB0971D382_gshared (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * __this, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___array0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Send>d__16>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m0996EC60B40B2090B23E54881415F88FBE155480_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Subscribe>d__35>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m7F46BD9D275C21386FD4E0DA80512950AFC6587E_gshared (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>,Wamp/<Subscribe>d__35>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m57BB3F5D115E588824DA87484EC6B7F276A8EE22_gshared (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * ___awaiter0, U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * ___stateMachine1, const RuntimeMethod* method);
// System.Boolean System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,System.Object>::TryAdd(!0,!1)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ConcurrentDictionary_2_TryAdd_m4F1110173D40ADCBAB4393F0587D3AA607174FDE_gshared (ConcurrentDictionary_2_t2CAAD473DB8373A614581938716FED5D21A1DEC1 * __this, uint32_t ___key0, RuntimeObject * ___value1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Unsubscribe>d__36>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m553F9508C8EF12D8C31A1E1B935D79855E6FF52C_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * ___stateMachine1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Object>,Wamp/<Unsubscribe>d__36>(!!0&,!!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m3E2EC9F9755076BFDAC850A9DF02962B255D4062_gshared (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977 * ___awaiter0, U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * ___stateMachine1, const RuntimeMethod* method);
// System.Boolean System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,System.Object>::TryRemove(!0,!1&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ConcurrentDictionary_2_TryRemove_mE7E73F60C641310187824F20B776CF05ACBBAF9E_gshared (ConcurrentDictionary_2_t2CAAD473DB8373A614581938716FED5D21A1DEC1 * __this, uint32_t ___key0, RuntimeObject ** ___value1, const RuntimeMethod* method);

// System.Delegate System.Delegate::Combine(System.Delegate,System.Delegate)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Delegate_t * Delegate_Combine_mC25D2F7DECAFBA6D9A2F9EBA8A77063F0658ECF1 (Delegate_t * ___a0, Delegate_t * ___b1, const RuntimeMethod* method);
// System.Delegate System.Delegate::Remove(System.Delegate,System.Delegate)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Delegate_t * Delegate_Remove_m0B0DB7D1B3AF96B71AFAA72BA0EFE32FBBC2932D (Delegate_t * ___source0, Delegate_t * ___value1, const RuntimeMethod* method);
// System.Runtime.CompilerServices.AsyncTaskMethodBuilder System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Create()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  AsyncTaskMethodBuilder_Create_m081DF9A202E7C2F3CF3D41E1E63E63DA18F19FDB (const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<AkWaapiClient/<Connect>d__4>(!!0&)
inline void AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_mF16437EE3964A0173C4ACD6C55A8A527F10F6357 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 *, const RuntimeMethod*))AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_mF16437EE3964A0173C4ACD6C55A8A527F10F6357_gshared)(__this, ___stateMachine0, method);
}
// System.Threading.Tasks.Task System.Runtime.CompilerServices.AsyncTaskMethodBuilder::get_Task()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * AsyncTaskMethodBuilder_get_Task_m3E45BC00F7D224FEA04AB9BF26DB52E131D33022 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, const RuntimeMethod* method);
// System.Void Wamp/DisconnectedHandler::Invoke()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DisconnectedHandler_Invoke_m08F15DEC1D0B8B106737140AF777D9CAEF92E79E (DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<AkWaapiClient/<Close>d__6>(!!0&)
inline void AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mC26FDDD09F7C37DC8CCAB604721FE4F6DC561F89 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D *, const RuntimeMethod*))AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mC26FDDD09F7C37DC8CCAB604721FE4F6DC561F89_gshared)(__this, ___stateMachine0, method);
}
// System.Boolean Wamp::IsConnected()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Wamp_IsConnected_m937F67F3943693AE69F82BA0897E18C163A0B70C (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method);
// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::Create()
inline AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  AsyncTaskMethodBuilder_1_Create_m4CACDA7CCC96C431E5426E670B268CC6FDF86695 (const RuntimeMethod* method)
{
	return ((  AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  (*) (const RuntimeMethod*))AsyncTaskMethodBuilder_1_Create_mC7806A5C115ED2239A5073313AA3564D8244156E_gshared)(method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::Start<AkWaapiClient/<Call>d__8>(!!0&)
inline void AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_mF1115D2856D6D60A689700396433A6E0BFEF1B44 (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * __this, U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *, U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_m362FF7DEAF1731C68DADD5FE96A0C37771765483_gshared)(__this, ___stateMachine0, method);
}
// System.Threading.Tasks.Task`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::get_Task()
inline Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * AsyncTaskMethodBuilder_1_get_Task_mB005567F7203FC44DD0AE1150FFC92706B8E2BB4 (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * __this, const RuntimeMethod* method)
{
	return ((  Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * (*) (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_get_Task_m19C5664D70C4FC799BEFB8D0FC98E687F97059FA_gshared)(__this, method);
}
// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::Create()
inline AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  AsyncTaskMethodBuilder_1_Create_mFA0E603D8EEE094438B0465D1E57747E2E12FC70 (const RuntimeMethod* method)
{
	return ((  AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  (*) (const RuntimeMethod*))AsyncTaskMethodBuilder_1_Create_mFA0E603D8EEE094438B0465D1E57747E2E12FC70_gshared)(method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::Start<AkWaapiClient/<Subscribe>d__9>(!!0&)
inline void AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_m9E8504336F653A9061842B0CE589D6072249F798 (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *, U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_m9E8504336F653A9061842B0CE589D6072249F798_gshared)(__this, ___stateMachine0, method);
}
// System.Threading.Tasks.Task`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::get_Task()
inline Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * AsyncTaskMethodBuilder_1_get_Task_m157191133E216D7561AD02E894BCA819FD5F98FF (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, const RuntimeMethod* method)
{
	return ((  Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * (*) (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_get_Task_m157191133E216D7561AD02E894BCA819FD5F98FF_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<AkWaapiClient/<Unsubscribe>d__10>(!!0&)
inline void AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_m8DCB5F69062BBD1684327A53545EED187BDE62C7 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D *, const RuntimeMethod*))AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_m8DCB5F69062BBD1684327A53545EED187BDE62C7_gshared)(__this, ___stateMachine0, method);
}
// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0 (RuntimeObject * __this, const RuntimeMethod* method);
// System.Void Wamp/WampNotConnectedException::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD (WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F * __this, String_t* ___message0, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<System.String> Wamp::Call(System.String,System.String,System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * Wamp_Call_mAE552B01EB08CE7275EEDD97710E512589D61B33 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___uri0, String_t* ___args1, String_t* ___options2, int32_t ___timeout3, const RuntimeMethod* method);
// System.Runtime.CompilerServices.TaskAwaiter`1<!0> System.Threading.Tasks.Task`1<System.String>::GetAwaiter()
inline TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214  Task_1_GetAwaiter_m7A7CC7C265752869A4FE28A21A3780AE1814DC56 (Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * __this, const RuntimeMethod* method)
{
	return ((  TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214  (*) (Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 *, const RuntimeMethod*))Task_1_GetAwaiter_m9C50610C6F05C1DA9BFA67201CB570F1DE040817_gshared)(__this, method);
}
// System.Boolean System.Runtime.CompilerServices.TaskAwaiter`1<System.String>::get_IsCompleted()
inline bool TaskAwaiter_1_get_IsCompleted_m1B663832F61F0CC68E324522D851F61F4D9DCE13 (TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 *, const RuntimeMethod*))TaskAwaiter_1_get_IsCompleted_mBF435C7EFD03FCF7810FC08EEDC5945F80FF88F9_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.String>,AkWaapiClient/<Call>d__8>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_mD1999A0F69B3FB48161783859F369FDCA943E7ED (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * __this, TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 * ___awaiter0, U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *, TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 *, U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_m9F7D25375BCA21356F2661784C82F8518E79B13D_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// !0 System.Runtime.CompilerServices.TaskAwaiter`1<System.String>::GetResult()
inline String_t* TaskAwaiter_1_GetResult_m09DDE7E4E666D55579B249C10764EFC380DAB78B (TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 * __this, const RuntimeMethod* method)
{
	return ((  String_t* (*) (TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 *, const RuntimeMethod*))TaskAwaiter_1_GetResult_m9E148849CD4747E1BDD831E4FB2D7ECFA13C11C8_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::SetException(System.Exception)
inline void AsyncTaskMethodBuilder_1_SetException_m7EC0D7D4B3431CA02400760ADA732A416EAEFB2D (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * __this, Exception_t * ___exception0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *, Exception_t *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetException_m4C0B5462ECCB520FACA3C90B353DF596DAAF586D_gshared)(__this, ___exception0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::SetResult(!0)
inline void AsyncTaskMethodBuilder_1_SetResult_m44836E9953D99A304CCB8725A8E47453725FFE9B (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * __this, String_t* ___result0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *, String_t*, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetResult_mD7DA7A17DC0610B11A0AAA364C3CA51FEC1271DB_gshared)(__this, ___result0, method);
}
// System.Void AkWaapiClient/<Call>d__8::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3 (U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
inline void AsyncTaskMethodBuilder_1_SetStateMachine_m83945BA8843F53C1C9ED18D4B312FFF9A24BB9EB (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *, RuntimeObject*, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetStateMachine_m5CC21A02320CF3D2DD7894A31123DFD82A428E4C_gshared)(__this, ___stateMachine0, method);
}
// System.Void AkWaapiClient/<Call>d__8::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCallU3Ed__8_SetStateMachine_mD2692F6222738E5FB87B23429B8DD0B43F651FDC (U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Threading.Tasks.Task Wamp::Close(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * Wamp_Close_m8607EFADFFC175CC0825312F7EFA8E175FA39B74 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, int32_t ___timeout0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.TaskAwaiter System.Threading.Tasks.Task::GetAwaiter()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C (Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * __this, const RuntimeMethod* method);
// System.Boolean System.Runtime.CompilerServices.TaskAwaiter::get_IsCompleted()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87 (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AkWaapiClient/<Close>d__6>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mA764FAAB815FCF8AE6EEDC1517B93BDDDA7D35E6 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *, U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mA764FAAB815FCF8AE6EEDC1517B93BDDDA7D35E6_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void System.Runtime.CompilerServices.TaskAwaiter::GetResult()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * __this, const RuntimeMethod* method);
// System.Void Wamp/DisconnectedHandler::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DisconnectedHandler__ctor_m742456B3847D7F450EEFBD2053B6C43C3D272C80 (DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method);
// System.Void Wamp::remove_Disconnected(Wamp/DisconnectedHandler)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_remove_Disconnected_m733F63A5B3D9B63CA05DB0B31C6BE3C9456D7D9F (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * ___value0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::SetException(System.Exception)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_SetException_m370C484922A63A6EF96E241D1370B8814F1F2D6B (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, Exception_t * ___exception0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::SetResult()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_SetResult_m151016FB698F3BB34A73BAE693A97513A7E4C838 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, const RuntimeMethod* method);
// System.Void AkWaapiClient/<Close>d__6::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517 (U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AsyncTaskMethodBuilder_SetStateMachine_mB5DD68F7C49EA6D452AEBA02B1B98AED898C3C25 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void AkWaapiClient/<Close>d__6::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCloseU3Ed__6_SetStateMachine_m55135EC1DC2BD15058D218A67C6AB2019D6653FE (U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void Wamp::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp__ctor_mCD0D3AC4AB87B0AC898D448724AB0568594D6193 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method);
// System.Void Wamp::add_Disconnected(Wamp/DisconnectedHandler)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_add_Disconnected_mBAA1A70AD8CE39B3A45DB824FB26FF9C2C11F143 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * ___value0, const RuntimeMethod* method);
// System.Threading.Tasks.Task Wamp::Connect(System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * Wamp_Connect_m091D964EE6A72E12FA0905681BF78AD05D9D7FAB (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___host0, int32_t ___timeout1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AkWaapiClient/<Connect>d__4>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_m86930540C6C3B639FB8E3043C372E6B46488F0AD (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *, U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_m86930540C6C3B639FB8E3043C372E6B46488F0AD_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void AkWaapiClient/<Connect>d__4::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CConnectU3Ed__4_MoveNext_m13F3495E6D4BDE5F1C839110864B68AB3F5B7BB6 (U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * __this, const RuntimeMethod* method);
// System.Void AkWaapiClient/<Connect>d__4::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CConnectU3Ed__4_SetStateMachine_mDF27AC5C9A5B8B3E4254E946CBB2F67107F6F757 (U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<System.UInt32> Wamp::Subscribe(System.String,System.String,Wamp/PublishHandler,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * Wamp_Subscribe_mC841A9CDF1DA84F41596A6E4E087CB13C8AF4F40 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___topic0, String_t* ___options1, PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * ___publishEvent2, int32_t ___timeout3, const RuntimeMethod* method);
// System.Runtime.CompilerServices.TaskAwaiter`1<!0> System.Threading.Tasks.Task`1<System.UInt32>::GetAwaiter()
inline TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  Task_1_GetAwaiter_m67228F27784EA8C9DF71B165FAB7072A46C28A9E (Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * __this, const RuntimeMethod* method)
{
	return ((  TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  (*) (Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F *, const RuntimeMethod*))Task_1_GetAwaiter_m67228F27784EA8C9DF71B165FAB7072A46C28A9E_gshared)(__this, method);
}
// System.Boolean System.Runtime.CompilerServices.TaskAwaiter`1<System.UInt32>::get_IsCompleted()
inline bool TaskAwaiter_1_get_IsCompleted_mD9FB168E3D6034701DE4736347E1B30AE6CCE70F (TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 *, const RuntimeMethod*))TaskAwaiter_1_get_IsCompleted_mD9FB168E3D6034701DE4736347E1B30AE6CCE70F_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.UInt32>,AkWaapiClient/<Subscribe>d__9>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_mABEC0D792F8A5AC3256DBC194D55631CC98783FB (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 * ___awaiter0, U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *, TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 *, U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_mABEC0D792F8A5AC3256DBC194D55631CC98783FB_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// !0 System.Runtime.CompilerServices.TaskAwaiter`1<System.UInt32>::GetResult()
inline uint32_t TaskAwaiter_1_GetResult_mD575FD03753A3FD916DFF7C9834342D3EEEB0EE8 (TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 * __this, const RuntimeMethod* method)
{
	return ((  uint32_t (*) (TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 *, const RuntimeMethod*))TaskAwaiter_1_GetResult_mD575FD03753A3FD916DFF7C9834342D3EEEB0EE8_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::SetException(System.Exception)
inline void AsyncTaskMethodBuilder_1_SetException_m4BCFE40068BC66F1C48B5C7C7C9F93F5E48EF00B (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, Exception_t * ___exception0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *, Exception_t *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetException_m4BCFE40068BC66F1C48B5C7C7C9F93F5E48EF00B_gshared)(__this, ___exception0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::SetResult(!0)
inline void AsyncTaskMethodBuilder_1_SetResult_m887E134B6FD52D8CA2116A466F69BC8E1EA6ED5E (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, uint32_t ___result0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *, uint32_t, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetResult_m887E134B6FD52D8CA2116A466F69BC8E1EA6ED5E_gshared)(__this, ___result0, method);
}
// System.Void AkWaapiClient/<Subscribe>d__9::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760 (U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
inline void AsyncTaskMethodBuilder_1_SetStateMachine_m2C2B09AB812EDEDAB3C9E89B8A2BF19C4EC8B45F (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *, RuntimeObject*, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetStateMachine_m2C2B09AB812EDEDAB3C9E89B8A2BF19C4EC8B45F_gshared)(__this, ___stateMachine0, method);
}
// System.Void AkWaapiClient/<Subscribe>d__9::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSubscribeU3Ed__9_SetStateMachine_m5AD4A356DAE70F2EC5F1BB8257BEEF5008C4117F (U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Threading.Tasks.Task Wamp::Unsubscribe(System.UInt32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * Wamp_Unsubscribe_m185B046DAF9E4293617E8A512747B768958ABA6C (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, uint32_t ___subscriptionId0, int32_t ___timeout1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AkWaapiClient/<Unsubscribe>d__10>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_mD436987D09427E1D06EC26E219AD2D10638951B6 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *, U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_mD436987D09427E1D06EC26E219AD2D10638951B6_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void AkWaapiClient/<Unsubscribe>d__10::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4 (U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * __this, const RuntimeMethod* method);
// System.Void AkWaapiClient/<Unsubscribe>d__10::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CUnsubscribeU3Ed__10_SetStateMachine_m3DD99D8798B4C3D9DB2A04230689657AC1139F8C (U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void JsonSerializable::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE (JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B * __this, const RuntimeMethod* method);
// System.Void Args::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9 (Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D * __this, const RuntimeMethod* method);
// System.String UnityEngine.JsonUtility::ToJson(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* JsonUtility_ToJson_m588D3BCFA6FC7FA342FC221D4CB02729E901E573 (RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.Void Options::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Options__ctor_mB2226F341FEBF5B020CF7942625A2F7652485163 (Options_t36565DDE7EEC80CC7827D71EEC8E99E37411D050 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,WwiseObjectType>::ContainsKey(!0)
inline bool ReadOnlyDictionary_2_ContainsKey_m3D72DE0E00E5930D0399B05F47DDED2CBFA58D7A (ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * __this, String_t* ___key0, const RuntimeMethod* method)
{
	return ((  bool (*) (ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 *, String_t*, const RuntimeMethod*))ReadOnlyDictionary_2_ContainsKey_mE2D8481B8A943A4DFD191B44B3AA5350CEC7BF1E_gshared)(__this, ___key0, method);
}
// System.Boolean System.String::op_Inequality(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_op_Inequality_m0BD184A74F453A72376E81CC6CAEE2556B80493E (String_t* ___a0, String_t* ___b1, const RuntimeMethod* method);
// System.Boolean System.String::op_Equality(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_op_Equality_m139F0E4195AE2F856019E63B241F36F016997FCE (String_t* ___a0, String_t* ___b1, const RuntimeMethod* method);
// !1 System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,WwiseObjectType>::get_Item(!0)
inline int32_t ReadOnlyDictionary_2_get_Item_m2872DF7EB7C71DD1A8E217C9FACA183F7AD5A02C (ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * __this, String_t* ___key0, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 *, String_t*, const RuntimeMethod*))ReadOnlyDictionary_2_get_Item_mEA07B2EBEC5714297A157CA478B224C0076CF428_gshared)(__this, ___key0, method);
}
// System.Void System.Collections.Generic.Dictionary`2<WwiseObjectType,System.String>::.ctor()
inline void Dictionary_2__ctor_m9457A48CCEE984A72083457DACF6F3F0C97E4AA5 (Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD *, const RuntimeMethod*))Dictionary_2__ctor_m80B728B0F4A8176CF1F62C2768D31E6F7838B232_gshared)(__this, method);
}
// System.Void System.Collections.Generic.Dictionary`2<WwiseObjectType,System.String>::Add(!0,!1)
inline void Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9 (Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * __this, int32_t ___key0, String_t* ___value1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD *, int32_t, String_t*, const RuntimeMethod*))Dictionary_2_Add_mB3D9D66F9CFB6CB7013F547768CAE89834974B8F_gshared)(__this, ___key0, ___value1, method);
}
// System.Void System.Collections.ObjectModel.ReadOnlyDictionary`2<WwiseObjectType,System.String>::.ctor(System.Collections.Generic.IDictionary`2<!0,!1>)
inline void ReadOnlyDictionary_2__ctor_m09C7C2FF3D8EC8592F1E582191C2F95970CA4D0F (ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D * __this, RuntimeObject* ___dictionary0, const RuntimeMethod* method)
{
	((  void (*) (ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D *, RuntimeObject*, const RuntimeMethod*))ReadOnlyDictionary_2__ctor_m8B628482E1B0A2958F5997A978B90DF7C316A869_gshared)(__this, ___dictionary0, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,System.String>::.ctor()
inline void Dictionary_2__ctor_m5B1C279E77422BB0B2C7B0374ECF89E3224AF62B (Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC *, const RuntimeMethod*))Dictionary_2__ctor_m2C7E51568033239B506E15E7804A0B8658246498_gshared)(__this, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,System.String>::Add(!0,!1)
inline void Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC (Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC * __this, String_t* ___key0, String_t* ___value1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC *, String_t*, String_t*, const RuntimeMethod*))Dictionary_2_Add_mC741BBB0A647C814227953DB9B23CB1BDF571C5B_gshared)(__this, ___key0, ___value1, method);
}
// System.Void System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,System.String>::.ctor(System.Collections.Generic.IDictionary`2<!0,!1>)
inline void ReadOnlyDictionary_2__ctor_mB2D19FDF7E2760F6CD503397D0395FBD27E877FF (ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE * __this, RuntimeObject* ___dictionary0, const RuntimeMethod* method)
{
	((  void (*) (ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE *, RuntimeObject*, const RuntimeMethod*))ReadOnlyDictionary_2__ctor_mC417F57C7FB9D62B2F8388B52FD3E45955BA160A_gshared)(__this, ___dictionary0, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,WwiseObjectType>::.ctor()
inline void Dictionary_2__ctor_mF9BF70BC1501E2DD8B1B8928E3920BF963A562A5 (Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F *, const RuntimeMethod*))Dictionary_2__ctor_m1C8D9B685C8406F92F3C063FCA11D9AB5F56493E_gshared)(__this, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,WwiseObjectType>::set_Item(!0,!1)
inline void Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D (Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * __this, String_t* ___key0, int32_t ___value1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F *, String_t*, int32_t, const RuntimeMethod*))Dictionary_2_set_Item_m0065D5FD414B2D11BC53F897CDDFEEFE8B93875B_gshared)(__this, ___key0, ___value1, method);
}
// System.Void System.Collections.ObjectModel.ReadOnlyDictionary`2<System.String,WwiseObjectType>::.ctor(System.Collections.Generic.IDictionary`2<!0,!1>)
inline void ReadOnlyDictionary_2__ctor_mC837B9F33F33A0BA69860897896746402C48619E (ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * __this, RuntimeObject* ___dictionary0, const RuntimeMethod* method)
{
	((  void (*) (ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 *, RuntimeObject*, const RuntimeMethod*))ReadOnlyDictionary_2__ctor_m8BE1FBD324F6E964BF77911D0EF7F6F41FCC91DA_gshared)(__this, ___dictionary0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<Wamp/<Send>d__16>(!!0&)
inline void AsyncTaskMethodBuilder_Start_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m3BE2ACD6057BFEC9516FD5CA2EC71DD1F46E95FB (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A *, const RuntimeMethod*))AsyncTaskMethodBuilder_Start_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m3BE2ACD6057BFEC9516FD5CA2EC71DD1F46E95FB_gshared)(__this, ___stateMachine0, method);
}
// System.Text.RegularExpressions.Match System.Text.RegularExpressions.Regex::Match(System.String,System.String,System.Text.RegularExpressions.RegexOptions)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * Regex_Match_m08332EE8B44F5A94218B8D432627EB7F71EE7BE2 (String_t* ___input0, String_t* ___pattern1, int32_t ___options2, const RuntimeMethod* method);
// System.Int32 System.Text.RegularExpressions.GroupCollection::get_Count()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t GroupCollection_get_Count_mBDDCA62E15FC586F0CCBD75F006BF0B08713E26E (GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * __this, const RuntimeMethod* method);
// System.Void Wamp/ErrorException::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9 (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, String_t* ___message0, const RuntimeMethod* method);
// System.Text.RegularExpressions.Group System.Text.RegularExpressions.GroupCollection::get_Item(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177 (GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * __this, int32_t ___groupnum0, const RuntimeMethod* method);
// System.String System.Text.RegularExpressions.Capture::get_Value()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C (Capture_tF4475248CCF3EFF914844BE2C993FC609D41DB73 * __this, const RuntimeMethod* method);
// System.Int32 System.Int32::Parse(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA (String_t* ___s0, const RuntimeMethod* method);
// Wamp/Response Wamp::ParseWelcome(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseWelcome_mDC04C238E5A69F16500F3C9A7678B10185601B58 (String_t* ___msg0, const RuntimeMethod* method);
// Wamp/Response Wamp::ParseGoodbye(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseGoodbye_m62130B50323A9CDC2F8182BA1E492B5F182A958A (String_t* ___msg0, const RuntimeMethod* method);
// Wamp/Response Wamp::ParseSubscribed(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseSubscribed_m705D9E4D5465BAF013A92740D8D822AF448B1F23 (String_t* ___msg0, const RuntimeMethod* method);
// Wamp/Response Wamp::ParseUnsubscribed(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseUnsubscribed_m21AF2D9070DE4E49F5CC7C53A164C1A5C2D7040E (String_t* ___msg0, const RuntimeMethod* method);
// Wamp/Response Wamp::ParseEvent(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseEvent_m21C36EAE091AB9B20402C75770048AA5FC9F9020 (String_t* ___msg0, const RuntimeMethod* method);
// Wamp/Response Wamp::ParseResult(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseResult_m1ED4173FAF19510DA46B93BCA58DAA6FE0140634 (String_t* ___msg0, const RuntimeMethod* method);
// Wamp/ErrorException Wamp/ErrorException::FromResponse(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * ErrorException_FromResponse_m7F3FD8A84BC8AEF0BC62A4CD5203DF961BC803C9 (String_t* ___response0, const RuntimeMethod* method);
// System.Boolean System.Text.RegularExpressions.Group::get_Success()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521 (Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * __this, const RuntimeMethod* method);
// System.Void Wamp/Response::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method);
// System.Void Wamp/Response::set_MessageId(Wamp/Messages)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void Wamp/Response::set_RequestId(System.Int32)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Int32 System.Text.RegularExpressions.Capture::get_Index()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31_inline (Capture_tF4475248CCF3EFF914844BE2C993FC609D41DB73 * __this, const RuntimeMethod* method);
// System.Int32 System.String::get_Length()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018_inline (String_t* __this, const RuntimeMethod* method);
// System.String System.String::Substring(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Substring_mB593C0A320C683E6E47EFFC0A12B7A465E5E43BB (String_t* __this, int32_t ___startIndex0, int32_t ___length1, const RuntimeMethod* method);
// System.Void Wamp/Response::set_Json(System.String)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_Json_m8B200462D00D107744D54E7FD990BB541675D7F9_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, String_t* ___value0, const RuntimeMethod* method);
// System.UInt32 System.UInt32::Parse(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t UInt32_Parse_m7BE20B4A60B436F4061567396833BE360ACD476D (String_t* ___s0, const RuntimeMethod* method);
// System.Void Wamp/Response::set_SubscriptionId(System.UInt32)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_SubscriptionId_m160D966B5D30F42BF0D5C133AA49CC14B62ED853_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, uint32_t ___value0, const RuntimeMethod* method);
// System.Void Wamp/Response::set_ContextSpecificResultId(System.Int32)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_ContextSpecificResultId_m4E0BD596C10376CFFFD141BF47A2322DBF18D760_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::Create()
inline AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  AsyncTaskMethodBuilder_1_Create_m94B4F919FEC6BCB096ECA1FD0DE9594CBBD14576 (const RuntimeMethod* method)
{
	return ((  AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  (*) (const RuntimeMethod*))AsyncTaskMethodBuilder_1_Create_mC7806A5C115ED2239A5073313AA3564D8244156E_gshared)(method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::Start<Wamp/<ReceiveMessage>d__24>(!!0&)
inline void AsyncTaskMethodBuilder_1_Start_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_m2B93F2B8EC2D264EE75A4DF55225BCC2F83A7E3B (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_Start_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_m9E877DEA04729613615309850E05CF23E91A118F_gshared)(__this, ___stateMachine0, method);
}
// System.Threading.Tasks.Task`1<!0> System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::get_Task()
inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * AsyncTaskMethodBuilder_1_get_Task_m7CB437A60103DC49A5C02014C51B0684D0E3E69C (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, const RuntimeMethod* method)
{
	return ((  Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_get_Task_m19C5664D70C4FC799BEFB8D0FC98E687F97059FA_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::Start<Wamp/<Receive>d__25>(!!0&)
inline void AsyncTaskMethodBuilder_1_Start_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_m2642B44518F49E595EC0F58CBE4876BB59B52DBB (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_Start_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_mA2E7E1F0956096CE8D81B18FF70AD60203E1B505_gshared)(__this, ___stateMachine0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::Start<Wamp/<ReceiveExpect>d__26>(!!0&)
inline void AsyncTaskMethodBuilder_1_Start_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m8CA846E439DFA4D8D21C28CF451D501736903735 (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_Start_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_mF6049B47708FBB29E1BDFEE6AF464C1ECC931A8B_gshared)(__this, ___stateMachine0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<Wamp/<Connect>d__27>(!!0&)
inline void AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m83286F1C813B3EF711EFFF20F60DF019DD0EF82A (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 *, const RuntimeMethod*))AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m83286F1C813B3EF711EFFF20F60DF019DD0EF82A_gshared)(__this, ___stateMachine0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<Wamp/<Close>d__30>(!!0&)
inline void AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m014E726B3574D52F7F9E118E1B7A58DF73336783 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 *, const RuntimeMethod*))AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m014E726B3574D52F7F9E118E1B7A58DF73336783_gshared)(__this, ___stateMachine0, method);
}
// System.Int32 Wamp/Response::get_ContextSpecificResultId()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t Response_get_ContextSpecificResultId_m8C53A20C58BACF5A2DA2379A42D2818F283CF862_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,Wamp/PublishHandler>::TryGetValue(!0,!1&)
inline bool ConcurrentDictionary_2_TryGetValue_mB8CB5BED33D46B4F69E7967FA50455B66E08A421 (ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * __this, uint32_t ___key0, PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 ** ___value1, const RuntimeMethod* method)
{
	return ((  bool (*) (ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 *, uint32_t, PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 **, const RuntimeMethod*))ConcurrentDictionary_2_TryGetValue_m89C9CF866355F7BB41EDDCBB0F1D3026CE7273D6_gshared)(__this, ___key0, ___value1, method);
}
// System.String Wamp/Response::get_Json()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR String_t* Response_get_Json_m344AA62580A8B48CEECF9F5A9B33638D572B785B_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method);
// System.Void Wamp/PublishHandler::Invoke(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PublishHandler_Invoke_m85F2A61F37B7D01827F76105781D219BFCF7E448 (PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * __this, String_t* ___json0, const RuntimeMethod* method);
// System.Void Wamp/<>c__DisplayClass32_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass32_0__ctor_m21ABB4A02AE3611EDDC6C1A4A27CF6F83341418A (U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63 * __this, const RuntimeMethod* method);
// System.Threading.CancellationToken System.Threading.CancellationTokenSource::get_Token()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  CancellationTokenSource_get_Token_mBB578AFC3DB427E263C966B2DCA86E6ED1CCBC9B (CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * __this, const RuntimeMethod* method);
// System.Threading.Tasks.TaskFactory System.Threading.Tasks.Task::get_Factory()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155 * Task_get_Factory_m31F1298E08390A4AD46B85AB060F1FAD4CE12112_inline (const RuntimeMethod* method);
// System.Void System.Action::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Action__ctor_m570E96B2A0C48BC1DC6788460316191F24572760 (Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method);
// System.Threading.Tasks.Task System.Threading.Tasks.TaskFactory::StartNew(System.Action,System.Threading.CancellationToken)
IL2CPP_EXTERN_C IL2CPP_NO_INLINE IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * TaskFactory_StartNew_m33BCF7F3334F8ADB57FEAE2E0524A9B483F4EF87 (TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155 * __this, Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * ___action0, CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  ___cancellationToken1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::Start<Wamp/<Call>d__34>(!!0&)
inline void AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_m1109EFCCABBD7FBE73DF89539EA069F7803F4CA2 (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * __this, U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *, U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mCFD1635DF5FF1599EC400ED06D2D816C3E5A519A_gshared)(__this, ___stateMachine0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::Start<Wamp/<Subscribe>d__35>(!!0&)
inline void AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m4CFDDD929A9A264EF81EAA747130B8946DD69999 (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *, U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m4CFDDD929A9A264EF81EAA747130B8946DD69999_gshared)(__this, ___stateMachine0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start<Wamp/<Unsubscribe>d__36>(!!0&)
inline void AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m9B9904F2786C63840AA72106EF2A750CB549AEA3 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 *, const RuntimeMethod*))AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m9B9904F2786C63840AA72106EF2A750CB549AEA3_gshared)(__this, ___stateMachine0, method);
}
// System.Void System.Threading.CancellationTokenSource::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CancellationTokenSource__ctor_m217582F71932ADD00D63047D8D53C87111116C6B (CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * __this, const RuntimeMethod* method);
// System.Void System.Threading.Tasks.TaskCompletionSource`1<Wamp/Response>::.ctor()
inline void TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3 (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * __this, const RuntimeMethod* method)
{
	((  void (*) (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 *, const RuntimeMethod*))TaskCompletionSource_1__ctor_m3A77018A60870C828E549796E331896683B62705_gshared)(__this, method);
}
// System.Void System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,Wamp/PublishHandler>::.ctor()
inline void ConcurrentDictionary_2__ctor_mAE7C80BE83DA4BF21D02463F2AEC2BDA59704B2F (ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * __this, const RuntimeMethod* method)
{
	((  void (*) (ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 *, const RuntimeMethod*))ConcurrentDictionary_2__ctor_m9A6F57EF5BA973054F37AE56E6B40E944DD4FDA5_gshared)(__this, method);
}
// System.Void Wamp/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m4643EB15B51A45103D4E30A86716ACD2F70B48B4 (U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 * __this, const RuntimeMethod* method);
// System.Void System.Threading.CancellationToken::ThrowIfCancellationRequested()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CancellationToken_ThrowIfCancellationRequested_m13AB667F961F83D8ED759BA402325638F43B0938 (CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB * __this, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<Wamp/Response> Wamp::ReceiveMessage()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * Wamp_ReceiveMessage_m333714DD38A3BEBB92BA90A416BC053CDC1158BC (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method);
// System.Void System.Threading.Tasks.Task::Wait()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Task_Wait_m7793234C16E5D2B719519CE3C55653EA4D1A815A (Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * __this, const RuntimeMethod* method);
// !0 System.Threading.Tasks.Task`1<Wamp/Response>::get_Result()
inline Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876 (Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * __this, const RuntimeMethod* method)
{
	return ((  Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * (*) (Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA *, const RuntimeMethod*))Task_1_get_Result_m653E95E70604B69D29BC9679AA4588ED82AD01D7_gshared)(__this, method);
}
// Wamp/Messages Wamp/Response::get_MessageId()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t Response_get_MessageId_mC397D82D70FC4A2DC73186D1CADF3ADF34CEE0D7_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method);
// System.Void Wamp::ProcessEvent(Wamp/Response)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_ProcessEvent_mB6BA36EA16F2375692017561F09D725C6D2E6E35 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * ___message0, const RuntimeMethod* method);
// System.Void System.Threading.Tasks.TaskCompletionSource`1<Wamp/Response>::SetResult(!0)
inline void TaskCompletionSource_1_SetResult_mC00E900D0DF47C8A8E1AC8126E8CF9E545516EFE (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * __this, Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * ___result0, const RuntimeMethod* method)
{
	((  void (*) (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 *, Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 *, const RuntimeMethod*))TaskCompletionSource_1_SetResult_m86E11C99226F2BF07334B344F36EE443271B9070_gshared)(__this, ___result0, method);
}
// System.Boolean System.Threading.CancellationToken::get_IsCancellationRequested()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool CancellationToken_get_IsCancellationRequested_mCF3521778F20F7048B7121885794B9562324447D (CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB * __this, const RuntimeMethod* method);
// System.Exception System.Exception::get_InnerException()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR Exception_t * Exception_get_InnerException_mCB68CC8CBF2540EF381CB17A4E4E3F6D0E33453F_inline (Exception_t * __this, const RuntimeMethod* method);
// System.Type System.Exception::GetType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Type_t * Exception_GetType_mA3390B9D538D5FAC3802D9D8A2FCAC31465130F3 (Exception_t * __this, const RuntimeMethod* method);
// System.Type System.Type::GetTypeFromHandle(System.RuntimeTypeHandle)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Type_t * Type_GetTypeFromHandle_m9DC58ADF0512987012A8A016FB64B068F3B1AFF6 (RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D  ___handle0, const RuntimeMethod* method);
// System.Boolean System.Type::op_Equality(System.Type,System.Type)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Type_op_Equality_m7040622C9E1037EFC73E1F0EDB1DD241282BE3D8 (Type_t * ___left0, Type_t * ___right1, const RuntimeMethod* method);
// System.Net.WebSockets.WebSocketError System.Net.WebSockets.WebSocketException::get_WebSocketErrorCode()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t WebSocketException_get_WebSocketErrorCode_m7AC07357E5C368E87BB9C4E16A6F9BF46FBF14CD_inline (WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B * __this, const RuntimeMethod* method);
// System.Void System.Threading.Tasks.TaskCompletionSource`1<Wamp/Response>::SetException(System.Exception)
inline void TaskCompletionSource_1_SetException_mB10C34767496AC4F8A94CA8ABA1462B2EC81C6B8 (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * __this, Exception_t * ___exception0, const RuntimeMethod* method)
{
	((  void (*) (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 *, Exception_t *, const RuntimeMethod*))TaskCompletionSource_1_SetException_m32F878B5587E7DA84F6EAD84D297488C300B16E1_gshared)(__this, ___exception0, method);
}
// System.Void Wamp::OnDisconnect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_OnDisconnect_m17E2623C24F5E4FE6AAC0736C0C8EB1E323D099F (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Format_mA3AC3FE7B23D97F3A5BAA082D25B0E01B341A865 (String_t* ___format0, ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* ___args1, const RuntimeMethod* method);
// System.Threading.Tasks.Task Wamp::Send(System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___msg0, int32_t ___timeout1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Call>d__34>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mE41874465445B27A74796D0922012A53154AC9C3 (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *, U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mF6AFBF00E8067F0CE905589AB9C5D14D1F83810B_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Threading.Tasks.Task`1<Wamp/Response> Wamp::ReceiveExpect(Wamp/Messages,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, int32_t ___message0, int32_t ___requestId1, int32_t ___timeout2, const RuntimeMethod* method);
// System.Runtime.CompilerServices.TaskAwaiter`1<!0> System.Threading.Tasks.Task`1<Wamp/Response>::GetAwaiter()
inline TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3 (Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * __this, const RuntimeMethod* method)
{
	return ((  TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  (*) (Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA *, const RuntimeMethod*))Task_1_GetAwaiter_m9C50610C6F05C1DA9BFA67201CB570F1DE040817_gshared)(__this, method);
}
// System.Boolean System.Runtime.CompilerServices.TaskAwaiter`1<Wamp/Response>::get_IsCompleted()
inline bool TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *, const RuntimeMethod*))TaskAwaiter_1_get_IsCompleted_mBF435C7EFD03FCF7810FC08EEDC5945F80FF88F9_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.String>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<Wamp/Response>,Wamp/<Call>d__34>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mF490191D1E3DB080FB623CECA0FE22B25E9F298D (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * __this, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * ___awaiter0, U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *, U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mB7E7D2A87A1F10FB3B6927F6EC0D42EEF627DA62_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// !0 System.Runtime.CompilerServices.TaskAwaiter`1<Wamp/Response>::GetResult()
inline Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50 (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * __this, const RuntimeMethod* method)
{
	return ((  Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * (*) (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *, const RuntimeMethod*))TaskAwaiter_1_GetResult_m9E148849CD4747E1BDD831E4FB2D7ECFA13C11C8_gshared)(__this, method);
}
// System.Void Wamp/<Call>d__34::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCallU3Ed__34_MoveNext_mFE458EC82A6FE04034653EFACBCDF773333888F1 (U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * __this, const RuntimeMethod* method);
// System.Void Wamp/<Call>d__34::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCallU3Ed__34_SetStateMachine_mC98B572BE8C143D41DF3D54466223A92F1F1D6B8 (U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Format_m0ACDD8B34764E4040AED0B3EEB753567E4576BFA (String_t* ___format0, RuntimeObject * ___arg01, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Close>d__30>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mDAC2ADF8AB1E52888B4479666D626F617937E900 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *, U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mDAC2ADF8AB1E52888B4479666D626F617937E900_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<Wamp/Response>,Wamp/<Close>d__30>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m67D96E6CEEDCD41F4AD94298BF70CFB2EBA1D917 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * ___awaiter0, U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *, U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mF5BBC9EFF014107E99EBF16D634F06C760ADE6E7_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void System.Threading.CancellationTokenSource::Cancel()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CancellationTokenSource_Cancel_m33023D4CB46117A4C6A7C1ED0076918871A1E2DF (CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * __this, const RuntimeMethod* method);
// System.Void System.Threading.CancellationTokenSource::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CancellationTokenSource__ctor_m282A9AF96A92487F7B0B391F00F3083C1832A53F (CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * __this, int32_t ___millisecondsDelay0, const RuntimeMethod* method);
// System.Void Wamp/<Close>d__30::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCloseU3Ed__30_MoveNext_mAB43192731588E3CF72C9F96212C641FB1A0184D (U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * __this, const RuntimeMethod* method);
// System.Void Wamp/<Close>d__30::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCloseU3Ed__30_SetStateMachine_mDD6A8E81D89D09469510FB615D6DF79B2E61C0AB (U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Uri::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Uri__ctor_mBA69907A1D799CD12ED44B611985B25FE4C626A2 (Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E * __this, String_t* ___uriString0, const RuntimeMethod* method);
// System.Void System.Net.WebSockets.ClientWebSocket::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ClientWebSocket__ctor_m1D76A019F2A4599B3406D69CBFF9E7D507AF8CE1 (ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * __this, const RuntimeMethod* method);
// System.Threading.Tasks.Task System.Net.WebSockets.ClientWebSocket::ConnectAsync(System.Uri,System.Threading.CancellationToken)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * ClientWebSocket_ConnectAsync_m5345909A338BEFF1D71DE95D7A25515E5D348E54 (ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * __this, Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E * ___uri0, CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  ___cancellationToken1, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Connect>d__27>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m393F31C0EF4CBF441A486F7C6A0D4AB4B58B4286 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *, U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m393F31C0EF4CBF441A486F7C6A0D4AB4B58B4286_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void Wamp::StartListen()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_StartListen_mD58F9728B82A7A344E95BA20A462450F5725CEB8 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<Wamp/Response>,Wamp/<Connect>d__27>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_mCD9168B1DF026CB3BB6DEF84647D3DAD1BA186A6 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * ___awaiter0, U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *, U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m220B7939F9FD150B558C3EEC33C5646B580DF4A7_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void Wamp/<Connect>d__27::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14 (U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * __this, const RuntimeMethod* method);
// System.Void Wamp/<Connect>d__27::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CConnectU3Ed__27_SetStateMachine_m3C346664EBD564CDA981B81988E47665403580B9 (U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<!0> System.Threading.Tasks.TaskCompletionSource`1<Wamp/Response>::get_Task()
inline Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * TaskCompletionSource_1_get_Task_mDC9ED85B68696CD8BD9DE3A757F317BA5C6417A4_inline (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * __this, const RuntimeMethod* method)
{
	return ((  Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * (*) (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 *, const RuntimeMethod*))TaskCompletionSource_1_get_Task_mE3DDBDE4F3FB8A530456D158F4C460E85A4974B9_gshared_inline)(__this, method);
}
// System.Threading.Tasks.Task System.Threading.Tasks.Task::Delay(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * Task_Delay_m193E6692B81A2A6C45F5FAE08CF79FA06FC7DA60 (int32_t ___millisecondsDelay0, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<System.Threading.Tasks.Task> System.Threading.Tasks.Task::WhenAny(System.Threading.Tasks.Task[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138 * Task_WhenAny_mBC42BCB13C1F576DE6DAA08EB4F704D8176E674F (TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE* ___tasks0, const RuntimeMethod* method);
// System.Runtime.CompilerServices.TaskAwaiter`1<!0> System.Threading.Tasks.Task`1<System.Threading.Tasks.Task>::GetAwaiter()
inline TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A  Task_1_GetAwaiter_m9814C67F6EAD25792CF76E9A4C961FD4704B2965 (Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138 * __this, const RuntimeMethod* method)
{
	return ((  TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A  (*) (Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138 *, const RuntimeMethod*))Task_1_GetAwaiter_m9C50610C6F05C1DA9BFA67201CB570F1DE040817_gshared)(__this, method);
}
// System.Boolean System.Runtime.CompilerServices.TaskAwaiter`1<System.Threading.Tasks.Task>::get_IsCompleted()
inline bool TaskAwaiter_1_get_IsCompleted_m65B87815F65EECDC664D3CD37DA73A87E753258A (TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A *, const RuntimeMethod*))TaskAwaiter_1_get_IsCompleted_mBF435C7EFD03FCF7810FC08EEDC5945F80FF88F9_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Threading.Tasks.Task>,Wamp/<Receive>d__25>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_mC22DC39F316BF248F38A8A452016A5A992B8C5EF (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A * ___awaiter0, U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A *, U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_m30AEB03D457566947B991E758054ACE94DB895A3_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// !0 System.Runtime.CompilerServices.TaskAwaiter`1<System.Threading.Tasks.Task>::GetResult()
inline Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * TaskAwaiter_1_GetResult_mA33716D8F7BAE3970F8307C41CE96B2A452FCF5A (TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A * __this, const RuntimeMethod* method)
{
	return ((  Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * (*) (TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A *, const RuntimeMethod*))TaskAwaiter_1_GetResult_m9E148849CD4747E1BDD831E4FB2D7ECFA13C11C8_gshared)(__this, method);
}
// System.Void Wamp/TimeoutException::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TimeoutException__ctor_m2AD6BA4E69FE5415F5E571171A0346292B84E0D4 (TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0 * __this, String_t* ___message0, const RuntimeMethod* method);
// System.AggregateException System.Threading.Tasks.Task::get_Exception()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR AggregateException_t9217B9E89DF820D5632411F2BD92F444B17BD60E * Task_get_Exception_mA61AAD3E52CBEB631D1956217B521456E7960B95 (Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::SetException(System.Exception)
inline void AsyncTaskMethodBuilder_1_SetException_m89F128C1E1A0F0E16A1FFA86AD6A96E8997DB857 (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, Exception_t * ___exception0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, Exception_t *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetException_m4C0B5462ECCB520FACA3C90B353DF596DAAF586D_gshared)(__this, ___exception0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::SetResult(!0)
inline void AsyncTaskMethodBuilder_1_SetResult_m013485E27C036058F955FBFB38CB72C8390A9C92 (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * ___result0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetResult_mD7DA7A17DC0610B11A0AAA364C3CA51FEC1271DB_gshared)(__this, ___result0, method);
}
// System.Void Wamp/<Receive>d__25::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4 (U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * __this, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
inline void AsyncTaskMethodBuilder_1_SetStateMachine_m5EF4BCC5A6E298F61AF578E53EAF3AD0FEE6C5D3 (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, RuntimeObject*, const RuntimeMethod*))AsyncTaskMethodBuilder_1_SetStateMachine_m5CC21A02320CF3D2DD7894A31123DFD82A428E4C_gshared)(__this, ___stateMachine0, method);
}
// System.Void Wamp/<Receive>d__25::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveU3Ed__25_SetStateMachine_m1DFEA710015A7E2BA876C1837E14781B6BC5E68F (U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Threading.Tasks.Task`1<Wamp/Response> Wamp::Receive(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * Wamp_Receive_m7B47E5C25B601C3C446B02A97117ACAA3FA3BF13 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, int32_t ___timeout0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<Wamp/Response>,Wamp/<ReceiveExpect>d__26>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m2EB1C430D6D5413CB1A2A876F98D2F34F4C9BEF3 (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * ___awaiter0, U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *, U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m515F307519C1D6D6BAC17C9BEB0F2107B1556B48_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.String System.String::Concat(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_mB78D0094592718DA6D5DB6C712A9C225631666BE (String_t* ___str00, String_t* ___str11, const RuntimeMethod* method);
// System.Int32 Wamp/Response::get_RequestId()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t Response_get_RequestId_m839528D15AAC4BC39EAEB22669F38B75140A0C05_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method);
// System.Void Wamp/<ReceiveExpect>d__26::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0 (U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * __this, const RuntimeMethod* method);
// System.Void Wamp/<ReceiveExpect>d__26::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveExpectU3Ed__26_SetStateMachine_mFDCB7BA62E930894AC2A0A7A5100EE36A256FD7B (U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Collections.Generic.IEnumerable`1<System.Byte>>::.ctor()
inline void List_1__ctor_mB7D4AB3F605E57A961003A9975A9DD9E3023B769 (List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 *, const RuntimeMethod*))List_1__ctor_mC832F1AC0F814BAEB19175F5D7972A7507508BC3_gshared)(__this, method);
}
// System.Void System.ArraySegment`1<System.Byte>::.ctor(!0[],System.Int32,System.Int32)
inline void ArraySegment_1__ctor_m6305655CDE2F6E154BA79003B66CF61795462804 (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * __this, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___array0, int32_t ___offset1, int32_t ___count2, const RuntimeMethod* method)
{
	((  void (*) (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA *, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*, int32_t, int32_t, const RuntimeMethod*))ArraySegment_1__ctor_m6305655CDE2F6E154BA79003B66CF61795462804_gshared)(__this, ___array0, ___offset1, ___count2, method);
}
// System.Runtime.CompilerServices.TaskAwaiter`1<!0> System.Threading.Tasks.Task`1<System.Net.WebSockets.WebSocketReceiveResult>::GetAwaiter()
inline TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD  Task_1_GetAwaiter_mAFED2623EE194913D17CD104EE32E077A0BD324E (Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F * __this, const RuntimeMethod* method)
{
	return ((  TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD  (*) (Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F *, const RuntimeMethod*))Task_1_GetAwaiter_m9C50610C6F05C1DA9BFA67201CB570F1DE040817_gshared)(__this, method);
}
// System.Boolean System.Runtime.CompilerServices.TaskAwaiter`1<System.Net.WebSockets.WebSocketReceiveResult>::get_IsCompleted()
inline bool TaskAwaiter_1_get_IsCompleted_mBD5D88440DBE5104B7AEF7A11D549FE39008740D (TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD *, const RuntimeMethod*))TaskAwaiter_1_get_IsCompleted_mBF435C7EFD03FCF7810FC08EEDC5945F80FF88F9_gshared)(__this, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<Wamp/Response>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<System.Net.WebSockets.WebSocketReceiveResult>,Wamp/<ReceiveMessage>d__24>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_mA44D0B4B5FB1613D34ACD01F6D6F1E99E95AD4C8 (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * __this, TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD * ___awaiter0, U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *, TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD *, U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_m869EB03758A4A1D5D4EBFB4374B8C354F04E3AAE_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// !0 System.Runtime.CompilerServices.TaskAwaiter`1<System.Net.WebSockets.WebSocketReceiveResult>::GetResult()
inline WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * TaskAwaiter_1_GetResult_m814E69FC46668F93FB02713896269AAACBD01F06 (TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD * __this, const RuntimeMethod* method)
{
	return ((  WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * (*) (TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD *, const RuntimeMethod*))TaskAwaiter_1_GetResult_m9E148849CD4747E1BDD831E4FB2D7ECFA13C11C8_gshared)(__this, method);
}
// System.Int32 System.ArraySegment`1<System.Byte>::get_Offset()
inline int32_t ArraySegment_1_get_Offset_m6651443913CC50A02AE5D7C4CDC6F6744D39B483_inline (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA *, const RuntimeMethod*))ArraySegment_1_get_Offset_m6651443913CC50A02AE5D7C4CDC6F6744D39B483_gshared_inline)(__this, method);
}
// System.Collections.Generic.IEnumerable`1<!!0> System.Linq.Enumerable::Skip<System.Byte>(System.Collections.Generic.IEnumerable`1<!!0>,System.Int32)
inline RuntimeObject* Enumerable_Skip_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m73025D0C956827AA7A6EA962A50C8B63F69FBBBE (RuntimeObject* ___source0, int32_t ___count1, const RuntimeMethod* method)
{
	return ((  RuntimeObject* (*) (RuntimeObject*, int32_t, const RuntimeMethod*))Enumerable_Skip_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m73025D0C956827AA7A6EA962A50C8B63F69FBBBE_gshared)(___source0, ___count1, method);
}
// System.Int32 System.Net.WebSockets.WebSocketReceiveResult::get_Count()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t WebSocketReceiveResult_get_Count_m2C308CD164D4199DACE7613DC7E8DC1F5E66DF65_inline (WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * __this, const RuntimeMethod* method);
// System.Collections.Generic.IEnumerable`1<!!0> System.Linq.Enumerable::Take<System.Byte>(System.Collections.Generic.IEnumerable`1<!!0>,System.Int32)
inline RuntimeObject* Enumerable_Take_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_mFBC4D57366E255AFC2F139800ABAD01A519B2B05 (RuntimeObject* ___source0, int32_t ___count1, const RuntimeMethod* method)
{
	return ((  RuntimeObject* (*) (RuntimeObject*, int32_t, const RuntimeMethod*))Enumerable_Take_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_mFBC4D57366E255AFC2F139800ABAD01A519B2B05_gshared)(___source0, ___count1, method);
}
// System.Void System.Collections.Generic.List`1<System.Collections.Generic.IEnumerable`1<System.Byte>>::Add(!0)
inline void List_1_Add_m4454ADA74D82DCE063A15F0A54CE55D3CDFAA382 (List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * __this, RuntimeObject* ___item0, const RuntimeMethod* method)
{
	((  void (*) (List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 *, RuntimeObject*, const RuntimeMethod*))List_1_Add_m6930161974C7504C80F52EC379EF012387D43138_gshared)(__this, ___item0, method);
}
// System.Boolean System.Net.WebSockets.WebSocketReceiveResult::get_EndOfMessage()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool WebSocketReceiveResult_get_EndOfMessage_m18C6588C6F9FC235BEC84AA7572B7F49C5E6BEB9_inline (WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * __this, const RuntimeMethod* method);
// System.Void System.Func`2<System.Collections.Generic.IEnumerable`1<System.Byte>,System.Collections.Generic.IEnumerable`1<System.Byte>>::.ctor(System.Object,System.IntPtr)
inline void Func_2__ctor_m71F83ACB080E1E97771766B7F659BD1B091831B7 (Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method)
{
	((  void (*) (Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 *, RuntimeObject *, intptr_t, const RuntimeMethod*))Func_2__ctor_mE2AF7615AD18E9CD92B1909285F5EC5DA8D180C8_gshared)(__this, ___object0, ___method1, method);
}
// System.Collections.Generic.IEnumerable`1<!!1> System.Linq.Enumerable::SelectMany<System.Collections.Generic.IEnumerable`1<System.Byte>,System.Byte>(System.Collections.Generic.IEnumerable`1<!!0>,System.Func`2<!!0,System.Collections.Generic.IEnumerable`1<!!1>>)
inline RuntimeObject* Enumerable_SelectMany_TisIEnumerable_1_t5A38FCC3E9F64286F2A624D6571AF9EA7844398E_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m90F6F46EB605689C56C3A8F2667983FB5C70265A (RuntimeObject* ___source0, Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * ___selector1, const RuntimeMethod* method)
{
	return ((  RuntimeObject* (*) (RuntimeObject*, Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 *, const RuntimeMethod*))Enumerable_SelectMany_TisRuntimeObject_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_mEF1CD215BE4CF70D3F66FF364C0B2778CA5EB598_gshared)(___source0, ___selector1, method);
}
// !!0[] System.Linq.Enumerable::ToArray<System.Byte>(System.Collections.Generic.IEnumerable`1<!!0>)
inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* Enumerable_ToArray_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m48AFCA8923688797114AA384B978E290AAAF206B (RuntimeObject* ___source0, const RuntimeMethod* method)
{
	return ((  ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* (*) (RuntimeObject*, const RuntimeMethod*))Enumerable_ToArray_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m48AFCA8923688797114AA384B978E290AAAF206B_gshared)(___source0, method);
}
// System.Text.Encoding System.Text.Encoding::get_UTF8()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * Encoding_get_UTF8_m67C8652936B681E7BC7505E459E88790E0FF16D9 (const RuntimeMethod* method);
// Wamp/Response Wamp::Parse(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___msg0, const RuntimeMethod* method);
// System.Void Wamp/<ReceiveMessage>d__24::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F (U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * __this, const RuntimeMethod* method);
// System.Void Wamp/<ReceiveMessage>d__24::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveMessageU3Ed__24_SetStateMachine_m1A3F556E61365751BF72BC7C8C95F8DEDBF12C3C (U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.ArraySegment`1<System.Byte>::.ctor(!0[])
inline void ArraySegment_1__ctor_mC699D21C137279D4D9A501143A898CCB0971D382 (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * __this, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___array0, const RuntimeMethod* method)
{
	((  void (*) (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA *, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*, const RuntimeMethod*))ArraySegment_1__ctor_mC699D21C137279D4D9A501143A898CCB0971D382_gshared)(__this, ___array0, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Send>d__16>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m0996EC60B40B2090B23E54881415F88FBE155480 (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *, U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m0996EC60B40B2090B23E54881415F88FBE155480_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void Wamp/<Send>d__16::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72 (U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * __this, const RuntimeMethod* method);
// System.Void Wamp/<Send>d__16::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSendU3Ed__16_SetStateMachine_m5303935E88DD68C4A40AEDBFCDF18F8DEA84E31B (U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Subscribe>d__35>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m7F46BD9D275C21386FD4E0DA80512950AFC6587E (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *, U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m7F46BD9D275C21386FD4E0DA80512950AFC6587E_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<System.UInt32>::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<Wamp/Response>,Wamp/<Subscribe>d__35>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_mDC84E980D918760546764180E8EFF9C820AC03B2 (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * __this, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * ___awaiter0, U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *, U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 *, const RuntimeMethod*))AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m57BB3F5D115E588824DA87484EC6B7F276A8EE22_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.UInt32 Wamp/Response::get_SubscriptionId()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR uint32_t Response_get_SubscriptionId_m38F262E5543B6AA4EB3EDDB8A8F1365B84284383_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,Wamp/PublishHandler>::TryAdd(!0,!1)
inline bool ConcurrentDictionary_2_TryAdd_mE2925CDD203464DF30191E99B8FC7F6FBD10420B (ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * __this, uint32_t ___key0, PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * ___value1, const RuntimeMethod* method)
{
	return ((  bool (*) (ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 *, uint32_t, PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 *, const RuntimeMethod*))ConcurrentDictionary_2_TryAdd_m4F1110173D40ADCBAB4393F0587D3AA607174FDE_gshared)(__this, ___key0, ___value1, method);
}
// System.Void Wamp/<Subscribe>d__35::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSubscribeU3Ed__35_MoveNext_m871F84E5292DE81E13BE9C94AB0EA8765E1D5285 (U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * __this, const RuntimeMethod* method);
// System.Void Wamp/<Subscribe>d__35::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSubscribeU3Ed__35_SetStateMachine_mDAD9620ACF150FAED21040DF4EAC8D41588BD7C6 (U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object,System.Object,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Format_m26BBF75F9609FAD0B39C2242FEBAAD7D68F14D99 (String_t* ___format0, RuntimeObject * ___arg01, RuntimeObject * ___arg12, RuntimeObject * ___arg23, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,Wamp/<Unsubscribe>d__36>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m553F9508C8EF12D8C31A1E1B935D79855E6FF52C (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * ___awaiter0, U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *, U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m553F9508C8EF12D8C31A1E1B935D79855E6FF52C_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter`1<Wamp/Response>,Wamp/<Unsubscribe>d__36>(!!0&,!!1&)
inline void AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m04E32B234DB4F762A2F7D6F2540BA392DBC0EF2A (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * __this, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * ___awaiter0, U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * ___stateMachine1, const RuntimeMethod* method)
{
	((  void (*) (AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *, TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *, U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 *, const RuntimeMethod*))AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t8CDB78D2A4D48E80C35A8FF6FC04A82B9FC35977_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m3E2EC9F9755076BFDAC850A9DF02962B255D4062_gshared)(__this, ___awaiter0, ___stateMachine1, method);
}
// System.Boolean System.Collections.Concurrent.ConcurrentDictionary`2<System.UInt32,Wamp/PublishHandler>::TryRemove(!0,!1&)
inline bool ConcurrentDictionary_2_TryRemove_m69838C15D68F91E4E959F18061311021A99D41FB (ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * __this, uint32_t ___key0, PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 ** ___value1, const RuntimeMethod* method)
{
	return ((  bool (*) (ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 *, uint32_t, PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 **, const RuntimeMethod*))ConcurrentDictionary_2_TryRemove_mE7E73F60C641310187824F20B776CF05ACBBAF9E_gshared)(__this, ___key0, ___value1, method);
}
// System.Void Wamp/<Unsubscribe>d__36::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CUnsubscribeU3Ed__36_MoveNext_m342B13779519EDA18D70E718177AFB7256C1CB54 (U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * __this, const RuntimeMethod* method);
// System.Void Wamp/<Unsubscribe>d__36::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CUnsubscribeU3Ed__36_SetStateMachine_mD7D2367D4B35E676ADA256D3997B6DBAF72B293E (U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method);
// System.Void System.Exception::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Exception__ctor_m89BADFF36C3B170013878726E07729D51AA9FBE0 (Exception_t * __this, String_t* ___message0, const RuntimeMethod* method);
// System.String System.String::Concat(System.String[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m232E857CA5107EA6AC52E7DD7018716C021F237B (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___values0, const RuntimeMethod* method);
// System.Void Wamp/ErrorException::set_Json(System.String)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void ErrorException_set_Json_m63B27B2FF42F2763E1B259F6CAA1B1813839D6EC_inline (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, String_t* ___value0, const RuntimeMethod* method);
// System.Void Wamp/ErrorException::set_MessageId(Wamp/Messages)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void ErrorException_set_MessageId_mB2E895A07D439F8EB5C11D1E02EEC602FC84DAB1_inline (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void Wamp/ErrorException::set_RequestId(System.Int32)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void ErrorException_set_RequestId_m141F6E4AA9228ECD9320038A3FC7D0633DDD53A9_inline (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void Wamp/ErrorException::set_Uri(System.String)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void ErrorException_set_Uri_mEFBFD6E03D38DA354BB53E6DA1467A6E1F97BE90_inline (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, String_t* ___value0, const RuntimeMethod* method);
// WwiseObjectInfo WwiseObjectInfoJsonObject::op_Implicit(WwiseObjectInfoJsonObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  WwiseObjectInfoJsonObject_op_Implicit_m891DE29A29F2BBD51786E3473155DB4938678A0B (WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * ___info0, const RuntimeMethod* method);
// WwiseObjectInfo WwiseObjectInfoJsonObject::ToObjectInfo(WwiseObjectInfoJsonObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  WwiseObjectInfoJsonObject_ToObjectInfo_m34217D48C83C57B40D1772E3C02CA43DCAE739E1 (WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * ___info0, const RuntimeMethod* method);
// System.String System.String::ToLower()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_ToLower_m5287204D93C9DDC4DF84581ADD756D0FDE2BA5A8 (String_t* __this, const RuntimeMethod* method);
// WwiseObjectType WaapiHelper::GetWwiseObjectTypeFromString(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WaapiHelper_GetWwiseObjectTypeFromString_m04C5DF50A1EA2E0B0188B3C71B94B2BB406A58DE (String_t* ___typeString0, String_t* ___workUnitType1, const RuntimeMethod* method);
// System.Guid System.Guid::Parse(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Guid_t  Guid_Parse_m665C7B8218EE95A0F8296F722CBA88C33E4C1286 (String_t* ___input0, const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkWaapiClient::add_Disconnected(Wamp_DisconnectedHandler)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkWaapiClient_add_Disconnected_m23455C48DF662205286001B85808AB1D4A8306E9 (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkWaapiClient_add_Disconnected_m23455C48DF662205286001B85808AB1D4A8306E9_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_0 = NULL;
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_1 = NULL;
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_2 = NULL;
	{
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_0 = __this->get_Disconnected_1();
		V_0 = L_0;
	}

IL_0007:
	{
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_1 = V_0;
		V_1 = L_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_2 = V_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_3 = ___value0;
		Delegate_t * L_4 = Delegate_Combine_mC25D2F7DECAFBA6D9A2F9EBA8A77063F0658ECF1(L_2, L_3, /*hidden argument*/NULL);
		V_2 = ((DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)CastclassSealed((RuntimeObject*)L_4, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3_il2cpp_TypeInfo_var));
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 ** L_5 = __this->get_address_of_Disconnected_1();
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_6 = V_2;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_7 = V_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_8 = InterlockedCompareExchangeImpl<DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *>((DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 **)L_5, L_6, L_7);
		V_0 = L_8;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_9 = V_0;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_10 = V_1;
		if ((!(((RuntimeObject*)(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)L_9) == ((RuntimeObject*)(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void AkWaapiClient::remove_Disconnected(Wamp_DisconnectedHandler)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkWaapiClient_remove_Disconnected_m0B10E01BB8B37C4FEF60591D0AA9F8943EE7345D (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkWaapiClient_remove_Disconnected_m0B10E01BB8B37C4FEF60591D0AA9F8943EE7345D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_0 = NULL;
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_1 = NULL;
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_2 = NULL;
	{
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_0 = __this->get_Disconnected_1();
		V_0 = L_0;
	}

IL_0007:
	{
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_1 = V_0;
		V_1 = L_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_2 = V_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_3 = ___value0;
		Delegate_t * L_4 = Delegate_Remove_m0B0DB7D1B3AF96B71AFAA72BA0EFE32FBBC2932D(L_2, L_3, /*hidden argument*/NULL);
		V_2 = ((DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)CastclassSealed((RuntimeObject*)L_4, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3_il2cpp_TypeInfo_var));
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 ** L_5 = __this->get_address_of_Disconnected_1();
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_6 = V_2;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_7 = V_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_8 = InterlockedCompareExchangeImpl<DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *>((DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 **)L_5, L_6, L_7);
		V_0 = L_8;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_9 = V_0;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_10 = V_1;
		if ((!(((RuntimeObject*)(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)L_9) == ((RuntimeObject*)(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Threading.Tasks.Task AkWaapiClient::Connect(System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * AkWaapiClient_Connect_m7B36FAFC8A88A778B1976073C457ACAFAD495374 (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, String_t* ___uri0, int32_t ___timeout1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkWaapiClient_Connect_m7B36FAFC8A88A778B1976073C457ACAFAD495374_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		String_t* L_0 = ___uri0;
		(&V_0)->set_uri_3(L_0);
		int32_t L_1 = ___timeout1;
		(&V_0)->set_timeout_4(L_1);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_2 = AsyncTaskMethodBuilder_Create_m081DF9A202E7C2F3CF3D41E1E63E63DA18F19FDB(/*hidden argument*/NULL);
		(&V_0)->set_U3CU3Et__builder_1(L_2);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248  L_3 = V_0;
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_4 = L_3.get_U3CU3Et__builder_1();
		V_1 = L_4;
		AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_mF16437EE3964A0173C4ACD6C55A8A527F10F6357((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)(&V_1), (U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_mF16437EE3964A0173C4ACD6C55A8A527F10F6357_RuntimeMethod_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_5 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_6 = AsyncTaskMethodBuilder_get_Task_m3E45BC00F7D224FEA04AB9BF26DB52E131D33022((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// System.Void AkWaapiClient::Wamp_Disconnected()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkWaapiClient_Wamp_Disconnected_mA53BAA173A2BFE01B0BD97F5BF3A2D1EC9E0113F (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, const RuntimeMethod* method)
{
	{
		// if (Disconnected != null)
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_0 = __this->get_Disconnected_1();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		// Disconnected();
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_1 = __this->get_Disconnected_1();
		NullCheck(L_1);
		DisconnectedHandler_Invoke_m08F15DEC1D0B8B106737140AF777D9CAEF92E79E(L_1, /*hidden argument*/NULL);
	}

IL_0013:
	{
		// }
		return;
	}
}
// System.Threading.Tasks.Task AkWaapiClient::Close(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * AkWaapiClient_Close_mE0747AE29CCE6D2F9367E62C7748CD02B2586A8B (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, int32_t ___timeout0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkWaapiClient_Close_mE0747AE29CCE6D2F9367E62C7748CD02B2586A8B_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		int32_t L_0 = ___timeout0;
		(&V_0)->set_timeout_3(L_0);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_1 = AsyncTaskMethodBuilder_Create_m081DF9A202E7C2F3CF3D41E1E63E63DA18F19FDB(/*hidden argument*/NULL);
		(&V_0)->set_U3CU3Et__builder_1(L_1);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D  L_2 = V_0;
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_3 = L_2.get_U3CU3Et__builder_1();
		V_1 = L_3;
		AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mC26FDDD09F7C37DC8CCAB604721FE4F6DC561F89((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)(&V_1), (U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mC26FDDD09F7C37DC8CCAB604721FE4F6DC561F89_RuntimeMethod_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_4 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_5 = AsyncTaskMethodBuilder_get_Task_m3E45BC00F7D224FEA04AB9BF26DB52E131D33022((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// System.Boolean AkWaapiClient::IsConnected()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkWaapiClient_IsConnected_m8946333A475C43407EA8008736236EFBBE2E103C (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, const RuntimeMethod* method)
{
	{
		// if (wamp == null)
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_0 = __this->get_wamp_0();
		if (L_0)
		{
			goto IL_000a;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_000a:
	{
		// return wamp.IsConnected();
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_wamp_0();
		NullCheck(L_1);
		bool L_2 = Wamp_IsConnected_m937F67F3943693AE69F82BA0897E18C163A0B70C(L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Threading.Tasks.Task`1<System.String> AkWaapiClient::Call(System.String,System.String,System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * AkWaapiClient_Call_m228E834AEDE74F68F26208B1073183014B984763 (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, String_t* ___uri0, String_t* ___args1, String_t* ___options2, int32_t ___timeout3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkWaapiClient_Call_m228E834AEDE74F68F26208B1073183014B984763_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		String_t* L_0 = ___uri0;
		(&V_0)->set_uri_5(L_0);
		String_t* L_1 = ___args1;
		(&V_0)->set_args_3(L_1);
		String_t* L_2 = ___options2;
		(&V_0)->set_options_4(L_2);
		int32_t L_3 = ___timeout3;
		(&V_0)->set_timeout_6(L_3);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  L_4 = AsyncTaskMethodBuilder_1_Create_m4CACDA7CCC96C431E5426E670B268CC6FDF86695(/*hidden argument*/AsyncTaskMethodBuilder_1_Create_m4CACDA7CCC96C431E5426E670B268CC6FDF86695_RuntimeMethod_var);
		(&V_0)->set_U3CU3Et__builder_1(L_4);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31  L_5 = V_0;
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  L_6 = L_5.get_U3CU3Et__builder_1();
		V_1 = L_6;
		AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_mF1115D2856D6D60A689700396433A6E0BFEF1B44((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)(&V_1), (U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_mF1115D2856D6D60A689700396433A6E0BFEF1B44_RuntimeMethod_var);
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_7 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * L_8 = AsyncTaskMethodBuilder_1_get_Task_mB005567F7203FC44DD0AE1150FFC92706B8E2BB4((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_7, /*hidden argument*/AsyncTaskMethodBuilder_1_get_Task_mB005567F7203FC44DD0AE1150FFC92706B8E2BB4_RuntimeMethod_var);
		return L_8;
	}
}
// System.Threading.Tasks.Task`1<System.UInt32> AkWaapiClient::Subscribe(System.String,System.String,Wamp_PublishHandler,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * AkWaapiClient_Subscribe_m4E52D19C0C845D3CCA1A1DA5CA9A77DAB7BDF996 (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, String_t* ___topic0, String_t* ___options1, PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * ___publishHandler2, int32_t ___timeout3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkWaapiClient_Subscribe_m4E52D19C0C845D3CCA1A1DA5CA9A77DAB7BDF996_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		String_t* L_0 = ___topic0;
		(&V_0)->set_topic_4(L_0);
		String_t* L_1 = ___options1;
		(&V_0)->set_options_3(L_1);
		PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * L_2 = ___publishHandler2;
		(&V_0)->set_publishHandler_5(L_2);
		int32_t L_3 = ___timeout3;
		(&V_0)->set_timeout_6(L_3);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  L_4 = AsyncTaskMethodBuilder_1_Create_mFA0E603D8EEE094438B0465D1E57747E2E12FC70(/*hidden argument*/AsyncTaskMethodBuilder_1_Create_mFA0E603D8EEE094438B0465D1E57747E2E12FC70_RuntimeMethod_var);
		(&V_0)->set_U3CU3Et__builder_1(L_4);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C  L_5 = V_0;
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  L_6 = L_5.get_U3CU3Et__builder_1();
		V_1 = L_6;
		AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_m9E8504336F653A9061842B0CE589D6072249F798((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)(&V_1), (U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_m9E8504336F653A9061842B0CE589D6072249F798_RuntimeMethod_var);
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_7 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * L_8 = AsyncTaskMethodBuilder_1_get_Task_m157191133E216D7561AD02E894BCA819FD5F98FF((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_7, /*hidden argument*/AsyncTaskMethodBuilder_1_get_Task_m157191133E216D7561AD02E894BCA819FD5F98FF_RuntimeMethod_var);
		return L_8;
	}
}
// System.Threading.Tasks.Task AkWaapiClient::Unsubscribe(System.UInt32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * AkWaapiClient_Unsubscribe_m1B4867EC231A6315D787905D00FCD8E6A249EC25 (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, uint32_t ___subscriptionId0, int32_t ___timeout1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkWaapiClient_Unsubscribe_m1B4867EC231A6315D787905D00FCD8E6A249EC25_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		uint32_t L_0 = ___subscriptionId0;
		(&V_0)->set_subscriptionId_3(L_0);
		int32_t L_1 = ___timeout1;
		(&V_0)->set_timeout_4(L_1);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_2 = AsyncTaskMethodBuilder_Create_m081DF9A202E7C2F3CF3D41E1E63E63DA18F19FDB(/*hidden argument*/NULL);
		(&V_0)->set_U3CU3Et__builder_1(L_2);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D  L_3 = V_0;
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_4 = L_3.get_U3CU3Et__builder_1();
		V_1 = L_4;
		AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_m8DCB5F69062BBD1684327A53545EED187BDE62C7((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)(&V_1), (U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_m8DCB5F69062BBD1684327A53545EED187BDE62C7_RuntimeMethod_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_5 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_6 = AsyncTaskMethodBuilder_get_Task_m3E45BC00F7D224FEA04AB9BF26DB52E131D33022((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// System.Void AkWaapiClient::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkWaapiClient__ctor_mB410C36E69BBAFD1C690B4872D89C02F38876242 (AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkWaapiClient_<Call>d__8::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3 (U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * V_1 = NULL;
	String_t* V_2 = NULL;
	TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214  V_3;
	memset((&V_3), 0, sizeof(V_3));
	Exception_t * V_4 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 3);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_009f;
			}
		}

IL_0014:
		{
			// if (wamp == null)
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_3 = V_1;
			NullCheck(L_3);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_4 = L_3->get_wamp_0();
			if (L_4)
			{
				goto IL_0027;
			}
		}

IL_001c:
		{
			// throw new Wamp.WampNotConnectedException("WAMP connection is not established");
			WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F * L_5 = (WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F *)il2cpp_codegen_object_new(WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F_il2cpp_TypeInfo_var);
			WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD(L_5, _stringLiteralE7BFD0F7AF4EBF7DA118143137EA49D776896104, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_5, U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3_RuntimeMethod_var);
		}

IL_0027:
		{
			// if (args == null)
			String_t* L_6 = __this->get_args_3();
			if (L_6)
			{
				goto IL_003a;
			}
		}

IL_002f:
		{
			// args = "{}";
			__this->set_args_3(_stringLiteralBF21A9E8FBC5A3846FB05B4FA0859E0917B2202F);
		}

IL_003a:
		{
			// if (options == null)
			String_t* L_7 = __this->get_options_4();
			if (L_7)
			{
				goto IL_004d;
			}
		}

IL_0042:
		{
			// options = "{}";
			__this->set_options_4(_stringLiteralBF21A9E8FBC5A3846FB05B4FA0859E0917B2202F);
		}

IL_004d:
		{
			// return await wamp.Call(uri, args, options, timeout);
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_8 = V_1;
			NullCheck(L_8);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_9 = L_8->get_wamp_0();
			String_t* L_10 = __this->get_uri_5();
			String_t* L_11 = __this->get_args_3();
			String_t* L_12 = __this->get_options_4();
			int32_t L_13 = __this->get_timeout_6();
			NullCheck(L_9);
			Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * L_14 = Wamp_Call_mAE552B01EB08CE7275EEDD97710E512589D61B33(L_9, L_10, L_11, L_12, L_13, /*hidden argument*/NULL);
			NullCheck(L_14);
			TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214  L_15 = Task_1_GetAwaiter_m7A7CC7C265752869A4FE28A21A3780AE1814DC56(L_14, /*hidden argument*/Task_1_GetAwaiter_m7A7CC7C265752869A4FE28A21A3780AE1814DC56_RuntimeMethod_var);
			V_3 = L_15;
			bool L_16 = TaskAwaiter_1_get_IsCompleted_m1B663832F61F0CC68E324522D851F61F4D9DCE13((TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 *)(&V_3), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_m1B663832F61F0CC68E324522D851F61F4D9DCE13_RuntimeMethod_var);
			if (L_16)
			{
				goto IL_00bb;
			}
		}

IL_007f:
		{
			int32_t L_17 = 0;
			V_0 = L_17;
			__this->set_U3CU3E1__state_0(L_17);
			TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214  L_18 = V_3;
			__this->set_U3CU3Eu__1_7(L_18);
			AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_19 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_mD1999A0F69B3FB48161783859F369FDCA943E7ED((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_19, (TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 *)(&V_3), (U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214_TisU3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31_mD1999A0F69B3FB48161783859F369FDCA943E7ED_RuntimeMethod_var);
			goto IL_00f2;
		}

IL_009f:
		{
			TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214  L_20 = __this->get_U3CU3Eu__1_7();
			V_3 = L_20;
			TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 * L_21 = __this->get_address_of_U3CU3Eu__1_7();
			il2cpp_codegen_initobj(L_21, sizeof(TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 ));
			int32_t L_22 = (-1);
			V_0 = L_22;
			__this->set_U3CU3E1__state_0(L_22);
		}

IL_00bb:
		{
			String_t* L_23 = TaskAwaiter_1_GetResult_m09DDE7E4E666D55579B249C10764EFC380DAB78B((TaskAwaiter_1_t0139085A70D09D28A04F5187195DC0184E53D214 *)(&V_3), /*hidden argument*/TaskAwaiter_1_GetResult_m09DDE7E4E666D55579B249C10764EFC380DAB78B_RuntimeMethod_var);
			V_2 = L_23;
			goto IL_00de;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_00c5;
		throw e;
	}

CATCH_00c5:
	{ // begin catch(System.Exception)
		V_4 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_24 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_25 = V_4;
		AsyncTaskMethodBuilder_1_SetException_m7EC0D7D4B3431CA02400760ADA732A416EAEFB2D((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_24, L_25, /*hidden argument*/AsyncTaskMethodBuilder_1_SetException_m7EC0D7D4B3431CA02400760ADA732A416EAEFB2D_RuntimeMethod_var);
		goto IL_00f2;
	} // end catch (depth: 1)

IL_00de:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_26 = __this->get_address_of_U3CU3Et__builder_1();
		String_t* L_27 = V_2;
		AsyncTaskMethodBuilder_1_SetResult_m44836E9953D99A304CCB8725A8E47453725FFE9B((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_26, L_27, /*hidden argument*/AsyncTaskMethodBuilder_1_SetResult_m44836E9953D99A304CCB8725A8E47453725FFE9B_RuntimeMethod_var);
	}

IL_00f2:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * _thisAdjusted = reinterpret_cast<U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 *>(__this + _offset);
	U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3(_thisAdjusted, method);
}
// System.Void AkWaapiClient_<Call>d__8::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCallU3Ed__8_SetStateMachine_mD2692F6222738E5FB87B23429B8DD0B43F651FDC (U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CCallU3Ed__8_SetStateMachine_mD2692F6222738E5FB87B23429B8DD0B43F651FDC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_1_SetStateMachine_m83945BA8843F53C1C9ED18D4B312FFF9A24BB9EB((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_0, L_1, /*hidden argument*/AsyncTaskMethodBuilder_1_SetStateMachine_m83945BA8843F53C1C9ED18D4B312FFF9A24BB9EB_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CCallU3Ed__8_SetStateMachine_mD2692F6222738E5FB87B23429B8DD0B43F651FDC_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 * _thisAdjusted = reinterpret_cast<U3CCallU3Ed__8_t952EFEB991F23F593C85C37B60A2415BC6A8ED31 *>(__this + _offset);
	U3CCallU3Ed__8_SetStateMachine_mD2692F6222738E5FB87B23429B8DD0B43F651FDC(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkWaapiClient_<Close>d__6::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517 (U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * V_1 = NULL;
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  V_2;
	memset((&V_2), 0, sizeof(V_2));
	Exception_t * V_3 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 3);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_0064;
			}
		}

IL_0011:
		{
			// if (wamp == null)
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_3 = V_1;
			NullCheck(L_3);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_4 = L_3->get_wamp_0();
			if (L_4)
			{
				goto IL_0024;
			}
		}

IL_0019:
		{
			// throw new Wamp.WampNotConnectedException("WAMP connection is not established");
			WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F * L_5 = (WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F *)il2cpp_codegen_object_new(WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F_il2cpp_TypeInfo_var);
			WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD(L_5, _stringLiteralE7BFD0F7AF4EBF7DA118143137EA49D776896104, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_5, U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517_RuntimeMethod_var);
		}

IL_0024:
		{
			// await wamp.Close(timeout);
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_6 = V_1;
			NullCheck(L_6);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_7 = L_6->get_wamp_0();
			int32_t L_8 = __this->get_timeout_3();
			NullCheck(L_7);
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_9 = Wamp_Close_m8607EFADFFC175CC0825312F7EFA8E175FA39B74(L_7, L_8, /*hidden argument*/NULL);
			NullCheck(L_9);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_10 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_9, /*hidden argument*/NULL);
			V_2 = L_10;
			bool L_11 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
			if (L_11)
			{
				goto IL_0080;
			}
		}

IL_0044:
		{
			int32_t L_12 = 0;
			V_0 = L_12;
			__this->set_U3CU3E1__state_0(L_12);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_13 = V_2;
			__this->set_U3CU3Eu__1_4(L_13);
			AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_14 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mA764FAAB815FCF8AE6EEDC1517B93BDDDA7D35E6((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_14, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), (U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D_mA764FAAB815FCF8AE6EEDC1517B93BDDDA7D35E6_RuntimeMethod_var);
			goto IL_00d1;
		}

IL_0064:
		{
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_15 = __this->get_U3CU3Eu__1_4();
			V_2 = L_15;
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_16 = __this->get_address_of_U3CU3Eu__1_4();
			il2cpp_codegen_initobj(L_16, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
			int32_t L_17 = (-1);
			V_0 = L_17;
			__this->set_U3CU3E1__state_0(L_17);
		}

IL_0080:
		{
			TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
			// wamp.Disconnected -= Wamp_Disconnected;
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_18 = V_1;
			NullCheck(L_18);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_19 = L_18->get_wamp_0();
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_20 = V_1;
			DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_21 = (DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)il2cpp_codegen_object_new(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3_il2cpp_TypeInfo_var);
			DisconnectedHandler__ctor_m742456B3847D7F450EEFBD2053B6C43C3D272C80(L_21, L_20, (intptr_t)((intptr_t)AkWaapiClient_Wamp_Disconnected_mA53BAA173A2BFE01B0BD97F5BF3A2D1EC9E0113F_RuntimeMethod_var), /*hidden argument*/NULL);
			NullCheck(L_19);
			Wamp_remove_Disconnected_m733F63A5B3D9B63CA05DB0B31C6BE3C9456D7D9F(L_19, L_21, /*hidden argument*/NULL);
			// wamp = null;
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_22 = V_1;
			NullCheck(L_22);
			L_22->set_wamp_0((Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 *)NULL);
			goto IL_00be;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_00a7;
		throw e;
	}

CATCH_00a7:
	{ // begin catch(System.Exception)
		V_3 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_23 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_24 = V_3;
		AsyncTaskMethodBuilder_SetException_m370C484922A63A6EF96E241D1370B8814F1F2D6B((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_23, L_24, /*hidden argument*/NULL);
		goto IL_00d1;
	} // end catch (depth: 1)

IL_00be:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_25 = __this->get_address_of_U3CU3Et__builder_1();
		AsyncTaskMethodBuilder_SetResult_m151016FB698F3BB34A73BAE693A97513A7E4C838((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_25, /*hidden argument*/NULL);
	}

IL_00d1:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * _thisAdjusted = reinterpret_cast<U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D *>(__this + _offset);
	U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517(_thisAdjusted, method);
}
// System.Void AkWaapiClient_<Close>d__6::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCloseU3Ed__6_SetStateMachine_m55135EC1DC2BD15058D218A67C6AB2019D6653FE (U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	{
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_SetStateMachine_mB5DD68F7C49EA6D452AEBA02B1B98AED898C3C25((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CCloseU3Ed__6_SetStateMachine_m55135EC1DC2BD15058D218A67C6AB2019D6653FE_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D * _thisAdjusted = reinterpret_cast<U3CCloseU3Ed__6_tE14B1C9211ED1579A8B64E117A216640B1182E5D *>(__this + _offset);
	U3CCloseU3Ed__6_SetStateMachine_m55135EC1DC2BD15058D218A67C6AB2019D6653FE(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkWaapiClient_<Connect>d__4::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CConnectU3Ed__4_MoveNext_m13F3495E6D4BDE5F1C839110864B68AB3F5B7BB6 (U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CConnectU3Ed__4_MoveNext_m13F3495E6D4BDE5F1C839110864B68AB3F5B7BB6_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * V_1 = NULL;
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  V_2;
	memset((&V_2), 0, sizeof(V_2));
	Exception_t * V_3 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 3);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_0081;
			}
		}

IL_0011:
		{
			// if (wamp == null)
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_3 = V_1;
			NullCheck(L_3);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_4 = L_3->get_wamp_0();
			if (L_4)
			{
				goto IL_0024;
			}
		}

IL_0019:
		{
			// wamp = new Wamp();
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_5 = V_1;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_6 = (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 *)il2cpp_codegen_object_new(Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24_il2cpp_TypeInfo_var);
			Wamp__ctor_mCD0D3AC4AB87B0AC898D448724AB0568594D6193(L_6, /*hidden argument*/NULL);
			NullCheck(L_5);
			L_5->set_wamp_0(L_6);
		}

IL_0024:
		{
			// wamp.Disconnected += Wamp_Disconnected;
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_7 = V_1;
			NullCheck(L_7);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_8 = L_7->get_wamp_0();
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_9 = V_1;
			DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_10 = (DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)il2cpp_codegen_object_new(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3_il2cpp_TypeInfo_var);
			DisconnectedHandler__ctor_m742456B3847D7F450EEFBD2053B6C43C3D272C80(L_10, L_9, (intptr_t)((intptr_t)AkWaapiClient_Wamp_Disconnected_mA53BAA173A2BFE01B0BD97F5BF3A2D1EC9E0113F_RuntimeMethod_var), /*hidden argument*/NULL);
			NullCheck(L_8);
			Wamp_add_Disconnected_mBAA1A70AD8CE39B3A45DB824FB26FF9C2C11F143(L_8, L_10, /*hidden argument*/NULL);
			// await wamp.Connect(uri, timeout);
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_11 = V_1;
			NullCheck(L_11);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_12 = L_11->get_wamp_0();
			String_t* L_13 = __this->get_uri_3();
			int32_t L_14 = __this->get_timeout_4();
			NullCheck(L_12);
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_15 = Wamp_Connect_m091D964EE6A72E12FA0905681BF78AD05D9D7FAB(L_12, L_13, L_14, /*hidden argument*/NULL);
			NullCheck(L_15);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_16 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_15, /*hidden argument*/NULL);
			V_2 = L_16;
			bool L_17 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
			if (L_17)
			{
				goto IL_009d;
			}
		}

IL_0061:
		{
			int32_t L_18 = 0;
			V_0 = L_18;
			__this->set_U3CU3E1__state_0(L_18);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_19 = V_2;
			__this->set_U3CU3Eu__1_5(L_19);
			AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_20 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_m86930540C6C3B639FB8E3043C372E6B46488F0AD((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_20, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), (U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248_m86930540C6C3B639FB8E3043C372E6B46488F0AD_RuntimeMethod_var);
			goto IL_00d0;
		}

IL_0081:
		{
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_21 = __this->get_U3CU3Eu__1_5();
			V_2 = L_21;
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_22 = __this->get_address_of_U3CU3Eu__1_5();
			il2cpp_codegen_initobj(L_22, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
			int32_t L_23 = (-1);
			V_0 = L_23;
			__this->set_U3CU3E1__state_0(L_23);
		}

IL_009d:
		{
			TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
			goto IL_00bd;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_00a6;
		throw e;
	}

CATCH_00a6:
	{ // begin catch(System.Exception)
		V_3 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_24 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_25 = V_3;
		AsyncTaskMethodBuilder_SetException_m370C484922A63A6EF96E241D1370B8814F1F2D6B((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_24, L_25, /*hidden argument*/NULL);
		goto IL_00d0;
	} // end catch (depth: 1)

IL_00bd:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_26 = __this->get_address_of_U3CU3Et__builder_1();
		AsyncTaskMethodBuilder_SetResult_m151016FB698F3BB34A73BAE693A97513A7E4C838((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_26, /*hidden argument*/NULL);
	}

IL_00d0:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CConnectU3Ed__4_MoveNext_m13F3495E6D4BDE5F1C839110864B68AB3F5B7BB6_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * _thisAdjusted = reinterpret_cast<U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 *>(__this + _offset);
	U3CConnectU3Ed__4_MoveNext_m13F3495E6D4BDE5F1C839110864B68AB3F5B7BB6(_thisAdjusted, method);
}
// System.Void AkWaapiClient_<Connect>d__4::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CConnectU3Ed__4_SetStateMachine_mDF27AC5C9A5B8B3E4254E946CBB2F67107F6F757 (U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	{
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_SetStateMachine_mB5DD68F7C49EA6D452AEBA02B1B98AED898C3C25((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CConnectU3Ed__4_SetStateMachine_mDF27AC5C9A5B8B3E4254E946CBB2F67107F6F757_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 * _thisAdjusted = reinterpret_cast<U3CConnectU3Ed__4_t5766176CE6D3BEADC47949F9489E0584ABCC7248 *>(__this + _offset);
	U3CConnectU3Ed__4_SetStateMachine_mDF27AC5C9A5B8B3E4254E946CBB2F67107F6F757(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkWaapiClient_<Subscribe>d__9::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760 (U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * V_1 = NULL;
	uint32_t V_2 = 0;
	TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  V_3;
	memset((&V_3), 0, sizeof(V_3));
	Exception_t * V_4 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 3);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_0089;
			}
		}

IL_0011:
		{
			// if (wamp == null)
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_3 = V_1;
			NullCheck(L_3);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_4 = L_3->get_wamp_0();
			if (L_4)
			{
				goto IL_0024;
			}
		}

IL_0019:
		{
			// throw new Wamp.WampNotConnectedException("WAMP connection is not established");
			WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F * L_5 = (WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F *)il2cpp_codegen_object_new(WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F_il2cpp_TypeInfo_var);
			WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD(L_5, _stringLiteralE7BFD0F7AF4EBF7DA118143137EA49D776896104, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_5, U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760_RuntimeMethod_var);
		}

IL_0024:
		{
			// if (options == null)
			String_t* L_6 = __this->get_options_3();
			if (L_6)
			{
				goto IL_0037;
			}
		}

IL_002c:
		{
			// options = "{}";
			__this->set_options_3(_stringLiteralBF21A9E8FBC5A3846FB05B4FA0859E0917B2202F);
		}

IL_0037:
		{
			// return await wamp.Subscribe(topic, options, publishHandler, timeout);
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_7 = V_1;
			NullCheck(L_7);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_8 = L_7->get_wamp_0();
			String_t* L_9 = __this->get_topic_4();
			String_t* L_10 = __this->get_options_3();
			PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * L_11 = __this->get_publishHandler_5();
			int32_t L_12 = __this->get_timeout_6();
			NullCheck(L_8);
			Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * L_13 = Wamp_Subscribe_mC841A9CDF1DA84F41596A6E4E087CB13C8AF4F40(L_8, L_9, L_10, L_11, L_12, /*hidden argument*/NULL);
			NullCheck(L_13);
			TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  L_14 = Task_1_GetAwaiter_m67228F27784EA8C9DF71B165FAB7072A46C28A9E(L_13, /*hidden argument*/Task_1_GetAwaiter_m67228F27784EA8C9DF71B165FAB7072A46C28A9E_RuntimeMethod_var);
			V_3 = L_14;
			bool L_15 = TaskAwaiter_1_get_IsCompleted_mD9FB168E3D6034701DE4736347E1B30AE6CCE70F((TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 *)(&V_3), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_mD9FB168E3D6034701DE4736347E1B30AE6CCE70F_RuntimeMethod_var);
			if (L_15)
			{
				goto IL_00a5;
			}
		}

IL_0069:
		{
			int32_t L_16 = 0;
			V_0 = L_16;
			__this->set_U3CU3E1__state_0(L_16);
			TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  L_17 = V_3;
			__this->set_U3CU3Eu__1_7(L_17);
			AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_18 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_mABEC0D792F8A5AC3256DBC194D55631CC98783FB((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_18, (TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 *)(&V_3), (U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830_TisU3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C_mABEC0D792F8A5AC3256DBC194D55631CC98783FB_RuntimeMethod_var);
			goto IL_00dc;
		}

IL_0089:
		{
			TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830  L_19 = __this->get_U3CU3Eu__1_7();
			V_3 = L_19;
			TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 * L_20 = __this->get_address_of_U3CU3Eu__1_7();
			il2cpp_codegen_initobj(L_20, sizeof(TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 ));
			int32_t L_21 = (-1);
			V_0 = L_21;
			__this->set_U3CU3E1__state_0(L_21);
		}

IL_00a5:
		{
			uint32_t L_22 = TaskAwaiter_1_GetResult_mD575FD03753A3FD916DFF7C9834342D3EEEB0EE8((TaskAwaiter_1_t4775EBEDF8907030D3D4E4F035D7BC9DD18E8830 *)(&V_3), /*hidden argument*/TaskAwaiter_1_GetResult_mD575FD03753A3FD916DFF7C9834342D3EEEB0EE8_RuntimeMethod_var);
			V_2 = L_22;
			goto IL_00c8;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_00af;
		throw e;
	}

CATCH_00af:
	{ // begin catch(System.Exception)
		V_4 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_23 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_24 = V_4;
		AsyncTaskMethodBuilder_1_SetException_m4BCFE40068BC66F1C48B5C7C7C9F93F5E48EF00B((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_23, L_24, /*hidden argument*/AsyncTaskMethodBuilder_1_SetException_m4BCFE40068BC66F1C48B5C7C7C9F93F5E48EF00B_RuntimeMethod_var);
		goto IL_00dc;
	} // end catch (depth: 1)

IL_00c8:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_25 = __this->get_address_of_U3CU3Et__builder_1();
		uint32_t L_26 = V_2;
		AsyncTaskMethodBuilder_1_SetResult_m887E134B6FD52D8CA2116A466F69BC8E1EA6ED5E((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_25, L_26, /*hidden argument*/AsyncTaskMethodBuilder_1_SetResult_m887E134B6FD52D8CA2116A466F69BC8E1EA6ED5E_RuntimeMethod_var);
	}

IL_00dc:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * _thisAdjusted = reinterpret_cast<U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C *>(__this + _offset);
	U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760(_thisAdjusted, method);
}
// System.Void AkWaapiClient_<Subscribe>d__9::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSubscribeU3Ed__9_SetStateMachine_m5AD4A356DAE70F2EC5F1BB8257BEEF5008C4117F (U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CSubscribeU3Ed__9_SetStateMachine_m5AD4A356DAE70F2EC5F1BB8257BEEF5008C4117F_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_1_SetStateMachine_m2C2B09AB812EDEDAB3C9E89B8A2BF19C4EC8B45F((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_0, L_1, /*hidden argument*/AsyncTaskMethodBuilder_1_SetStateMachine_m2C2B09AB812EDEDAB3C9E89B8A2BF19C4EC8B45F_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CSubscribeU3Ed__9_SetStateMachine_m5AD4A356DAE70F2EC5F1BB8257BEEF5008C4117F_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C * _thisAdjusted = reinterpret_cast<U3CSubscribeU3Ed__9_t63C8A1D02F682314AEE7EF720B4401CFD3DCDB5C *>(__this + _offset);
	U3CSubscribeU3Ed__9_SetStateMachine_m5AD4A356DAE70F2EC5F1BB8257BEEF5008C4117F(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkWaapiClient_<Unsubscribe>d__10::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4 (U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * V_1 = NULL;
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  V_2;
	memset((&V_2), 0, sizeof(V_2));
	Exception_t * V_3 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 3);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_006a;
			}
		}

IL_0011:
		{
			// if (wamp == null)
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_3 = V_1;
			NullCheck(L_3);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_4 = L_3->get_wamp_0();
			if (L_4)
			{
				goto IL_0024;
			}
		}

IL_0019:
		{
			// throw new Wamp.WampNotConnectedException("WAMP connection is not established");
			WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F * L_5 = (WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F *)il2cpp_codegen_object_new(WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F_il2cpp_TypeInfo_var);
			WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD(L_5, _stringLiteralE7BFD0F7AF4EBF7DA118143137EA49D776896104, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_5, U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4_RuntimeMethod_var);
		}

IL_0024:
		{
			// await wamp.Unsubscribe(subscriptionId, timeout);
			AkWaapiClient_t6B89ED8AD7E03AC9C9FFF976E3A15D726520F4A1 * L_6 = V_1;
			NullCheck(L_6);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_7 = L_6->get_wamp_0();
			uint32_t L_8 = __this->get_subscriptionId_3();
			int32_t L_9 = __this->get_timeout_4();
			NullCheck(L_7);
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_10 = Wamp_Unsubscribe_m185B046DAF9E4293617E8A512747B768958ABA6C(L_7, L_8, L_9, /*hidden argument*/NULL);
			NullCheck(L_10);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_11 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_10, /*hidden argument*/NULL);
			V_2 = L_11;
			bool L_12 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
			if (L_12)
			{
				goto IL_0086;
			}
		}

IL_004a:
		{
			int32_t L_13 = 0;
			V_0 = L_13;
			__this->set_U3CU3E1__state_0(L_13);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_14 = V_2;
			__this->set_U3CU3Eu__1_5(L_14);
			AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_15 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_mD436987D09427E1D06EC26E219AD2D10638951B6((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_15, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), (U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D_mD436987D09427E1D06EC26E219AD2D10638951B6_RuntimeMethod_var);
			goto IL_00b9;
		}

IL_006a:
		{
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_16 = __this->get_U3CU3Eu__1_5();
			V_2 = L_16;
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_17 = __this->get_address_of_U3CU3Eu__1_5();
			il2cpp_codegen_initobj(L_17, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
			int32_t L_18 = (-1);
			V_0 = L_18;
			__this->set_U3CU3E1__state_0(L_18);
		}

IL_0086:
		{
			TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
			goto IL_00a6;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_008f;
		throw e;
	}

CATCH_008f:
	{ // begin catch(System.Exception)
		V_3 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_19 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_20 = V_3;
		AsyncTaskMethodBuilder_SetException_m370C484922A63A6EF96E241D1370B8814F1F2D6B((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_19, L_20, /*hidden argument*/NULL);
		goto IL_00b9;
	} // end catch (depth: 1)

IL_00a6:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_21 = __this->get_address_of_U3CU3Et__builder_1();
		AsyncTaskMethodBuilder_SetResult_m151016FB698F3BB34A73BAE693A97513A7E4C838((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_21, /*hidden argument*/NULL);
	}

IL_00b9:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * _thisAdjusted = reinterpret_cast<U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D *>(__this + _offset);
	U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4(_thisAdjusted, method);
}
// System.Void AkWaapiClient_<Unsubscribe>d__10::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CUnsubscribeU3Ed__10_SetStateMachine_m3DD99D8798B4C3D9DB2A04230689657AC1139F8C (U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	{
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_SetStateMachine_mB5DD68F7C49EA6D452AEBA02B1B98AED898C3C25((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CUnsubscribeU3Ed__10_SetStateMachine_m3DD99D8798B4C3D9DB2A04230689657AC1139F8C_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D * _thisAdjusted = reinterpret_cast<U3CUnsubscribeU3Ed__10_t9FC9C22261A531D856D958416D95E64A6464171D *>(__this + _offset);
	U3CUnsubscribeU3Ed__10_SetStateMachine_m3DD99D8798B4C3D9DB2A04230689657AC1139F8C(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Args::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9 (Args_tB23D16D3FE3BEA2DEAD3B2189F34A81470ABD34D * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ArgsCommand::.ctor(System.String,System.String[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArgsCommand__ctor_m60D67E600FEA543B4081DCC6AA447751013D6E1B (ArgsCommand_t675212B8DFD4A88AFF6A0484842254A82CBCAFD2 * __this, String_t* ___c0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___objectIds1, const RuntimeMethod* method)
{
	{
		// public ArgsCommand(string c, string[] objectIds)
		Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9(__this, /*hidden argument*/NULL);
		// command = c;
		String_t* L_0 = ___c0;
		__this->set_command_1(L_0);
		// objects = objectIds;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_1 = ___objectIds1;
		__this->set_objects_0(L_1);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ArgsDisplayName::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArgsDisplayName__ctor_m2B14218C56F0061404AC79875F90150C2FD76D63 (ArgsDisplayName_tB0504FC27F9B3A43933A54C7CE48C2480CD36DCD * __this, String_t* ___displayName0, const RuntimeMethod* method)
{
	{
		// public ArgsDisplayName(string displayName)
		Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9(__this, /*hidden argument*/NULL);
		// this.displayName = displayName;
		String_t* L_0 = ___displayName0;
		__this->set_displayName_0(L_0);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ArgsObject::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArgsObject__ctor_m8F267DB607A75FCF3F2FA67A0F59A6F677FA0191 (ArgsObject_t58DE1003F3AF0D598690ED9208AC6BF67819D832 * __this, String_t* ___objectId0, const RuntimeMethod* method)
{
	{
		// public ArgsObject(string objectId)
		Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9(__this, /*hidden argument*/NULL);
		// @object = objectId;
		String_t* L_0 = ___objectId0;
		__this->set_object_0(L_0);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ArgsPlay::.ctor(System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArgsPlay__ctor_m15D42EC03786D00B07138F46DCD3751BF167AD5C (ArgsPlay_t5EA1BD810BBA204223D66BA4E6650B78FB2BDDDB * __this, String_t* ___a0, int32_t ___t1, const RuntimeMethod* method)
{
	{
		// public ArgsPlay(string a, int t) { action = a; transport = t; }
		Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9(__this, /*hidden argument*/NULL);
		// public ArgsPlay(string a, int t) { action = a; transport = t; }
		String_t* L_0 = ___a0;
		__this->set_action_0(L_0);
		// public ArgsPlay(string a, int t) { action = a; transport = t; }
		int32_t L_1 = ___t1;
		__this->set_transport_1(L_1);
		// public ArgsPlay(string a, int t) { action = a; transport = t; }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ArgsRename::.ctor(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArgsRename__ctor_mED3E3B39211B2C8E699CBC3C519F3FAC37C6FFCD (ArgsRename_tDD8FBA42725ABDCAEA48D8EFEDEAC1E343BFA414 * __this, String_t* ___objectId0, String_t* ___value1, const RuntimeMethod* method)
{
	{
		// public ArgsRename(string objectId, string value)
		Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9(__this, /*hidden argument*/NULL);
		// @object = objectId;
		String_t* L_0 = ___objectId0;
		__this->set_object_0(L_0);
		// this.value = value;
		String_t* L_1 = ___value1;
		__this->set_value_1(L_1);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ArgsTransport::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArgsTransport__ctor_mF279D8D1041917F43379FFC68EC8E345367F5C74 (ArgsTransport_t924F2C28D1C132CA258F1C6F1E7236DC0DF76CD2 * __this, int32_t ___t0, const RuntimeMethod* method)
{
	{
		// public ArgsTransport(int t) { transport = t; }
		Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9(__this, /*hidden argument*/NULL);
		// public ArgsTransport(int t) { transport = t; }
		int32_t L_0 = ___t0;
		__this->set_transport_0(L_0);
		// public ArgsTransport(int t) { transport = t; }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ErrorDetails::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ErrorDetails__ctor_m3BA1C08EF47154C3EAF9DD5C5B7BADB4EDE30E39 (ErrorDetails_t21A26837A9AD74120E02D79946F6D3B03EC5AAA2 * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ErrorMessage::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ErrorMessage__ctor_m4DF7DC147C5FA9FBA0206CEFF78E03DED4C31AA3 (ErrorMessage_tED7633C6802CF0672E6C52EB479D17926BDCCEBC * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.String JsonSerializable::op_Implicit(JsonSerializable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* JsonSerializable_op_Implicit_m3C7EB2F1AB6BCB3FE77634021CC6841E1B179680 (JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B * ___o0, const RuntimeMethod* method)
{
	{
		// public static implicit operator string(JsonSerializable o) => UnityEngine.JsonUtility.ToJson(o);
		JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B * L_0 = ___o0;
		String_t* L_1 = JsonUtility_ToJson_m588D3BCFA6FC7FA342FC221D4CB02729E901E573(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Void JsonSerializable::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE (JsonSerializable_t6166B151C84BD16B0B14D9412D83D29B78B9EB8B * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Options::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Options__ctor_mB2226F341FEBF5B020CF7942625A2F7652485163 (Options_t36565DDE7EEC80CC7827D71EEC8E99E37411D050 * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ReturnOptions::.ctor(System.String[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ReturnOptions__ctor_m788C3E784D91725A93065E30AB42A1578C043526 (ReturnOptions_tBED022AD296CD58A16E37C3DBC9D07089EA289FD * __this, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___infokeys0, const RuntimeMethod* method)
{
	{
		// public ReturnOptions(string [] infokeys)
		Options__ctor_mB2226F341FEBF5B020CF7942625A2F7652485163(__this, /*hidden argument*/NULL);
		// @return = infokeys;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_0 = ___infokeys0;
		__this->set_return_0(L_0);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ReturnTransport::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ReturnTransport__ctor_mDD5D0EC2E8085540DBFE074FE601CDA6EC502457 (ReturnTransport_tB91DDDE10CD868C4AA03BEF7F4AA95E78E54F2DD * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ReturnWwiseObjects::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ReturnWwiseObjects__ctor_m94A86AE27A1F0BE528A4EEC26E19F2210EF8E607 (ReturnWwiseObjects_t4AC346E1F2794A85FF82A3E8463A838E2D90B4B8 * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void SelectedWwiseObjects::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SelectedWwiseObjects__ctor_m9784904F53E10976B5EB7E76796A6DA2392C5915 (SelectedWwiseObjects_t4B9895C68B1B11B76DC69F9C6DB2E69BB714E7A0 * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void TransportOptions::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TransportOptions__ctor_mF0DD9736D70BF4FEE558F4AC4EEA41E7E0833270 (TransportOptions_t9EEC93A2E911B9D1A386999782BE3168373A2527 * __this, int32_t ___id0, const RuntimeMethod* method)
{
	{
		// public TransportOptions(int id)
		Options__ctor_mB2226F341FEBF5B020CF7942625A2F7652485163(__this, /*hidden argument*/NULL);
		// transport = id;
		int32_t L_0 = ___id0;
		__this->set_transport_0(L_0);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void TransportState::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TransportState__ctor_m3C589B89FBBAA471911E58AF4D386EC8BEF76793 (TransportState_t1F81EF9D2597F1351B60E6530C77973DA92DC7AD * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WaapiHelper::GetWwiseObjectTypeFromString(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WaapiHelper_GetWwiseObjectTypeFromString_m04C5DF50A1EA2E0B0188B3C71B94B2BB406A58DE (String_t* ___typeString0, String_t* ___workUnitType1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (WaapiHelper_GetWwiseObjectTypeFromString_m04C5DF50A1EA2E0B0188B3C71B94B2BB406A58DE_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (!WaapiKeywords.typeStringDict.ContainsKey(typeString))
		IL2CPP_RUNTIME_CLASS_INIT(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var);
		ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * L_0 = ((WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields*)il2cpp_codegen_static_fields_for(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var))->get_typeStringDict_84();
		String_t* L_1 = ___typeString0;
		NullCheck(L_0);
		bool L_2 = ReadOnlyDictionary_2_ContainsKey_m3D72DE0E00E5930D0399B05F47DDED2CBFA58D7A(L_0, L_1, /*hidden argument*/ReadOnlyDictionary_2_ContainsKey_m3D72DE0E00E5930D0399B05F47DDED2CBFA58D7A_RuntimeMethod_var);
		if (L_2)
		{
			goto IL_000f;
		}
	}
	{
		// return WwiseObjectType.None;
		return (int32_t)(0);
	}

IL_000f:
	{
		// if (workUnitType != string.Empty)
		String_t* L_3 = ___workUnitType1;
		String_t* L_4 = ((String_t_StaticFields*)il2cpp_codegen_static_fields_for(String_t_il2cpp_TypeInfo_var))->get_Empty_5();
		bool L_5 = String_op_Inequality_m0BD184A74F453A72376E81CC6CAEE2556B80493E(L_3, L_4, /*hidden argument*/NULL);
		if (!L_5)
		{
			goto IL_0045;
		}
	}
	{
		// if (workUnitType == "folder")
		String_t* L_6 = ___workUnitType1;
		bool L_7 = String_op_Equality_m139F0E4195AE2F856019E63B241F36F016997FCE(L_6, _stringLiteralAFFFDD08D81DD168981D9A0DCCEB2FB24C2AB56A, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0039;
		}
	}
	{
		// return WaapiKeywords.typeStringDict["physicalfolder"];
		IL2CPP_RUNTIME_CLASS_INIT(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var);
		ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * L_8 = ((WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields*)il2cpp_codegen_static_fields_for(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var))->get_typeStringDict_84();
		NullCheck(L_8);
		int32_t L_9 = ReadOnlyDictionary_2_get_Item_m2872DF7EB7C71DD1A8E217C9FACA183F7AD5A02C(L_8, _stringLiteralF8A33074742E5DB761623D7FA8CFF61C2BFE483E, /*hidden argument*/ReadOnlyDictionary_2_get_Item_m2872DF7EB7C71DD1A8E217C9FACA183F7AD5A02C_RuntimeMethod_var);
		return L_9;
	}

IL_0039:
	{
		// return WaapiKeywords.typeStringDict[typeString];
		IL2CPP_RUNTIME_CLASS_INIT(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var);
		ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * L_10 = ((WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields*)il2cpp_codegen_static_fields_for(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var))->get_typeStringDict_84();
		String_t* L_11 = ___typeString0;
		NullCheck(L_10);
		int32_t L_12 = ReadOnlyDictionary_2_get_Item_m2872DF7EB7C71DD1A8E217C9FACA183F7AD5A02C(L_10, L_11, /*hidden argument*/ReadOnlyDictionary_2_get_Item_m2872DF7EB7C71DD1A8E217C9FACA183F7AD5A02C_RuntimeMethod_var);
		return L_12;
	}

IL_0045:
	{
		// return WaapiKeywords.typeStringDict[typeString];
		IL2CPP_RUNTIME_CLASS_INIT(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var);
		ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * L_13 = ((WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields*)il2cpp_codegen_static_fields_for(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var))->get_typeStringDict_84();
		String_t* L_14 = ___typeString0;
		NullCheck(L_13);
		int32_t L_15 = ReadOnlyDictionary_2_get_Item_m2872DF7EB7C71DD1A8E217C9FACA183F7AD5A02C(L_13, L_14, /*hidden argument*/ReadOnlyDictionary_2_get_Item_m2872DF7EB7C71DD1A8E217C9FACA183F7AD5A02C_RuntimeMethod_var);
		return L_15;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WaapiKeywords::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WaapiKeywords__ctor_m90A5404044D01E8198019D449DB057627B723C92 (WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void WaapiKeywords::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WaapiKeywords__cctor_m98F6325EE529F42B2E47B71504811F517DB2059C (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (WaapiKeywords__cctor_m98F6325EE529F42B2E47B71504811F517DB2059C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public static ReadOnlyDictionary<WwiseObjectType, string> WwiseObjectTypeStrings = new ReadOnlyDictionary<WwiseObjectType, string>(new Dictionary<WwiseObjectType, string>()
		//     {
		//         {WwiseObjectType.None, "None"},
		//         {WwiseObjectType.AuxBus, "AuxiliaryBus"},
		//         {WwiseObjectType.Bus, "Bus"},
		//         {WwiseObjectType.Event, "Event"},
		//         {WwiseObjectType.Folder, "Folder"},
		//         {WwiseObjectType.PhysicalFolder, "PhysicalFolder"},
		//         {WwiseObjectType.Project, "Project"},
		//         {WwiseObjectType.Soundbank, "SoundBank"},
		//         {WwiseObjectType.State, "State"},
		//         {WwiseObjectType.StateGroup, "StateGroup"},
		//         {WwiseObjectType.Switch, "Switch"},
		//         {WwiseObjectType.SwitchGroup, "SwitchGroup"},
		//         {WwiseObjectType.WorkUnit, "WorkUnit"},
		//         {WwiseObjectType.GameParameter, "Game Parametr"},
		//         {WwiseObjectType.Trigger, "Trigger"},
		//         {WwiseObjectType.AcousticTexture, "AcousticTexture"}
		//     });
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_0 = (Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD *)il2cpp_codegen_object_new(Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m9457A48CCEE984A72083457DACF6F3F0C97E4AA5(L_0, /*hidden argument*/Dictionary_2__ctor_m9457A48CCEE984A72083457DACF6F3F0C97E4AA5_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_1 = L_0;
		NullCheck(L_1);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_1, 0, _stringLiteral6EEF6648406C333A4035CD5E60D0BF2ECF2606D7, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_2 = L_1;
		NullCheck(L_2);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_2, 1, _stringLiteral3E3989AB04E4455D509DAA6CD05571B080E4D7F6, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_3 = L_2;
		NullCheck(L_3);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_3, 2, _stringLiteral56070A568367D5A4E9970CFFF19CB97578CE1361, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_4 = L_3;
		NullCheck(L_4);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_4, 3, _stringLiteralAD8919ACE091B14011C6439CFD5E1707B58F5ABD, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_5 = L_4;
		NullCheck(L_5);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_5, 4, _stringLiteral30BAA24967E08965D1594408031F0324AE11CCAC, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_6 = L_5;
		NullCheck(L_6);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_6, 5, _stringLiteralFCFC80212C4D07D824FB2CF6431A65784130AEBB, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_7 = L_6;
		NullCheck(L_7);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_7, 6, _stringLiteralF6F4DA8D93E88A08220E03B7810451D3BA540A34, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_8 = L_7;
		NullCheck(L_8);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_8, 7, _stringLiteralEA82829F65F92FD02BFF592AF541585CBFBDA281, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_9 = L_8;
		NullCheck(L_9);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_9, 8, _stringLiteralA72502067518684F9DEEEC70CF119FD26326CD33, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_10 = L_9;
		NullCheck(L_10);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_10, ((int32_t)9), _stringLiteralF68BE0CD5F76E3FB04BD01BC622726AA56A16DB8, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_11 = L_10;
		NullCheck(L_11);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_11, ((int32_t)10), _stringLiteral3E44C920427E845DF4958295EB8C3045B55FCFD5, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_12 = L_11;
		NullCheck(L_12);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_12, ((int32_t)11), _stringLiteral34EBDF208667B8C52EA799739D7D859B466DE3D1, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_13 = L_12;
		NullCheck(L_13);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_13, ((int32_t)12), _stringLiteral2BDA1C5D2E633249BBEE7BECBAE728747171CCF2, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_14 = L_13;
		NullCheck(L_14);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_14, ((int32_t)13), _stringLiteral21D989A541A872BB9D3762D9DFFF0F3072DE0445, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_15 = L_14;
		NullCheck(L_15);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_15, ((int32_t)14), _stringLiteralD3F06A581B2B66FA7A3965DDEB6FB307F7BE20BA, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		Dictionary_2_t4447AE2B86EC1B650CBA06F97BDC87767E4566AD * L_16 = L_15;
		NullCheck(L_16);
		Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9(L_16, ((int32_t)15), _stringLiteralC3A12CF2C913253F799D73280079AB3A6ABEF3B4, /*hidden argument*/Dictionary_2_Add_m6C2C2DBEE45B274DBC281F5B6AD3E534E21ED3B9_RuntimeMethod_var);
		ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D * L_17 = (ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D *)il2cpp_codegen_object_new(ReadOnlyDictionary_2_t48DFABE4125A336059DF55A4DA5360CF826BA02D_il2cpp_TypeInfo_var);
		ReadOnlyDictionary_2__ctor_m09C7C2FF3D8EC8592F1E582191C2F95970CA4D0F(L_17, L_16, /*hidden argument*/ReadOnlyDictionary_2__ctor_m09C7C2FF3D8EC8592F1E582191C2F95970CA4D0F_RuntimeMethod_var);
		((WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields*)il2cpp_codegen_static_fields_for(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var))->set_WwiseObjectTypeStrings_82(L_17);
		// public static ReadOnlyDictionary<string, string> FolderDisplaynames = new ReadOnlyDictionary<string, string>(new Dictionary<string, string>()
		// {
		//     {"Master-Mixer Hierarchy", "Auxiliary Busses" },
		//     { "Events", "Events"},
		//     { "States", "States"},
		//     { "SoundBanks", "SoundBanks"},
		//     { "Switches", "Switches"},
		//     { "Virtual Acoustics", "Virtual Acoustics"},
		// });
		Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC * L_18 = (Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC *)il2cpp_codegen_object_new(Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m5B1C279E77422BB0B2C7B0374ECF89E3224AF62B(L_18, /*hidden argument*/Dictionary_2__ctor_m5B1C279E77422BB0B2C7B0374ECF89E3224AF62B_RuntimeMethod_var);
		Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC * L_19 = L_18;
		NullCheck(L_19);
		Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC(L_19, _stringLiteralDAD9C4182CF9862CDD00BFB8ABC34EE355283AA2, _stringLiteralAAF42B55E4D31D4476DEB2C93D749D172FB6A78E, /*hidden argument*/Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC_RuntimeMethod_var);
		Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC * L_20 = L_19;
		NullCheck(L_20);
		Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC(L_20, _stringLiteralC5497BCA58468AE64AED6C0FD921109217988DB3, _stringLiteralC5497BCA58468AE64AED6C0FD921109217988DB3, /*hidden argument*/Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC_RuntimeMethod_var);
		Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC * L_21 = L_20;
		NullCheck(L_21);
		Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC(L_21, _stringLiteral6E6975211C2EC5DF87ECA6F10522B61408628C47, _stringLiteral6E6975211C2EC5DF87ECA6F10522B61408628C47, /*hidden argument*/Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC_RuntimeMethod_var);
		Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC * L_22 = L_21;
		NullCheck(L_22);
		Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC(L_22, _stringLiteralE8EFD34D217B4D3B444529914BD6F8F32330D85A, _stringLiteralE8EFD34D217B4D3B444529914BD6F8F32330D85A, /*hidden argument*/Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC_RuntimeMethod_var);
		Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC * L_23 = L_22;
		NullCheck(L_23);
		Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC(L_23, _stringLiteral521FB7097B70476A3E1F5E4B812E25F28991CB8F, _stringLiteral521FB7097B70476A3E1F5E4B812E25F28991CB8F, /*hidden argument*/Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC_RuntimeMethod_var);
		Dictionary_2_t931BF283048C4E74FC063C3036E5F3FE328861FC * L_24 = L_23;
		NullCheck(L_24);
		Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC(L_24, _stringLiteral9A53A1188CADA337FB136F35F09E145211EA6D33, _stringLiteral9A53A1188CADA337FB136F35F09E145211EA6D33, /*hidden argument*/Dictionary_2_Add_m8E1E97EC586BFF6D3F84BB3429DF6198853F25AC_RuntimeMethod_var);
		ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE * L_25 = (ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE *)il2cpp_codegen_object_new(ReadOnlyDictionary_2_t29543C8C3288540849751E93624E1C8FD5AF5DDE_il2cpp_TypeInfo_var);
		ReadOnlyDictionary_2__ctor_mB2D19FDF7E2760F6CD503397D0395FBD27E877FF(L_25, L_24, /*hidden argument*/ReadOnlyDictionary_2__ctor_mB2D19FDF7E2760F6CD503397D0395FBD27E877FF_RuntimeMethod_var);
		((WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields*)il2cpp_codegen_static_fields_for(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var))->set_FolderDisplaynames_83(L_25);
		// public static ReadOnlyDictionary<string, WwiseObjectType> typeStringDict = new ReadOnlyDictionary<string, WwiseObjectType>(new Dictionary<string, WwiseObjectType>()
		// {
		//     ["auxbus"] = WwiseObjectType.AuxBus,
		//     ["bus"] = WwiseObjectType.Bus,
		//     ["event"] = WwiseObjectType.Event,
		//     ["folder"] = WwiseObjectType.Folder,
		//     ["physicalfolder"] = WwiseObjectType.PhysicalFolder,
		//     ["soundbank"] = WwiseObjectType.Soundbank,
		//     ["project"] = WwiseObjectType.Project,
		//     ["state"] = WwiseObjectType.State,
		//     ["stategroup"] = WwiseObjectType.StateGroup,
		//     ["switch"] = WwiseObjectType.Switch,
		//     ["switchgroup"] = WwiseObjectType.SwitchGroup,
		//     ["workunit"] = WwiseObjectType.WorkUnit,
		//     ["gameparameter"] = WwiseObjectType.GameParameter,
		//     ["trigger"] = WwiseObjectType.Trigger,
		//     ["acoustictexture"] = WwiseObjectType.AcousticTexture
		// });
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_26 = (Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F *)il2cpp_codegen_object_new(Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_mF9BF70BC1501E2DD8B1B8928E3920BF963A562A5(L_26, /*hidden argument*/Dictionary_2__ctor_mF9BF70BC1501E2DD8B1B8928E3920BF963A562A5_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_27 = L_26;
		NullCheck(L_27);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_27, _stringLiteral9E4CA27B355FD460812EA4B5B4A70907455DB5EC, 1, /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_28 = L_27;
		NullCheck(L_28);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_28, _stringLiteral32C70CEBF110EEDB8637B5E875A6C94F1EF6E8C5, 2, /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_29 = L_28;
		NullCheck(L_29);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_29, _stringLiteral5006ED0248A019713B762563076292379DAF07B4, 3, /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_30 = L_29;
		NullCheck(L_30);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_30, _stringLiteralAFFFDD08D81DD168981D9A0DCCEB2FB24C2AB56A, 4, /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_31 = L_30;
		NullCheck(L_31);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_31, _stringLiteralF8A33074742E5DB761623D7FA8CFF61C2BFE483E, 5, /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_32 = L_31;
		NullCheck(L_32);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_32, _stringLiteralB57149B2CB8478D76FBB48F89ED551B22A913C4A, 7, /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_33 = L_32;
		NullCheck(L_33);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_33, _stringLiteral98F54143AB4E86B28C3AFEE0F50F2F51CFB2ED38, 6, /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_34 = L_33;
		NullCheck(L_34);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_34, _stringLiteralAA4A5F8125F234182E2DEA92805AFDFB747A86BE, 8, /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_35 = L_34;
		NullCheck(L_35);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_35, _stringLiteralCA8156011050BBBC5972C9E5388071F8374EDEF4, ((int32_t)9), /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_36 = L_35;
		NullCheck(L_36);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_36, _stringLiteral01BA7992F85DE477E8E630428EB5ED14769F9155, ((int32_t)10), /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_37 = L_36;
		NullCheck(L_37);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_37, _stringLiteralDF91E4F832891C6C2664A695B7C49E72D5414B8F, ((int32_t)11), /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_38 = L_37;
		NullCheck(L_38);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_38, _stringLiteral65068281F583818187F997A36D242A89750AC7F9, ((int32_t)12), /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_39 = L_38;
		NullCheck(L_39);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_39, _stringLiteral5E82BDD9CD88FBA2F846334A2D213A3199C5C73E, ((int32_t)13), /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_40 = L_39;
		NullCheck(L_40);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_40, _stringLiteral63D62D4AEE9A5D4FE8539E53A9E3D05FFC210C9B, ((int32_t)14), /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		Dictionary_2_t66BBE1D809B502E0FF015778F898BADEE9DEE38F * L_41 = L_40;
		NullCheck(L_41);
		Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D(L_41, _stringLiteral841E058CC2C285F32E177EC99D0203C01BAE625D, ((int32_t)15), /*hidden argument*/Dictionary_2_set_Item_m0FAB1B3FC5FF5256C23B0EF064EE603EADE1A07D_RuntimeMethod_var);
		ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 * L_42 = (ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3 *)il2cpp_codegen_object_new(ReadOnlyDictionary_2_t5B516CFCEFA8C8FDFDF308FDC91A12E6BE139CA3_il2cpp_TypeInfo_var);
		ReadOnlyDictionary_2__ctor_mC837B9F33F33A0BA69860897896746402C48619E(L_42, L_41, /*hidden argument*/ReadOnlyDictionary_2__ctor_mC837B9F33F33A0BA69860897896746402C48619E_RuntimeMethod_var);
		((WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_StaticFields*)il2cpp_codegen_static_fields_for(WaapiKeywords_tB98B6B08B75BCF00F42D9A0FC4C3CE8788AEAEFE_il2cpp_TypeInfo_var))->set_typeStringDict_84(L_42);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp::add_Disconnected(Wamp_DisconnectedHandler)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_add_Disconnected_mBAA1A70AD8CE39B3A45DB824FB26FF9C2C11F143 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_add_Disconnected_mBAA1A70AD8CE39B3A45DB824FB26FF9C2C11F143_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_0 = NULL;
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_1 = NULL;
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_2 = NULL;
	{
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_0 = __this->get_Disconnected_0();
		V_0 = L_0;
	}

IL_0007:
	{
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_1 = V_0;
		V_1 = L_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_2 = V_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_3 = ___value0;
		Delegate_t * L_4 = Delegate_Combine_mC25D2F7DECAFBA6D9A2F9EBA8A77063F0658ECF1(L_2, L_3, /*hidden argument*/NULL);
		V_2 = ((DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)CastclassSealed((RuntimeObject*)L_4, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3_il2cpp_TypeInfo_var));
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 ** L_5 = __this->get_address_of_Disconnected_0();
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_6 = V_2;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_7 = V_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_8 = InterlockedCompareExchangeImpl<DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *>((DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 **)L_5, L_6, L_7);
		V_0 = L_8;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_9 = V_0;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_10 = V_1;
		if ((!(((RuntimeObject*)(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)L_9) == ((RuntimeObject*)(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Wamp::remove_Disconnected(Wamp_DisconnectedHandler)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_remove_Disconnected_m733F63A5B3D9B63CA05DB0B31C6BE3C9456D7D9F (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_remove_Disconnected_m733F63A5B3D9B63CA05DB0B31C6BE3C9456D7D9F_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_0 = NULL;
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_1 = NULL;
	DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * V_2 = NULL;
	{
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_0 = __this->get_Disconnected_0();
		V_0 = L_0;
	}

IL_0007:
	{
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_1 = V_0;
		V_1 = L_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_2 = V_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_3 = ___value0;
		Delegate_t * L_4 = Delegate_Remove_m0B0DB7D1B3AF96B71AFAA72BA0EFE32FBBC2932D(L_2, L_3, /*hidden argument*/NULL);
		V_2 = ((DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)CastclassSealed((RuntimeObject*)L_4, DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3_il2cpp_TypeInfo_var));
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 ** L_5 = __this->get_address_of_Disconnected_0();
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_6 = V_2;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_7 = V_1;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_8 = InterlockedCompareExchangeImpl<DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *>((DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 **)L_5, L_6, L_7);
		V_0 = L_8;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_9 = V_0;
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_10 = V_1;
		if ((!(((RuntimeObject*)(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)L_9) == ((RuntimeObject*)(DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 *)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Threading.Tasks.Task Wamp::Send(System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___msg0, int32_t ___timeout1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_4(__this);
		String_t* L_0 = ___msg0;
		(&V_0)->set_msg_3(L_0);
		int32_t L_1 = ___timeout1;
		(&V_0)->set_timeout_2(L_1);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_2 = AsyncTaskMethodBuilder_Create_m081DF9A202E7C2F3CF3D41E1E63E63DA18F19FDB(/*hidden argument*/NULL);
		(&V_0)->set_U3CU3Et__builder_1(L_2);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A  L_3 = V_0;
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_4 = L_3.get_U3CU3Et__builder_1();
		V_1 = L_4;
		AsyncTaskMethodBuilder_Start_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m3BE2ACD6057BFEC9516FD5CA2EC71DD1F46E95FB((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)(&V_1), (U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_Start_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m3BE2ACD6057BFEC9516FD5CA2EC71DD1F46E95FB_RuntimeMethod_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_5 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_6 = AsyncTaskMethodBuilder_get_Task_m3E45BC00F7D224FEA04AB9BF26DB52E131D33022((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// Wamp_Response Wamp::Parse(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___msg0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * G_B2_0 = NULL;
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * G_B1_0 = NULL;
	{
		// var match = System.Text.RegularExpressions.Regex.Match(msg, msgTypePattern, System.Text.RegularExpressions.RegexOptions.Singleline);
		String_t* L_0 = ___msg0;
		IL2CPP_RUNTIME_CLASS_INIT(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF_il2cpp_TypeInfo_var);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_1 = Regex_Match_m08332EE8B44F5A94218B8D432627EB7F71EE7BE2(L_0, _stringLiteralC03C9E03EF9031F1884F64E7D2C4CECE8066943D, ((int32_t)16), /*hidden argument*/NULL);
		// if (match.Groups.Count != 2)
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_2 = L_1;
		NullCheck(L_2);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_3 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_2);
		NullCheck(L_3);
		int32_t L_4 = GroupCollection_get_Count_mBDDCA62E15FC586F0CCBD75F006BF0B08713E26E(L_3, /*hidden argument*/NULL);
		G_B1_0 = L_2;
		if ((((int32_t)L_4) == ((int32_t)2)))
		{
			G_B2_0 = L_2;
			goto IL_0026;
		}
	}
	{
		// throw new ErrorException("Error while parsing response from server.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_5 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_5, _stringLiteral1100C278A2149AE25E6C9D115CC40383875DA328, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5, Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A_RuntimeMethod_var);
	}

IL_0026:
	{
		// Messages messageId = (Messages)int.Parse(match.Groups[1].Value);
		NullCheck(G_B2_0);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_6 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, G_B2_0);
		NullCheck(L_6);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_7 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_6, 1, /*hidden argument*/NULL);
		NullCheck(L_7);
		String_t* L_8 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_7, /*hidden argument*/NULL);
		int32_t L_9 = Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA(L_8, /*hidden argument*/NULL);
		V_0 = L_9;
		// switch (messageId)
		int32_t L_10 = V_0;
		if ((((int32_t)L_10) > ((int32_t)6)))
		{
			goto IL_004a;
		}
	}
	{
		int32_t L_11 = V_0;
		if ((((int32_t)L_11) == ((int32_t)2)))
		{
			goto IL_006e;
		}
	}
	{
		int32_t L_12 = V_0;
		if ((((int32_t)L_12) == ((int32_t)6)))
		{
			goto IL_0075;
		}
	}
	{
		goto IL_009f;
	}

IL_004a:
	{
		int32_t L_13 = V_0;
		if ((((int32_t)L_13) == ((int32_t)8)))
		{
			goto IL_0098;
		}
	}
	{
		int32_t L_14 = V_0;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_14, (int32_t)((int32_t)33))))
		{
			case 0:
			{
				goto IL_007c;
			}
			case 1:
			{
				goto IL_009f;
			}
			case 2:
			{
				goto IL_0083;
			}
			case 3:
			{
				goto IL_008a;
			}
		}
	}
	{
		int32_t L_15 = V_0;
		if ((((int32_t)L_15) == ((int32_t)((int32_t)50))))
		{
			goto IL_0091;
		}
	}
	{
		goto IL_009f;
	}

IL_006e:
	{
		// return ParseWelcome(msg);
		String_t* L_16 = ___msg0;
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_17 = Wamp_ParseWelcome_mDC04C238E5A69F16500F3C9A7678B10185601B58(L_16, /*hidden argument*/NULL);
		return L_17;
	}

IL_0075:
	{
		// return ParseGoodbye(msg);
		String_t* L_18 = ___msg0;
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_19 = Wamp_ParseGoodbye_m62130B50323A9CDC2F8182BA1E492B5F182A958A(L_18, /*hidden argument*/NULL);
		return L_19;
	}

IL_007c:
	{
		// return ParseSubscribed(msg);
		String_t* L_20 = ___msg0;
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_21 = Wamp_ParseSubscribed_m705D9E4D5465BAF013A92740D8D822AF448B1F23(L_20, /*hidden argument*/NULL);
		return L_21;
	}

IL_0083:
	{
		// return ParseUnsubscribed(msg);
		String_t* L_22 = ___msg0;
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_23 = Wamp_ParseUnsubscribed_m21AF2D9070DE4E49F5CC7C53A164C1A5C2D7040E(L_22, /*hidden argument*/NULL);
		return L_23;
	}

IL_008a:
	{
		// return ParseEvent(msg);
		String_t* L_24 = ___msg0;
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_25 = Wamp_ParseEvent_m21C36EAE091AB9B20402C75770048AA5FC9F9020(L_24, /*hidden argument*/NULL);
		return L_25;
	}

IL_0091:
	{
		// return ParseResult(msg);
		String_t* L_26 = ___msg0;
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_27 = Wamp_ParseResult_m1ED4173FAF19510DA46B93BCA58DAA6FE0140634(L_26, /*hidden argument*/NULL);
		return L_27;
	}

IL_0098:
	{
		// throw ErrorException.FromResponse(msg);
		String_t* L_28 = ___msg0;
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_29 = ErrorException_FromResponse_m7F3FD8A84BC8AEF0BC62A4CD5203DF961BC803C9(L_28, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_29, Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A_RuntimeMethod_var);
	}

IL_009f:
	{
		// throw new ErrorException("Unexpected result from server.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_30 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_30, _stringLiteralC1711278AE69E1916962F0754E0D596566858442, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_30, Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A_RuntimeMethod_var);
	}
}
// Wamp_Response Wamp::ParseResult(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseResult_m1ED4173FAF19510DA46B93BCA58DAA6FE0140634 (String_t* ___msg0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_ParseResult_m1ED4173FAF19510DA46B93BCA58DAA6FE0140634_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * V_0 = NULL;
	{
		// var match = System.Text.RegularExpressions.Regex.Match(msg, pattern, System.Text.RegularExpressions.RegexOptions.Singleline);
		String_t* L_0 = ___msg0;
		IL2CPP_RUNTIME_CLASS_INIT(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF_il2cpp_TypeInfo_var);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_1 = Regex_Match_m08332EE8B44F5A94218B8D432627EB7F71EE7BE2(L_0, _stringLiteralA85865E9EE2503B850D7E7E0EB3ACFCC242A0C27, ((int32_t)16), /*hidden argument*/NULL);
		V_0 = L_1;
		// if (!match.Success || match.Groups.Count != 3)
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_2 = V_0;
		NullCheck(L_2);
		bool L_3 = Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0024;
		}
	}
	{
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_4 = V_0;
		NullCheck(L_4);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_5 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_4);
		NullCheck(L_5);
		int32_t L_6 = GroupCollection_get_Count_mBDDCA62E15FC586F0CCBD75F006BF0B08713E26E(L_5, /*hidden argument*/NULL);
		if ((((int32_t)L_6) == ((int32_t)3)))
		{
			goto IL_002f;
		}
	}

IL_0024:
	{
		// throw new ErrorException("Invalid RESULT message.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_7 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_7, _stringLiteralAF655BFDF69FC9B2FF11EAC5ACC69C16AE7AB9D5, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7, Wamp_ParseResult_m1ED4173FAF19510DA46B93BCA58DAA6FE0140634_RuntimeMethod_var);
	}

IL_002f:
	{
		// return new Response()
		// {
		//     MessageId = Messages.RESULT,
		//     RequestId = (int.Parse(match.Groups[1].Value)),
		//     Json = msg.Substring(match.Groups[2].Index, msg.Length - match.Groups[2].Index - 1)
		// };
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_8 = (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 *)il2cpp_codegen_object_new(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8_il2cpp_TypeInfo_var);
		Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5(L_8, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_9 = L_8;
		NullCheck(L_9);
		Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A_inline(L_9, ((int32_t)50), /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_10 = L_9;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_11 = V_0;
		NullCheck(L_11);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_12 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_11);
		NullCheck(L_12);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_13 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_12, 1, /*hidden argument*/NULL);
		NullCheck(L_13);
		String_t* L_14 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_13, /*hidden argument*/NULL);
		int32_t L_15 = Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA(L_14, /*hidden argument*/NULL);
		NullCheck(L_10);
		Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4_inline(L_10, L_15, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_16 = L_10;
		String_t* L_17 = ___msg0;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_18 = V_0;
		NullCheck(L_18);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_19 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_18);
		NullCheck(L_19);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_20 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_19, 2, /*hidden argument*/NULL);
		NullCheck(L_20);
		int32_t L_21 = Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31_inline(L_20, /*hidden argument*/NULL);
		String_t* L_22 = ___msg0;
		NullCheck(L_22);
		int32_t L_23 = String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018_inline(L_22, /*hidden argument*/NULL);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_24 = V_0;
		NullCheck(L_24);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_25 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_24);
		NullCheck(L_25);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_26 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_25, 2, /*hidden argument*/NULL);
		NullCheck(L_26);
		int32_t L_27 = Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31_inline(L_26, /*hidden argument*/NULL);
		NullCheck(L_17);
		String_t* L_28 = String_Substring_mB593C0A320C683E6E47EFFC0A12B7A465E5E43BB(L_17, L_21, ((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_23, (int32_t)L_27)), (int32_t)1)), /*hidden argument*/NULL);
		NullCheck(L_16);
		Response_set_Json_m8B200462D00D107744D54E7FD990BB541675D7F9_inline(L_16, L_28, /*hidden argument*/NULL);
		return L_16;
	}
}
// Wamp_Response Wamp::ParseSubscribed(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseSubscribed_m705D9E4D5465BAF013A92740D8D822AF448B1F23 (String_t* ___msg0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_ParseSubscribed_m705D9E4D5465BAF013A92740D8D822AF448B1F23_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * V_0 = NULL;
	{
		// var match = System.Text.RegularExpressions.Regex.Match(msg, pattern, System.Text.RegularExpressions.RegexOptions.Singleline);
		String_t* L_0 = ___msg0;
		IL2CPP_RUNTIME_CLASS_INIT(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF_il2cpp_TypeInfo_var);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_1 = Regex_Match_m08332EE8B44F5A94218B8D432627EB7F71EE7BE2(L_0, _stringLiteral884405D16B0748FF736292F6E63C4CB9411E73B4, ((int32_t)16), /*hidden argument*/NULL);
		V_0 = L_1;
		// if (!match.Success || match.Groups.Count != 3)
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_2 = V_0;
		NullCheck(L_2);
		bool L_3 = Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0024;
		}
	}
	{
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_4 = V_0;
		NullCheck(L_4);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_5 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_4);
		NullCheck(L_5);
		int32_t L_6 = GroupCollection_get_Count_mBDDCA62E15FC586F0CCBD75F006BF0B08713E26E(L_5, /*hidden argument*/NULL);
		if ((((int32_t)L_6) == ((int32_t)3)))
		{
			goto IL_002f;
		}
	}

IL_0024:
	{
		// throw new ErrorException("Invalid SUBSCRIBED message.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_7 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_7, _stringLiteral2DEB67EF43F9E641C7455D80D92FC48227D84C6C, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7, Wamp_ParseSubscribed_m705D9E4D5465BAF013A92740D8D822AF448B1F23_RuntimeMethod_var);
	}

IL_002f:
	{
		// return new Response()
		// {
		//     MessageId = Messages.SUBSCRIBED,
		//     RequestId = (int.Parse(match.Groups[1].Value)),
		//     
		//     SubscriptionId = (uint.Parse(match.Groups[2].Value))
		// };
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_8 = (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 *)il2cpp_codegen_object_new(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8_il2cpp_TypeInfo_var);
		Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5(L_8, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_9 = L_8;
		NullCheck(L_9);
		Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A_inline(L_9, ((int32_t)33), /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_10 = L_9;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_11 = V_0;
		NullCheck(L_11);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_12 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_11);
		NullCheck(L_12);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_13 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_12, 1, /*hidden argument*/NULL);
		NullCheck(L_13);
		String_t* L_14 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_13, /*hidden argument*/NULL);
		int32_t L_15 = Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA(L_14, /*hidden argument*/NULL);
		NullCheck(L_10);
		Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4_inline(L_10, L_15, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_16 = L_10;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_17 = V_0;
		NullCheck(L_17);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_18 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_17);
		NullCheck(L_18);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_19 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_18, 2, /*hidden argument*/NULL);
		NullCheck(L_19);
		String_t* L_20 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_19, /*hidden argument*/NULL);
		uint32_t L_21 = UInt32_Parse_m7BE20B4A60B436F4061567396833BE360ACD476D(L_20, /*hidden argument*/NULL);
		NullCheck(L_16);
		Response_set_SubscriptionId_m160D966B5D30F42BF0D5C133AA49CC14B62ED853_inline(L_16, L_21, /*hidden argument*/NULL);
		return L_16;
	}
}
// Wamp_Response Wamp::ParseUnsubscribed(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseUnsubscribed_m21AF2D9070DE4E49F5CC7C53A164C1A5C2D7040E (String_t* ___msg0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_ParseUnsubscribed_m21AF2D9070DE4E49F5CC7C53A164C1A5C2D7040E_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * V_0 = NULL;
	{
		// var match = System.Text.RegularExpressions.Regex.Match(msg, pattern, System.Text.RegularExpressions.RegexOptions.Singleline);
		String_t* L_0 = ___msg0;
		IL2CPP_RUNTIME_CLASS_INIT(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF_il2cpp_TypeInfo_var);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_1 = Regex_Match_m08332EE8B44F5A94218B8D432627EB7F71EE7BE2(L_0, _stringLiteral13A372FA1ADE32B3077F2878063E147B5490768D, ((int32_t)16), /*hidden argument*/NULL);
		V_0 = L_1;
		// if (!match.Success || match.Groups.Count != 2)
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_2 = V_0;
		NullCheck(L_2);
		bool L_3 = Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0024;
		}
	}
	{
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_4 = V_0;
		NullCheck(L_4);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_5 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_4);
		NullCheck(L_5);
		int32_t L_6 = GroupCollection_get_Count_mBDDCA62E15FC586F0CCBD75F006BF0B08713E26E(L_5, /*hidden argument*/NULL);
		if ((((int32_t)L_6) == ((int32_t)2)))
		{
			goto IL_002f;
		}
	}

IL_0024:
	{
		// throw new ErrorException("Invalid UNSUBSCRIBED message.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_7 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_7, _stringLiteral0A5A3986DAA2141AA71AD79F5BE515664FC07A37, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7, Wamp_ParseUnsubscribed_m21AF2D9070DE4E49F5CC7C53A164C1A5C2D7040E_RuntimeMethod_var);
	}

IL_002f:
	{
		// return new Response()
		// {
		//     MessageId = Messages.UNSUBSCRIBED,
		//     RequestId = (int.Parse(match.Groups[1].Value))
		// };
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_8 = (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 *)il2cpp_codegen_object_new(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8_il2cpp_TypeInfo_var);
		Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5(L_8, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_9 = L_8;
		NullCheck(L_9);
		Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A_inline(L_9, ((int32_t)35), /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_10 = L_9;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_11 = V_0;
		NullCheck(L_11);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_12 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_11);
		NullCheck(L_12);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_13 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_12, 1, /*hidden argument*/NULL);
		NullCheck(L_13);
		String_t* L_14 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_13, /*hidden argument*/NULL);
		int32_t L_15 = Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA(L_14, /*hidden argument*/NULL);
		NullCheck(L_10);
		Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4_inline(L_10, L_15, /*hidden argument*/NULL);
		return L_10;
	}
}
// Wamp_Response Wamp::ParseGoodbye(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseGoodbye_m62130B50323A9CDC2F8182BA1E492B5F182A958A (String_t* ___msg0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_ParseGoodbye_m62130B50323A9CDC2F8182BA1E492B5F182A958A_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * V_0 = NULL;
	{
		// var match = System.Text.RegularExpressions.Regex.Match(msg, pattern, System.Text.RegularExpressions.RegexOptions.Singleline);
		String_t* L_0 = ___msg0;
		IL2CPP_RUNTIME_CLASS_INIT(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF_il2cpp_TypeInfo_var);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_1 = Regex_Match_m08332EE8B44F5A94218B8D432627EB7F71EE7BE2(L_0, _stringLiteralD6720DD1056FA18CDA232DCEE48F2C7F93C5498A, ((int32_t)16), /*hidden argument*/NULL);
		V_0 = L_1;
		// if (!match.Success || match.Groups.Count != 1)
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_2 = V_0;
		NullCheck(L_2);
		bool L_3 = Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0024;
		}
	}
	{
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_4 = V_0;
		NullCheck(L_4);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_5 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_4);
		NullCheck(L_5);
		int32_t L_6 = GroupCollection_get_Count_mBDDCA62E15FC586F0CCBD75F006BF0B08713E26E(L_5, /*hidden argument*/NULL);
		if ((((int32_t)L_6) == ((int32_t)1)))
		{
			goto IL_002f;
		}
	}

IL_0024:
	{
		// throw new ErrorException("Invalid GOODBYE message.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_7 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_7, _stringLiteralEDF719C70211ED45FD8CC49FBF0B6EDB7D79DA78, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7, Wamp_ParseGoodbye_m62130B50323A9CDC2F8182BA1E492B5F182A958A_RuntimeMethod_var);
	}

IL_002f:
	{
		// return new Response()
		// {
		//     MessageId = Messages.GOODBYE
		// };
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_8 = (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 *)il2cpp_codegen_object_new(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8_il2cpp_TypeInfo_var);
		Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5(L_8, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_9 = L_8;
		NullCheck(L_9);
		Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A_inline(L_9, 6, /*hidden argument*/NULL);
		return L_9;
	}
}
// Wamp_Response Wamp::ParseWelcome(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseWelcome_mDC04C238E5A69F16500F3C9A7678B10185601B58 (String_t* ___msg0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_ParseWelcome_mDC04C238E5A69F16500F3C9A7678B10185601B58_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * V_0 = NULL;
	{
		// var match = System.Text.RegularExpressions.Regex.Match(msg, pattern, System.Text.RegularExpressions.RegexOptions.Singleline);
		String_t* L_0 = ___msg0;
		IL2CPP_RUNTIME_CLASS_INIT(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF_il2cpp_TypeInfo_var);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_1 = Regex_Match_m08332EE8B44F5A94218B8D432627EB7F71EE7BE2(L_0, _stringLiteralFA0B17AAE9869D691F0902955D0B60D61440D765, ((int32_t)16), /*hidden argument*/NULL);
		V_0 = L_1;
		// if (!match.Success || match.Groups.Count != 2)
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_2 = V_0;
		NullCheck(L_2);
		bool L_3 = Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0024;
		}
	}
	{
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_4 = V_0;
		NullCheck(L_4);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_5 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_4);
		NullCheck(L_5);
		int32_t L_6 = GroupCollection_get_Count_mBDDCA62E15FC586F0CCBD75F006BF0B08713E26E(L_5, /*hidden argument*/NULL);
		if ((((int32_t)L_6) == ((int32_t)2)))
		{
			goto IL_002f;
		}
	}

IL_0024:
	{
		// throw new ErrorException("Invalid WELCOME message.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_7 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_7, _stringLiteral0DA57E388A3E0B2139C06600A6C796230AB8B5D7, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7, Wamp_ParseWelcome_mDC04C238E5A69F16500F3C9A7678B10185601B58_RuntimeMethod_var);
	}

IL_002f:
	{
		// return new Response()
		// {
		//     MessageId = Messages.WELCOME,
		//     RequestId = 0,
		//     ContextSpecificResultId = (int.Parse(match.Groups[1].Value))
		// };
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_8 = (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 *)il2cpp_codegen_object_new(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8_il2cpp_TypeInfo_var);
		Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5(L_8, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_9 = L_8;
		NullCheck(L_9);
		Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A_inline(L_9, 2, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_10 = L_9;
		NullCheck(L_10);
		Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4_inline(L_10, 0, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_11 = L_10;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_12 = V_0;
		NullCheck(L_12);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_13 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_12);
		NullCheck(L_13);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_14 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_13, 1, /*hidden argument*/NULL);
		NullCheck(L_14);
		String_t* L_15 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_14, /*hidden argument*/NULL);
		int32_t L_16 = Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA(L_15, /*hidden argument*/NULL);
		NullCheck(L_11);
		Response_set_ContextSpecificResultId_m4E0BD596C10376CFFFD141BF47A2322DBF18D760_inline(L_11, L_16, /*hidden argument*/NULL);
		return L_11;
	}
}
// Wamp_Response Wamp::ParseEvent(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * Wamp_ParseEvent_m21C36EAE091AB9B20402C75770048AA5FC9F9020 (String_t* ___msg0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_ParseEvent_m21C36EAE091AB9B20402C75770048AA5FC9F9020_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * V_0 = NULL;
	{
		// var match = System.Text.RegularExpressions.Regex.Match(msg, pattern, System.Text.RegularExpressions.RegexOptions.Singleline);
		String_t* L_0 = ___msg0;
		IL2CPP_RUNTIME_CLASS_INIT(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF_il2cpp_TypeInfo_var);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_1 = Regex_Match_m08332EE8B44F5A94218B8D432627EB7F71EE7BE2(L_0, _stringLiteralA61F5E4AE96501BEBBC6733EE1441E23E592881B, ((int32_t)16), /*hidden argument*/NULL);
		V_0 = L_1;
		// if (match.Groups.Count != 4)
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_2 = V_0;
		NullCheck(L_2);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_3 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_2);
		NullCheck(L_3);
		int32_t L_4 = GroupCollection_get_Count_mBDDCA62E15FC586F0CCBD75F006BF0B08713E26E(L_3, /*hidden argument*/NULL);
		if ((((int32_t)L_4) == ((int32_t)4)))
		{
			goto IL_0027;
		}
	}
	{
		// throw new ErrorException("Invalid EVENT message.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_5 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_5, _stringLiteral3A2800F24C7C2D7C9500D358F429B9DBB39A229A, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5, Wamp_ParseEvent_m21C36EAE091AB9B20402C75770048AA5FC9F9020_RuntimeMethod_var);
	}

IL_0027:
	{
		// return new Response()
		// {
		//     MessageId = Messages.EVENT,
		//     RequestId = (int.Parse(match.Groups[2].Value)),
		//     ContextSpecificResultId = (int.Parse(match.Groups[1].Value)),
		//     Json = msg.Substring(match.Groups[3].Index, msg.Length - match.Groups[3].Index - 1)
		// };
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_6 = (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 *)il2cpp_codegen_object_new(Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8_il2cpp_TypeInfo_var);
		Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5(L_6, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_7 = L_6;
		NullCheck(L_7);
		Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A_inline(L_7, ((int32_t)36), /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_8 = L_7;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_9 = V_0;
		NullCheck(L_9);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_10 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_9);
		NullCheck(L_10);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_11 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_10, 2, /*hidden argument*/NULL);
		NullCheck(L_11);
		String_t* L_12 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_11, /*hidden argument*/NULL);
		int32_t L_13 = Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA(L_12, /*hidden argument*/NULL);
		NullCheck(L_8);
		Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4_inline(L_8, L_13, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_14 = L_8;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_15 = V_0;
		NullCheck(L_15);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_16 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_15);
		NullCheck(L_16);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_17 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_16, 1, /*hidden argument*/NULL);
		NullCheck(L_17);
		String_t* L_18 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_17, /*hidden argument*/NULL);
		int32_t L_19 = Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA(L_18, /*hidden argument*/NULL);
		NullCheck(L_14);
		Response_set_ContextSpecificResultId_m4E0BD596C10376CFFFD141BF47A2322DBF18D760_inline(L_14, L_19, /*hidden argument*/NULL);
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_20 = L_14;
		String_t* L_21 = ___msg0;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_22 = V_0;
		NullCheck(L_22);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_23 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_22);
		NullCheck(L_23);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_24 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_23, 3, /*hidden argument*/NULL);
		NullCheck(L_24);
		int32_t L_25 = Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31_inline(L_24, /*hidden argument*/NULL);
		String_t* L_26 = ___msg0;
		NullCheck(L_26);
		int32_t L_27 = String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018_inline(L_26, /*hidden argument*/NULL);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_28 = V_0;
		NullCheck(L_28);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_29 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_28);
		NullCheck(L_29);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_30 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_29, 3, /*hidden argument*/NULL);
		NullCheck(L_30);
		int32_t L_31 = Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31_inline(L_30, /*hidden argument*/NULL);
		NullCheck(L_21);
		String_t* L_32 = String_Substring_mB593C0A320C683E6E47EFFC0A12B7A465E5E43BB(L_21, L_25, ((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_27, (int32_t)L_31)), (int32_t)1)), /*hidden argument*/NULL);
		NullCheck(L_20);
		Response_set_Json_m8B200462D00D107744D54E7FD990BB541675D7F9_inline(L_20, L_32, /*hidden argument*/NULL);
		return L_20;
	}
}
// System.Threading.Tasks.Task`1<Wamp_Response> Wamp::ReceiveMessage()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * Wamp_ReceiveMessage_m333714DD38A3BEBB92BA90A416BC053CDC1158BC (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_ReceiveMessage_m333714DD38A3BEBB92BA90A416BC053CDC1158BC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  L_0 = AsyncTaskMethodBuilder_1_Create_m94B4F919FEC6BCB096ECA1FD0DE9594CBBD14576(/*hidden argument*/AsyncTaskMethodBuilder_1_Create_m94B4F919FEC6BCB096ECA1FD0DE9594CBBD14576_RuntimeMethod_var);
		(&V_0)->set_U3CU3Et__builder_1(L_0);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C  L_1 = V_0;
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  L_2 = L_1.get_U3CU3Et__builder_1();
		V_1 = L_2;
		AsyncTaskMethodBuilder_1_Start_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_m2B93F2B8EC2D264EE75A4DF55225BCC2F83A7E3B((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)(&V_1), (U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_1_Start_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_m2B93F2B8EC2D264EE75A4DF55225BCC2F83A7E3B_RuntimeMethod_var);
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_3 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_4 = AsyncTaskMethodBuilder_1_get_Task_m7CB437A60103DC49A5C02014C51B0684D0E3E69C((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_3, /*hidden argument*/AsyncTaskMethodBuilder_1_get_Task_m7CB437A60103DC49A5C02014C51B0684D0E3E69C_RuntimeMethod_var);
		return L_4;
	}
}
// System.Threading.Tasks.Task`1<Wamp_Response> Wamp::Receive(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * Wamp_Receive_m7B47E5C25B601C3C446B02A97117ACAA3FA3BF13 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, int32_t ___timeout0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_Receive_m7B47E5C25B601C3C446B02A97117ACAA3FA3BF13_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		int32_t L_0 = ___timeout0;
		(&V_0)->set_timeout_3(L_0);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  L_1 = AsyncTaskMethodBuilder_1_Create_m94B4F919FEC6BCB096ECA1FD0DE9594CBBD14576(/*hidden argument*/AsyncTaskMethodBuilder_1_Create_m94B4F919FEC6BCB096ECA1FD0DE9594CBBD14576_RuntimeMethod_var);
		(&V_0)->set_U3CU3Et__builder_1(L_1);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC  L_2 = V_0;
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  L_3 = L_2.get_U3CU3Et__builder_1();
		V_1 = L_3;
		AsyncTaskMethodBuilder_1_Start_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_m2642B44518F49E595EC0F58CBE4876BB59B52DBB((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)(&V_1), (U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_1_Start_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_m2642B44518F49E595EC0F58CBE4876BB59B52DBB_RuntimeMethod_var);
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_4 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_5 = AsyncTaskMethodBuilder_1_get_Task_m7CB437A60103DC49A5C02014C51B0684D0E3E69C((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_4, /*hidden argument*/AsyncTaskMethodBuilder_1_get_Task_m7CB437A60103DC49A5C02014C51B0684D0E3E69C_RuntimeMethod_var);
		return L_5;
	}
}
// System.Threading.Tasks.Task`1<Wamp_Response> Wamp::ReceiveExpect(Wamp_Messages,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, int32_t ___message0, int32_t ___requestId1, int32_t ___timeout2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		int32_t L_0 = ___message0;
		(&V_0)->set_message_4(L_0);
		int32_t L_1 = ___requestId1;
		(&V_0)->set_requestId_5(L_1);
		int32_t L_2 = ___timeout2;
		(&V_0)->set_timeout_3(L_2);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  L_3 = AsyncTaskMethodBuilder_1_Create_m94B4F919FEC6BCB096ECA1FD0DE9594CBBD14576(/*hidden argument*/AsyncTaskMethodBuilder_1_Create_m94B4F919FEC6BCB096ECA1FD0DE9594CBBD14576_RuntimeMethod_var);
		(&V_0)->set_U3CU3Et__builder_1(L_3);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F  L_4 = V_0;
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD  L_5 = L_4.get_U3CU3Et__builder_1();
		V_1 = L_5;
		AsyncTaskMethodBuilder_1_Start_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m8CA846E439DFA4D8D21C28CF451D501736903735((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)(&V_1), (U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_1_Start_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m8CA846E439DFA4D8D21C28CF451D501736903735_RuntimeMethod_var);
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_6 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_7 = AsyncTaskMethodBuilder_1_get_Task_m7CB437A60103DC49A5C02014C51B0684D0E3E69C((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_6, /*hidden argument*/AsyncTaskMethodBuilder_1_get_Task_m7CB437A60103DC49A5C02014C51B0684D0E3E69C_RuntimeMethod_var);
		return L_7;
	}
}
// System.Threading.Tasks.Task Wamp::Connect(System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * Wamp_Connect_m091D964EE6A72E12FA0905681BF78AD05D9D7FAB (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___host0, int32_t ___timeout1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_Connect_m091D964EE6A72E12FA0905681BF78AD05D9D7FAB_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_3(__this);
		String_t* L_0 = ___host0;
		(&V_0)->set_host_2(L_0);
		int32_t L_1 = ___timeout1;
		(&V_0)->set_timeout_4(L_1);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_2 = AsyncTaskMethodBuilder_Create_m081DF9A202E7C2F3CF3D41E1E63E63DA18F19FDB(/*hidden argument*/NULL);
		(&V_0)->set_U3CU3Et__builder_1(L_2);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6  L_3 = V_0;
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_4 = L_3.get_U3CU3Et__builder_1();
		V_1 = L_4;
		AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m83286F1C813B3EF711EFFF20F60DF019DD0EF82A((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)(&V_1), (U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_Start_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m83286F1C813B3EF711EFFF20F60DF019DD0EF82A_RuntimeMethod_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_5 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_6 = AsyncTaskMethodBuilder_get_Task_m3E45BC00F7D224FEA04AB9BF26DB52E131D33022((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// System.Boolean Wamp::IsConnected()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Wamp_IsConnected_m937F67F3943693AE69F82BA0897E18C163A0B70C (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method)
{
	{
		// if (ws == null)
		ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_0 = __this->get_ws_1();
		if (L_0)
		{
			goto IL_000a;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_000a:
	{
		// return ws.State == System.Net.WebSockets.WebSocketState.Open;
		ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_1 = __this->get_ws_1();
		NullCheck(L_1);
		int32_t L_2 = VirtFuncInvoker0< int32_t >::Invoke(5 /* System.Net.WebSockets.WebSocketState System.Net.WebSockets.WebSocket::get_State() */, L_1);
		return (bool)((((int32_t)L_2) == ((int32_t)2))? 1 : 0);
	}
}
// System.Net.WebSockets.WebSocketState Wamp::SocketState()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Wamp_SocketState_m44CB7A55E93140987D8D2C475C010842EEA0C378 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method)
{
	{
		// if (ws == null) return System.Net.WebSockets.WebSocketState.None;
		ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_0 = __this->get_ws_1();
		if (L_0)
		{
			goto IL_000a;
		}
	}
	{
		// if (ws == null) return System.Net.WebSockets.WebSocketState.None;
		return (int32_t)(0);
	}

IL_000a:
	{
		// return ws.State;
		ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_1 = __this->get_ws_1();
		NullCheck(L_1);
		int32_t L_2 = VirtFuncInvoker0< int32_t >::Invoke(5 /* System.Net.WebSockets.WebSocketState System.Net.WebSockets.WebSocket::get_State() */, L_1);
		return L_2;
	}
}
// System.Threading.Tasks.Task Wamp::Close(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * Wamp_Close_m8607EFADFFC175CC0825312F7EFA8E175FA39B74 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, int32_t ___timeout0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_Close_m8607EFADFFC175CC0825312F7EFA8E175FA39B74_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		int32_t L_0 = ___timeout0;
		(&V_0)->set_timeout_3(L_0);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_1 = AsyncTaskMethodBuilder_Create_m081DF9A202E7C2F3CF3D41E1E63E63DA18F19FDB(/*hidden argument*/NULL);
		(&V_0)->set_U3CU3Et__builder_1(L_1);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5  L_2 = V_0;
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_3 = L_2.get_U3CU3Et__builder_1();
		V_1 = L_3;
		AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m014E726B3574D52F7F9E118E1B7A58DF73336783((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)(&V_1), (U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_Start_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m014E726B3574D52F7F9E118E1B7A58DF73336783_RuntimeMethod_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_4 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_5 = AsyncTaskMethodBuilder_get_Task_m3E45BC00F7D224FEA04AB9BF26DB52E131D33022((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// System.Void Wamp::ProcessEvent(Wamp_Response)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_ProcessEvent_mB6BA36EA16F2375692017561F09D725C6D2E6E35 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * ___message0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_ProcessEvent_mB6BA36EA16F2375692017561F09D725C6D2E6E35_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * V_1 = NULL;
	{
		// int subscriptionId = message.ContextSpecificResultId;
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_0 = ___message0;
		NullCheck(L_0);
		int32_t L_1 = Response_get_ContextSpecificResultId_m8C53A20C58BACF5A2DA2379A42D2818F283CF862_inline(L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		// PublishHandler publishEvent = null;
		V_1 = (PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 *)NULL;
		// if (!subscriptions.TryGetValue((uint)subscriptionId, out publishEvent))
		ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * L_2 = __this->get_subscriptions_6();
		int32_t L_3 = V_0;
		NullCheck(L_2);
		bool L_4 = ConcurrentDictionary_2_TryGetValue_mB8CB5BED33D46B4F69E7967FA50455B66E08A421(L_2, L_3, (PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 **)(&V_1), /*hidden argument*/ConcurrentDictionary_2_TryGetValue_mB8CB5BED33D46B4F69E7967FA50455B66E08A421_RuntimeMethod_var);
		if (L_4)
		{
			goto IL_0024;
		}
	}
	{
		// throw new ErrorException("UNSUBSCRIBE: unknown subscription id.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_5 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_5, _stringLiteral0CF128F0185D0AAF2854CFBC0EDB34460E5F529E, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5, Wamp_ProcessEvent_mB6BA36EA16F2375692017561F09D725C6D2E6E35_RuntimeMethod_var);
	}

IL_0024:
	{
		// publishEvent(message.Json);
		PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * L_6 = V_1;
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_7 = ___message0;
		NullCheck(L_7);
		String_t* L_8 = Response_get_Json_m344AA62580A8B48CEECF9F5A9B33638D572B785B_inline(L_7, /*hidden argument*/NULL);
		NullCheck(L_6);
		PublishHandler_Invoke_m85F2A61F37B7D01827F76105781D219BFCF7E448(L_6, L_8, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void Wamp::StartListen()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_StartListen_mD58F9728B82A7A344E95BA20A462450F5725CEB8 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_StartListen_mD58F9728B82A7A344E95BA20A462450F5725CEB8_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63 * V_0 = NULL;
	{
		U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63 * L_0 = (U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63 *)il2cpp_codegen_object_new(U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63_il2cpp_TypeInfo_var);
		U3CU3Ec__DisplayClass32_0__ctor_m21ABB4A02AE3611EDDC6C1A4A27CF6F83341418A(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63 * L_1 = V_0;
		NullCheck(L_1);
		L_1->set_U3CU3E4__this_1(__this);
		// System.Threading.CancellationToken ct = stopServerTokenSource.Token;
		U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63 * L_2 = V_0;
		CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_3 = __this->get_stopServerTokenSource_4();
		NullCheck(L_3);
		CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  L_4 = CancellationTokenSource_get_Token_mBB578AFC3DB427E263C966B2DCA86E6ED1CCBC9B(L_3, /*hidden argument*/NULL);
		NullCheck(L_2);
		L_2->set_ct_0(L_4);
		// var task = System.Threading.Tasks.Task.Factory.StartNew(() =>
		// {
		//     ct.ThrowIfCancellationRequested();
		//     while (true)
		//     {
		//         try
		//         {
		//             System.Threading.Tasks.Task<Response> receiveTask = ReceiveMessage();
		//             receiveTask.Wait();
		// 
		//             if (receiveTask.Result.MessageId == Messages.EVENT)
		//                 ProcessEvent(receiveTask.Result);
		//             else if (taskCompletion != null)
		//                 taskCompletion.SetResult(receiveTask.Result);
		//             else
		//                 throw new ErrorException("Received WAMP message that we did not expect.");
		// 
		//             if (ct.IsCancellationRequested)
		//             {
		//                 break;
		//             }
		//         }
		//         catch (System.Exception e)
		//         {
		//             if (e.InnerException.GetType() == typeof(System.Net.WebSockets.WebSocketException))
		//             {
		//                 var exception = e.InnerException as System.Net.WebSockets.WebSocketException;
		//                 if (exception.WebSocketErrorCode == System.Net.WebSockets.WebSocketError.ConnectionClosedPrematurely)
		//                 {
		//                     if (taskCompletion != null)
		//                         taskCompletion.SetException(e);
		// 
		//                     OnDisconnect();
		// 
		//                     return;
		//                 }
		//             }
		// 
		//             if (ws.State != System.Net.WebSockets.WebSocketState.Open)
		//             {
		//                 OnDisconnect();
		//                 return;
		//             }
		// 
		// 
		//             
		//             if (taskCompletion != null)
		//                 taskCompletion.SetException(e);
		//         }
		//     }
		// }, stopServerTokenSource.Token);
		IL2CPP_RUNTIME_CLASS_INIT(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_il2cpp_TypeInfo_var);
		TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155 * L_5 = Task_get_Factory_m31F1298E08390A4AD46B85AB060F1FAD4CE12112_inline(/*hidden argument*/NULL);
		U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63 * L_6 = V_0;
		Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * L_7 = (Action_t591D2A86165F896B4B800BB5C25CE18672A55579 *)il2cpp_codegen_object_new(Action_t591D2A86165F896B4B800BB5C25CE18672A55579_il2cpp_TypeInfo_var);
		Action__ctor_m570E96B2A0C48BC1DC6788460316191F24572760(L_7, L_6, (intptr_t)((intptr_t)U3CU3Ec__DisplayClass32_0_U3CStartListenU3Eb__0_mB184AA45B5F3D79923AF3B9DEAB1E06956F8D6E9_RuntimeMethod_var), /*hidden argument*/NULL);
		CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_8 = __this->get_stopServerTokenSource_4();
		NullCheck(L_8);
		CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  L_9 = CancellationTokenSource_get_Token_mBB578AFC3DB427E263C966B2DCA86E6ED1CCBC9B(L_8, /*hidden argument*/NULL);
		NullCheck(L_5);
		TaskFactory_StartNew_m33BCF7F3334F8ADB57FEAE2E0524A9B483F4EF87(L_5, L_7, L_9, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void Wamp::OnDisconnect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp_OnDisconnect_m17E2623C24F5E4FE6AAC0736C0C8EB1E323D099F (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method)
{
	{
		// if (Disconnected != null)
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_0 = __this->get_Disconnected_0();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		// Disconnected();
		DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * L_1 = __this->get_Disconnected_0();
		NullCheck(L_1);
		DisconnectedHandler_Invoke_m08F15DEC1D0B8B106737140AF777D9CAEF92E79E(L_1, /*hidden argument*/NULL);
	}

IL_0013:
	{
		// }
		return;
	}
}
// System.Threading.Tasks.Task`1<System.String> Wamp::Call(System.String,System.String,System.String,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * Wamp_Call_mAE552B01EB08CE7275EEDD97710E512589D61B33 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___uri0, String_t* ___args1, String_t* ___options2, int32_t ___timeout3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_Call_mAE552B01EB08CE7275EEDD97710E512589D61B33_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		String_t* L_0 = ___uri0;
		(&V_0)->set_uri_4(L_0);
		String_t* L_1 = ___args1;
		(&V_0)->set_args_5(L_1);
		String_t* L_2 = ___options2;
		(&V_0)->set_options_3(L_2);
		int32_t L_3 = ___timeout3;
		(&V_0)->set_timeout_6(L_3);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  L_4 = AsyncTaskMethodBuilder_1_Create_m4CACDA7CCC96C431E5426E670B268CC6FDF86695(/*hidden argument*/AsyncTaskMethodBuilder_1_Create_m4CACDA7CCC96C431E5426E670B268CC6FDF86695_RuntimeMethod_var);
		(&V_0)->set_U3CU3Et__builder_1(L_4);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D  L_5 = V_0;
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C  L_6 = L_5.get_U3CU3Et__builder_1();
		V_1 = L_6;
		AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_m1109EFCCABBD7FBE73DF89539EA069F7803F4CA2((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)(&V_1), (U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_1_Start_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_m1109EFCCABBD7FBE73DF89539EA069F7803F4CA2_RuntimeMethod_var);
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_7 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_1_t4A75FEC8F36C5D4F8793BB8C94E4DAA7457D0286 * L_8 = AsyncTaskMethodBuilder_1_get_Task_mB005567F7203FC44DD0AE1150FFC92706B8E2BB4((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_7, /*hidden argument*/AsyncTaskMethodBuilder_1_get_Task_mB005567F7203FC44DD0AE1150FFC92706B8E2BB4_RuntimeMethod_var);
		return L_8;
	}
}
// System.Threading.Tasks.Task`1<System.UInt32> Wamp::Subscribe(System.String,System.String,Wamp_PublishHandler,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * Wamp_Subscribe_mC841A9CDF1DA84F41596A6E4E087CB13C8AF4F40 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, String_t* ___topic0, String_t* ___options1, PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * ___publishEvent2, int32_t ___timeout3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_Subscribe_mC841A9CDF1DA84F41596A6E4E087CB13C8AF4F40_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		String_t* L_0 = ___topic0;
		(&V_0)->set_topic_4(L_0);
		String_t* L_1 = ___options1;
		(&V_0)->set_options_3(L_1);
		PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * L_2 = ___publishEvent2;
		(&V_0)->set_publishEvent_6(L_2);
		int32_t L_3 = ___timeout3;
		(&V_0)->set_timeout_5(L_3);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  L_4 = AsyncTaskMethodBuilder_1_Create_mFA0E603D8EEE094438B0465D1E57747E2E12FC70(/*hidden argument*/AsyncTaskMethodBuilder_1_Create_mFA0E603D8EEE094438B0465D1E57747E2E12FC70_RuntimeMethod_var);
		(&V_0)->set_U3CU3Et__builder_1(L_4);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9  L_5 = V_0;
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED  L_6 = L_5.get_U3CU3Et__builder_1();
		V_1 = L_6;
		AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m4CFDDD929A9A264EF81EAA747130B8946DD69999((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)(&V_1), (U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_1_Start_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m4CFDDD929A9A264EF81EAA747130B8946DD69999_RuntimeMethod_var);
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_7 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_1_tB8C8430765AEE1D5F24261F5BAD009C22AC7872F * L_8 = AsyncTaskMethodBuilder_1_get_Task_m157191133E216D7561AD02E894BCA819FD5F98FF((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_7, /*hidden argument*/AsyncTaskMethodBuilder_1_get_Task_m157191133E216D7561AD02E894BCA819FD5F98FF_RuntimeMethod_var);
		return L_8;
	}
}
// System.Threading.Tasks.Task Wamp::Unsubscribe(System.UInt32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * Wamp_Unsubscribe_m185B046DAF9E4293617E8A512747B768958ABA6C (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, uint32_t ___subscriptionId0, int32_t ___timeout1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp_Unsubscribe_m185B046DAF9E4293617E8A512747B768958ABA6C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		(&V_0)->set_U3CU3E4__this_2(__this);
		uint32_t L_0 = ___subscriptionId0;
		(&V_0)->set_subscriptionId_3(L_0);
		int32_t L_1 = ___timeout1;
		(&V_0)->set_timeout_4(L_1);
		IL2CPP_RUNTIME_CLASS_INIT(AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487_il2cpp_TypeInfo_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_2 = AsyncTaskMethodBuilder_Create_m081DF9A202E7C2F3CF3D41E1E63E63DA18F19FDB(/*hidden argument*/NULL);
		(&V_0)->set_U3CU3Et__builder_1(L_2);
		(&V_0)->set_U3CU3E1__state_0((-1));
		U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2  L_3 = V_0;
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487  L_4 = L_3.get_U3CU3Et__builder_1();
		V_1 = L_4;
		AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m9B9904F2786C63840AA72106EF2A750CB549AEA3((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)(&V_1), (U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 *)(&V_0), /*hidden argument*/AsyncTaskMethodBuilder_Start_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m9B9904F2786C63840AA72106EF2A750CB549AEA3_RuntimeMethod_var);
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_5 = (&V_0)->get_address_of_U3CU3Et__builder_1();
		Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_6 = AsyncTaskMethodBuilder_get_Task_m3E45BC00F7D224FEA04AB9BF26DB52E131D33022((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// System.Void Wamp::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Wamp__ctor_mCD0D3AC4AB87B0AC898D448724AB0568594D6193 (Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Wamp__ctor_mCD0D3AC4AB87B0AC898D448724AB0568594D6193_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// private System.Threading.CancellationTokenSource stopServerTokenSource = new System.Threading.CancellationTokenSource();
		CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_0 = (CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE *)il2cpp_codegen_object_new(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_il2cpp_TypeInfo_var);
		CancellationTokenSource__ctor_m217582F71932ADD00D63047D8D53C87111116C6B(L_0, /*hidden argument*/NULL);
		__this->set_stopServerTokenSource_4(L_0);
		// private System.Threading.Tasks.TaskCompletionSource<Response> taskCompletion = new System.Threading.Tasks.TaskCompletionSource<Response>();
		TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_1 = (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 *)il2cpp_codegen_object_new(TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0_il2cpp_TypeInfo_var);
		TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3(L_1, /*hidden argument*/TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3_RuntimeMethod_var);
		__this->set_taskCompletion_5(L_1);
		// private System.Collections.Concurrent.ConcurrentDictionary<uint, PublishHandler> subscriptions = new System.Collections.Concurrent.ConcurrentDictionary<uint, PublishHandler>();
		ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * L_2 = (ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 *)il2cpp_codegen_object_new(ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0_il2cpp_TypeInfo_var);
		ConcurrentDictionary_2__ctor_mAE7C80BE83DA4BF21D02463F2AEC2BDA59704B2F(L_2, /*hidden argument*/ConcurrentDictionary_2__ctor_mAE7C80BE83DA4BF21D02463F2AEC2BDA59704B2F_RuntimeMethod_var);
		__this->set_subscriptions_6(L_2);
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_mDD40621A39ED2248A9CD84ED04CFF64820655B0C (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CU3Ec__cctor_mDD40621A39ED2248A9CD84ED04CFF64820655B0C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 * L_0 = (U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 *)il2cpp_codegen_object_new(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_m4643EB15B51A45103D4E30A86716ACD2F70B48B4(L_0, /*hidden argument*/NULL);
		((U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_il2cpp_TypeInfo_var))->set_U3CU3E9_0(L_0);
		return;
	}
}
// System.Void Wamp_<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m4643EB15B51A45103D4E30A86716ACD2F70B48B4 (U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Collections.Generic.IEnumerable`1<System.Byte> Wamp_<>c::<ReceiveMessage>b__24_0(System.Collections.Generic.IEnumerable`1<System.Byte>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CU3Ec_U3CReceiveMessageU3Eb__24_0_m239F0211E8D016A1ACCFF6005B536DECEE383B10 (U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 * __this, RuntimeObject* ___t0, const RuntimeMethod* method)
{
	{
		// byte[] bytes = segments.SelectMany(t => t).ToArray<byte>();
		RuntimeObject* L_0 = ___t0;
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<>c__DisplayClass32_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass32_0__ctor_m21ABB4A02AE3611EDDC6C1A4A27CF6F83341418A (U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Wamp_<>c__DisplayClass32_0::<StartListen>b__0()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass32_0_U3CStartListenU3Eb__0_mB184AA45B5F3D79923AF3B9DEAB1E06956F8D6E9 (U3CU3Ec__DisplayClass32_0_t4DB2320B7DA943E77B0931E14E79862B2F971E63 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CU3Ec__DisplayClass32_0_U3CStartListenU3Eb__0_mB184AA45B5F3D79923AF3B9DEAB1E06956F8D6E9_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * V_0 = NULL;
	Exception_t * V_1 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 5);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		// ct.ThrowIfCancellationRequested();
		CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB * L_0 = __this->get_address_of_ct_0();
		CancellationToken_ThrowIfCancellationRequested_m13AB667F961F83D8ED759BA402325638F43B0938((CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB *)L_0, /*hidden argument*/NULL);
	}

IL_000b:
	{
	}

IL_000c:
	try
	{ // begin try (depth: 1)
		{
			// System.Threading.Tasks.Task<Response> receiveTask = ReceiveMessage();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_1();
			NullCheck(L_1);
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_2 = Wamp_ReceiveMessage_m333714DD38A3BEBB92BA90A416BC053CDC1158BC(L_1, /*hidden argument*/NULL);
			V_0 = L_2;
			// receiveTask.Wait();
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_3 = V_0;
			NullCheck(L_3);
			Task_Wait_m7793234C16E5D2B719519CE3C55653EA4D1A815A(L_3, /*hidden argument*/NULL);
			// if (receiveTask.Result.MessageId == Messages.EVENT)
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_4 = V_0;
			NullCheck(L_4);
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_5 = Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876(L_4, /*hidden argument*/Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876_RuntimeMethod_var);
			NullCheck(L_5);
			int32_t L_6 = Response_get_MessageId_mC397D82D70FC4A2DC73186D1CADF3ADF34CEE0D7_inline(L_5, /*hidden argument*/NULL);
			if ((!(((uint32_t)L_6) == ((uint32_t)((int32_t)36)))))
			{
				goto IL_0040;
			}
		}

IL_002d:
		{
			// ProcessEvent(receiveTask.Result);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_7 = __this->get_U3CU3E4__this_1();
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_8 = V_0;
			NullCheck(L_8);
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_9 = Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876(L_8, /*hidden argument*/Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876_RuntimeMethod_var);
			NullCheck(L_7);
			Wamp_ProcessEvent_mB6BA36EA16F2375692017561F09D725C6D2E6E35(L_7, L_9, /*hidden argument*/NULL);
			goto IL_0070;
		}

IL_0040:
		{
			// else if (taskCompletion != null)
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_10 = __this->get_U3CU3E4__this_1();
			NullCheck(L_10);
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_11 = L_10->get_taskCompletion_5();
			if (!L_11)
			{
				goto IL_0065;
			}
		}

IL_004d:
		{
			// taskCompletion.SetResult(receiveTask.Result);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_12 = __this->get_U3CU3E4__this_1();
			NullCheck(L_12);
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_13 = L_12->get_taskCompletion_5();
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_14 = V_0;
			NullCheck(L_14);
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_15 = Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876(L_14, /*hidden argument*/Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876_RuntimeMethod_var);
			NullCheck(L_13);
			TaskCompletionSource_1_SetResult_mC00E900D0DF47C8A8E1AC8126E8CF9E545516EFE(L_13, L_15, /*hidden argument*/TaskCompletionSource_1_SetResult_mC00E900D0DF47C8A8E1AC8126E8CF9E545516EFE_RuntimeMethod_var);
			goto IL_0070;
		}

IL_0065:
		{
			// throw new ErrorException("Received WAMP message that we did not expect.");
			ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_16 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
			ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_16, _stringLiteral2DAABBE443140677B21642B084FB0DDFF84904B7, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_16, U3CU3Ec__DisplayClass32_0_U3CStartListenU3Eb__0_mB184AA45B5F3D79923AF3B9DEAB1E06956F8D6E9_RuntimeMethod_var);
		}

IL_0070:
		{
			// if (ct.IsCancellationRequested)
			CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB * L_17 = __this->get_address_of_ct_0();
			bool L_18 = CancellationToken_get_IsCancellationRequested_mCF3521778F20F7048B7121885794B9562324447D((CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB *)L_17, /*hidden argument*/NULL);
			if (!L_18)
			{
				goto IL_0082;
			}
		}

IL_007d:
		{
			// break;
			goto IL_0122;
		}

IL_0082:
		{
			// }
			goto IL_000b;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_0084;
		throw e;
	}

CATCH_0084:
	{ // begin catch(System.Exception)
		{
			// catch (System.Exception e)
			V_1 = ((Exception_t *)__exception_local);
			// if (e.InnerException.GetType() == typeof(System.Net.WebSockets.WebSocketException))
			Exception_t * L_19 = V_1;
			NullCheck(L_19);
			Exception_t * L_20 = Exception_get_InnerException_mCB68CC8CBF2540EF381CB17A4E4E3F6D0E33453F_inline(L_19, /*hidden argument*/NULL);
			NullCheck(L_20);
			Type_t * L_21 = Exception_GetType_mA3390B9D538D5FAC3802D9D8A2FCAC31465130F3(L_20, /*hidden argument*/NULL);
			RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D  L_22 = { reinterpret_cast<intptr_t> (WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B_0_0_0_var) };
			IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
			Type_t * L_23 = Type_GetTypeFromHandle_m9DC58ADF0512987012A8A016FB64B068F3B1AFF6(L_22, /*hidden argument*/NULL);
			bool L_24 = Type_op_Equality_m7040622C9E1037EFC73E1F0EDB1DD241282BE3D8(L_21, L_23, /*hidden argument*/NULL);
			if (!L_24)
			{
				goto IL_00df;
			}
		}

IL_00a1:
		{
			// var exception = e.InnerException as System.Net.WebSockets.WebSocketException;
			Exception_t * L_25 = V_1;
			NullCheck(L_25);
			Exception_t * L_26 = Exception_get_InnerException_mCB68CC8CBF2540EF381CB17A4E4E3F6D0E33453F_inline(L_25, /*hidden argument*/NULL);
			// if (exception.WebSocketErrorCode == System.Net.WebSockets.WebSocketError.ConnectionClosedPrematurely)
			NullCheck(((WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B *)IsInstSealed((RuntimeObject*)L_26, WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B_il2cpp_TypeInfo_var)));
			int32_t L_27 = WebSocketException_get_WebSocketErrorCode_m7AC07357E5C368E87BB9C4E16A6F9BF46FBF14CD_inline(((WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B *)IsInstSealed((RuntimeObject*)L_26, WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
			if ((!(((uint32_t)L_27) == ((uint32_t)8))))
			{
				goto IL_00df;
			}
		}

IL_00b4:
		{
			// if (taskCompletion != null)
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_28 = __this->get_U3CU3E4__this_1();
			NullCheck(L_28);
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_29 = L_28->get_taskCompletion_5();
			if (!L_29)
			{
				goto IL_00d2;
			}
		}

IL_00c1:
		{
			// taskCompletion.SetException(e);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_30 = __this->get_U3CU3E4__this_1();
			NullCheck(L_30);
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_31 = L_30->get_taskCompletion_5();
			Exception_t * L_32 = V_1;
			NullCheck(L_31);
			TaskCompletionSource_1_SetException_mB10C34767496AC4F8A94CA8ABA1462B2EC81C6B8(L_31, L_32, /*hidden argument*/TaskCompletionSource_1_SetException_mB10C34767496AC4F8A94CA8ABA1462B2EC81C6B8_RuntimeMethod_var);
		}

IL_00d2:
		{
			// OnDisconnect();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_33 = __this->get_U3CU3E4__this_1();
			NullCheck(L_33);
			Wamp_OnDisconnect_m17E2623C24F5E4FE6AAC0736C0C8EB1E323D099F(L_33, /*hidden argument*/NULL);
			// return;
			goto IL_0122;
		}

IL_00df:
		{
			// if (ws.State != System.Net.WebSockets.WebSocketState.Open)
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_34 = __this->get_U3CU3E4__this_1();
			NullCheck(L_34);
			ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_35 = L_34->get_ws_1();
			NullCheck(L_35);
			int32_t L_36 = VirtFuncInvoker0< int32_t >::Invoke(5 /* System.Net.WebSockets.WebSocketState System.Net.WebSockets.WebSocket::get_State() */, L_35);
			if ((((int32_t)L_36) == ((int32_t)2)))
			{
				goto IL_00ff;
			}
		}

IL_00f2:
		{
			// OnDisconnect();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_37 = __this->get_U3CU3E4__this_1();
			NullCheck(L_37);
			Wamp_OnDisconnect_m17E2623C24F5E4FE6AAC0736C0C8EB1E323D099F(L_37, /*hidden argument*/NULL);
			// return;
			goto IL_0122;
		}

IL_00ff:
		{
			// if (taskCompletion != null)
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_38 = __this->get_U3CU3E4__this_1();
			NullCheck(L_38);
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_39 = L_38->get_taskCompletion_5();
			if (!L_39)
			{
				goto IL_011d;
			}
		}

IL_010c:
		{
			// taskCompletion.SetException(e);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_40 = __this->get_U3CU3E4__this_1();
			NullCheck(L_40);
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_41 = L_40->get_taskCompletion_5();
			Exception_t * L_42 = V_1;
			NullCheck(L_41);
			TaskCompletionSource_1_SetException_mB10C34767496AC4F8A94CA8ABA1462B2EC81C6B8(L_41, L_42, /*hidden argument*/TaskCompletionSource_1_SetException_mB10C34767496AC4F8A94CA8ABA1462B2EC81C6B8_RuntimeMethod_var);
		}

IL_011d:
		{
			// }
			goto IL_000b;
		}
	} // end catch (depth: 1)

IL_0122:
	{
		// }, stopServerTokenSource.Token);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<Call>d__34::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCallU3Ed__34_MoveNext_mFE458EC82A6FE04034653EFACBCDF773333888F1 (U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CCallU3Ed__34_MoveNext_mFE458EC82A6FE04034653EFACBCDF773333888F1_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * V_1 = NULL;
	String_t* V_2 = NULL;
	int32_t V_3 = 0;
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  V_4;
	memset((&V_4), 0, sizeof(V_4));
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  V_5;
	memset((&V_5), 0, sizeof(V_5));
	Exception_t * V_6 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 4);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_00b5;
			}
		}

IL_0014:
		{
			int32_t L_3 = V_0;
			if ((((int32_t)L_3) == ((int32_t)1)))
			{
				goto IL_011e;
			}
		}

IL_001b:
		{
			// int requestId = ++currentRequestId;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_4 = V_1;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_5 = V_1;
			NullCheck(L_5);
			int32_t L_6 = L_5->get_currentRequestId_3();
			V_3 = ((int32_t)il2cpp_codegen_add((int32_t)L_6, (int32_t)1));
			int32_t L_7 = V_3;
			NullCheck(L_4);
			L_4->set_currentRequestId_3(L_7);
			int32_t L_8 = V_3;
			__this->set_U3CrequestIdU3E5__2_7(L_8);
			// await Send($"[{(int)Messages.CALL},{requestId},{options},\"{uri}\",[],{args}]", timeout);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_9 = V_1;
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_10 = (ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A*)(ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A*)SZArrayNew(ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A_il2cpp_TypeInfo_var, (uint32_t)5);
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_11 = L_10;
			int32_t L_12 = ((int32_t)48);
			RuntimeObject * L_13 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_12);
			NullCheck(L_11);
			ArrayElementTypeCheck (L_11, L_13);
			(L_11)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_13);
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_14 = L_11;
			int32_t L_15 = __this->get_U3CrequestIdU3E5__2_7();
			int32_t L_16 = L_15;
			RuntimeObject * L_17 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_16);
			NullCheck(L_14);
			ArrayElementTypeCheck (L_14, L_17);
			(L_14)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_17);
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_18 = L_14;
			String_t* L_19 = __this->get_options_3();
			NullCheck(L_18);
			ArrayElementTypeCheck (L_18, L_19);
			(L_18)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_19);
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_20 = L_18;
			String_t* L_21 = __this->get_uri_4();
			NullCheck(L_20);
			ArrayElementTypeCheck (L_20, L_21);
			(L_20)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_21);
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_22 = L_20;
			String_t* L_23 = __this->get_args_5();
			NullCheck(L_22);
			ArrayElementTypeCheck (L_22, L_23);
			(L_22)->SetAt(static_cast<il2cpp_array_size_t>(4), (RuntimeObject *)L_23);
			String_t* L_24 = String_Format_mA3AC3FE7B23D97F3A5BAA082D25B0E01B341A865(_stringLiteral29F0D275C3CF8BD94A296DB72E80EA061DF558D6, L_22, /*hidden argument*/NULL);
			int32_t L_25 = __this->get_timeout_6();
			NullCheck(L_9);
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_26 = Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591(L_9, L_24, L_25, /*hidden argument*/NULL);
			NullCheck(L_26);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_27 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_26, /*hidden argument*/NULL);
			V_4 = L_27;
			bool L_28 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_4), /*hidden argument*/NULL);
			if (L_28)
			{
				goto IL_00d2;
			}
		}

IL_0091:
		{
			int32_t L_29 = 0;
			V_0 = L_29;
			__this->set_U3CU3E1__state_0(L_29);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_30 = V_4;
			__this->set_U3CU3Eu__1_8(L_30);
			AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_31 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mE41874465445B27A74796D0922012A53154AC9C3((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_31, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_4), (U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mE41874465445B27A74796D0922012A53154AC9C3_RuntimeMethod_var);
			goto IL_0177;
		}

IL_00b5:
		{
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_32 = __this->get_U3CU3Eu__1_8();
			V_4 = L_32;
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_33 = __this->get_address_of_U3CU3Eu__1_8();
			il2cpp_codegen_initobj(L_33, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
			int32_t L_34 = (-1);
			V_0 = L_34;
			__this->set_U3CU3E1__state_0(L_34);
		}

IL_00d2:
		{
			TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_4), /*hidden argument*/NULL);
			// Response response = await ReceiveExpect(Messages.RESULT, requestId, timeout);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_35 = V_1;
			int32_t L_36 = __this->get_U3CrequestIdU3E5__2_7();
			int32_t L_37 = __this->get_timeout_6();
			NullCheck(L_35);
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_38 = Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864(L_35, ((int32_t)50), L_36, L_37, /*hidden argument*/NULL);
			NullCheck(L_38);
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_39 = Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3(L_38, /*hidden argument*/Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3_RuntimeMethod_var);
			V_5 = L_39;
			bool L_40 = TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_5), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E_RuntimeMethod_var);
			if (L_40)
			{
				goto IL_013b;
			}
		}

IL_00fd:
		{
			int32_t L_41 = 1;
			V_0 = L_41;
			__this->set_U3CU3E1__state_0(L_41);
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_42 = V_5;
			__this->set_U3CU3Eu__2_9(L_42);
			AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_43 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mF490191D1E3DB080FB623CECA0FE22B25E9F298D((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_43, (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_5), (U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D_mF490191D1E3DB080FB623CECA0FE22B25E9F298D_RuntimeMethod_var);
			goto IL_0177;
		}

IL_011e:
		{
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_44 = __this->get_U3CU3Eu__2_9();
			V_5 = L_44;
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * L_45 = __this->get_address_of_U3CU3Eu__2_9();
			il2cpp_codegen_initobj(L_45, sizeof(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 ));
			int32_t L_46 = (-1);
			V_0 = L_46;
			__this->set_U3CU3E1__state_0(L_46);
		}

IL_013b:
		{
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_47 = TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_5), /*hidden argument*/TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50_RuntimeMethod_var);
			// return response.Json;
			NullCheck(L_47);
			String_t* L_48 = Response_get_Json_m344AA62580A8B48CEECF9F5A9B33638D572B785B_inline(L_47, /*hidden argument*/NULL);
			V_2 = L_48;
			goto IL_0163;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_014a;
		throw e;
	}

CATCH_014a:
	{ // begin catch(System.Exception)
		V_6 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_49 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_50 = V_6;
		AsyncTaskMethodBuilder_1_SetException_m7EC0D7D4B3431CA02400760ADA732A416EAEFB2D((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_49, L_50, /*hidden argument*/AsyncTaskMethodBuilder_1_SetException_m7EC0D7D4B3431CA02400760ADA732A416EAEFB2D_RuntimeMethod_var);
		goto IL_0177;
	} // end catch (depth: 1)

IL_0163:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_51 = __this->get_address_of_U3CU3Et__builder_1();
		String_t* L_52 = V_2;
		AsyncTaskMethodBuilder_1_SetResult_m44836E9953D99A304CCB8725A8E47453725FFE9B((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_51, L_52, /*hidden argument*/AsyncTaskMethodBuilder_1_SetResult_m44836E9953D99A304CCB8725A8E47453725FFE9B_RuntimeMethod_var);
	}

IL_0177:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CCallU3Ed__34_MoveNext_mFE458EC82A6FE04034653EFACBCDF773333888F1_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * _thisAdjusted = reinterpret_cast<U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D *>(__this + _offset);
	U3CCallU3Ed__34_MoveNext_mFE458EC82A6FE04034653EFACBCDF773333888F1(_thisAdjusted, method);
}
// System.Void Wamp_<Call>d__34::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCallU3Ed__34_SetStateMachine_mC98B572BE8C143D41DF3D54466223A92F1F1D6B8 (U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CCallU3Ed__34_SetStateMachine_mC98B572BE8C143D41DF3D54466223A92F1F1D6B8_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_1_SetStateMachine_m83945BA8843F53C1C9ED18D4B312FFF9A24BB9EB((AsyncTaskMethodBuilder_1_tC7B1E45031A96D1F2363C0491EC79BBE740BC10C *)L_0, L_1, /*hidden argument*/AsyncTaskMethodBuilder_1_SetStateMachine_m83945BA8843F53C1C9ED18D4B312FFF9A24BB9EB_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CCallU3Ed__34_SetStateMachine_mC98B572BE8C143D41DF3D54466223A92F1F1D6B8_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D * _thisAdjusted = reinterpret_cast<U3CCallU3Ed__34_t236D41E3C3148DBFBBDE360CAE42797026751B5D *>(__this + _offset);
	U3CCallU3Ed__34_SetStateMachine_mC98B572BE8C143D41DF3D54466223A92F1F1D6B8(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<Close>d__30::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCloseU3Ed__30_MoveNext_mAB43192731588E3CF72C9F96212C641FB1A0184D (U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CCloseU3Ed__30_MoveNext_mAB43192731588E3CF72C9F96212C641FB1A0184D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * V_1 = NULL;
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  V_2;
	memset((&V_2), 0, sizeof(V_2));
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  V_3;
	memset((&V_3), 0, sizeof(V_3));
	Exception_t * V_4 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 8);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
		}

IL_0013:
		try
		{ // begin try (depth: 2)
			{
				int32_t L_3 = V_0;
				switch (L_3)
				{
					case 0:
					{
						goto IL_0073;
					}
					case 1:
					{
						goto IL_00d6;
					}
					case 2:
					{
						goto IL_0116;
					}
				}
			}

IL_0025:
			{
				// await Send($"[{(int)Messages.GOODBYE},{{}},\"bye_from_csharp_client\"]", timeout);
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_4 = V_1;
				int32_t L_5 = 6;
				RuntimeObject * L_6 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_5);
				String_t* L_7 = String_Format_m0ACDD8B34764E4040AED0B3EEB753567E4576BFA(_stringLiteral78272321B843EDB866543FEA772D57A3E1AB374E, L_6, /*hidden argument*/NULL);
				int32_t L_8 = __this->get_timeout_3();
				NullCheck(L_4);
				Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_9 = Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591(L_4, L_7, L_8, /*hidden argument*/NULL);
				NullCheck(L_9);
				TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_10 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_9, /*hidden argument*/NULL);
				V_2 = L_10;
				bool L_11 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
				if (L_11)
				{
					goto IL_008f;
				}
			}

IL_0050:
			{
				int32_t L_12 = 0;
				V_0 = L_12;
				__this->set_U3CU3E1__state_0(L_12);
				TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_13 = V_2;
				__this->set_U3CU3Eu__1_4(L_13);
				AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_14 = __this->get_address_of_U3CU3Et__builder_1();
				AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mDAC2ADF8AB1E52888B4479666D626F617937E900((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_14, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), (U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mDAC2ADF8AB1E52888B4479666D626F617937E900_RuntimeMethod_var);
				goto IL_01fa;
			}

IL_0073:
			{
				TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_15 = __this->get_U3CU3Eu__1_4();
				V_2 = L_15;
				TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_16 = __this->get_address_of_U3CU3Eu__1_4();
				il2cpp_codegen_initobj(L_16, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
				int32_t L_17 = (-1);
				V_0 = L_17;
				__this->set_U3CU3E1__state_0(L_17);
			}

IL_008f:
			{
				TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
				// Response response = await ReceiveExpect(Messages.GOODBYE, 0, timeout);
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_18 = V_1;
				int32_t L_19 = __this->get_timeout_3();
				NullCheck(L_18);
				Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_20 = Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864(L_18, 6, 0, L_19, /*hidden argument*/NULL);
				NullCheck(L_20);
				TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_21 = Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3(L_20, /*hidden argument*/Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3_RuntimeMethod_var);
				V_3 = L_21;
				bool L_22 = TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_3), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E_RuntimeMethod_var);
				if (L_22)
				{
					goto IL_00f2;
				}
			}

IL_00b3:
			{
				int32_t L_23 = 1;
				V_0 = L_23;
				__this->set_U3CU3E1__state_0(L_23);
				TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_24 = V_3;
				__this->set_U3CU3Eu__2_5(L_24);
				AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_25 = __this->get_address_of_U3CU3Et__builder_1();
				AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m67D96E6CEEDCD41F4AD94298BF70CFB2EBA1D917((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_25, (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_3), (U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_m67D96E6CEEDCD41F4AD94298BF70CFB2EBA1D917_RuntimeMethod_var);
				goto IL_01fa;
			}

IL_00d6:
			{
				TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_26 = __this->get_U3CU3Eu__2_5();
				V_3 = L_26;
				TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * L_27 = __this->get_address_of_U3CU3Eu__2_5();
				il2cpp_codegen_initobj(L_27, sizeof(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 ));
				int32_t L_28 = (-1);
				V_0 = L_28;
				__this->set_U3CU3E1__state_0(L_28);
			}

IL_00f2:
			{
				TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_3), /*hidden argument*/TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50_RuntimeMethod_var);
				// stopServerTokenSource.Cancel();
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_29 = V_1;
				NullCheck(L_29);
				CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_30 = L_29->get_stopServerTokenSource_4();
				NullCheck(L_30);
				CancellationTokenSource_Cancel_m33023D4CB46117A4C6A7C1ED0076918871A1E2DF(L_30, /*hidden argument*/NULL);
				// using (var cts = new System.Threading.CancellationTokenSource(timeout))
				int32_t L_31 = __this->get_timeout_3();
				CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_32 = (CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE *)il2cpp_codegen_object_new(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_il2cpp_TypeInfo_var);
				CancellationTokenSource__ctor_m282A9AF96A92487F7B0B391F00F3083C1832A53F(L_32, L_31, /*hidden argument*/NULL);
				__this->set_U3CctsU3E5__2_6(L_32);
			}

IL_0116:
			{
			}

IL_0117:
			try
			{ // begin try (depth: 3)
				{
					int32_t L_33 = V_0;
					if ((((int32_t)L_33) == ((int32_t)2)))
					{
						goto IL_016d;
					}
				}

IL_011b:
				{
					// await ws.CloseOutputAsync(System.Net.WebSockets.WebSocketCloseStatus.NormalClosure, "wamp_close", cts.Token);
					Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_34 = V_1;
					NullCheck(L_34);
					ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_35 = L_34->get_ws_1();
					CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_36 = __this->get_U3CctsU3E5__2_6();
					NullCheck(L_36);
					CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  L_37 = CancellationTokenSource_get_Token_mBB578AFC3DB427E263C966B2DCA86E6ED1CCBC9B(L_36, /*hidden argument*/NULL);
					NullCheck(L_35);
					Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_38 = VirtFuncInvoker3< Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 *, int32_t, String_t*, CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  >::Invoke(7 /* System.Threading.Tasks.Task System.Net.WebSockets.WebSocket::CloseOutputAsync(System.Net.WebSockets.WebSocketCloseStatus,System.String,System.Threading.CancellationToken) */, L_35, ((int32_t)1000), _stringLiteral7AAB67A524EC369B9D708D84DC85A9E10DDAD247, L_37);
					NullCheck(L_38);
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_39 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_38, /*hidden argument*/NULL);
					V_2 = L_39;
					bool L_40 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
					if (L_40)
					{
						goto IL_0189;
					}
				}

IL_014a:
				{
					int32_t L_41 = 2;
					V_0 = L_41;
					__this->set_U3CU3E1__state_0(L_41);
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_42 = V_2;
					__this->set_U3CU3Eu__1_4(L_42);
					AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_43 = __this->get_address_of_U3CU3Et__builder_1();
					AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mDAC2ADF8AB1E52888B4479666D626F617937E900((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_43, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), (U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5_mDAC2ADF8AB1E52888B4479666D626F617937E900_RuntimeMethod_var);
					IL2CPP_LEAVE(0x1FA, FINALLY_0192);
				}

IL_016d:
				{
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_44 = __this->get_U3CU3Eu__1_4();
					V_2 = L_44;
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_45 = __this->get_address_of_U3CU3Eu__1_4();
					il2cpp_codegen_initobj(L_45, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
					int32_t L_46 = (-1);
					V_0 = L_46;
					__this->set_U3CU3E1__state_0(L_46);
				}

IL_0189:
				{
					TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_2), /*hidden argument*/NULL);
					// }
					IL2CPP_LEAVE(0x1AA, FINALLY_0192);
				}
			} // end try (depth: 3)
			catch(Il2CppExceptionWrapper& e)
			{
				__last_unhandled_exception = (Exception_t *)e.ex;
				goto FINALLY_0192;
			}

FINALLY_0192:
			{ // begin finally (depth: 3)
				{
					int32_t L_47 = V_0;
					if ((((int32_t)L_47) >= ((int32_t)0)))
					{
						goto IL_01a9;
					}
				}

IL_0196:
				{
					CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_48 = __this->get_U3CctsU3E5__2_6();
					if (!L_48)
					{
						goto IL_01a9;
					}
				}

IL_019e:
				{
					CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_49 = __this->get_U3CctsU3E5__2_6();
					NullCheck(L_49);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_49);
				}

IL_01a9:
				{
					IL2CPP_END_FINALLY(402)
				}
			} // end finally (depth: 3)
			IL2CPP_CLEANUP(402)
			{
				IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
				IL2CPP_JUMP_TBL(0x1FA, IL_01fa)
				IL2CPP_JUMP_TBL(0x1AA, IL_01aa)
			}

IL_01aa:
			{
				__this->set_U3CctsU3E5__2_6((CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE *)NULL);
				// }
				goto IL_01cc;
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			__exception_local = (Exception_t *)e.ex;
			if(il2cpp_codegen_class_is_assignable_from (WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
				goto CATCH_01b3;
			throw e;
		}

CATCH_01b3:
		{ // begin catch(System.Net.WebSockets.WebSocketException)
			// catch (System.Net.WebSockets.WebSocketException)
			// ws.Dispose();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_50 = V_1;
			NullCheck(L_50);
			ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_51 = L_50->get_ws_1();
			NullCheck(L_51);
			VirtActionInvoker0::Invoke(8 /* System.Void System.Net.WebSockets.WebSocket::Dispose() */, L_51);
			// stopServerTokenSource.Cancel();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_52 = V_1;
			NullCheck(L_52);
			CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_53 = L_52->get_stopServerTokenSource_4();
			NullCheck(L_53);
			CancellationTokenSource_Cancel_m33023D4CB46117A4C6A7C1ED0076918871A1E2DF(L_53, /*hidden argument*/NULL);
			// return;
			goto IL_01e7;
		} // end catch (depth: 2)

IL_01cc:
		{
			goto IL_01e7;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_01ce;
		throw e;
	}

CATCH_01ce:
	{ // begin catch(System.Exception)
		V_4 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_54 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_55 = V_4;
		AsyncTaskMethodBuilder_SetException_m370C484922A63A6EF96E241D1370B8814F1F2D6B((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_54, L_55, /*hidden argument*/NULL);
		goto IL_01fa;
	} // end catch (depth: 1)

IL_01e7:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_56 = __this->get_address_of_U3CU3Et__builder_1();
		AsyncTaskMethodBuilder_SetResult_m151016FB698F3BB34A73BAE693A97513A7E4C838((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_56, /*hidden argument*/NULL);
	}

IL_01fa:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CCloseU3Ed__30_MoveNext_mAB43192731588E3CF72C9F96212C641FB1A0184D_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * _thisAdjusted = reinterpret_cast<U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 *>(__this + _offset);
	U3CCloseU3Ed__30_MoveNext_mAB43192731588E3CF72C9F96212C641FB1A0184D(_thisAdjusted, method);
}
// System.Void Wamp_<Close>d__30::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CCloseU3Ed__30_SetStateMachine_mDD6A8E81D89D09469510FB615D6DF79B2E61C0AB (U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	{
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_SetStateMachine_mB5DD68F7C49EA6D452AEBA02B1B98AED898C3C25((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CCloseU3Ed__30_SetStateMachine_mDD6A8E81D89D09469510FB615D6DF79B2E61C0AB_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 * _thisAdjusted = reinterpret_cast<U3CCloseU3Ed__30_t02EC171805E6B1BF1E49CB58C69A8FCC2B5849D5 *>(__this + _offset);
	U3CCloseU3Ed__30_SetStateMachine_mDD6A8E81D89D09469510FB615D6DF79B2E61C0AB(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<Connect>d__27::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14 (U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * V_1 = NULL;
	Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E * V_2 = NULL;
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  V_3;
	memset((&V_3), 0, sizeof(V_3));
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * V_4 = NULL;
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  V_5;
	memset((&V_5), 0, sizeof(V_5));
	Exception_t * V_6 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 7);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_3();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
		}

IL_0013:
		try
		{ // begin try (depth: 2)
			{
				int32_t L_3 = V_0;
				switch (L_3)
				{
					case 0:
					{
						goto IL_003c;
					}
					case 1:
					{
						goto IL_012e;
					}
					case 2:
					{
						goto IL_0199;
					}
				}
			}

IL_0025:
			{
				// System.Uri uri = new System.Uri(host);
				String_t* L_4 = __this->get_host_2();
				Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E * L_5 = (Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E *)il2cpp_codegen_object_new(Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E_il2cpp_TypeInfo_var);
				Uri__ctor_mBA69907A1D799CD12ED44B611985B25FE4C626A2(L_5, L_4, /*hidden argument*/NULL);
				V_2 = L_5;
				// using (var cts = new System.Threading.CancellationTokenSource())
				CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_6 = (CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE *)il2cpp_codegen_object_new(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_il2cpp_TypeInfo_var);
				CancellationTokenSource__ctor_m217582F71932ADD00D63047D8D53C87111116C6B(L_6, /*hidden argument*/NULL);
				__this->set_U3CctsU3E5__2_5(L_6);
			}

IL_003c:
			{
			}

IL_003d:
			try
			{ // begin try (depth: 3)
				{
					int32_t L_7 = V_0;
					if (!L_7)
					{
						goto IL_009c;
					}
				}

IL_0040:
				{
					// if (ws == null)
					Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_8 = V_1;
					NullCheck(L_8);
					ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_9 = L_8->get_ws_1();
					if (L_9)
					{
						goto IL_0053;
					}
				}

IL_0048:
				{
					// ws = new System.Net.WebSockets.ClientWebSocket();
					Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_10 = V_1;
					ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_11 = (ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 *)il2cpp_codegen_object_new(ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90_il2cpp_TypeInfo_var);
					ClientWebSocket__ctor_m1D76A019F2A4599B3406D69CBFF9E7D507AF8CE1(L_11, /*hidden argument*/NULL);
					NullCheck(L_10);
					L_10->set_ws_1(L_11);
				}

IL_0053:
				{
					// await ws.ConnectAsync(uri, cts.Token);
					Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_12 = V_1;
					NullCheck(L_12);
					ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_13 = L_12->get_ws_1();
					Uri_t87E4A94B2901F5EEDD18AA72C3DB1B00E672D68E * L_14 = V_2;
					CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_15 = __this->get_U3CctsU3E5__2_5();
					NullCheck(L_15);
					CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  L_16 = CancellationTokenSource_get_Token_mBB578AFC3DB427E263C966B2DCA86E6ED1CCBC9B(L_15, /*hidden argument*/NULL);
					NullCheck(L_13);
					Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_17 = ClientWebSocket_ConnectAsync_m5345909A338BEFF1D71DE95D7A25515E5D348E54(L_13, L_14, L_16, /*hidden argument*/NULL);
					NullCheck(L_17);
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_18 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_17, /*hidden argument*/NULL);
					V_3 = L_18;
					bool L_19 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_3), /*hidden argument*/NULL);
					if (L_19)
					{
						goto IL_00b8;
					}
				}

IL_0079:
				{
					int32_t L_20 = 0;
					V_0 = L_20;
					__this->set_U3CU3E1__state_0(L_20);
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_21 = V_3;
					__this->set_U3CU3Eu__1_6(L_21);
					AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_22 = __this->get_address_of_U3CU3Et__builder_1();
					AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m393F31C0EF4CBF441A486F7C6A0D4AB4B58B4286((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_22, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_3), (U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m393F31C0EF4CBF441A486F7C6A0D4AB4B58B4286_RuntimeMethod_var);
					IL2CPP_LEAVE(0x228, FINALLY_00c1);
				}

IL_009c:
				{
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_23 = __this->get_U3CU3Eu__1_6();
					V_3 = L_23;
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_24 = __this->get_address_of_U3CU3Eu__1_6();
					il2cpp_codegen_initobj(L_24, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
					int32_t L_25 = (-1);
					V_0 = L_25;
					__this->set_U3CU3E1__state_0(L_25);
				}

IL_00b8:
				{
					TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_3), /*hidden argument*/NULL);
					// }
					IL2CPP_LEAVE(0xD9, FINALLY_00c1);
				}
			} // end try (depth: 3)
			catch(Il2CppExceptionWrapper& e)
			{
				__last_unhandled_exception = (Exception_t *)e.ex;
				goto FINALLY_00c1;
			}

FINALLY_00c1:
			{ // begin finally (depth: 3)
				{
					int32_t L_26 = V_0;
					if ((((int32_t)L_26) >= ((int32_t)0)))
					{
						goto IL_00d8;
					}
				}

IL_00c5:
				{
					CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_27 = __this->get_U3CctsU3E5__2_5();
					if (!L_27)
					{
						goto IL_00d8;
					}
				}

IL_00cd:
				{
					CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_28 = __this->get_U3CctsU3E5__2_5();
					NullCheck(L_28);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_28);
				}

IL_00d8:
				{
					IL2CPP_END_FINALLY(193)
				}
			} // end finally (depth: 3)
			IL2CPP_CLEANUP(193)
			{
				IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
				IL2CPP_JUMP_TBL(0x228, IL_0228)
				IL2CPP_JUMP_TBL(0xD9, IL_00d9)
			}

IL_00d9:
			{
				__this->set_U3CctsU3E5__2_5((CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE *)NULL);
				// await Send($"[{(int)Messages.HELLO},\"realm1\"]", timeout);
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_29 = V_1;
				int32_t L_30 = 1;
				RuntimeObject * L_31 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_30);
				String_t* L_32 = String_Format_m0ACDD8B34764E4040AED0B3EEB753567E4576BFA(_stringLiteralA5DA2189ECA4EFF57E0D70FFAD03138FACBEA493, L_31, /*hidden argument*/NULL);
				int32_t L_33 = __this->get_timeout_4();
				NullCheck(L_29);
				Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_34 = Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591(L_29, L_32, L_33, /*hidden argument*/NULL);
				NullCheck(L_34);
				TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_35 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_34, /*hidden argument*/NULL);
				V_3 = L_35;
				bool L_36 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_3), /*hidden argument*/NULL);
				if (L_36)
				{
					goto IL_014a;
				}
			}

IL_010b:
			{
				int32_t L_37 = 1;
				V_0 = L_37;
				__this->set_U3CU3E1__state_0(L_37);
				TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_38 = V_3;
				__this->set_U3CU3Eu__1_6(L_38);
				AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_39 = __this->get_address_of_U3CU3Et__builder_1();
				AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m393F31C0EF4CBF441A486F7C6A0D4AB4B58B4286((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_39, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_3), (U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_m393F31C0EF4CBF441A486F7C6A0D4AB4B58B4286_RuntimeMethod_var);
				goto IL_0228;
			}

IL_012e:
			{
				TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_40 = __this->get_U3CU3Eu__1_6();
				V_3 = L_40;
				TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_41 = __this->get_address_of_U3CU3Eu__1_6();
				il2cpp_codegen_initobj(L_41, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
				int32_t L_42 = (-1);
				V_0 = L_42;
				__this->set_U3CU3E1__state_0(L_42);
			}

IL_014a:
			{
				TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_3), /*hidden argument*/NULL);
				// StartListen();
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_43 = V_1;
				NullCheck(L_43);
				Wamp_StartListen_mD58F9728B82A7A344E95BA20A462450F5725CEB8(L_43, /*hidden argument*/NULL);
				// Response response = await ReceiveExpect(Messages.WELCOME, 0, timeout);
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_44 = V_1;
				int32_t L_45 = __this->get_timeout_4();
				NullCheck(L_44);
				Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_46 = Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864(L_44, 2, 0, L_45, /*hidden argument*/NULL);
				NullCheck(L_46);
				TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_47 = Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3(L_46, /*hidden argument*/Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3_RuntimeMethod_var);
				V_5 = L_47;
				bool L_48 = TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_5), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E_RuntimeMethod_var);
				if (L_48)
				{
					goto IL_01b6;
				}
			}

IL_0175:
			{
				int32_t L_49 = 2;
				V_0 = L_49;
				__this->set_U3CU3E1__state_0(L_49);
				TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_50 = V_5;
				__this->set_U3CU3Eu__2_7(L_50);
				AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_51 = __this->get_address_of_U3CU3Et__builder_1();
				AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_mCD9168B1DF026CB3BB6DEF84647D3DAD1BA186A6((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_51, (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_5), (U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6_mCD9168B1DF026CB3BB6DEF84647D3DAD1BA186A6_RuntimeMethod_var);
				goto IL_0228;
			}

IL_0199:
			{
				TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_52 = __this->get_U3CU3Eu__2_7();
				V_5 = L_52;
				TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * L_53 = __this->get_address_of_U3CU3Eu__2_7();
				il2cpp_codegen_initobj(L_53, sizeof(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 ));
				int32_t L_54 = (-1);
				V_0 = L_54;
				__this->set_U3CU3E1__state_0(L_54);
			}

IL_01b6:
			{
				Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_55 = TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_5), /*hidden argument*/TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50_RuntimeMethod_var);
				V_4 = L_55;
				// sessionId = response.ContextSpecificResultId;
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_56 = V_1;
				Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_57 = V_4;
				NullCheck(L_57);
				int32_t L_58 = Response_get_ContextSpecificResultId_m8C53A20C58BACF5A2DA2379A42D2818F283CF862_inline(L_57, /*hidden argument*/NULL);
				NullCheck(L_56);
				L_56->set_sessionId_2(L_58);
				// }
				goto IL_01fa;
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			__exception_local = (Exception_t *)e.ex;
			if(il2cpp_codegen_class_is_assignable_from (WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
				goto CATCH_01ce;
			if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
				goto CATCH_01ef;
			throw e;
		}

CATCH_01ce:
		{ // begin catch(System.Net.WebSockets.WebSocketException)
			// ws.Dispose();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_59 = V_1;
			NullCheck(L_59);
			ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_60 = L_59->get_ws_1();
			NullCheck(L_60);
			VirtActionInvoker0::Invoke(8 /* System.Void System.Net.WebSockets.WebSocket::Dispose() */, L_60);
			// ws = new System.Net.WebSockets.ClientWebSocket();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_61 = V_1;
			ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_62 = (ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 *)il2cpp_codegen_object_new(ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90_il2cpp_TypeInfo_var);
			ClientWebSocket__ctor_m1D76A019F2A4599B3406D69CBFF9E7D507AF8CE1(L_62, /*hidden argument*/NULL);
			NullCheck(L_61);
			L_61->set_ws_1(L_62);
			// throw new ErrorException(e.ToString());
			NullCheck(((WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B *)__exception_local));
			String_t* L_63 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, ((WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B *)__exception_local));
			ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_64 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
			ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_64, L_63, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_64, U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14_RuntimeMethod_var);
		} // end catch (depth: 2)

CATCH_01ef:
		{ // begin catch(System.Exception)
			// throw new ErrorException(e.ToString());
			NullCheck(((Exception_t *)__exception_local));
			String_t* L_65 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, ((Exception_t *)__exception_local));
			ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_66 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
			ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_66, L_65, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_66, U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14_RuntimeMethod_var);
		} // end catch (depth: 2)

IL_01fa:
		{
			goto IL_0215;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_01fc;
		throw e;
	}

CATCH_01fc:
	{ // begin catch(System.Exception)
		V_6 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_67 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_68 = V_6;
		AsyncTaskMethodBuilder_SetException_m370C484922A63A6EF96E241D1370B8814F1F2D6B((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_67, L_68, /*hidden argument*/NULL);
		goto IL_0228;
	} // end catch (depth: 1)

IL_0215:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_69 = __this->get_address_of_U3CU3Et__builder_1();
		AsyncTaskMethodBuilder_SetResult_m151016FB698F3BB34A73BAE693A97513A7E4C838((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_69, /*hidden argument*/NULL);
	}

IL_0228:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * _thisAdjusted = reinterpret_cast<U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 *>(__this + _offset);
	U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14(_thisAdjusted, method);
}
// System.Void Wamp_<Connect>d__27::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CConnectU3Ed__27_SetStateMachine_m3C346664EBD564CDA981B81988E47665403580B9 (U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	{
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_SetStateMachine_mB5DD68F7C49EA6D452AEBA02B1B98AED898C3C25((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CConnectU3Ed__27_SetStateMachine_m3C346664EBD564CDA981B81988E47665403580B9_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 * _thisAdjusted = reinterpret_cast<U3CConnectU3Ed__27_t4E08E6D6AB76911A1765C07EBB2EC10FB4EE88B6 *>(__this + _offset);
	U3CConnectU3Ed__27_SetStateMachine_m3C346664EBD564CDA981B81988E47665403580B9(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<Receive>d__25::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4 (U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * V_1 = NULL;
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * V_2 = NULL;
	Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * V_3 = NULL;
	TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A  V_4;
	memset((&V_4), 0, sizeof(V_4));
	Exception_t * V_5 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 3);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_006c;
			}
		}

IL_0011:
		{
			// System.Threading.Tasks.Task task = await System.Threading.Tasks.Task.WhenAny(
			//     taskCompletion.Task,
			//     System.Threading.Tasks.Task.Delay(timeout));
			TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE* L_3 = (TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE*)(TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE*)SZArrayNew(TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE_il2cpp_TypeInfo_var, (uint32_t)2);
			TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE* L_4 = L_3;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_5 = V_1;
			NullCheck(L_5);
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_6 = L_5->get_taskCompletion_5();
			NullCheck(L_6);
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_7 = TaskCompletionSource_1_get_Task_mDC9ED85B68696CD8BD9DE3A757F317BA5C6417A4_inline(L_6, /*hidden argument*/TaskCompletionSource_1_get_Task_mDC9ED85B68696CD8BD9DE3A757F317BA5C6417A4_RuntimeMethod_var);
			NullCheck(L_4);
			ArrayElementTypeCheck (L_4, L_7);
			(L_4)->SetAt(static_cast<il2cpp_array_size_t>(0), (Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 *)L_7);
			TaskU5BU5D_tE4155ED1F21E503C57CC7066D9B6AB64EE0DDDCE* L_8 = L_4;
			int32_t L_9 = __this->get_timeout_3();
			IL2CPP_RUNTIME_CLASS_INIT(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_il2cpp_TypeInfo_var);
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_10 = Task_Delay_m193E6692B81A2A6C45F5FAE08CF79FA06FC7DA60(L_9, /*hidden argument*/NULL);
			NullCheck(L_8);
			ArrayElementTypeCheck (L_8, L_10);
			(L_8)->SetAt(static_cast<il2cpp_array_size_t>(1), (Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 *)L_10);
			Task_1_t6E4E91059C08F359F21A42B8BFA51E8BBFA47138 * L_11 = Task_WhenAny_mBC42BCB13C1F576DE6DAA08EB4F704D8176E674F(L_8, /*hidden argument*/NULL);
			NullCheck(L_11);
			TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A  L_12 = Task_1_GetAwaiter_m9814C67F6EAD25792CF76E9A4C961FD4704B2965(L_11, /*hidden argument*/Task_1_GetAwaiter_m9814C67F6EAD25792CF76E9A4C961FD4704B2965_RuntimeMethod_var);
			V_4 = L_12;
			bool L_13 = TaskAwaiter_1_get_IsCompleted_m65B87815F65EECDC664D3CD37DA73A87E753258A((TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A *)(&V_4), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_m65B87815F65EECDC664D3CD37DA73A87E753258A_RuntimeMethod_var);
			if (L_13)
			{
				goto IL_0089;
			}
		}

IL_0048:
		{
			int32_t L_14 = 0;
			V_0 = L_14;
			__this->set_U3CU3E1__state_0(L_14);
			TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A  L_15 = V_4;
			__this->set_U3CU3Eu__1_4(L_15);
			AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_16 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_mC22DC39F316BF248F38A8A452016A5A992B8C5EF((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_16, (TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A *)(&V_4), (U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A_TisU3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC_mC22DC39F316BF248F38A8A452016A5A992B8C5EF_RuntimeMethod_var);
			goto IL_013d;
		}

IL_006c:
		{
			TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A  L_17 = __this->get_U3CU3Eu__1_4();
			V_4 = L_17;
			TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A * L_18 = __this->get_address_of_U3CU3Eu__1_4();
			il2cpp_codegen_initobj(L_18, sizeof(TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A ));
			int32_t L_19 = (-1);
			V_0 = L_19;
			__this->set_U3CU3E1__state_0(L_19);
		}

IL_0089:
		{
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_20 = TaskAwaiter_1_GetResult_mA33716D8F7BAE3970F8307C41CE96B2A452FCF5A((TaskAwaiter_1_t78F594F2ECA5ACE0077371E22C1F5233E063990A *)(&V_4), /*hidden argument*/TaskAwaiter_1_GetResult_mA33716D8F7BAE3970F8307C41CE96B2A452FCF5A_RuntimeMethod_var);
			V_3 = L_20;
			// if (task != taskCompletion.Task)
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_21 = V_3;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_22 = V_1;
			NullCheck(L_22);
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_23 = L_22->get_taskCompletion_5();
			NullCheck(L_23);
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_24 = TaskCompletionSource_1_get_Task_mDC9ED85B68696CD8BD9DE3A757F317BA5C6417A4_inline(L_23, /*hidden argument*/TaskCompletionSource_1_get_Task_mDC9ED85B68696CD8BD9DE3A757F317BA5C6417A4_RuntimeMethod_var);
			if ((((RuntimeObject*)(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 *)L_21) == ((RuntimeObject*)(Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA *)L_24)))
			{
				goto IL_00b5;
			}
		}

IL_009f:
		{
			// taskCompletion = new System.Threading.Tasks.TaskCompletionSource<Response>();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_25 = V_1;
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_26 = (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 *)il2cpp_codegen_object_new(TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0_il2cpp_TypeInfo_var);
			TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3(L_26, /*hidden argument*/TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3_RuntimeMethod_var);
			NullCheck(L_25);
			L_25->set_taskCompletion_5(L_26);
			// throw new TimeoutException("Timeout when receiving message.");
			TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0 * L_27 = (TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0 *)il2cpp_codegen_object_new(TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0_il2cpp_TypeInfo_var);
			TimeoutException__ctor_m2AD6BA4E69FE5415F5E571171A0346292B84E0D4(L_27, _stringLiteralE28DCD4D264C656D8E287F57412D38AB4732B1F4, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_27, U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4_RuntimeMethod_var);
		}

IL_00b5:
		{
			// if (task.Exception != null)
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_28 = V_3;
			NullCheck(L_28);
			AggregateException_t9217B9E89DF820D5632411F2BD92F444B17BD60E * L_29 = Task_get_Exception_mA61AAD3E52CBEB631D1956217B521456E7960B95(L_28, /*hidden argument*/NULL);
			if (!L_29)
			{
				goto IL_00f2;
			}
		}

IL_00bd:
		{
			// taskCompletion = new System.Threading.Tasks.TaskCompletionSource<Response>();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_30 = V_1;
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_31 = (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 *)il2cpp_codegen_object_new(TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0_il2cpp_TypeInfo_var);
			TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3(L_31, /*hidden argument*/TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3_RuntimeMethod_var);
			NullCheck(L_30);
			L_30->set_taskCompletion_5(L_31);
			// if (task.Exception.InnerException.InnerException != null)
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_32 = V_3;
			NullCheck(L_32);
			AggregateException_t9217B9E89DF820D5632411F2BD92F444B17BD60E * L_33 = Task_get_Exception_mA61AAD3E52CBEB631D1956217B521456E7960B95(L_32, /*hidden argument*/NULL);
			NullCheck(L_33);
			Exception_t * L_34 = Exception_get_InnerException_mCB68CC8CBF2540EF381CB17A4E4E3F6D0E33453F_inline(L_33, /*hidden argument*/NULL);
			NullCheck(L_34);
			Exception_t * L_35 = Exception_get_InnerException_mCB68CC8CBF2540EF381CB17A4E4E3F6D0E33453F_inline(L_34, /*hidden argument*/NULL);
			if (!L_35)
			{
				goto IL_00eb;
			}
		}

IL_00da:
		{
			// throw task.Exception.InnerException.InnerException;
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_36 = V_3;
			NullCheck(L_36);
			AggregateException_t9217B9E89DF820D5632411F2BD92F444B17BD60E * L_37 = Task_get_Exception_mA61AAD3E52CBEB631D1956217B521456E7960B95(L_36, /*hidden argument*/NULL);
			NullCheck(L_37);
			Exception_t * L_38 = Exception_get_InnerException_mCB68CC8CBF2540EF381CB17A4E4E3F6D0E33453F_inline(L_37, /*hidden argument*/NULL);
			NullCheck(L_38);
			Exception_t * L_39 = Exception_get_InnerException_mCB68CC8CBF2540EF381CB17A4E4E3F6D0E33453F_inline(L_38, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_39, U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4_RuntimeMethod_var);
		}

IL_00eb:
		{
			// throw task.Exception;
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_40 = V_3;
			NullCheck(L_40);
			AggregateException_t9217B9E89DF820D5632411F2BD92F444B17BD60E * L_41 = Task_get_Exception_mA61AAD3E52CBEB631D1956217B521456E7960B95(L_40, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_41, U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4_RuntimeMethod_var);
		}

IL_00f2:
		{
			// var result = taskCompletion.Task.Result;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_42 = V_1;
			NullCheck(L_42);
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_43 = L_42->get_taskCompletion_5();
			NullCheck(L_43);
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_44 = TaskCompletionSource_1_get_Task_mDC9ED85B68696CD8BD9DE3A757F317BA5C6417A4_inline(L_43, /*hidden argument*/TaskCompletionSource_1_get_Task_mDC9ED85B68696CD8BD9DE3A757F317BA5C6417A4_RuntimeMethod_var);
			NullCheck(L_44);
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_45 = Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876(L_44, /*hidden argument*/Task_1_get_Result_m29CF4955444AD6763FF7AEE7FF56CFD91C801876_RuntimeMethod_var);
			// taskCompletion = new System.Threading.Tasks.TaskCompletionSource<Response>();
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_46 = V_1;
			TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 * L_47 = (TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0 *)il2cpp_codegen_object_new(TaskCompletionSource_1_tA8AC3BF989CCB673267BC80213062ADFA5AA11B0_il2cpp_TypeInfo_var);
			TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3(L_47, /*hidden argument*/TaskCompletionSource_1__ctor_mE2D48FBB4FC0F09ED0BB28C9A64F6488744B64A3_RuntimeMethod_var);
			NullCheck(L_46);
			L_46->set_taskCompletion_5(L_47);
			// return result;
			V_2 = L_45;
			goto IL_0129;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_0110;
		throw e;
	}

CATCH_0110:
	{ // begin catch(System.Exception)
		V_5 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_48 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_49 = V_5;
		AsyncTaskMethodBuilder_1_SetException_m89F128C1E1A0F0E16A1FFA86AD6A96E8997DB857((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_48, L_49, /*hidden argument*/AsyncTaskMethodBuilder_1_SetException_m89F128C1E1A0F0E16A1FFA86AD6A96E8997DB857_RuntimeMethod_var);
		goto IL_013d;
	} // end catch (depth: 1)

IL_0129:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_50 = __this->get_address_of_U3CU3Et__builder_1();
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_51 = V_2;
		AsyncTaskMethodBuilder_1_SetResult_m013485E27C036058F955FBFB38CB72C8390A9C92((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_50, L_51, /*hidden argument*/AsyncTaskMethodBuilder_1_SetResult_m013485E27C036058F955FBFB38CB72C8390A9C92_RuntimeMethod_var);
	}

IL_013d:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * _thisAdjusted = reinterpret_cast<U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC *>(__this + _offset);
	U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4(_thisAdjusted, method);
}
// System.Void Wamp_<Receive>d__25::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveU3Ed__25_SetStateMachine_m1DFEA710015A7E2BA876C1837E14781B6BC5E68F (U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CReceiveU3Ed__25_SetStateMachine_m1DFEA710015A7E2BA876C1837E14781B6BC5E68F_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_1_SetStateMachine_m5EF4BCC5A6E298F61AF578E53EAF3AD0FEE6C5D3((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_0, L_1, /*hidden argument*/AsyncTaskMethodBuilder_1_SetStateMachine_m5EF4BCC5A6E298F61AF578E53EAF3AD0FEE6C5D3_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CReceiveU3Ed__25_SetStateMachine_m1DFEA710015A7E2BA876C1837E14781B6BC5E68F_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC * _thisAdjusted = reinterpret_cast<U3CReceiveU3Ed__25_t36E456B8A0D32D9F8BE586764E1CF796D00F59CC *>(__this + _offset);
	U3CReceiveU3Ed__25_SetStateMachine_m1DFEA710015A7E2BA876C1837E14781B6BC5E68F(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<ReceiveExpect>d__26::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0 (U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * V_1 = NULL;
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * V_2 = NULL;
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  V_3;
	memset((&V_3), 0, sizeof(V_3));
	Exception_t * V_4 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 3);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * G_B7_0 = NULL;
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * G_B6_0 = NULL;
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * G_B9_0 = NULL;
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * G_B8_0 = NULL;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_004f;
			}
		}

IL_0011:
		{
			// Response response = await Receive(timeout);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_3 = V_1;
			int32_t L_4 = __this->get_timeout_3();
			NullCheck(L_3);
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_5 = Wamp_Receive_m7B47E5C25B601C3C446B02A97117ACAA3FA3BF13(L_3, L_4, /*hidden argument*/NULL);
			NullCheck(L_5);
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_6 = Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3(L_5, /*hidden argument*/Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3_RuntimeMethod_var);
			V_3 = L_6;
			bool L_7 = TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_3), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E_RuntimeMethod_var);
			if (L_7)
			{
				goto IL_006b;
			}
		}

IL_002c:
		{
			int32_t L_8 = 0;
			V_0 = L_8;
			__this->set_U3CU3E1__state_0(L_8);
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_9 = V_3;
			__this->set_U3CU3Eu__1_6(L_9);
			AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_10 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m2EB1C430D6D5413CB1A2A876F98D2F34F4C9BEF3((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_10, (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_3), (U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F_m2EB1C430D6D5413CB1A2A876F98D2F34F4C9BEF3_RuntimeMethod_var);
			goto IL_0100;
		}

IL_004f:
		{
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_11 = __this->get_U3CU3Eu__1_6();
			V_3 = L_11;
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * L_12 = __this->get_address_of_U3CU3Eu__1_6();
			il2cpp_codegen_initobj(L_12, sizeof(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 ));
			int32_t L_13 = (-1);
			V_0 = L_13;
			__this->set_U3CU3E1__state_0(L_13);
		}

IL_006b:
		{
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_14 = TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_3), /*hidden argument*/TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50_RuntimeMethod_var);
			// if (response.MessageId != message)
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_15 = L_14;
			NullCheck(L_15);
			int32_t L_16 = Response_get_MessageId_mC397D82D70FC4A2DC73186D1CADF3ADF34CEE0D7_inline(L_15, /*hidden argument*/NULL);
			int32_t L_17 = __this->get_message_4();
			G_B6_0 = L_15;
			if ((((int32_t)L_16) == ((int32_t)L_17)))
			{
				G_B7_0 = L_15;
				goto IL_00a1;
			}
		}

IL_0080:
		{
			// throw new ErrorException($"{message.ToString()}: invalid response. Did not receive expected answer.");
			int32_t* L_18 = __this->get_address_of_message_4();
			RuntimeObject * L_19 = Box(Messages_tD25B555D7E0152EFD72FB82E6E3843CCCDA276B3_il2cpp_TypeInfo_var, L_18);
			NullCheck(L_19);
			String_t* L_20 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_19);
			*L_18 = *(int32_t*)UnBox(L_19);
			String_t* L_21 = String_Concat_mB78D0094592718DA6D5DB6C712A9C225631666BE(L_20, _stringLiteral7B7C3753BD237A59A89DDD31B04B4253900F7101, /*hidden argument*/NULL);
			ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_22 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
			ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_22, L_21, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_22, U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0_RuntimeMethod_var);
		}

IL_00a1:
		{
			// if (response.RequestId != requestId)
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_23 = G_B7_0;
			NullCheck(L_23);
			int32_t L_24 = Response_get_RequestId_m839528D15AAC4BC39EAEB22669F38B75140A0C05_inline(L_23, /*hidden argument*/NULL);
			int32_t L_25 = __this->get_requestId_5();
			G_B8_0 = L_23;
			if ((((int32_t)L_24) == ((int32_t)L_25)))
			{
				G_B9_0 = L_23;
				goto IL_00d0;
			}
		}

IL_00af:
		{
			// throw new ErrorException($"{message.ToString()}: invalid request id for result.");
			int32_t* L_26 = __this->get_address_of_message_4();
			RuntimeObject * L_27 = Box(Messages_tD25B555D7E0152EFD72FB82E6E3843CCCDA276B3_il2cpp_TypeInfo_var, L_26);
			NullCheck(L_27);
			String_t* L_28 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_27);
			*L_26 = *(int32_t*)UnBox(L_27);
			String_t* L_29 = String_Concat_mB78D0094592718DA6D5DB6C712A9C225631666BE(L_28, _stringLiteralF4BB5287F1F7F06D43442AB7E16E48611FEF2CA7, /*hidden argument*/NULL);
			ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_30 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
			ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_30, L_29, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_30, U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0_RuntimeMethod_var);
		}

IL_00d0:
		{
			// return response;
			V_2 = G_B9_0;
			goto IL_00ec;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_00d3;
		throw e;
	}

CATCH_00d3:
	{ // begin catch(System.Exception)
		V_4 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_31 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_32 = V_4;
		AsyncTaskMethodBuilder_1_SetException_m89F128C1E1A0F0E16A1FFA86AD6A96E8997DB857((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_31, L_32, /*hidden argument*/AsyncTaskMethodBuilder_1_SetException_m89F128C1E1A0F0E16A1FFA86AD6A96E8997DB857_RuntimeMethod_var);
		goto IL_0100;
	} // end catch (depth: 1)

IL_00ec:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_33 = __this->get_address_of_U3CU3Et__builder_1();
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_34 = V_2;
		AsyncTaskMethodBuilder_1_SetResult_m013485E27C036058F955FBFB38CB72C8390A9C92((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_33, L_34, /*hidden argument*/AsyncTaskMethodBuilder_1_SetResult_m013485E27C036058F955FBFB38CB72C8390A9C92_RuntimeMethod_var);
	}

IL_0100:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * _thisAdjusted = reinterpret_cast<U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F *>(__this + _offset);
	U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0(_thisAdjusted, method);
}
// System.Void Wamp_<ReceiveExpect>d__26::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveExpectU3Ed__26_SetStateMachine_mFDCB7BA62E930894AC2A0A7A5100EE36A256FD7B (U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CReceiveExpectU3Ed__26_SetStateMachine_mFDCB7BA62E930894AC2A0A7A5100EE36A256FD7B_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_1_SetStateMachine_m5EF4BCC5A6E298F61AF578E53EAF3AD0FEE6C5D3((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_0, L_1, /*hidden argument*/AsyncTaskMethodBuilder_1_SetStateMachine_m5EF4BCC5A6E298F61AF578E53EAF3AD0FEE6C5D3_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CReceiveExpectU3Ed__26_SetStateMachine_mFDCB7BA62E930894AC2A0A7A5100EE36A256FD7B_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F * _thisAdjusted = reinterpret_cast<U3CReceiveExpectU3Ed__26_t4C27E0EBBEF92B46E3408444B8FF6BB63F858F2F *>(__this + _offset);
	U3CReceiveExpectU3Ed__26_SetStateMachine_mFDCB7BA62E930894AC2A0A7A5100EE36A256FD7B(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<ReceiveMessage>d__24::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F (U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * V_1 = NULL;
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * V_2 = NULL;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_3 = NULL;
	WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * V_4 = NULL;
	TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD  V_5;
	memset((&V_5), 0, sizeof(V_5));
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_6 = NULL;
	String_t* V_7 = NULL;
	Exception_t * V_8 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 4);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * G_B16_0 = NULL;
	List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * G_B16_1 = NULL;
	Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * G_B15_0 = NULL;
	List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * G_B15_1 = NULL;
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_001c;
			}
		}

IL_0011:
		{
			// System.Collections.Generic.List<System.Collections.Generic.IEnumerable<byte>> segments = new System.Collections.Generic.List<System.Collections.Generic.IEnumerable<byte>>();
			List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * L_3 = (List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 *)il2cpp_codegen_object_new(List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814_il2cpp_TypeInfo_var);
			List_1__ctor_mB7D4AB3F605E57A961003A9975A9DD9E3023B769(L_3, /*hidden argument*/List_1__ctor_mB7D4AB3F605E57A961003A9975A9DD9E3023B769_RuntimeMethod_var);
			__this->set_U3CsegmentsU3E5__2_3(L_3);
		}

IL_001c:
		{
		}

IL_001d:
		try
		{ // begin try (depth: 2)
			{
				int32_t L_4 = V_0;
				if (!L_4)
				{
					goto IL_008b;
				}
			}

IL_0020:
			{
				// byte[] buffer = new byte[4096];
				ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_5 = (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*)(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*)SZArrayNew(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821_il2cpp_TypeInfo_var, (uint32_t)((int32_t)4096));
				V_3 = L_5;
				// var segment = new System.ArraySegment<byte>(buffer, 0, buffer.Length);
				ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_6 = V_3;
				ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_7 = V_3;
				NullCheck(L_7);
				ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA  L_8;
				memset((&L_8), 0, sizeof(L_8));
				ArraySegment_1__ctor_m6305655CDE2F6E154BA79003B66CF61795462804((&L_8), L_6, 0, (((int32_t)((int32_t)(((RuntimeArray*)L_7)->max_length)))), /*hidden argument*/ArraySegment_1__ctor_m6305655CDE2F6E154BA79003B66CF61795462804_RuntimeMethod_var);
				__this->set_U3CsegmentU3E5__3_4(L_8);
				// System.Net.WebSockets.WebSocketReceiveResult rcvResult = await ws.ReceiveAsync(segment, stopServerTokenSource.Token);
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_9 = V_1;
				NullCheck(L_9);
				ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_10 = L_9->get_ws_1();
				ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA  L_11 = __this->get_U3CsegmentU3E5__3_4();
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_12 = V_1;
				NullCheck(L_12);
				CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_13 = L_12->get_stopServerTokenSource_4();
				NullCheck(L_13);
				CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  L_14 = CancellationTokenSource_get_Token_mBB578AFC3DB427E263C966B2DCA86E6ED1CCBC9B(L_13, /*hidden argument*/NULL);
				NullCheck(L_10);
				Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F * L_15 = VirtFuncInvoker2< Task_1_t9EB2B802BED2EDEB5CD1C5EB0198026B2540B45F *, ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA , CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  >::Invoke(9 /* System.Threading.Tasks.Task`1<System.Net.WebSockets.WebSocketReceiveResult> System.Net.WebSockets.WebSocket::ReceiveAsync(System.ArraySegment`1<System.Byte>,System.Threading.CancellationToken) */, L_10, L_11, L_14);
				NullCheck(L_15);
				TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD  L_16 = Task_1_GetAwaiter_mAFED2623EE194913D17CD104EE32E077A0BD324E(L_15, /*hidden argument*/Task_1_GetAwaiter_mAFED2623EE194913D17CD104EE32E077A0BD324E_RuntimeMethod_var);
				V_5 = L_16;
				bool L_17 = TaskAwaiter_1_get_IsCompleted_mBD5D88440DBE5104B7AEF7A11D549FE39008740D((TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD *)(&V_5), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_mBD5D88440DBE5104B7AEF7A11D549FE39008740D_RuntimeMethod_var);
				if (L_17)
				{
					goto IL_00a8;
				}
			}

IL_0067:
			{
				int32_t L_18 = 0;
				V_0 = L_18;
				__this->set_U3CU3E1__state_0(L_18);
				TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD  L_19 = V_5;
				__this->set_U3CU3Eu__1_5(L_19);
				AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_20 = __this->get_address_of_U3CU3Et__builder_1();
				AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_mA44D0B4B5FB1613D34ACD01F6D6F1E99E95AD4C8((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_20, (TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD *)(&V_5), (U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD_TisU3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C_mA44D0B4B5FB1613D34ACD01F6D6F1E99E95AD4C8_RuntimeMethod_var);
				goto IL_0196;
			}

IL_008b:
			{
				TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD  L_21 = __this->get_U3CU3Eu__1_5();
				V_5 = L_21;
				TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD * L_22 = __this->get_address_of_U3CU3Eu__1_5();
				il2cpp_codegen_initobj(L_22, sizeof(TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD ));
				int32_t L_23 = (-1);
				V_0 = L_23;
				__this->set_U3CU3E1__state_0(L_23);
			}

IL_00a8:
			{
				WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * L_24 = TaskAwaiter_1_GetResult_m814E69FC46668F93FB02713896269AAACBD01F06((TaskAwaiter_1_tF50D2557A14EF69F6DCBC217F906947C920A6DDD *)(&V_5), /*hidden argument*/TaskAwaiter_1_GetResult_m814E69FC46668F93FB02713896269AAACBD01F06_RuntimeMethod_var);
				V_4 = L_24;
				// segments.Add(segment.Skip(segment.Offset).Take(rcvResult.Count));
				List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * L_25 = __this->get_U3CsegmentsU3E5__2_3();
				ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA  L_26 = __this->get_U3CsegmentU3E5__3_4();
				ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA  L_27 = L_26;
				RuntimeObject * L_28 = Box(ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA_il2cpp_TypeInfo_var, &L_27);
				ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * L_29 = __this->get_address_of_U3CsegmentU3E5__3_4();
				int32_t L_30 = ArraySegment_1_get_Offset_m6651443913CC50A02AE5D7C4CDC6F6744D39B483_inline((ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA *)L_29, /*hidden argument*/ArraySegment_1_get_Offset_m6651443913CC50A02AE5D7C4CDC6F6744D39B483_RuntimeMethod_var);
				RuntimeObject* L_31 = Enumerable_Skip_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m73025D0C956827AA7A6EA962A50C8B63F69FBBBE((RuntimeObject*)L_28, L_30, /*hidden argument*/Enumerable_Skip_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m73025D0C956827AA7A6EA962A50C8B63F69FBBBE_RuntimeMethod_var);
				WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * L_32 = V_4;
				NullCheck(L_32);
				int32_t L_33 = WebSocketReceiveResult_get_Count_m2C308CD164D4199DACE7613DC7E8DC1F5E66DF65_inline(L_32, /*hidden argument*/NULL);
				RuntimeObject* L_34 = Enumerable_Take_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_mFBC4D57366E255AFC2F139800ABAD01A519B2B05(L_31, L_33, /*hidden argument*/Enumerable_Take_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_mFBC4D57366E255AFC2F139800ABAD01A519B2B05_RuntimeMethod_var);
				NullCheck(L_25);
				List_1_Add_m4454ADA74D82DCE063A15F0A54CE55D3CDFAA382(L_25, L_34, /*hidden argument*/List_1_Add_m4454ADA74D82DCE063A15F0A54CE55D3CDFAA382_RuntimeMethod_var);
				// if (rcvResult.EndOfMessage)
				WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * L_35 = V_4;
				NullCheck(L_35);
				bool L_36 = WebSocketReceiveResult_get_EndOfMessage_m18C6588C6F9FC235BEC84AA7572B7F49C5E6BEB9_inline(L_35, /*hidden argument*/NULL);
				if (L_36)
				{
					goto IL_00fd;
				}
			}

IL_00ec:
			{
				// }
				ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * L_37 = __this->get_address_of_U3CsegmentU3E5__3_4();
				il2cpp_codegen_initobj(L_37, sizeof(ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA ));
				// while (true)
				goto IL_0020;
			}

IL_00fd:
			{
				// }
				goto IL_0111;
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			__exception_local = (Exception_t *)e.ex;
			if(il2cpp_codegen_class_is_assignable_from (WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
				goto CATCH_00ff;
			if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
				goto CATCH_0105;
			throw e;
		}

CATCH_00ff:
		{ // begin catch(System.Net.WebSockets.WebSocketException)
			// throw e.InnerException;
			NullCheck(((WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B *)__exception_local));
			Exception_t * L_38 = Exception_get_InnerException_mCB68CC8CBF2540EF381CB17A4E4E3F6D0E33453F_inline(((WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B *)__exception_local), /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_38, U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_RuntimeMethod_var);
		} // end catch (depth: 2)

CATCH_0105:
		{ // begin catch(System.Exception)
			// catch (System.Exception)
			// throw new ErrorException("Error receiving response from server.");
			ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_39 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
			ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_39, _stringLiteralA75543DB956397B3AAF3798633E311C2C2352857, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_39, U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_RuntimeMethod_var);
		} // end catch (depth: 2)

IL_0111:
		{
		}

IL_0112:
		try
		{ // begin try (depth: 2)
			{
				// byte[] bytes = segments.SelectMany(t => t).ToArray<byte>();
				List_1_tFD0346BF78E1559BAEE54A2E5DB501EC5B13C814 * L_40 = __this->get_U3CsegmentsU3E5__2_3();
				IL2CPP_RUNTIME_CLASS_INIT(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_il2cpp_TypeInfo_var);
				Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * L_41 = ((U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_il2cpp_TypeInfo_var))->get_U3CU3E9__24_0_1();
				Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * L_42 = L_41;
				G_B15_0 = L_42;
				G_B15_1 = L_40;
				if (L_42)
				{
					G_B16_0 = L_42;
					G_B16_1 = L_40;
					goto IL_0137;
				}
			}

IL_0120:
			{
				IL2CPP_RUNTIME_CLASS_INIT(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_il2cpp_TypeInfo_var);
				U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7 * L_43 = ((U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_il2cpp_TypeInfo_var))->get_U3CU3E9_0();
				Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * L_44 = (Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 *)il2cpp_codegen_object_new(Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094_il2cpp_TypeInfo_var);
				Func_2__ctor_m71F83ACB080E1E97771766B7F659BD1B091831B7(L_44, L_43, (intptr_t)((intptr_t)U3CU3Ec_U3CReceiveMessageU3Eb__24_0_m239F0211E8D016A1ACCFF6005B536DECEE383B10_RuntimeMethod_var), /*hidden argument*/Func_2__ctor_m71F83ACB080E1E97771766B7F659BD1B091831B7_RuntimeMethod_var);
				Func_2_tF95A6F56041B30B8DC36B4D886E0DA94022A6094 * L_45 = L_44;
				((U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_t9671D3F2C6ED7965EEC137C4FFC60F398D9A65E7_il2cpp_TypeInfo_var))->set_U3CU3E9__24_0_1(L_45);
				G_B16_0 = L_45;
				G_B16_1 = G_B15_1;
			}

IL_0137:
			{
				RuntimeObject* L_46 = Enumerable_SelectMany_TisIEnumerable_1_t5A38FCC3E9F64286F2A624D6571AF9EA7844398E_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m90F6F46EB605689C56C3A8F2667983FB5C70265A(G_B16_1, G_B16_0, /*hidden argument*/Enumerable_SelectMany_TisIEnumerable_1_t5A38FCC3E9F64286F2A624D6571AF9EA7844398E_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m90F6F46EB605689C56C3A8F2667983FB5C70265A_RuntimeMethod_var);
				ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_47 = Enumerable_ToArray_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m48AFCA8923688797114AA384B978E290AAAF206B(L_46, /*hidden argument*/Enumerable_ToArray_TisByte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_m48AFCA8923688797114AA384B978E290AAAF206B_RuntimeMethod_var);
				V_6 = L_47;
				// string msg = System.Text.Encoding.UTF8.GetString(bytes);
				Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_48 = Encoding_get_UTF8_m67C8652936B681E7BC7505E459E88790E0FF16D9(/*hidden argument*/NULL);
				ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_49 = V_6;
				NullCheck(L_48);
				String_t* L_50 = VirtFuncInvoker1< String_t*, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* >::Invoke(31 /* System.String System.Text.Encoding::GetString(System.Byte[]) */, L_48, L_49);
				V_7 = L_50;
				// return Parse(msg);
				Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_51 = V_1;
				String_t* L_52 = V_7;
				NullCheck(L_51);
				Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_53 = Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A(L_51, L_52, /*hidden argument*/NULL);
				V_2 = L_53;
				goto IL_0182;
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			__exception_local = (Exception_t *)e.ex;
			if(il2cpp_codegen_class_is_assignable_from (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
				goto CATCH_015c;
			if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
				goto CATCH_015d;
			throw e;
		}

CATCH_015c:
		{ // begin catch(Wamp/ErrorException)
			// throw e;
			IL2CPP_RAISE_MANAGED_EXCEPTION(((ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)__exception_local), U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_RuntimeMethod_var);
		} // end catch (depth: 2)

CATCH_015d:
		{ // begin catch(System.Exception)
			// catch (System.Exception)
			// throw new ErrorException("Error while parsing response from server.");
			ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_54 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
			ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_54, _stringLiteral1100C278A2149AE25E6C9D115CC40383875DA328, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_54, U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_RuntimeMethod_var);
		} // end catch (depth: 2)
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_0169;
		throw e;
	}

CATCH_0169:
	{ // begin catch(System.Exception)
		V_8 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_55 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_56 = V_8;
		AsyncTaskMethodBuilder_1_SetException_m89F128C1E1A0F0E16A1FFA86AD6A96E8997DB857((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_55, L_56, /*hidden argument*/AsyncTaskMethodBuilder_1_SetException_m89F128C1E1A0F0E16A1FFA86AD6A96E8997DB857_RuntimeMethod_var);
		goto IL_0196;
	} // end catch (depth: 1)

IL_0182:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_57 = __this->get_address_of_U3CU3Et__builder_1();
		Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_58 = V_2;
		AsyncTaskMethodBuilder_1_SetResult_m013485E27C036058F955FBFB38CB72C8390A9C92((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_57, L_58, /*hidden argument*/AsyncTaskMethodBuilder_1_SetResult_m013485E27C036058F955FBFB38CB72C8390A9C92_RuntimeMethod_var);
	}

IL_0196:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * _thisAdjusted = reinterpret_cast<U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C *>(__this + _offset);
	U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F(_thisAdjusted, method);
}
// System.Void Wamp_<ReceiveMessage>d__24::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReceiveMessageU3Ed__24_SetStateMachine_m1A3F556E61365751BF72BC7C8C95F8DEDBF12C3C (U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CReceiveMessageU3Ed__24_SetStateMachine_m1A3F556E61365751BF72BC7C8C95F8DEDBF12C3C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_1_SetStateMachine_m5EF4BCC5A6E298F61AF578E53EAF3AD0FEE6C5D3((AsyncTaskMethodBuilder_1_t3288E5DB4601D7E46EE8411E8A123139A5A881AD *)L_0, L_1, /*hidden argument*/AsyncTaskMethodBuilder_1_SetStateMachine_m5EF4BCC5A6E298F61AF578E53EAF3AD0FEE6C5D3_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CReceiveMessageU3Ed__24_SetStateMachine_m1A3F556E61365751BF72BC7C8C95F8DEDBF12C3C_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C * _thisAdjusted = reinterpret_cast<U3CReceiveMessageU3Ed__24_tACFC8662D81FABE2DDB02DB65B279A95D191066C *>(__this + _offset);
	U3CReceiveMessageU3Ed__24_SetStateMachine_m1A3F556E61365751BF72BC7C8C95F8DEDBF12C3C(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<Send>d__16::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72 (U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * V_1 = NULL;
	ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA  V_2;
	memset((&V_2), 0, sizeof(V_2));
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  V_3;
	memset((&V_3), 0, sizeof(V_3));
	Exception_t * V_4 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 5);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_4();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
		}

IL_0011:
		try
		{ // begin try (depth: 2)
			{
				int32_t L_3 = V_0;
				if (!L_3)
				{
					goto IL_0025;
				}
			}

IL_0014:
			{
				// using (var cts = new System.Threading.CancellationTokenSource(timeout))
				int32_t L_4 = __this->get_timeout_2();
				CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_5 = (CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE *)il2cpp_codegen_object_new(CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE_il2cpp_TypeInfo_var);
				CancellationTokenSource__ctor_m282A9AF96A92487F7B0B391F00F3083C1832A53F(L_5, L_4, /*hidden argument*/NULL);
				__this->set_U3CctsU3E5__2_5(L_5);
			}

IL_0025:
			{
			}

IL_0026:
			try
			{ // begin try (depth: 3)
				{
					int32_t L_6 = V_0;
					if (!L_6)
					{
						goto IL_008b;
					}
				}

IL_0029:
				{
					// var segment = new System.ArraySegment<byte>(System.Text.Encoding.UTF8.GetBytes(msg));
					Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_7 = Encoding_get_UTF8_m67C8652936B681E7BC7505E459E88790E0FF16D9(/*hidden argument*/NULL);
					String_t* L_8 = __this->get_msg_3();
					NullCheck(L_7);
					ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_9 = VirtFuncInvoker1< ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*, String_t* >::Invoke(15 /* System.Byte[] System.Text.Encoding::GetBytes(System.String) */, L_7, L_8);
					ArraySegment_1__ctor_mC699D21C137279D4D9A501143A898CCB0971D382((ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA *)(&V_2), L_9, /*hidden argument*/ArraySegment_1__ctor_mC699D21C137279D4D9A501143A898CCB0971D382_RuntimeMethod_var);
					// await ws.SendAsync(segment, System.Net.WebSockets.WebSocketMessageType.Text, true, cts.Token);
					Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_10 = V_1;
					NullCheck(L_10);
					ClientWebSocket_tEB832A5CAA8600CAB37CAEF611D75335E4ECCC90 * L_11 = L_10->get_ws_1();
					ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA  L_12 = V_2;
					CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_13 = __this->get_U3CctsU3E5__2_5();
					NullCheck(L_13);
					CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  L_14 = CancellationTokenSource_get_Token_mBB578AFC3DB427E263C966B2DCA86E6ED1CCBC9B(L_13, /*hidden argument*/NULL);
					NullCheck(L_11);
					Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_15 = VirtFuncInvoker4< Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 *, ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA , int32_t, bool, CancellationToken_t9E956952F7F20908F2AE72EDF36D97E6C7DB63AB  >::Invoke(10 /* System.Threading.Tasks.Task System.Net.WebSockets.WebSocket::SendAsync(System.ArraySegment`1<System.Byte>,System.Net.WebSockets.WebSocketMessageType,System.Boolean,System.Threading.CancellationToken) */, L_11, L_12, 0, (bool)1, L_14);
					NullCheck(L_15);
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_16 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_15, /*hidden argument*/NULL);
					V_3 = L_16;
					bool L_17 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_3), /*hidden argument*/NULL);
					if (L_17)
					{
						goto IL_00a7;
					}
				}

IL_0068:
				{
					int32_t L_18 = 0;
					V_0 = L_18;
					__this->set_U3CU3E1__state_0(L_18);
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_19 = V_3;
					__this->set_U3CU3Eu__1_6(L_19);
					AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_20 = __this->get_address_of_U3CU3Et__builder_1();
					AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m0996EC60B40B2090B23E54881415F88FBE155480((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_20, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_3), (U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A_m0996EC60B40B2090B23E54881415F88FBE155480_RuntimeMethod_var);
					IL2CPP_LEAVE(0x10B, FINALLY_00b0);
				}

IL_008b:
				{
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_21 = __this->get_U3CU3Eu__1_6();
					V_3 = L_21;
					TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_22 = __this->get_address_of_U3CU3Eu__1_6();
					il2cpp_codegen_initobj(L_22, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
					int32_t L_23 = (-1);
					V_0 = L_23;
					__this->set_U3CU3E1__state_0(L_23);
				}

IL_00a7:
				{
					TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_3), /*hidden argument*/NULL);
					// }
					IL2CPP_LEAVE(0xC8, FINALLY_00b0);
				}
			} // end try (depth: 3)
			catch(Il2CppExceptionWrapper& e)
			{
				__last_unhandled_exception = (Exception_t *)e.ex;
				goto FINALLY_00b0;
			}

FINALLY_00b0:
			{ // begin finally (depth: 3)
				{
					int32_t L_24 = V_0;
					if ((((int32_t)L_24) >= ((int32_t)0)))
					{
						goto IL_00c7;
					}
				}

IL_00b4:
				{
					CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_25 = __this->get_U3CctsU3E5__2_5();
					if (!L_25)
					{
						goto IL_00c7;
					}
				}

IL_00bc:
				{
					CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE * L_26 = __this->get_U3CctsU3E5__2_5();
					NullCheck(L_26);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_26);
				}

IL_00c7:
				{
					IL2CPP_END_FINALLY(176)
				}
			} // end finally (depth: 3)
			IL2CPP_CLEANUP(176)
			{
				IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
				IL2CPP_JUMP_TBL(0x10B, IL_010b)
				IL2CPP_JUMP_TBL(0xC8, IL_00c8)
			}

IL_00c8:
			{
				__this->set_U3CctsU3E5__2_5((CancellationTokenSource_tF480B7E74A032667AFBD31F0530D619FB43AD3FE *)NULL);
				// }
				goto IL_00dd;
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			__exception_local = (Exception_t *)e.ex;
			if(il2cpp_codegen_class_is_assignable_from (TaskCanceledException_tB1E5209054F302F814E18BBCACDF6546BAF2EC48_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
				goto CATCH_00d1;
			throw e;
		}

CATCH_00d1:
		{ // begin catch(System.Threading.Tasks.TaskCanceledException)
			// catch (System.Threading.Tasks.TaskCanceledException)
			// throw new TimeoutException("Timeout when sending message.");
			TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0 * L_27 = (TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0 *)il2cpp_codegen_object_new(TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0_il2cpp_TypeInfo_var);
			TimeoutException__ctor_m2AD6BA4E69FE5415F5E571171A0346292B84E0D4(L_27, _stringLiteral0EE291B9316432879664DDEFE015DA3D0D04C664, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_27, U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72_RuntimeMethod_var);
		} // end catch (depth: 2)

IL_00dd:
		{
			goto IL_00f8;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_00df;
		throw e;
	}

CATCH_00df:
	{ // begin catch(System.Exception)
		V_4 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_28 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_29 = V_4;
		AsyncTaskMethodBuilder_SetException_m370C484922A63A6EF96E241D1370B8814F1F2D6B((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_28, L_29, /*hidden argument*/NULL);
		goto IL_010b;
	} // end catch (depth: 1)

IL_00f8:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_30 = __this->get_address_of_U3CU3Et__builder_1();
		AsyncTaskMethodBuilder_SetResult_m151016FB698F3BB34A73BAE693A97513A7E4C838((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_30, /*hidden argument*/NULL);
	}

IL_010b:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * _thisAdjusted = reinterpret_cast<U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A *>(__this + _offset);
	U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72(_thisAdjusted, method);
}
// System.Void Wamp_<Send>d__16::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSendU3Ed__16_SetStateMachine_m5303935E88DD68C4A40AEDBFCDF18F8DEA84E31B (U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	{
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_SetStateMachine_mB5DD68F7C49EA6D452AEBA02B1B98AED898C3C25((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CSendU3Ed__16_SetStateMachine_m5303935E88DD68C4A40AEDBFCDF18F8DEA84E31B_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A * _thisAdjusted = reinterpret_cast<U3CSendU3Ed__16_tBBB68F0E4657077C52977495C518A995A5C0558A *>(__this + _offset);
	U3CSendU3Ed__16_SetStateMachine_m5303935E88DD68C4A40AEDBFCDF18F8DEA84E31B(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<Subscribe>d__35::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSubscribeU3Ed__35_MoveNext_m871F84E5292DE81E13BE9C94AB0EA8765E1D5285 (U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CSubscribeU3Ed__35_MoveNext_m871F84E5292DE81E13BE9C94AB0EA8765E1D5285_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * V_1 = NULL;
	uint32_t V_2 = 0;
	Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * V_3 = NULL;
	int32_t V_4 = 0;
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  V_5;
	memset((&V_5), 0, sizeof(V_5));
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  V_6;
	memset((&V_6), 0, sizeof(V_6));
	Exception_t * V_7 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 4);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_00af;
			}
		}

IL_0014:
		{
			int32_t L_3 = V_0;
			if ((((int32_t)L_3) == ((int32_t)1)))
			{
				goto IL_0118;
			}
		}

IL_001b:
		{
			// int requestId = ++currentRequestId;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_4 = V_1;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_5 = V_1;
			NullCheck(L_5);
			int32_t L_6 = L_5->get_currentRequestId_3();
			V_4 = ((int32_t)il2cpp_codegen_add((int32_t)L_6, (int32_t)1));
			int32_t L_7 = V_4;
			NullCheck(L_4);
			L_4->set_currentRequestId_3(L_7);
			int32_t L_8 = V_4;
			__this->set_U3CrequestIdU3E5__2_7(L_8);
			// await Send($"[{(int)Messages.SUBSCRIBE},{requestId},{options},\"{topic}\"]", timeout);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_9 = V_1;
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_10 = (ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A*)(ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A*)SZArrayNew(ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A_il2cpp_TypeInfo_var, (uint32_t)4);
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_11 = L_10;
			int32_t L_12 = ((int32_t)32);
			RuntimeObject * L_13 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_12);
			NullCheck(L_11);
			ArrayElementTypeCheck (L_11, L_13);
			(L_11)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_13);
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_14 = L_11;
			int32_t L_15 = __this->get_U3CrequestIdU3E5__2_7();
			int32_t L_16 = L_15;
			RuntimeObject * L_17 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_16);
			NullCheck(L_14);
			ArrayElementTypeCheck (L_14, L_17);
			(L_14)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_17);
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_18 = L_14;
			String_t* L_19 = __this->get_options_3();
			NullCheck(L_18);
			ArrayElementTypeCheck (L_18, L_19);
			(L_18)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_19);
			ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* L_20 = L_18;
			String_t* L_21 = __this->get_topic_4();
			NullCheck(L_20);
			ArrayElementTypeCheck (L_20, L_21);
			(L_20)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_21);
			String_t* L_22 = String_Format_mA3AC3FE7B23D97F3A5BAA082D25B0E01B341A865(_stringLiteral81A699D4D87542144D512C24A1862E6E0C575602, L_20, /*hidden argument*/NULL);
			int32_t L_23 = __this->get_timeout_5();
			NullCheck(L_9);
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_24 = Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591(L_9, L_22, L_23, /*hidden argument*/NULL);
			NullCheck(L_24);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_25 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_24, /*hidden argument*/NULL);
			V_5 = L_25;
			bool L_26 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_5), /*hidden argument*/NULL);
			if (L_26)
			{
				goto IL_00cc;
			}
		}

IL_008b:
		{
			int32_t L_27 = 0;
			V_0 = L_27;
			__this->set_U3CU3E1__state_0(L_27);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_28 = V_5;
			__this->set_U3CU3Eu__1_8(L_28);
			AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_29 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m7F46BD9D275C21386FD4E0DA80512950AFC6587E((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_29, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_5), (U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_m7F46BD9D275C21386FD4E0DA80512950AFC6587E_RuntimeMethod_var);
			goto IL_018b;
		}

IL_00af:
		{
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_30 = __this->get_U3CU3Eu__1_8();
			V_5 = L_30;
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_31 = __this->get_address_of_U3CU3Eu__1_8();
			il2cpp_codegen_initobj(L_31, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
			int32_t L_32 = (-1);
			V_0 = L_32;
			__this->set_U3CU3E1__state_0(L_32);
		}

IL_00cc:
		{
			TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_5), /*hidden argument*/NULL);
			// Response response = await ReceiveExpect(Messages.SUBSCRIBED, requestId, timeout);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_33 = V_1;
			int32_t L_34 = __this->get_U3CrequestIdU3E5__2_7();
			int32_t L_35 = __this->get_timeout_5();
			NullCheck(L_33);
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_36 = Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864(L_33, ((int32_t)33), L_34, L_35, /*hidden argument*/NULL);
			NullCheck(L_36);
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_37 = Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3(L_36, /*hidden argument*/Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3_RuntimeMethod_var);
			V_6 = L_37;
			bool L_38 = TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_6), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E_RuntimeMethod_var);
			if (L_38)
			{
				goto IL_0135;
			}
		}

IL_00f7:
		{
			int32_t L_39 = 1;
			V_0 = L_39;
			__this->set_U3CU3E1__state_0(L_39);
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_40 = V_6;
			__this->set_U3CU3Eu__2_9(L_40);
			AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_41 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_mDC84E980D918760546764180E8EFF9C820AC03B2((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_41, (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_6), (U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_1_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9_mDC84E980D918760546764180E8EFF9C820AC03B2_RuntimeMethod_var);
			goto IL_018b;
		}

IL_0118:
		{
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_42 = __this->get_U3CU3Eu__2_9();
			V_6 = L_42;
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * L_43 = __this->get_address_of_U3CU3Eu__2_9();
			il2cpp_codegen_initobj(L_43, sizeof(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 ));
			int32_t L_44 = (-1);
			V_0 = L_44;
			__this->set_U3CU3E1__state_0(L_44);
		}

IL_0135:
		{
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_45 = TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_6), /*hidden argument*/TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50_RuntimeMethod_var);
			V_3 = L_45;
			// subscriptions.TryAdd(response.SubscriptionId, publishEvent);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_46 = V_1;
			NullCheck(L_46);
			ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * L_47 = L_46->get_subscriptions_6();
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_48 = V_3;
			NullCheck(L_48);
			uint32_t L_49 = Response_get_SubscriptionId_m38F262E5543B6AA4EB3EDDB8A8F1365B84284383_inline(L_48, /*hidden argument*/NULL);
			PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * L_50 = __this->get_publishEvent_6();
			NullCheck(L_47);
			ConcurrentDictionary_2_TryAdd_mE2925CDD203464DF30191E99B8FC7F6FBD10420B(L_47, L_49, L_50, /*hidden argument*/ConcurrentDictionary_2_TryAdd_mE2925CDD203464DF30191E99B8FC7F6FBD10420B_RuntimeMethod_var);
			// return response.SubscriptionId;
			Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * L_51 = V_3;
			NullCheck(L_51);
			uint32_t L_52 = Response_get_SubscriptionId_m38F262E5543B6AA4EB3EDDB8A8F1365B84284383_inline(L_51, /*hidden argument*/NULL);
			V_2 = L_52;
			goto IL_0177;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_015e;
		throw e;
	}

CATCH_015e:
	{ // begin catch(System.Exception)
		V_7 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_53 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_54 = V_7;
		AsyncTaskMethodBuilder_1_SetException_m4BCFE40068BC66F1C48B5C7C7C9F93F5E48EF00B((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_53, L_54, /*hidden argument*/AsyncTaskMethodBuilder_1_SetException_m4BCFE40068BC66F1C48B5C7C7C9F93F5E48EF00B_RuntimeMethod_var);
		goto IL_018b;
	} // end catch (depth: 1)

IL_0177:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_55 = __this->get_address_of_U3CU3Et__builder_1();
		uint32_t L_56 = V_2;
		AsyncTaskMethodBuilder_1_SetResult_m887E134B6FD52D8CA2116A466F69BC8E1EA6ED5E((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_55, L_56, /*hidden argument*/AsyncTaskMethodBuilder_1_SetResult_m887E134B6FD52D8CA2116A466F69BC8E1EA6ED5E_RuntimeMethod_var);
	}

IL_018b:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CSubscribeU3Ed__35_MoveNext_m871F84E5292DE81E13BE9C94AB0EA8765E1D5285_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * _thisAdjusted = reinterpret_cast<U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 *>(__this + _offset);
	U3CSubscribeU3Ed__35_MoveNext_m871F84E5292DE81E13BE9C94AB0EA8765E1D5285(_thisAdjusted, method);
}
// System.Void Wamp_<Subscribe>d__35::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CSubscribeU3Ed__35_SetStateMachine_mDAD9620ACF150FAED21040DF4EAC8D41588BD7C6 (U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CSubscribeU3Ed__35_SetStateMachine_mDAD9620ACF150FAED21040DF4EAC8D41588BD7C6_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_1_SetStateMachine_m2C2B09AB812EDEDAB3C9E89B8A2BF19C4EC8B45F((AsyncTaskMethodBuilder_1_tD386300660CF74FF8FB22C6C3C937BBA9F7E8DED *)L_0, L_1, /*hidden argument*/AsyncTaskMethodBuilder_1_SetStateMachine_m2C2B09AB812EDEDAB3C9E89B8A2BF19C4EC8B45F_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CSubscribeU3Ed__35_SetStateMachine_mDAD9620ACF150FAED21040DF4EAC8D41588BD7C6_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 * _thisAdjusted = reinterpret_cast<U3CSubscribeU3Ed__35_tFAB60896060ACE4DD3F76FC6B15ECDE68AC85CC9 *>(__this + _offset);
	U3CSubscribeU3Ed__35_SetStateMachine_mDAD9620ACF150FAED21040DF4EAC8D41588BD7C6(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_<Unsubscribe>d__36::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CUnsubscribeU3Ed__36_MoveNext_m342B13779519EDA18D70E718177AFB7256C1CB54 (U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CUnsubscribeU3Ed__36_MoveNext_m342B13779519EDA18D70E718177AFB7256C1CB54_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * V_1 = NULL;
	PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * V_2 = NULL;
	int32_t V_3 = 0;
	TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  V_4;
	memset((&V_4), 0, sizeof(V_4));
	TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  V_5;
	memset((&V_5), 0, sizeof(V_5));
	Exception_t * V_6 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 4);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = __this->get_U3CU3E1__state_0();
		V_0 = L_0;
		Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_1 = __this->get_U3CU3E4__this_2();
		V_1 = L_1;
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_2 = V_0;
			if (!L_2)
			{
				goto IL_0099;
			}
		}

IL_0014:
		{
			int32_t L_3 = V_0;
			if ((((int32_t)L_3) == ((int32_t)1)))
			{
				goto IL_0102;
			}
		}

IL_001b:
		{
			// int requestId = ++currentRequestId;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_4 = V_1;
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_5 = V_1;
			NullCheck(L_5);
			int32_t L_6 = L_5->get_currentRequestId_3();
			V_3 = ((int32_t)il2cpp_codegen_add((int32_t)L_6, (int32_t)1));
			int32_t L_7 = V_3;
			NullCheck(L_4);
			L_4->set_currentRequestId_3(L_7);
			int32_t L_8 = V_3;
			__this->set_U3CrequestIdU3E5__2_5(L_8);
			// await Send($"[{(int)Messages.UNSUBSCRIBE},{requestId},{subscriptionId}]", timeout);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_9 = V_1;
			int32_t L_10 = ((int32_t)34);
			RuntimeObject * L_11 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_10);
			int32_t L_12 = __this->get_U3CrequestIdU3E5__2_5();
			int32_t L_13 = L_12;
			RuntimeObject * L_14 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_13);
			uint32_t L_15 = __this->get_subscriptionId_3();
			uint32_t L_16 = L_15;
			RuntimeObject * L_17 = Box(UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B_il2cpp_TypeInfo_var, &L_16);
			String_t* L_18 = String_Format_m26BBF75F9609FAD0B39C2242FEBAAD7D68F14D99(_stringLiteralADD50DC32B886BB91B26CB80CF5526F3F9CFBCE0, L_11, L_14, L_17, /*hidden argument*/NULL);
			int32_t L_19 = __this->get_timeout_4();
			NullCheck(L_9);
			Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2 * L_20 = Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591(L_9, L_18, L_19, /*hidden argument*/NULL);
			NullCheck(L_20);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_21 = Task_GetAwaiter_m73027D5E4C16E961C658B83526BED8E32FD2AC6C(L_20, /*hidden argument*/NULL);
			V_4 = L_21;
			bool L_22 = TaskAwaiter_get_IsCompleted_m5A2B6FEA0ED3B01B5E88DBF2D8BC4A45652ABD87((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_4), /*hidden argument*/NULL);
			if (L_22)
			{
				goto IL_00b6;
			}
		}

IL_0075:
		{
			int32_t L_23 = 0;
			V_0 = L_23;
			__this->set_U3CU3E1__state_0(L_23);
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_24 = V_4;
			__this->set_U3CU3Eu__1_6(L_24);
			AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_25 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m553F9508C8EF12D8C31A1E1B935D79855E6FF52C((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_25, (TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_4), (U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m553F9508C8EF12D8C31A1E1B935D79855E6FF52C_RuntimeMethod_var);
			goto IL_0169;
		}

IL_0099:
		{
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F  L_26 = __this->get_U3CU3Eu__1_6();
			V_4 = L_26;
			TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F * L_27 = __this->get_address_of_U3CU3Eu__1_6();
			il2cpp_codegen_initobj(L_27, sizeof(TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F ));
			int32_t L_28 = (-1);
			V_0 = L_28;
			__this->set_U3CU3E1__state_0(L_28);
		}

IL_00b6:
		{
			TaskAwaiter_GetResult_m89868C01592AC2B06CE1FD42D9B9C187C6FD928A((TaskAwaiter_t0CDE8DBB564F0A0EA55FA6B3D43EEF96BC26252F *)(&V_4), /*hidden argument*/NULL);
			// Response response = await ReceiveExpect(Messages.UNSUBSCRIBED, requestId, timeout);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_29 = V_1;
			int32_t L_30 = __this->get_U3CrequestIdU3E5__2_5();
			int32_t L_31 = __this->get_timeout_4();
			NullCheck(L_29);
			Task_1_t08BD6D22BEF0D415C8B77212F8A7EE6DD16E3BBA * L_32 = Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864(L_29, ((int32_t)35), L_30, L_31, /*hidden argument*/NULL);
			NullCheck(L_32);
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_33 = Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3(L_32, /*hidden argument*/Task_1_GetAwaiter_m67581CE187790009660BEBD2E5FF9C284A5C68B3_RuntimeMethod_var);
			V_5 = L_33;
			bool L_34 = TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_5), /*hidden argument*/TaskAwaiter_1_get_IsCompleted_m4CF72984063616126FC5DF7B2EACFF6D5505D25E_RuntimeMethod_var);
			if (L_34)
			{
				goto IL_011f;
			}
		}

IL_00e1:
		{
			int32_t L_35 = 1;
			V_0 = L_35;
			__this->set_U3CU3E1__state_0(L_35);
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_36 = V_5;
			__this->set_U3CU3Eu__2_7(L_36);
			AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_37 = __this->get_address_of_U3CU3Et__builder_1();
			AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m04E32B234DB4F762A2F7D6F2540BA392DBC0EF2A((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_37, (TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_5), (U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 *)__this, /*hidden argument*/AsyncTaskMethodBuilder_AwaitUnsafeOnCompleted_TisTaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9_TisU3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2_m04E32B234DB4F762A2F7D6F2540BA392DBC0EF2A_RuntimeMethod_var);
			goto IL_0169;
		}

IL_0102:
		{
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9  L_38 = __this->get_U3CU3Eu__2_7();
			V_5 = L_38;
			TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 * L_39 = __this->get_address_of_U3CU3Eu__2_7();
			il2cpp_codegen_initobj(L_39, sizeof(TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 ));
			int32_t L_40 = (-1);
			V_0 = L_40;
			__this->set_U3CU3E1__state_0(L_40);
		}

IL_011f:
		{
			TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50((TaskAwaiter_1_t4AECC1B8D17CDA83CA1A474EF7BCD0A9C05A6EA9 *)(&V_5), /*hidden argument*/TaskAwaiter_1_GetResult_mB652254D22D4864187593B64F8A530A100489E50_RuntimeMethod_var);
			// subscriptions.TryRemove(subscriptionId, out oldEvent);
			Wamp_tCBDFD41B065AE79E4A03C5048222FEB903502E24 * L_41 = V_1;
			NullCheck(L_41);
			ConcurrentDictionary_2_tCD17FC9EFD062DE0A6B1EE0B15263413B58D01F0 * L_42 = L_41->get_subscriptions_6();
			uint32_t L_43 = __this->get_subscriptionId_3();
			NullCheck(L_42);
			ConcurrentDictionary_2_TryRemove_m69838C15D68F91E4E959F18061311021A99D41FB(L_42, L_43, (PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 **)(&V_2), /*hidden argument*/ConcurrentDictionary_2_TryRemove_m69838C15D68F91E4E959F18061311021A99D41FB_RuntimeMethod_var);
			goto IL_0156;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t_il2cpp_TypeInfo_var, il2cpp_codegen_object_class(e.ex)))
			goto CATCH_013d;
		throw e;
	}

CATCH_013d:
	{ // begin catch(System.Exception)
		V_6 = ((Exception_t *)__exception_local);
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_44 = __this->get_address_of_U3CU3Et__builder_1();
		Exception_t * L_45 = V_6;
		AsyncTaskMethodBuilder_SetException_m370C484922A63A6EF96E241D1370B8814F1F2D6B((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_44, L_45, /*hidden argument*/NULL);
		goto IL_0169;
	} // end catch (depth: 1)

IL_0156:
	{
		// }
		__this->set_U3CU3E1__state_0(((int32_t)-2));
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_46 = __this->get_address_of_U3CU3Et__builder_1();
		AsyncTaskMethodBuilder_SetResult_m151016FB698F3BB34A73BAE693A97513A7E4C838((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_46, /*hidden argument*/NULL);
	}

IL_0169:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void U3CUnsubscribeU3Ed__36_MoveNext_m342B13779519EDA18D70E718177AFB7256C1CB54_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * _thisAdjusted = reinterpret_cast<U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 *>(__this + _offset);
	U3CUnsubscribeU3Ed__36_MoveNext_m342B13779519EDA18D70E718177AFB7256C1CB54(_thisAdjusted, method);
}
// System.Void Wamp_<Unsubscribe>d__36::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CUnsubscribeU3Ed__36_SetStateMachine_mD7D2367D4B35E676ADA256D3997B6DBAF72B293E (U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	{
		AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 * L_0 = __this->get_address_of_U3CU3Et__builder_1();
		RuntimeObject* L_1 = ___stateMachine0;
		AsyncTaskMethodBuilder_SetStateMachine_mB5DD68F7C49EA6D452AEBA02B1B98AED898C3C25((AsyncTaskMethodBuilder_t0CD1893D670405BED201BE8CA6F2E811F2C0F487 *)L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void U3CUnsubscribeU3Ed__36_SetStateMachine_mD7D2367D4B35E676ADA256D3997B6DBAF72B293E_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___stateMachine0, const RuntimeMethod* method)
{
	int32_t _offset = 1;
	U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 * _thisAdjusted = reinterpret_cast<U3CUnsubscribeU3Ed__36_t24FA26472BD29BCE1DC4DB1D786BB958F5EDE6E2 *>(__this + _offset);
	U3CUnsubscribeU3Ed__36_SetStateMachine_mD7D2367D4B35E676ADA256D3997B6DBAF72B293E(_thisAdjusted, ___stateMachine0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C  void DelegatePInvokeWrapper_DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 (DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * __this, const RuntimeMethod* method)
{
	typedef void (DEFAULT_CALL *PInvokeFunc)();
	PInvokeFunc il2cppPInvokeFunc = reinterpret_cast<PInvokeFunc>(il2cpp_codegen_get_method_pointer(((RuntimeDelegate*)__this)->method));

	// Native function invocation
	il2cppPInvokeFunc();

}
// System.Void Wamp_DisconnectedHandler::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DisconnectedHandler__ctor_m742456B3847D7F450EEFBD2053B6C43C3D272C80 (DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method)
{
	__this->set_method_ptr_0(il2cpp_codegen_get_method_pointer((RuntimeMethod*)___method1));
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Void Wamp_DisconnectedHandler::Invoke()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DisconnectedHandler_Invoke_m08F15DEC1D0B8B106737140AF777D9CAEF92E79E (DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * __this, const RuntimeMethod* method)
{
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* delegateArrayToInvoke = __this->get_delegates_11();
	Delegate_t** delegatesToInvoke;
	il2cpp_array_size_t length;
	if (delegateArrayToInvoke != NULL)
	{
		length = delegateArrayToInvoke->max_length;
		delegatesToInvoke = reinterpret_cast<Delegate_t**>(delegateArrayToInvoke->GetAddressAtUnchecked(0));
	}
	else
	{
		length = 1;
		delegatesToInvoke = reinterpret_cast<Delegate_t**>(&__this);
	}

	for (il2cpp_array_size_t i = 0; i < length; i++)
	{
		Delegate_t* currentDelegate = delegatesToInvoke[i];
		Il2CppMethodPointer targetMethodPointer = currentDelegate->get_method_ptr_0();
		RuntimeObject* targetThis = currentDelegate->get_m_target_2();
		RuntimeMethod* targetMethod = (RuntimeMethod*)(currentDelegate->get_method_3());
		if (!il2cpp_codegen_method_is_virtual(targetMethod))
		{
			il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found(targetMethod);
		}
		bool ___methodIsStatic = MethodIsStatic(targetMethod);
		int ___parameterCount = il2cpp_codegen_method_parameter_count(targetMethod);
		if (___methodIsStatic)
		{
			if (___parameterCount == 0)
			{
				// open
				typedef void (*FunctionPointerType) (const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(targetMethod);
			}
			else
			{
				// closed
				typedef void (*FunctionPointerType) (void*, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(targetThis, targetMethod);
			}
		}
		else
		{
			// closed
			if (targetThis != NULL && il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_generic_instance(targetMethod))
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						GenericInterfaceActionInvoker0::Invoke(targetMethod, targetThis);
					else
						GenericVirtActionInvoker0::Invoke(targetMethod, targetThis);
				}
				else
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						InterfaceActionInvoker0::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), targetThis);
					else
						VirtActionInvoker0::Invoke(il2cpp_codegen_method_get_slot(targetMethod), targetThis);
				}
			}
			else
			{
				typedef void (*FunctionPointerType) (void*, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(targetThis, targetMethod);
			}
		}
	}
}
// System.IAsyncResult Wamp_DisconnectedHandler::BeginInvoke(System.AsyncCallback,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* DisconnectedHandler_BeginInvoke_mDA3C965C383835C646F861342836EAA6A853D4F0 (DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * __this, AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4 * ___callback0, RuntimeObject * ___object1, const RuntimeMethod* method)
{
	void *__d_args[1] = {0};
	return (RuntimeObject*)il2cpp_codegen_delegate_begin_invoke((RuntimeDelegate*)__this, __d_args, (RuntimeDelegate*)___callback0, (RuntimeObject*)___object1);
}
// System.Void Wamp_DisconnectedHandler::EndInvoke(System.IAsyncResult)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DisconnectedHandler_EndInvoke_m29EB3F908BD393FD1495681609835B5DE61A385D (DisconnectedHandler_tF52E34C9DD05AA9FE68B838EF11D58DB03F60EB3 * __this, RuntimeObject* ___result0, const RuntimeMethod* method)
{
	il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.String Wamp_ErrorException::get_Json()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* ErrorException_get_Json_m6F364D704AE749F82E57E62A4039891B5AA65BC2 (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, const RuntimeMethod* method)
{
	{
		// internal string Json { get; set; }
		String_t* L_0 = __this->get_U3CJsonU3Ek__BackingField_17();
		return L_0;
	}
}
// System.Void Wamp_ErrorException::set_Json(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ErrorException_set_Json_m63B27B2FF42F2763E1B259F6CAA1B1813839D6EC (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		// internal string Json { get; set; }
		String_t* L_0 = ___value0;
		__this->set_U3CJsonU3Ek__BackingField_17(L_0);
		return;
	}
}
// Wamp_Messages Wamp_ErrorException::get_MessageId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ErrorException_get_MessageId_m951111C43E1CC324EAF227B5DA4975DBA837BB5B (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, const RuntimeMethod* method)
{
	{
		// internal Messages MessageId { get; set; }
		int32_t L_0 = __this->get_U3CMessageIdU3Ek__BackingField_18();
		return L_0;
	}
}
// System.Void Wamp_ErrorException::set_MessageId(Wamp_Messages)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ErrorException_set_MessageId_mB2E895A07D439F8EB5C11D1E02EEC602FC84DAB1 (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// internal Messages MessageId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CMessageIdU3Ek__BackingField_18(L_0);
		return;
	}
}
// System.Int32 Wamp_ErrorException::get_RequestId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ErrorException_get_RequestId_m820DEA354FDC75A23968D323311483801B65502E (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, const RuntimeMethod* method)
{
	{
		// internal int RequestId { get; set; }
		int32_t L_0 = __this->get_U3CRequestIdU3Ek__BackingField_19();
		return L_0;
	}
}
// System.Void Wamp_ErrorException::set_RequestId(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ErrorException_set_RequestId_m141F6E4AA9228ECD9320038A3FC7D0633DDD53A9 (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// internal int RequestId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CRequestIdU3Ek__BackingField_19(L_0);
		return;
	}
}
// System.String Wamp_ErrorException::get_Uri()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* ErrorException_get_Uri_m307DAFB1DE6403546BF024E1AA100BC3B387E4BC (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, const RuntimeMethod* method)
{
	{
		// internal string Uri { get; set; }
		String_t* L_0 = __this->get_U3CUriU3Ek__BackingField_20();
		return L_0;
	}
}
// System.Void Wamp_ErrorException::set_Uri(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ErrorException_set_Uri_mEFBFD6E03D38DA354BB53E6DA1467A6E1F97BE90 (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		// internal string Uri { get; set; }
		String_t* L_0 = ___value0;
		__this->set_U3CUriU3Ek__BackingField_20(L_0);
		return;
	}
}
// System.Void Wamp_ErrorException::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9 (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, String_t* ___message0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// : base(message)
		String_t* L_0 = ___message0;
		IL2CPP_RUNTIME_CLASS_INIT(Exception_t_il2cpp_TypeInfo_var);
		Exception__ctor_m89BADFF36C3B170013878726E07729D51AA9FBE0(__this, L_0, /*hidden argument*/NULL);
		// }
		return;
	}
}
// Wamp_ErrorException Wamp_ErrorException::FromResponse(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * ErrorException_FromResponse_m7F3FD8A84BC8AEF0BC62A4CD5203DF961BC803C9 (String_t* ___response0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ErrorException_FromResponse_m7F3FD8A84BC8AEF0BC62A4CD5203DF961BC803C9_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * V_1 = NULL;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	String_t* V_4 = NULL;
	String_t* V_5 = NULL;
	{
		// string pattern = @"^\[\s*8,\s*(\d+)\s*,\s*(\d+)\s*,\s*\{\s*\}\s*,\s*""([^,\s]+)""\s*,\[\s*\]\s*,\s*(\{)";
		V_0 = _stringLiteral4FD19FAE88F259405F9AE652A1A77583AC534FB2;
		// var match = System.Text.RegularExpressions.Regex.Match(response, pattern, System.Text.RegularExpressions.RegexOptions.Singleline);
		String_t* L_0 = ___response0;
		String_t* L_1 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF_il2cpp_TypeInfo_var);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_2 = Regex_Match_m08332EE8B44F5A94218B8D432627EB7F71EE7BE2(L_0, L_1, ((int32_t)16), /*hidden argument*/NULL);
		V_1 = L_2;
		// if (match.Groups.Count != 5)
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_3 = V_1;
		NullCheck(L_3);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_4 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_3);
		NullCheck(L_4);
		int32_t L_5 = GroupCollection_get_Count_mBDDCA62E15FC586F0CCBD75F006BF0B08713E26E(L_4, /*hidden argument*/NULL);
		if ((((int32_t)L_5) == ((int32_t)5)))
		{
			goto IL_0029;
		}
	}
	{
		// throw new ErrorException("Invalid ERROR message.");
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_6 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_6, _stringLiteral1439A06384A159CD45C0CCDE53F72F30FD15FD22, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_6, ErrorException_FromResponse_m7F3FD8A84BC8AEF0BC62A4CD5203DF961BC803C9_RuntimeMethod_var);
	}

IL_0029:
	{
		// Messages messageId = (Messages)int.Parse(match.Groups[1].Value);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_7 = V_1;
		NullCheck(L_7);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_8 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_7);
		NullCheck(L_8);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_9 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_8, 1, /*hidden argument*/NULL);
		NullCheck(L_9);
		String_t* L_10 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_9, /*hidden argument*/NULL);
		int32_t L_11 = Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA(L_10, /*hidden argument*/NULL);
		V_2 = L_11;
		// int requestId = int.Parse(match.Groups[2].Value);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_12 = V_1;
		NullCheck(L_12);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_13 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_12);
		NullCheck(L_13);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_14 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_13, 2, /*hidden argument*/NULL);
		NullCheck(L_14);
		String_t* L_15 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_14, /*hidden argument*/NULL);
		int32_t L_16 = Int32_Parse_m5807B6243415790250FC25168F767C08FC16FDEA(L_15, /*hidden argument*/NULL);
		V_3 = L_16;
		// string uri = match.Groups[3].Value;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_17 = V_1;
		NullCheck(L_17);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_18 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_17);
		NullCheck(L_18);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_19 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_18, 3, /*hidden argument*/NULL);
		NullCheck(L_19);
		String_t* L_20 = Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C(L_19, /*hidden argument*/NULL);
		V_4 = L_20;
		// string json = response.Substring(match.Groups[4].Index, response.Length - match.Groups[4].Index - 1);
		String_t* L_21 = ___response0;
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_22 = V_1;
		NullCheck(L_22);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_23 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_22);
		NullCheck(L_23);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_24 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_23, 4, /*hidden argument*/NULL);
		NullCheck(L_24);
		int32_t L_25 = Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31_inline(L_24, /*hidden argument*/NULL);
		String_t* L_26 = ___response0;
		NullCheck(L_26);
		int32_t L_27 = String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018_inline(L_26, /*hidden argument*/NULL);
		Match_tE447871AB59EED3642F31EB9559D162C2977EBB5 * L_28 = V_1;
		NullCheck(L_28);
		GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * L_29 = VirtFuncInvoker0< GroupCollection_tD9051ED1A991E3666439262B517FDD2F968C064F * >::Invoke(5 /* System.Text.RegularExpressions.GroupCollection System.Text.RegularExpressions.Match::get_Groups() */, L_28);
		NullCheck(L_29);
		Group_tB4759D0385925B2C8C14ED3FCD5D2F43CFBD0443 * L_30 = GroupCollection_get_Item_m5ABF137CEFD5E2F2FE2EC76835963594300D4177(L_29, 4, /*hidden argument*/NULL);
		NullCheck(L_30);
		int32_t L_31 = Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31_inline(L_30, /*hidden argument*/NULL);
		NullCheck(L_21);
		String_t* L_32 = String_Substring_mB593C0A320C683E6E47EFFC0A12B7A465E5E43BB(L_21, L_25, ((int32_t)il2cpp_codegen_subtract((int32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_27, (int32_t)L_31)), (int32_t)1)), /*hidden argument*/NULL);
		V_5 = L_32;
		// return new ErrorException($"Error {uri} in {messageId.ToString()} operation.")
		// {
		//     Json = json,
		//     MessageId = messageId,
		//     RequestId = requestId,
		//     Uri = uri
		// };
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_33 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)5);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_34 = L_33;
		NullCheck(L_34);
		ArrayElementTypeCheck (L_34, _stringLiteral975FA903026B31A9F131D79CA7D5A3C419167BE3);
		(L_34)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral975FA903026B31A9F131D79CA7D5A3C419167BE3);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_35 = L_34;
		String_t* L_36 = V_4;
		NullCheck(L_35);
		ArrayElementTypeCheck (L_35, L_36);
		(L_35)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)L_36);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_37 = L_35;
		NullCheck(L_37);
		ArrayElementTypeCheck (L_37, _stringLiteral64D2F058B2C616C8EFED8152F4A527D3F4A3F56F);
		(L_37)->SetAt(static_cast<il2cpp_array_size_t>(2), (String_t*)_stringLiteral64D2F058B2C616C8EFED8152F4A527D3F4A3F56F);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_38 = L_37;
		RuntimeObject * L_39 = Box(Messages_tD25B555D7E0152EFD72FB82E6E3843CCCDA276B3_il2cpp_TypeInfo_var, (&V_2));
		NullCheck(L_39);
		String_t* L_40 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_39);
		V_2 = *(int32_t*)UnBox(L_39);
		NullCheck(L_38);
		ArrayElementTypeCheck (L_38, L_40);
		(L_38)->SetAt(static_cast<il2cpp_array_size_t>(3), (String_t*)L_40);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_41 = L_38;
		NullCheck(L_41);
		ArrayElementTypeCheck (L_41, _stringLiteralD9842BE6592DBAC6DB4096D01408D6F0BB6D295A);
		(L_41)->SetAt(static_cast<il2cpp_array_size_t>(4), (String_t*)_stringLiteralD9842BE6592DBAC6DB4096D01408D6F0BB6D295A);
		String_t* L_42 = String_Concat_m232E857CA5107EA6AC52E7DD7018716C021F237B(L_41, /*hidden argument*/NULL);
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_43 = (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 *)il2cpp_codegen_object_new(ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46_il2cpp_TypeInfo_var);
		ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9(L_43, L_42, /*hidden argument*/NULL);
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_44 = L_43;
		String_t* L_45 = V_5;
		NullCheck(L_44);
		ErrorException_set_Json_m63B27B2FF42F2763E1B259F6CAA1B1813839D6EC_inline(L_44, L_45, /*hidden argument*/NULL);
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_46 = L_44;
		int32_t L_47 = V_2;
		NullCheck(L_46);
		ErrorException_set_MessageId_mB2E895A07D439F8EB5C11D1E02EEC602FC84DAB1_inline(L_46, L_47, /*hidden argument*/NULL);
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_48 = L_46;
		int32_t L_49 = V_3;
		NullCheck(L_48);
		ErrorException_set_RequestId_m141F6E4AA9228ECD9320038A3FC7D0633DDD53A9_inline(L_48, L_49, /*hidden argument*/NULL);
		ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * L_50 = L_48;
		String_t* L_51 = V_4;
		NullCheck(L_50);
		ErrorException_set_Uri_mEFBFD6E03D38DA354BB53E6DA1467A6E1F97BE90_inline(L_50, L_51, /*hidden argument*/NULL);
		return L_50;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C  void DelegatePInvokeWrapper_PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 (PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * __this, String_t* ___json0, const RuntimeMethod* method)
{
	typedef void (DEFAULT_CALL *PInvokeFunc)(char*);
	PInvokeFunc il2cppPInvokeFunc = reinterpret_cast<PInvokeFunc>(il2cpp_codegen_get_method_pointer(((RuntimeDelegate*)__this)->method));

	// Marshaling of parameter '___json0' to native representation
	char* ____json0_marshaled = NULL;
	____json0_marshaled = il2cpp_codegen_marshal_string(___json0);

	// Native function invocation
	il2cppPInvokeFunc(____json0_marshaled);

	// Marshaling cleanup of parameter '___json0' native representation
	il2cpp_codegen_marshal_free(____json0_marshaled);
	____json0_marshaled = NULL;

}
// System.Void Wamp_PublishHandler::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PublishHandler__ctor_mF50D892D205E428FEBDE6AE72C209A6B386524B2 (PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method)
{
	__this->set_method_ptr_0(il2cpp_codegen_get_method_pointer((RuntimeMethod*)___method1));
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Void Wamp_PublishHandler::Invoke(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PublishHandler_Invoke_m85F2A61F37B7D01827F76105781D219BFCF7E448 (PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * __this, String_t* ___json0, const RuntimeMethod* method)
{
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* delegateArrayToInvoke = __this->get_delegates_11();
	Delegate_t** delegatesToInvoke;
	il2cpp_array_size_t length;
	if (delegateArrayToInvoke != NULL)
	{
		length = delegateArrayToInvoke->max_length;
		delegatesToInvoke = reinterpret_cast<Delegate_t**>(delegateArrayToInvoke->GetAddressAtUnchecked(0));
	}
	else
	{
		length = 1;
		delegatesToInvoke = reinterpret_cast<Delegate_t**>(&__this);
	}

	for (il2cpp_array_size_t i = 0; i < length; i++)
	{
		Delegate_t* currentDelegate = delegatesToInvoke[i];
		Il2CppMethodPointer targetMethodPointer = currentDelegate->get_method_ptr_0();
		RuntimeObject* targetThis = currentDelegate->get_m_target_2();
		RuntimeMethod* targetMethod = (RuntimeMethod*)(currentDelegate->get_method_3());
		if (!il2cpp_codegen_method_is_virtual(targetMethod))
		{
			il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found(targetMethod);
		}
		bool ___methodIsStatic = MethodIsStatic(targetMethod);
		int ___parameterCount = il2cpp_codegen_method_parameter_count(targetMethod);
		if (___methodIsStatic)
		{
			if (___parameterCount == 1)
			{
				// open
				typedef void (*FunctionPointerType) (String_t*, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(___json0, targetMethod);
			}
			else
			{
				// closed
				typedef void (*FunctionPointerType) (void*, String_t*, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(targetThis, ___json0, targetMethod);
			}
		}
		else if (___parameterCount != 1)
		{
			// open
			if (il2cpp_codegen_method_is_virtual(targetMethod) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_generic_instance(targetMethod))
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						GenericInterfaceActionInvoker0::Invoke(targetMethod, ___json0);
					else
						GenericVirtActionInvoker0::Invoke(targetMethod, ___json0);
				}
				else
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						InterfaceActionInvoker0::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), ___json0);
					else
						VirtActionInvoker0::Invoke(il2cpp_codegen_method_get_slot(targetMethod), ___json0);
				}
			}
			else
			{
				typedef void (*FunctionPointerType) (String_t*, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(___json0, targetMethod);
			}
		}
		else
		{
			// closed
			if (targetThis != NULL && il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_generic_instance(targetMethod))
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						GenericInterfaceActionInvoker1< String_t* >::Invoke(targetMethod, targetThis, ___json0);
					else
						GenericVirtActionInvoker1< String_t* >::Invoke(targetMethod, targetThis, ___json0);
				}
				else
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						InterfaceActionInvoker1< String_t* >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), targetThis, ___json0);
					else
						VirtActionInvoker1< String_t* >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), targetThis, ___json0);
				}
			}
			else
			{
				if (targetThis == NULL && il2cpp_codegen_class_is_value_type(il2cpp_codegen_method_get_declaring_type(targetMethod)))
				{
					typedef void (*FunctionPointerType) (RuntimeObject*, const RuntimeMethod*);
					((FunctionPointerType)targetMethodPointer)((reinterpret_cast<RuntimeObject*>(___json0) - 1), targetMethod);
				}
				if (targetThis == NULL)
				{
					typedef void (*FunctionPointerType) (String_t*, const RuntimeMethod*);
					((FunctionPointerType)targetMethodPointer)(___json0, targetMethod);
				}
				else
				{
					typedef void (*FunctionPointerType) (void*, String_t*, const RuntimeMethod*);
					((FunctionPointerType)targetMethodPointer)(targetThis, ___json0, targetMethod);
				}
			}
		}
	}
}
// System.IAsyncResult Wamp_PublishHandler::BeginInvoke(System.String,System.AsyncCallback,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* PublishHandler_BeginInvoke_mE0D9DE2DBF0BDA0314F3E4BBB4C2BFDA4F2CE68E (PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * __this, String_t* ___json0, AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4 * ___callback1, RuntimeObject * ___object2, const RuntimeMethod* method)
{
	void *__d_args[2] = {0};
	__d_args[0] = ___json0;
	return (RuntimeObject*)il2cpp_codegen_delegate_begin_invoke((RuntimeDelegate*)__this, __d_args, (RuntimeDelegate*)___callback1, (RuntimeObject*)___object2);
}
// System.Void Wamp_PublishHandler::EndInvoke(System.IAsyncResult)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PublishHandler_EndInvoke_mD6D4C66F02CBFF7906EFE4303E7B68793F86FF18 (PublishHandler_t0F04E9AA41AD74391DBA82D9FB8045863B341682 * __this, RuntimeObject* ___result0, const RuntimeMethod* method)
{
	il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Wamp_Messages Wamp_Response::get_MessageId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Response_get_MessageId_mC397D82D70FC4A2DC73186D1CADF3ADF34CEE0D7 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public Messages MessageId { get; set; }
		int32_t L_0 = __this->get_U3CMessageIdU3Ek__BackingField_0();
		return L_0;
	}
}
// System.Void Wamp_Response::set_MessageId(Wamp_Messages)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// public Messages MessageId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CMessageIdU3Ek__BackingField_0(L_0);
		return;
	}
}
// System.Int32 Wamp_Response::get_RequestId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Response_get_RequestId_m839528D15AAC4BC39EAEB22669F38B75140A0C05 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public int RequestId { get; set; }
		int32_t L_0 = __this->get_U3CRequestIdU3Ek__BackingField_1();
		return L_0;
	}
}
// System.Void Wamp_Response::set_RequestId(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// public int RequestId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CRequestIdU3Ek__BackingField_1(L_0);
		return;
	}
}
// System.Int32 Wamp_Response::get_ContextSpecificResultId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Response_get_ContextSpecificResultId_m8C53A20C58BACF5A2DA2379A42D2818F283CF862 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public int ContextSpecificResultId { get; set; }
		int32_t L_0 = __this->get_U3CContextSpecificResultIdU3Ek__BackingField_2();
		return L_0;
	}
}
// System.Void Wamp_Response::set_ContextSpecificResultId(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Response_set_ContextSpecificResultId_m4E0BD596C10376CFFFD141BF47A2322DBF18D760 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// public int ContextSpecificResultId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CContextSpecificResultIdU3Ek__BackingField_2(L_0);
		return;
	}
}
// System.UInt32 Wamp_Response::get_SubscriptionId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t Response_get_SubscriptionId_m38F262E5543B6AA4EB3EDDB8A8F1365B84284383 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public uint SubscriptionId { get; set; }
		uint32_t L_0 = __this->get_U3CSubscriptionIdU3Ek__BackingField_3();
		return L_0;
	}
}
// System.Void Wamp_Response::set_SubscriptionId(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Response_set_SubscriptionId_m160D966B5D30F42BF0D5C133AA49CC14B62ED853 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, uint32_t ___value0, const RuntimeMethod* method)
{
	{
		// public uint SubscriptionId { get; set; }
		uint32_t L_0 = ___value0;
		__this->set_U3CSubscriptionIdU3Ek__BackingField_3(L_0);
		return;
	}
}
// System.String Wamp_Response::get_Json()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Response_get_Json_m344AA62580A8B48CEECF9F5A9B33638D572B785B (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public string Json { get; set; }
		String_t* L_0 = __this->get_U3CJsonU3Ek__BackingField_4();
		return L_0;
	}
}
// System.Void Wamp_Response::set_Json(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Response_set_Json_m8B200462D00D107744D54E7FD990BB541675D7F9 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		// public string Json { get; set; }
		String_t* L_0 = ___value0;
		__this->set_U3CJsonU3Ek__BackingField_4(L_0);
		return;
	}
}
// System.Void Wamp_Response::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5 (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_TimeoutException::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TimeoutException__ctor_m2AD6BA4E69FE5415F5E571171A0346292B84E0D4 (TimeoutException_t1CB902C3079D0EDB762D1C95D561A204147AA3D0 * __this, String_t* ___message0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TimeoutException__ctor_m2AD6BA4E69FE5415F5E571171A0346292B84E0D4_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// : base(message)
		String_t* L_0 = ___message0;
		IL2CPP_RUNTIME_CLASS_INIT(Exception_t_il2cpp_TypeInfo_var);
		Exception__ctor_m89BADFF36C3B170013878726E07729D51AA9FBE0(__this, L_0, /*hidden argument*/NULL);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Wamp_WampNotConnectedException::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD (WampNotConnectedException_t099477213FD9E80BB53EA60D814EABC6918A709F * __this, String_t* ___message0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// : base(message)
		String_t* L_0 = ___message0;
		IL2CPP_RUNTIME_CLASS_INIT(Exception_t_il2cpp_TypeInfo_var);
		Exception__ctor_m89BADFF36C3B170013878726E07729D51AA9FBE0(__this, L_0, /*hidden argument*/NULL);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WaqlArgs::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WaqlArgs__ctor_m544A7F4EE9BF592CCB63E265D4E5903CEB3D8FEA (WaqlArgs_t5604E26ED22F0E7787E1D7B4CF81594F2E72FEFE * __this, String_t* ___query0, const RuntimeMethod* method)
{
	{
		// public WaqlArgs(string query)
		Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9(__this, /*hidden argument*/NULL);
		// waql = query;
		String_t* L_0 = ___query0;
		__this->set_waql_0(L_0);
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WwiseChildModifiedInfo::ParseInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseChildModifiedInfo_ParseInfo_mCC9AAA37701E3D17396ABB487C44B6851557EA3F (WwiseChildModifiedInfo_t3C189D93FA4E1E9D3E7798FA5FF9644BA5241B7D * __this, const RuntimeMethod* method)
{
	{
		// parentInfo = parent;
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_0 = __this->get_parent_0();
		WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  L_1 = WwiseObjectInfoJsonObject_op_Implicit_m891DE29A29F2BBD51786E3473155DB4938678A0B(L_0, /*hidden argument*/NULL);
		__this->set_parentInfo_2(L_1);
		// childInfo = child;
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_2 = __this->get_child_1();
		WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  L_3 = WwiseObjectInfoJsonObject_op_Implicit_m891DE29A29F2BBD51786E3473155DB4938678A0B(L_2, /*hidden argument*/NULL);
		__this->set_childInfo_3(L_3);
		// }
		return;
	}
}
// System.Void WwiseChildModifiedInfo::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseChildModifiedInfo__ctor_mA594FC7B5DD5E56C707F3BDFB1F60BE443BF3DF0 (WwiseChildModifiedInfo_t3C189D93FA4E1E9D3E7798FA5FF9644BA5241B7D * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: WwiseObjectInfo
IL2CPP_EXTERN_C void WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshal_pinvoke(const WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562& unmarshaled, WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshaled_pinvoke& marshaled)
{
	marshaled.___objectGUID_0 = unmarshaled.get_objectGUID_0();
	marshaled.___parentID_1 = unmarshaled.get_parentID_1();
	marshaled.___name_2 = il2cpp_codegen_marshal_string(unmarshaled.get_name_2());
	marshaled.___type_3 = unmarshaled.get_type_3();
	marshaled.___childrenCount_4 = unmarshaled.get_childrenCount_4();
	marshaled.___path_5 = il2cpp_codegen_marshal_string(unmarshaled.get_path_5());
	marshaled.___workUnitType_6 = il2cpp_codegen_marshal_string(unmarshaled.get_workUnitType_6());
	marshaled.___filePath_7 = il2cpp_codegen_marshal_string(unmarshaled.get_filePath_7());
	marshaled.___soundbankBnkFilePath_8 = il2cpp_codegen_marshal_string(unmarshaled.get_soundbankBnkFilePath_8());
}
IL2CPP_EXTERN_C void WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshal_pinvoke_back(const WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshaled_pinvoke& marshaled, WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562& unmarshaled)
{
	Guid_t  unmarshaled_objectGUID_temp_0;
	memset((&unmarshaled_objectGUID_temp_0), 0, sizeof(unmarshaled_objectGUID_temp_0));
	unmarshaled_objectGUID_temp_0 = marshaled.___objectGUID_0;
	unmarshaled.set_objectGUID_0(unmarshaled_objectGUID_temp_0);
	Guid_t  unmarshaled_parentID_temp_1;
	memset((&unmarshaled_parentID_temp_1), 0, sizeof(unmarshaled_parentID_temp_1));
	unmarshaled_parentID_temp_1 = marshaled.___parentID_1;
	unmarshaled.set_parentID_1(unmarshaled_parentID_temp_1);
	unmarshaled.set_name_2(il2cpp_codegen_marshal_string_result(marshaled.___name_2));
	int32_t unmarshaled_type_temp_3 = 0;
	unmarshaled_type_temp_3 = marshaled.___type_3;
	unmarshaled.set_type_3(unmarshaled_type_temp_3);
	int32_t unmarshaled_childrenCount_temp_4 = 0;
	unmarshaled_childrenCount_temp_4 = marshaled.___childrenCount_4;
	unmarshaled.set_childrenCount_4(unmarshaled_childrenCount_temp_4);
	unmarshaled.set_path_5(il2cpp_codegen_marshal_string_result(marshaled.___path_5));
	unmarshaled.set_workUnitType_6(il2cpp_codegen_marshal_string_result(marshaled.___workUnitType_6));
	unmarshaled.set_filePath_7(il2cpp_codegen_marshal_string_result(marshaled.___filePath_7));
	unmarshaled.set_soundbankBnkFilePath_8(il2cpp_codegen_marshal_string_result(marshaled.___soundbankBnkFilePath_8));
}
// Conversion method for clean up from marshalling of: WwiseObjectInfo
IL2CPP_EXTERN_C void WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshal_pinvoke_cleanup(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshaled_pinvoke& marshaled)
{
	il2cpp_codegen_marshal_free(marshaled.___name_2);
	marshaled.___name_2 = NULL;
	il2cpp_codegen_marshal_free(marshaled.___path_5);
	marshaled.___path_5 = NULL;
	il2cpp_codegen_marshal_free(marshaled.___workUnitType_6);
	marshaled.___workUnitType_6 = NULL;
	il2cpp_codegen_marshal_free(marshaled.___filePath_7);
	marshaled.___filePath_7 = NULL;
	il2cpp_codegen_marshal_free(marshaled.___soundbankBnkFilePath_8);
	marshaled.___soundbankBnkFilePath_8 = NULL;
}
// Conversion methods for marshalling of: WwiseObjectInfo
IL2CPP_EXTERN_C void WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshal_com(const WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562& unmarshaled, WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshaled_com& marshaled)
{
	marshaled.___objectGUID_0 = unmarshaled.get_objectGUID_0();
	marshaled.___parentID_1 = unmarshaled.get_parentID_1();
	marshaled.___name_2 = il2cpp_codegen_marshal_bstring(unmarshaled.get_name_2());
	marshaled.___type_3 = unmarshaled.get_type_3();
	marshaled.___childrenCount_4 = unmarshaled.get_childrenCount_4();
	marshaled.___path_5 = il2cpp_codegen_marshal_bstring(unmarshaled.get_path_5());
	marshaled.___workUnitType_6 = il2cpp_codegen_marshal_bstring(unmarshaled.get_workUnitType_6());
	marshaled.___filePath_7 = il2cpp_codegen_marshal_bstring(unmarshaled.get_filePath_7());
	marshaled.___soundbankBnkFilePath_8 = il2cpp_codegen_marshal_bstring(unmarshaled.get_soundbankBnkFilePath_8());
}
IL2CPP_EXTERN_C void WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshal_com_back(const WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshaled_com& marshaled, WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562& unmarshaled)
{
	Guid_t  unmarshaled_objectGUID_temp_0;
	memset((&unmarshaled_objectGUID_temp_0), 0, sizeof(unmarshaled_objectGUID_temp_0));
	unmarshaled_objectGUID_temp_0 = marshaled.___objectGUID_0;
	unmarshaled.set_objectGUID_0(unmarshaled_objectGUID_temp_0);
	Guid_t  unmarshaled_parentID_temp_1;
	memset((&unmarshaled_parentID_temp_1), 0, sizeof(unmarshaled_parentID_temp_1));
	unmarshaled_parentID_temp_1 = marshaled.___parentID_1;
	unmarshaled.set_parentID_1(unmarshaled_parentID_temp_1);
	unmarshaled.set_name_2(il2cpp_codegen_marshal_bstring_result(marshaled.___name_2));
	int32_t unmarshaled_type_temp_3 = 0;
	unmarshaled_type_temp_3 = marshaled.___type_3;
	unmarshaled.set_type_3(unmarshaled_type_temp_3);
	int32_t unmarshaled_childrenCount_temp_4 = 0;
	unmarshaled_childrenCount_temp_4 = marshaled.___childrenCount_4;
	unmarshaled.set_childrenCount_4(unmarshaled_childrenCount_temp_4);
	unmarshaled.set_path_5(il2cpp_codegen_marshal_bstring_result(marshaled.___path_5));
	unmarshaled.set_workUnitType_6(il2cpp_codegen_marshal_bstring_result(marshaled.___workUnitType_6));
	unmarshaled.set_filePath_7(il2cpp_codegen_marshal_bstring_result(marshaled.___filePath_7));
	unmarshaled.set_soundbankBnkFilePath_8(il2cpp_codegen_marshal_bstring_result(marshaled.___soundbankBnkFilePath_8));
}
// Conversion method for clean up from marshalling of: WwiseObjectInfo
IL2CPP_EXTERN_C void WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshal_com_cleanup(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562_marshaled_com& marshaled)
{
	il2cpp_codegen_marshal_free_bstring(marshaled.___name_2);
	marshaled.___name_2 = NULL;
	il2cpp_codegen_marshal_free_bstring(marshaled.___path_5);
	marshaled.___path_5 = NULL;
	il2cpp_codegen_marshal_free_bstring(marshaled.___workUnitType_6);
	marshaled.___workUnitType_6 = NULL;
	il2cpp_codegen_marshal_free_bstring(marshaled.___filePath_7);
	marshaled.___filePath_7 = NULL;
	il2cpp_codegen_marshal_free_bstring(marshaled.___soundbankBnkFilePath_8);
	marshaled.___soundbankBnkFilePath_8 = NULL;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectInfo WwiseObjectInfoJsonObject::op_Implicit(WwiseObjectInfoJsonObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  WwiseObjectInfoJsonObject_op_Implicit_m891DE29A29F2BBD51786E3473155DB4938678A0B (WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * ___info0, const RuntimeMethod* method)
{
	{
		// return ToObjectInfo(info);
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_0 = ___info0;
		WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  L_1 = WwiseObjectInfoJsonObject_ToObjectInfo_m34217D48C83C57B40D1772E3C02CA43DCAE739E1(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// WwiseObjectInfo WwiseObjectInfoJsonObject::ToObjectInfo(WwiseObjectInfoJsonObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  WwiseObjectInfoJsonObject_ToObjectInfo_m34217D48C83C57B40D1772E3C02CA43DCAE739E1 (WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * ___info0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (WwiseObjectInfoJsonObject_ToObjectInfo_m34217D48C83C57B40D1772E3C02CA43DCAE739E1_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	Guid_t  V_2;
	memset((&V_2), 0, sizeof(V_2));
	Guid_t  V_3;
	memset((&V_3), 0, sizeof(V_3));
	WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  V_4;
	memset((&V_4), 0, sizeof(V_4));
	String_t* G_B3_0 = NULL;
	String_t* G_B5_0 = NULL;
	String_t* G_B4_0 = NULL;
	String_t* G_B6_0 = NULL;
	String_t* G_B6_1 = NULL;
	Guid_t  G_B9_0;
	memset((&G_B9_0), 0, sizeof(G_B9_0));
	Guid_t  G_B12_0;
	memset((&G_B12_0), 0, sizeof(G_B12_0));
	{
		// var type = info.type == null ? "" : info.type;
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_0 = ___info0;
		NullCheck(L_0);
		String_t* L_1 = L_0->get_type_3();
		if (!L_1)
		{
			goto IL_0010;
		}
	}
	{
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_2 = ___info0;
		NullCheck(L_2);
		String_t* L_3 = L_2->get_type_3();
		G_B3_0 = L_3;
		goto IL_0015;
	}

IL_0010:
	{
		G_B3_0 = _stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709;
	}

IL_0015:
	{
		// var wutype = info.workunitType == null ? "" : info.workunitType;
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_4 = ___info0;
		NullCheck(L_4);
		String_t* L_5 = L_4->get_workunitType_7();
		G_B4_0 = G_B3_0;
		if (!L_5)
		{
			G_B5_0 = G_B3_0;
			goto IL_0025;
		}
	}
	{
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_6 = ___info0;
		NullCheck(L_6);
		String_t* L_7 = L_6->get_workunitType_7();
		G_B6_0 = L_7;
		G_B6_1 = G_B4_0;
		goto IL_002a;
	}

IL_0025:
	{
		G_B6_0 = _stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709;
		G_B6_1 = G_B5_0;
	}

IL_002a:
	{
		V_0 = G_B6_0;
		// var objectType = WaapiHelper.GetWwiseObjectTypeFromString(type.ToLower(), wutype.ToLower());
		NullCheck(G_B6_1);
		String_t* L_8 = String_ToLower_m5287204D93C9DDC4DF84581ADD756D0FDE2BA5A8(G_B6_1, /*hidden argument*/NULL);
		String_t* L_9 = V_0;
		NullCheck(L_9);
		String_t* L_10 = String_ToLower_m5287204D93C9DDC4DF84581ADD756D0FDE2BA5A8(L_9, /*hidden argument*/NULL);
		int32_t L_11 = WaapiHelper_GetWwiseObjectTypeFromString_m04C5DF50A1EA2E0B0188B3C71B94B2BB406A58DE(L_8, L_10, /*hidden argument*/NULL);
		V_1 = L_11;
		// var parentID = info.parent.id == null ? System.Guid.Empty : System.Guid.Parse(info.parent.id);
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_12 = ___info0;
		NullCheck(L_12);
		WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C * L_13 = L_12->get_parent_1();
		NullCheck(L_13);
		String_t* L_14 = L_13->get_id_0();
		if (!L_14)
		{
			goto IL_005b;
		}
	}
	{
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_15 = ___info0;
		NullCheck(L_15);
		WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C * L_16 = L_15->get_parent_1();
		NullCheck(L_16);
		String_t* L_17 = L_16->get_id_0();
		IL2CPP_RUNTIME_CLASS_INIT(Guid_t_il2cpp_TypeInfo_var);
		Guid_t  L_18 = Guid_Parse_m665C7B8218EE95A0F8296F722CBA88C33E4C1286(L_17, /*hidden argument*/NULL);
		G_B9_0 = L_18;
		goto IL_0060;
	}

IL_005b:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Guid_t_il2cpp_TypeInfo_var);
		Guid_t  L_19 = ((Guid_t_StaticFields*)il2cpp_codegen_static_fields_for(Guid_t_il2cpp_TypeInfo_var))->get_Empty_0();
		G_B9_0 = L_19;
	}

IL_0060:
	{
		V_2 = G_B9_0;
		// var objectGuid = info.id == null ? System.Guid.Empty : System.Guid.Parse(info.id);
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_20 = ___info0;
		NullCheck(L_20);
		String_t* L_21 = L_20->get_id_0();
		if (!L_21)
		{
			goto IL_0076;
		}
	}
	{
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_22 = ___info0;
		NullCheck(L_22);
		String_t* L_23 = L_22->get_id_0();
		IL2CPP_RUNTIME_CLASS_INIT(Guid_t_il2cpp_TypeInfo_var);
		Guid_t  L_24 = Guid_Parse_m665C7B8218EE95A0F8296F722CBA88C33E4C1286(L_23, /*hidden argument*/NULL);
		G_B12_0 = L_24;
		goto IL_007b;
	}

IL_0076:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Guid_t_il2cpp_TypeInfo_var);
		Guid_t  L_25 = ((Guid_t_StaticFields*)il2cpp_codegen_static_fields_for(Guid_t_il2cpp_TypeInfo_var))->get_Empty_0();
		G_B12_0 = L_25;
	}

IL_007b:
	{
		V_3 = G_B12_0;
		// return new WwiseObjectInfo
		// {
		//     objectGUID = objectGuid,
		//     name = info.name,
		//     type = objectType,
		//     childrenCount = info.childrenCount,
		//     path = info.path,
		//     workUnitType = wutype,
		//     parentID = parentID,
		//     filePath = info.filePath,
		//     soundbankBnkFilePath = info.soundbankBnkFilePath
		// };
		il2cpp_codegen_initobj((&V_4), sizeof(WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562 ));
		Guid_t  L_26 = V_3;
		(&V_4)->set_objectGUID_0(L_26);
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_27 = ___info0;
		NullCheck(L_27);
		String_t* L_28 = L_27->get_name_2();
		(&V_4)->set_name_2(L_28);
		int32_t L_29 = V_1;
		(&V_4)->set_type_3(L_29);
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_30 = ___info0;
		NullCheck(L_30);
		int32_t L_31 = L_30->get_childrenCount_4();
		(&V_4)->set_childrenCount_4(L_31);
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_32 = ___info0;
		NullCheck(L_32);
		String_t* L_33 = L_32->get_path_5();
		(&V_4)->set_path_5(L_33);
		String_t* L_34 = V_0;
		(&V_4)->set_workUnitType_6(L_34);
		Guid_t  L_35 = V_2;
		(&V_4)->set_parentID_1(L_35);
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_36 = ___info0;
		NullCheck(L_36);
		String_t* L_37 = L_36->get_filePath_6();
		(&V_4)->set_filePath_7(L_37);
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_38 = ___info0;
		NullCheck(L_38);
		String_t* L_39 = L_38->get_soundbankBnkFilePath_8();
		(&V_4)->set_soundbankBnkFilePath_8(L_39);
		WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  L_40 = V_4;
		return L_40;
	}
}
// System.Void WwiseObjectInfoJsonObject::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseObjectInfoJsonObject__ctor_mE056E64AC8C8D8AAFE9B9170F0C585EAB59C41E4 (WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WwiseObjectInfoParent::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseObjectInfoParent__ctor_m110C353E41363504B8EDEC82627F90C2E2C3B042 (WwiseObjectInfoParent_tF8609E3E8C2248131341DD9D7C3AB7993BE18D9C * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WwiseRenameInfo::ParseInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseRenameInfo_ParseInfo_m880DD2D586D1EB3FA0D9F776FFC5EC3D24D273E9 (WwiseRenameInfo_t08FA05A48049742662096652F0A5B40DDE5B4C31 * __this, const RuntimeMethod* method)
{
	{
		// objectInfo = @object;
		WwiseObjectInfoJsonObject_t341F410400E695AE250FEFD977795F5D96EF0A17 * L_0 = __this->get_object_0();
		WwiseObjectInfo_t38ACAE6325D886BC9C77D6D3D596E24A5BEAF562  L_1 = WwiseObjectInfoJsonObject_op_Implicit_m891DE29A29F2BBD51786E3473155DB4938678A0B(L_0, /*hidden argument*/NULL);
		__this->set_objectInfo_3(L_1);
		// }
		return;
	}
}
// System.Void WwiseRenameInfo::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseRenameInfo__ctor_mBF30859A831A058DA2650F3A26FDE0A8A05D387C (WwiseRenameInfo_t08FA05A48049742662096652F0A5B40DDE5B4C31 * __this, const RuntimeMethod* method)
{
	{
		JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ak__ctor_m4CCD374F6B1B80939DDEB64410380F8276567A04 (ak_tF511177EEAEB475EB78D68D19AE992F862CBB2A6 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_soundengine::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void soundengine__ctor_m778F4A903981C95FAA549572CDECF65718F23DA2 (soundengine_t694E3972DE713D444B64B412B97B7108DC843BA2 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_soundengine_error::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void error__ctor_m5EF13877DC4D3C647104FBDFD35EE8B6D0EB64ED (error_tCDE597E016300C016A3FEE568638DC713C2EDF61 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void wwise__ctor_mAE8FD2766A53D97BFDE8CD14CF3B24CB3FEAD75B (wwise_t7068E32CB53B72B95D1B19CE31764F556F895B73 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void core__ctor_m24159AE4D5D557A37BDF540FCC663BED6147570B (core_t2A82E032B006312497032C96741453A5F70ECA74 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_audio::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void audio__ctor_mF922E2E8C239A88D888086B06F87FC529C503D01 (audio_t47E4E106B54C9DF68C91887F06C3898310F2C0F3 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_audioSourcePeaks::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void audioSourcePeaks__ctor_m07D467395B57BAB41B1235BAE2B4FF8B886D308B (audioSourcePeaks_t503D3CB9E73B4338F31A0060F5008944D2B4E1D7 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_log::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void log__ctor_m485D5E6FB1903986784B38CEA94427D01935B879 (log_tA74FD121C946B190C887AEDDF632EFE00D4F8C8C * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void object__ctor_mFF98DACF238902E34662AD50F77C08F3875CED9B (object_t0FDE90CA89444F5B6103DBBE4484C4C404CBEF13 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_plugin::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void plugin__ctor_m6B4FEED0E6B049E3FCF16E30E969DE368E5EA27C (plugin_t6477174149106EA1CA08712CEDFAC6028FDC5DE4 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_profiler::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void profiler__ctor_m306EDAFFF696F2316D7557773B4F687628FE6172 (profiler_tB89DC98B050F1E087FB89C6DDB20BC381FB7CA65 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_project::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void project__ctor_m112A63E590C0FAD5D2A6F8671CB5BCB1936216FF (project_t245E31FDE836DE1D2F40961C29EE21036450FC8A * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_remote::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void remote__ctor_m4C7E168CA675D3670936EA3EE26E2340EADD9E08 (remote_t4C4F4EEBAC03CF408E3C74E936EC87563F2FEA09 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_soundbank::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void soundbank__ctor_m1093997F74590CE7BE5D9B09F00DB9F020D4C9CA (soundbank_tCC9926C7815C27A6209BB97EA23E27B302300771 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_switchContainer::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void switchContainer__ctor_mBDFC5656C40D496C935DD9EB44DC8E9785D4A1B6 (switchContainer_tDDDB01C44DF50EFEF268CA874FCD80FE21B0E346 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_transport::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void transport__ctor_m3088AFFE35D7789AD23F28029AB01056BC61A11E (transport_tB8EF7287199C52452B7B8154131F2B26537C1905 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_core_undo::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void undo__ctor_m54D7581967508052F793083F65C79E557FCE63BF (undo_t5CF6EE76079FD0E24252206687B55766055EAB46 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_debug::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void debug__ctor_mCBB981BB13DDEF0417374FF4CF37634B3ABAC21A (debug_t829D0F86B78CE3E43CF489CD32C09DAB255C271E * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_error::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void error__ctor_mC47AF26531BD56F5DBC1F468ACA52DDA48343DD2 (error_tCD7560328D4A46FEB23E1B161450E7A6F8107172 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_ui::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ui__ctor_mD5687B037A197EC6E76881FE770C1EA849198557 (ui_t294C9D5BA24A6473CA0945190027352134FD517A * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_ui_commands::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void commands__ctor_m8A2579EC170A22A576E6EB9ED20D348379274E9A (commands_tFC4F4BB98976F182CFEA291E7E8962B7AB92B0E7 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_ui_project::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void project__ctor_m903C2B2559D6309AECD7E44FECC67BB3BD1DC8D2 (project_tC709A78C52B6A1C3E7E4A3F46A84163E22F00868 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void ak_wwise_waapi::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void waapi__ctor_mC4EE7EDAC8B3597585CE9FD06822EE98E7F3820F (waapi_tB7251965C2BF8D27DD071A5757C5A547D41EED68 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// public Messages MessageId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CMessageIdU3Ek__BackingField_0(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// public int RequestId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CRequestIdU3Ek__BackingField_1(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31_inline (Capture_tF4475248CCF3EFF914844BE2C993FC609D41DB73 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__index_1();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018_inline (String_t* __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_m_stringLength_0();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_Json_m8B200462D00D107744D54E7FD990BB541675D7F9_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		// public string Json { get; set; }
		String_t* L_0 = ___value0;
		__this->set_U3CJsonU3Ek__BackingField_4(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_SubscriptionId_m160D966B5D30F42BF0D5C133AA49CC14B62ED853_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, uint32_t ___value0, const RuntimeMethod* method)
{
	{
		// public uint SubscriptionId { get; set; }
		uint32_t L_0 = ___value0;
		__this->set_U3CSubscriptionIdU3Ek__BackingField_3(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void Response_set_ContextSpecificResultId_m4E0BD596C10376CFFFD141BF47A2322DBF18D760_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// public int ContextSpecificResultId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CContextSpecificResultIdU3Ek__BackingField_2(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t Response_get_ContextSpecificResultId_m8C53A20C58BACF5A2DA2379A42D2818F283CF862_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public int ContextSpecificResultId { get; set; }
		int32_t L_0 = __this->get_U3CContextSpecificResultIdU3Ek__BackingField_2();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR String_t* Response_get_Json_m344AA62580A8B48CEECF9F5A9B33638D572B785B_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public string Json { get; set; }
		String_t* L_0 = __this->get_U3CJsonU3Ek__BackingField_4();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155 * Task_get_Factory_m31F1298E08390A4AD46B85AB060F1FAD4CE12112_inline (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Task_get_Factory_m31F1298E08390A4AD46B85AB060F1FAD4CE12112Ak_Wwise_Api_WAAPI_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_il2cpp_TypeInfo_var);
		TaskFactory_tF3C6D983390ACFB40B4979E225368F78006D6155 * L_0 = ((Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_StaticFields*)il2cpp_codegen_static_fields_for(Task_t1F48C203E163126EBC69ACCA679D1A462DEE9EB2_il2cpp_TypeInfo_var))->get_s_factory_3();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t Response_get_MessageId_mC397D82D70FC4A2DC73186D1CADF3ADF34CEE0D7_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public Messages MessageId { get; set; }
		int32_t L_0 = __this->get_U3CMessageIdU3Ek__BackingField_0();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR Exception_t * Exception_get_InnerException_mCB68CC8CBF2540EF381CB17A4E4E3F6D0E33453F_inline (Exception_t * __this, const RuntimeMethod* method)
{
	{
		Exception_t * L_0 = __this->get__innerException_4();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t WebSocketException_get_WebSocketErrorCode_m7AC07357E5C368E87BB9C4E16A6F9BF46FBF14CD_inline (WebSocketException_t9E62BA3E25FCDFF862D14645F13CFDCCADFF682B * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get__webSocketErrorCode_20();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t Response_get_RequestId_m839528D15AAC4BC39EAEB22669F38B75140A0C05_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public int RequestId { get; set; }
		int32_t L_0 = __this->get_U3CRequestIdU3Ek__BackingField_1();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR int32_t WebSocketReceiveResult_get_Count_m2C308CD164D4199DACE7613DC7E8DC1F5E66DF65_inline (WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_U3CCountU3Ek__BackingField_0();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool WebSocketReceiveResult_get_EndOfMessage_m18C6588C6F9FC235BEC84AA7572B7F49C5E6BEB9_inline (WebSocketReceiveResult_t5AB5305DD415041B3EB61E67A99D2A0A8418DCF5 * __this, const RuntimeMethod* method)
{
	{
		bool L_0 = __this->get_U3CEndOfMessageU3Ek__BackingField_1();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR uint32_t Response_get_SubscriptionId_m38F262E5543B6AA4EB3EDDB8A8F1365B84284383_inline (Response_t4BA078FE2173CC0683583DCEE786806DAAD9C4F8 * __this, const RuntimeMethod* method)
{
	{
		// public uint SubscriptionId { get; set; }
		uint32_t L_0 = __this->get_U3CSubscriptionIdU3Ek__BackingField_3();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void ErrorException_set_Json_m63B27B2FF42F2763E1B259F6CAA1B1813839D6EC_inline (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		// internal string Json { get; set; }
		String_t* L_0 = ___value0;
		__this->set_U3CJsonU3Ek__BackingField_17(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void ErrorException_set_MessageId_mB2E895A07D439F8EB5C11D1E02EEC602FC84DAB1_inline (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// internal Messages MessageId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CMessageIdU3Ek__BackingField_18(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void ErrorException_set_RequestId_m141F6E4AA9228ECD9320038A3FC7D0633DDD53A9_inline (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		// internal int RequestId { get; set; }
		int32_t L_0 = ___value0;
		__this->set_U3CRequestIdU3Ek__BackingField_19(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void ErrorException_set_Uri_mEFBFD6E03D38DA354BB53E6DA1467A6E1F97BE90_inline (ErrorException_tA048E630A80B38EBB3F4966D770D69FE3C422F46 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		// internal string Uri { get; set; }
		String_t* L_0 = ___value0;
		__this->set_U3CUriU3Ek__BackingField_20(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * TaskCompletionSource_1_get_Task_mE3DDBDE4F3FB8A530456D158F4C460E85A4974B9_gshared_inline (TaskCompletionSource_1_t6C02642279BC7BF03091A8CB685FC6B4E68BED12 * __this, const RuntimeMethod* method)
{
	{
		Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 * L_0 = (Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 *)__this->get_m_task_0();
		return (Task_1_tA56001ED5270173CA1432EDFCD84EABB1024BC09 *)L_0;
	}
}
IL2CPP_EXTERN_C inline IL2CPP_METHOD_ATTR int32_t ArraySegment_1_get_Offset_m6651443913CC50A02AE5D7C4CDC6F6744D39B483_gshared_inline (ArraySegment_1_t5B17204266E698CC035E2A7F6435A4F78286D0FA * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = (int32_t)__this->get__offset_1();
		return (int32_t)L_0;
	}
}
