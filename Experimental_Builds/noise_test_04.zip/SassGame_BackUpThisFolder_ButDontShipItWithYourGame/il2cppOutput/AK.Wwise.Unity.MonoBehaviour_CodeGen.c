﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void AkMultiPosEvent::FinishedPlaying(System.Object,AkCallbackType,System.Object)
extern void AkMultiPosEvent_FinishedPlaying_m37A44F0E44FAD6A38DC68DF5281B2D823FF8C772 (void);
// 0x00000002 System.Void AkMultiPosEvent::.ctor()
extern void AkMultiPosEvent__ctor_mD90BA3EAA1236EC6A175AED1F68D541C369DA1DD (void);
// 0x00000003 System.Void AkAmbient::OnEnable()
extern void AkAmbient_OnEnable_m32AC458163E555319B2726135E48334394216E7A (void);
// 0x00000004 System.Void AkAmbient::Start()
extern void AkAmbient_Start_mD09C271BE59E7B58C2B67F6AFE86E748964E56E8 (void);
// 0x00000005 System.Void AkAmbient::OnDisable()
extern void AkAmbient_OnDisable_m24F93BB234BCA9384A19AA3115D35692A7804434 (void);
// 0x00000006 System.Void AkAmbient::HandleEvent(UnityEngine.GameObject)
extern void AkAmbient_HandleEvent_mB69FB92C646765A447505A56F186614559D07B2C (void);
// 0x00000007 System.Void AkAmbient::OnDrawGizmosSelected()
extern void AkAmbient_OnDrawGizmosSelected_m0900783AE6B75B6354B69FE2D680A62326AD44B1 (void);
// 0x00000008 AkPositionArray AkAmbient::BuildMultiDirectionArray(AkMultiPosEvent)
extern void AkAmbient_BuildMultiDirectionArray_m4995F264D274366BCACCC17EBCDCD787C0A6616A (void);
// 0x00000009 AkPositionArray AkAmbient::BuildAkPositionArray()
extern void AkAmbient_BuildAkPositionArray_m69A0C96B894AD54B91DB0150D8EFEAEA33FC8BCA (void);
// 0x0000000A System.Void AkAmbient::.ctor()
extern void AkAmbient__ctor_m7E9617B2ED9CEE2C439118FC6EFD045CDF241B54 (void);
// 0x0000000B System.Void AkAmbient::.cctor()
extern void AkAmbient__cctor_m002C02152E253E8A20ED47521088A62E0D4D85CA (void);
// 0x0000000C UnityEngine.Vector3 AkAmbientLargeModePositioner::get_Position()
extern void AkAmbientLargeModePositioner_get_Position_mC0E0BEE7B64241819CBF9947A6C7126AA7FF0006 (void);
// 0x0000000D UnityEngine.Vector3 AkAmbientLargeModePositioner::get_Forward()
extern void AkAmbientLargeModePositioner_get_Forward_m807ACC4874C064FFE2C4BA28C34A681363F46B46 (void);
// 0x0000000E UnityEngine.Vector3 AkAmbientLargeModePositioner::get_Up()
extern void AkAmbientLargeModePositioner_get_Up_mCC494E3357CB23891B417722811D733B4F3E91E1 (void);
// 0x0000000F System.Void AkAmbientLargeModePositioner::.ctor()
extern void AkAmbientLargeModePositioner__ctor_mC6AE6D073AA795F2D1B35C10B20799D5F34667A5 (void);
// 0x00000010 AkAudioListener_DefaultListenerList AkAudioListener::get_DefaultListeners()
extern void AkAudioListener_get_DefaultListeners_m8A9D788B6673EC14C32D44ED5798C17E0CEF7CDE (void);
// 0x00000011 System.Void AkAudioListener::StartListeningToEmitter(AkGameObj)
extern void AkAudioListener_StartListeningToEmitter_m9A510F9C38E147779CD40B1B86948F50C9D09A6E (void);
// 0x00000012 System.Void AkAudioListener::StopListeningToEmitter(AkGameObj)
extern void AkAudioListener_StopListeningToEmitter_m5D0DD95DFEB9113CEC970AF926122C7E780F364A (void);
// 0x00000013 System.Void AkAudioListener::SetIsDefaultListener(System.Boolean)
extern void AkAudioListener_SetIsDefaultListener_mBB648B2B9F10D48EE3B4548C3EB025DFFFB8772E (void);
// 0x00000014 System.Void AkAudioListener::Awake()
extern void AkAudioListener_Awake_mF9B0527790404DC52105F52C4B37AC26E368064A (void);
// 0x00000015 System.Void AkAudioListener::OnEnable()
extern void AkAudioListener_OnEnable_m5BFAA659BAC9FBF5F4E214A8444B7EB77ADDBFD6 (void);
// 0x00000016 System.Void AkAudioListener::OnDisable()
extern void AkAudioListener_OnDisable_mC8FD57411FDB15993480A3DCD46FA0E9FDBAB42B (void);
// 0x00000017 System.Void AkAudioListener::Update()
extern void AkAudioListener_Update_m0F1848C440D6603D52D0BC2CA498DEA04F264918 (void);
// 0x00000018 System.UInt64 AkAudioListener::GetAkGameObjectID()
extern void AkAudioListener_GetAkGameObjectID_m63945B83EC3C102624C2D8BE6794D4E4CFB7C2BA (void);
// 0x00000019 System.Void AkAudioListener::Migrate14()
extern void AkAudioListener_Migrate14_m00AAFAADD31C4DCF00DD27B38CF160F6E6EFE2F3 (void);
// 0x0000001A System.Void AkAudioListener::.ctor()
extern void AkAudioListener__ctor_mDE8A2FA8B52DDC3C74FD18D75BF5F4C15C2A24F8 (void);
// 0x0000001B System.Void AkAudioListener::.cctor()
extern void AkAudioListener__cctor_mA87F6C07917CF590935E5D89CB729A37FC4FCC74 (void);
// 0x0000001C System.Void AkBank::Awake()
extern void AkBank_Awake_mAC373310C7E2B1A9B595C08729E68381DFE8625A (void);
// 0x0000001D System.Void AkBank::Start()
extern void AkBank_Start_mE512EB9F712BE29CD0E48E4522BD32D2D52FBB3A (void);
// 0x0000001E System.Void AkBank::HandleEvent(UnityEngine.GameObject)
extern void AkBank_HandleEvent_m9D79FF000AAC28ACD6E267CC768322835AE8E540 (void);
// 0x0000001F System.Void AkBank::UnloadBank(UnityEngine.GameObject)
extern void AkBank_UnloadBank_m1630FBE54D4A14081B6609D8220C0607455788D3 (void);
// 0x00000020 System.Void AkBank::OnDestroy()
extern void AkBank_OnDestroy_m09824F9A47FC03A31B62E03CBF2ECE106FC18F13 (void);
// 0x00000021 System.String AkBank::get_bankName()
extern void AkBank_get_bankName_mD83A97F7ADA9C1736B66ED242C883F365488CF37 (void);
// 0x00000022 System.Byte[] AkBank::get_valueGuid()
extern void AkBank_get_valueGuid_m210031800B84BED3EEEFED57ABABF1644A19139E (void);
// 0x00000023 System.Void AkBank::.ctor()
extern void AkBank__ctor_m209447EB063141B658188B52F60B85F359E0ACFE (void);
// 0x00000024 System.Void AkEarlyReflections::OnEnable()
extern void AkEarlyReflections_OnEnable_mBEA4DA3EA07C0F04140F0A6889A4BAF9B987DF36 (void);
// 0x00000025 System.Void AkEarlyReflections::SetEarlyReflectionsVolume(System.Single)
extern void AkEarlyReflections_SetEarlyReflectionsVolume_m1AFE6AA63B070F6F91A92AE319D4B7D40F505B31 (void);
// 0x00000026 System.Void AkEarlyReflections::.ctor()
extern void AkEarlyReflections__ctor_m2E9C9D0970DA6860547E2FFA99687D3F646F4AAE (void);
// 0x00000027 System.Void AkEmitterObstructionOcclusion::Awake()
extern void AkEmitterObstructionOcclusion_Awake_m6EF9651669D3D943F77599E502DED4CDC95ECAA3 (void);
// 0x00000028 System.Void AkEmitterObstructionOcclusion::UpdateCurrentListenerList()
extern void AkEmitterObstructionOcclusion_UpdateCurrentListenerList_mE20E36E3DB5F9BECDFF4EA8A376057336E767A75 (void);
// 0x00000029 System.Void AkEmitterObstructionOcclusion::SetObstructionOcclusion(System.Collections.Generic.KeyValuePair`2<AkAudioListener,AkObstructionOcclusion_ObstructionOcclusionValue>)
extern void AkEmitterObstructionOcclusion_SetObstructionOcclusion_m55D990CE937FE58BC3619B9E6A1C7870903643B9 (void);
// 0x0000002A System.Void AkEmitterObstructionOcclusion::.ctor()
extern void AkEmitterObstructionOcclusion__ctor_m64725B3D7AE8EB61DD7DA11F8896C9F77609235A (void);
// 0x0000002B UnityEngine.Collider AkEnvironment::get_Collider()
extern void AkEnvironment_get_Collider_m65877779C993973A6903BEAF09935B9BD2739F20 (void);
// 0x0000002C System.Void AkEnvironment::set_Collider(UnityEngine.Collider)
extern void AkEnvironment_set_Collider_m74D6D33B65662FE4262C96D56FEEB9C5D75FC2A0 (void);
// 0x0000002D System.Void AkEnvironment::Awake()
extern void AkEnvironment_Awake_mD528518CDA793033F2FCFF02A1631E10C46D07DF (void);
// 0x0000002E System.Int32 AkEnvironment::get_m_auxBusID()
extern void AkEnvironment_get_m_auxBusID_m3F932F6BCB85A4E0CA04E34F3E04FBC8503A1EEF (void);
// 0x0000002F System.Byte[] AkEnvironment::get_valueGuid()
extern void AkEnvironment_get_valueGuid_mB600B3770B6F60DB6AC255DD57B224CC97034C03 (void);
// 0x00000030 System.UInt32 AkEnvironment::GetAuxBusID()
extern void AkEnvironment_GetAuxBusID_mEBC073AF9E261C207678BA2C329D142BA42B6089 (void);
// 0x00000031 UnityEngine.Collider AkEnvironment::GetCollider()
extern void AkEnvironment_GetCollider_m53B4616B6885FE53EF40145AF65462841109A571 (void);
// 0x00000032 System.Void AkEnvironment::.ctor()
extern void AkEnvironment__ctor_mA03253B037D55D8C048F2135CE931A5B2D8D7A88 (void);
// 0x00000033 System.Void AkEnvironment::.cctor()
extern void AkEnvironment__cctor_m107990CBEABF324E6EF23BD81C40276145AE8EC0 (void);
// 0x00000034 UnityEngine.BoxCollider AkEnvironmentPortal::get_BoxCollider()
extern void AkEnvironmentPortal_get_BoxCollider_m83328213A0D50DC09236B902254A0085A2C3594F (void);
// 0x00000035 System.Boolean AkEnvironmentPortal::get_EnvironmentsShareAuxBus()
extern void AkEnvironmentPortal_get_EnvironmentsShareAuxBus_m4361CFE583AF13A8CC4B085A3BAC22CA9A24DC8F (void);
// 0x00000036 System.Single AkEnvironmentPortal::GetAuxSendValueForPosition(UnityEngine.Vector3,System.Int32)
extern void AkEnvironmentPortal_GetAuxSendValueForPosition_m12D05EAB9C0F892256484C24305AAF584B256A68 (void);
// 0x00000037 System.Void AkEnvironmentPortal::.ctor()
extern void AkEnvironmentPortal__ctor_mAF885A007BD0C1112562E8EAE7DA35E14E708CF2 (void);
// 0x00000038 System.Void AkEventCallbackMsg::.ctor()
extern void AkEventCallbackMsg__ctor_mFAB96F4DE551C1EE9E07E58B395B6928B92CDBB9 (void);
// 0x00000039 AK.Wwise.BaseType AkEvent::get_WwiseType()
extern void AkEvent_get_WwiseType_m37A2D9A46416A5948166BD698CD3EEC8B22A6A8D (void);
// 0x0000003A System.Void AkEvent::Start()
extern void AkEvent_Start_mA0EDDFEEC00A1FB62DABBA5C202FF01F359C66A5 (void);
// 0x0000003B System.Void AkEvent::Callback(System.Object,AkCallbackType,AkCallbackInfo)
extern void AkEvent_Callback_m10C4A64B658E271C98EFC5FF24D1BEBC0A4C5926 (void);
// 0x0000003C System.Void AkEvent::HandleEvent(UnityEngine.GameObject)
extern void AkEvent_HandleEvent_m36E8AC6AAB31A1EECC0D73B3013439A582CA8468 (void);
// 0x0000003D System.Void AkEvent::Stop(System.Int32)
extern void AkEvent_Stop_mDF5B33DEC0D9CAFC46149F633A4B46715DE6D3AE (void);
// 0x0000003E System.Void AkEvent::Stop(System.Int32,AkCurveInterpolation)
extern void AkEvent_Stop_m25D312C425F9F77F40868E98D286714EEFA4EA83 (void);
// 0x0000003F System.Int32 AkEvent::get_eventID()
extern void AkEvent_get_eventID_mA1A4456F81FF1A21391CB9DDE0CCEC3082263591 (void);
// 0x00000040 System.Byte[] AkEvent::get_valueGuid()
extern void AkEvent_get_valueGuid_m66EAEF0ED85DED18451723B7C0E1EB49F8C24524 (void);
// 0x00000041 AkEventCallbackData AkEvent::get_m_callbackData()
extern void AkEvent_get_m_callbackData_m9C9605B16383F4C765B046B6C5A9CC56CE2C4767 (void);
// 0x00000042 System.Void AkEvent::.ctor()
extern void AkEvent__ctor_mB484C4E01B83DD0F8EFBEA9DFB5934CC1BA96124 (void);
// 0x00000043 System.Void AkEventCallbackData::.ctor()
extern void AkEventCallbackData__ctor_m8B26A9570EBB4A31F7F8B1703CA1F90071E61440 (void);
// 0x00000044 System.Boolean AkGameObj::get_IsUsingDefaultListeners()
extern void AkGameObj_get_IsUsingDefaultListeners_m41B4A13AA2E890D3A824C63775F4FE11BC93EF24 (void);
// 0x00000045 System.Collections.Generic.List`1<AkAudioListener> AkGameObj::get_ListenerList()
extern void AkGameObj_get_ListenerList_m3A2A10C1D0F27EAFB316DA65D8CB228A61D12EAF (void);
// 0x00000046 System.Void AkGameObj::AddListener(AkAudioListener)
extern void AkGameObj_AddListener_m25945DA7041F15026C38290BCCE8EDE3A0830AF6 (void);
// 0x00000047 System.Void AkGameObj::RemoveListener(AkAudioListener)
extern void AkGameObj_RemoveListener_m14B365D68449C766955001558E2E297DA05112E0 (void);
// 0x00000048 AKRESULT AkGameObj::Register()
extern void AkGameObj_Register_m43212BC00196CD9CFCF72ED247048A898A402455 (void);
// 0x00000049 System.Void AkGameObj::SetPosition()
extern void AkGameObj_SetPosition_m41A8CF054D5849F2F9AE182369B8D500B8A767CD (void);
// 0x0000004A System.Void AkGameObj::Awake()
extern void AkGameObj_Awake_mE61143FFA54E34722EBA2A8B80E7C2D4ECA55B0F (void);
// 0x0000004B System.Void AkGameObj::CheckStaticStatus()
extern void AkGameObj_CheckStaticStatus_mE4AB083F44266F2D346C6542E9BBE290201358CB (void);
// 0x0000004C System.Void AkGameObj::OnEnable()
extern void AkGameObj_OnEnable_m80C92A594FCD6F778743E5BB7A578037132E661A (void);
// 0x0000004D System.Void AkGameObj::OnDestroy()
extern void AkGameObj_OnDestroy_mB7EB487F404F5C5866ECBC2BD0FE7F3929C98A6C (void);
// 0x0000004E System.Void AkGameObj::Update()
extern void AkGameObj_Update_mE1097E10C693385D580870AFD8CB703356C3D59F (void);
// 0x0000004F UnityEngine.Vector3 AkGameObj::GetPosition()
extern void AkGameObj_GetPosition_m5F679DD514CEDF221425EC2B4955B4CDD350AC37 (void);
// 0x00000050 UnityEngine.Vector3 AkGameObj::GetForward()
extern void AkGameObj_GetForward_m5FA54A2DFAEF77E43F7DC6197A3449FC296F3282 (void);
// 0x00000051 UnityEngine.Vector3 AkGameObj::GetUpward()
extern void AkGameObj_GetUpward_mC92637671394080B7F6B14CA62768A0781B2ABE3 (void);
// 0x00000052 System.Void AkGameObj::OnTriggerEnter(UnityEngine.Collider)
extern void AkGameObj_OnTriggerEnter_mA1B9D531D0117521BF0C29FDD1D428BE7DD37396 (void);
// 0x00000053 System.Void AkGameObj::OnTriggerExit(UnityEngine.Collider)
extern void AkGameObj_OnTriggerExit_m5E43A91077AB9C2DC7FAEE12DF77E08CAAF1CB4F (void);
// 0x00000054 System.Void AkGameObj::.ctor()
extern void AkGameObj__ctor_m5F41909A0208EBAE7B6BA82CDD9345C821330832 (void);
// 0x00000055 System.Void AkGameObjEnvironmentData::AddHighestPriorityEnvironmentsFromPortals(UnityEngine.Vector3)
extern void AkGameObjEnvironmentData_AddHighestPriorityEnvironmentsFromPortals_m538ECAF34C5C4CA576365F7CD6009AC995C48A6F (void);
// 0x00000056 System.Void AkGameObjEnvironmentData::AddHighestPriorityEnvironments(UnityEngine.Vector3)
extern void AkGameObjEnvironmentData_AddHighestPriorityEnvironments_m923F9CE6779925A9454AF822DFEBEA17EDDC4A18 (void);
// 0x00000057 System.Void AkGameObjEnvironmentData::UpdateAuxSend(UnityEngine.GameObject,UnityEngine.Vector3)
extern void AkGameObjEnvironmentData_UpdateAuxSend_m34C4C4BBE36712BF9110F70DF80C7BA145711701 (void);
// 0x00000058 System.Void AkGameObjEnvironmentData::TryAddEnvironment(AkEnvironment)
extern void AkGameObjEnvironmentData_TryAddEnvironment_mC3F2B15E1E0F29C104E2ED49C17082FBD4D1112C (void);
// 0x00000059 System.Void AkGameObjEnvironmentData::RemoveEnvironment(AkEnvironment)
extern void AkGameObjEnvironmentData_RemoveEnvironment_mD9DC16225D00E3ABD76947F905744A0EAF6419E3 (void);
// 0x0000005A System.Void AkGameObjEnvironmentData::AddAkEnvironment(UnityEngine.Collider,UnityEngine.Collider)
extern void AkGameObjEnvironmentData_AddAkEnvironment_mF1E4850D28160BD023FABF7177E0BCFE22DCB7FB (void);
// 0x0000005B System.Boolean AkGameObjEnvironmentData::AkEnvironmentBelongsToActivePortals(AkEnvironment)
extern void AkGameObjEnvironmentData_AkEnvironmentBelongsToActivePortals_m61CB7A01ED610F38C94E01A546C7D6DAEA8A8455 (void);
// 0x0000005C System.Void AkGameObjEnvironmentData::RemoveAkEnvironment(UnityEngine.Collider,UnityEngine.Collider)
extern void AkGameObjEnvironmentData_RemoveAkEnvironment_m63564B12BBB75B03B0EC8E0315656C226C36BFC9 (void);
// 0x0000005D System.Void AkGameObjEnvironmentData::.ctor()
extern void AkGameObjEnvironmentData__ctor_m8543FB199B824B823B834DD13107AC110E67F188 (void);
// 0x0000005E System.Void AkGameObjListenerList::SetUseDefaultListeners(System.Boolean)
extern void AkGameObjListenerList_SetUseDefaultListeners_mAB2A789F0BADE7D9BB5D739DCDF2342FCDD5000F (void);
// 0x0000005F System.Void AkGameObjListenerList::Init(AkGameObj)
extern void AkGameObjListenerList_Init_m0A7C7990785864A9AFBF165DB142A869EC7354F7 (void);
// 0x00000060 System.Boolean AkGameObjListenerList::Add(AkAudioListener)
extern void AkGameObjListenerList_Add_m9E894412F89DDA978ECA0E5502B783EB0BA2F59E (void);
// 0x00000061 System.Boolean AkGameObjListenerList::Remove(AkAudioListener)
extern void AkGameObjListenerList_Remove_m90A1F7F27AD7B2D601A97FBB1D1F9CE29944BD79 (void);
// 0x00000062 System.Void AkGameObjListenerList::.ctor()
extern void AkGameObjListenerList__ctor_mD84365C75DC04B85CEFA30D7BDEC4EE5C0448E9E (void);
// 0x00000063 System.Void AkGameObjPosOffsetData::.ctor()
extern void AkGameObjPosOffsetData__ctor_mE60ED5211415BD049398E65AF335C26DA5DEC7A0 (void);
// 0x00000064 System.Void AkGameObjPositionData::.ctor()
extern void AkGameObjPositionData__ctor_mBD2AD04DA13E1899F2E95040BCF19AF67ED9B5E4 (void);
// 0x00000065 System.Void AkGameObjPositionOffsetData::.ctor(System.Boolean)
extern void AkGameObjPositionOffsetData__ctor_m8B1DB67BF486DF7F7CE5785BB12CB7598CBC844B (void);
// 0x00000066 System.Void AkInitializer::Awake()
extern void AkInitializer_Awake_m797D3CB395A3FFD28CAB1E9CDF837F79EAE801FC (void);
// 0x00000067 System.Void AkInitializer::OnEnable()
extern void AkInitializer_OnEnable_m7F88C0768B73CC7C09DA1FD5AE500A1BD01E9E9C (void);
// 0x00000068 System.Void AkInitializer::OnDisable()
extern void AkInitializer_OnDisable_m3C34A35992E9A769A166C5B136D8305F7FB552EC (void);
// 0x00000069 System.Void AkInitializer::OnDestroy()
extern void AkInitializer_OnDestroy_m77067FA4FDE9B2D3A2F089A6306A3AC1131E811D (void);
// 0x0000006A System.Void AkInitializer::OnApplicationPause(System.Boolean)
extern void AkInitializer_OnApplicationPause_m69DC87DD9629FF38A459C0B7B3FEF3C06B1C98F4 (void);
// 0x0000006B System.Void AkInitializer::OnApplicationFocus(System.Boolean)
extern void AkInitializer_OnApplicationFocus_m8A68CEEBC0634B20995501C031C258DC7788EB01 (void);
// 0x0000006C System.Void AkInitializer::OnApplicationQuit()
extern void AkInitializer_OnApplicationQuit_m4E6FBBECF0B77AB088DDC1448D34A96A7858E393 (void);
// 0x0000006D System.Void AkInitializer::LateUpdate()
extern void AkInitializer_LateUpdate_mC6F5F64F755BC395F5ACE9E33516CFD19FEB9CC5 (void);
// 0x0000006E System.Void AkInitializer::.ctor()
extern void AkInitializer__ctor_m42D59A76F989DB32FF7B522DA68911E4B9856E1C (void);
// 0x0000006F System.Void AkMemBankLoader::Start()
extern void AkMemBankLoader_Start_mE10DE98B91637CA52ADA53022BCB9DEFF3C0D34B (void);
// 0x00000070 System.Void AkMemBankLoader::LoadNonLocalizedBank(System.String)
extern void AkMemBankLoader_LoadNonLocalizedBank_m8319D0FBB89CF5681F722B11374EEF66F6D38903 (void);
// 0x00000071 System.Void AkMemBankLoader::LoadLocalizedBank(System.String)
extern void AkMemBankLoader_LoadLocalizedBank_m33063767BA1071624A71D1EC768DF345EF4F263C (void);
// 0x00000072 System.UInt32 AkMemBankLoader::AllocateAlignedBuffer(System.Byte[])
extern void AkMemBankLoader_AllocateAlignedBuffer_mA448AEF21063773C7345A908C8AAD0A79EF3F8BF (void);
// 0x00000073 System.Collections.IEnumerator AkMemBankLoader::LoadFile()
extern void AkMemBankLoader_LoadFile_m95ED610F7B19B780FA65D93C50030D6C1B050D7A (void);
// 0x00000074 System.Void AkMemBankLoader::DoLoadBank(System.String)
extern void AkMemBankLoader_DoLoadBank_m2AD9CFBD62D23BA20D2010F1CD7C285970B41DF6 (void);
// 0x00000075 System.Void AkMemBankLoader::OnDestroy()
extern void AkMemBankLoader_OnDestroy_mA6399B3A4ABD953B69CB15BBBEC886EFE4D5B724 (void);
// 0x00000076 System.Void AkMemBankLoader::.ctor()
extern void AkMemBankLoader__ctor_m62AD76ED8499AC6B71A7D5144B4222C539530CDE (void);
// 0x00000077 System.Void AkObstructionOcclusion::InitIntervalsAndFadeRates()
extern void AkObstructionOcclusion_InitIntervalsAndFadeRates_m910FE747479822278E6E3EE1F5477A75BCB4FDD7 (void);
// 0x00000078 System.Void AkObstructionOcclusion::UpdateCurrentListenerList()
// 0x00000079 System.Void AkObstructionOcclusion::UpdateObstructionOcclusionValues()
extern void AkObstructionOcclusion_UpdateObstructionOcclusionValues_m4C5C339242A4A66AB8C017F7EA0A91B8E40516B5 (void);
// 0x0000007A System.Void AkObstructionOcclusion::CastRays()
extern void AkObstructionOcclusion_CastRays_m7A3AF28F52BEECD1E77463445B2CA46CB91652C8 (void);
// 0x0000007B System.Void AkObstructionOcclusion::SetObstructionOcclusion(System.Collections.Generic.KeyValuePair`2<AkAudioListener,AkObstructionOcclusion_ObstructionOcclusionValue>)
// 0x0000007C System.Void AkObstructionOcclusion::Update()
extern void AkObstructionOcclusion_Update_m10BBECEFD7187140A9B357E14990C3EF2BBC2A4C (void);
// 0x0000007D System.Void AkObstructionOcclusion::.ctor()
extern void AkObstructionOcclusion__ctor_mB234B4257001E2B506747E3487A508933A594E3E (void);
// 0x0000007E System.Void AkRadialEmitter::SetGameObjectOuterRadius(System.Single)
extern void AkRadialEmitter_SetGameObjectOuterRadius_mA30A2279218EDCD881C7DCB2C847B91AE9E68877 (void);
// 0x0000007F System.Void AkRadialEmitter::SetGameObjectInnerRadius(System.Single)
extern void AkRadialEmitter_SetGameObjectInnerRadius_mFACE4CFCDF17CE50A5864DC296DC218232A388B7 (void);
// 0x00000080 System.Void AkRadialEmitter::SetGameObjectRadius(System.Single,System.Single)
extern void AkRadialEmitter_SetGameObjectRadius_mFC075FEA1F37D1441D1703B4F6B5BB61ED2A6502 (void);
// 0x00000081 System.Void AkRadialEmitter::SetGameObjectRadius()
extern void AkRadialEmitter_SetGameObjectRadius_m26C4699A0954A11F3BEBC9C1F7D45E0F690C9AAF (void);
// 0x00000082 System.Void AkRadialEmitter::SetGameObjectRadius(UnityEngine.GameObject)
extern void AkRadialEmitter_SetGameObjectRadius_m5632109F37C604E70089ADBC83A16F71287E4563 (void);
// 0x00000083 System.Void AkRadialEmitter::OnEnable()
extern void AkRadialEmitter_OnEnable_mBDC9A14FE5A60785DD7359FE8FD467DBF4762D61 (void);
// 0x00000084 System.Void AkRadialEmitter::.ctor()
extern void AkRadialEmitter__ctor_mFAC6B10A038B76258CEA79DD0B2A8E4430A6BB15 (void);
// 0x00000085 System.UInt64 AkRoom::GetAkRoomID(AkRoom)
extern void AkRoom_GetAkRoomID_mE221813B9CB262E874A9CF1DEAB1ADFCD16EFE34 (void);
// 0x00000086 System.Int32 AkRoom::get_RoomCount()
extern void AkRoom_get_RoomCount_m18B0D24B5AF666F4D8D64E12F20301FB936AD055 (void);
// 0x00000087 System.Void AkRoom::set_RoomCount(System.Int32)
extern void AkRoom_set_RoomCount_mA822414F0BD8BF4B5F7DDA5A89D0A00042273F3C (void);
// 0x00000088 System.Boolean AkRoom::TryEnter(AkRoomAwareObject)
extern void AkRoom_TryEnter_m8E13FE1FD6DF46E4547DBF1A4F66CA0697B06814 (void);
// 0x00000089 System.Void AkRoom::Exit(AkRoomAwareObject)
extern void AkRoom_Exit_m37AC618E86EAC271D27FF1AA543421C515AAF175 (void);
// 0x0000008A System.UInt64 AkRoom::GetID()
extern void AkRoom_GetID_m4DC1CD4E1D7D1B379BFA314C74E0CE53A249F92E (void);
// 0x0000008B System.Void AkRoom::SetRoom()
extern void AkRoom_SetRoom_m1DF05059A40216631DC5970270FCA972BDEEBB24 (void);
// 0x0000008C UnityEngine.Vector3 AkRoom::GetCapsuleScale(UnityEngine.Vector3,System.Single,System.Single,System.Int32)
extern void AkRoom_GetCapsuleScale_mDF935F777E8AAD1C19033EA5579AC0B400A385F5 (void);
// 0x0000008D System.UInt64 AkRoom::GetGeometryID()
extern void AkRoom_GetGeometryID_mB24BD53DC120BFB23BBB88E0D3FB4F0E1ACF3F2E (void);
// 0x0000008E System.Void AkRoom::OnEnable()
extern void AkRoom_OnEnable_mF86872C3CF676E107A37683AB00ED5873E876605 (void);
// 0x0000008F System.Void AkRoom::OnDisable()
extern void AkRoom_OnDisable_m067BABFC55E57234E9FC879C9802211BE20A29E6 (void);
// 0x00000090 System.Void AkRoom::OnTriggerEnter(UnityEngine.Collider)
extern void AkRoom_OnTriggerEnter_m151069C55CB34BC30431F36573C31A2678AA8734 (void);
// 0x00000091 System.Void AkRoom::OnTriggerExit(UnityEngine.Collider)
extern void AkRoom_OnTriggerExit_m7A71AC04F7682DDE350BDDEFEFB8CB01D7C1D176 (void);
// 0x00000092 System.Void AkRoom::PostRoomTone()
extern void AkRoom_PostRoomTone_mD8B4401166012F846BB17F43FC1AB907D538506E (void);
// 0x00000093 System.Void AkRoom::HandleEvent(UnityEngine.GameObject)
extern void AkRoom_HandleEvent_m4F31412C140538F885BAFB8AD180B84358F6538D (void);
// 0x00000094 System.Single AkRoom::get_wallOcclusion()
extern void AkRoom_get_wallOcclusion_mBCFC280EDBF61012FB6E8D39179C3AAA8ACD09C3 (void);
// 0x00000095 System.Void AkRoom::set_wallOcclusion(System.Single)
extern void AkRoom_set_wallOcclusion_mE252FA53EBF17B801EFEC64B1475103ADC934743 (void);
// 0x00000096 System.Void AkRoom::.ctor()
extern void AkRoom__ctor_m675081BF544042320FF23F6F753E5742AFF46B0A (void);
// 0x00000097 System.Void AkRoom::.cctor()
extern void AkRoom__cctor_m8818E9AB56622F5548C253A1EFDDD7950E0455E1 (void);
// 0x00000098 System.Void AkRoomAwareManager::RegisterRoomAwareObject(AkRoomAwareObject)
extern void AkRoomAwareManager_RegisterRoomAwareObject_m2318DD031F95F4BF354599362385FECE9DC01019 (void);
// 0x00000099 System.Void AkRoomAwareManager::UnregisterRoomAwareObject(AkRoomAwareObject)
extern void AkRoomAwareManager_UnregisterRoomAwareObject_mD6200F411DEDEDA8D04CDC1D485C7EFC7131CB79 (void);
// 0x0000009A System.Void AkRoomAwareManager::RegisterRoomAwareObjectForUpdate(AkRoomAwareObject)
extern void AkRoomAwareManager_RegisterRoomAwareObjectForUpdate_mE13BB788CD686462A3AB8911B32BF1E8A313DCB4 (void);
// 0x0000009B System.Void AkRoomAwareManager::ObjectEnteredRoom(UnityEngine.Collider,AkRoom)
extern void AkRoomAwareManager_ObjectEnteredRoom_m04F570E2EBDF8AD15CCC357E89F15182F7A27406 (void);
// 0x0000009C System.Void AkRoomAwareManager::ObjectEnteredRoom(AkRoomAwareObject,AkRoom)
extern void AkRoomAwareManager_ObjectEnteredRoom_m6EFFC5DD1EF1462BA691A34576ECBC066926B64C (void);
// 0x0000009D System.Void AkRoomAwareManager::ObjectExitedRoom(UnityEngine.Collider,AkRoom)
extern void AkRoomAwareManager_ObjectExitedRoom_m39A12FC3DB608BE05781CEB7D31219DD47A8D7CD (void);
// 0x0000009E System.Void AkRoomAwareManager::ObjectExitedRoom(AkRoomAwareObject,AkRoom)
extern void AkRoomAwareManager_ObjectExitedRoom_mEF4E9C13B790AF1C6AF48B98056F6E8D4CD91D5E (void);
// 0x0000009F System.Void AkRoomAwareManager::UpdateRoomAwareObjects()
extern void AkRoomAwareManager_UpdateRoomAwareObjects_m76BA1B7236CAA6DFE9E3839DB3B9ADD70B1302E3 (void);
// 0x000000A0 System.Void AkRoomAwareManager::.cctor()
extern void AkRoomAwareManager__cctor_m6FD71CB52142D617F6317E1F8F042B6BF4B86942 (void);
// 0x000000A1 AkRoomAwareObject AkRoomAwareObject::GetAkRoomAwareObjectFromCollider(UnityEngine.Collider)
extern void AkRoomAwareObject_GetAkRoomAwareObjectFromCollider_mE17BF244F8EB5304647936C098CB9DD6C8CBD34A (void);
// 0x000000A2 System.Void AkRoomAwareObject::Awake()
extern void AkRoomAwareObject_Awake_m8A46A5F4FF1A06B9B248DE47DB667B82B1C3C07B (void);
// 0x000000A3 System.Void AkRoomAwareObject::OnEnable()
extern void AkRoomAwareObject_OnEnable_mB2CCA3DA8E630C8B35D54B6C30A8E4FC1099846D (void);
// 0x000000A4 System.Void AkRoomAwareObject::OnDisable()
extern void AkRoomAwareObject_OnDisable_mC67429AD5E39D80411C79B55E288A56CF9ADECE0 (void);
// 0x000000A5 System.Void AkRoomAwareObject::OnDestroy()
extern void AkRoomAwareObject_OnDestroy_m866F9670C58E604AD278860F26881FE0F258851C (void);
// 0x000000A6 System.Void AkRoomAwareObject::SetGameObjectInHighestPriorityActiveAndEnabledRoom()
extern void AkRoomAwareObject_SetGameObjectInHighestPriorityActiveAndEnabledRoom_m93F075B4E8E7E3D845C598BFCCFC45DBD320DAB6 (void);
// 0x000000A7 System.Void AkRoomAwareObject::SetGameObjectInRoom(AkRoom)
extern void AkRoomAwareObject_SetGameObjectInRoom_m0E471D6066C89A5EE2A2203AC94A655C854B0FF4 (void);
// 0x000000A8 System.Void AkRoomAwareObject::EnteredRoom(AkRoom)
extern void AkRoomAwareObject_EnteredRoom_m30F9868D6D1864B8DBF652145370EBAFBC8C17A5 (void);
// 0x000000A9 System.Void AkRoomAwareObject::ExitedRoom(AkRoom)
extern void AkRoomAwareObject_ExitedRoom_mDE8568AB4B59C39A704174A2227BD1C12E79D093 (void);
// 0x000000AA System.Void AkRoomAwareObject::.ctor()
extern void AkRoomAwareObject__ctor_m1D7ECC042B61739C258933FBFB22C656931172B4 (void);
// 0x000000AB System.Void AkRoomAwareObject::.cctor()
extern void AkRoomAwareObject__cctor_m5BC0E672C58201C2DE2E6B8F42351E029780BE37 (void);
// 0x000000AC System.Void AkRoomManager::Init()
extern void AkRoomManager_Init_mC65C173101545414B0378EAE92D24845C0702E7A (void);
// 0x000000AD System.Void AkRoomManager::Terminate()
extern void AkRoomManager_Terminate_m56CB2E20F01ADC8B6B1E66078DF657289E1C4049 (void);
// 0x000000AE System.Void AkRoomManager::RegisterPortal(AkRoomPortal)
extern void AkRoomManager_RegisterPortal_mEBF8EEE080EA2C22EED60CEB911655B0CE3DB469 (void);
// 0x000000AF System.Void AkRoomManager::UnregisterPortal(AkRoomPortal)
extern void AkRoomManager_UnregisterPortal_m7D41A1B5BB87EEDDBC380877882B4DD0B73D07BC (void);
// 0x000000B0 System.Void AkRoomManager::RegisterReflector(AkSurfaceReflector)
extern void AkRoomManager_RegisterReflector_m741C11D991B0AEA9185662726119A2C2EA7621DB (void);
// 0x000000B1 System.Void AkRoomManager::UnregisterReflector(AkSurfaceReflector)
extern void AkRoomManager_UnregisterReflector_m15537F07939C97C909D877F2C95D0696424F3455 (void);
// 0x000000B2 System.Void AkRoomManager::RegisterPortalUpdate(AkRoomPortal)
extern void AkRoomManager_RegisterPortalUpdate_m3794AB836D4D41AFC0FFA8CC1426AEFC28A5F4D9 (void);
// 0x000000B3 System.Void AkRoomManager::RegisterRoomUpdate(AkRoom)
extern void AkRoomManager_RegisterRoomUpdate_m4D6052E0C467499F05D0646255C2C75F097ED53D (void);
// 0x000000B4 System.Void AkRoomManager::Update()
extern void AkRoomManager_Update_m6A8516CC77612C510B2C1F23E68FB5ECBF77E24A (void);
// 0x000000B5 System.Void AkRoomManager::.ctor()
extern void AkRoomManager__ctor_mFA3322A377829C10EB2A8370091AB03CBE9C6DB7 (void);
// 0x000000B6 System.Boolean AkRoomPortal::get_portalActive()
extern void AkRoomPortal_get_portalActive_m18AB3238AA73AA2FB123D07E9612A80DC0E59C68 (void);
// 0x000000B7 System.Void AkRoomPortal::set_portalActive(System.Boolean)
extern void AkRoomPortal_set_portalActive_m28F322C3DBFF0FD253F09E7470DBCA50A828E747 (void);
// 0x000000B8 System.UInt64 AkRoomPortal::get_frontRoomID()
extern void AkRoomPortal_get_frontRoomID_mF9FAF34A6C8BD064EEA794204D45FA75838027DE (void);
// 0x000000B9 System.UInt64 AkRoomPortal::get_backRoomID()
extern void AkRoomPortal_get_backRoomID_mF6166E22145B55646913B906D145454D4CA706B4 (void);
// 0x000000BA AkRoom AkRoomPortal::GetRoom(System.Int32)
extern void AkRoomPortal_GetRoom_mE8CBA3FB1C356F40E8988A8BCC696E3B2412AE83 (void);
// 0x000000BB AkRoom AkRoomPortal::get_frontRoom()
extern void AkRoomPortal_get_frontRoom_m89628B5544BA40856C7814FF194E0BB5C87648AD (void);
// 0x000000BC AkRoom AkRoomPortal::get_backRoom()
extern void AkRoomPortal_get_backRoom_m08DAB06481074927E27E58E7A384B506E6671A99 (void);
// 0x000000BD System.Void AkRoomPortal::SetRoomPortal()
extern void AkRoomPortal_SetRoomPortal_m887D4E1791385824E5B0B345D199C29F67EF972D (void);
// 0x000000BE System.Void AkRoomPortal::UpdateRoomPortal()
extern void AkRoomPortal_UpdateRoomPortal_m08A33E347830B9C96D61D0358C5AE1430B0F78A1 (void);
// 0x000000BF System.Boolean AkRoomPortal::Overlaps(AkRoom)
extern void AkRoomPortal_Overlaps_m6E54A88CFFEEC6C6701FDB41D56D86E439251271 (void);
// 0x000000C0 System.Boolean AkRoomPortal::get_IsValid()
extern void AkRoomPortal_get_IsValid_mB1013323F372A7DF192C5282879E286779456F3C (void);
// 0x000000C1 System.UInt64 AkRoomPortal::GetID()
extern void AkRoomPortal_GetID_m5BD7D664F5B45DAF4B989D9196716687FDC64D69 (void);
// 0x000000C2 System.Void AkRoomPortal::Awake()
extern void AkRoomPortal_Awake_m164C38189A239F6563E07A4A4F532AB1EC9134B7 (void);
// 0x000000C3 System.Void AkRoomPortal::Start()
extern void AkRoomPortal_Start_m821CE400ACBEBCCB9AB2207F11F48C918CA8B797 (void);
// 0x000000C4 System.Void AkRoomPortal::HandleEvent(UnityEngine.GameObject)
extern void AkRoomPortal_HandleEvent_mB5878CD3DB4D70DCB41C010FA6EB3A74F9E685DF (void);
// 0x000000C5 System.Void AkRoomPortal::ClosePortal(UnityEngine.GameObject)
extern void AkRoomPortal_ClosePortal_m6D8D38F087836DB0D2412A9697C82026F6B7B7FC (void);
// 0x000000C6 System.Void AkRoomPortal::OnDestroy()
extern void AkRoomPortal_OnDestroy_mB7A0E91F11F63FE37EF58F33DF086CE411D59939 (void);
// 0x000000C7 System.Void AkRoomPortal::OnEnable()
extern void AkRoomPortal_OnEnable_mD449ACBD357BC092892B8CE88835323E5EF574CE (void);
// 0x000000C8 System.Void AkRoomPortal::OnDisable()
extern void AkRoomPortal_OnDisable_mDEC5100D4DECC67B00548AFCCB332C38A55565CD (void);
// 0x000000C9 System.Boolean AkRoomPortal::IsRoomActive(AkRoom)
extern void AkRoomPortal_IsRoomActive_m276583F2DDFB7B84B95C25CAE67F732965BF1D3F (void);
// 0x000000CA System.Void AkRoomPortal::Open()
extern void AkRoomPortal_Open_m2C4822BC2E5AEF1B9C34D7670805C66C65247EC6 (void);
// 0x000000CB System.Void AkRoomPortal::Close()
extern void AkRoomPortal_Close_m099B83A48E6739AA9783AACF764843182676EC9C (void);
// 0x000000CC System.Void AkRoomPortal::FindOverlappingRooms(AkRoom_PriorityList[])
extern void AkRoomPortal_FindOverlappingRooms_m7AB09936003B6288D136C68DA504626D5831AEEE (void);
// 0x000000CD System.Void AkRoomPortal::FillRoomList(UnityEngine.Vector3,AkRoom_PriorityList)
extern void AkRoomPortal_FillRoomList_m4A74123AD46B94FF7517320B338D9E6FD4DEE9E1 (void);
// 0x000000CE System.Void AkRoomPortal::UpdateRooms()
extern void AkRoomPortal_UpdateRooms_m833790F95374D9E76FB434F7582BA2DB734DAAEA (void);
// 0x000000CF System.Void AkRoomPortal::SetRoom(System.Int32,AkRoom)
extern void AkRoomPortal_SetRoom_mFD3FD429CFA7354762784B185616D3C11AF6DF79 (void);
// 0x000000D0 System.Void AkRoomPortal::SetFrontRoom(AkRoom)
extern void AkRoomPortal_SetFrontRoom_m26E29FFAFBC72773F495E2BFDA062D444B0213F4 (void);
// 0x000000D1 System.Void AkRoomPortal::SetBackRoom(AkRoom)
extern void AkRoomPortal_SetBackRoom_m41C3F46C5392D6D8D932441C8570F77D2BED2455 (void);
// 0x000000D2 System.Void AkRoomPortal::UpdateSoundEngineRoomIDs()
extern void AkRoomPortal_UpdateSoundEngineRoomIDs_mCAC6D28DFEC3E0890761D5E08B220BA3431E7FA3 (void);
// 0x000000D3 System.Void AkRoomPortal::UpdateOverlappingRooms()
extern void AkRoomPortal_UpdateOverlappingRooms_m1679EA2A2E7F2A516DB484F8EE7B74EFD36C2857 (void);
// 0x000000D4 System.Void AkRoomPortal::.ctor()
extern void AkRoomPortal__ctor_m5AEFE54D23127EA5558D0991057CF74F4B71D688 (void);
// 0x000000D5 System.Void AkRoomPortalObstruction::Awake()
extern void AkRoomPortalObstruction_Awake_m4CBB028E7427F95C1B8339160B6E3264BF86E1E4 (void);
// 0x000000D6 System.Void AkRoomPortalObstruction::UpdateCurrentListenerList()
extern void AkRoomPortalObstruction_UpdateCurrentListenerList_m0547D6B9943AC9E191A519485D35FC83FCAE0287 (void);
// 0x000000D7 System.Void AkRoomPortalObstruction::SetObstructionOcclusion(System.Collections.Generic.KeyValuePair`2<AkAudioListener,AkObstructionOcclusion_ObstructionOcclusionValue>)
extern void AkRoomPortalObstruction_SetObstructionOcclusion_m064242A547E99D9044424A3F7BC09357255B1A57 (void);
// 0x000000D8 System.Void AkRoomPortalObstruction::.ctor()
extern void AkRoomPortalObstruction__ctor_mE047AF1D82CE062C410392FDF1D1EAB750DE434B (void);
// 0x000000D9 AkSoundEngineController AkSoundEngineController::get_Instance()
extern void AkSoundEngineController_get_Instance_mA66616663FE3EC41603FC735B55EFB4630906D55 (void);
// 0x000000DA System.Void AkSoundEngineController::.ctor()
extern void AkSoundEngineController__ctor_m972A3A562B05FC5F9DC40FEE00A3ECC82FE8B557 (void);
// 0x000000DB System.Void AkSoundEngineController::Finalize()
extern void AkSoundEngineController_Finalize_mC2FCD185E62C1610B170C7F7B1BE359A35F1CEE7 (void);
// 0x000000DC System.Void AkSoundEngineController::LateUpdate()
extern void AkSoundEngineController_LateUpdate_m22CCEBDE9EA68D0CD1F40BDCC2DE62432EDD042F (void);
// 0x000000DD AkWwiseInitializationSettings AkSoundEngineController::GetInitSettingsInstance()
extern void AkSoundEngineController_GetInitSettingsInstance_m31BCEFBC6B5EE52A9CA84C700E506CDD992A80C3 (void);
// 0x000000DE System.Void AkSoundEngineController::Init(AkInitializer)
extern void AkSoundEngineController_Init_m671A97B796E77D34FC7D11BEECAD63BFB60DFD5C (void);
// 0x000000DF System.Void AkSoundEngineController::OnDisable()
extern void AkSoundEngineController_OnDisable_m6C6B0B8D32FC84EDAE00ACE8F70AAC85017C5CF8 (void);
// 0x000000E0 System.Void AkSoundEngineController::Terminate()
extern void AkSoundEngineController_Terminate_mCF64EED8CEDDD45F5D9299358B71E3B08D843AC6 (void);
// 0x000000E1 System.Void AkSoundEngineController::OnApplicationPause(System.Boolean)
extern void AkSoundEngineController_OnApplicationPause_mA505F1BCC14D458A9EB178DEF53788D19865380D (void);
// 0x000000E2 System.Void AkSoundEngineController::OnApplicationFocus(System.Boolean)
extern void AkSoundEngineController_OnApplicationFocus_m5DEE95DB3A9124E4050FCC3C3529DF154C0B22BA (void);
// 0x000000E3 System.Void AkSoundEngineController::ActivateAudio(System.Boolean,System.Boolean)
extern void AkSoundEngineController_ActivateAudio_m290C3BE630F6DB5FBCA703757E1EDAD7542092FD (void);
// 0x000000E4 System.Void AkSpatialAudioDebugDraw::.ctor()
extern void AkSpatialAudioDebugDraw__ctor_m9913A2BFED56DE782F54F99EE002058EEEA23B49 (void);
// 0x000000E5 System.Void AkSpatialAudioEmitter::.ctor()
extern void AkSpatialAudioEmitter__ctor_m690D886355E3EBBE9991D923D31CE14D3026D92F (void);
// 0x000000E6 AkAudioListener AkSpatialAudioListener::get_TheSpatialAudioListener()
extern void AkSpatialAudioListener_get_TheSpatialAudioListener_m7FDE5271A2F5841EEF0534970579A540F0454959 (void);
// 0x000000E7 AkSpatialAudioListener_SpatialAudioListenerList AkSpatialAudioListener::get_SpatialAudioListeners()
extern void AkSpatialAudioListener_get_SpatialAudioListeners_m77BD0CF877F206C3FBC8E548DCC34D25B30DCC02 (void);
// 0x000000E8 System.Void AkSpatialAudioListener::Awake()
extern void AkSpatialAudioListener_Awake_m97156EE04DBE1ACA9C4339AD41935AAA1F7DF2DF (void);
// 0x000000E9 System.Void AkSpatialAudioListener::OnEnable()
extern void AkSpatialAudioListener_OnEnable_m801B101C588095CE88674720CE95DE3B81851A57 (void);
// 0x000000EA System.Void AkSpatialAudioListener::OnDisable()
extern void AkSpatialAudioListener_OnDisable_mD7DCB836C49EE34F99FB65F1DAA54AD307DD1B01 (void);
// 0x000000EB System.Void AkSpatialAudioListener::.ctor()
extern void AkSpatialAudioListener__ctor_m2F59AC93CE6E73090BB1D471B332C54B94E99B87 (void);
// 0x000000EC System.Void AkSpatialAudioListener::.cctor()
extern void AkSpatialAudioListener__cctor_m922AC62B14BBC9C44B458C3CFB813948D69561F5 (void);
// 0x000000ED AK.Wwise.BaseType AkState::get_WwiseType()
extern void AkState_get_WwiseType_m4A90AE03E39F0497EB68B26D74B5DE874C8A3422 (void);
// 0x000000EE System.Void AkState::HandleEvent(UnityEngine.GameObject)
extern void AkState_HandleEvent_m22E7BAEF601A84631378FC64BE955C3CF052E088 (void);
// 0x000000EF System.Int32 AkState::get_valueID()
extern void AkState_get_valueID_m1C36A5062444FDBD886B1BBE12CF470E78B5A970 (void);
// 0x000000F0 System.Int32 AkState::get_groupID()
extern void AkState_get_groupID_mC74E0E94A8E2811B7A0E4EFD450EB2CE1C361DAA (void);
// 0x000000F1 System.Byte[] AkState::get_valueGuid()
extern void AkState_get_valueGuid_m53B0463978C45F361BA89A891FC410A7CA0EB9A7 (void);
// 0x000000F2 System.Byte[] AkState::get_groupGuid()
extern void AkState_get_groupGuid_m3F0318D79B0EF589154B4DB5B22371D72788B750 (void);
// 0x000000F3 System.Void AkState::.ctor()
extern void AkState__ctor_mE76E15ACCAAA00D510B2724B9BAF85B92BE0F7DF (void);
// 0x000000F4 System.UInt64 AkSurfaceReflector::GetID()
extern void AkSurfaceReflector_GetID_m7368B22142562B8FCCF8DD5900DBF3979F82CBE1 (void);
// 0x000000F5 System.Void AkSurfaceReflector::SetGeometryFromMesh(UnityEngine.Mesh,UnityEngine.Transform,System.UInt64,System.UInt64,System.Boolean,System.Boolean,System.Boolean,AK.Wwise.AcousticTexture[],System.Single[],System.String)
extern void AkSurfaceReflector_SetGeometryFromMesh_m2A9DC790E6B76C0EA8CB3CE7C5B0CE61BD95C708 (void);
// 0x000000F6 System.Void AkSurfaceReflector::SetAssociatedRoom(AkRoom)
extern void AkSurfaceReflector_SetAssociatedRoom_m6824EE2788EFD029BFED4CDFA56D016BD14217A1 (void);
// 0x000000F7 System.Void AkSurfaceReflector::SetGeometry()
extern void AkSurfaceReflector_SetGeometry_m201B4FFC7FB97B788DCCFB6829ACB4C5377947A9 (void);
// 0x000000F8 System.Void AkSurfaceReflector::UpdateGeometry()
extern void AkSurfaceReflector_UpdateGeometry_m8E65C04BAB7A9CAD5FB65A27AA677ACFCE2902CB (void);
// 0x000000F9 System.Void AkSurfaceReflector::RemoveGeometry()
extern void AkSurfaceReflector_RemoveGeometry_mBE46396E0C87F4BA989AC5310A38D61E3811A0AE (void);
// 0x000000FA System.Void AkSurfaceReflector::RemoveGeometrySet(UnityEngine.MeshFilter)
extern void AkSurfaceReflector_RemoveGeometrySet_mDFDBAA066EBA981303232DDB3B2EC3F5D387D45A (void);
// 0x000000FB System.Void AkSurfaceReflector::Awake()
extern void AkSurfaceReflector_Awake_m726CD36A7CDC7B7D91D3B570A74E0354460AA04C (void);
// 0x000000FC System.Void AkSurfaceReflector::OnEnable()
extern void AkSurfaceReflector_OnEnable_m0BF7D1C4CFF40940C0087C20A593324D0109964B (void);
// 0x000000FD System.Void AkSurfaceReflector::OnDisable()
extern void AkSurfaceReflector_OnDisable_m6F2B56C91193FED4AC58C63D2CEEA86CC7576185 (void);
// 0x000000FE System.UInt64 AkSurfaceReflector::GetAkGeometrySetID(UnityEngine.MeshFilter)
extern void AkSurfaceReflector_GetAkGeometrySetID_m6EF88E8E4DFE0796F88EB57B423930E079F6E6D2 (void);
// 0x000000FF System.Void AkSurfaceReflector::AddGeometrySet(AK.Wwise.AcousticTexture,UnityEngine.MeshFilter,System.UInt64,System.Boolean,System.Boolean,System.Boolean)
extern void AkSurfaceReflector_AddGeometrySet_m6002C7281CD77D6ECC153A750484B28036D0EB4F (void);
// 0x00000100 AK.Wwise.AcousticTexture AkSurfaceReflector::get_AcousticTexture()
extern void AkSurfaceReflector_get_AcousticTexture_m325283F16C8D5586C628BFE296DB67F97BC6D0DE (void);
// 0x00000101 System.Void AkSurfaceReflector::set_AcousticTexture(AK.Wwise.AcousticTexture)
extern void AkSurfaceReflector_set_AcousticTexture_m9F7DF017BA86AC10ED11EBCF8EF5268B75F76D2B (void);
// 0x00000102 System.Single[] AkSurfaceReflector::get_OcclusionValues()
extern void AkSurfaceReflector_get_OcclusionValues_m76853597C3CA201D27EDC54D847E3C9F553D92E2 (void);
// 0x00000103 System.Void AkSurfaceReflector::set_OcclusionValues(System.Single[])
extern void AkSurfaceReflector_set_OcclusionValues_m57F39D78A4AF01AB239464AAD170B33CDAAFC2DA (void);
// 0x00000104 System.Void AkSurfaceReflector::.ctor()
extern void AkSurfaceReflector__ctor_mB26309C65651E8401F147A591C91D5E84800C248 (void);
// 0x00000105 System.Void AkSurfaceReflector::.cctor()
extern void AkSurfaceReflector__cctor_m49DF7901B3C6A9B6CFFE952A0ADFF2FB868972BB (void);
// 0x00000106 AK.Wwise.BaseType AkSwitch::get_WwiseType()
extern void AkSwitch_get_WwiseType_m2E1924D0343663304C3CD3BE97480CEEEC4BBAD9 (void);
// 0x00000107 System.Void AkSwitch::HandleEvent(UnityEngine.GameObject)
extern void AkSwitch_HandleEvent_m603D674C3BFB2526AE9EF149C2DBAC6F790A7699 (void);
// 0x00000108 System.Int32 AkSwitch::get_valueID()
extern void AkSwitch_get_valueID_mEBF306EFFCD5D3AA33445426E6504F8DBCD3B105 (void);
// 0x00000109 System.Int32 AkSwitch::get_groupID()
extern void AkSwitch_get_groupID_m3A41A65DAE179B2491C3B6D55A1B1EC4CCA4A829 (void);
// 0x0000010A System.Byte[] AkSwitch::get_valueGuid()
extern void AkSwitch_get_valueGuid_m4DEA598DED5B3DF29378DF580B244E4E54375913 (void);
// 0x0000010B System.Byte[] AkSwitch::get_groupGuid()
extern void AkSwitch_get_groupGuid_m09429DA5DBBDBB4DAE833FCDC48A304D19B3AFD4 (void);
// 0x0000010C System.Void AkSwitch::.ctor()
extern void AkSwitch__ctor_mADD94392D4FCD64B111060EBD7137F6942507929 (void);
// 0x0000010D System.Void AkTerminator::.ctor()
extern void AkTerminator__ctor_mF75A8A32C34312AF88FFD94568B3F861774F56B7 (void);
// 0x0000010E System.Collections.Generic.Dictionary`2<System.UInt32,System.String> AkTriggerBase::GetAllDerivedTypes()
extern void AkTriggerBase_GetAllDerivedTypes_mC338EACE9CE56503198BD4F195042D46973DA17B (void);
// 0x0000010F System.Void AkTriggerBase::.ctor()
extern void AkTriggerBase__ctor_m9D5775053972609EA5122FF00A3F0A55420C5B0C (void);
// 0x00000110 System.Void AkTriggerCollisionEnter::OnCollisionEnter(UnityEngine.Collision)
extern void AkTriggerCollisionEnter_OnCollisionEnter_m6428913AD15C2D7F8372C2BABFFE64508E0C8D0A (void);
// 0x00000111 System.Void AkTriggerCollisionEnter::OnTriggerEnter(UnityEngine.Collider)
extern void AkTriggerCollisionEnter_OnTriggerEnter_m289963135558E1FCC4B0DF4AE196FDB085CA84F9 (void);
// 0x00000112 System.Void AkTriggerCollisionEnter::.ctor()
extern void AkTriggerCollisionEnter__ctor_m8D91F1812E49F9EA79AAA6DC165B34917CA87CF5 (void);
// 0x00000113 System.Void AkTriggerCollisionExit::OnCollisionExit(UnityEngine.Collision)
extern void AkTriggerCollisionExit_OnCollisionExit_mD09DE26F203EA54DB07F5767F72F5F640763647C (void);
// 0x00000114 System.Void AkTriggerCollisionExit::.ctor()
extern void AkTriggerCollisionExit__ctor_mFF38470E502204090AF7837689AE09E62CE44381 (void);
// 0x00000115 System.Void AkTriggerDisable::OnDisable()
extern void AkTriggerDisable_OnDisable_mBC3D196E4CEE190293A06C451CEC030E953F6627 (void);
// 0x00000116 System.Void AkTriggerDisable::.ctor()
extern void AkTriggerDisable__ctor_mA3D2D4115E3784BA37F2104567AF319FA2B66E19 (void);
// 0x00000117 System.Void AkTriggerEnable::.ctor()
extern void AkTriggerEnable__ctor_m6909D337F01F613A731E4F78739EBD28898852D4 (void);
// 0x00000118 System.Void AkTriggerEnter::OnTriggerEnter(UnityEngine.Collider)
extern void AkTriggerEnter_OnTriggerEnter_m0EA8915D6E2EDECCFFF024EB23FB2305FBC541E0 (void);
// 0x00000119 System.Void AkTriggerEnter::.ctor()
extern void AkTriggerEnter__ctor_mC712377B2DD34CA0BB5EE9ADE55D62EEF40B255A (void);
// 0x0000011A System.Void AkTriggerExit::OnTriggerExit(UnityEngine.Collider)
extern void AkTriggerExit_OnTriggerExit_m18C09FAA3A170EE9BBC9DB64FA413DD054F146E5 (void);
// 0x0000011B System.Void AkTriggerExit::.ctor()
extern void AkTriggerExit__ctor_m822128589E50F07DFDA6A7394EA0972A127C6B33 (void);
// 0x0000011C System.Void AkTriggerHandler::HandleEvent(UnityEngine.GameObject)
// 0x0000011D System.Void AkTriggerHandler::Awake()
extern void AkTriggerHandler_Awake_m869064E99F4D8486A97A3488DC31DA885ADF2B9D (void);
// 0x0000011E System.Void AkTriggerHandler::Start()
extern void AkTriggerHandler_Start_m38613C29E76BB6A8CED9D0B6C83AB91AE9C783A7 (void);
// 0x0000011F System.Void AkTriggerHandler::OnDestroy()
extern void AkTriggerHandler_OnDestroy_m0634BB8F6F51E604100630C1297E102DB7AF800B (void);
// 0x00000120 System.Void AkTriggerHandler::DoDestroy()
extern void AkTriggerHandler_DoDestroy_m2B3D3BCE3D8005A2E3FEE27966CF8845D1A91AD5 (void);
// 0x00000121 System.Void AkTriggerHandler::RegisterTriggers(System.Collections.Generic.List`1<System.Int32>,AkTriggerBase_Trigger)
extern void AkTriggerHandler_RegisterTriggers_m248835CE7CF7815D635ECF282419219C324DC2E5 (void);
// 0x00000122 System.Void AkTriggerHandler::UnregisterTriggers(System.Collections.Generic.List`1<System.Int32>,AkTriggerBase_Trigger)
extern void AkTriggerHandler_UnregisterTriggers_mC08B80CC4956E6CFB190FC433BC13CB9A3A494EA (void);
// 0x00000123 System.Void AkTriggerHandler::.ctor()
extern void AkTriggerHandler__ctor_mA51D5264D3AEA7FFAB45CE168135EB2276BC5C5B (void);
// 0x00000124 System.Void AkTriggerHandler::.cctor()
extern void AkTriggerHandler__cctor_m93C0573F6647EDF4E2FEDB6747BC22141931F2FB (void);
// 0x00000125 AK.Wwise.BaseType AkDragDropTriggerHandler::get_WwiseType()
// 0x00000126 System.Void AkDragDropTriggerHandler::Awake()
extern void AkDragDropTriggerHandler_Awake_m02398C3E373522151D745AC1535E9C430C0E765E (void);
// 0x00000127 System.Void AkDragDropTriggerHandler::Start()
extern void AkDragDropTriggerHandler_Start_mCD0DA688F9EA13BB97A88F730F403F495B7EADEA (void);
// 0x00000128 System.Void AkDragDropTriggerHandler::OnDestroy()
extern void AkDragDropTriggerHandler_OnDestroy_m33372FBB0014E6F5327CD3ED22B2A50B653E2FFE (void);
// 0x00000129 System.Void AkDragDropTriggerHandler::.ctor()
extern void AkDragDropTriggerHandler__ctor_mE178637D9D21E9D3891C73C68C0D0997D619E453 (void);
// 0x0000012A System.Void AkTriggerMouseDown::OnMouseDown()
extern void AkTriggerMouseDown_OnMouseDown_mA44F27B56A86B5D01DE79FE8113876AC9F3D23AF (void);
// 0x0000012B System.Void AkTriggerMouseDown::.ctor()
extern void AkTriggerMouseDown__ctor_m729E5800F75AF38D5C2F12A2C7B94E72B46CB7AF (void);
// 0x0000012C System.Void AkTriggerMouseEnter::OnMouseEnter()
extern void AkTriggerMouseEnter_OnMouseEnter_m68A1B708AB394E53A030E0F12231E025FEEE561F (void);
// 0x0000012D System.Void AkTriggerMouseEnter::.ctor()
extern void AkTriggerMouseEnter__ctor_m8881D675B5A17875511DAFC8CC83F9149EF1D90C (void);
// 0x0000012E System.Void AkTriggerMouseExit::OnMouseExit()
extern void AkTriggerMouseExit_OnMouseExit_m7078CB6E46C565C5FDF987752143B6CDD166906A (void);
// 0x0000012F System.Void AkTriggerMouseExit::.ctor()
extern void AkTriggerMouseExit__ctor_m321A34D10E8EEAA6FA963AF3C889CD316FA144A9 (void);
// 0x00000130 System.Void AkTriggerMouseUp::OnMouseUp()
extern void AkTriggerMouseUp_OnMouseUp_mF39BB1DB4F0341826B0857E36FC6E92F1EA063B7 (void);
// 0x00000131 System.Void AkTriggerMouseUp::.ctor()
extern void AkTriggerMouseUp__ctor_m46762357A5A50562619C2368F05CD0C13998FE27 (void);
// 0x00000132 System.Collections.Generic.List`1<AkAudioListener> AkAudioListener_BaseListenerList::get_ListenerList()
extern void BaseListenerList_get_ListenerList_mC6B374A7F0343CAA95349038593B22CD5246BA6B (void);
// 0x00000133 System.Boolean AkAudioListener_BaseListenerList::Add(AkAudioListener)
extern void BaseListenerList_Add_mC99DEC88B3408C57FC660CD39FAA8D30F54CB599 (void);
// 0x00000134 System.Boolean AkAudioListener_BaseListenerList::Remove(AkAudioListener)
extern void BaseListenerList_Remove_m8E1F0A7FC0C4899586D53F0E5E7F0F8B85A688F6 (void);
// 0x00000135 System.UInt64[] AkAudioListener_BaseListenerList::GetListenerIds()
extern void BaseListenerList_GetListenerIds_mF14D924A6ABAEB9E74C13BEC671EB7C9B95CB248 (void);
// 0x00000136 System.Void AkAudioListener_BaseListenerList::.ctor()
extern void BaseListenerList__ctor_mE005B9B403FC5A1422BB6A878ABC1620DDE2ED27 (void);
// 0x00000137 System.Boolean AkAudioListener_DefaultListenerList::Add(AkAudioListener)
extern void DefaultListenerList_Add_mBD889E228AB5B96CD1B02A633F51FCB6E059EF60 (void);
// 0x00000138 System.Boolean AkAudioListener_DefaultListenerList::Remove(AkAudioListener)
extern void DefaultListenerList_Remove_mD9EB89E9965B9A121BA8BFF462CA38412DC977E1 (void);
// 0x00000139 System.Void AkAudioListener_DefaultListenerList::.ctor()
extern void DefaultListenerList__ctor_m0A8BF0D269164F30555C4DB8B8E0086D3A588E84 (void);
// 0x0000013A System.Int32 AkEnvironment_AkEnvironment_CompareByPriority::Compare(AkEnvironment,AkEnvironment)
extern void AkEnvironment_CompareByPriority_Compare_mC901241A77C21547AB3520D5ACC9FAEFC8BEC1B2 (void);
// 0x0000013B System.Void AkEnvironment_AkEnvironment_CompareByPriority::.ctor()
extern void AkEnvironment_CompareByPriority__ctor_m92D551FAA2971E369052A3DD32AFE1DD3D0C0B1E (void);
// 0x0000013C System.Int32 AkEnvironment_AkEnvironment_CompareBySelectionAlgorithm::Compare(AkEnvironment,AkEnvironment)
extern void AkEnvironment_CompareBySelectionAlgorithm_Compare_m5152FAC9FC959CCAB86EC683B93F2308E0799A9D (void);
// 0x0000013D System.Void AkEnvironment_AkEnvironment_CompareBySelectionAlgorithm::.ctor()
extern void AkEnvironment_CompareBySelectionAlgorithm__ctor_m4A62447376982AFFE0092E656EC5DD0E6D55E7A8 (void);
// 0x0000013E System.Void AkEvent_CallbackData::CallFunction(AkEventCallbackMsg)
extern void CallbackData_CallFunction_mEF222802AB68A78D4EC186D3A981982ECF1AC38C (void);
// 0x0000013F System.Void AkEvent_CallbackData::.ctor()
extern void CallbackData__ctor_m5A294F59DC0E2A3778D72E4ECF84713261A2802F (void);
// 0x00000140 System.Void AkMemBankLoader_<LoadFile>d__14::.ctor(System.Int32)
extern void U3CLoadFileU3Ed__14__ctor_mB982D5A675A39A0F41B5D8A8969A768C2709FB9B (void);
// 0x00000141 System.Void AkMemBankLoader_<LoadFile>d__14::System.IDisposable.Dispose()
extern void U3CLoadFileU3Ed__14_System_IDisposable_Dispose_m6E764F953C0B9CE9BEBD8F916A468D0553F819EF (void);
// 0x00000142 System.Boolean AkMemBankLoader_<LoadFile>d__14::MoveNext()
extern void U3CLoadFileU3Ed__14_MoveNext_m36BFA4BB0FDE5F11CE4503DBE24B4C61A48E66D1 (void);
// 0x00000143 System.Object AkMemBankLoader_<LoadFile>d__14::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CLoadFileU3Ed__14_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1EFFF7EDF67177181237CDC6FFFC59857619E059 (void);
// 0x00000144 System.Void AkMemBankLoader_<LoadFile>d__14::System.Collections.IEnumerator.Reset()
extern void U3CLoadFileU3Ed__14_System_Collections_IEnumerator_Reset_m50381B0312FC6CBE7F40A21B43997A183DAEEDAB (void);
// 0x00000145 System.Object AkMemBankLoader_<LoadFile>d__14::System.Collections.IEnumerator.get_Current()
extern void U3CLoadFileU3Ed__14_System_Collections_IEnumerator_get_Current_mA1ACA0C86840851899034DA22F7551DC6E3EAFFD (void);
// 0x00000146 System.Boolean AkObstructionOcclusion_ObstructionOcclusionValue::Update(System.Single)
extern void ObstructionOcclusionValue_Update_m6EDFB01CA66B826529EF0008B14BFC1F94153829 (void);
// 0x00000147 System.Void AkObstructionOcclusion_ObstructionOcclusionValue::.ctor()
extern void ObstructionOcclusionValue__ctor_mE701E6D6E1B0F54BB87D5B7B15A41EC4B5AD5A33 (void);
// 0x00000148 System.UInt64 AkRoom_PriorityList::GetHighestPriorityActiveAndEnabledRoomID()
extern void PriorityList_GetHighestPriorityActiveAndEnabledRoomID_mE41BDC1EF6602FE26CE9A78A4E5AED29EDD1B3C7 (void);
// 0x00000149 AkRoom AkRoom_PriorityList::GetHighestPriorityActiveAndEnabledRoom()
extern void PriorityList_GetHighestPriorityActiveAndEnabledRoom_mE26F56E1294C77A8CE0504122F0B785B7A4B6155 (void);
// 0x0000014A System.Int32 AkRoom_PriorityList::get_Count()
extern void PriorityList_get_Count_m73ACE23A019E8F12ED8B87FDBA069BCD868A99D5 (void);
// 0x0000014B System.Void AkRoom_PriorityList::Clear()
extern void PriorityList_Clear_mBF47C8611DEFC3569394FD3FD2BDCF669EAE874E (void);
// 0x0000014C System.Void AkRoom_PriorityList::Add(AkRoom)
extern void PriorityList_Add_mE03888CB02F2B698B3135EA85404A24BAF2FB517 (void);
// 0x0000014D System.Void AkRoom_PriorityList::Remove(AkRoom)
extern void PriorityList_Remove_mD5CC0DDD400F68786FCD3A2F6E22E281FB10546F (void);
// 0x0000014E System.Boolean AkRoom_PriorityList::Contains(AkRoom)
extern void PriorityList_Contains_mCC22DB31BCE851EC10C16458004ECE77EEE7F701 (void);
// 0x0000014F System.Int32 AkRoom_PriorityList::BinarySearch(AkRoom)
extern void PriorityList_BinarySearch_m4DF107432088FA7AEA7B680CEEF7774694D8EC1C (void);
// 0x00000150 AkRoom AkRoom_PriorityList::get_Item(System.Int32)
extern void PriorityList_get_Item_mF7C7533D90902C28676C54BE027383F8681CA093 (void);
// 0x00000151 System.Void AkRoom_PriorityList::.ctor()
extern void PriorityList__ctor_mBDF2342AB55347945ECAB03B97F52850C97C39F9 (void);
// 0x00000152 System.Void AkRoom_PriorityList::.cctor()
extern void PriorityList__cctor_mE7C97D8F0A2992B1C977910A3E4BED064F88A053 (void);
// 0x00000153 System.Collections.Generic.List`1<AkSpatialAudioListener> AkSpatialAudioListener_SpatialAudioListenerList::get_ListenerList()
extern void SpatialAudioListenerList_get_ListenerList_m793D88049C80D103FB66EBB8AF1EC857C349EC59 (void);
// 0x00000154 System.Boolean AkSpatialAudioListener_SpatialAudioListenerList::Add(AkSpatialAudioListener)
extern void SpatialAudioListenerList_Add_mF6419C7D3DE60EFE1A6D3E7D5751862A3B917C4E (void);
// 0x00000155 System.Boolean AkSpatialAudioListener_SpatialAudioListenerList::Remove(AkSpatialAudioListener)
extern void SpatialAudioListenerList_Remove_m60B72CD217E5EAC0E638A557285064E6E0631B59 (void);
// 0x00000156 System.Void AkSpatialAudioListener_SpatialAudioListenerList::Refresh()
extern void SpatialAudioListenerList_Refresh_m3113DE951531925E91997114044921C0E3AAE6EB (void);
// 0x00000157 System.Void AkSpatialAudioListener_SpatialAudioListenerList::.ctor()
extern void SpatialAudioListenerList__ctor_m766F63C31F341B792FDD57ACE8B85795648C715C (void);
// 0x00000158 System.Void AkTriggerBase_Trigger::.ctor(System.Object,System.IntPtr)
extern void Trigger__ctor_m2568516901F5E7F917C3E21011C024CDA5CEB2AA (void);
// 0x00000159 System.Void AkTriggerBase_Trigger::Invoke(UnityEngine.GameObject)
extern void Trigger_Invoke_m5C703ED65465C52CB38C6CAA5F4F403FC19CC3A3 (void);
// 0x0000015A System.IAsyncResult AkTriggerBase_Trigger::BeginInvoke(UnityEngine.GameObject,System.AsyncCallback,System.Object)
extern void Trigger_BeginInvoke_m6868360963FF665A6D640AE1D053C6797A5DABDA (void);
// 0x0000015B System.Void AkTriggerBase_Trigger::EndInvoke(System.IAsyncResult)
extern void Trigger_EndInvoke_mCF3675C00A37FF6D633DF26A4B3E81C083DE016C (void);
// 0x0000015C System.Int32 AkRoom_PriorityList_CompareByPriority::Compare(AkRoom,AkRoom)
extern void CompareByPriority_Compare_mC849AC9FFFA5A72E923B3A1C490FFE4CE92993FB (void);
// 0x0000015D System.Void AkRoom_PriorityList_CompareByPriority::.ctor()
extern void CompareByPriority__ctor_mC130010F6B66FDDCD0AF2AD8D762B100095439DF (void);
static Il2CppMethodPointer s_methodPointers[349] = 
{
	AkMultiPosEvent_FinishedPlaying_m37A44F0E44FAD6A38DC68DF5281B2D823FF8C772,
	AkMultiPosEvent__ctor_mD90BA3EAA1236EC6A175AED1F68D541C369DA1DD,
	AkAmbient_OnEnable_m32AC458163E555319B2726135E48334394216E7A,
	AkAmbient_Start_mD09C271BE59E7B58C2B67F6AFE86E748964E56E8,
	AkAmbient_OnDisable_m24F93BB234BCA9384A19AA3115D35692A7804434,
	AkAmbient_HandleEvent_mB69FB92C646765A447505A56F186614559D07B2C,
	AkAmbient_OnDrawGizmosSelected_m0900783AE6B75B6354B69FE2D680A62326AD44B1,
	AkAmbient_BuildMultiDirectionArray_m4995F264D274366BCACCC17EBCDCD787C0A6616A,
	AkAmbient_BuildAkPositionArray_m69A0C96B894AD54B91DB0150D8EFEAEA33FC8BCA,
	AkAmbient__ctor_m7E9617B2ED9CEE2C439118FC6EFD045CDF241B54,
	AkAmbient__cctor_m002C02152E253E8A20ED47521088A62E0D4D85CA,
	AkAmbientLargeModePositioner_get_Position_mC0E0BEE7B64241819CBF9947A6C7126AA7FF0006,
	AkAmbientLargeModePositioner_get_Forward_m807ACC4874C064FFE2C4BA28C34A681363F46B46,
	AkAmbientLargeModePositioner_get_Up_mCC494E3357CB23891B417722811D733B4F3E91E1,
	AkAmbientLargeModePositioner__ctor_mC6AE6D073AA795F2D1B35C10B20799D5F34667A5,
	AkAudioListener_get_DefaultListeners_m8A9D788B6673EC14C32D44ED5798C17E0CEF7CDE,
	AkAudioListener_StartListeningToEmitter_m9A510F9C38E147779CD40B1B86948F50C9D09A6E,
	AkAudioListener_StopListeningToEmitter_m5D0DD95DFEB9113CEC970AF926122C7E780F364A,
	AkAudioListener_SetIsDefaultListener_mBB648B2B9F10D48EE3B4548C3EB025DFFFB8772E,
	AkAudioListener_Awake_mF9B0527790404DC52105F52C4B37AC26E368064A,
	AkAudioListener_OnEnable_m5BFAA659BAC9FBF5F4E214A8444B7EB77ADDBFD6,
	AkAudioListener_OnDisable_mC8FD57411FDB15993480A3DCD46FA0E9FDBAB42B,
	AkAudioListener_Update_m0F1848C440D6603D52D0BC2CA498DEA04F264918,
	AkAudioListener_GetAkGameObjectID_m63945B83EC3C102624C2D8BE6794D4E4CFB7C2BA,
	AkAudioListener_Migrate14_m00AAFAADD31C4DCF00DD27B38CF160F6E6EFE2F3,
	AkAudioListener__ctor_mDE8A2FA8B52DDC3C74FD18D75BF5F4C15C2A24F8,
	AkAudioListener__cctor_mA87F6C07917CF590935E5D89CB729A37FC4FCC74,
	AkBank_Awake_mAC373310C7E2B1A9B595C08729E68381DFE8625A,
	AkBank_Start_mE512EB9F712BE29CD0E48E4522BD32D2D52FBB3A,
	AkBank_HandleEvent_m9D79FF000AAC28ACD6E267CC768322835AE8E540,
	AkBank_UnloadBank_m1630FBE54D4A14081B6609D8220C0607455788D3,
	AkBank_OnDestroy_m09824F9A47FC03A31B62E03CBF2ECE106FC18F13,
	AkBank_get_bankName_mD83A97F7ADA9C1736B66ED242C883F365488CF37,
	AkBank_get_valueGuid_m210031800B84BED3EEEFED57ABABF1644A19139E,
	AkBank__ctor_m209447EB063141B658188B52F60B85F359E0ACFE,
	AkEarlyReflections_OnEnable_mBEA4DA3EA07C0F04140F0A6889A4BAF9B987DF36,
	AkEarlyReflections_SetEarlyReflectionsVolume_m1AFE6AA63B070F6F91A92AE319D4B7D40F505B31,
	AkEarlyReflections__ctor_m2E9C9D0970DA6860547E2FFA99687D3F646F4AAE,
	AkEmitterObstructionOcclusion_Awake_m6EF9651669D3D943F77599E502DED4CDC95ECAA3,
	AkEmitterObstructionOcclusion_UpdateCurrentListenerList_mE20E36E3DB5F9BECDFF4EA8A376057336E767A75,
	AkEmitterObstructionOcclusion_SetObstructionOcclusion_m55D990CE937FE58BC3619B9E6A1C7870903643B9,
	AkEmitterObstructionOcclusion__ctor_m64725B3D7AE8EB61DD7DA11F8896C9F77609235A,
	AkEnvironment_get_Collider_m65877779C993973A6903BEAF09935B9BD2739F20,
	AkEnvironment_set_Collider_m74D6D33B65662FE4262C96D56FEEB9C5D75FC2A0,
	AkEnvironment_Awake_mD528518CDA793033F2FCFF02A1631E10C46D07DF,
	AkEnvironment_get_m_auxBusID_m3F932F6BCB85A4E0CA04E34F3E04FBC8503A1EEF,
	AkEnvironment_get_valueGuid_mB600B3770B6F60DB6AC255DD57B224CC97034C03,
	AkEnvironment_GetAuxBusID_mEBC073AF9E261C207678BA2C329D142BA42B6089,
	AkEnvironment_GetCollider_m53B4616B6885FE53EF40145AF65462841109A571,
	AkEnvironment__ctor_mA03253B037D55D8C048F2135CE931A5B2D8D7A88,
	AkEnvironment__cctor_m107990CBEABF324E6EF23BD81C40276145AE8EC0,
	AkEnvironmentPortal_get_BoxCollider_m83328213A0D50DC09236B902254A0085A2C3594F,
	AkEnvironmentPortal_get_EnvironmentsShareAuxBus_m4361CFE583AF13A8CC4B085A3BAC22CA9A24DC8F,
	AkEnvironmentPortal_GetAuxSendValueForPosition_m12D05EAB9C0F892256484C24305AAF584B256A68,
	AkEnvironmentPortal__ctor_mAF885A007BD0C1112562E8EAE7DA35E14E708CF2,
	AkEventCallbackMsg__ctor_mFAB96F4DE551C1EE9E07E58B395B6928B92CDBB9,
	AkEvent_get_WwiseType_m37A2D9A46416A5948166BD698CD3EEC8B22A6A8D,
	AkEvent_Start_mA0EDDFEEC00A1FB62DABBA5C202FF01F359C66A5,
	AkEvent_Callback_m10C4A64B658E271C98EFC5FF24D1BEBC0A4C5926,
	AkEvent_HandleEvent_m36E8AC6AAB31A1EECC0D73B3013439A582CA8468,
	AkEvent_Stop_mDF5B33DEC0D9CAFC46149F633A4B46715DE6D3AE,
	AkEvent_Stop_m25D312C425F9F77F40868E98D286714EEFA4EA83,
	AkEvent_get_eventID_mA1A4456F81FF1A21391CB9DDE0CCEC3082263591,
	AkEvent_get_valueGuid_m66EAEF0ED85DED18451723B7C0E1EB49F8C24524,
	AkEvent_get_m_callbackData_m9C9605B16383F4C765B046B6C5A9CC56CE2C4767,
	AkEvent__ctor_mB484C4E01B83DD0F8EFBEA9DFB5934CC1BA96124,
	AkEventCallbackData__ctor_m8B26A9570EBB4A31F7F8B1703CA1F90071E61440,
	AkGameObj_get_IsUsingDefaultListeners_m41B4A13AA2E890D3A824C63775F4FE11BC93EF24,
	AkGameObj_get_ListenerList_m3A2A10C1D0F27EAFB316DA65D8CB228A61D12EAF,
	AkGameObj_AddListener_m25945DA7041F15026C38290BCCE8EDE3A0830AF6,
	AkGameObj_RemoveListener_m14B365D68449C766955001558E2E297DA05112E0,
	AkGameObj_Register_m43212BC00196CD9CFCF72ED247048A898A402455,
	AkGameObj_SetPosition_m41A8CF054D5849F2F9AE182369B8D500B8A767CD,
	AkGameObj_Awake_mE61143FFA54E34722EBA2A8B80E7C2D4ECA55B0F,
	AkGameObj_CheckStaticStatus_mE4AB083F44266F2D346C6542E9BBE290201358CB,
	AkGameObj_OnEnable_m80C92A594FCD6F778743E5BB7A578037132E661A,
	AkGameObj_OnDestroy_mB7EB487F404F5C5866ECBC2BD0FE7F3929C98A6C,
	AkGameObj_Update_mE1097E10C693385D580870AFD8CB703356C3D59F,
	AkGameObj_GetPosition_m5F679DD514CEDF221425EC2B4955B4CDD350AC37,
	AkGameObj_GetForward_m5FA54A2DFAEF77E43F7DC6197A3449FC296F3282,
	AkGameObj_GetUpward_mC92637671394080B7F6B14CA62768A0781B2ABE3,
	AkGameObj_OnTriggerEnter_mA1B9D531D0117521BF0C29FDD1D428BE7DD37396,
	AkGameObj_OnTriggerExit_m5E43A91077AB9C2DC7FAEE12DF77E08CAAF1CB4F,
	AkGameObj__ctor_m5F41909A0208EBAE7B6BA82CDD9345C821330832,
	AkGameObjEnvironmentData_AddHighestPriorityEnvironmentsFromPortals_m538ECAF34C5C4CA576365F7CD6009AC995C48A6F,
	AkGameObjEnvironmentData_AddHighestPriorityEnvironments_m923F9CE6779925A9454AF822DFEBEA17EDDC4A18,
	AkGameObjEnvironmentData_UpdateAuxSend_m34C4C4BBE36712BF9110F70DF80C7BA145711701,
	AkGameObjEnvironmentData_TryAddEnvironment_mC3F2B15E1E0F29C104E2ED49C17082FBD4D1112C,
	AkGameObjEnvironmentData_RemoveEnvironment_mD9DC16225D00E3ABD76947F905744A0EAF6419E3,
	AkGameObjEnvironmentData_AddAkEnvironment_mF1E4850D28160BD023FABF7177E0BCFE22DCB7FB,
	AkGameObjEnvironmentData_AkEnvironmentBelongsToActivePortals_m61CB7A01ED610F38C94E01A546C7D6DAEA8A8455,
	AkGameObjEnvironmentData_RemoveAkEnvironment_m63564B12BBB75B03B0EC8E0315656C226C36BFC9,
	AkGameObjEnvironmentData__ctor_m8543FB199B824B823B834DD13107AC110E67F188,
	AkGameObjListenerList_SetUseDefaultListeners_mAB2A789F0BADE7D9BB5D739DCDF2342FCDD5000F,
	AkGameObjListenerList_Init_m0A7C7990785864A9AFBF165DB142A869EC7354F7,
	AkGameObjListenerList_Add_m9E894412F89DDA978ECA0E5502B783EB0BA2F59E,
	AkGameObjListenerList_Remove_m90A1F7F27AD7B2D601A97FBB1D1F9CE29944BD79,
	AkGameObjListenerList__ctor_mD84365C75DC04B85CEFA30D7BDEC4EE5C0448E9E,
	AkGameObjPosOffsetData__ctor_mE60ED5211415BD049398E65AF335C26DA5DEC7A0,
	AkGameObjPositionData__ctor_mBD2AD04DA13E1899F2E95040BCF19AF67ED9B5E4,
	AkGameObjPositionOffsetData__ctor_m8B1DB67BF486DF7F7CE5785BB12CB7598CBC844B,
	AkInitializer_Awake_m797D3CB395A3FFD28CAB1E9CDF837F79EAE801FC,
	AkInitializer_OnEnable_m7F88C0768B73CC7C09DA1FD5AE500A1BD01E9E9C,
	AkInitializer_OnDisable_m3C34A35992E9A769A166C5B136D8305F7FB552EC,
	AkInitializer_OnDestroy_m77067FA4FDE9B2D3A2F089A6306A3AC1131E811D,
	AkInitializer_OnApplicationPause_m69DC87DD9629FF38A459C0B7B3FEF3C06B1C98F4,
	AkInitializer_OnApplicationFocus_m8A68CEEBC0634B20995501C031C258DC7788EB01,
	AkInitializer_OnApplicationQuit_m4E6FBBECF0B77AB088DDC1448D34A96A7858E393,
	AkInitializer_LateUpdate_mC6F5F64F755BC395F5ACE9E33516CFD19FEB9CC5,
	AkInitializer__ctor_m42D59A76F989DB32FF7B522DA68911E4B9856E1C,
	AkMemBankLoader_Start_mE10DE98B91637CA52ADA53022BCB9DEFF3C0D34B,
	AkMemBankLoader_LoadNonLocalizedBank_m8319D0FBB89CF5681F722B11374EEF66F6D38903,
	AkMemBankLoader_LoadLocalizedBank_m33063767BA1071624A71D1EC768DF345EF4F263C,
	AkMemBankLoader_AllocateAlignedBuffer_mA448AEF21063773C7345A908C8AAD0A79EF3F8BF,
	AkMemBankLoader_LoadFile_m95ED610F7B19B780FA65D93C50030D6C1B050D7A,
	AkMemBankLoader_DoLoadBank_m2AD9CFBD62D23BA20D2010F1CD7C285970B41DF6,
	AkMemBankLoader_OnDestroy_mA6399B3A4ABD953B69CB15BBBEC886EFE4D5B724,
	AkMemBankLoader__ctor_m62AD76ED8499AC6B71A7D5144B4222C539530CDE,
	AkObstructionOcclusion_InitIntervalsAndFadeRates_m910FE747479822278E6E3EE1F5477A75BCB4FDD7,
	NULL,
	AkObstructionOcclusion_UpdateObstructionOcclusionValues_m4C5C339242A4A66AB8C017F7EA0A91B8E40516B5,
	AkObstructionOcclusion_CastRays_m7A3AF28F52BEECD1E77463445B2CA46CB91652C8,
	NULL,
	AkObstructionOcclusion_Update_m10BBECEFD7187140A9B357E14990C3EF2BBC2A4C,
	AkObstructionOcclusion__ctor_mB234B4257001E2B506747E3487A508933A594E3E,
	AkRadialEmitter_SetGameObjectOuterRadius_mA30A2279218EDCD881C7DCB2C847B91AE9E68877,
	AkRadialEmitter_SetGameObjectInnerRadius_mFACE4CFCDF17CE50A5864DC296DC218232A388B7,
	AkRadialEmitter_SetGameObjectRadius_mFC075FEA1F37D1441D1703B4F6B5BB61ED2A6502,
	AkRadialEmitter_SetGameObjectRadius_m26C4699A0954A11F3BEBC9C1F7D45E0F690C9AAF,
	AkRadialEmitter_SetGameObjectRadius_m5632109F37C604E70089ADBC83A16F71287E4563,
	AkRadialEmitter_OnEnable_mBDC9A14FE5A60785DD7359FE8FD467DBF4762D61,
	AkRadialEmitter__ctor_mFAC6B10A038B76258CEA79DD0B2A8E4430A6BB15,
	AkRoom_GetAkRoomID_mE221813B9CB262E874A9CF1DEAB1ADFCD16EFE34,
	AkRoom_get_RoomCount_m18B0D24B5AF666F4D8D64E12F20301FB936AD055,
	AkRoom_set_RoomCount_mA822414F0BD8BF4B5F7DDA5A89D0A00042273F3C,
	AkRoom_TryEnter_m8E13FE1FD6DF46E4547DBF1A4F66CA0697B06814,
	AkRoom_Exit_m37AC618E86EAC271D27FF1AA543421C515AAF175,
	AkRoom_GetID_m4DC1CD4E1D7D1B379BFA314C74E0CE53A249F92E,
	AkRoom_SetRoom_m1DF05059A40216631DC5970270FCA972BDEEBB24,
	AkRoom_GetCapsuleScale_mDF935F777E8AAD1C19033EA5579AC0B400A385F5,
	AkRoom_GetGeometryID_mB24BD53DC120BFB23BBB88E0D3FB4F0E1ACF3F2E,
	AkRoom_OnEnable_mF86872C3CF676E107A37683AB00ED5873E876605,
	AkRoom_OnDisable_m067BABFC55E57234E9FC879C9802211BE20A29E6,
	AkRoom_OnTriggerEnter_m151069C55CB34BC30431F36573C31A2678AA8734,
	AkRoom_OnTriggerExit_m7A71AC04F7682DDE350BDDEFEFB8CB01D7C1D176,
	AkRoom_PostRoomTone_mD8B4401166012F846BB17F43FC1AB907D538506E,
	AkRoom_HandleEvent_m4F31412C140538F885BAFB8AD180B84358F6538D,
	AkRoom_get_wallOcclusion_mBCFC280EDBF61012FB6E8D39179C3AAA8ACD09C3,
	AkRoom_set_wallOcclusion_mE252FA53EBF17B801EFEC64B1475103ADC934743,
	AkRoom__ctor_m675081BF544042320FF23F6F753E5742AFF46B0A,
	AkRoom__cctor_m8818E9AB56622F5548C253A1EFDDD7950E0455E1,
	AkRoomAwareManager_RegisterRoomAwareObject_m2318DD031F95F4BF354599362385FECE9DC01019,
	AkRoomAwareManager_UnregisterRoomAwareObject_mD6200F411DEDEDA8D04CDC1D485C7EFC7131CB79,
	AkRoomAwareManager_RegisterRoomAwareObjectForUpdate_mE13BB788CD686462A3AB8911B32BF1E8A313DCB4,
	AkRoomAwareManager_ObjectEnteredRoom_m04F570E2EBDF8AD15CCC357E89F15182F7A27406,
	AkRoomAwareManager_ObjectEnteredRoom_m6EFFC5DD1EF1462BA691A34576ECBC066926B64C,
	AkRoomAwareManager_ObjectExitedRoom_m39A12FC3DB608BE05781CEB7D31219DD47A8D7CD,
	AkRoomAwareManager_ObjectExitedRoom_mEF4E9C13B790AF1C6AF48B98056F6E8D4CD91D5E,
	AkRoomAwareManager_UpdateRoomAwareObjects_m76BA1B7236CAA6DFE9E3839DB3B9ADD70B1302E3,
	AkRoomAwareManager__cctor_m6FD71CB52142D617F6317E1F8F042B6BF4B86942,
	AkRoomAwareObject_GetAkRoomAwareObjectFromCollider_mE17BF244F8EB5304647936C098CB9DD6C8CBD34A,
	AkRoomAwareObject_Awake_m8A46A5F4FF1A06B9B248DE47DB667B82B1C3C07B,
	AkRoomAwareObject_OnEnable_mB2CCA3DA8E630C8B35D54B6C30A8E4FC1099846D,
	AkRoomAwareObject_OnDisable_mC67429AD5E39D80411C79B55E288A56CF9ADECE0,
	AkRoomAwareObject_OnDestroy_m866F9670C58E604AD278860F26881FE0F258851C,
	AkRoomAwareObject_SetGameObjectInHighestPriorityActiveAndEnabledRoom_m93F075B4E8E7E3D845C598BFCCFC45DBD320DAB6,
	AkRoomAwareObject_SetGameObjectInRoom_m0E471D6066C89A5EE2A2203AC94A655C854B0FF4,
	AkRoomAwareObject_EnteredRoom_m30F9868D6D1864B8DBF652145370EBAFBC8C17A5,
	AkRoomAwareObject_ExitedRoom_mDE8568AB4B59C39A704174A2227BD1C12E79D093,
	AkRoomAwareObject__ctor_m1D7ECC042B61739C258933FBFB22C656931172B4,
	AkRoomAwareObject__cctor_m5BC0E672C58201C2DE2E6B8F42351E029780BE37,
	AkRoomManager_Init_mC65C173101545414B0378EAE92D24845C0702E7A,
	AkRoomManager_Terminate_m56CB2E20F01ADC8B6B1E66078DF657289E1C4049,
	AkRoomManager_RegisterPortal_mEBF8EEE080EA2C22EED60CEB911655B0CE3DB469,
	AkRoomManager_UnregisterPortal_m7D41A1B5BB87EEDDBC380877882B4DD0B73D07BC,
	AkRoomManager_RegisterReflector_m741C11D991B0AEA9185662726119A2C2EA7621DB,
	AkRoomManager_UnregisterReflector_m15537F07939C97C909D877F2C95D0696424F3455,
	AkRoomManager_RegisterPortalUpdate_m3794AB836D4D41AFC0FFA8CC1426AEFC28A5F4D9,
	AkRoomManager_RegisterRoomUpdate_m4D6052E0C467499F05D0646255C2C75F097ED53D,
	AkRoomManager_Update_m6A8516CC77612C510B2C1F23E68FB5ECBF77E24A,
	AkRoomManager__ctor_mFA3322A377829C10EB2A8370091AB03CBE9C6DB7,
	AkRoomPortal_get_portalActive_m18AB3238AA73AA2FB123D07E9612A80DC0E59C68,
	AkRoomPortal_set_portalActive_m28F322C3DBFF0FD253F09E7470DBCA50A828E747,
	AkRoomPortal_get_frontRoomID_mF9FAF34A6C8BD064EEA794204D45FA75838027DE,
	AkRoomPortal_get_backRoomID_mF6166E22145B55646913B906D145454D4CA706B4,
	AkRoomPortal_GetRoom_mE8CBA3FB1C356F40E8988A8BCC696E3B2412AE83,
	AkRoomPortal_get_frontRoom_m89628B5544BA40856C7814FF194E0BB5C87648AD,
	AkRoomPortal_get_backRoom_m08DAB06481074927E27E58E7A384B506E6671A99,
	AkRoomPortal_SetRoomPortal_m887D4E1791385824E5B0B345D199C29F67EF972D,
	AkRoomPortal_UpdateRoomPortal_m08A33E347830B9C96D61D0358C5AE1430B0F78A1,
	AkRoomPortal_Overlaps_m6E54A88CFFEEC6C6701FDB41D56D86E439251271,
	AkRoomPortal_get_IsValid_mB1013323F372A7DF192C5282879E286779456F3C,
	AkRoomPortal_GetID_m5BD7D664F5B45DAF4B989D9196716687FDC64D69,
	AkRoomPortal_Awake_m164C38189A239F6563E07A4A4F532AB1EC9134B7,
	AkRoomPortal_Start_m821CE400ACBEBCCB9AB2207F11F48C918CA8B797,
	AkRoomPortal_HandleEvent_mB5878CD3DB4D70DCB41C010FA6EB3A74F9E685DF,
	AkRoomPortal_ClosePortal_m6D8D38F087836DB0D2412A9697C82026F6B7B7FC,
	AkRoomPortal_OnDestroy_mB7A0E91F11F63FE37EF58F33DF086CE411D59939,
	AkRoomPortal_OnEnable_mD449ACBD357BC092892B8CE88835323E5EF574CE,
	AkRoomPortal_OnDisable_mDEC5100D4DECC67B00548AFCCB332C38A55565CD,
	AkRoomPortal_IsRoomActive_m276583F2DDFB7B84B95C25CAE67F732965BF1D3F,
	AkRoomPortal_Open_m2C4822BC2E5AEF1B9C34D7670805C66C65247EC6,
	AkRoomPortal_Close_m099B83A48E6739AA9783AACF764843182676EC9C,
	AkRoomPortal_FindOverlappingRooms_m7AB09936003B6288D136C68DA504626D5831AEEE,
	AkRoomPortal_FillRoomList_m4A74123AD46B94FF7517320B338D9E6FD4DEE9E1,
	AkRoomPortal_UpdateRooms_m833790F95374D9E76FB434F7582BA2DB734DAAEA,
	AkRoomPortal_SetRoom_mFD3FD429CFA7354762784B185616D3C11AF6DF79,
	AkRoomPortal_SetFrontRoom_m26E29FFAFBC72773F495E2BFDA062D444B0213F4,
	AkRoomPortal_SetBackRoom_m41C3F46C5392D6D8D932441C8570F77D2BED2455,
	AkRoomPortal_UpdateSoundEngineRoomIDs_mCAC6D28DFEC3E0890761D5E08B220BA3431E7FA3,
	AkRoomPortal_UpdateOverlappingRooms_m1679EA2A2E7F2A516DB484F8EE7B74EFD36C2857,
	AkRoomPortal__ctor_m5AEFE54D23127EA5558D0991057CF74F4B71D688,
	AkRoomPortalObstruction_Awake_m4CBB028E7427F95C1B8339160B6E3264BF86E1E4,
	AkRoomPortalObstruction_UpdateCurrentListenerList_m0547D6B9943AC9E191A519485D35FC83FCAE0287,
	AkRoomPortalObstruction_SetObstructionOcclusion_m064242A547E99D9044424A3F7BC09357255B1A57,
	AkRoomPortalObstruction__ctor_mE047AF1D82CE062C410392FDF1D1EAB750DE434B,
	AkSoundEngineController_get_Instance_mA66616663FE3EC41603FC735B55EFB4630906D55,
	AkSoundEngineController__ctor_m972A3A562B05FC5F9DC40FEE00A3ECC82FE8B557,
	AkSoundEngineController_Finalize_mC2FCD185E62C1610B170C7F7B1BE359A35F1CEE7,
	AkSoundEngineController_LateUpdate_m22CCEBDE9EA68D0CD1F40BDCC2DE62432EDD042F,
	AkSoundEngineController_GetInitSettingsInstance_m31BCEFBC6B5EE52A9CA84C700E506CDD992A80C3,
	AkSoundEngineController_Init_m671A97B796E77D34FC7D11BEECAD63BFB60DFD5C,
	AkSoundEngineController_OnDisable_m6C6B0B8D32FC84EDAE00ACE8F70AAC85017C5CF8,
	AkSoundEngineController_Terminate_mCF64EED8CEDDD45F5D9299358B71E3B08D843AC6,
	AkSoundEngineController_OnApplicationPause_mA505F1BCC14D458A9EB178DEF53788D19865380D,
	AkSoundEngineController_OnApplicationFocus_m5DEE95DB3A9124E4050FCC3C3529DF154C0B22BA,
	AkSoundEngineController_ActivateAudio_m290C3BE630F6DB5FBCA703757E1EDAD7542092FD,
	AkSpatialAudioDebugDraw__ctor_m9913A2BFED56DE782F54F99EE002058EEEA23B49,
	AkSpatialAudioEmitter__ctor_m690D886355E3EBBE9991D923D31CE14D3026D92F,
	AkSpatialAudioListener_get_TheSpatialAudioListener_m7FDE5271A2F5841EEF0534970579A540F0454959,
	AkSpatialAudioListener_get_SpatialAudioListeners_m77BD0CF877F206C3FBC8E548DCC34D25B30DCC02,
	AkSpatialAudioListener_Awake_m97156EE04DBE1ACA9C4339AD41935AAA1F7DF2DF,
	AkSpatialAudioListener_OnEnable_m801B101C588095CE88674720CE95DE3B81851A57,
	AkSpatialAudioListener_OnDisable_mD7DCB836C49EE34F99FB65F1DAA54AD307DD1B01,
	AkSpatialAudioListener__ctor_m2F59AC93CE6E73090BB1D471B332C54B94E99B87,
	AkSpatialAudioListener__cctor_m922AC62B14BBC9C44B458C3CFB813948D69561F5,
	AkState_get_WwiseType_m4A90AE03E39F0497EB68B26D74B5DE874C8A3422,
	AkState_HandleEvent_m22E7BAEF601A84631378FC64BE955C3CF052E088,
	AkState_get_valueID_m1C36A5062444FDBD886B1BBE12CF470E78B5A970,
	AkState_get_groupID_mC74E0E94A8E2811B7A0E4EFD450EB2CE1C361DAA,
	AkState_get_valueGuid_m53B0463978C45F361BA89A891FC410A7CA0EB9A7,
	AkState_get_groupGuid_m3F0318D79B0EF589154B4DB5B22371D72788B750,
	AkState__ctor_mE76E15ACCAAA00D510B2724B9BAF85B92BE0F7DF,
	AkSurfaceReflector_GetID_m7368B22142562B8FCCF8DD5900DBF3979F82CBE1,
	AkSurfaceReflector_SetGeometryFromMesh_m2A9DC790E6B76C0EA8CB3CE7C5B0CE61BD95C708,
	AkSurfaceReflector_SetAssociatedRoom_m6824EE2788EFD029BFED4CDFA56D016BD14217A1,
	AkSurfaceReflector_SetGeometry_m201B4FFC7FB97B788DCCFB6829ACB4C5377947A9,
	AkSurfaceReflector_UpdateGeometry_m8E65C04BAB7A9CAD5FB65A27AA677ACFCE2902CB,
	AkSurfaceReflector_RemoveGeometry_mBE46396E0C87F4BA989AC5310A38D61E3811A0AE,
	AkSurfaceReflector_RemoveGeometrySet_mDFDBAA066EBA981303232DDB3B2EC3F5D387D45A,
	AkSurfaceReflector_Awake_m726CD36A7CDC7B7D91D3B570A74E0354460AA04C,
	AkSurfaceReflector_OnEnable_m0BF7D1C4CFF40940C0087C20A593324D0109964B,
	AkSurfaceReflector_OnDisable_m6F2B56C91193FED4AC58C63D2CEEA86CC7576185,
	AkSurfaceReflector_GetAkGeometrySetID_m6EF88E8E4DFE0796F88EB57B423930E079F6E6D2,
	AkSurfaceReflector_AddGeometrySet_m6002C7281CD77D6ECC153A750484B28036D0EB4F,
	AkSurfaceReflector_get_AcousticTexture_m325283F16C8D5586C628BFE296DB67F97BC6D0DE,
	AkSurfaceReflector_set_AcousticTexture_m9F7DF017BA86AC10ED11EBCF8EF5268B75F76D2B,
	AkSurfaceReflector_get_OcclusionValues_m76853597C3CA201D27EDC54D847E3C9F553D92E2,
	AkSurfaceReflector_set_OcclusionValues_m57F39D78A4AF01AB239464AAD170B33CDAAFC2DA,
	AkSurfaceReflector__ctor_mB26309C65651E8401F147A591C91D5E84800C248,
	AkSurfaceReflector__cctor_m49DF7901B3C6A9B6CFFE952A0ADFF2FB868972BB,
	AkSwitch_get_WwiseType_m2E1924D0343663304C3CD3BE97480CEEEC4BBAD9,
	AkSwitch_HandleEvent_m603D674C3BFB2526AE9EF149C2DBAC6F790A7699,
	AkSwitch_get_valueID_mEBF306EFFCD5D3AA33445426E6504F8DBCD3B105,
	AkSwitch_get_groupID_m3A41A65DAE179B2491C3B6D55A1B1EC4CCA4A829,
	AkSwitch_get_valueGuid_m4DEA598DED5B3DF29378DF580B244E4E54375913,
	AkSwitch_get_groupGuid_m09429DA5DBBDBB4DAE833FCDC48A304D19B3AFD4,
	AkSwitch__ctor_mADD94392D4FCD64B111060EBD7137F6942507929,
	AkTerminator__ctor_mF75A8A32C34312AF88FFD94568B3F861774F56B7,
	AkTriggerBase_GetAllDerivedTypes_mC338EACE9CE56503198BD4F195042D46973DA17B,
	AkTriggerBase__ctor_m9D5775053972609EA5122FF00A3F0A55420C5B0C,
	AkTriggerCollisionEnter_OnCollisionEnter_m6428913AD15C2D7F8372C2BABFFE64508E0C8D0A,
	AkTriggerCollisionEnter_OnTriggerEnter_m289963135558E1FCC4B0DF4AE196FDB085CA84F9,
	AkTriggerCollisionEnter__ctor_m8D91F1812E49F9EA79AAA6DC165B34917CA87CF5,
	AkTriggerCollisionExit_OnCollisionExit_mD09DE26F203EA54DB07F5767F72F5F640763647C,
	AkTriggerCollisionExit__ctor_mFF38470E502204090AF7837689AE09E62CE44381,
	AkTriggerDisable_OnDisable_mBC3D196E4CEE190293A06C451CEC030E953F6627,
	AkTriggerDisable__ctor_mA3D2D4115E3784BA37F2104567AF319FA2B66E19,
	AkTriggerEnable__ctor_m6909D337F01F613A731E4F78739EBD28898852D4,
	AkTriggerEnter_OnTriggerEnter_m0EA8915D6E2EDECCFFF024EB23FB2305FBC541E0,
	AkTriggerEnter__ctor_mC712377B2DD34CA0BB5EE9ADE55D62EEF40B255A,
	AkTriggerExit_OnTriggerExit_m18C09FAA3A170EE9BBC9DB64FA413DD054F146E5,
	AkTriggerExit__ctor_m822128589E50F07DFDA6A7394EA0972A127C6B33,
	NULL,
	AkTriggerHandler_Awake_m869064E99F4D8486A97A3488DC31DA885ADF2B9D,
	AkTriggerHandler_Start_m38613C29E76BB6A8CED9D0B6C83AB91AE9C783A7,
	AkTriggerHandler_OnDestroy_m0634BB8F6F51E604100630C1297E102DB7AF800B,
	AkTriggerHandler_DoDestroy_m2B3D3BCE3D8005A2E3FEE27966CF8845D1A91AD5,
	AkTriggerHandler_RegisterTriggers_m248835CE7CF7815D635ECF282419219C324DC2E5,
	AkTriggerHandler_UnregisterTriggers_mC08B80CC4956E6CFB190FC433BC13CB9A3A494EA,
	AkTriggerHandler__ctor_mA51D5264D3AEA7FFAB45CE168135EB2276BC5C5B,
	AkTriggerHandler__cctor_m93C0573F6647EDF4E2FEDB6747BC22141931F2FB,
	NULL,
	AkDragDropTriggerHandler_Awake_m02398C3E373522151D745AC1535E9C430C0E765E,
	AkDragDropTriggerHandler_Start_mCD0DA688F9EA13BB97A88F730F403F495B7EADEA,
	AkDragDropTriggerHandler_OnDestroy_m33372FBB0014E6F5327CD3ED22B2A50B653E2FFE,
	AkDragDropTriggerHandler__ctor_mE178637D9D21E9D3891C73C68C0D0997D619E453,
	AkTriggerMouseDown_OnMouseDown_mA44F27B56A86B5D01DE79FE8113876AC9F3D23AF,
	AkTriggerMouseDown__ctor_m729E5800F75AF38D5C2F12A2C7B94E72B46CB7AF,
	AkTriggerMouseEnter_OnMouseEnter_m68A1B708AB394E53A030E0F12231E025FEEE561F,
	AkTriggerMouseEnter__ctor_m8881D675B5A17875511DAFC8CC83F9149EF1D90C,
	AkTriggerMouseExit_OnMouseExit_m7078CB6E46C565C5FDF987752143B6CDD166906A,
	AkTriggerMouseExit__ctor_m321A34D10E8EEAA6FA963AF3C889CD316FA144A9,
	AkTriggerMouseUp_OnMouseUp_mF39BB1DB4F0341826B0857E36FC6E92F1EA063B7,
	AkTriggerMouseUp__ctor_m46762357A5A50562619C2368F05CD0C13998FE27,
	BaseListenerList_get_ListenerList_mC6B374A7F0343CAA95349038593B22CD5246BA6B,
	BaseListenerList_Add_mC99DEC88B3408C57FC660CD39FAA8D30F54CB599,
	BaseListenerList_Remove_m8E1F0A7FC0C4899586D53F0E5E7F0F8B85A688F6,
	BaseListenerList_GetListenerIds_mF14D924A6ABAEB9E74C13BEC671EB7C9B95CB248,
	BaseListenerList__ctor_mE005B9B403FC5A1422BB6A878ABC1620DDE2ED27,
	DefaultListenerList_Add_mBD889E228AB5B96CD1B02A633F51FCB6E059EF60,
	DefaultListenerList_Remove_mD9EB89E9965B9A121BA8BFF462CA38412DC977E1,
	DefaultListenerList__ctor_m0A8BF0D269164F30555C4DB8B8E0086D3A588E84,
	AkEnvironment_CompareByPriority_Compare_mC901241A77C21547AB3520D5ACC9FAEFC8BEC1B2,
	AkEnvironment_CompareByPriority__ctor_m92D551FAA2971E369052A3DD32AFE1DD3D0C0B1E,
	AkEnvironment_CompareBySelectionAlgorithm_Compare_m5152FAC9FC959CCAB86EC683B93F2308E0799A9D,
	AkEnvironment_CompareBySelectionAlgorithm__ctor_m4A62447376982AFFE0092E656EC5DD0E6D55E7A8,
	CallbackData_CallFunction_mEF222802AB68A78D4EC186D3A981982ECF1AC38C,
	CallbackData__ctor_m5A294F59DC0E2A3778D72E4ECF84713261A2802F,
	U3CLoadFileU3Ed__14__ctor_mB982D5A675A39A0F41B5D8A8969A768C2709FB9B,
	U3CLoadFileU3Ed__14_System_IDisposable_Dispose_m6E764F953C0B9CE9BEBD8F916A468D0553F819EF,
	U3CLoadFileU3Ed__14_MoveNext_m36BFA4BB0FDE5F11CE4503DBE24B4C61A48E66D1,
	U3CLoadFileU3Ed__14_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1EFFF7EDF67177181237CDC6FFFC59857619E059,
	U3CLoadFileU3Ed__14_System_Collections_IEnumerator_Reset_m50381B0312FC6CBE7F40A21B43997A183DAEEDAB,
	U3CLoadFileU3Ed__14_System_Collections_IEnumerator_get_Current_mA1ACA0C86840851899034DA22F7551DC6E3EAFFD,
	ObstructionOcclusionValue_Update_m6EDFB01CA66B826529EF0008B14BFC1F94153829,
	ObstructionOcclusionValue__ctor_mE701E6D6E1B0F54BB87D5B7B15A41EC4B5AD5A33,
	PriorityList_GetHighestPriorityActiveAndEnabledRoomID_mE41BDC1EF6602FE26CE9A78A4E5AED29EDD1B3C7,
	PriorityList_GetHighestPriorityActiveAndEnabledRoom_mE26F56E1294C77A8CE0504122F0B785B7A4B6155,
	PriorityList_get_Count_m73ACE23A019E8F12ED8B87FDBA069BCD868A99D5,
	PriorityList_Clear_mBF47C8611DEFC3569394FD3FD2BDCF669EAE874E,
	PriorityList_Add_mE03888CB02F2B698B3135EA85404A24BAF2FB517,
	PriorityList_Remove_mD5CC0DDD400F68786FCD3A2F6E22E281FB10546F,
	PriorityList_Contains_mCC22DB31BCE851EC10C16458004ECE77EEE7F701,
	PriorityList_BinarySearch_m4DF107432088FA7AEA7B680CEEF7774694D8EC1C,
	PriorityList_get_Item_mF7C7533D90902C28676C54BE027383F8681CA093,
	PriorityList__ctor_mBDF2342AB55347945ECAB03B97F52850C97C39F9,
	PriorityList__cctor_mE7C97D8F0A2992B1C977910A3E4BED064F88A053,
	SpatialAudioListenerList_get_ListenerList_m793D88049C80D103FB66EBB8AF1EC857C349EC59,
	SpatialAudioListenerList_Add_mF6419C7D3DE60EFE1A6D3E7D5751862A3B917C4E,
	SpatialAudioListenerList_Remove_m60B72CD217E5EAC0E638A557285064E6E0631B59,
	SpatialAudioListenerList_Refresh_m3113DE951531925E91997114044921C0E3AAE6EB,
	SpatialAudioListenerList__ctor_m766F63C31F341B792FDD57ACE8B85795648C715C,
	Trigger__ctor_m2568516901F5E7F917C3E21011C024CDA5CEB2AA,
	Trigger_Invoke_m5C703ED65465C52CB38C6CAA5F4F403FC19CC3A3,
	Trigger_BeginInvoke_m6868360963FF665A6D640AE1D053C6797A5DABDA,
	Trigger_EndInvoke_mCF3675C00A37FF6D633DF26A4B3E81C083DE016C,
	CompareByPriority_Compare_mC849AC9FFFA5A72E923B3A1C490FFE4CE92993FB,
	CompareByPriority__ctor_mC130010F6B66FDDCD0AF2AD8D762B100095439DF,
};
static const int32_t s_InvokerIndices[349] = 
{
	107,
	23,
	23,
	23,
	23,
	26,
	23,
	28,
	14,
	23,
	3,
	1351,
	1351,
	1351,
	23,
	4,
	26,
	26,
	31,
	23,
	23,
	23,
	23,
	182,
	23,
	23,
	3,
	23,
	23,
	26,
	26,
	23,
	14,
	14,
	23,
	23,
	326,
	23,
	23,
	23,
	2657,
	23,
	14,
	26,
	23,
	10,
	14,
	10,
	14,
	23,
	3,
	14,
	89,
	2658,
	23,
	23,
	14,
	23,
	107,
	26,
	32,
	129,
	10,
	14,
	14,
	23,
	23,
	89,
	14,
	26,
	26,
	10,
	23,
	23,
	23,
	23,
	23,
	23,
	1351,
	1351,
	1351,
	26,
	26,
	23,
	1352,
	1352,
	2659,
	26,
	26,
	27,
	9,
	27,
	23,
	31,
	26,
	9,
	9,
	23,
	23,
	23,
	31,
	23,
	23,
	23,
	23,
	31,
	31,
	23,
	23,
	23,
	23,
	26,
	26,
	112,
	14,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	2657,
	23,
	23,
	326,
	326,
	1316,
	23,
	26,
	23,
	23,
	160,
	106,
	173,
	9,
	26,
	182,
	23,
	2660,
	182,
	23,
	23,
	26,
	26,
	23,
	26,
	714,
	326,
	23,
	3,
	163,
	163,
	163,
	137,
	137,
	137,
	137,
	3,
	3,
	0,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	26,
	23,
	3,
	3,
	3,
	163,
	163,
	163,
	163,
	163,
	163,
	3,
	23,
	89,
	31,
	182,
	182,
	34,
	14,
	14,
	23,
	23,
	9,
	89,
	182,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	9,
	23,
	23,
	26,
	2661,
	23,
	62,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	2657,
	23,
	4,
	23,
	23,
	23,
	14,
	26,
	23,
	23,
	31,
	31,
	42,
	23,
	23,
	4,
	4,
	23,
	23,
	23,
	23,
	3,
	14,
	26,
	10,
	10,
	14,
	14,
	23,
	182,
	2662,
	26,
	23,
	23,
	23,
	163,
	23,
	23,
	23,
	160,
	2663,
	14,
	26,
	14,
	26,
	23,
	3,
	14,
	26,
	10,
	10,
	14,
	14,
	23,
	23,
	4,
	23,
	26,
	26,
	23,
	26,
	23,
	23,
	23,
	23,
	26,
	23,
	26,
	23,
	26,
	23,
	23,
	23,
	23,
	27,
	27,
	23,
	3,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	9,
	9,
	14,
	23,
	9,
	9,
	23,
	41,
	23,
	41,
	23,
	26,
	23,
	32,
	23,
	89,
	14,
	23,
	14,
	475,
	23,
	182,
	14,
	10,
	23,
	26,
	26,
	9,
	112,
	34,
	23,
	3,
	14,
	9,
	9,
	23,
	23,
	124,
	26,
	213,
	26,
	41,
	23,
};
extern const Il2CppCodeGenModule g_AK_Wwise_Unity_MonoBehaviourCodeGenModule;
const Il2CppCodeGenModule g_AK_Wwise_Unity_MonoBehaviourCodeGenModule = 
{
	"AK.Wwise.Unity.MonoBehaviour.dll",
	349,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
