﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String UnityEngine.JsonUtility::ToJsonInternal(System.Object,System.Boolean)
extern void JsonUtility_ToJsonInternal_m9BE2809ED2EE4486F4636C638F60342849ED9C7D (void);
// 0x00000002 System.String UnityEngine.JsonUtility::ToJson(System.Object)
extern void JsonUtility_ToJson_m588D3BCFA6FC7FA342FC221D4CB02729E901E573 (void);
// 0x00000003 System.String UnityEngine.JsonUtility::ToJson(System.Object,System.Boolean)
extern void JsonUtility_ToJson_m7726F8B90F5F4049147B9463CC08672A29B603FA (void);
static Il2CppMethodPointer s_methodPointers[3] = 
{
	JsonUtility_ToJsonInternal_m9BE2809ED2EE4486F4636C638F60342849ED9C7D,
	JsonUtility_ToJson_m588D3BCFA6FC7FA342FC221D4CB02729E901E573,
	JsonUtility_ToJson_m7726F8B90F5F4049147B9463CC08672A29B603FA,
};
static const int32_t s_InvokerIndices[3] = 
{
	162,
	0,
	162,
};
extern const Il2CppCodeGenModule g_UnityEngine_JSONSerializeModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_JSONSerializeModuleCodeGenModule = 
{
	"UnityEngine.JSONSerializeModule.dll",
	3,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
