﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void AkWaapiClient::add_Disconnected(Wamp_DisconnectedHandler)
extern void AkWaapiClient_add_Disconnected_m23455C48DF662205286001B85808AB1D4A8306E9 (void);
// 0x00000002 System.Void AkWaapiClient::remove_Disconnected(Wamp_DisconnectedHandler)
extern void AkWaapiClient_remove_Disconnected_m0B10E01BB8B37C4FEF60591D0AA9F8943EE7345D (void);
// 0x00000003 System.Threading.Tasks.Task AkWaapiClient::Connect(System.String,System.Int32)
extern void AkWaapiClient_Connect_m7B36FAFC8A88A778B1976073C457ACAFAD495374 (void);
// 0x00000004 System.Void AkWaapiClient::Wamp_Disconnected()
extern void AkWaapiClient_Wamp_Disconnected_mA53BAA173A2BFE01B0BD97F5BF3A2D1EC9E0113F (void);
// 0x00000005 System.Threading.Tasks.Task AkWaapiClient::Close(System.Int32)
extern void AkWaapiClient_Close_mE0747AE29CCE6D2F9367E62C7748CD02B2586A8B (void);
// 0x00000006 System.Boolean AkWaapiClient::IsConnected()
extern void AkWaapiClient_IsConnected_m8946333A475C43407EA8008736236EFBBE2E103C (void);
// 0x00000007 System.Threading.Tasks.Task`1<System.String> AkWaapiClient::Call(System.String,System.String,System.String,System.Int32)
extern void AkWaapiClient_Call_m228E834AEDE74F68F26208B1073183014B984763 (void);
// 0x00000008 System.Threading.Tasks.Task`1<System.UInt32> AkWaapiClient::Subscribe(System.String,System.String,Wamp_PublishHandler,System.Int32)
extern void AkWaapiClient_Subscribe_m4E52D19C0C845D3CCA1A1DA5CA9A77DAB7BDF996 (void);
// 0x00000009 System.Threading.Tasks.Task AkWaapiClient::Unsubscribe(System.UInt32,System.Int32)
extern void AkWaapiClient_Unsubscribe_m1B4867EC231A6315D787905D00FCD8E6A249EC25 (void);
// 0x0000000A System.Void AkWaapiClient::.ctor()
extern void AkWaapiClient__ctor_mB410C36E69BBAFD1C690B4872D89C02F38876242 (void);
// 0x0000000B System.String JsonSerializable::op_Implicit(JsonSerializable)
extern void JsonSerializable_op_Implicit_m3C7EB2F1AB6BCB3FE77634021CC6841E1B179680 (void);
// 0x0000000C System.Void JsonSerializable::.ctor()
extern void JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE (void);
// 0x0000000D System.Void Args::.ctor()
extern void Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9 (void);
// 0x0000000E System.Void WaqlArgs::.ctor(System.String)
extern void WaqlArgs__ctor_m544A7F4EE9BF592CCB63E265D4E5903CEB3D8FEA (void);
// 0x0000000F System.Void ArgsObject::.ctor(System.String)
extern void ArgsObject__ctor_m8F267DB607A75FCF3F2FA67A0F59A6F677FA0191 (void);
// 0x00000010 System.Void ArgsRename::.ctor(System.String,System.String)
extern void ArgsRename__ctor_mED3E3B39211B2C8E699CBC3C519F3FAC37C6FFCD (void);
// 0x00000011 System.Void ArgsDisplayName::.ctor(System.String)
extern void ArgsDisplayName__ctor_m2B14218C56F0061404AC79875F90150C2FD76D63 (void);
// 0x00000012 System.Void ArgsCommand::.ctor(System.String,System.String[])
extern void ArgsCommand__ctor_m60D67E600FEA543B4081DCC6AA447751013D6E1B (void);
// 0x00000013 System.Void ArgsPlay::.ctor(System.String,System.Int32)
extern void ArgsPlay__ctor_m15D42EC03786D00B07138F46DCD3751BF167AD5C (void);
// 0x00000014 System.Void ArgsTransport::.ctor(System.Int32)
extern void ArgsTransport__ctor_mF279D8D1041917F43379FFC68EC8E345367F5C74 (void);
// 0x00000015 System.Void Options::.ctor()
extern void Options__ctor_mB2226F341FEBF5B020CF7942625A2F7652485163 (void);
// 0x00000016 System.Void ReturnOptions::.ctor(System.String[])
extern void ReturnOptions__ctor_m788C3E784D91725A93065E30AB42A1578C043526 (void);
// 0x00000017 System.Void TransportOptions::.ctor(System.Int32)
extern void TransportOptions__ctor_mF0DD9736D70BF4FEE558F4AC4EEA41E7E0833270 (void);
// 0x00000018 System.Void ReturnTransport::.ctor()
extern void ReturnTransport__ctor_mDD5D0EC2E8085540DBFE074FE601CDA6EC502457 (void);
// 0x00000019 System.Void TransportState::.ctor()
extern void TransportState__ctor_m3C589B89FBBAA471911E58AF4D386EC8BEF76793 (void);
// 0x0000001A System.Void ErrorMessage::.ctor()
extern void ErrorMessage__ctor_m4DF7DC147C5FA9FBA0206CEFF78E03DED4C31AA3 (void);
// 0x0000001B System.Void ErrorDetails::.ctor()
extern void ErrorDetails__ctor_m3BA1C08EF47154C3EAF9DD5C5B7BADB4EDE30E39 (void);
// 0x0000001C System.Void ReturnWwiseObjects::.ctor()
extern void ReturnWwiseObjects__ctor_m94A86AE27A1F0BE528A4EEC26E19F2210EF8E607 (void);
// 0x0000001D System.Void ReturnWwiseObjects`1::.ctor()
// 0x0000001E System.Void SelectedWwiseObjects::.ctor()
extern void SelectedWwiseObjects__ctor_m9784904F53E10976B5EB7E76796A6DA2392C5915 (void);
// 0x0000001F System.Void WwiseRenameInfo::ParseInfo()
extern void WwiseRenameInfo_ParseInfo_m880DD2D586D1EB3FA0D9F776FFC5EC3D24D273E9 (void);
// 0x00000020 System.Void WwiseRenameInfo::.ctor()
extern void WwiseRenameInfo__ctor_mBF30859A831A058DA2650F3A26FDE0A8A05D387C (void);
// 0x00000021 System.Void WwiseChildModifiedInfo::ParseInfo()
extern void WwiseChildModifiedInfo_ParseInfo_mCC9AAA37701E3D17396ABB487C44B6851557EA3F (void);
// 0x00000022 System.Void WwiseChildModifiedInfo::.ctor()
extern void WwiseChildModifiedInfo__ctor_mA594FC7B5DD5E56C707F3BDFB1F60BE443BF3DF0 (void);
// 0x00000023 WwiseObjectInfo WwiseObjectInfoJsonObject::op_Implicit(WwiseObjectInfoJsonObject)
extern void WwiseObjectInfoJsonObject_op_Implicit_m891DE29A29F2BBD51786E3473155DB4938678A0B (void);
// 0x00000024 WwiseObjectInfo WwiseObjectInfoJsonObject::ToObjectInfo(WwiseObjectInfoJsonObject)
extern void WwiseObjectInfoJsonObject_ToObjectInfo_m34217D48C83C57B40D1772E3C02CA43DCAE739E1 (void);
// 0x00000025 System.Void WwiseObjectInfoJsonObject::.ctor()
extern void WwiseObjectInfoJsonObject__ctor_mE056E64AC8C8D8AAFE9B9170F0C585EAB59C41E4 (void);
// 0x00000026 System.Void WwiseObjectInfoParent::.ctor()
extern void WwiseObjectInfoParent__ctor_m110C353E41363504B8EDEC82627F90C2E2C3B042 (void);
// 0x00000027 WwiseObjectType WaapiHelper::GetWwiseObjectTypeFromString(System.String,System.String)
extern void WaapiHelper_GetWwiseObjectTypeFromString_m04C5DF50A1EA2E0B0188B3C71B94B2BB406A58DE (void);
// 0x00000028 System.Void WaapiKeywords::.ctor()
extern void WaapiKeywords__ctor_m90A5404044D01E8198019D449DB057627B723C92 (void);
// 0x00000029 System.Void WaapiKeywords::.cctor()
extern void WaapiKeywords__cctor_m98F6325EE529F42B2E47B71504811F517DB2059C (void);
// 0x0000002A System.Void ak::.ctor()
extern void ak__ctor_m4CCD374F6B1B80939DDEB64410380F8276567A04 (void);
// 0x0000002B System.Void Wamp::add_Disconnected(Wamp_DisconnectedHandler)
extern void Wamp_add_Disconnected_mBAA1A70AD8CE39B3A45DB824FB26FF9C2C11F143 (void);
// 0x0000002C System.Void Wamp::remove_Disconnected(Wamp_DisconnectedHandler)
extern void Wamp_remove_Disconnected_m733F63A5B3D9B63CA05DB0B31C6BE3C9456D7D9F (void);
// 0x0000002D System.Threading.Tasks.Task Wamp::Send(System.String,System.Int32)
extern void Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591 (void);
// 0x0000002E Wamp_Response Wamp::Parse(System.String)
extern void Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A (void);
// 0x0000002F Wamp_Response Wamp::ParseResult(System.String)
extern void Wamp_ParseResult_m1ED4173FAF19510DA46B93BCA58DAA6FE0140634 (void);
// 0x00000030 Wamp_Response Wamp::ParseSubscribed(System.String)
extern void Wamp_ParseSubscribed_m705D9E4D5465BAF013A92740D8D822AF448B1F23 (void);
// 0x00000031 Wamp_Response Wamp::ParseUnsubscribed(System.String)
extern void Wamp_ParseUnsubscribed_m21AF2D9070DE4E49F5CC7C53A164C1A5C2D7040E (void);
// 0x00000032 Wamp_Response Wamp::ParseGoodbye(System.String)
extern void Wamp_ParseGoodbye_m62130B50323A9CDC2F8182BA1E492B5F182A958A (void);
// 0x00000033 Wamp_Response Wamp::ParseWelcome(System.String)
extern void Wamp_ParseWelcome_mDC04C238E5A69F16500F3C9A7678B10185601B58 (void);
// 0x00000034 Wamp_Response Wamp::ParseEvent(System.String)
extern void Wamp_ParseEvent_m21C36EAE091AB9B20402C75770048AA5FC9F9020 (void);
// 0x00000035 System.Threading.Tasks.Task`1<Wamp_Response> Wamp::ReceiveMessage()
extern void Wamp_ReceiveMessage_m333714DD38A3BEBB92BA90A416BC053CDC1158BC (void);
// 0x00000036 System.Threading.Tasks.Task`1<Wamp_Response> Wamp::Receive(System.Int32)
extern void Wamp_Receive_m7B47E5C25B601C3C446B02A97117ACAA3FA3BF13 (void);
// 0x00000037 System.Threading.Tasks.Task`1<Wamp_Response> Wamp::ReceiveExpect(Wamp_Messages,System.Int32,System.Int32)
extern void Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864 (void);
// 0x00000038 System.Threading.Tasks.Task Wamp::Connect(System.String,System.Int32)
extern void Wamp_Connect_m091D964EE6A72E12FA0905681BF78AD05D9D7FAB (void);
// 0x00000039 System.Boolean Wamp::IsConnected()
extern void Wamp_IsConnected_m937F67F3943693AE69F82BA0897E18C163A0B70C (void);
// 0x0000003A System.Net.WebSockets.WebSocketState Wamp::SocketState()
extern void Wamp_SocketState_m44CB7A55E93140987D8D2C475C010842EEA0C378 (void);
// 0x0000003B System.Threading.Tasks.Task Wamp::Close(System.Int32)
extern void Wamp_Close_m8607EFADFFC175CC0825312F7EFA8E175FA39B74 (void);
// 0x0000003C System.Void Wamp::ProcessEvent(Wamp_Response)
extern void Wamp_ProcessEvent_mB6BA36EA16F2375692017561F09D725C6D2E6E35 (void);
// 0x0000003D System.Void Wamp::StartListen()
extern void Wamp_StartListen_mD58F9728B82A7A344E95BA20A462450F5725CEB8 (void);
// 0x0000003E System.Void Wamp::OnDisconnect()
extern void Wamp_OnDisconnect_m17E2623C24F5E4FE6AAC0736C0C8EB1E323D099F (void);
// 0x0000003F System.Threading.Tasks.Task`1<System.String> Wamp::Call(System.String,System.String,System.String,System.Int32)
extern void Wamp_Call_mAE552B01EB08CE7275EEDD97710E512589D61B33 (void);
// 0x00000040 System.Threading.Tasks.Task`1<System.UInt32> Wamp::Subscribe(System.String,System.String,Wamp_PublishHandler,System.Int32)
extern void Wamp_Subscribe_mC841A9CDF1DA84F41596A6E4E087CB13C8AF4F40 (void);
// 0x00000041 System.Threading.Tasks.Task Wamp::Unsubscribe(System.UInt32,System.Int32)
extern void Wamp_Unsubscribe_m185B046DAF9E4293617E8A512747B768958ABA6C (void);
// 0x00000042 System.Void Wamp::.ctor()
extern void Wamp__ctor_mCD0D3AC4AB87B0AC898D448724AB0568594D6193 (void);
// 0x00000043 System.Void AkWaapiClient_<Connect>d__4::MoveNext()
extern void U3CConnectU3Ed__4_MoveNext_m13F3495E6D4BDE5F1C839110864B68AB3F5B7BB6_AdjustorThunk (void);
// 0x00000044 System.Void AkWaapiClient_<Connect>d__4::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CConnectU3Ed__4_SetStateMachine_mDF27AC5C9A5B8B3E4254E946CBB2F67107F6F757_AdjustorThunk (void);
// 0x00000045 System.Void AkWaapiClient_<Close>d__6::MoveNext()
extern void U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517_AdjustorThunk (void);
// 0x00000046 System.Void AkWaapiClient_<Close>d__6::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CCloseU3Ed__6_SetStateMachine_m55135EC1DC2BD15058D218A67C6AB2019D6653FE_AdjustorThunk (void);
// 0x00000047 System.Void AkWaapiClient_<Call>d__8::MoveNext()
extern void U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3_AdjustorThunk (void);
// 0x00000048 System.Void AkWaapiClient_<Call>d__8::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CCallU3Ed__8_SetStateMachine_mD2692F6222738E5FB87B23429B8DD0B43F651FDC_AdjustorThunk (void);
// 0x00000049 System.Void AkWaapiClient_<Subscribe>d__9::MoveNext()
extern void U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760_AdjustorThunk (void);
// 0x0000004A System.Void AkWaapiClient_<Subscribe>d__9::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CSubscribeU3Ed__9_SetStateMachine_m5AD4A356DAE70F2EC5F1BB8257BEEF5008C4117F_AdjustorThunk (void);
// 0x0000004B System.Void AkWaapiClient_<Unsubscribe>d__10::MoveNext()
extern void U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4_AdjustorThunk (void);
// 0x0000004C System.Void AkWaapiClient_<Unsubscribe>d__10::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CUnsubscribeU3Ed__10_SetStateMachine_m3DD99D8798B4C3D9DB2A04230689657AC1139F8C_AdjustorThunk (void);
// 0x0000004D System.Void ak_soundengine::.ctor()
extern void soundengine__ctor_m778F4A903981C95FAA549572CDECF65718F23DA2 (void);
// 0x0000004E System.Void ak_wwise::.ctor()
extern void wwise__ctor_mAE8FD2766A53D97BFDE8CD14CF3B24CB3FEAD75B (void);
// 0x0000004F System.Void Wamp_TimeoutException::.ctor(System.String)
extern void TimeoutException__ctor_m2AD6BA4E69FE5415F5E571171A0346292B84E0D4 (void);
// 0x00000050 System.Void Wamp_WampNotConnectedException::.ctor(System.String)
extern void WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD (void);
// 0x00000051 System.String Wamp_ErrorException::get_Json()
extern void ErrorException_get_Json_m6F364D704AE749F82E57E62A4039891B5AA65BC2 (void);
// 0x00000052 System.Void Wamp_ErrorException::set_Json(System.String)
extern void ErrorException_set_Json_m63B27B2FF42F2763E1B259F6CAA1B1813839D6EC (void);
// 0x00000053 Wamp_Messages Wamp_ErrorException::get_MessageId()
extern void ErrorException_get_MessageId_m951111C43E1CC324EAF227B5DA4975DBA837BB5B (void);
// 0x00000054 System.Void Wamp_ErrorException::set_MessageId(Wamp_Messages)
extern void ErrorException_set_MessageId_mB2E895A07D439F8EB5C11D1E02EEC602FC84DAB1 (void);
// 0x00000055 System.Int32 Wamp_ErrorException::get_RequestId()
extern void ErrorException_get_RequestId_m820DEA354FDC75A23968D323311483801B65502E (void);
// 0x00000056 System.Void Wamp_ErrorException::set_RequestId(System.Int32)
extern void ErrorException_set_RequestId_m141F6E4AA9228ECD9320038A3FC7D0633DDD53A9 (void);
// 0x00000057 System.String Wamp_ErrorException::get_Uri()
extern void ErrorException_get_Uri_m307DAFB1DE6403546BF024E1AA100BC3B387E4BC (void);
// 0x00000058 System.Void Wamp_ErrorException::set_Uri(System.String)
extern void ErrorException_set_Uri_mEFBFD6E03D38DA354BB53E6DA1467A6E1F97BE90 (void);
// 0x00000059 System.Void Wamp_ErrorException::.ctor(System.String)
extern void ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9 (void);
// 0x0000005A Wamp_ErrorException Wamp_ErrorException::FromResponse(System.String)
extern void ErrorException_FromResponse_m7F3FD8A84BC8AEF0BC62A4CD5203DF961BC803C9 (void);
// 0x0000005B Wamp_Messages Wamp_Response::get_MessageId()
extern void Response_get_MessageId_mC397D82D70FC4A2DC73186D1CADF3ADF34CEE0D7 (void);
// 0x0000005C System.Void Wamp_Response::set_MessageId(Wamp_Messages)
extern void Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A (void);
// 0x0000005D System.Int32 Wamp_Response::get_RequestId()
extern void Response_get_RequestId_m839528D15AAC4BC39EAEB22669F38B75140A0C05 (void);
// 0x0000005E System.Void Wamp_Response::set_RequestId(System.Int32)
extern void Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4 (void);
// 0x0000005F System.Int32 Wamp_Response::get_ContextSpecificResultId()
extern void Response_get_ContextSpecificResultId_m8C53A20C58BACF5A2DA2379A42D2818F283CF862 (void);
// 0x00000060 System.Void Wamp_Response::set_ContextSpecificResultId(System.Int32)
extern void Response_set_ContextSpecificResultId_m4E0BD596C10376CFFFD141BF47A2322DBF18D760 (void);
// 0x00000061 System.UInt32 Wamp_Response::get_SubscriptionId()
extern void Response_get_SubscriptionId_m38F262E5543B6AA4EB3EDDB8A8F1365B84284383 (void);
// 0x00000062 System.Void Wamp_Response::set_SubscriptionId(System.UInt32)
extern void Response_set_SubscriptionId_m160D966B5D30F42BF0D5C133AA49CC14B62ED853 (void);
// 0x00000063 System.String Wamp_Response::get_Json()
extern void Response_get_Json_m344AA62580A8B48CEECF9F5A9B33638D572B785B (void);
// 0x00000064 System.Void Wamp_Response::set_Json(System.String)
extern void Response_set_Json_m8B200462D00D107744D54E7FD990BB541675D7F9 (void);
// 0x00000065 System.Void Wamp_Response::.ctor()
extern void Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5 (void);
// 0x00000066 System.Void Wamp_PublishHandler::.ctor(System.Object,System.IntPtr)
extern void PublishHandler__ctor_mF50D892D205E428FEBDE6AE72C209A6B386524B2 (void);
// 0x00000067 System.Void Wamp_PublishHandler::Invoke(System.String)
extern void PublishHandler_Invoke_m85F2A61F37B7D01827F76105781D219BFCF7E448 (void);
// 0x00000068 System.IAsyncResult Wamp_PublishHandler::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void PublishHandler_BeginInvoke_mE0D9DE2DBF0BDA0314F3E4BBB4C2BFDA4F2CE68E (void);
// 0x00000069 System.Void Wamp_PublishHandler::EndInvoke(System.IAsyncResult)
extern void PublishHandler_EndInvoke_mD6D4C66F02CBFF7906EFE4303E7B68793F86FF18 (void);
// 0x0000006A System.Void Wamp_DisconnectedHandler::.ctor(System.Object,System.IntPtr)
extern void DisconnectedHandler__ctor_m742456B3847D7F450EEFBD2053B6C43C3D272C80 (void);
// 0x0000006B System.Void Wamp_DisconnectedHandler::Invoke()
extern void DisconnectedHandler_Invoke_m08F15DEC1D0B8B106737140AF777D9CAEF92E79E (void);
// 0x0000006C System.IAsyncResult Wamp_DisconnectedHandler::BeginInvoke(System.AsyncCallback,System.Object)
extern void DisconnectedHandler_BeginInvoke_mDA3C965C383835C646F861342836EAA6A853D4F0 (void);
// 0x0000006D System.Void Wamp_DisconnectedHandler::EndInvoke(System.IAsyncResult)
extern void DisconnectedHandler_EndInvoke_m29EB3F908BD393FD1495681609835B5DE61A385D (void);
// 0x0000006E System.Void Wamp_<Send>d__16::MoveNext()
extern void U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72_AdjustorThunk (void);
// 0x0000006F System.Void Wamp_<Send>d__16::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CSendU3Ed__16_SetStateMachine_m5303935E88DD68C4A40AEDBFCDF18F8DEA84E31B_AdjustorThunk (void);
// 0x00000070 System.Void Wamp_<>c::.cctor()
extern void U3CU3Ec__cctor_mDD40621A39ED2248A9CD84ED04CFF64820655B0C (void);
// 0x00000071 System.Void Wamp_<>c::.ctor()
extern void U3CU3Ec__ctor_m4643EB15B51A45103D4E30A86716ACD2F70B48B4 (void);
// 0x00000072 System.Collections.Generic.IEnumerable`1<System.Byte> Wamp_<>c::<ReceiveMessage>b__24_0(System.Collections.Generic.IEnumerable`1<System.Byte>)
extern void U3CU3Ec_U3CReceiveMessageU3Eb__24_0_m239F0211E8D016A1ACCFF6005B536DECEE383B10 (void);
// 0x00000073 System.Void Wamp_<ReceiveMessage>d__24::MoveNext()
extern void U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_AdjustorThunk (void);
// 0x00000074 System.Void Wamp_<ReceiveMessage>d__24::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CReceiveMessageU3Ed__24_SetStateMachine_m1A3F556E61365751BF72BC7C8C95F8DEDBF12C3C_AdjustorThunk (void);
// 0x00000075 System.Void Wamp_<Receive>d__25::MoveNext()
extern void U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4_AdjustorThunk (void);
// 0x00000076 System.Void Wamp_<Receive>d__25::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CReceiveU3Ed__25_SetStateMachine_m1DFEA710015A7E2BA876C1837E14781B6BC5E68F_AdjustorThunk (void);
// 0x00000077 System.Void Wamp_<ReceiveExpect>d__26::MoveNext()
extern void U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0_AdjustorThunk (void);
// 0x00000078 System.Void Wamp_<ReceiveExpect>d__26::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CReceiveExpectU3Ed__26_SetStateMachine_mFDCB7BA62E930894AC2A0A7A5100EE36A256FD7B_AdjustorThunk (void);
// 0x00000079 System.Void Wamp_<Connect>d__27::MoveNext()
extern void U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14_AdjustorThunk (void);
// 0x0000007A System.Void Wamp_<Connect>d__27::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CConnectU3Ed__27_SetStateMachine_m3C346664EBD564CDA981B81988E47665403580B9_AdjustorThunk (void);
// 0x0000007B System.Void Wamp_<Close>d__30::MoveNext()
extern void U3CCloseU3Ed__30_MoveNext_mAB43192731588E3CF72C9F96212C641FB1A0184D_AdjustorThunk (void);
// 0x0000007C System.Void Wamp_<Close>d__30::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CCloseU3Ed__30_SetStateMachine_mDD6A8E81D89D09469510FB615D6DF79B2E61C0AB_AdjustorThunk (void);
// 0x0000007D System.Void Wamp_<>c__DisplayClass32_0::.ctor()
extern void U3CU3Ec__DisplayClass32_0__ctor_m21ABB4A02AE3611EDDC6C1A4A27CF6F83341418A (void);
// 0x0000007E System.Void Wamp_<>c__DisplayClass32_0::<StartListen>b__0()
extern void U3CU3Ec__DisplayClass32_0_U3CStartListenU3Eb__0_mB184AA45B5F3D79923AF3B9DEAB1E06956F8D6E9 (void);
// 0x0000007F System.Void Wamp_<Call>d__34::MoveNext()
extern void U3CCallU3Ed__34_MoveNext_mFE458EC82A6FE04034653EFACBCDF773333888F1_AdjustorThunk (void);
// 0x00000080 System.Void Wamp_<Call>d__34::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CCallU3Ed__34_SetStateMachine_mC98B572BE8C143D41DF3D54466223A92F1F1D6B8_AdjustorThunk (void);
// 0x00000081 System.Void Wamp_<Subscribe>d__35::MoveNext()
extern void U3CSubscribeU3Ed__35_MoveNext_m871F84E5292DE81E13BE9C94AB0EA8765E1D5285_AdjustorThunk (void);
// 0x00000082 System.Void Wamp_<Subscribe>d__35::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CSubscribeU3Ed__35_SetStateMachine_mDAD9620ACF150FAED21040DF4EAC8D41588BD7C6_AdjustorThunk (void);
// 0x00000083 System.Void Wamp_<Unsubscribe>d__36::MoveNext()
extern void U3CUnsubscribeU3Ed__36_MoveNext_m342B13779519EDA18D70E718177AFB7256C1CB54_AdjustorThunk (void);
// 0x00000084 System.Void Wamp_<Unsubscribe>d__36::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CUnsubscribeU3Ed__36_SetStateMachine_mD7D2367D4B35E676ADA256D3997B6DBAF72B293E_AdjustorThunk (void);
// 0x00000085 System.Void ak_soundengine_error::.ctor()
extern void error__ctor_m5EF13877DC4D3C647104FBDFD35EE8B6D0EB64ED (void);
// 0x00000086 System.Void ak_wwise_error::.ctor()
extern void error__ctor_mC47AF26531BD56F5DBC1F468ACA52DDA48343DD2 (void);
// 0x00000087 System.Void ak_wwise_debug::.ctor()
extern void debug__ctor_mCBB981BB13DDEF0417374FF4CF37634B3ABAC21A (void);
// 0x00000088 System.Void ak_wwise_core::.ctor()
extern void core__ctor_m24159AE4D5D557A37BDF540FCC663BED6147570B (void);
// 0x00000089 System.Void ak_wwise_ui::.ctor()
extern void ui__ctor_mD5687B037A197EC6E76881FE770C1EA849198557 (void);
// 0x0000008A System.Void ak_wwise_waapi::.ctor()
extern void waapi__ctor_mC4EE7EDAC8B3597585CE9FD06822EE98E7F3820F (void);
// 0x0000008B System.Void ak_wwise_core_audioSourcePeaks::.ctor()
extern void audioSourcePeaks__ctor_m07D467395B57BAB41B1235BAE2B4FF8B886D308B (void);
// 0x0000008C System.Void ak_wwise_core_remote::.ctor()
extern void remote__ctor_m4C7E168CA675D3670936EA3EE26E2340EADD9E08 (void);
// 0x0000008D System.Void ak_wwise_core_log::.ctor()
extern void log__ctor_m485D5E6FB1903986784B38CEA94427D01935B879 (void);
// 0x0000008E System.Void ak_wwise_core_object::.ctor()
extern void object__ctor_mFF98DACF238902E34662AD50F77C08F3875CED9B (void);
// 0x0000008F System.Void ak_wwise_core_undo::.ctor()
extern void undo__ctor_m54D7581967508052F793083F65C79E557FCE63BF (void);
// 0x00000090 System.Void ak_wwise_core_profiler::.ctor()
extern void profiler__ctor_m306EDAFFF696F2316D7557773B4F687628FE6172 (void);
// 0x00000091 System.Void ak_wwise_core_project::.ctor()
extern void project__ctor_m112A63E590C0FAD5D2A6F8671CB5BCB1936216FF (void);
// 0x00000092 System.Void ak_wwise_core_transport::.ctor()
extern void transport__ctor_m3088AFFE35D7789AD23F28029AB01056BC61A11E (void);
// 0x00000093 System.Void ak_wwise_core_soundbank::.ctor()
extern void soundbank__ctor_m1093997F74590CE7BE5D9B09F00DB9F020D4C9CA (void);
// 0x00000094 System.Void ak_wwise_core_audio::.ctor()
extern void audio__ctor_mF922E2E8C239A88D888086B06F87FC529C503D01 (void);
// 0x00000095 System.Void ak_wwise_core_switchContainer::.ctor()
extern void switchContainer__ctor_mBDFC5656C40D496C935DD9EB44DC8E9785D4A1B6 (void);
// 0x00000096 System.Void ak_wwise_core_plugin::.ctor()
extern void plugin__ctor_m6B4FEED0E6B049E3FCF16E30E969DE368E5EA27C (void);
// 0x00000097 System.Void ak_wwise_ui_project::.ctor()
extern void project__ctor_m903C2B2559D6309AECD7E44FECC67BB3BD1DC8D2 (void);
// 0x00000098 System.Void ak_wwise_ui_commands::.ctor()
extern void commands__ctor_m8A2579EC170A22A576E6EB9ED20D348379274E9A (void);
static Il2CppMethodPointer s_methodPointers[152] = 
{
	AkWaapiClient_add_Disconnected_m23455C48DF662205286001B85808AB1D4A8306E9,
	AkWaapiClient_remove_Disconnected_m0B10E01BB8B37C4FEF60591D0AA9F8943EE7345D,
	AkWaapiClient_Connect_m7B36FAFC8A88A778B1976073C457ACAFAD495374,
	AkWaapiClient_Wamp_Disconnected_mA53BAA173A2BFE01B0BD97F5BF3A2D1EC9E0113F,
	AkWaapiClient_Close_mE0747AE29CCE6D2F9367E62C7748CD02B2586A8B,
	AkWaapiClient_IsConnected_m8946333A475C43407EA8008736236EFBBE2E103C,
	AkWaapiClient_Call_m228E834AEDE74F68F26208B1073183014B984763,
	AkWaapiClient_Subscribe_m4E52D19C0C845D3CCA1A1DA5CA9A77DAB7BDF996,
	AkWaapiClient_Unsubscribe_m1B4867EC231A6315D787905D00FCD8E6A249EC25,
	AkWaapiClient__ctor_mB410C36E69BBAFD1C690B4872D89C02F38876242,
	JsonSerializable_op_Implicit_m3C7EB2F1AB6BCB3FE77634021CC6841E1B179680,
	JsonSerializable__ctor_mE3ABF790236AF63E02F9D08ACB935F013DE26AEE,
	Args__ctor_mF6D0DC71ABC77F11C29B33ED33B0BDBCC61F00E9,
	WaqlArgs__ctor_m544A7F4EE9BF592CCB63E265D4E5903CEB3D8FEA,
	ArgsObject__ctor_m8F267DB607A75FCF3F2FA67A0F59A6F677FA0191,
	ArgsRename__ctor_mED3E3B39211B2C8E699CBC3C519F3FAC37C6FFCD,
	ArgsDisplayName__ctor_m2B14218C56F0061404AC79875F90150C2FD76D63,
	ArgsCommand__ctor_m60D67E600FEA543B4081DCC6AA447751013D6E1B,
	ArgsPlay__ctor_m15D42EC03786D00B07138F46DCD3751BF167AD5C,
	ArgsTransport__ctor_mF279D8D1041917F43379FFC68EC8E345367F5C74,
	Options__ctor_mB2226F341FEBF5B020CF7942625A2F7652485163,
	ReturnOptions__ctor_m788C3E784D91725A93065E30AB42A1578C043526,
	TransportOptions__ctor_mF0DD9736D70BF4FEE558F4AC4EEA41E7E0833270,
	ReturnTransport__ctor_mDD5D0EC2E8085540DBFE074FE601CDA6EC502457,
	TransportState__ctor_m3C589B89FBBAA471911E58AF4D386EC8BEF76793,
	ErrorMessage__ctor_m4DF7DC147C5FA9FBA0206CEFF78E03DED4C31AA3,
	ErrorDetails__ctor_m3BA1C08EF47154C3EAF9DD5C5B7BADB4EDE30E39,
	ReturnWwiseObjects__ctor_m94A86AE27A1F0BE528A4EEC26E19F2210EF8E607,
	NULL,
	SelectedWwiseObjects__ctor_m9784904F53E10976B5EB7E76796A6DA2392C5915,
	WwiseRenameInfo_ParseInfo_m880DD2D586D1EB3FA0D9F776FFC5EC3D24D273E9,
	WwiseRenameInfo__ctor_mBF30859A831A058DA2650F3A26FDE0A8A05D387C,
	WwiseChildModifiedInfo_ParseInfo_mCC9AAA37701E3D17396ABB487C44B6851557EA3F,
	WwiseChildModifiedInfo__ctor_mA594FC7B5DD5E56C707F3BDFB1F60BE443BF3DF0,
	WwiseObjectInfoJsonObject_op_Implicit_m891DE29A29F2BBD51786E3473155DB4938678A0B,
	WwiseObjectInfoJsonObject_ToObjectInfo_m34217D48C83C57B40D1772E3C02CA43DCAE739E1,
	WwiseObjectInfoJsonObject__ctor_mE056E64AC8C8D8AAFE9B9170F0C585EAB59C41E4,
	WwiseObjectInfoParent__ctor_m110C353E41363504B8EDEC82627F90C2E2C3B042,
	WaapiHelper_GetWwiseObjectTypeFromString_m04C5DF50A1EA2E0B0188B3C71B94B2BB406A58DE,
	WaapiKeywords__ctor_m90A5404044D01E8198019D449DB057627B723C92,
	WaapiKeywords__cctor_m98F6325EE529F42B2E47B71504811F517DB2059C,
	ak__ctor_m4CCD374F6B1B80939DDEB64410380F8276567A04,
	Wamp_add_Disconnected_mBAA1A70AD8CE39B3A45DB824FB26FF9C2C11F143,
	Wamp_remove_Disconnected_m733F63A5B3D9B63CA05DB0B31C6BE3C9456D7D9F,
	Wamp_Send_m2DE0D552970C48553636ED29577CD67B3C32E591,
	Wamp_Parse_mAB6542E62838CC574F268C6ACED9274809CF457A,
	Wamp_ParseResult_m1ED4173FAF19510DA46B93BCA58DAA6FE0140634,
	Wamp_ParseSubscribed_m705D9E4D5465BAF013A92740D8D822AF448B1F23,
	Wamp_ParseUnsubscribed_m21AF2D9070DE4E49F5CC7C53A164C1A5C2D7040E,
	Wamp_ParseGoodbye_m62130B50323A9CDC2F8182BA1E492B5F182A958A,
	Wamp_ParseWelcome_mDC04C238E5A69F16500F3C9A7678B10185601B58,
	Wamp_ParseEvent_m21C36EAE091AB9B20402C75770048AA5FC9F9020,
	Wamp_ReceiveMessage_m333714DD38A3BEBB92BA90A416BC053CDC1158BC,
	Wamp_Receive_m7B47E5C25B601C3C446B02A97117ACAA3FA3BF13,
	Wamp_ReceiveExpect_mF10637E0F9E79CC5137754ECBCA24272383F1864,
	Wamp_Connect_m091D964EE6A72E12FA0905681BF78AD05D9D7FAB,
	Wamp_IsConnected_m937F67F3943693AE69F82BA0897E18C163A0B70C,
	Wamp_SocketState_m44CB7A55E93140987D8D2C475C010842EEA0C378,
	Wamp_Close_m8607EFADFFC175CC0825312F7EFA8E175FA39B74,
	Wamp_ProcessEvent_mB6BA36EA16F2375692017561F09D725C6D2E6E35,
	Wamp_StartListen_mD58F9728B82A7A344E95BA20A462450F5725CEB8,
	Wamp_OnDisconnect_m17E2623C24F5E4FE6AAC0736C0C8EB1E323D099F,
	Wamp_Call_mAE552B01EB08CE7275EEDD97710E512589D61B33,
	Wamp_Subscribe_mC841A9CDF1DA84F41596A6E4E087CB13C8AF4F40,
	Wamp_Unsubscribe_m185B046DAF9E4293617E8A512747B768958ABA6C,
	Wamp__ctor_mCD0D3AC4AB87B0AC898D448724AB0568594D6193,
	U3CConnectU3Ed__4_MoveNext_m13F3495E6D4BDE5F1C839110864B68AB3F5B7BB6_AdjustorThunk,
	U3CConnectU3Ed__4_SetStateMachine_mDF27AC5C9A5B8B3E4254E946CBB2F67107F6F757_AdjustorThunk,
	U3CCloseU3Ed__6_MoveNext_mBC17ADA14E060E99A5EDC8E80F91E8A97E7F6517_AdjustorThunk,
	U3CCloseU3Ed__6_SetStateMachine_m55135EC1DC2BD15058D218A67C6AB2019D6653FE_AdjustorThunk,
	U3CCallU3Ed__8_MoveNext_m89D6CF60EBCD12B91A490A513BB733162BE60BB3_AdjustorThunk,
	U3CCallU3Ed__8_SetStateMachine_mD2692F6222738E5FB87B23429B8DD0B43F651FDC_AdjustorThunk,
	U3CSubscribeU3Ed__9_MoveNext_mD9F9BC3A229A9BBB77D12E5264E5074AD5D4E760_AdjustorThunk,
	U3CSubscribeU3Ed__9_SetStateMachine_m5AD4A356DAE70F2EC5F1BB8257BEEF5008C4117F_AdjustorThunk,
	U3CUnsubscribeU3Ed__10_MoveNext_m3580E1C4599C1654A1605AD60EFA362519976AB4_AdjustorThunk,
	U3CUnsubscribeU3Ed__10_SetStateMachine_m3DD99D8798B4C3D9DB2A04230689657AC1139F8C_AdjustorThunk,
	soundengine__ctor_m778F4A903981C95FAA549572CDECF65718F23DA2,
	wwise__ctor_mAE8FD2766A53D97BFDE8CD14CF3B24CB3FEAD75B,
	TimeoutException__ctor_m2AD6BA4E69FE5415F5E571171A0346292B84E0D4,
	WampNotConnectedException__ctor_m9F67C3FB5519219C1CE6CE530F40704466CA7ECD,
	ErrorException_get_Json_m6F364D704AE749F82E57E62A4039891B5AA65BC2,
	ErrorException_set_Json_m63B27B2FF42F2763E1B259F6CAA1B1813839D6EC,
	ErrorException_get_MessageId_m951111C43E1CC324EAF227B5DA4975DBA837BB5B,
	ErrorException_set_MessageId_mB2E895A07D439F8EB5C11D1E02EEC602FC84DAB1,
	ErrorException_get_RequestId_m820DEA354FDC75A23968D323311483801B65502E,
	ErrorException_set_RequestId_m141F6E4AA9228ECD9320038A3FC7D0633DDD53A9,
	ErrorException_get_Uri_m307DAFB1DE6403546BF024E1AA100BC3B387E4BC,
	ErrorException_set_Uri_mEFBFD6E03D38DA354BB53E6DA1467A6E1F97BE90,
	ErrorException__ctor_m67A67333E733EE338D7A09FB3D3FD256547FAEF9,
	ErrorException_FromResponse_m7F3FD8A84BC8AEF0BC62A4CD5203DF961BC803C9,
	Response_get_MessageId_mC397D82D70FC4A2DC73186D1CADF3ADF34CEE0D7,
	Response_set_MessageId_m5419548F7C55CD3903F45A1ECE609D37BE892E1A,
	Response_get_RequestId_m839528D15AAC4BC39EAEB22669F38B75140A0C05,
	Response_set_RequestId_mE99F65B9CFBC1ACB1C91C0DDD49E922772D4A7C4,
	Response_get_ContextSpecificResultId_m8C53A20C58BACF5A2DA2379A42D2818F283CF862,
	Response_set_ContextSpecificResultId_m4E0BD596C10376CFFFD141BF47A2322DBF18D760,
	Response_get_SubscriptionId_m38F262E5543B6AA4EB3EDDB8A8F1365B84284383,
	Response_set_SubscriptionId_m160D966B5D30F42BF0D5C133AA49CC14B62ED853,
	Response_get_Json_m344AA62580A8B48CEECF9F5A9B33638D572B785B,
	Response_set_Json_m8B200462D00D107744D54E7FD990BB541675D7F9,
	Response__ctor_m9F9F6466D04CA9751434DEEA54811E67A01EF1D5,
	PublishHandler__ctor_mF50D892D205E428FEBDE6AE72C209A6B386524B2,
	PublishHandler_Invoke_m85F2A61F37B7D01827F76105781D219BFCF7E448,
	PublishHandler_BeginInvoke_mE0D9DE2DBF0BDA0314F3E4BBB4C2BFDA4F2CE68E,
	PublishHandler_EndInvoke_mD6D4C66F02CBFF7906EFE4303E7B68793F86FF18,
	DisconnectedHandler__ctor_m742456B3847D7F450EEFBD2053B6C43C3D272C80,
	DisconnectedHandler_Invoke_m08F15DEC1D0B8B106737140AF777D9CAEF92E79E,
	DisconnectedHandler_BeginInvoke_mDA3C965C383835C646F861342836EAA6A853D4F0,
	DisconnectedHandler_EndInvoke_m29EB3F908BD393FD1495681609835B5DE61A385D,
	U3CSendU3Ed__16_MoveNext_mFA2A408E16C941E646CF177B63ADA93468C30D72_AdjustorThunk,
	U3CSendU3Ed__16_SetStateMachine_m5303935E88DD68C4A40AEDBFCDF18F8DEA84E31B_AdjustorThunk,
	U3CU3Ec__cctor_mDD40621A39ED2248A9CD84ED04CFF64820655B0C,
	U3CU3Ec__ctor_m4643EB15B51A45103D4E30A86716ACD2F70B48B4,
	U3CU3Ec_U3CReceiveMessageU3Eb__24_0_m239F0211E8D016A1ACCFF6005B536DECEE383B10,
	U3CReceiveMessageU3Ed__24_MoveNext_mE7D8C1402297F88C74D6C016EF0EF4E6C045D73F_AdjustorThunk,
	U3CReceiveMessageU3Ed__24_SetStateMachine_m1A3F556E61365751BF72BC7C8C95F8DEDBF12C3C_AdjustorThunk,
	U3CReceiveU3Ed__25_MoveNext_mE1646B8554A7C49AFCAC93337D170AD052E977F4_AdjustorThunk,
	U3CReceiveU3Ed__25_SetStateMachine_m1DFEA710015A7E2BA876C1837E14781B6BC5E68F_AdjustorThunk,
	U3CReceiveExpectU3Ed__26_MoveNext_mB080E9B1627F4AAB2887120987D643E026CDA3D0_AdjustorThunk,
	U3CReceiveExpectU3Ed__26_SetStateMachine_mFDCB7BA62E930894AC2A0A7A5100EE36A256FD7B_AdjustorThunk,
	U3CConnectU3Ed__27_MoveNext_mA5DF712A92E29B5A6A2AA37650D4919FE3DA7F14_AdjustorThunk,
	U3CConnectU3Ed__27_SetStateMachine_m3C346664EBD564CDA981B81988E47665403580B9_AdjustorThunk,
	U3CCloseU3Ed__30_MoveNext_mAB43192731588E3CF72C9F96212C641FB1A0184D_AdjustorThunk,
	U3CCloseU3Ed__30_SetStateMachine_mDD6A8E81D89D09469510FB615D6DF79B2E61C0AB_AdjustorThunk,
	U3CU3Ec__DisplayClass32_0__ctor_m21ABB4A02AE3611EDDC6C1A4A27CF6F83341418A,
	U3CU3Ec__DisplayClass32_0_U3CStartListenU3Eb__0_mB184AA45B5F3D79923AF3B9DEAB1E06956F8D6E9,
	U3CCallU3Ed__34_MoveNext_mFE458EC82A6FE04034653EFACBCDF773333888F1_AdjustorThunk,
	U3CCallU3Ed__34_SetStateMachine_mC98B572BE8C143D41DF3D54466223A92F1F1D6B8_AdjustorThunk,
	U3CSubscribeU3Ed__35_MoveNext_m871F84E5292DE81E13BE9C94AB0EA8765E1D5285_AdjustorThunk,
	U3CSubscribeU3Ed__35_SetStateMachine_mDAD9620ACF150FAED21040DF4EAC8D41588BD7C6_AdjustorThunk,
	U3CUnsubscribeU3Ed__36_MoveNext_m342B13779519EDA18D70E718177AFB7256C1CB54_AdjustorThunk,
	U3CUnsubscribeU3Ed__36_SetStateMachine_mD7D2367D4B35E676ADA256D3997B6DBAF72B293E_AdjustorThunk,
	error__ctor_m5EF13877DC4D3C647104FBDFD35EE8B6D0EB64ED,
	error__ctor_mC47AF26531BD56F5DBC1F468ACA52DDA48343DD2,
	debug__ctor_mCBB981BB13DDEF0417374FF4CF37634B3ABAC21A,
	core__ctor_m24159AE4D5D557A37BDF540FCC663BED6147570B,
	ui__ctor_mD5687B037A197EC6E76881FE770C1EA849198557,
	waapi__ctor_mC4EE7EDAC8B3597585CE9FD06822EE98E7F3820F,
	audioSourcePeaks__ctor_m07D467395B57BAB41B1235BAE2B4FF8B886D308B,
	remote__ctor_m4C7E168CA675D3670936EA3EE26E2340EADD9E08,
	log__ctor_m485D5E6FB1903986784B38CEA94427D01935B879,
	object__ctor_mFF98DACF238902E34662AD50F77C08F3875CED9B,
	undo__ctor_m54D7581967508052F793083F65C79E557FCE63BF,
	profiler__ctor_m306EDAFFF696F2316D7557773B4F687628FE6172,
	project__ctor_m112A63E590C0FAD5D2A6F8671CB5BCB1936216FF,
	transport__ctor_m3088AFFE35D7789AD23F28029AB01056BC61A11E,
	soundbank__ctor_m1093997F74590CE7BE5D9B09F00DB9F020D4C9CA,
	audio__ctor_mF922E2E8C239A88D888086B06F87FC529C503D01,
	switchContainer__ctor_mBDFC5656C40D496C935DD9EB44DC8E9785D4A1B6,
	plugin__ctor_m6B4FEED0E6B049E3FCF16E30E969DE368E5EA27C,
	project__ctor_m903C2B2559D6309AECD7E44FECC67BB3BD1DC8D2,
	commands__ctor_m8A2579EC170A22A576E6EB9ED20D348379274E9A,
};
static const int32_t s_InvokerIndices[152] = 
{
	26,
	26,
	58,
	23,
	34,
	89,
	153,
	153,
	200,
	23,
	0,
	23,
	23,
	26,
	26,
	27,
	26,
	27,
	130,
	32,
	23,
	26,
	32,
	23,
	23,
	23,
	23,
	23,
	-1,
	23,
	23,
	23,
	23,
	23,
	2667,
	2667,
	23,
	23,
	138,
	23,
	3,
	23,
	26,
	26,
	58,
	28,
	0,
	0,
	0,
	0,
	0,
	0,
	14,
	34,
	201,
	58,
	89,
	10,
	34,
	26,
	23,
	23,
	153,
	153,
	200,
	23,
	23,
	26,
	23,
	26,
	23,
	26,
	23,
	26,
	23,
	26,
	23,
	23,
	26,
	26,
	14,
	26,
	10,
	32,
	10,
	32,
	14,
	26,
	26,
	0,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	14,
	26,
	23,
	124,
	26,
	213,
	26,
	124,
	23,
	105,
	26,
	23,
	26,
	3,
	23,
	28,
	23,
	26,
	23,
	26,
	23,
	26,
	23,
	26,
	23,
	26,
	23,
	23,
	23,
	26,
	23,
	26,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
};
extern const Il2CppCodeGenModule g_Ak_Wwise_Api_WAAPICodeGenModule;
const Il2CppCodeGenModule g_Ak_Wwise_Api_WAAPICodeGenModule = 
{
	"Ak.Wwise.Api.WAAPI.dll",
	152,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
