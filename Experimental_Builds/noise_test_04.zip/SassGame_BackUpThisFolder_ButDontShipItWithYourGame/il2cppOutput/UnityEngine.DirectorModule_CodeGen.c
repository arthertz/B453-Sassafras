﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 UnityEngine.Playables.DirectorWrapMode UnityEngine.Playables.PlayableDirector::get_extrapolationMode()
extern void PlayableDirector_get_extrapolationMode_m4FC3DF6DBD09B189599AFABAF85758961BFB2289 (void);
// 0x00000002 UnityEngine.Playables.PlayableAsset UnityEngine.Playables.PlayableDirector::get_playableAsset()
extern void PlayableDirector_get_playableAsset_m37F11F9F2AC93F9EE6CF4BDE73D7A9B56CC84B0B (void);
// 0x00000003 UnityEngine.Object UnityEngine.Playables.PlayableDirector::GetReferenceValue(UnityEngine.PropertyName,System.Boolean&)
extern void PlayableDirector_GetReferenceValue_mBD609B990E5972D58864FF930BE5319D504486E1 (void);
// 0x00000004 UnityEngine.Object UnityEngine.Playables.PlayableDirector::GetGenericBinding(UnityEngine.Object)
extern void PlayableDirector_GetGenericBinding_m5A0C25A638FC89F9FB971D91C31B915017CC57BD (void);
// 0x00000005 UnityEngine.Playables.DirectorWrapMode UnityEngine.Playables.PlayableDirector::GetWrapMode()
extern void PlayableDirector_GetWrapMode_mA5D7EE8B25479E8AEA34AC88FCA4B3BFB8A9D1E2 (void);
// 0x00000006 UnityEngine.ScriptableObject UnityEngine.Playables.PlayableDirector::Internal_GetPlayableAsset()
extern void PlayableDirector_Internal_GetPlayableAsset_mE263E406B984F61533DD1CB4DD9F377579A205BD (void);
// 0x00000007 System.Void UnityEngine.Playables.PlayableDirector::SendOnPlayableDirectorPlay()
extern void PlayableDirector_SendOnPlayableDirectorPlay_m4E9920374473D4726C270EF6ECACA93303C7BA87 (void);
// 0x00000008 System.Void UnityEngine.Playables.PlayableDirector::SendOnPlayableDirectorPause()
extern void PlayableDirector_SendOnPlayableDirectorPause_m4E43A08D82CCE58DE75A1D9605A716BD85837F81 (void);
// 0x00000009 System.Void UnityEngine.Playables.PlayableDirector::SendOnPlayableDirectorStop()
extern void PlayableDirector_SendOnPlayableDirectorStop_mB1699B938518B0D2CBB70B6A7678FBA8A83839A8 (void);
// 0x0000000A UnityEngine.Object UnityEngine.Playables.PlayableDirector::GetReferenceValue_Injected(UnityEngine.PropertyName&,System.Boolean&)
extern void PlayableDirector_GetReferenceValue_Injected_m99342CA690EE99A4157E926D6788E31B6707AD87 (void);
static Il2CppMethodPointer s_methodPointers[10] = 
{
	PlayableDirector_get_extrapolationMode_m4FC3DF6DBD09B189599AFABAF85758961BFB2289,
	PlayableDirector_get_playableAsset_m37F11F9F2AC93F9EE6CF4BDE73D7A9B56CC84B0B,
	PlayableDirector_GetReferenceValue_mBD609B990E5972D58864FF930BE5319D504486E1,
	PlayableDirector_GetGenericBinding_m5A0C25A638FC89F9FB971D91C31B915017CC57BD,
	PlayableDirector_GetWrapMode_mA5D7EE8B25479E8AEA34AC88FCA4B3BFB8A9D1E2,
	PlayableDirector_Internal_GetPlayableAsset_mE263E406B984F61533DD1CB4DD9F377579A205BD,
	PlayableDirector_SendOnPlayableDirectorPlay_m4E9920374473D4726C270EF6ECACA93303C7BA87,
	PlayableDirector_SendOnPlayableDirectorPause_m4E43A08D82CCE58DE75A1D9605A716BD85837F81,
	PlayableDirector_SendOnPlayableDirectorStop_mB1699B938518B0D2CBB70B6A7678FBA8A83839A8,
	PlayableDirector_GetReferenceValue_Injected_m99342CA690EE99A4157E926D6788E31B6707AD87,
};
static const int32_t s_InvokerIndices[10] = 
{
	10,
	14,
	1348,
	28,
	10,
	14,
	23,
	23,
	23,
	930,
};
extern const Il2CppCodeGenModule g_UnityEngine_DirectorModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_DirectorModuleCodeGenModule = 
{
	"UnityEngine.DirectorModule.dll",
	10,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
