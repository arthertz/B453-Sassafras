﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"

template <typename R>
struct VirtFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};

// AK.Wwise.AcousticTexture
struct AcousticTexture_t3A55AF140C3AD4F6F291BCB030AEE7E4CB251DBA;
// AK.Wwise.AuxBus
struct AuxBus_tB74A0BABF2CB9974E22C2E1096C5B5A14FF72460;
// AK.Wwise.Bank
struct Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA;
// AK.Wwise.BaseGroupType
struct BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7;
// AK.Wwise.BaseType
struct BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE;
// AK.Wwise.CallbackFlags
struct CallbackFlags_tF53FCB71961652A8EC87A77A5D382C014BC7CA1F;
// AK.Wwise.Event
struct Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F;
// AK.Wwise.RTPC
struct RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C;
// AK.Wwise.State
struct State_t33FE9B211AA324266CA50DC53343CA54B4A6A74C;
// AK.Wwise.Switch
struct Switch_t3C5E93F72DE4D390F7C5E8F4ECC7765EBFEA75D7;
// AK.Wwise.Trigger
struct Trigger_t5ACE3FCFFD1C9CB7459B8CF2F15734EB96B4300E;
// AkCallbackInfo
struct AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979;
// AkCallbackManager/BankCallback
struct BankCallback_t4566058B743D615B6C79A9A3682B47476ADAE686;
// AkCallbackManager/EventCallback
struct EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561;
// AkMIDIPostArray
struct AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78;
// System.AsyncCallback
struct AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4;
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.DelegateData
struct DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE;
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
// System.IAsyncResult
struct IAsyncResult_t8E194308510B375B42432981AE5E7488C458D598;
// System.Reflection.Binder
struct Binder_t4D5CB06963501D32847C057B57157D6DC49CA759;
// System.Reflection.MemberFilter
struct MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Security.Cryptography.RandomNumberGenerator
struct RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2;
// System.String
struct String_t;
// System.Type
struct Type_t;
// System.Type[]
struct TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.GameObject
struct GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F;
// UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0;
// UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734;
// WwiseAcousticTextureReference
struct WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805;
// WwiseAuxBusReference
struct WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3;
// WwiseBankReference
struct WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6;
// WwiseEventReference
struct WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C;
// WwiseGroupValueObjectReference
struct WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E;
// WwiseObjectReference
struct WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6;
// WwiseRtpcReference
struct WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E;
// WwiseStateGroupReference
struct WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6;
// WwiseStateReference
struct WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511;
// WwiseSwitchGroupReference
struct WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6;
// WwiseSwitchReference
struct WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19;
// WwiseTriggerReference
struct WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE;

IL2CPP_EXTERN_C RuntimeClass* AkBankManager_t0707FA28C848388CF54FDA6E5C5C8A34F1BBF7EA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Debug_t7B5FCB117E2FD63B6838BC52821B252E2BFB61C4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Guid_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* String_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral0D0C4DDD7CAB8253149568AACCC1F72AA7F9ACF8;
IL2CPP_EXTERN_C String_t* _stringLiteral3A52CE780950D4D969792A2559CD519D7EE8C727;
IL2CPP_EXTERN_C String_t* _stringLiteral47C86F27A40F154D0FF5D5D54021387BEB1A3752;
IL2CPP_EXTERN_C String_t* _stringLiteralC3CF574CB7C9180E542021AF824ED52565F509F6;
IL2CPP_EXTERN_C const uint32_t AcousticTexture_set_ObjectReference_mBDAB9D5BA879D24BF1C7F543F76CEFD442E58A9D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AuxBus_set_ObjectReference_m130FCE92CFF4D543369BC5154D8EAFBCF96FDA9E_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Bank_LoadAsync_mD0EDAB56C81E98240631CCE3AFA5175F56A8C79D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Bank_Load_mE46124DE4BEB7444BFAB5D030E483D07E749732D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Bank_Unload_m0E6337A3DE4E818A065D60456BA28FE66959CAFD_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Bank_set_ObjectReference_m70806BA0660E74626D2F04575930B5A5B9B609E7_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BaseGroupType_IsValid_mADCBE3C3E7B68B2D97014E1A84B2526BBE0AEDDB_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BaseGroupType_get_GroupId_mF73642DEE955F78AF36A9DED227DFAD6E36B9DA6_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BaseGroupType_get_GroupWwiseObjectReference_mC00EC611D1AB6A833A3389928F58AB828DEB509E_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BaseGroupType_get_groupGuid_m6B0D66D9318433251D42610956CFB90B05B7EF8B_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BaseType_IsValid_mFF810061EE89CBE4C8E823B9DD12D868E95F90F5_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BaseType_ToString_mAAFCAE5E25C7899DD5114DD7D778A6D1E5D4CF2C_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BaseType_Validate_mCF58D3BA9A28AA4DB9F4C2BB11728A222730C109_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BaseType_get_Name_mDFFF2E7872296A918CB207A3D4F0141A82A57651_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t BaseType_get_valueGuid_mBCE9BC6DCBA50287E5EAEFD7EC058BFF7D0EE944_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Event_Post_m7E549AC780ECAC443484AC66E4201AC85AC34938_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Event_Post_m975A00B31848012ACE9114D3FDB25CA0E630601D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Event_Post_mB44E5C0A82FA36EDC65070D3024E066EE4D21F7A_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Event_StopMIDI_m134DB6480821D066829993FC9AE0089183A85B25_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Event_StopMIDI_m3EF14DD7C5CDA754301D41F35138329678A3E806_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Event_set_ObjectReference_m1A659F392D4DA6CB6BF285D8FC6256BC40A48C7D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t RTPC_GetValue_mE4BBCDABF8F856CBD6E2E74B223130DDF4AD6776_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t RTPC_SetGlobalValue_mE95A5B940C8101349FA64E225E3D08233871C505_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t RTPC_SetValue_m1C344467FDED1786C71D410DBFCD5D03DCCD9AD5_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t RTPC_set_ObjectReference_mA15859BEF88F307DC76FCC01EB1EA597E60FC557_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t State_SetValue_m3277A24BDD3292A989E4C9E4DAC8232C97DC8102_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t State_set_ObjectReference_mC2B636ABD6F3CAC90E48590BF03B908A66E7D435_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Switch_SetValue_m7B841B28FA764A67FE68B2195F6DE87FE8432F98_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Switch_set_ObjectReference_mC8D431846370386B7200FDB1A3B9B5306C3620B7_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Trigger_Post_mBDF91ECB8ADF7C97A038C5C8135384B4B91F1509_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t Trigger_set_ObjectReference_m0932A4F9EA97A9749BBB02CACAAE63F5FDC45D00_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t WwiseGroupValueObjectReference_get_DisplayName_m1BDB9F6B4F9C5BB82C156DB4AA50F088B15D4D94_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t WwiseObjectReference_get_Guid_mA730AB56F442D112796810ECFB314FD39CB33C14_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t WwiseStateReference_set_GroupObjectReference_mB38F503F67AC85A4195656D7B265180025F85EF1_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t WwiseSwitchReference_set_GroupObjectReference_m28DA84F22ACE63362B2C792048724EA9B957A497_MetadataUsageId;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;

struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_tE66B841E1A63BC9EDFB687A16A6C93FB858E3D22 
{
public:

public:
};


// System.Object


// AK.Wwise.BaseType
struct  BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE  : public RuntimeObject
{
public:
	// System.Int32 AK.Wwise.BaseType::idInternal
	int32_t ___idInternal_0;
	// System.Byte[] AK.Wwise.BaseType::valueGuidInternal
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___valueGuidInternal_1;

public:
	inline static int32_t get_offset_of_idInternal_0() { return static_cast<int32_t>(offsetof(BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE, ___idInternal_0)); }
	inline int32_t get_idInternal_0() const { return ___idInternal_0; }
	inline int32_t* get_address_of_idInternal_0() { return &___idInternal_0; }
	inline void set_idInternal_0(int32_t value)
	{
		___idInternal_0 = value;
	}

	inline static int32_t get_offset_of_valueGuidInternal_1() { return static_cast<int32_t>(offsetof(BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE, ___valueGuidInternal_1)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_valueGuidInternal_1() const { return ___valueGuidInternal_1; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_valueGuidInternal_1() { return &___valueGuidInternal_1; }
	inline void set_valueGuidInternal_1(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___valueGuidInternal_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___valueGuidInternal_1), (void*)value);
	}
};


// AK.Wwise.CallbackFlags
struct  CallbackFlags_tF53FCB71961652A8EC87A77A5D382C014BC7CA1F  : public RuntimeObject
{
public:
	// System.UInt32 AK.Wwise.CallbackFlags::value
	uint32_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(CallbackFlags_tF53FCB71961652A8EC87A77A5D382C014BC7CA1F, ___value_0)); }
	inline uint32_t get_value_0() const { return ___value_0; }
	inline uint32_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(uint32_t value)
	{
		___value_0 = value;
	}
};

struct Il2CppArrayBounds;

// System.Array


// System.Reflection.MemberInfo
struct  MemberInfo_t  : public RuntimeObject
{
public:

public:
};


// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::m_stringLength
	int32_t ___m_stringLength_0;
	// System.Char System.String::m_firstChar
	Il2CppChar ___m_firstChar_1;

public:
	inline static int32_t get_offset_of_m_stringLength_0() { return static_cast<int32_t>(offsetof(String_t, ___m_stringLength_0)); }
	inline int32_t get_m_stringLength_0() const { return ___m_stringLength_0; }
	inline int32_t* get_address_of_m_stringLength_0() { return &___m_stringLength_0; }
	inline void set_m_stringLength_0(int32_t value)
	{
		___m_stringLength_0 = value;
	}

	inline static int32_t get_offset_of_m_firstChar_1() { return static_cast<int32_t>(offsetof(String_t, ___m_firstChar_1)); }
	inline Il2CppChar get_m_firstChar_1() const { return ___m_firstChar_1; }
	inline Il2CppChar* get_address_of_m_firstChar_1() { return &___m_firstChar_1; }
	inline void set_m_firstChar_1(Il2CppChar value)
	{
		___m_firstChar_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_5;

public:
	inline static int32_t get_offset_of_Empty_5() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_5)); }
	inline String_t* get_Empty_5() const { return ___Empty_5; }
	inline String_t** get_address_of_Empty_5() { return &___Empty_5; }
	inline void set_Empty_5(String_t* value)
	{
		___Empty_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Empty_5), (void*)value);
	}
};


// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};

// AK.Wwise.AcousticTexture
struct  AcousticTexture_t3A55AF140C3AD4F6F291BCB030AEE7E4CB251DBA  : public BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE
{
public:
	// WwiseAcousticTextureReference AK.Wwise.AcousticTexture::WwiseObjectReference
	WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805 * ___WwiseObjectReference_2;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_2() { return static_cast<int32_t>(offsetof(AcousticTexture_t3A55AF140C3AD4F6F291BCB030AEE7E4CB251DBA, ___WwiseObjectReference_2)); }
	inline WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805 * get_WwiseObjectReference_2() const { return ___WwiseObjectReference_2; }
	inline WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805 ** get_address_of_WwiseObjectReference_2() { return &___WwiseObjectReference_2; }
	inline void set_WwiseObjectReference_2(WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805 * value)
	{
		___WwiseObjectReference_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_2), (void*)value);
	}
};


// AK.Wwise.AuxBus
struct  AuxBus_tB74A0BABF2CB9974E22C2E1096C5B5A14FF72460  : public BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE
{
public:
	// WwiseAuxBusReference AK.Wwise.AuxBus::WwiseObjectReference
	WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3 * ___WwiseObjectReference_2;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_2() { return static_cast<int32_t>(offsetof(AuxBus_tB74A0BABF2CB9974E22C2E1096C5B5A14FF72460, ___WwiseObjectReference_2)); }
	inline WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3 * get_WwiseObjectReference_2() const { return ___WwiseObjectReference_2; }
	inline WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3 ** get_address_of_WwiseObjectReference_2() { return &___WwiseObjectReference_2; }
	inline void set_WwiseObjectReference_2(WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3 * value)
	{
		___WwiseObjectReference_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_2), (void*)value);
	}
};


// AK.Wwise.Bank
struct  Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA  : public BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE
{
public:
	// WwiseBankReference AK.Wwise.Bank::WwiseObjectReference
	WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6 * ___WwiseObjectReference_2;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_2() { return static_cast<int32_t>(offsetof(Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA, ___WwiseObjectReference_2)); }
	inline WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6 * get_WwiseObjectReference_2() const { return ___WwiseObjectReference_2; }
	inline WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6 ** get_address_of_WwiseObjectReference_2() { return &___WwiseObjectReference_2; }
	inline void set_WwiseObjectReference_2(WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6 * value)
	{
		___WwiseObjectReference_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_2), (void*)value);
	}
};


// AK.Wwise.BaseGroupType
struct  BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7  : public BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE
{
public:
	// System.Int32 AK.Wwise.BaseGroupType::groupIdInternal
	int32_t ___groupIdInternal_2;
	// System.Byte[] AK.Wwise.BaseGroupType::groupGuidInternal
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___groupGuidInternal_3;

public:
	inline static int32_t get_offset_of_groupIdInternal_2() { return static_cast<int32_t>(offsetof(BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7, ___groupIdInternal_2)); }
	inline int32_t get_groupIdInternal_2() const { return ___groupIdInternal_2; }
	inline int32_t* get_address_of_groupIdInternal_2() { return &___groupIdInternal_2; }
	inline void set_groupIdInternal_2(int32_t value)
	{
		___groupIdInternal_2 = value;
	}

	inline static int32_t get_offset_of_groupGuidInternal_3() { return static_cast<int32_t>(offsetof(BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7, ___groupGuidInternal_3)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_groupGuidInternal_3() const { return ___groupGuidInternal_3; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_groupGuidInternal_3() { return &___groupGuidInternal_3; }
	inline void set_groupGuidInternal_3(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___groupGuidInternal_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___groupGuidInternal_3), (void*)value);
	}
};


// AK.Wwise.Event
struct  Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F  : public BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE
{
public:
	// WwiseEventReference AK.Wwise.Event::WwiseObjectReference
	WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C * ___WwiseObjectReference_2;
	// System.UInt32 AK.Wwise.Event::m_playingId
	uint32_t ___m_playingId_3;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_2() { return static_cast<int32_t>(offsetof(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F, ___WwiseObjectReference_2)); }
	inline WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C * get_WwiseObjectReference_2() const { return ___WwiseObjectReference_2; }
	inline WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C ** get_address_of_WwiseObjectReference_2() { return &___WwiseObjectReference_2; }
	inline void set_WwiseObjectReference_2(WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C * value)
	{
		___WwiseObjectReference_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_2), (void*)value);
	}

	inline static int32_t get_offset_of_m_playingId_3() { return static_cast<int32_t>(offsetof(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F, ___m_playingId_3)); }
	inline uint32_t get_m_playingId_3() const { return ___m_playingId_3; }
	inline uint32_t* get_address_of_m_playingId_3() { return &___m_playingId_3; }
	inline void set_m_playingId_3(uint32_t value)
	{
		___m_playingId_3 = value;
	}
};


// AK.Wwise.RTPC
struct  RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C  : public BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE
{
public:
	// WwiseRtpcReference AK.Wwise.RTPC::WwiseObjectReference
	WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E * ___WwiseObjectReference_2;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_2() { return static_cast<int32_t>(offsetof(RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C, ___WwiseObjectReference_2)); }
	inline WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E * get_WwiseObjectReference_2() const { return ___WwiseObjectReference_2; }
	inline WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E ** get_address_of_WwiseObjectReference_2() { return &___WwiseObjectReference_2; }
	inline void set_WwiseObjectReference_2(WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E * value)
	{
		___WwiseObjectReference_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_2), (void*)value);
	}
};


// AK.Wwise.Trigger
struct  Trigger_t5ACE3FCFFD1C9CB7459B8CF2F15734EB96B4300E  : public BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE
{
public:
	// WwiseTriggerReference AK.Wwise.Trigger::WwiseObjectReference
	WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE * ___WwiseObjectReference_2;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_2() { return static_cast<int32_t>(offsetof(Trigger_t5ACE3FCFFD1C9CB7459B8CF2F15734EB96B4300E, ___WwiseObjectReference_2)); }
	inline WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE * get_WwiseObjectReference_2() const { return ___WwiseObjectReference_2; }
	inline WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE ** get_address_of_WwiseObjectReference_2() { return &___WwiseObjectReference_2; }
	inline void set_WwiseObjectReference_2(WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE * value)
	{
		___WwiseObjectReference_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_2), (void*)value);
	}
};


// System.Boolean
struct  Boolean_tB53F6830F670160873277339AA58F15CAED4399C 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Byte
struct  Byte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07 
{
public:
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Byte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07, ___m_value_0)); }
	inline uint8_t get_m_value_0() const { return ___m_value_0; }
	inline uint8_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint8_t value)
	{
		___m_value_0 = value;
	}
};


// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};

// System.Guid
struct  Guid_t 
{
public:
	// System.Int32 System.Guid::_a
	int32_t ____a_1;
	// System.Int16 System.Guid::_b
	int16_t ____b_2;
	// System.Int16 System.Guid::_c
	int16_t ____c_3;
	// System.Byte System.Guid::_d
	uint8_t ____d_4;
	// System.Byte System.Guid::_e
	uint8_t ____e_5;
	// System.Byte System.Guid::_f
	uint8_t ____f_6;
	// System.Byte System.Guid::_g
	uint8_t ____g_7;
	// System.Byte System.Guid::_h
	uint8_t ____h_8;
	// System.Byte System.Guid::_i
	uint8_t ____i_9;
	// System.Byte System.Guid::_j
	uint8_t ____j_10;
	// System.Byte System.Guid::_k
	uint8_t ____k_11;

public:
	inline static int32_t get_offset_of__a_1() { return static_cast<int32_t>(offsetof(Guid_t, ____a_1)); }
	inline int32_t get__a_1() const { return ____a_1; }
	inline int32_t* get_address_of__a_1() { return &____a_1; }
	inline void set__a_1(int32_t value)
	{
		____a_1 = value;
	}

	inline static int32_t get_offset_of__b_2() { return static_cast<int32_t>(offsetof(Guid_t, ____b_2)); }
	inline int16_t get__b_2() const { return ____b_2; }
	inline int16_t* get_address_of__b_2() { return &____b_2; }
	inline void set__b_2(int16_t value)
	{
		____b_2 = value;
	}

	inline static int32_t get_offset_of__c_3() { return static_cast<int32_t>(offsetof(Guid_t, ____c_3)); }
	inline int16_t get__c_3() const { return ____c_3; }
	inline int16_t* get_address_of__c_3() { return &____c_3; }
	inline void set__c_3(int16_t value)
	{
		____c_3 = value;
	}

	inline static int32_t get_offset_of__d_4() { return static_cast<int32_t>(offsetof(Guid_t, ____d_4)); }
	inline uint8_t get__d_4() const { return ____d_4; }
	inline uint8_t* get_address_of__d_4() { return &____d_4; }
	inline void set__d_4(uint8_t value)
	{
		____d_4 = value;
	}

	inline static int32_t get_offset_of__e_5() { return static_cast<int32_t>(offsetof(Guid_t, ____e_5)); }
	inline uint8_t get__e_5() const { return ____e_5; }
	inline uint8_t* get_address_of__e_5() { return &____e_5; }
	inline void set__e_5(uint8_t value)
	{
		____e_5 = value;
	}

	inline static int32_t get_offset_of__f_6() { return static_cast<int32_t>(offsetof(Guid_t, ____f_6)); }
	inline uint8_t get__f_6() const { return ____f_6; }
	inline uint8_t* get_address_of__f_6() { return &____f_6; }
	inline void set__f_6(uint8_t value)
	{
		____f_6 = value;
	}

	inline static int32_t get_offset_of__g_7() { return static_cast<int32_t>(offsetof(Guid_t, ____g_7)); }
	inline uint8_t get__g_7() const { return ____g_7; }
	inline uint8_t* get_address_of__g_7() { return &____g_7; }
	inline void set__g_7(uint8_t value)
	{
		____g_7 = value;
	}

	inline static int32_t get_offset_of__h_8() { return static_cast<int32_t>(offsetof(Guid_t, ____h_8)); }
	inline uint8_t get__h_8() const { return ____h_8; }
	inline uint8_t* get_address_of__h_8() { return &____h_8; }
	inline void set__h_8(uint8_t value)
	{
		____h_8 = value;
	}

	inline static int32_t get_offset_of__i_9() { return static_cast<int32_t>(offsetof(Guid_t, ____i_9)); }
	inline uint8_t get__i_9() const { return ____i_9; }
	inline uint8_t* get_address_of__i_9() { return &____i_9; }
	inline void set__i_9(uint8_t value)
	{
		____i_9 = value;
	}

	inline static int32_t get_offset_of__j_10() { return static_cast<int32_t>(offsetof(Guid_t, ____j_10)); }
	inline uint8_t get__j_10() const { return ____j_10; }
	inline uint8_t* get_address_of__j_10() { return &____j_10; }
	inline void set__j_10(uint8_t value)
	{
		____j_10 = value;
	}

	inline static int32_t get_offset_of__k_11() { return static_cast<int32_t>(offsetof(Guid_t, ____k_11)); }
	inline uint8_t get__k_11() const { return ____k_11; }
	inline uint8_t* get_address_of__k_11() { return &____k_11; }
	inline void set__k_11(uint8_t value)
	{
		____k_11 = value;
	}
};

struct Guid_t_StaticFields
{
public:
	// System.Guid System.Guid::Empty
	Guid_t  ___Empty_0;
	// System.Object System.Guid::_rngAccess
	RuntimeObject * ____rngAccess_12;
	// System.Security.Cryptography.RandomNumberGenerator System.Guid::_rng
	RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2 * ____rng_13;

public:
	inline static int32_t get_offset_of_Empty_0() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ___Empty_0)); }
	inline Guid_t  get_Empty_0() const { return ___Empty_0; }
	inline Guid_t * get_address_of_Empty_0() { return &___Empty_0; }
	inline void set_Empty_0(Guid_t  value)
	{
		___Empty_0 = value;
	}

	inline static int32_t get_offset_of__rngAccess_12() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rngAccess_12)); }
	inline RuntimeObject * get__rngAccess_12() const { return ____rngAccess_12; }
	inline RuntimeObject ** get_address_of__rngAccess_12() { return &____rngAccess_12; }
	inline void set__rngAccess_12(RuntimeObject * value)
	{
		____rngAccess_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____rngAccess_12), (void*)value);
	}

	inline static int32_t get_offset_of__rng_13() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rng_13)); }
	inline RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2 * get__rng_13() const { return ____rng_13; }
	inline RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2 ** get_address_of__rng_13() { return &____rng_13; }
	inline void set__rng_13(RandomNumberGenerator_t12277F7F965BA79C54E4B3BFABD27A5FFB725EE2 * value)
	{
		____rng_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____rng_13), (void*)value);
	}
};


// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// System.Single
struct  Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};


// System.UInt32
struct  UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};


// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};


// AK.Wwise.State
struct  State_t33FE9B211AA324266CA50DC53343CA54B4A6A74C  : public BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7
{
public:
	// WwiseStateReference AK.Wwise.State::WwiseObjectReference
	WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 * ___WwiseObjectReference_4;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_4() { return static_cast<int32_t>(offsetof(State_t33FE9B211AA324266CA50DC53343CA54B4A6A74C, ___WwiseObjectReference_4)); }
	inline WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 * get_WwiseObjectReference_4() const { return ___WwiseObjectReference_4; }
	inline WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 ** get_address_of_WwiseObjectReference_4() { return &___WwiseObjectReference_4; }
	inline void set_WwiseObjectReference_4(WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 * value)
	{
		___WwiseObjectReference_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_4), (void*)value);
	}
};


// AK.Wwise.Switch
struct  Switch_t3C5E93F72DE4D390F7C5E8F4ECC7765EBFEA75D7  : public BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7
{
public:
	// WwiseSwitchReference AK.Wwise.Switch::WwiseObjectReference
	WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 * ___WwiseObjectReference_4;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_4() { return static_cast<int32_t>(offsetof(Switch_t3C5E93F72DE4D390F7C5E8F4ECC7765EBFEA75D7, ___WwiseObjectReference_4)); }
	inline WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 * get_WwiseObjectReference_4() const { return ___WwiseObjectReference_4; }
	inline WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 ** get_address_of_WwiseObjectReference_4() { return &___WwiseObjectReference_4; }
	inline void set_WwiseObjectReference_4(WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 * value)
	{
		___WwiseObjectReference_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_4), (void*)value);
	}
};


// AKRESULT
struct  AKRESULT_tD4180A39C1C146D9D524C690593E626EAC82632D 
{
public:
	// System.Int32 AKRESULT::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AKRESULT_tD4180A39C1C146D9D524C690593E626EAC82632D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkActionOnEventType
struct  AkActionOnEventType_tF50137C5392E8FF66C92CD7FD8C10089C4B7FFDA 
{
public:
	// System.Int32 AkActionOnEventType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AkActionOnEventType_tF50137C5392E8FF66C92CD7FD8C10089C4B7FFDA, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkCallbackType
struct  AkCallbackType_t12D54123FC89B09B3A0DDEDED73128E43067F76C 
{
public:
	// System.Int32 AkCallbackType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AkCallbackType_t12D54123FC89B09B3A0DDEDED73128E43067F76C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkCurveInterpolation
struct  AkCurveInterpolation_t8BCCF34DA2DE3EEC52EB0432F409094258841BA9 
{
public:
	// System.Int32 AkCurveInterpolation::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AkCurveInterpolation_t8BCCF34DA2DE3EEC52EB0432F409094258841BA9, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkMIDIPostArray
struct  AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78  : public RuntimeObject
{
public:
	// System.Int32 AkMIDIPostArray::m_Count
	int32_t ___m_Count_0;
	// System.Int32 AkMIDIPostArray::SIZE_OF
	int32_t ___SIZE_OF_1;
	// System.IntPtr AkMIDIPostArray::m_Buffer
	intptr_t ___m_Buffer_2;

public:
	inline static int32_t get_offset_of_m_Count_0() { return static_cast<int32_t>(offsetof(AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78, ___m_Count_0)); }
	inline int32_t get_m_Count_0() const { return ___m_Count_0; }
	inline int32_t* get_address_of_m_Count_0() { return &___m_Count_0; }
	inline void set_m_Count_0(int32_t value)
	{
		___m_Count_0 = value;
	}

	inline static int32_t get_offset_of_SIZE_OF_1() { return static_cast<int32_t>(offsetof(AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78, ___SIZE_OF_1)); }
	inline int32_t get_SIZE_OF_1() const { return ___SIZE_OF_1; }
	inline int32_t* get_address_of_SIZE_OF_1() { return &___SIZE_OF_1; }
	inline void set_SIZE_OF_1(int32_t value)
	{
		___SIZE_OF_1 = value;
	}

	inline static int32_t get_offset_of_m_Buffer_2() { return static_cast<int32_t>(offsetof(AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78, ___m_Buffer_2)); }
	inline intptr_t get_m_Buffer_2() const { return ___m_Buffer_2; }
	inline intptr_t* get_address_of_m_Buffer_2() { return &___m_Buffer_2; }
	inline void set_m_Buffer_2(intptr_t value)
	{
		___m_Buffer_2 = value;
	}
};


// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_target_2), (void*)value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___method_info_7), (void*)value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___original_method_info_8), (void*)value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * get_data_9() const { return ___data_9; }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___data_9), (void*)value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};

// System.Reflection.BindingFlags
struct  BindingFlags_tE35C91D046E63A1B92BB9AB909FCF9DA84379ED0 
{
public:
	// System.Int32 System.Reflection.BindingFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(BindingFlags_tE35C91D046E63A1B92BB9AB909FCF9DA84379ED0, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.RuntimeTypeHandle
struct  RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D 
{
public:
	// System.IntPtr System.RuntimeTypeHandle::value
	intptr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D, ___value_0)); }
	inline intptr_t get_value_0() const { return ___value_0; }
	inline intptr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(intptr_t value)
	{
		___value_0 = value;
	}
};


// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// WwiseObjectType
struct  WwiseObjectType_t44E6AEBBAC5EB4F06796CC09EE0388208EF9D216 
{
public:
	// System.Int32 WwiseObjectType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WwiseObjectType_t44E6AEBBAC5EB4F06796CC09EE0388208EF9D216, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___delegates_11), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};

// System.Type
struct  Type_t  : public MemberInfo_t
{
public:
	// System.RuntimeTypeHandle System.Type::_impl
	RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D  ____impl_9;

public:
	inline static int32_t get_offset_of__impl_9() { return static_cast<int32_t>(offsetof(Type_t, ____impl_9)); }
	inline RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D  get__impl_9() const { return ____impl_9; }
	inline RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D * get_address_of__impl_9() { return &____impl_9; }
	inline void set__impl_9(RuntimeTypeHandle_t7B542280A22F0EC4EAC2061C29178845847A8B2D  value)
	{
		____impl_9 = value;
	}
};

struct Type_t_StaticFields
{
public:
	// System.Reflection.MemberFilter System.Type::FilterAttribute
	MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * ___FilterAttribute_0;
	// System.Reflection.MemberFilter System.Type::FilterName
	MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * ___FilterName_1;
	// System.Reflection.MemberFilter System.Type::FilterNameIgnoreCase
	MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * ___FilterNameIgnoreCase_2;
	// System.Object System.Type::Missing
	RuntimeObject * ___Missing_3;
	// System.Char System.Type::Delimiter
	Il2CppChar ___Delimiter_4;
	// System.Type[] System.Type::EmptyTypes
	TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F* ___EmptyTypes_5;
	// System.Reflection.Binder System.Type::defaultBinder
	Binder_t4D5CB06963501D32847C057B57157D6DC49CA759 * ___defaultBinder_6;

public:
	inline static int32_t get_offset_of_FilterAttribute_0() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterAttribute_0)); }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * get_FilterAttribute_0() const { return ___FilterAttribute_0; }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 ** get_address_of_FilterAttribute_0() { return &___FilterAttribute_0; }
	inline void set_FilterAttribute_0(MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * value)
	{
		___FilterAttribute_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FilterAttribute_0), (void*)value);
	}

	inline static int32_t get_offset_of_FilterName_1() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterName_1)); }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * get_FilterName_1() const { return ___FilterName_1; }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 ** get_address_of_FilterName_1() { return &___FilterName_1; }
	inline void set_FilterName_1(MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * value)
	{
		___FilterName_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FilterName_1), (void*)value);
	}

	inline static int32_t get_offset_of_FilterNameIgnoreCase_2() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterNameIgnoreCase_2)); }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * get_FilterNameIgnoreCase_2() const { return ___FilterNameIgnoreCase_2; }
	inline MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 ** get_address_of_FilterNameIgnoreCase_2() { return &___FilterNameIgnoreCase_2; }
	inline void set_FilterNameIgnoreCase_2(MemberFilter_t25C1BD92C42BE94426E300787C13C452CB89B381 * value)
	{
		___FilterNameIgnoreCase_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FilterNameIgnoreCase_2), (void*)value);
	}

	inline static int32_t get_offset_of_Missing_3() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___Missing_3)); }
	inline RuntimeObject * get_Missing_3() const { return ___Missing_3; }
	inline RuntimeObject ** get_address_of_Missing_3() { return &___Missing_3; }
	inline void set_Missing_3(RuntimeObject * value)
	{
		___Missing_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Missing_3), (void*)value);
	}

	inline static int32_t get_offset_of_Delimiter_4() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___Delimiter_4)); }
	inline Il2CppChar get_Delimiter_4() const { return ___Delimiter_4; }
	inline Il2CppChar* get_address_of_Delimiter_4() { return &___Delimiter_4; }
	inline void set_Delimiter_4(Il2CppChar value)
	{
		___Delimiter_4 = value;
	}

	inline static int32_t get_offset_of_EmptyTypes_5() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___EmptyTypes_5)); }
	inline TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F* get_EmptyTypes_5() const { return ___EmptyTypes_5; }
	inline TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F** get_address_of_EmptyTypes_5() { return &___EmptyTypes_5; }
	inline void set_EmptyTypes_5(TypeU5BU5D_t7FE623A666B49176DE123306221193E888A12F5F* value)
	{
		___EmptyTypes_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___EmptyTypes_5), (void*)value);
	}

	inline static int32_t get_offset_of_defaultBinder_6() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___defaultBinder_6)); }
	inline Binder_t4D5CB06963501D32847C057B57157D6DC49CA759 * get_defaultBinder_6() const { return ___defaultBinder_6; }
	inline Binder_t4D5CB06963501D32847C057B57157D6DC49CA759 ** get_address_of_defaultBinder_6() { return &___defaultBinder_6; }
	inline void set_defaultBinder_6(Binder_t4D5CB06963501D32847C057B57157D6DC49CA759 * value)
	{
		___defaultBinder_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___defaultBinder_6), (void*)value);
	}
};


// UnityEngine.GameObject
struct  GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};


// UnityEngine.ScriptableObject
struct  ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_pinvoke : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_com : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
};

// AkCallbackManager_BankCallback
struct  BankCallback_t4566058B743D615B6C79A9A3682B47476ADAE686  : public MulticastDelegate_t
{
public:

public:
};


// AkCallbackManager_EventCallback
struct  EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561  : public MulticastDelegate_t
{
public:

public:
};


// WwiseObjectReference
struct  WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:
	// System.String WwiseObjectReference::objectName
	String_t* ___objectName_4;
	// System.UInt32 WwiseObjectReference::id
	uint32_t ___id_5;
	// System.String WwiseObjectReference::guid
	String_t* ___guid_6;

public:
	inline static int32_t get_offset_of_objectName_4() { return static_cast<int32_t>(offsetof(WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6, ___objectName_4)); }
	inline String_t* get_objectName_4() const { return ___objectName_4; }
	inline String_t** get_address_of_objectName_4() { return &___objectName_4; }
	inline void set_objectName_4(String_t* value)
	{
		___objectName_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___objectName_4), (void*)value);
	}

	inline static int32_t get_offset_of_id_5() { return static_cast<int32_t>(offsetof(WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6, ___id_5)); }
	inline uint32_t get_id_5() const { return ___id_5; }
	inline uint32_t* get_address_of_id_5() { return &___id_5; }
	inline void set_id_5(uint32_t value)
	{
		___id_5 = value;
	}

	inline static int32_t get_offset_of_guid_6() { return static_cast<int32_t>(offsetof(WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6, ___guid_6)); }
	inline String_t* get_guid_6() const { return ___guid_6; }
	inline String_t** get_address_of_guid_6() { return &___guid_6; }
	inline void set_guid_6(String_t* value)
	{
		___guid_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___guid_6), (void*)value);
	}
};


// WwiseAcousticTextureReference
struct  WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805  : public WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6
{
public:

public:
};


// WwiseAuxBusReference
struct  WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3  : public WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6
{
public:

public:
};


// WwiseBankReference
struct  WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6  : public WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6
{
public:

public:
};


// WwiseEventReference
struct  WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C  : public WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6
{
public:

public:
};


// WwiseGroupValueObjectReference
struct  WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E  : public WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6
{
public:

public:
};


// WwiseRtpcReference
struct  WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E  : public WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6
{
public:

public:
};


// WwiseStateGroupReference
struct  WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6  : public WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6
{
public:

public:
};


// WwiseSwitchGroupReference
struct  WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6  : public WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6
{
public:

public:
};


// WwiseTriggerReference
struct  WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE  : public WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6
{
public:

public:
};


// WwiseStateReference
struct  WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511  : public WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E
{
public:
	// WwiseStateGroupReference WwiseStateReference::WwiseStateGroupReference
	WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6 * ___WwiseStateGroupReference_7;

public:
	inline static int32_t get_offset_of_WwiseStateGroupReference_7() { return static_cast<int32_t>(offsetof(WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511, ___WwiseStateGroupReference_7)); }
	inline WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6 * get_WwiseStateGroupReference_7() const { return ___WwiseStateGroupReference_7; }
	inline WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6 ** get_address_of_WwiseStateGroupReference_7() { return &___WwiseStateGroupReference_7; }
	inline void set_WwiseStateGroupReference_7(WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6 * value)
	{
		___WwiseStateGroupReference_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseStateGroupReference_7), (void*)value);
	}
};


// WwiseSwitchReference
struct  WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19  : public WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E
{
public:
	// WwiseSwitchGroupReference WwiseSwitchReference::WwiseSwitchGroupReference
	WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6 * ___WwiseSwitchGroupReference_7;

public:
	inline static int32_t get_offset_of_WwiseSwitchGroupReference_7() { return static_cast<int32_t>(offsetof(WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19, ___WwiseSwitchGroupReference_7)); }
	inline WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6 * get_WwiseSwitchGroupReference_7() const { return ___WwiseSwitchGroupReference_7; }
	inline WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6 ** get_address_of_WwiseSwitchGroupReference_7() { return &___WwiseSwitchGroupReference_7; }
	inline void set_WwiseSwitchGroupReference_7(WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6 * value)
	{
		___WwiseSwitchGroupReference_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseSwitchGroupReference_7), (void*)value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) uint8_t m_Items[1];

public:
	inline uint8_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline uint8_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, uint8_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline uint8_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline uint8_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, uint8_t value)
	{
		m_Items[index] = value;
	}
};



// System.Void AK.Wwise.BaseType::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898 (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method);
// System.Void AkBankManager::LoadBank(System.String,System.Boolean,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkBankManager_LoadBank_m2FCDED8CCBE26E9012699F88428103CA152FFDB9 (String_t* ___name0, bool ___decodeBank1, bool ___saveDecodedBank2, const RuntimeMethod* method);
// System.Void AkBankManager::LoadBankAsync(System.String,AkCallbackManager/BankCallback)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkBankManager_LoadBankAsync_mB0619AEA4718877300B46F9110C9E96C1041A5D8 (String_t* ___name0, BankCallback_t4566058B743D615B6C79A9A3682B47476ADAE686 * ___callback1, const RuntimeMethod* method);
// System.Void AkBankManager::UnloadBank(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkBankManager_UnloadBank_m9403088BE5722AE8633024748E68EA2B3542FB28 (String_t* ___name0, const RuntimeMethod* method);
// System.Boolean UnityEngine.Object::op_Implicit(UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534 (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___exists0, const RuntimeMethod* method);
// WwiseObjectReference AK.Wwise.BaseGroupType::get_GroupWwiseObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * BaseGroupType_get_GroupWwiseObjectReference_mC00EC611D1AB6A833A3389928F58AB828DEB509E (BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7 * __this, const RuntimeMethod* method);
// System.UInt32 WwiseObjectReference::get_Id()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR uint32_t WwiseObjectReference_get_Id_m6AFC577D7CB88EC618408101C2415016520205FB_inline (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method);
// System.Boolean AK.Wwise.BaseType::IsValid()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool BaseType_IsValid_mFF810061EE89CBE4C8E823B9DD12D868E95F90F5 (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.Object::op_Inequality(UnityEngine.Object,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1 (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___x0, Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___y1, const RuntimeMethod* method);
// System.UInt32 AK.Wwise.BaseGroupType::get_GroupId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t BaseGroupType_get_GroupId_mF73642DEE955F78AF36A9DED227DFAD6E36B9DA6 (BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7 * __this, const RuntimeMethod* method);
// System.Guid WwiseObjectReference::get_Guid()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Guid_t  WwiseObjectReference_get_Guid_mA730AB56F442D112796810ECFB314FD39CB33C14 (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method);
// System.Byte[] System.Guid::ToByteArray()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* Guid_ToByteArray_m5E99B09A26EA3A1943CC8FE697E247DAC5465223 (Guid_t * __this, const RuntimeMethod* method);
// System.Type System.Object::GetType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Type_t * Object_GetType_m2E0B62414ECCAA3094B703790CE88CBB2F83EA60 (RuntimeObject * __this, const RuntimeMethod* method);
// System.String System.String::Concat(System.String,System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_mF4626905368D6558695A823466A1AF65EADB9923 (String_t* ___str00, String_t* ___str11, String_t* ___str22, const RuntimeMethod* method);
// System.Void UnityEngine.Debug::LogWarning(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_LogWarning_m37338644DC81F640CCDFEAE35A223F0E965F0568 (RuntimeObject * ___message0, const RuntimeMethod* method);
// System.String System.String::Concat(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_mB78D0094592718DA6D5DB6C712A9C225631666BE (String_t* ___str00, String_t* ___str11, const RuntimeMethod* method);
// System.String WwiseObjectReference::get_ObjectName()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR String_t* WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821_inline (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method);
// System.UInt32 AK.Wwise.BaseType::get_Id()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method);
// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0 (RuntimeObject * __this, const RuntimeMethod* method);
// System.UInt32 AkSoundEngine::PostEvent(System.UInt32,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t AkSoundEngine_PostEvent_m70980C1B8E64FC6974A693637F1C3EF81B599EC5 (uint32_t ___in_eventID0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___in_gameObjectID1, const RuntimeMethod* method);
// System.Void AK.Wwise.Event::VerifyPlayingID(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_VerifyPlayingID_mF06416D9AED9C4251F6AA39D2FBCA71274DA926B (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, uint32_t ___playingId0, const RuntimeMethod* method);
// System.UInt32 AkSoundEngine::PostEvent(System.UInt32,UnityEngine.GameObject,System.UInt32,AkCallbackManager/EventCallback,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t AkSoundEngine_PostEvent_m6D65008EA2DF3ABE7F52D42987114D689C5C7F7B (uint32_t ___in_eventID0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___in_gameObjectID1, uint32_t ___in_uFlags2, EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 * ___in_pfnCallback3, RuntimeObject * ___in_pCookie4, const RuntimeMethod* method);
// System.Void AK.Wwise.Event::ExecuteAction(UnityEngine.GameObject,AkActionOnEventType,System.Int32,AkCurveInterpolation)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, int32_t ___actionOnEventType1, int32_t ___transitionDuration2, int32_t ___curveInterpolation3, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType,UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_ExecuteActionOnEvent_mEB060B0245616DD68C515B6BA20C3D0569B04D8E (uint32_t ___in_eventID0, int32_t ___in_ActionType1, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___in_gameObjectID2, int32_t ___in_uTransitionDuration3, int32_t ___in_eFadeCurve4, const RuntimeMethod* method);
// System.Void AK.Wwise.BaseType::Verify(AKRESULT)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, int32_t ___result0, const RuntimeMethod* method);
// System.Void AkMIDIPostArray::PostOnEvent(System.UInt32,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkMIDIPostArray_PostOnEvent_m66EC148F3ABCB245B84A636549488C4ACFF6FD4D (AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78 * __this, uint32_t ___in_eventID0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject1, const RuntimeMethod* method);
// System.Void AkMIDIPostArray::PostOnEvent(System.UInt32,UnityEngine.GameObject,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkMIDIPostArray_PostOnEvent_mFA194E3A82334997EF5B4C7FFC44ED64668CBE79 (AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78 * __this, uint32_t ___in_eventID0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject1, int32_t ___count2, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::StopMIDIOnEvent(System.UInt32,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_StopMIDIOnEvent_m8E8BD26C821D2DB66D754EB520049AE749D48F32 (uint32_t ___in_eventID0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___in_gameObjectID1, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::StopMIDIOnEvent(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_StopMIDIOnEvent_mFFB9A53556646A6E3FB7E4F782DEBDC5AE29E156 (uint32_t ___in_eventID0, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_SetRTPCValue_m18561150273DA0C176DADCBDF426E70613AF356D (uint32_t ___in_rtpcID0, float ___in_value1, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___in_gameObjectID2, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::GetRTPCValue(System.UInt32,UnityEngine.GameObject,System.UInt32,System.Single&,System.Int32&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_GetRTPCValue_m09BD553FBF1926B313A4C7FEE2D23221449B03B3 (uint32_t ___in_rtpcID0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___in_gameObjectID1, uint32_t ___in_playingID2, float* ___out_rValue3, int32_t* ___io_rValueType4, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_SetRTPCValue_mFD00540F3921139DB4467CAA06A2DAA43DD5EB19 (uint32_t ___in_rtpcID0, float ___in_value1, const RuntimeMethod* method);
// System.Single AK.Wwise.RTPC::GetValue(UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float RTPC_GetValue_mE4BBCDABF8F856CBD6E2E74B223130DDF4AD6776 (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::SetState(System.UInt32,System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_SetState_m27B10E6734080647D4ED57903BF9EA010F60D08C (uint32_t ___in_stateGroup0, uint32_t ___in_state1, const RuntimeMethod* method);
// System.Void AK.Wwise.BaseGroupType::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void BaseGroupType__ctor_m507DE24A74927CD8D251293A8F86756EDA3A136C (BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7 * __this, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::SetSwitch(System.UInt32,System.UInt32,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_SetSwitch_mB25E783656DD320341B7578E08A40F5EDD5046CA (uint32_t ___in_switchGroup0, uint32_t ___in_switchState1, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___in_gameObjectID2, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::PostTrigger(System.UInt32,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_PostTrigger_mAE35A465050B381130B8C1710F29A7C204600C0D (uint32_t ___in_triggerID0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___in_gameObjectID1, const RuntimeMethod* method);
// System.Void WwiseObjectReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method);
// System.Boolean System.String::IsNullOrEmpty(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_IsNullOrEmpty_m06A85A206AC2106D1982826C5665B9BD35324229 (String_t* ___value0, const RuntimeMethod* method);
// System.Void System.Guid::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Guid__ctor_mC668142577A40A77D13B78AADDEFFFC2E2705079 (Guid_t * __this, String_t* ___g0, const RuntimeMethod* method);
// System.Void UnityEngine.ScriptableObject::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ScriptableObject__ctor_m6E2B3821A4A361556FC12E9B1C71E1D5DC002C5B (ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734 * __this, const RuntimeMethod* method);
// System.Void WwiseGroupValueObjectReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseGroupValueObjectReference__ctor_mEF381CCC534B4D2B825DA84F6A69B8C93FBC04AE (WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E * __this, const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectReference AK.Wwise.AcousticTexture::get_ObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * AcousticTexture_get_ObjectReference_mF40AF0DC967818D3827FBE267E243F4D116D8821 (AcousticTexture_t3A55AF140C3AD4F6F291BCB030AEE7E4CB251DBA * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseObjectReference; }
		WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805 * L_0 = __this->get_WwiseObjectReference_2();
		return L_0;
	}
}
// System.Void AK.Wwise.AcousticTexture::set_ObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AcousticTexture_set_ObjectReference_mBDAB9D5BA879D24BF1C7F543F76CEFD442E58A9D (AcousticTexture_t3A55AF140C3AD4F6F291BCB030AEE7E4CB251DBA * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AcousticTexture_set_ObjectReference_mBDAB9D5BA879D24BF1C7F543F76CEFD442E58A9D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseObjectReference = value as WwiseAcousticTextureReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseObjectReference_2(((WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805 *)IsInstClass((RuntimeObject*)L_0, WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805_il2cpp_TypeInfo_var)));
		// set { WwiseObjectReference = value as WwiseAcousticTextureReference; }
		return;
	}
}
// WwiseObjectType AK.Wwise.AcousticTexture::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AcousticTexture_get_WwiseObjectType_mF67FBA56C692AA7454C4140AD39D066B38B33346 (AcousticTexture_t3A55AF140C3AD4F6F291BCB030AEE7E4CB251DBA * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.AcousticTexture; } }
		return (int32_t)(((int32_t)15));
	}
}
// System.Void AK.Wwise.AcousticTexture::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AcousticTexture__ctor_m0E2DB175634A4592BE9BABD27E40EDF0FBC5EBDE (AcousticTexture_t3A55AF140C3AD4F6F291BCB030AEE7E4CB251DBA * __this, const RuntimeMethod* method)
{
	{
		BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectReference AK.Wwise.AuxBus::get_ObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * AuxBus_get_ObjectReference_mEB909C28D1C9B36CB5DB1792985C94EC4837A6D4 (AuxBus_tB74A0BABF2CB9974E22C2E1096C5B5A14FF72460 * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseObjectReference; }
		WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3 * L_0 = __this->get_WwiseObjectReference_2();
		return L_0;
	}
}
// System.Void AK.Wwise.AuxBus::set_ObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AuxBus_set_ObjectReference_m130FCE92CFF4D543369BC5154D8EAFBCF96FDA9E (AuxBus_tB74A0BABF2CB9974E22C2E1096C5B5A14FF72460 * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AuxBus_set_ObjectReference_m130FCE92CFF4D543369BC5154D8EAFBCF96FDA9E_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseObjectReference = value as WwiseAuxBusReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseObjectReference_2(((WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3 *)IsInstClass((RuntimeObject*)L_0, WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3_il2cpp_TypeInfo_var)));
		// set { WwiseObjectReference = value as WwiseAuxBusReference; }
		return;
	}
}
// WwiseObjectType AK.Wwise.AuxBus::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AuxBus_get_WwiseObjectType_m843FE87544B19EAD2A090F8099D2104C4433AA16 (AuxBus_tB74A0BABF2CB9974E22C2E1096C5B5A14FF72460 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.AuxBus; } }
		return (int32_t)(1);
	}
}
// System.Void AK.Wwise.AuxBus::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AuxBus__ctor_mDA756A46983C38D87850ABF7BF5C47BD4A4E9731 (AuxBus_tB74A0BABF2CB9974E22C2E1096C5B5A14FF72460 * __this, const RuntimeMethod* method)
{
	{
		BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType AK.Wwise.Bank::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Bank_get_WwiseObjectType_m74AF277A309F5A7034F3325643943B14B6E3D483 (Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.Soundbank; } }
		return (int32_t)(7);
	}
}
// WwiseObjectReference AK.Wwise.Bank::get_ObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * Bank_get_ObjectReference_m5C061EAE560173E72FB4B9595A4A3449CA68F282 (Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseObjectReference; }
		WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6 * L_0 = __this->get_WwiseObjectReference_2();
		return L_0;
	}
}
// System.Void AK.Wwise.Bank::set_ObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Bank_set_ObjectReference_m70806BA0660E74626D2F04575930B5A5B9B609E7 (Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Bank_set_ObjectReference_m70806BA0660E74626D2F04575930B5A5B9B609E7_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseObjectReference = value as WwiseBankReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseObjectReference_2(((WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6 *)IsInstClass((RuntimeObject*)L_0, WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6_il2cpp_TypeInfo_var)));
		// set { WwiseObjectReference = value as WwiseBankReference; }
		return;
	}
}
// System.Void AK.Wwise.Bank::Load(System.Boolean,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Bank_Load_mE46124DE4BEB7444BFAB5D030E483D07E749732D (Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA * __this, bool ___decodeBank0, bool ___saveDecodedBank1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Bank_Load_mE46124DE4BEB7444BFAB5D030E483D07E749732D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0015;
		}
	}
	{
		// AkBankManager.LoadBank(Name, decodeBank, saveDecodedBank);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(7 /* System.String AK.Wwise.BaseType::get_Name() */, __this);
		bool L_2 = ___decodeBank0;
		bool L_3 = ___saveDecodedBank1;
		IL2CPP_RUNTIME_CLASS_INIT(AkBankManager_t0707FA28C848388CF54FDA6E5C5C8A34F1BBF7EA_il2cpp_TypeInfo_var);
		AkBankManager_LoadBank_m2FCDED8CCBE26E9012699F88428103CA152FFDB9(L_1, L_2, L_3, /*hidden argument*/NULL);
	}

IL_0015:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Bank::LoadAsync(AkCallbackManager_BankCallback)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Bank_LoadAsync_mD0EDAB56C81E98240631CCE3AFA5175F56A8C79D (Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA * __this, BankCallback_t4566058B743D615B6C79A9A3682B47476ADAE686 * ___callback0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Bank_LoadAsync_mD0EDAB56C81E98240631CCE3AFA5175F56A8C79D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0014;
		}
	}
	{
		// AkBankManager.LoadBankAsync(Name, callback);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(7 /* System.String AK.Wwise.BaseType::get_Name() */, __this);
		BankCallback_t4566058B743D615B6C79A9A3682B47476ADAE686 * L_2 = ___callback0;
		IL2CPP_RUNTIME_CLASS_INIT(AkBankManager_t0707FA28C848388CF54FDA6E5C5C8A34F1BBF7EA_il2cpp_TypeInfo_var);
		AkBankManager_LoadBankAsync_mB0619AEA4718877300B46F9110C9E96C1041A5D8(L_1, L_2, /*hidden argument*/NULL);
	}

IL_0014:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Bank::Unload()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Bank_Unload_m0E6337A3DE4E818A065D60456BA28FE66959CAFD (Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Bank_Unload_m0E6337A3DE4E818A065D60456BA28FE66959CAFD_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		// AkBankManager.UnloadBank(Name);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(7 /* System.String AK.Wwise.BaseType::get_Name() */, __this);
		IL2CPP_RUNTIME_CLASS_INIT(AkBankManager_t0707FA28C848388CF54FDA6E5C5C8A34F1BBF7EA_il2cpp_TypeInfo_var);
		AkBankManager_UnloadBank_m9403088BE5722AE8633024748E68EA2B3542FB28(L_1, /*hidden argument*/NULL);
	}

IL_0013:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Bank::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Bank__ctor_m02ED1634B3F356354DF9780F4FD0D89BC560D2A1 (Bank_t3B4511CF658980DDC5ABBA2ABC655A0B46B6C8FA * __this, const RuntimeMethod* method)
{
	{
		BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectReference AK.Wwise.BaseGroupType::get_GroupWwiseObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * BaseGroupType_get_GroupWwiseObjectReference_mC00EC611D1AB6A833A3389928F58AB828DEB509E (BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseGroupType_get_GroupWwiseObjectReference_mC00EC611D1AB6A833A3389928F58AB828DEB509E_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E * V_0 = NULL;
	{
		// var reference = ObjectReference as WwiseGroupValueObjectReference;
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = VirtFuncInvoker0< WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * >::Invoke(4 /* WwiseObjectReference AK.Wwise.BaseType::get_ObjectReference() */, __this);
		V_0 = ((WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E *)IsInstClass((RuntimeObject*)L_0, WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E_il2cpp_TypeInfo_var));
		// return reference ? reference.GroupObjectReference : null;
		WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E * L_1 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_2 = Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534(L_1, /*hidden argument*/NULL);
		if (L_2)
		{
			goto IL_0016;
		}
	}
	{
		return (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 *)NULL;
	}

IL_0016:
	{
		WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E * L_3 = V_0;
		NullCheck(L_3);
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_4 = VirtFuncInvoker0< WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * >::Invoke(6 /* WwiseObjectReference WwiseGroupValueObjectReference::get_GroupObjectReference() */, L_3);
		return L_4;
	}
}
// System.UInt32 AK.Wwise.BaseGroupType::get_GroupId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t BaseGroupType_get_GroupId_mF73642DEE955F78AF36A9DED227DFAD6E36B9DA6 (BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseGroupType_get_GroupId_mF73642DEE955F78AF36A9DED227DFAD6E36B9DA6_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// get { return GroupWwiseObjectReference ? GroupWwiseObjectReference.Id : AkSoundEngine.AK_INVALID_UNIQUE_ID; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = BaseGroupType_get_GroupWwiseObjectReference_mC00EC611D1AB6A833A3389928F58AB828DEB509E(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_1 = Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534(L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_000f;
		}
	}
	{
		return 0;
	}

IL_000f:
	{
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_2 = BaseGroupType_get_GroupWwiseObjectReference_mC00EC611D1AB6A833A3389928F58AB828DEB509E(__this, /*hidden argument*/NULL);
		NullCheck(L_2);
		uint32_t L_3 = WwiseObjectReference_get_Id_m6AFC577D7CB88EC618408101C2415016520205FB_inline(L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Boolean AK.Wwise.BaseGroupType::IsValid()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool BaseGroupType_IsValid_mADCBE3C3E7B68B2D97014E1A84B2526BBE0AEDDB (BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseGroupType_IsValid_mADCBE3C3E7B68B2D97014E1A84B2526BBE0AEDDB_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return base.IsValid() && GroupWwiseObjectReference != null;
		bool L_0 = BaseType_IsValid_mFF810061EE89CBE4C8E823B9DD12D868E95F90F5(__this, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0015;
		}
	}
	{
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_1 = BaseGroupType_get_GroupWwiseObjectReference_mC00EC611D1AB6A833A3389928F58AB828DEB509E(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_2 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_1, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		return L_2;
	}

IL_0015:
	{
		return (bool)0;
	}
}
// System.Int32 AK.Wwise.BaseGroupType::get_groupID()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t BaseGroupType_get_groupID_mAA3C98D2E4BE7F4DCA97AC0B84E467F4527F187F (BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7 * __this, const RuntimeMethod* method)
{
	{
		// get { return (int)GroupId; }
		uint32_t L_0 = BaseGroupType_get_GroupId_mF73642DEE955F78AF36A9DED227DFAD6E36B9DA6(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Byte[] AK.Wwise.BaseGroupType::get_groupGuid()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* BaseGroupType_get_groupGuid_m6B0D66D9318433251D42610956CFB90B05B7EF8B (BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseGroupType_get_groupGuid_m6B0D66D9318433251D42610956CFB90B05B7EF8B_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * V_0 = NULL;
	Guid_t  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		// var objRef = ObjectReference;
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = VirtFuncInvoker0< WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * >::Invoke(4 /* WwiseObjectReference AK.Wwise.BaseType::get_ObjectReference() */, __this);
		V_0 = L_0;
		// return !objRef ? null : objRef.Guid.ToByteArray();
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_1 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_2 = Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534(L_1, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_001e;
		}
	}
	{
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_3 = V_0;
		NullCheck(L_3);
		Guid_t  L_4 = WwiseObjectReference_get_Guid_mA730AB56F442D112796810ECFB314FD39CB33C14(L_3, /*hidden argument*/NULL);
		V_1 = L_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_5 = Guid_ToByteArray_m5E99B09A26EA3A1943CC8FE697E247DAC5465223((Guid_t *)(&V_1), /*hidden argument*/NULL);
		return L_5;
	}

IL_001e:
	{
		return (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*)NULL;
	}
}
// System.Void AK.Wwise.BaseGroupType::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void BaseGroupType__ctor_m507DE24A74927CD8D251293A8F86756EDA3A136C (BaseGroupType_tBE1D219FC472092BD6AD452B340CC8E3747216B7 * __this, const RuntimeMethod* method)
{
	{
		BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.String AK.Wwise.BaseType::get_Name()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* BaseType_get_Name_mDFFF2E7872296A918CB207A3D4F0141A82A57651 (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseType_get_Name_mDFFF2E7872296A918CB207A3D4F0141A82A57651_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// get { return IsValid() ? ObjectReference.DisplayName : string.Empty; }
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (L_0)
		{
			goto IL_000e;
		}
	}
	{
		String_t* L_1 = ((String_t_StaticFields*)il2cpp_codegen_static_fields_for(String_t_il2cpp_TypeInfo_var))->get_Empty_5();
		return L_1;
	}

IL_000e:
	{
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_2 = VirtFuncInvoker0< WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * >::Invoke(4 /* WwiseObjectReference AK.Wwise.BaseType::get_ObjectReference() */, __this);
		NullCheck(L_2);
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(4 /* System.String WwiseObjectReference::get_DisplayName() */, L_2);
		return L_3;
	}
}
// System.UInt32 AK.Wwise.BaseType::get_Id()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method)
{
	{
		// get { return IsValid() ? ObjectReference.Id : AkSoundEngine.AK_INVALID_UNIQUE_ID; }
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (L_0)
		{
			goto IL_000a;
		}
	}
	{
		return 0;
	}

IL_000a:
	{
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_1 = VirtFuncInvoker0< WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * >::Invoke(4 /* WwiseObjectReference AK.Wwise.BaseType::get_ObjectReference() */, __this);
		NullCheck(L_1);
		uint32_t L_2 = WwiseObjectReference_get_Id_m6AFC577D7CB88EC618408101C2415016520205FB_inline(L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.UInt32 AK.Wwise.BaseType::get_InvalidId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t BaseType_get_InvalidId_mC09A7B7CB1FDDF5F0F341E5F23D7CA7849172D26 (const RuntimeMethod* method)
{
	{
		// get { return AkSoundEngine.AK_INVALID_UNIQUE_ID; }
		return 0;
	}
}
// System.Boolean AK.Wwise.BaseType::IsValid()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool BaseType_IsValid_mFF810061EE89CBE4C8E823B9DD12D868E95F90F5 (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseType_IsValid_mFF810061EE89CBE4C8E823B9DD12D868E95F90F5_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return ObjectReference != null;
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = VirtFuncInvoker0< WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * >::Invoke(4 /* WwiseObjectReference AK.Wwise.BaseType::get_ObjectReference() */, __this);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_1 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_0, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Boolean AK.Wwise.BaseType::Validate()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool BaseType_Validate_mCF58D3BA9A28AA4DB9F4C2BB11728A222730C109 (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseType_Validate_mCF58D3BA9A28AA4DB9F4C2BB11728A222730C109_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_000a;
		}
	}
	{
		// return true;
		return (bool)1;
	}

IL_000a:
	{
		// UnityEngine.Debug.LogWarning("Wwise ID has not been resolved. Consider picking a new " + GetType().Name + ".");
		Type_t * L_1 = Object_GetType_m2E0B62414ECCAA3094B703790CE88CBB2F83EA60(__this, /*hidden argument*/NULL);
		NullCheck(L_1);
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(7 /* System.String System.Reflection.MemberInfo::get_Name() */, L_1);
		String_t* L_3 = String_Concat_mF4626905368D6558695A823466A1AF65EADB9923(_stringLiteral47C86F27A40F154D0FF5D5D54021387BEB1A3752, L_2, _stringLiteral3A52CE780950D4D969792A2559CD519D7EE8C727, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Debug_t7B5FCB117E2FD63B6838BC52821B252E2BFB61C4_il2cpp_TypeInfo_var);
		Debug_LogWarning_m37338644DC81F640CCDFEAE35A223F0E965F0568(L_3, /*hidden argument*/NULL);
		// return false;
		return (bool)0;
	}
}
// System.Void AK.Wwise.BaseType::Verify(AKRESULT)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, int32_t ___result0, const RuntimeMethod* method)
{
	{
		// }
		return;
	}
}
// System.String AK.Wwise.BaseType::ToString()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* BaseType_ToString_mAAFCAE5E25C7899DD5114DD7D778A6D1E5D4CF2C (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseType_ToString_mAAFCAE5E25C7899DD5114DD7D778A6D1E5D4CF2C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return IsValid() ? ObjectReference.ObjectName : ("Empty " + GetType().Name);
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (L_0)
		{
			goto IL_001e;
		}
	}
	{
		Type_t * L_1 = Object_GetType_m2E0B62414ECCAA3094B703790CE88CBB2F83EA60(__this, /*hidden argument*/NULL);
		NullCheck(L_1);
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(7 /* System.String System.Reflection.MemberInfo::get_Name() */, L_1);
		String_t* L_3 = String_Concat_mB78D0094592718DA6D5DB6C712A9C225631666BE(_stringLiteralC3CF574CB7C9180E542021AF824ED52565F509F6, L_2, /*hidden argument*/NULL);
		return L_3;
	}

IL_001e:
	{
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_4 = VirtFuncInvoker0< WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * >::Invoke(4 /* WwiseObjectReference AK.Wwise.BaseType::get_ObjectReference() */, __this);
		NullCheck(L_4);
		String_t* L_5 = WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821_inline(L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// System.Int32 AK.Wwise.BaseType::get_ID()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t BaseType_get_ID_mD6C019E541BADA7F08CA0AB73BF51F665C0F88EE (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method)
{
	{
		// get { return (int)Id; }
		uint32_t L_0 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Byte[] AK.Wwise.BaseType::get_valueGuid()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* BaseType_get_valueGuid_mBCE9BC6DCBA50287E5EAEFD7EC058BFF7D0EE944 (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseType_get_valueGuid_mBCE9BC6DCBA50287E5EAEFD7EC058BFF7D0EE944_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * V_0 = NULL;
	Guid_t  V_1;
	memset((&V_1), 0, sizeof(V_1));
	{
		// var objRef = ObjectReference;
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = VirtFuncInvoker0< WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * >::Invoke(4 /* WwiseObjectReference AK.Wwise.BaseType::get_ObjectReference() */, __this);
		V_0 = L_0;
		// return !objRef ? null : objRef.Guid.ToByteArray();
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_1 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_2 = Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534(L_1, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_001e;
		}
	}
	{
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_3 = V_0;
		NullCheck(L_3);
		Guid_t  L_4 = WwiseObjectReference_get_Guid_mA730AB56F442D112796810ECFB314FD39CB33C14(L_3, /*hidden argument*/NULL);
		V_1 = L_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_5 = Guid_ToByteArray_m5E99B09A26EA3A1943CC8FE697E247DAC5465223((Guid_t *)(&V_1), /*hidden argument*/NULL);
		return L_5;
	}

IL_001e:
	{
		return (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*)NULL;
	}
}
// System.Void AK.Wwise.BaseType::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898 (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AK.Wwise.CallbackFlags::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CallbackFlags__ctor_m601552170E49E5E73BE6EFB37CDAC4835C8B79A5 (CallbackFlags_tF53FCB71961652A8EC87A77A5D382C014BC7CA1F * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.UInt32 AK.Wwise.Event::get_PlayingId()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t Event_get_PlayingId_m45A26FC96EBD32601B9EC4580DD5222142A98178 (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, const RuntimeMethod* method)
{
	{
		// get { return m_playingId; }
		uint32_t L_0 = __this->get_m_playingId_3();
		return L_0;
	}
}
// WwiseObjectReference AK.Wwise.Event::get_ObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * Event_get_ObjectReference_m7317DF42BCCC275C6C191AE001087498D4065FE1 (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseObjectReference; }
		WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C * L_0 = __this->get_WwiseObjectReference_2();
		return L_0;
	}
}
// System.Void AK.Wwise.Event::set_ObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_set_ObjectReference_m1A659F392D4DA6CB6BF285D8FC6256BC40A48C7D (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Event_set_ObjectReference_m1A659F392D4DA6CB6BF285D8FC6256BC40A48C7D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseObjectReference = value as WwiseEventReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseObjectReference_2(((WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C *)IsInstClass((RuntimeObject*)L_0, WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C_il2cpp_TypeInfo_var)));
		// set { WwiseObjectReference = value as WwiseEventReference; }
		return;
	}
}
// WwiseObjectType AK.Wwise.Event::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Event_get_WwiseObjectType_m5E0F8AC9167575B4FCEAE4773607C5F37D2C0EF0 (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.Event; } }
		return (int32_t)(3);
	}
}
// System.Void AK.Wwise.Event::VerifyPlayingID(System.UInt32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_VerifyPlayingID_mF06416D9AED9C4251F6AA39D2FBCA71274DA926B (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, uint32_t ___playingId0, const RuntimeMethod* method)
{
	{
		// }
		return;
	}
}
// System.UInt32 AK.Wwise.Event::Post(UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t Event_Post_mB44E5C0A82FA36EDC65070D3024E066EE4D21F7A (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Event_Post_mB44E5C0A82FA36EDC65070D3024E066EE4D21F7A_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (!IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (L_0)
		{
			goto IL_000a;
		}
	}
	{
		// return AkSoundEngine.AK_INVALID_PLAYING_ID;
		return 0;
	}

IL_000a:
	{
		// m_playingId = AkSoundEngine.PostEvent(Id, gameObject);
		uint32_t L_1 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_2 = ___gameObject0;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		uint32_t L_3 = AkSoundEngine_PostEvent_m70980C1B8E64FC6974A693637F1C3EF81B599EC5(L_1, L_2, /*hidden argument*/NULL);
		__this->set_m_playingId_3(L_3);
		// VerifyPlayingID(m_playingId);
		uint32_t L_4 = __this->get_m_playingId_3();
		Event_VerifyPlayingID_mF06416D9AED9C4251F6AA39D2FBCA71274DA926B(__this, L_4, /*hidden argument*/NULL);
		// return m_playingId;
		uint32_t L_5 = __this->get_m_playingId_3();
		return L_5;
	}
}
// System.UInt32 AK.Wwise.Event::Post(UnityEngine.GameObject,AK.Wwise.CallbackFlags,AkCallbackManager_EventCallback,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t Event_Post_m7E549AC780ECAC443484AC66E4201AC85AC34938 (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, CallbackFlags_tF53FCB71961652A8EC87A77A5D382C014BC7CA1F * ___flags1, EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 * ___callback2, RuntimeObject * ___cookie3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Event_Post_m7E549AC780ECAC443484AC66E4201AC85AC34938_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (!IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (L_0)
		{
			goto IL_000a;
		}
	}
	{
		// return AkSoundEngine.AK_INVALID_PLAYING_ID;
		return 0;
	}

IL_000a:
	{
		// m_playingId = AkSoundEngine.PostEvent(Id, gameObject, flags.value, callback, cookie);
		uint32_t L_1 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_2 = ___gameObject0;
		CallbackFlags_tF53FCB71961652A8EC87A77A5D382C014BC7CA1F * L_3 = ___flags1;
		NullCheck(L_3);
		uint32_t L_4 = L_3->get_value_0();
		EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 * L_5 = ___callback2;
		RuntimeObject * L_6 = ___cookie3;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		uint32_t L_7 = AkSoundEngine_PostEvent_m6D65008EA2DF3ABE7F52D42987114D689C5C7F7B(L_1, L_2, L_4, L_5, L_6, /*hidden argument*/NULL);
		__this->set_m_playingId_3(L_7);
		// VerifyPlayingID(m_playingId);
		uint32_t L_8 = __this->get_m_playingId_3();
		Event_VerifyPlayingID_mF06416D9AED9C4251F6AA39D2FBCA71274DA926B(__this, L_8, /*hidden argument*/NULL);
		// return m_playingId;
		uint32_t L_9 = __this->get_m_playingId_3();
		return L_9;
	}
}
// System.UInt32 AK.Wwise.Event::Post(UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t Event_Post_m975A00B31848012ACE9114D3FDB25CA0E630601D (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, uint32_t ___flags1, EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 * ___callback2, RuntimeObject * ___cookie3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Event_Post_m975A00B31848012ACE9114D3FDB25CA0E630601D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (!IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (L_0)
		{
			goto IL_000a;
		}
	}
	{
		// return AkSoundEngine.AK_INVALID_PLAYING_ID;
		return 0;
	}

IL_000a:
	{
		// m_playingId = AkSoundEngine.PostEvent(Id, gameObject, flags, callback, cookie);
		uint32_t L_1 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_2 = ___gameObject0;
		uint32_t L_3 = ___flags1;
		EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 * L_4 = ___callback2;
		RuntimeObject * L_5 = ___cookie3;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		uint32_t L_6 = AkSoundEngine_PostEvent_m6D65008EA2DF3ABE7F52D42987114D689C5C7F7B(L_1, L_2, L_3, L_4, L_5, /*hidden argument*/NULL);
		__this->set_m_playingId_3(L_6);
		// VerifyPlayingID(m_playingId);
		uint32_t L_7 = __this->get_m_playingId_3();
		Event_VerifyPlayingID_mF06416D9AED9C4251F6AA39D2FBCA71274DA926B(__this, L_7, /*hidden argument*/NULL);
		// return m_playingId;
		uint32_t L_8 = __this->get_m_playingId_3();
		return L_8;
	}
}
// System.Void AK.Wwise.Event::Stop(UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_Stop_mF058FF1C69C98C1C87C1B2F517DBDBEAAE85D943 (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, int32_t ___transitionDuration1, int32_t ___curveInterpolation2, const RuntimeMethod* method)
{
	{
		// ExecuteAction(gameObject, AkActionOnEventType.AkActionOnEventType_Stop, transitionDuration, curveInterpolation);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_0 = ___gameObject0;
		int32_t L_1 = ___transitionDuration1;
		int32_t L_2 = ___curveInterpolation2;
		Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE(__this, L_0, 0, L_1, L_2, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void AK.Wwise.Event::ExecuteAction(UnityEngine.GameObject,AkActionOnEventType,System.Int32,AkCurveInterpolation)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, int32_t ___actionOnEventType1, int32_t ___transitionDuration2, int32_t ___curveInterpolation3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0020;
		}
	}
	{
		// var result = AkSoundEngine.ExecuteActionOnEvent(Id, actionOnEventType, gameObject, transitionDuration,
		//     curveInterpolation);
		uint32_t L_1 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		int32_t L_2 = ___actionOnEventType1;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_3 = ___gameObject0;
		int32_t L_4 = ___transitionDuration2;
		int32_t L_5 = ___curveInterpolation3;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		int32_t L_6 = AkSoundEngine_ExecuteActionOnEvent_mEB060B0245616DD68C515B6BA20C3D0569B04D8E(L_1, L_2, L_3, L_4, L_5, /*hidden argument*/NULL);
		V_0 = L_6;
		// Verify(result);
		int32_t L_7 = V_0;
		BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D(__this, L_7, /*hidden argument*/NULL);
	}

IL_0020:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Event::PostMIDI(UnityEngine.GameObject,AkMIDIPostArray)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_PostMIDI_m982B73165A912E06894938827527969DCC2F0D3D (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78 * ___array1, const RuntimeMethod* method)
{
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0015;
		}
	}
	{
		// array.PostOnEvent(Id, gameObject);
		AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78 * L_1 = ___array1;
		uint32_t L_2 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_3 = ___gameObject0;
		NullCheck(L_1);
		AkMIDIPostArray_PostOnEvent_m66EC148F3ABCB245B84A636549488C4ACFF6FD4D(L_1, L_2, L_3, /*hidden argument*/NULL);
	}

IL_0015:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Event::PostMIDI(UnityEngine.GameObject,AkMIDIPostArray,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_PostMIDI_m3AECB7750EF014AE8C0D51AC4E779FA731EA43F4 (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78 * ___array1, int32_t ___count2, const RuntimeMethod* method)
{
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		// array.PostOnEvent(Id, gameObject, count);
		AkMIDIPostArray_t75C719DF1567975822C8562CCAAF6894695A4A78 * L_1 = ___array1;
		uint32_t L_2 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_3 = ___gameObject0;
		int32_t L_4 = ___count2;
		NullCheck(L_1);
		AkMIDIPostArray_PostOnEvent_mFA194E3A82334997EF5B4C7FFC44ED64668CBE79(L_1, L_2, L_3, L_4, /*hidden argument*/NULL);
	}

IL_0016:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Event::StopMIDI(UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_StopMIDI_m134DB6480821D066829993FC9AE0089183A85B25 (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Event_StopMIDI_m134DB6480821D066829993FC9AE0089183A85B25_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0015;
		}
	}
	{
		// AkSoundEngine.StopMIDIOnEvent(Id, gameObject);
		uint32_t L_1 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_2 = ___gameObject0;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		AkSoundEngine_StopMIDIOnEvent_m8E8BD26C821D2DB66D754EB520049AE749D48F32(L_1, L_2, /*hidden argument*/NULL);
	}

IL_0015:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Event::StopMIDI()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_StopMIDI_m3EF14DD7C5CDA754301D41F35138329678A3E806 (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Event_StopMIDI_m3EF14DD7C5CDA754301D41F35138329678A3E806_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0014;
		}
	}
	{
		// AkSoundEngine.StopMIDIOnEvent(Id);
		uint32_t L_1 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		AkSoundEngine_StopMIDIOnEvent_mFFB9A53556646A6E3FB7E4F782DEBDC5AE29E156(L_1, /*hidden argument*/NULL);
	}

IL_0014:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Event::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event__ctor_mB99941177C1FF4FE4FDDD4185CB0C25681F4815D (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, const RuntimeMethod* method)
{
	{
		BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectReference AK.Wwise.RTPC::get_ObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * RTPC_get_ObjectReference_m445052D3FBE9D3166A82FD97A5E0145C721A5B50 (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseObjectReference; }
		WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E * L_0 = __this->get_WwiseObjectReference_2();
		return L_0;
	}
}
// System.Void AK.Wwise.RTPC::set_ObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RTPC_set_ObjectReference_mA15859BEF88F307DC76FCC01EB1EA597E60FC557 (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (RTPC_set_ObjectReference_mA15859BEF88F307DC76FCC01EB1EA597E60FC557_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseObjectReference = value as WwiseRtpcReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseObjectReference_2(((WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E *)IsInstClass((RuntimeObject*)L_0, WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E_il2cpp_TypeInfo_var)));
		// set { WwiseObjectReference = value as WwiseRtpcReference; }
		return;
	}
}
// WwiseObjectType AK.Wwise.RTPC::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t RTPC_get_WwiseObjectType_m1026A2AEAB4CC66051C8FC588FB993391D341E3D (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.GameParameter; } }
		return (int32_t)(((int32_t)13));
	}
}
// System.Void AK.Wwise.RTPC::SetValue(UnityEngine.GameObject,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RTPC_SetValue_m1C344467FDED1786C71D410DBFCD5D03DCCD9AD5 (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, float ___value1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (RTPC_SetValue_m1C344467FDED1786C71D410DBFCD5D03DCCD9AD5_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_001d;
		}
	}
	{
		// var result = AkSoundEngine.SetRTPCValue(Id, value, gameObject);
		uint32_t L_1 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		float L_2 = ___value1;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_3 = ___gameObject0;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		int32_t L_4 = AkSoundEngine_SetRTPCValue_m18561150273DA0C176DADCBDF426E70613AF356D(L_1, L_2, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		// Verify(result);
		int32_t L_5 = V_0;
		BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D(__this, L_5, /*hidden argument*/NULL);
	}

IL_001d:
	{
		// }
		return;
	}
}
// System.Single AK.Wwise.RTPC::GetValue(UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float RTPC_GetValue_mE4BBCDABF8F856CBD6E2E74B223130DDF4AD6776 (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (RTPC_GetValue_mE4BBCDABF8F856CBD6E2E74B223130DDF4AD6776_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t G_B4_0 = 0;
	{
		// float value = 0;
		V_0 = (0.0f);
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0034;
		}
	}
	{
		// var akQueryValue = gameObject ? AkQueryRTPCValue.RTPCValue_GameObject : AkQueryRTPCValue.RTPCValue_Global;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_1 = ___gameObject0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_2 = Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534(L_1, /*hidden argument*/NULL);
		if (L_2)
		{
			goto IL_0019;
		}
	}
	{
		G_B4_0 = 1;
		goto IL_001a;
	}

IL_0019:
	{
		G_B4_0 = 2;
	}

IL_001a:
	{
		// var queryValue = (int)akQueryValue;
		V_1 = G_B4_0;
		// var result = AkSoundEngine.GetRTPCValue(Id, gameObject, AkSoundEngine.AK_INVALID_PLAYING_ID, out value, ref queryValue);
		uint32_t L_3 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_4 = ___gameObject0;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		int32_t L_5 = AkSoundEngine_GetRTPCValue_m09BD553FBF1926B313A4C7FEE2D23221449B03B3(L_3, L_4, 0, (float*)(&V_0), (int32_t*)(&V_1), /*hidden argument*/NULL);
		V_2 = L_5;
		// Verify(result);
		int32_t L_6 = V_2;
		BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D(__this, L_6, /*hidden argument*/NULL);
	}

IL_0034:
	{
		// return value;
		float L_7 = V_0;
		return L_7;
	}
}
// System.Void AK.Wwise.RTPC::SetGlobalValue(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RTPC_SetGlobalValue_mE95A5B940C8101349FA64E225E3D08233871C505 (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, float ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (RTPC_SetGlobalValue_mE95A5B940C8101349FA64E225E3D08233871C505_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_001c;
		}
	}
	{
		// var result = AkSoundEngine.SetRTPCValue(Id, value);
		uint32_t L_1 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		float L_2 = ___value0;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		int32_t L_3 = AkSoundEngine_SetRTPCValue_mFD00540F3921139DB4467CAA06A2DAA43DD5EB19(L_1, L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		// Verify(result);
		int32_t L_4 = V_0;
		BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D(__this, L_4, /*hidden argument*/NULL);
	}

IL_001c:
	{
		// }
		return;
	}
}
// System.Single AK.Wwise.RTPC::GetGlobalValue()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float RTPC_GetGlobalValue_m0D5A676E5B7B5EA08AE6F3562C2DBF99490BCB29 (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, const RuntimeMethod* method)
{
	{
		// return GetValue(null);
		float L_0 = RTPC_GetValue_mE4BBCDABF8F856CBD6E2E74B223130DDF4AD6776(__this, (GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F *)NULL, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Void AK.Wwise.RTPC::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RTPC__ctor_m7ECE0016601182CE16F80569BBD0F6E1C206803A (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, const RuntimeMethod* method)
{
	{
		BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectReference AK.Wwise.State::get_ObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * State_get_ObjectReference_mCE1AE7DCBB93E0E1E7086A66F6227D079B29EBF6 (State_t33FE9B211AA324266CA50DC53343CA54B4A6A74C * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseObjectReference; }
		WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 * L_0 = __this->get_WwiseObjectReference_4();
		return L_0;
	}
}
// System.Void AK.Wwise.State::set_ObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void State_set_ObjectReference_mC2B636ABD6F3CAC90E48590BF03B908A66E7D435 (State_t33FE9B211AA324266CA50DC53343CA54B4A6A74C * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (State_set_ObjectReference_mC2B636ABD6F3CAC90E48590BF03B908A66E7D435_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseObjectReference = value as WwiseStateReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseObjectReference_4(((WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 *)IsInstClass((RuntimeObject*)L_0, WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511_il2cpp_TypeInfo_var)));
		// set { WwiseObjectReference = value as WwiseStateReference; }
		return;
	}
}
// WwiseObjectType AK.Wwise.State::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t State_get_WwiseObjectType_m9D728BF39FAC0C20CE9701AF35F60A09E2557822 (State_t33FE9B211AA324266CA50DC53343CA54B4A6A74C * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.State; } }
		return (int32_t)(8);
	}
}
// WwiseObjectType AK.Wwise.State::get_WwiseObjectGroupType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t State_get_WwiseObjectGroupType_m50AACD700B9C013D1AA346A001708955636BD467 (State_t33FE9B211AA324266CA50DC53343CA54B4A6A74C * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectGroupType { get { return WwiseObjectType.StateGroup; } }
		return (int32_t)(((int32_t)9));
	}
}
// System.Void AK.Wwise.State::SetValue()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void State_SetValue_m3277A24BDD3292A989E4C9E4DAC8232C97DC8102 (State_t33FE9B211AA324266CA50DC53343CA54B4A6A74C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (State_SetValue_m3277A24BDD3292A989E4C9E4DAC8232C97DC8102_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0021;
		}
	}
	{
		// var result = AkSoundEngine.SetState(GroupId, Id);
		uint32_t L_1 = BaseGroupType_get_GroupId_mF73642DEE955F78AF36A9DED227DFAD6E36B9DA6(__this, /*hidden argument*/NULL);
		uint32_t L_2 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		int32_t L_3 = AkSoundEngine_SetState_m27B10E6734080647D4ED57903BF9EA010F60D08C(L_1, L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		// Verify(result);
		int32_t L_4 = V_0;
		BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D(__this, L_4, /*hidden argument*/NULL);
	}

IL_0021:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.State::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void State__ctor_m949C6BA1B7BDCBFC995AF1AB412CA2F324C4B82A (State_t33FE9B211AA324266CA50DC53343CA54B4A6A74C * __this, const RuntimeMethod* method)
{
	{
		BaseGroupType__ctor_m507DE24A74927CD8D251293A8F86756EDA3A136C(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectReference AK.Wwise.Switch::get_ObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * Switch_get_ObjectReference_mDD523B2FFED3AC416F064D73C1FFA37253FD701E (Switch_t3C5E93F72DE4D390F7C5E8F4ECC7765EBFEA75D7 * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseObjectReference; }
		WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 * L_0 = __this->get_WwiseObjectReference_4();
		return L_0;
	}
}
// System.Void AK.Wwise.Switch::set_ObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Switch_set_ObjectReference_mC8D431846370386B7200FDB1A3B9B5306C3620B7 (Switch_t3C5E93F72DE4D390F7C5E8F4ECC7765EBFEA75D7 * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Switch_set_ObjectReference_mC8D431846370386B7200FDB1A3B9B5306C3620B7_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseObjectReference = value as WwiseSwitchReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseObjectReference_4(((WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 *)IsInstClass((RuntimeObject*)L_0, WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19_il2cpp_TypeInfo_var)));
		// set { WwiseObjectReference = value as WwiseSwitchReference; }
		return;
	}
}
// WwiseObjectType AK.Wwise.Switch::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Switch_get_WwiseObjectType_m044A8559FB1555D1ADDD797FDB59B05C82454A29 (Switch_t3C5E93F72DE4D390F7C5E8F4ECC7765EBFEA75D7 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.Switch; } }
		return (int32_t)(((int32_t)10));
	}
}
// WwiseObjectType AK.Wwise.Switch::get_WwiseObjectGroupType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Switch_get_WwiseObjectGroupType_mDF7D2CF3CEEDAD3A94CB2F6E7DCFB24090B8A2D4 (Switch_t3C5E93F72DE4D390F7C5E8F4ECC7765EBFEA75D7 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectGroupType { get { return WwiseObjectType.SwitchGroup; } }
		return (int32_t)(((int32_t)11));
	}
}
// System.Void AK.Wwise.Switch::SetValue(UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Switch_SetValue_m7B841B28FA764A67FE68B2195F6DE87FE8432F98 (Switch_t3C5E93F72DE4D390F7C5E8F4ECC7765EBFEA75D7 * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Switch_SetValue_m7B841B28FA764A67FE68B2195F6DE87FE8432F98_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_0022;
		}
	}
	{
		// var result = AkSoundEngine.SetSwitch(GroupId, Id, gameObject);
		uint32_t L_1 = BaseGroupType_get_GroupId_mF73642DEE955F78AF36A9DED227DFAD6E36B9DA6(__this, /*hidden argument*/NULL);
		uint32_t L_2 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_3 = ___gameObject0;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		int32_t L_4 = AkSoundEngine_SetSwitch_mB25E783656DD320341B7578E08A40F5EDD5046CA(L_1, L_2, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		// Verify(result);
		int32_t L_5 = V_0;
		BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D(__this, L_5, /*hidden argument*/NULL);
	}

IL_0022:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Switch::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Switch__ctor_mAF6277E27CA8D79605F59F2EDECD057D9ED43F95 (Switch_t3C5E93F72DE4D390F7C5E8F4ECC7765EBFEA75D7 * __this, const RuntimeMethod* method)
{
	{
		BaseGroupType__ctor_m507DE24A74927CD8D251293A8F86756EDA3A136C(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectReference AK.Wwise.Trigger::get_ObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * Trigger_get_ObjectReference_m099F7DC1244CD75BD253FDCB448545B4CC9426BD (Trigger_t5ACE3FCFFD1C9CB7459B8CF2F15734EB96B4300E * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseObjectReference; }
		WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE * L_0 = __this->get_WwiseObjectReference_2();
		return L_0;
	}
}
// System.Void AK.Wwise.Trigger::set_ObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Trigger_set_ObjectReference_m0932A4F9EA97A9749BBB02CACAAE63F5FDC45D00 (Trigger_t5ACE3FCFFD1C9CB7459B8CF2F15734EB96B4300E * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Trigger_set_ObjectReference_m0932A4F9EA97A9749BBB02CACAAE63F5FDC45D00_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseObjectReference = value as WwiseTriggerReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseObjectReference_2(((WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE *)IsInstClass((RuntimeObject*)L_0, WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE_il2cpp_TypeInfo_var)));
		// set { WwiseObjectReference = value as WwiseTriggerReference; }
		return;
	}
}
// WwiseObjectType AK.Wwise.Trigger::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Trigger_get_WwiseObjectType_m6ED44BAE58D27901E599A9FB983075E40FBCB77D (Trigger_t5ACE3FCFFD1C9CB7459B8CF2F15734EB96B4300E * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.Trigger; } }
		return (int32_t)(((int32_t)14));
	}
}
// System.Void AK.Wwise.Trigger::Post(UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Trigger_Post_mBDF91ECB8ADF7C97A038C5C8135384B4B91F1509 (Trigger_t5ACE3FCFFD1C9CB7459B8CF2F15734EB96B4300E * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Trigger_Post_mBDF91ECB8ADF7C97A038C5C8135384B4B91F1509_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		// if (IsValid())
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean AK.Wwise.BaseType::IsValid() */, __this);
		if (!L_0)
		{
			goto IL_001c;
		}
	}
	{
		// var result = AkSoundEngine.PostTrigger(Id, gameObject);
		uint32_t L_1 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_2 = ___gameObject0;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		int32_t L_3 = AkSoundEngine_PostTrigger_mAE35A465050B381130B8C1710F29A7C204600C0D(L_1, L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		// Verify(result);
		int32_t L_4 = V_0;
		BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D(__this, L_4, /*hidden argument*/NULL);
	}

IL_001c:
	{
		// }
		return;
	}
}
// System.Void AK.Wwise.Trigger::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Trigger__ctor_m19564FCDDDC38BAE2089D029B026CD3ED4EF04FD (Trigger_t5ACE3FCFFD1C9CB7459B8CF2F15734EB96B4300E * __this, const RuntimeMethod* method)
{
	{
		BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseAcousticTextureReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseAcousticTextureReference_get_WwiseObjectType_m716134B3DD2F472E324C7E7740A04E283BAE6DB1 (WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.AcousticTexture; } }
		return (int32_t)(((int32_t)15));
	}
}
// System.Void WwiseAcousticTextureReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseAcousticTextureReference__ctor_m5B9E4AC73171B3920B6A2C9C0D62203C47563A71 (WwiseAcousticTextureReference_tBA3319573FCEDF844765F55CAD5F377B5D09D805 * __this, const RuntimeMethod* method)
{
	{
		WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseAuxBusReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseAuxBusReference_get_WwiseObjectType_m2E317138A1BD0A755692D65C855EE8F044E3B03A (WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.AuxBus; } }
		return (int32_t)(1);
	}
}
// System.Void WwiseAuxBusReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseAuxBusReference__ctor_mFFC2F25745E933296B5D235B3AD2348BB370DCCD (WwiseAuxBusReference_tC60EBD5AAA953D7B8078FBDEF4F656FA086BBAE3 * __this, const RuntimeMethod* method)
{
	{
		WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseBankReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseBankReference_get_WwiseObjectType_m78D831CD105A551B41750B1614165DCC4D917BE8 (WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.Soundbank; } }
		return (int32_t)(7);
	}
}
// System.Void WwiseBankReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseBankReference__ctor_m8030F92B10AC8E6AF63B133CEB01D46DA8CAF299 (WwiseBankReference_t5FEEB11E32AD5A69343A4D3A8660FB597A9B7ED6 * __this, const RuntimeMethod* method)
{
	{
		WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseEventReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseEventReference_get_WwiseObjectType_mA93850B1B0F59992FEAAA52AF9BA28918114AA68 (WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.Event; } }
		return (int32_t)(3);
	}
}
// System.Void WwiseEventReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseEventReference__ctor_m928BC09314770B0343989D9497F56ABCC5709DD0 (WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C * __this, const RuntimeMethod* method)
{
	{
		WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.String WwiseGroupValueObjectReference::get_DisplayName()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* WwiseGroupValueObjectReference_get_DisplayName_m1BDB9F6B4F9C5BB82C156DB4AA50F088B15D4D94 (WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (WwiseGroupValueObjectReference_get_DisplayName_m1BDB9F6B4F9C5BB82C156DB4AA50F088B15D4D94_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * V_0 = NULL;
	{
		// var groupReference = GroupObjectReference;
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = VirtFuncInvoker0< WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * >::Invoke(6 /* WwiseObjectReference WwiseGroupValueObjectReference::get_GroupObjectReference() */, __this);
		V_0 = L_0;
		// if (!groupReference)
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_1 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_2 = Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534(L_1, /*hidden argument*/NULL);
		if (L_2)
		{
			goto IL_0016;
		}
	}
	{
		// return ObjectName;
		String_t* L_3 = WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821_inline(__this, /*hidden argument*/NULL);
		return L_3;
	}

IL_0016:
	{
		// return groupReference.ObjectName + " / " + ObjectName;
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_4 = V_0;
		NullCheck(L_4);
		String_t* L_5 = WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821_inline(L_4, /*hidden argument*/NULL);
		String_t* L_6 = WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821_inline(__this, /*hidden argument*/NULL);
		String_t* L_7 = String_Concat_mF4626905368D6558695A823466A1AF65EADB9923(L_5, _stringLiteral0D0C4DDD7CAB8253149568AACCC1F72AA7F9ACF8, L_6, /*hidden argument*/NULL);
		return L_7;
	}
}
// System.Void WwiseGroupValueObjectReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseGroupValueObjectReference__ctor_mEF381CCC534B4D2B825DA84F6A69B8C93FBC04AE (WwiseGroupValueObjectReference_tEFE9B7F2387789231007DE840CCC083E44DF236E * __this, const RuntimeMethod* method)
{
	{
		WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Guid WwiseObjectReference::get_Guid()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Guid_t  WwiseObjectReference_get_Guid_mA730AB56F442D112796810ECFB314FD39CB33C14 (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (WwiseObjectReference_get_Guid_mA730AB56F442D112796810ECFB314FD39CB33C14_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// get { return string.IsNullOrEmpty(guid) ? System.Guid.Empty : new System.Guid(guid); }
		String_t* L_0 = __this->get_guid_6();
		bool L_1 = String_IsNullOrEmpty_m06A85A206AC2106D1982826C5665B9BD35324229(L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_0019;
		}
	}
	{
		String_t* L_2 = __this->get_guid_6();
		Guid_t  L_3;
		memset((&L_3), 0, sizeof(L_3));
		Guid__ctor_mC668142577A40A77D13B78AADDEFFFC2E2705079((&L_3), L_2, /*hidden argument*/NULL);
		return L_3;
	}

IL_0019:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Guid_t_il2cpp_TypeInfo_var);
		Guid_t  L_4 = ((Guid_t_StaticFields*)il2cpp_codegen_static_fields_for(Guid_t_il2cpp_TypeInfo_var))->get_Empty_0();
		return L_4;
	}
}
// System.String WwiseObjectReference::get_ObjectName()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821 (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method)
{
	{
		// public string ObjectName { get { return objectName; } }
		String_t* L_0 = __this->get_objectName_4();
		return L_0;
	}
}
// System.String WwiseObjectReference::get_DisplayName()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* WwiseObjectReference_get_DisplayName_mC00CBA33CDCCA0F867B40B7A9CD893ECE942B989 (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method)
{
	{
		// public virtual string DisplayName { get { return ObjectName; } }
		String_t* L_0 = WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821_inline(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.UInt32 WwiseObjectReference::get_Id()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t WwiseObjectReference_get_Id_m6AFC577D7CB88EC618408101C2415016520205FB (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method)
{
	{
		// public uint Id { get { return id; } }
		uint32_t L_0 = __this->get_id_5();
		return L_0;
	}
}
// System.Void WwiseObjectReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// private string objectName = string.Empty;
		String_t* L_0 = ((String_t_StaticFields*)il2cpp_codegen_static_fields_for(String_t_il2cpp_TypeInfo_var))->get_Empty_5();
		__this->set_objectName_4(L_0);
		// private string guid = string.Empty;
		String_t* L_1 = ((String_t_StaticFields*)il2cpp_codegen_static_fields_for(String_t_il2cpp_TypeInfo_var))->get_Empty_5();
		__this->set_guid_6(L_1);
		ScriptableObject__ctor_m6E2B3821A4A361556FC12E9B1C71E1D5DC002C5B(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseRtpcReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseRtpcReference_get_WwiseObjectType_mF09FD3F3437F6BDF7946F881F4BFC3F7156B42DA (WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.GameParameter; } }
		return (int32_t)(((int32_t)13));
	}
}
// System.Void WwiseRtpcReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseRtpcReference__ctor_m5C789BAA9F4715C322939B05AFA9E4BBBAAFEFB8 (WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E * __this, const RuntimeMethod* method)
{
	{
		WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseStateGroupReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseStateGroupReference_get_WwiseObjectType_m018FC3A2B2D1D7C2D148D0A0AF93CAD679B7011D (WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.StateGroup; } }
		return (int32_t)(((int32_t)9));
	}
}
// System.Void WwiseStateGroupReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseStateGroupReference__ctor_m63175271C679CB6F337D70B004EA46A012755521 (WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6 * __this, const RuntimeMethod* method)
{
	{
		WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseStateReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseStateReference_get_WwiseObjectType_m45E0A2965230CF2ADD893304673DD66CBF163B7F (WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.State; } }
		return (int32_t)(8);
	}
}
// WwiseObjectReference WwiseStateReference::get_GroupObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * WwiseStateReference_get_GroupObjectReference_mB6158977D748B4350E829514508FFAB0CEAB940F (WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseStateGroupReference; }
		WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6 * L_0 = __this->get_WwiseStateGroupReference_7();
		return L_0;
	}
}
// System.Void WwiseStateReference::set_GroupObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseStateReference_set_GroupObjectReference_mB38F503F67AC85A4195656D7B265180025F85EF1 (WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (WwiseStateReference_set_GroupObjectReference_mB38F503F67AC85A4195656D7B265180025F85EF1_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseStateGroupReference = value as WwiseStateGroupReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseStateGroupReference_7(((WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6 *)IsInstClass((RuntimeObject*)L_0, WwiseStateGroupReference_t2BCEB67640580FAC00F2D7F8BAB37D23F87B23F6_il2cpp_TypeInfo_var)));
		// set { WwiseStateGroupReference = value as WwiseStateGroupReference; }
		return;
	}
}
// WwiseObjectType WwiseStateReference::get_GroupWwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseStateReference_get_GroupWwiseObjectType_mCF4FD690441FDEE35582955A705C2633B4115DFB (WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType GroupWwiseObjectType { get { return WwiseObjectType.StateGroup; } }
		return (int32_t)(((int32_t)9));
	}
}
// System.Void WwiseStateReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseStateReference__ctor_mB88C6F4F4C5A033EDF1FF59D9C648D9A67C6B644 (WwiseStateReference_tE36CA2DD3CD81ECD73B3F09F5F4D5413E012B511 * __this, const RuntimeMethod* method)
{
	{
		WwiseGroupValueObjectReference__ctor_mEF381CCC534B4D2B825DA84F6A69B8C93FBC04AE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseSwitchGroupReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseSwitchGroupReference_get_WwiseObjectType_mD8EF023BC5DAAFC751F778866B7D05523FF2FDFD (WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.SwitchGroup; } }
		return (int32_t)(((int32_t)11));
	}
}
// System.Void WwiseSwitchGroupReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseSwitchGroupReference__ctor_m74ECCDD74B60F6D83397D571E9AF6281323E3CED (WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6 * __this, const RuntimeMethod* method)
{
	{
		WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseSwitchReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseSwitchReference_get_WwiseObjectType_m2CC649B9471D6354FFB655B2BF7791082F5E49DE (WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.Switch; } }
		return (int32_t)(((int32_t)10));
	}
}
// WwiseObjectReference WwiseSwitchReference::get_GroupObjectReference()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * WwiseSwitchReference_get_GroupObjectReference_mCC3D481CD4250F250C7343E6A3C8106BE5078EB5 (WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 * __this, const RuntimeMethod* method)
{
	{
		// get { return WwiseSwitchGroupReference; }
		WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6 * L_0 = __this->get_WwiseSwitchGroupReference_7();
		return L_0;
	}
}
// System.Void WwiseSwitchReference::set_GroupObjectReference(WwiseObjectReference)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseSwitchReference_set_GroupObjectReference_m28DA84F22ACE63362B2C792048724EA9B957A497 (WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 * __this, WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (WwiseSwitchReference_set_GroupObjectReference_m28DA84F22ACE63362B2C792048724EA9B957A497_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// set { WwiseSwitchGroupReference = value as WwiseSwitchGroupReference; }
		WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * L_0 = ___value0;
		__this->set_WwiseSwitchGroupReference_7(((WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6 *)IsInstClass((RuntimeObject*)L_0, WwiseSwitchGroupReference_t75001E49906A0B06437EBFF136399ABC3FBACAD6_il2cpp_TypeInfo_var)));
		// set { WwiseSwitchGroupReference = value as WwiseSwitchGroupReference; }
		return;
	}
}
// WwiseObjectType WwiseSwitchReference::get_GroupWwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseSwitchReference_get_GroupWwiseObjectType_mE3E06B601281BB9A2E0BE31091ED9CF3884CA625 (WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType GroupWwiseObjectType { get { return WwiseObjectType.SwitchGroup; } }
		return (int32_t)(((int32_t)11));
	}
}
// System.Void WwiseSwitchReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseSwitchReference__ctor_m363E747E0D06A93679A9795A33E56D5B5FA20715 (WwiseSwitchReference_t994AB63E99B3E17586B5E88E628AD2E043BC8C19 * __this, const RuntimeMethod* method)
{
	{
		WwiseGroupValueObjectReference__ctor_mEF381CCC534B4D2B825DA84F6A69B8C93FBC04AE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// WwiseObjectType WwiseTriggerReference::get_WwiseObjectType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t WwiseTriggerReference_get_WwiseObjectType_mE0E39630418D7D38AF162A3D39BABD774DC6ACA7 (WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE * __this, const RuntimeMethod* method)
{
	{
		// public override WwiseObjectType WwiseObjectType { get { return WwiseObjectType.Trigger; } }
		return (int32_t)(((int32_t)14));
	}
}
// System.Void WwiseTriggerReference::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WwiseTriggerReference__ctor_mD54ED33DA73C43F928A7FDBB1858D54696FD42D5 (WwiseTriggerReference_t475FCA203BF84495791555EEA8E6FBA64546B7DE * __this, const RuntimeMethod* method)
{
	{
		WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR uint32_t WwiseObjectReference_get_Id_m6AFC577D7CB88EC618408101C2415016520205FB_inline (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method)
{
	{
		// public uint Id { get { return id; } }
		uint32_t L_0 = __this->get_id_5();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR String_t* WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821_inline (WwiseObjectReference_tEB2AFA6D1374F358653D2B0CFBB91BBFD554D4C6 * __this, const RuntimeMethod* method)
{
	{
		// public string ObjectName { get { return objectName; } }
		String_t* L_0 = __this->get_objectName_4();
		return L_0;
	}
}
