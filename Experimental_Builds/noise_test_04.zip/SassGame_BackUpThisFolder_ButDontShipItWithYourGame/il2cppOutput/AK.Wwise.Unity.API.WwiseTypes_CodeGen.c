﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 WwiseObjectType WwiseAcousticTextureReference::get_WwiseObjectType()
extern void WwiseAcousticTextureReference_get_WwiseObjectType_m716134B3DD2F472E324C7E7740A04E283BAE6DB1 (void);
// 0x00000002 System.Void WwiseAcousticTextureReference::.ctor()
extern void WwiseAcousticTextureReference__ctor_m5B9E4AC73171B3920B6A2C9C0D62203C47563A71 (void);
// 0x00000003 WwiseObjectType WwiseAuxBusReference::get_WwiseObjectType()
extern void WwiseAuxBusReference_get_WwiseObjectType_m2E317138A1BD0A755692D65C855EE8F044E3B03A (void);
// 0x00000004 System.Void WwiseAuxBusReference::.ctor()
extern void WwiseAuxBusReference__ctor_mFFC2F25745E933296B5D235B3AD2348BB370DCCD (void);
// 0x00000005 WwiseObjectType WwiseBankReference::get_WwiseObjectType()
extern void WwiseBankReference_get_WwiseObjectType_m78D831CD105A551B41750B1614165DCC4D917BE8 (void);
// 0x00000006 System.Void WwiseBankReference::.ctor()
extern void WwiseBankReference__ctor_m8030F92B10AC8E6AF63B133CEB01D46DA8CAF299 (void);
// 0x00000007 WwiseObjectType WwiseEventReference::get_WwiseObjectType()
extern void WwiseEventReference_get_WwiseObjectType_mA93850B1B0F59992FEAAA52AF9BA28918114AA68 (void);
// 0x00000008 System.Void WwiseEventReference::.ctor()
extern void WwiseEventReference__ctor_m928BC09314770B0343989D9497F56ABCC5709DD0 (void);
// 0x00000009 System.Guid WwiseObjectReference::get_Guid()
extern void WwiseObjectReference_get_Guid_mA730AB56F442D112796810ECFB314FD39CB33C14 (void);
// 0x0000000A System.String WwiseObjectReference::get_ObjectName()
extern void WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821 (void);
// 0x0000000B System.String WwiseObjectReference::get_DisplayName()
extern void WwiseObjectReference_get_DisplayName_mC00CBA33CDCCA0F867B40B7A9CD893ECE942B989 (void);
// 0x0000000C System.UInt32 WwiseObjectReference::get_Id()
extern void WwiseObjectReference_get_Id_m6AFC577D7CB88EC618408101C2415016520205FB (void);
// 0x0000000D WwiseObjectType WwiseObjectReference::get_WwiseObjectType()
// 0x0000000E System.Void WwiseObjectReference::.ctor()
extern void WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F (void);
// 0x0000000F WwiseObjectReference WwiseGroupValueObjectReference::get_GroupObjectReference()
// 0x00000010 System.Void WwiseGroupValueObjectReference::set_GroupObjectReference(WwiseObjectReference)
// 0x00000011 WwiseObjectType WwiseGroupValueObjectReference::get_GroupWwiseObjectType()
// 0x00000012 System.String WwiseGroupValueObjectReference::get_DisplayName()
extern void WwiseGroupValueObjectReference_get_DisplayName_m1BDB9F6B4F9C5BB82C156DB4AA50F088B15D4D94 (void);
// 0x00000013 System.Void WwiseGroupValueObjectReference::.ctor()
extern void WwiseGroupValueObjectReference__ctor_mEF381CCC534B4D2B825DA84F6A69B8C93FBC04AE (void);
// 0x00000014 WwiseObjectType WwiseRtpcReference::get_WwiseObjectType()
extern void WwiseRtpcReference_get_WwiseObjectType_mF09FD3F3437F6BDF7946F881F4BFC3F7156B42DA (void);
// 0x00000015 System.Void WwiseRtpcReference::.ctor()
extern void WwiseRtpcReference__ctor_m5C789BAA9F4715C322939B05AFA9E4BBBAAFEFB8 (void);
// 0x00000016 WwiseObjectType WwiseStateGroupReference::get_WwiseObjectType()
extern void WwiseStateGroupReference_get_WwiseObjectType_m018FC3A2B2D1D7C2D148D0A0AF93CAD679B7011D (void);
// 0x00000017 System.Void WwiseStateGroupReference::.ctor()
extern void WwiseStateGroupReference__ctor_m63175271C679CB6F337D70B004EA46A012755521 (void);
// 0x00000018 WwiseObjectType WwiseStateReference::get_WwiseObjectType()
extern void WwiseStateReference_get_WwiseObjectType_m45E0A2965230CF2ADD893304673DD66CBF163B7F (void);
// 0x00000019 WwiseObjectReference WwiseStateReference::get_GroupObjectReference()
extern void WwiseStateReference_get_GroupObjectReference_mB6158977D748B4350E829514508FFAB0CEAB940F (void);
// 0x0000001A System.Void WwiseStateReference::set_GroupObjectReference(WwiseObjectReference)
extern void WwiseStateReference_set_GroupObjectReference_mB38F503F67AC85A4195656D7B265180025F85EF1 (void);
// 0x0000001B WwiseObjectType WwiseStateReference::get_GroupWwiseObjectType()
extern void WwiseStateReference_get_GroupWwiseObjectType_mCF4FD690441FDEE35582955A705C2633B4115DFB (void);
// 0x0000001C System.Void WwiseStateReference::.ctor()
extern void WwiseStateReference__ctor_mB88C6F4F4C5A033EDF1FF59D9C648D9A67C6B644 (void);
// 0x0000001D WwiseObjectType WwiseSwitchGroupReference::get_WwiseObjectType()
extern void WwiseSwitchGroupReference_get_WwiseObjectType_mD8EF023BC5DAAFC751F778866B7D05523FF2FDFD (void);
// 0x0000001E System.Void WwiseSwitchGroupReference::.ctor()
extern void WwiseSwitchGroupReference__ctor_m74ECCDD74B60F6D83397D571E9AF6281323E3CED (void);
// 0x0000001F WwiseObjectType WwiseSwitchReference::get_WwiseObjectType()
extern void WwiseSwitchReference_get_WwiseObjectType_m2CC649B9471D6354FFB655B2BF7791082F5E49DE (void);
// 0x00000020 WwiseObjectReference WwiseSwitchReference::get_GroupObjectReference()
extern void WwiseSwitchReference_get_GroupObjectReference_mCC3D481CD4250F250C7343E6A3C8106BE5078EB5 (void);
// 0x00000021 System.Void WwiseSwitchReference::set_GroupObjectReference(WwiseObjectReference)
extern void WwiseSwitchReference_set_GroupObjectReference_m28DA84F22ACE63362B2C792048724EA9B957A497 (void);
// 0x00000022 WwiseObjectType WwiseSwitchReference::get_GroupWwiseObjectType()
extern void WwiseSwitchReference_get_GroupWwiseObjectType_mE3E06B601281BB9A2E0BE31091ED9CF3884CA625 (void);
// 0x00000023 System.Void WwiseSwitchReference::.ctor()
extern void WwiseSwitchReference__ctor_m363E747E0D06A93679A9795A33E56D5B5FA20715 (void);
// 0x00000024 WwiseObjectType WwiseTriggerReference::get_WwiseObjectType()
extern void WwiseTriggerReference_get_WwiseObjectType_mE0E39630418D7D38AF162A3D39BABD774DC6ACA7 (void);
// 0x00000025 System.Void WwiseTriggerReference::.ctor()
extern void WwiseTriggerReference__ctor_mD54ED33DA73C43F928A7FDBB1858D54696FD42D5 (void);
// 0x00000026 WwiseObjectReference AK.Wwise.AcousticTexture::get_ObjectReference()
extern void AcousticTexture_get_ObjectReference_mF40AF0DC967818D3827FBE267E243F4D116D8821 (void);
// 0x00000027 System.Void AK.Wwise.AcousticTexture::set_ObjectReference(WwiseObjectReference)
extern void AcousticTexture_set_ObjectReference_mBDAB9D5BA879D24BF1C7F543F76CEFD442E58A9D (void);
// 0x00000028 WwiseObjectType AK.Wwise.AcousticTexture::get_WwiseObjectType()
extern void AcousticTexture_get_WwiseObjectType_mF67FBA56C692AA7454C4140AD39D066B38B33346 (void);
// 0x00000029 System.Void AK.Wwise.AcousticTexture::.ctor()
extern void AcousticTexture__ctor_m0E2DB175634A4592BE9BABD27E40EDF0FBC5EBDE (void);
// 0x0000002A WwiseObjectReference AK.Wwise.AuxBus::get_ObjectReference()
extern void AuxBus_get_ObjectReference_mEB909C28D1C9B36CB5DB1792985C94EC4837A6D4 (void);
// 0x0000002B System.Void AK.Wwise.AuxBus::set_ObjectReference(WwiseObjectReference)
extern void AuxBus_set_ObjectReference_m130FCE92CFF4D543369BC5154D8EAFBCF96FDA9E (void);
// 0x0000002C WwiseObjectType AK.Wwise.AuxBus::get_WwiseObjectType()
extern void AuxBus_get_WwiseObjectType_m843FE87544B19EAD2A090F8099D2104C4433AA16 (void);
// 0x0000002D System.Void AK.Wwise.AuxBus::.ctor()
extern void AuxBus__ctor_mDA756A46983C38D87850ABF7BF5C47BD4A4E9731 (void);
// 0x0000002E WwiseObjectType AK.Wwise.Bank::get_WwiseObjectType()
extern void Bank_get_WwiseObjectType_m74AF277A309F5A7034F3325643943B14B6E3D483 (void);
// 0x0000002F WwiseObjectReference AK.Wwise.Bank::get_ObjectReference()
extern void Bank_get_ObjectReference_m5C061EAE560173E72FB4B9595A4A3449CA68F282 (void);
// 0x00000030 System.Void AK.Wwise.Bank::set_ObjectReference(WwiseObjectReference)
extern void Bank_set_ObjectReference_m70806BA0660E74626D2F04575930B5A5B9B609E7 (void);
// 0x00000031 System.Void AK.Wwise.Bank::Load(System.Boolean,System.Boolean)
extern void Bank_Load_mE46124DE4BEB7444BFAB5D030E483D07E749732D (void);
// 0x00000032 System.Void AK.Wwise.Bank::LoadAsync(AkCallbackManager_BankCallback)
extern void Bank_LoadAsync_mD0EDAB56C81E98240631CCE3AFA5175F56A8C79D (void);
// 0x00000033 System.Void AK.Wwise.Bank::Unload()
extern void Bank_Unload_m0E6337A3DE4E818A065D60456BA28FE66959CAFD (void);
// 0x00000034 System.Void AK.Wwise.Bank::.ctor()
extern void Bank__ctor_m02ED1634B3F356354DF9780F4FD0D89BC560D2A1 (void);
// 0x00000035 WwiseObjectReference AK.Wwise.BaseGroupType::get_GroupWwiseObjectReference()
extern void BaseGroupType_get_GroupWwiseObjectReference_mC00EC611D1AB6A833A3389928F58AB828DEB509E (void);
// 0x00000036 WwiseObjectType AK.Wwise.BaseGroupType::get_WwiseObjectGroupType()
// 0x00000037 System.UInt32 AK.Wwise.BaseGroupType::get_GroupId()
extern void BaseGroupType_get_GroupId_mF73642DEE955F78AF36A9DED227DFAD6E36B9DA6 (void);
// 0x00000038 System.Boolean AK.Wwise.BaseGroupType::IsValid()
extern void BaseGroupType_IsValid_mADCBE3C3E7B68B2D97014E1A84B2526BBE0AEDDB (void);
// 0x00000039 System.Int32 AK.Wwise.BaseGroupType::get_groupID()
extern void BaseGroupType_get_groupID_mAA3C98D2E4BE7F4DCA97AC0B84E467F4527F187F (void);
// 0x0000003A System.Byte[] AK.Wwise.BaseGroupType::get_groupGuid()
extern void BaseGroupType_get_groupGuid_m6B0D66D9318433251D42610956CFB90B05B7EF8B (void);
// 0x0000003B System.Void AK.Wwise.BaseGroupType::.ctor()
extern void BaseGroupType__ctor_m507DE24A74927CD8D251293A8F86756EDA3A136C (void);
// 0x0000003C WwiseObjectReference AK.Wwise.BaseType::get_ObjectReference()
// 0x0000003D System.Void AK.Wwise.BaseType::set_ObjectReference(WwiseObjectReference)
// 0x0000003E WwiseObjectType AK.Wwise.BaseType::get_WwiseObjectType()
// 0x0000003F System.String AK.Wwise.BaseType::get_Name()
extern void BaseType_get_Name_mDFFF2E7872296A918CB207A3D4F0141A82A57651 (void);
// 0x00000040 System.UInt32 AK.Wwise.BaseType::get_Id()
extern void BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A (void);
// 0x00000041 System.UInt32 AK.Wwise.BaseType::get_InvalidId()
extern void BaseType_get_InvalidId_mC09A7B7CB1FDDF5F0F341E5F23D7CA7849172D26 (void);
// 0x00000042 System.Boolean AK.Wwise.BaseType::IsValid()
extern void BaseType_IsValid_mFF810061EE89CBE4C8E823B9DD12D868E95F90F5 (void);
// 0x00000043 System.Boolean AK.Wwise.BaseType::Validate()
extern void BaseType_Validate_mCF58D3BA9A28AA4DB9F4C2BB11728A222730C109 (void);
// 0x00000044 System.Void AK.Wwise.BaseType::Verify(AKRESULT)
extern void BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D (void);
// 0x00000045 System.String AK.Wwise.BaseType::ToString()
extern void BaseType_ToString_mAAFCAE5E25C7899DD5114DD7D778A6D1E5D4CF2C (void);
// 0x00000046 System.Int32 AK.Wwise.BaseType::get_ID()
extern void BaseType_get_ID_mD6C019E541BADA7F08CA0AB73BF51F665C0F88EE (void);
// 0x00000047 System.Byte[] AK.Wwise.BaseType::get_valueGuid()
extern void BaseType_get_valueGuid_mBCE9BC6DCBA50287E5EAEFD7EC058BFF7D0EE944 (void);
// 0x00000048 System.Void AK.Wwise.BaseType::.ctor()
extern void BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898 (void);
// 0x00000049 System.Void AK.Wwise.CallbackFlags::.ctor()
extern void CallbackFlags__ctor_m601552170E49E5E73BE6EFB37CDAC4835C8B79A5 (void);
// 0x0000004A System.UInt32 AK.Wwise.Event::get_PlayingId()
extern void Event_get_PlayingId_m45A26FC96EBD32601B9EC4580DD5222142A98178 (void);
// 0x0000004B WwiseObjectReference AK.Wwise.Event::get_ObjectReference()
extern void Event_get_ObjectReference_m7317DF42BCCC275C6C191AE001087498D4065FE1 (void);
// 0x0000004C System.Void AK.Wwise.Event::set_ObjectReference(WwiseObjectReference)
extern void Event_set_ObjectReference_m1A659F392D4DA6CB6BF285D8FC6256BC40A48C7D (void);
// 0x0000004D WwiseObjectType AK.Wwise.Event::get_WwiseObjectType()
extern void Event_get_WwiseObjectType_m5E0F8AC9167575B4FCEAE4773607C5F37D2C0EF0 (void);
// 0x0000004E System.Void AK.Wwise.Event::VerifyPlayingID(System.UInt32)
extern void Event_VerifyPlayingID_mF06416D9AED9C4251F6AA39D2FBCA71274DA926B (void);
// 0x0000004F System.UInt32 AK.Wwise.Event::Post(UnityEngine.GameObject)
extern void Event_Post_mB44E5C0A82FA36EDC65070D3024E066EE4D21F7A (void);
// 0x00000050 System.UInt32 AK.Wwise.Event::Post(UnityEngine.GameObject,AK.Wwise.CallbackFlags,AkCallbackManager_EventCallback,System.Object)
extern void Event_Post_m7E549AC780ECAC443484AC66E4201AC85AC34938 (void);
// 0x00000051 System.UInt32 AK.Wwise.Event::Post(UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void Event_Post_m975A00B31848012ACE9114D3FDB25CA0E630601D (void);
// 0x00000052 System.Void AK.Wwise.Event::Stop(UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
extern void Event_Stop_mF058FF1C69C98C1C87C1B2F517DBDBEAAE85D943 (void);
// 0x00000053 System.Void AK.Wwise.Event::ExecuteAction(UnityEngine.GameObject,AkActionOnEventType,System.Int32,AkCurveInterpolation)
extern void Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE (void);
// 0x00000054 System.Void AK.Wwise.Event::PostMIDI(UnityEngine.GameObject,AkMIDIPostArray)
extern void Event_PostMIDI_m982B73165A912E06894938827527969DCC2F0D3D (void);
// 0x00000055 System.Void AK.Wwise.Event::PostMIDI(UnityEngine.GameObject,AkMIDIPostArray,System.Int32)
extern void Event_PostMIDI_m3AECB7750EF014AE8C0D51AC4E779FA731EA43F4 (void);
// 0x00000056 System.Void AK.Wwise.Event::StopMIDI(UnityEngine.GameObject)
extern void Event_StopMIDI_m134DB6480821D066829993FC9AE0089183A85B25 (void);
// 0x00000057 System.Void AK.Wwise.Event::StopMIDI()
extern void Event_StopMIDI_m3EF14DD7C5CDA754301D41F35138329678A3E806 (void);
// 0x00000058 System.Void AK.Wwise.Event::.ctor()
extern void Event__ctor_mB99941177C1FF4FE4FDDD4185CB0C25681F4815D (void);
// 0x00000059 WwiseObjectReference AK.Wwise.RTPC::get_ObjectReference()
extern void RTPC_get_ObjectReference_m445052D3FBE9D3166A82FD97A5E0145C721A5B50 (void);
// 0x0000005A System.Void AK.Wwise.RTPC::set_ObjectReference(WwiseObjectReference)
extern void RTPC_set_ObjectReference_mA15859BEF88F307DC76FCC01EB1EA597E60FC557 (void);
// 0x0000005B WwiseObjectType AK.Wwise.RTPC::get_WwiseObjectType()
extern void RTPC_get_WwiseObjectType_m1026A2AEAB4CC66051C8FC588FB993391D341E3D (void);
// 0x0000005C System.Void AK.Wwise.RTPC::SetValue(UnityEngine.GameObject,System.Single)
extern void RTPC_SetValue_m1C344467FDED1786C71D410DBFCD5D03DCCD9AD5 (void);
// 0x0000005D System.Single AK.Wwise.RTPC::GetValue(UnityEngine.GameObject)
extern void RTPC_GetValue_mE4BBCDABF8F856CBD6E2E74B223130DDF4AD6776 (void);
// 0x0000005E System.Void AK.Wwise.RTPC::SetGlobalValue(System.Single)
extern void RTPC_SetGlobalValue_mE95A5B940C8101349FA64E225E3D08233871C505 (void);
// 0x0000005F System.Single AK.Wwise.RTPC::GetGlobalValue()
extern void RTPC_GetGlobalValue_m0D5A676E5B7B5EA08AE6F3562C2DBF99490BCB29 (void);
// 0x00000060 System.Void AK.Wwise.RTPC::.ctor()
extern void RTPC__ctor_m7ECE0016601182CE16F80569BBD0F6E1C206803A (void);
// 0x00000061 WwiseObjectReference AK.Wwise.State::get_ObjectReference()
extern void State_get_ObjectReference_mCE1AE7DCBB93E0E1E7086A66F6227D079B29EBF6 (void);
// 0x00000062 System.Void AK.Wwise.State::set_ObjectReference(WwiseObjectReference)
extern void State_set_ObjectReference_mC2B636ABD6F3CAC90E48590BF03B908A66E7D435 (void);
// 0x00000063 WwiseObjectType AK.Wwise.State::get_WwiseObjectType()
extern void State_get_WwiseObjectType_m9D728BF39FAC0C20CE9701AF35F60A09E2557822 (void);
// 0x00000064 WwiseObjectType AK.Wwise.State::get_WwiseObjectGroupType()
extern void State_get_WwiseObjectGroupType_m50AACD700B9C013D1AA346A001708955636BD467 (void);
// 0x00000065 System.Void AK.Wwise.State::SetValue()
extern void State_SetValue_m3277A24BDD3292A989E4C9E4DAC8232C97DC8102 (void);
// 0x00000066 System.Void AK.Wwise.State::.ctor()
extern void State__ctor_m949C6BA1B7BDCBFC995AF1AB412CA2F324C4B82A (void);
// 0x00000067 WwiseObjectReference AK.Wwise.Switch::get_ObjectReference()
extern void Switch_get_ObjectReference_mDD523B2FFED3AC416F064D73C1FFA37253FD701E (void);
// 0x00000068 System.Void AK.Wwise.Switch::set_ObjectReference(WwiseObjectReference)
extern void Switch_set_ObjectReference_mC8D431846370386B7200FDB1A3B9B5306C3620B7 (void);
// 0x00000069 WwiseObjectType AK.Wwise.Switch::get_WwiseObjectType()
extern void Switch_get_WwiseObjectType_m044A8559FB1555D1ADDD797FDB59B05C82454A29 (void);
// 0x0000006A WwiseObjectType AK.Wwise.Switch::get_WwiseObjectGroupType()
extern void Switch_get_WwiseObjectGroupType_mDF7D2CF3CEEDAD3A94CB2F6E7DCFB24090B8A2D4 (void);
// 0x0000006B System.Void AK.Wwise.Switch::SetValue(UnityEngine.GameObject)
extern void Switch_SetValue_m7B841B28FA764A67FE68B2195F6DE87FE8432F98 (void);
// 0x0000006C System.Void AK.Wwise.Switch::.ctor()
extern void Switch__ctor_mAF6277E27CA8D79605F59F2EDECD057D9ED43F95 (void);
// 0x0000006D WwiseObjectReference AK.Wwise.Trigger::get_ObjectReference()
extern void Trigger_get_ObjectReference_m099F7DC1244CD75BD253FDCB448545B4CC9426BD (void);
// 0x0000006E System.Void AK.Wwise.Trigger::set_ObjectReference(WwiseObjectReference)
extern void Trigger_set_ObjectReference_m0932A4F9EA97A9749BBB02CACAAE63F5FDC45D00 (void);
// 0x0000006F WwiseObjectType AK.Wwise.Trigger::get_WwiseObjectType()
extern void Trigger_get_WwiseObjectType_m6ED44BAE58D27901E599A9FB983075E40FBCB77D (void);
// 0x00000070 System.Void AK.Wwise.Trigger::Post(UnityEngine.GameObject)
extern void Trigger_Post_mBDF91ECB8ADF7C97A038C5C8135384B4B91F1509 (void);
// 0x00000071 System.Void AK.Wwise.Trigger::.ctor()
extern void Trigger__ctor_m19564FCDDDC38BAE2089D029B026CD3ED4EF04FD (void);
static Il2CppMethodPointer s_methodPointers[113] = 
{
	WwiseAcousticTextureReference_get_WwiseObjectType_m716134B3DD2F472E324C7E7740A04E283BAE6DB1,
	WwiseAcousticTextureReference__ctor_m5B9E4AC73171B3920B6A2C9C0D62203C47563A71,
	WwiseAuxBusReference_get_WwiseObjectType_m2E317138A1BD0A755692D65C855EE8F044E3B03A,
	WwiseAuxBusReference__ctor_mFFC2F25745E933296B5D235B3AD2348BB370DCCD,
	WwiseBankReference_get_WwiseObjectType_m78D831CD105A551B41750B1614165DCC4D917BE8,
	WwiseBankReference__ctor_m8030F92B10AC8E6AF63B133CEB01D46DA8CAF299,
	WwiseEventReference_get_WwiseObjectType_mA93850B1B0F59992FEAAA52AF9BA28918114AA68,
	WwiseEventReference__ctor_m928BC09314770B0343989D9497F56ABCC5709DD0,
	WwiseObjectReference_get_Guid_mA730AB56F442D112796810ECFB314FD39CB33C14,
	WwiseObjectReference_get_ObjectName_m58E64344E663162252A0190F15207DDFA7E63821,
	WwiseObjectReference_get_DisplayName_mC00CBA33CDCCA0F867B40B7A9CD893ECE942B989,
	WwiseObjectReference_get_Id_m6AFC577D7CB88EC618408101C2415016520205FB,
	NULL,
	WwiseObjectReference__ctor_mBFD3C8B3D48602C1E68FCC22E7653FEFC665EF8F,
	NULL,
	NULL,
	NULL,
	WwiseGroupValueObjectReference_get_DisplayName_m1BDB9F6B4F9C5BB82C156DB4AA50F088B15D4D94,
	WwiseGroupValueObjectReference__ctor_mEF381CCC534B4D2B825DA84F6A69B8C93FBC04AE,
	WwiseRtpcReference_get_WwiseObjectType_mF09FD3F3437F6BDF7946F881F4BFC3F7156B42DA,
	WwiseRtpcReference__ctor_m5C789BAA9F4715C322939B05AFA9E4BBBAAFEFB8,
	WwiseStateGroupReference_get_WwiseObjectType_m018FC3A2B2D1D7C2D148D0A0AF93CAD679B7011D,
	WwiseStateGroupReference__ctor_m63175271C679CB6F337D70B004EA46A012755521,
	WwiseStateReference_get_WwiseObjectType_m45E0A2965230CF2ADD893304673DD66CBF163B7F,
	WwiseStateReference_get_GroupObjectReference_mB6158977D748B4350E829514508FFAB0CEAB940F,
	WwiseStateReference_set_GroupObjectReference_mB38F503F67AC85A4195656D7B265180025F85EF1,
	WwiseStateReference_get_GroupWwiseObjectType_mCF4FD690441FDEE35582955A705C2633B4115DFB,
	WwiseStateReference__ctor_mB88C6F4F4C5A033EDF1FF59D9C648D9A67C6B644,
	WwiseSwitchGroupReference_get_WwiseObjectType_mD8EF023BC5DAAFC751F778866B7D05523FF2FDFD,
	WwiseSwitchGroupReference__ctor_m74ECCDD74B60F6D83397D571E9AF6281323E3CED,
	WwiseSwitchReference_get_WwiseObjectType_m2CC649B9471D6354FFB655B2BF7791082F5E49DE,
	WwiseSwitchReference_get_GroupObjectReference_mCC3D481CD4250F250C7343E6A3C8106BE5078EB5,
	WwiseSwitchReference_set_GroupObjectReference_m28DA84F22ACE63362B2C792048724EA9B957A497,
	WwiseSwitchReference_get_GroupWwiseObjectType_mE3E06B601281BB9A2E0BE31091ED9CF3884CA625,
	WwiseSwitchReference__ctor_m363E747E0D06A93679A9795A33E56D5B5FA20715,
	WwiseTriggerReference_get_WwiseObjectType_mE0E39630418D7D38AF162A3D39BABD774DC6ACA7,
	WwiseTriggerReference__ctor_mD54ED33DA73C43F928A7FDBB1858D54696FD42D5,
	AcousticTexture_get_ObjectReference_mF40AF0DC967818D3827FBE267E243F4D116D8821,
	AcousticTexture_set_ObjectReference_mBDAB9D5BA879D24BF1C7F543F76CEFD442E58A9D,
	AcousticTexture_get_WwiseObjectType_mF67FBA56C692AA7454C4140AD39D066B38B33346,
	AcousticTexture__ctor_m0E2DB175634A4592BE9BABD27E40EDF0FBC5EBDE,
	AuxBus_get_ObjectReference_mEB909C28D1C9B36CB5DB1792985C94EC4837A6D4,
	AuxBus_set_ObjectReference_m130FCE92CFF4D543369BC5154D8EAFBCF96FDA9E,
	AuxBus_get_WwiseObjectType_m843FE87544B19EAD2A090F8099D2104C4433AA16,
	AuxBus__ctor_mDA756A46983C38D87850ABF7BF5C47BD4A4E9731,
	Bank_get_WwiseObjectType_m74AF277A309F5A7034F3325643943B14B6E3D483,
	Bank_get_ObjectReference_m5C061EAE560173E72FB4B9595A4A3449CA68F282,
	Bank_set_ObjectReference_m70806BA0660E74626D2F04575930B5A5B9B609E7,
	Bank_Load_mE46124DE4BEB7444BFAB5D030E483D07E749732D,
	Bank_LoadAsync_mD0EDAB56C81E98240631CCE3AFA5175F56A8C79D,
	Bank_Unload_m0E6337A3DE4E818A065D60456BA28FE66959CAFD,
	Bank__ctor_m02ED1634B3F356354DF9780F4FD0D89BC560D2A1,
	BaseGroupType_get_GroupWwiseObjectReference_mC00EC611D1AB6A833A3389928F58AB828DEB509E,
	NULL,
	BaseGroupType_get_GroupId_mF73642DEE955F78AF36A9DED227DFAD6E36B9DA6,
	BaseGroupType_IsValid_mADCBE3C3E7B68B2D97014E1A84B2526BBE0AEDDB,
	BaseGroupType_get_groupID_mAA3C98D2E4BE7F4DCA97AC0B84E467F4527F187F,
	BaseGroupType_get_groupGuid_m6B0D66D9318433251D42610956CFB90B05B7EF8B,
	BaseGroupType__ctor_m507DE24A74927CD8D251293A8F86756EDA3A136C,
	NULL,
	NULL,
	NULL,
	BaseType_get_Name_mDFFF2E7872296A918CB207A3D4F0141A82A57651,
	BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A,
	BaseType_get_InvalidId_mC09A7B7CB1FDDF5F0F341E5F23D7CA7849172D26,
	BaseType_IsValid_mFF810061EE89CBE4C8E823B9DD12D868E95F90F5,
	BaseType_Validate_mCF58D3BA9A28AA4DB9F4C2BB11728A222730C109,
	BaseType_Verify_mE6155470D6E9EEB7BA97F692AE15F7B30B38983D,
	BaseType_ToString_mAAFCAE5E25C7899DD5114DD7D778A6D1E5D4CF2C,
	BaseType_get_ID_mD6C019E541BADA7F08CA0AB73BF51F665C0F88EE,
	BaseType_get_valueGuid_mBCE9BC6DCBA50287E5EAEFD7EC058BFF7D0EE944,
	BaseType__ctor_m930F7DA1FFBAF8BE9C844CE683F113046D28B898,
	CallbackFlags__ctor_m601552170E49E5E73BE6EFB37CDAC4835C8B79A5,
	Event_get_PlayingId_m45A26FC96EBD32601B9EC4580DD5222142A98178,
	Event_get_ObjectReference_m7317DF42BCCC275C6C191AE001087498D4065FE1,
	Event_set_ObjectReference_m1A659F392D4DA6CB6BF285D8FC6256BC40A48C7D,
	Event_get_WwiseObjectType_m5E0F8AC9167575B4FCEAE4773607C5F37D2C0EF0,
	Event_VerifyPlayingID_mF06416D9AED9C4251F6AA39D2FBCA71274DA926B,
	Event_Post_mB44E5C0A82FA36EDC65070D3024E066EE4D21F7A,
	Event_Post_m7E549AC780ECAC443484AC66E4201AC85AC34938,
	Event_Post_m975A00B31848012ACE9114D3FDB25CA0E630601D,
	Event_Stop_mF058FF1C69C98C1C87C1B2F517DBDBEAAE85D943,
	Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE,
	Event_PostMIDI_m982B73165A912E06894938827527969DCC2F0D3D,
	Event_PostMIDI_m3AECB7750EF014AE8C0D51AC4E779FA731EA43F4,
	Event_StopMIDI_m134DB6480821D066829993FC9AE0089183A85B25,
	Event_StopMIDI_m3EF14DD7C5CDA754301D41F35138329678A3E806,
	Event__ctor_mB99941177C1FF4FE4FDDD4185CB0C25681F4815D,
	RTPC_get_ObjectReference_m445052D3FBE9D3166A82FD97A5E0145C721A5B50,
	RTPC_set_ObjectReference_mA15859BEF88F307DC76FCC01EB1EA597E60FC557,
	RTPC_get_WwiseObjectType_m1026A2AEAB4CC66051C8FC588FB993391D341E3D,
	RTPC_SetValue_m1C344467FDED1786C71D410DBFCD5D03DCCD9AD5,
	RTPC_GetValue_mE4BBCDABF8F856CBD6E2E74B223130DDF4AD6776,
	RTPC_SetGlobalValue_mE95A5B940C8101349FA64E225E3D08233871C505,
	RTPC_GetGlobalValue_m0D5A676E5B7B5EA08AE6F3562C2DBF99490BCB29,
	RTPC__ctor_m7ECE0016601182CE16F80569BBD0F6E1C206803A,
	State_get_ObjectReference_mCE1AE7DCBB93E0E1E7086A66F6227D079B29EBF6,
	State_set_ObjectReference_mC2B636ABD6F3CAC90E48590BF03B908A66E7D435,
	State_get_WwiseObjectType_m9D728BF39FAC0C20CE9701AF35F60A09E2557822,
	State_get_WwiseObjectGroupType_m50AACD700B9C013D1AA346A001708955636BD467,
	State_SetValue_m3277A24BDD3292A989E4C9E4DAC8232C97DC8102,
	State__ctor_m949C6BA1B7BDCBFC995AF1AB412CA2F324C4B82A,
	Switch_get_ObjectReference_mDD523B2FFED3AC416F064D73C1FFA37253FD701E,
	Switch_set_ObjectReference_mC8D431846370386B7200FDB1A3B9B5306C3620B7,
	Switch_get_WwiseObjectType_m044A8559FB1555D1ADDD797FDB59B05C82454A29,
	Switch_get_WwiseObjectGroupType_mDF7D2CF3CEEDAD3A94CB2F6E7DCFB24090B8A2D4,
	Switch_SetValue_m7B841B28FA764A67FE68B2195F6DE87FE8432F98,
	Switch__ctor_mAF6277E27CA8D79605F59F2EDECD057D9ED43F95,
	Trigger_get_ObjectReference_m099F7DC1244CD75BD253FDCB448545B4CC9426BD,
	Trigger_set_ObjectReference_m0932A4F9EA97A9749BBB02CACAAE63F5FDC45D00,
	Trigger_get_WwiseObjectType_m6ED44BAE58D27901E599A9FB983075E40FBCB77D,
	Trigger_Post_mBDF91ECB8ADF7C97A038C5C8135384B4B91F1509,
	Trigger__ctor_m19564FCDDDC38BAE2089D029B026CD3ED4EF04FD,
};
static const int32_t s_InvokerIndices[113] = 
{
	10,
	23,
	10,
	23,
	10,
	23,
	10,
	23,
	703,
	14,
	14,
	10,
	10,
	23,
	14,
	26,
	10,
	14,
	23,
	10,
	23,
	10,
	23,
	10,
	14,
	26,
	10,
	23,
	10,
	23,
	10,
	14,
	26,
	10,
	23,
	10,
	23,
	14,
	26,
	10,
	23,
	14,
	26,
	10,
	23,
	10,
	14,
	26,
	42,
	26,
	23,
	23,
	14,
	10,
	10,
	89,
	10,
	14,
	23,
	14,
	26,
	10,
	14,
	10,
	106,
	89,
	89,
	32,
	14,
	10,
	14,
	23,
	23,
	10,
	14,
	26,
	10,
	32,
	112,
	2495,
	2496,
	35,
	202,
	27,
	118,
	26,
	23,
	23,
	14,
	26,
	10,
	917,
	228,
	326,
	714,
	23,
	14,
	26,
	10,
	10,
	23,
	23,
	14,
	26,
	10,
	10,
	26,
	23,
	14,
	26,
	10,
	26,
	23,
};
extern const Il2CppCodeGenModule g_AK_Wwise_Unity_API_WwiseTypesCodeGenModule;
const Il2CppCodeGenModule g_AK_Wwise_Unity_API_WwiseTypesCodeGenModule = 
{
	"AK.Wwise.Unity.API.WwiseTypes.dll",
	113,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
