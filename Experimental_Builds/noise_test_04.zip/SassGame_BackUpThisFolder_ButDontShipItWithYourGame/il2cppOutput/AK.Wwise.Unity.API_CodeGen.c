﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"



extern const RuntimeMethod* AkAudioInputManager_InternalAudioFormatDelegate_mE65C58A009B2CCE12BF2D66527E4DBA94359AE2F_RuntimeMethod_var;
extern const RuntimeMethod* AkAudioInputManager_InternalAudioSamplesDelegate_mCC8ACFBA434E55CA478271AC70312599C48729D8_RuntimeMethod_var;
extern const RuntimeMethod* AkLogger_WwiseInternalLogError_m74B4525C94A2B9D382CF3025E8B7AE1CBE92EA8A_RuntimeMethod_var;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void AkSoundEngine::AutoRegister(UnityEngine.GameObject,System.UInt64)
extern void AkSoundEngine_AutoRegister_m8932B8FA8793D0AEFD84E8F30AD3B572A914925A (void);
// 0x00000002 System.Boolean AkSoundEngine::IsInRegisteredList(System.UInt64)
extern void AkSoundEngine_IsInRegisteredList_m3A75ABB32DF33F3AA09D7CE30DAB57081A88102A (void);
// 0x00000003 System.Boolean AkSoundEngine::IsGameObjectRegistered(UnityEngine.GameObject)
extern void AkSoundEngine_IsGameObjectRegistered_mF122C3BF59940F5C71EF907937729D30B11A233D (void);
// 0x00000004 System.UInt32 AkSoundEngine::get_AK_INVALID_PIPELINE_ID()
extern void AkSoundEngine_get_AK_INVALID_PIPELINE_ID_mF5C71D7C362AC29EB90DDBB8CBC77E2ADE243E89 (void);
// 0x00000005 System.UInt64 AkSoundEngine::get_AK_INVALID_AUDIO_OBJECT_ID()
extern void AkSoundEngine_get_AK_INVALID_AUDIO_OBJECT_ID_m5561B0DF8DE56279E6F1E48CF32A58E2A62D5D3C (void);
// 0x00000006 System.UInt32 AkSoundEngine::get_AK_SOUNDBANK_VERSION()
extern void AkSoundEngine_get_AK_SOUNDBANK_VERSION_mB94FA41C12CFF4DC8C5A93FC7F93F1C38F78F3D9 (void);
// 0x00000007 System.UInt16 AkSoundEngine::get_AK_INT()
extern void AkSoundEngine_get_AK_INT_m6192F8AF098FECF2B870A2E2C66A4364F48DED70 (void);
// 0x00000008 System.UInt16 AkSoundEngine::get_AK_FLOAT()
extern void AkSoundEngine_get_AK_FLOAT_m9A2F3FD79B6D5F6ECEF4F71FCE681CDA6992EA25 (void);
// 0x00000009 System.Byte AkSoundEngine::get_AK_INTERLEAVED()
extern void AkSoundEngine_get_AK_INTERLEAVED_m7FDB1A9E1B5C7C2010472D5ED197C1DF101F3403 (void);
// 0x0000000A System.Byte AkSoundEngine::get_AK_NONINTERLEAVED()
extern void AkSoundEngine_get_AK_NONINTERLEAVED_m83B89B43ADE6C2B7A0C1C29F2A15029D4EEC875A (void);
// 0x0000000B System.UInt32 AkSoundEngine::get_AK_LE_NATIVE_BITSPERSAMPLE()
extern void AkSoundEngine_get_AK_LE_NATIVE_BITSPERSAMPLE_mAA2E7C87B512233902F0F968FC2BA3DCAE146CF8 (void);
// 0x0000000C System.UInt32 AkSoundEngine::get_AK_LE_NATIVE_SAMPLETYPE()
extern void AkSoundEngine_get_AK_LE_NATIVE_SAMPLETYPE_m9058942DB9054156BDCBC3716D8541E28DFEF234 (void);
// 0x0000000D System.UInt32 AkSoundEngine::get_AK_LE_NATIVE_INTERLEAVE()
extern void AkSoundEngine_get_AK_LE_NATIVE_INTERLEAVE_m3AF96BB342384948CD9F1F107876CC50AC42C5FA (void);
// 0x0000000E System.UInt32 AkSoundEngine::DynamicSequenceOpen(System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object,AkDynamicSequenceType)
extern void AkSoundEngine_DynamicSequenceOpen_m75549F0F10FB4C0B13F2FE3BDFF35436095E2E5C (void);
// 0x0000000F System.UInt32 AkSoundEngine::DynamicSequenceOpen(System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkSoundEngine_DynamicSequenceOpen_mC2F8BD01EB260B461477B5EEE6F81B3EAE561068 (void);
// 0x00000010 System.UInt32 AkSoundEngine::DynamicSequenceOpen(System.UInt64)
extern void AkSoundEngine_DynamicSequenceOpen_m6A479FFAE89868BD8EC01A462D437D984192F75B (void);
// 0x00000011 AKRESULT AkSoundEngine::DynamicSequenceClose(System.UInt32)
extern void AkSoundEngine_DynamicSequenceClose_m3FC07027C4C8A11B1E731370064A46CA64A1798C (void);
// 0x00000012 AKRESULT AkSoundEngine::DynamicSequencePlay(System.UInt32,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_DynamicSequencePlay_m1F99BF38AEAEF2A27E47231106344260F51E1BCB (void);
// 0x00000013 AKRESULT AkSoundEngine::DynamicSequencePlay(System.UInt32,System.Int32)
extern void AkSoundEngine_DynamicSequencePlay_m1BE6341A84CDB2C34F0F63376DC76EEE5B944A34 (void);
// 0x00000014 AKRESULT AkSoundEngine::DynamicSequencePlay(System.UInt32)
extern void AkSoundEngine_DynamicSequencePlay_mB51918F2DDDF967F76852ABE8A86013044BEC59A (void);
// 0x00000015 AKRESULT AkSoundEngine::DynamicSequencePause(System.UInt32,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_DynamicSequencePause_m9709C70C75B76FF0D4B90AD467FE2FA9AD449000 (void);
// 0x00000016 AKRESULT AkSoundEngine::DynamicSequencePause(System.UInt32,System.Int32)
extern void AkSoundEngine_DynamicSequencePause_mE4A4D6AE0BA5E8DDCBA99D6A49A1224557DDE206 (void);
// 0x00000017 AKRESULT AkSoundEngine::DynamicSequencePause(System.UInt32)
extern void AkSoundEngine_DynamicSequencePause_m38B12E64402F114CCE586BC5AA3E0F8DC263DC46 (void);
// 0x00000018 AKRESULT AkSoundEngine::DynamicSequenceResume(System.UInt32,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_DynamicSequenceResume_m0BA7A5130DDE1F4F1E27196DEE5A2F651AE7D41E (void);
// 0x00000019 AKRESULT AkSoundEngine::DynamicSequenceResume(System.UInt32,System.Int32)
extern void AkSoundEngine_DynamicSequenceResume_m6D989532E5DCFEAB67021E7FDC24EE6F5406317B (void);
// 0x0000001A AKRESULT AkSoundEngine::DynamicSequenceResume(System.UInt32)
extern void AkSoundEngine_DynamicSequenceResume_m521995569CC007694E610BD0016BE3CBC5248CD0 (void);
// 0x0000001B AKRESULT AkSoundEngine::DynamicSequenceStop(System.UInt32,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_DynamicSequenceStop_m0EC643E1A5A77D1A0D5EB389F7DE802093C93458 (void);
// 0x0000001C AKRESULT AkSoundEngine::DynamicSequenceStop(System.UInt32,System.Int32)
extern void AkSoundEngine_DynamicSequenceStop_m75B8F20505FF898E934D09E06FD6CD160641D71D (void);
// 0x0000001D AKRESULT AkSoundEngine::DynamicSequenceStop(System.UInt32)
extern void AkSoundEngine_DynamicSequenceStop_mC2183C1A8559575D6FCFB410EC4B81A353ED495F (void);
// 0x0000001E AKRESULT AkSoundEngine::DynamicSequenceBreak(System.UInt32)
extern void AkSoundEngine_DynamicSequenceBreak_m046931243D333118B99032A4C1F344E6F21C68A0 (void);
// 0x0000001F AKRESULT AkSoundEngine::Seek(System.UInt32,System.Int32,System.Boolean)
extern void AkSoundEngine_Seek_mAE1227F6DE74DB17F3539C4C6CBA655C31054D90 (void);
// 0x00000020 AKRESULT AkSoundEngine::Seek(System.UInt32,System.Single,System.Boolean)
extern void AkSoundEngine_Seek_m27692CF524E42EB4B6183AAA523F144BE90499F3 (void);
// 0x00000021 AKRESULT AkSoundEngine::DynamicSequenceGetPauseTimes(System.UInt32,System.UInt32&,System.UInt32&)
extern void AkSoundEngine_DynamicSequenceGetPauseTimes_m6E9EBF5319B4614E41388BBAF8CADE5518ED6612 (void);
// 0x00000022 AkPlaylist AkSoundEngine::DynamicSequenceLockPlaylist(System.UInt32)
extern void AkSoundEngine_DynamicSequenceLockPlaylist_m590D9126338E75C819BC40EA436C1D240AC00292 (void);
// 0x00000023 AKRESULT AkSoundEngine::DynamicSequenceUnlockPlaylist(System.UInt32)
extern void AkSoundEngine_DynamicSequenceUnlockPlaylist_m4F98F95DB569FF9C09ACF407D0B98F4DA52ADECB (void);
// 0x00000024 System.Boolean AkSoundEngine::IsInitialized()
extern void AkSoundEngine_IsInitialized_m76B4274558657C0E3F450F9B384D0B03A786844D (void);
// 0x00000025 AKRESULT AkSoundEngine::GetAudioSettings(AkAudioSettings)
extern void AkSoundEngine_GetAudioSettings_mEE83D45194A13F313954F4140CF8EB2AD4C00E37 (void);
// 0x00000026 AkChannelConfig AkSoundEngine::GetSpeakerConfiguration(System.UInt64)
extern void AkSoundEngine_GetSpeakerConfiguration_m4B4DD31D864097157C174A7579FE7FE1F2DC343B (void);
// 0x00000027 AkChannelConfig AkSoundEngine::GetSpeakerConfiguration()
extern void AkSoundEngine_GetSpeakerConfiguration_m7FEA2842CB52D59A3A0158A7EC0378B707E529C5 (void);
// 0x00000028 AKRESULT AkSoundEngine::GetOutputDeviceConfiguration(System.UInt64,AkChannelConfig,Ak3DAudioSinkCapabilities)
extern void AkSoundEngine_GetOutputDeviceConfiguration_m96D272CA1186C4945D1FC40F91D8316587EBDEA7 (void);
// 0x00000029 AKRESULT AkSoundEngine::GetPanningRule(System.Int32&,System.UInt64)
extern void AkSoundEngine_GetPanningRule_m00638BE10262167BD09940E66681D2486C0F65FA (void);
// 0x0000002A AKRESULT AkSoundEngine::GetPanningRule(System.Int32&)
extern void AkSoundEngine_GetPanningRule_m12B23D5E9EFBFDFDFDA73FA3C0CA7130E505D7E1 (void);
// 0x0000002B AKRESULT AkSoundEngine::SetPanningRule(AkPanningRule,System.UInt64)
extern void AkSoundEngine_SetPanningRule_mB9DA34AFDE63A9217AA23AD7F125F72A0E98FDF8 (void);
// 0x0000002C AKRESULT AkSoundEngine::SetPanningRule(AkPanningRule)
extern void AkSoundEngine_SetPanningRule_mF7B69C801F24CC46FC5B6D70D088F8D8DF35808E (void);
// 0x0000002D AKRESULT AkSoundEngine::GetSpeakerAngles(System.Single[],System.UInt32&,System.Single&,System.UInt64)
extern void AkSoundEngine_GetSpeakerAngles_m7129F49C663AA5B0531050E153740FBF01460EDA (void);
// 0x0000002E AKRESULT AkSoundEngine::GetSpeakerAngles(System.Single[],System.UInt32&,System.Single&)
extern void AkSoundEngine_GetSpeakerAngles_m6B1AD30A39D160AB2E76F2FA141D72FC2193F4B7 (void);
// 0x0000002F AKRESULT AkSoundEngine::SetSpeakerAngles(System.Single[],System.UInt32,System.Single,System.UInt64)
extern void AkSoundEngine_SetSpeakerAngles_mEF1E26AF3A4A715E948DE8073B9C7CC6193619A8 (void);
// 0x00000030 AKRESULT AkSoundEngine::SetSpeakerAngles(System.Single[],System.UInt32,System.Single)
extern void AkSoundEngine_SetSpeakerAngles_mF0B6E739E8F1B918418664AEBEFACD8E6CB7B77F (void);
// 0x00000031 AKRESULT AkSoundEngine::SetVolumeThreshold(System.Single)
extern void AkSoundEngine_SetVolumeThreshold_mE12690FD2F823C335B6EA66350C42901F5E48E2B (void);
// 0x00000032 AKRESULT AkSoundEngine::SetMaxNumVoicesLimit(System.UInt16)
extern void AkSoundEngine_SetMaxNumVoicesLimit_m75646AF062EE1250083888EEFD9738BAD1D2FD0B (void);
// 0x00000033 AKRESULT AkSoundEngine::RenderAudio(System.Boolean)
extern void AkSoundEngine_RenderAudio_m04C66D07ED8F0A9D6033C3343AECC1CC7B6C89B8 (void);
// 0x00000034 AKRESULT AkSoundEngine::RenderAudio()
extern void AkSoundEngine_RenderAudio_m0F159D5B99B42A2AE3EED95BEEB6746E6C7ED0B6 (void);
// 0x00000035 AKRESULT AkSoundEngine::RegisterPluginDLL(System.String,System.String)
extern void AkSoundEngine_RegisterPluginDLL_m1AD7645945F49003326A277B0255CD5FE801673E (void);
// 0x00000036 AKRESULT AkSoundEngine::RegisterPluginDLL(System.String)
extern void AkSoundEngine_RegisterPluginDLL_mC2D01851CC8ADE1EC8F4A85FD3B4B42DA6581BC7 (void);
// 0x00000037 System.UInt32 AkSoundEngine::GetIDFromString(System.String)
extern void AkSoundEngine_GetIDFromString_mEA872321C202FCF9F08189AF74F58853FCA9DB63 (void);
// 0x00000038 System.UInt32 AkSoundEngine::PostEvent(System.UInt32,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray,System.UInt32)
extern void AkSoundEngine_PostEvent_mAB665E57B07C35D4DA253B8F51C3292571B6D5A5 (void);
// 0x00000039 System.UInt32 AkSoundEngine::PostEvent(System.UInt32,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray)
extern void AkSoundEngine_PostEvent_mBF27F3E62716299C08EA98D60E4BB06E7F8908FE (void);
// 0x0000003A System.UInt32 AkSoundEngine::PostEvent(System.UInt32,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkSoundEngine_PostEvent_m997A7668B975E941F91CDBD192BA46E862745061 (void);
// 0x0000003B System.UInt32 AkSoundEngine::PostEvent(System.UInt32,System.UInt64)
extern void AkSoundEngine_PostEvent_mD400F73D4C60220DE61D6AD7B4C5431E70030F17 (void);
// 0x0000003C System.UInt32 AkSoundEngine::PostEvent(System.String,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray,System.UInt32)
extern void AkSoundEngine_PostEvent_m1EF119D5BA7EEAAF115CB16FEBE4D9B9960B8064 (void);
// 0x0000003D System.UInt32 AkSoundEngine::PostEvent(System.String,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray)
extern void AkSoundEngine_PostEvent_m5DDC87259E41D9FC13FF4A2E8D18635BB0716A78 (void);
// 0x0000003E System.UInt32 AkSoundEngine::PostEvent(System.String,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkSoundEngine_PostEvent_m36FA0E8E7E020CD2CD1D73AC122AAC6A97E4126F (void);
// 0x0000003F System.UInt32 AkSoundEngine::PostEvent(System.String,System.UInt64)
extern void AkSoundEngine_PostEvent_m4C77A39AD8F95FAA22D7260B66419ECF45CB2C71 (void);
// 0x00000040 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType,System.UInt64,System.Int32,AkCurveInterpolation,System.UInt32)
extern void AkSoundEngine_ExecuteActionOnEvent_m04C957F393FBEC288BBA56E1AE85A6AD78E03F12 (void);
// 0x00000041 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType,System.UInt64,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_ExecuteActionOnEvent_mC6896E088058423EA8EA51B34789251E9038E225 (void);
// 0x00000042 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType,System.UInt64,System.Int32)
extern void AkSoundEngine_ExecuteActionOnEvent_m449ECDA042B36FE27A1154FEB74F88860190FF2B (void);
// 0x00000043 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType,System.UInt64)
extern void AkSoundEngine_ExecuteActionOnEvent_m2BEF57503DD2B3D189557A02E419DDD26FFA6D31 (void);
// 0x00000044 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType)
extern void AkSoundEngine_ExecuteActionOnEvent_m5799002F93C9D6E956CC5AA47055146E310CC1E0 (void);
// 0x00000045 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.String,AkActionOnEventType,System.UInt64,System.Int32,AkCurveInterpolation,System.UInt32)
extern void AkSoundEngine_ExecuteActionOnEvent_m0B665A2327721EF957D348EF8EAE44AED75F54BA (void);
// 0x00000046 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.String,AkActionOnEventType,System.UInt64,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_ExecuteActionOnEvent_m4DE7A11CC88E759C9602ABD6E451C6B80332C5CB (void);
// 0x00000047 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.String,AkActionOnEventType,System.UInt64,System.Int32)
extern void AkSoundEngine_ExecuteActionOnEvent_mFE2B678EF9F9A376C9C8DEFB97B35E32F36EA546 (void);
// 0x00000048 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.String,AkActionOnEventType,System.UInt64)
extern void AkSoundEngine_ExecuteActionOnEvent_m50B404C9F1352422590312E9FE885E1E5C751580 (void);
// 0x00000049 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.String,AkActionOnEventType)
extern void AkSoundEngine_ExecuteActionOnEvent_m40581760C5529B7789E545DB9B4D8DF80250DBA2 (void);
// 0x0000004A System.UInt32 AkSoundEngine::PostMIDIOnEvent(System.UInt32,System.UInt64,AkMIDIPostArray,System.UInt16,System.Boolean,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32)
extern void AkSoundEngine_PostMIDIOnEvent_m99C5BD6A4694E18D5C32CB10B7B5A4AE0B5B129F (void);
// 0x0000004B System.UInt32 AkSoundEngine::PostMIDIOnEvent(System.UInt32,System.UInt64,AkMIDIPostArray,System.UInt16,System.Boolean,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkSoundEngine_PostMIDIOnEvent_mDBDE91EE1F181F17FD9FFD1BD4949CF847085838 (void);
// 0x0000004C System.UInt32 AkSoundEngine::PostMIDIOnEvent(System.UInt32,System.UInt64,AkMIDIPostArray,System.UInt16,System.Boolean)
extern void AkSoundEngine_PostMIDIOnEvent_m0D874DF3109285F82FFBBF44BC0C44515E0B9616 (void);
// 0x0000004D System.UInt32 AkSoundEngine::PostMIDIOnEvent(System.UInt32,System.UInt64,AkMIDIPostArray,System.UInt16)
extern void AkSoundEngine_PostMIDIOnEvent_m877A330AD811A57843DE7D2AFCBE174BC8522430 (void);
// 0x0000004E AKRESULT AkSoundEngine::StopMIDIOnEvent(System.UInt32,System.UInt64,System.UInt32)
extern void AkSoundEngine_StopMIDIOnEvent_m30E40360A044A6FE86E048E70C6876845213CA1A (void);
// 0x0000004F AKRESULT AkSoundEngine::StopMIDIOnEvent(System.UInt32,System.UInt64)
extern void AkSoundEngine_StopMIDIOnEvent_mCB261628179A521B1ACD880F21F94ABDC40ECC4E (void);
// 0x00000050 AKRESULT AkSoundEngine::StopMIDIOnEvent(System.UInt32)
extern void AkSoundEngine_StopMIDIOnEvent_mFFB9A53556646A6E3FB7E4F782DEBDC5AE29E156 (void);
// 0x00000051 AKRESULT AkSoundEngine::StopMIDIOnEvent()
extern void AkSoundEngine_StopMIDIOnEvent_m8C95C0CB26382E1A089DF0F46AE12B0C6E4BC1B7 (void);
// 0x00000052 AKRESULT AkSoundEngine::PinEventInStreamCache(System.UInt32,System.SByte,System.SByte)
extern void AkSoundEngine_PinEventInStreamCache_m25A2F7107A92575D920FB3AA3C7BAB5DE0F94D8D (void);
// 0x00000053 AKRESULT AkSoundEngine::PinEventInStreamCache(System.String,System.SByte,System.SByte)
extern void AkSoundEngine_PinEventInStreamCache_m8879102CE2FC407338B55F9FDF520C5B9FCB52D4 (void);
// 0x00000054 AKRESULT AkSoundEngine::UnpinEventInStreamCache(System.UInt32)
extern void AkSoundEngine_UnpinEventInStreamCache_m308A334A1E3315B82E9C2521A1C2D0E5F7F3F3C7 (void);
// 0x00000055 AKRESULT AkSoundEngine::UnpinEventInStreamCache(System.String)
extern void AkSoundEngine_UnpinEventInStreamCache_mD1130A7F70B444B198E9D24E7D04576288055B8C (void);
// 0x00000056 AKRESULT AkSoundEngine::GetBufferStatusForPinnedEvent(System.UInt32,System.Single&,System.Int32&)
extern void AkSoundEngine_GetBufferStatusForPinnedEvent_m01299F325EF5A28C45C88A4808D833D2437A9CA6 (void);
// 0x00000057 AKRESULT AkSoundEngine::GetBufferStatusForPinnedEvent(System.String,System.Single&,System.Int32&)
extern void AkSoundEngine_GetBufferStatusForPinnedEvent_m3D6A9203AA266F62018A8FFD82EEED1517D935D6 (void);
// 0x00000058 AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,System.UInt64,System.Int32,System.Boolean,System.UInt32)
extern void AkSoundEngine_SeekOnEvent_m308CC21BA7EC669933EE94D75EEE6B9249DC42B0 (void);
// 0x00000059 AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,System.UInt64,System.Int32,System.Boolean)
extern void AkSoundEngine_SeekOnEvent_m51BEC0069AB8B2F6CFC10F85BF677BB9EF794A86 (void);
// 0x0000005A AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,System.UInt64,System.Int32)
extern void AkSoundEngine_SeekOnEvent_m8272746694E03C7D6443DF568480E2E687085731 (void);
// 0x0000005B AKRESULT AkSoundEngine::SeekOnEvent(System.String,System.UInt64,System.Int32,System.Boolean,System.UInt32)
extern void AkSoundEngine_SeekOnEvent_m6A209FAC89DB2CBC42898F0EEEC9420C6FBC8386 (void);
// 0x0000005C AKRESULT AkSoundEngine::SeekOnEvent(System.String,System.UInt64,System.Int32,System.Boolean)
extern void AkSoundEngine_SeekOnEvent_m41DD52D02AAE3E77CBF9B2506073CE7811321847 (void);
// 0x0000005D AKRESULT AkSoundEngine::SeekOnEvent(System.String,System.UInt64,System.Int32)
extern void AkSoundEngine_SeekOnEvent_m3DE03447673A93B3C54C03D413E5E847C72CAC7B (void);
// 0x0000005E AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,System.UInt64,System.Single,System.Boolean,System.UInt32)
extern void AkSoundEngine_SeekOnEvent_m3C04059DA86FF6573B8E426C56D39A3D258F0886 (void);
// 0x0000005F AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,System.UInt64,System.Single,System.Boolean)
extern void AkSoundEngine_SeekOnEvent_m519C768432590722333467DE690FD1F473DCBEF6 (void);
// 0x00000060 AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,System.UInt64,System.Single)
extern void AkSoundEngine_SeekOnEvent_m39D61E482DCB6129EB53DC0A94C8F481F7C1A55C (void);
// 0x00000061 AKRESULT AkSoundEngine::SeekOnEvent(System.String,System.UInt64,System.Single,System.Boolean,System.UInt32)
extern void AkSoundEngine_SeekOnEvent_mD3D07B98208AFB3F9AD6933C7DFC12ED2B2B8C15 (void);
// 0x00000062 AKRESULT AkSoundEngine::SeekOnEvent(System.String,System.UInt64,System.Single,System.Boolean)
extern void AkSoundEngine_SeekOnEvent_mCAD27A774BDEF235A220B9F0553C1E66D4F29AB5 (void);
// 0x00000063 AKRESULT AkSoundEngine::SeekOnEvent(System.String,System.UInt64,System.Single)
extern void AkSoundEngine_SeekOnEvent_m6CC84805B582C89D9F7F0450777C90FD599F2E3F (void);
// 0x00000064 System.Void AkSoundEngine::CancelEventCallbackCookie(System.Object)
extern void AkSoundEngine_CancelEventCallbackCookie_m396B8B106A208CE221BD669F8520D0FB1B0467FB (void);
// 0x00000065 System.Void AkSoundEngine::CancelEventCallbackGameObject(System.UInt64)
extern void AkSoundEngine_CancelEventCallbackGameObject_m592D5B60AE7BC7CF1EC1469B5E00BEF2BD6D1F7E (void);
// 0x00000066 System.Void AkSoundEngine::CancelEventCallback(System.UInt32)
extern void AkSoundEngine_CancelEventCallback_m3E8F27765FCB26443A255BAAE11FAD6E60F849BF (void);
// 0x00000067 AKRESULT AkSoundEngine::GetSourcePlayPosition(System.UInt32,System.Int32&,System.Boolean)
extern void AkSoundEngine_GetSourcePlayPosition_m786F17819CC01810FF61202B1A8408B1A55F6AD5 (void);
// 0x00000068 AKRESULT AkSoundEngine::GetSourcePlayPosition(System.UInt32,System.Int32&)
extern void AkSoundEngine_GetSourcePlayPosition_m2A69E8D40B7FCB6F82573E998162D005BC5BA16F (void);
// 0x00000069 AKRESULT AkSoundEngine::GetSourceStreamBuffering(System.UInt32,System.Int32&,System.Int32&)
extern void AkSoundEngine_GetSourceStreamBuffering_m925BCEC4777CCAC225BB772D7DD5EEFB23D0354F (void);
// 0x0000006A System.Void AkSoundEngine::StopAll(System.UInt64)
extern void AkSoundEngine_StopAll_m1C809EDFDEAFDFD59ACC47339E570E5D511FB400 (void);
// 0x0000006B System.Void AkSoundEngine::StopAll()
extern void AkSoundEngine_StopAll_mFA9DADB215FBBBA1999DA7F3FD83F2218B16B6D1 (void);
// 0x0000006C System.Void AkSoundEngine::StopPlayingID(System.UInt32,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_StopPlayingID_mB94A9850776C16C6A7AA0FF0DD908AC1322F8E4F (void);
// 0x0000006D System.Void AkSoundEngine::StopPlayingID(System.UInt32,System.Int32)
extern void AkSoundEngine_StopPlayingID_mC0374253D4C3F4B234604776C25686F7CFD42636 (void);
// 0x0000006E System.Void AkSoundEngine::StopPlayingID(System.UInt32)
extern void AkSoundEngine_StopPlayingID_m74BF7B85B5153C84EFAD4B94101D9FD97F048095 (void);
// 0x0000006F System.Void AkSoundEngine::ExecuteActionOnPlayingID(AkActionOnEventType,System.UInt32,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_ExecuteActionOnPlayingID_m41002219A542A94A65832C3D29F9ACF7A987C666 (void);
// 0x00000070 System.Void AkSoundEngine::ExecuteActionOnPlayingID(AkActionOnEventType,System.UInt32,System.Int32)
extern void AkSoundEngine_ExecuteActionOnPlayingID_mAEE806664B8258F37BCE8078019ED45FFE87931C (void);
// 0x00000071 System.Void AkSoundEngine::ExecuteActionOnPlayingID(AkActionOnEventType,System.UInt32)
extern void AkSoundEngine_ExecuteActionOnPlayingID_mB56BE92390D1852440374B5CC5D5C17DFCDB4F5D (void);
// 0x00000072 System.Void AkSoundEngine::SetRandomSeed(System.UInt32)
extern void AkSoundEngine_SetRandomSeed_m769F9A2670DE35FFAE8E696C55BBE0C282B9B301 (void);
// 0x00000073 System.Void AkSoundEngine::MuteBackgroundMusic(System.Boolean)
extern void AkSoundEngine_MuteBackgroundMusic_m5DFC91D5DD8DEC88FBC60D4F30AB3758C0132179 (void);
// 0x00000074 System.Boolean AkSoundEngine::GetBackgroundMusicMute()
extern void AkSoundEngine_GetBackgroundMusicMute_mC901D1474927B37C95D1C2A0E5252BD438FBB58A (void);
// 0x00000075 AKRESULT AkSoundEngine::SendPluginCustomGameData(System.UInt32,System.UInt64,AkPluginType,System.UInt32,System.UInt32,System.IntPtr,System.UInt32)
extern void AkSoundEngine_SendPluginCustomGameData_m624DF4DE5C9B90949889A012E98DE64840995CA2 (void);
// 0x00000076 AKRESULT AkSoundEngine::UnregisterAllGameObj()
extern void AkSoundEngine_UnregisterAllGameObj_mB77917B8A31301DEFADFBDC99D0962543816F8AA (void);
// 0x00000077 AKRESULT AkSoundEngine::SetMultiplePositions(System.UInt64,AkPositionArray,System.UInt16,AkMultiPositionType)
extern void AkSoundEngine_SetMultiplePositions_m4C19EE8DB342C6432FEA7CD65E446F1549B60D78 (void);
// 0x00000078 AKRESULT AkSoundEngine::SetMultiplePositions(System.UInt64,AkPositionArray,System.UInt16)
extern void AkSoundEngine_SetMultiplePositions_m1FDD3A4706B34960E7E71DD98B983264CEFB4AB6 (void);
// 0x00000079 AKRESULT AkSoundEngine::SetMultiplePositions(System.UInt64,AkChannelEmitterArray,System.UInt16,AkMultiPositionType)
extern void AkSoundEngine_SetMultiplePositions_mDBDCBB2F4A9CBFC5B8463F558BDD1B389768CA0D (void);
// 0x0000007A AKRESULT AkSoundEngine::SetMultiplePositions(System.UInt64,AkChannelEmitterArray,System.UInt16)
extern void AkSoundEngine_SetMultiplePositions_mAFD26C2CB8223669B94F3C4A9DB88013261BFB11 (void);
// 0x0000007B AKRESULT AkSoundEngine::SetScalingFactor(System.UInt64,System.Single)
extern void AkSoundEngine_SetScalingFactor_m1EA6DC9A5F4FF7DF088E275F22A8F1004D932345 (void);
// 0x0000007C AKRESULT AkSoundEngine::ClearBanks()
extern void AkSoundEngine_ClearBanks_m25BA2D588E317FA01EBAC637D2E227C18D8250AA (void);
// 0x0000007D AKRESULT AkSoundEngine::SetBankLoadIOSettings(System.Single,System.SByte)
extern void AkSoundEngine_SetBankLoadIOSettings_m6BFFB95FF88BABF183E11965ED4FAD8FC1416586 (void);
// 0x0000007E AKRESULT AkSoundEngine::LoadBank(System.String,System.UInt32&)
extern void AkSoundEngine_LoadBank_mEABF8DDB0CDAA2D9928245374B055CE7DB391ED2 (void);
// 0x0000007F AKRESULT AkSoundEngine::LoadBank(System.UInt32)
extern void AkSoundEngine_LoadBank_mCF3CE3DDE26F1260E8BFF29C7E8247D309A0B70C (void);
// 0x00000080 AKRESULT AkSoundEngine::LoadBankMemoryView(System.IntPtr,System.UInt32,System.UInt32&)
extern void AkSoundEngine_LoadBankMemoryView_mC4D1D0C818ABFBDC028C5C6387292F8865214585 (void);
// 0x00000081 AKRESULT AkSoundEngine::LoadBankMemoryCopy(System.IntPtr,System.UInt32,System.UInt32&)
extern void AkSoundEngine_LoadBankMemoryCopy_m4E8F32303DB8F16FF4CBFB4E1F2D70294E434D3C (void);
// 0x00000082 AKRESULT AkSoundEngine::LoadBank(System.String,AkCallbackManager_BankCallback,System.Object,System.UInt32&)
extern void AkSoundEngine_LoadBank_m97EC88CC63821A30D8D568DF4B48332392FA23B1 (void);
// 0x00000083 AKRESULT AkSoundEngine::LoadBank(System.UInt32,AkCallbackManager_BankCallback,System.Object)
extern void AkSoundEngine_LoadBank_mAD5170A2BBB0938AAE7A458C6C8B2C6414BFD263 (void);
// 0x00000084 AKRESULT AkSoundEngine::LoadBankMemoryView(System.IntPtr,System.UInt32,AkCallbackManager_BankCallback,System.Object,System.UInt32&)
extern void AkSoundEngine_LoadBankMemoryView_m56BC3666D73157DFEA1D136B98CD4498B99CDA30 (void);
// 0x00000085 AKRESULT AkSoundEngine::LoadBankMemoryCopy(System.IntPtr,System.UInt32,AkCallbackManager_BankCallback,System.Object,System.UInt32&)
extern void AkSoundEngine_LoadBankMemoryCopy_mC9CE36B08E3B875E5990FEF269B5DF0BA7CF5DAA (void);
// 0x00000086 AKRESULT AkSoundEngine::UnloadBank(System.String,System.IntPtr)
extern void AkSoundEngine_UnloadBank_m8E40BFA3897D3381DE7E211608CAF145C0BCB9AF (void);
// 0x00000087 AKRESULT AkSoundEngine::UnloadBank(System.UInt32,System.IntPtr)
extern void AkSoundEngine_UnloadBank_m89A742A422BFC4DBE2EFAA2E4D2574E0D9F8AD8B (void);
// 0x00000088 AKRESULT AkSoundEngine::UnloadBank(System.String,System.IntPtr,AkCallbackManager_BankCallback,System.Object)
extern void AkSoundEngine_UnloadBank_m80CCFB3DC6C45532A371DB171F442196E465A216 (void);
// 0x00000089 AKRESULT AkSoundEngine::UnloadBank(System.UInt32,System.IntPtr,AkCallbackManager_BankCallback,System.Object)
extern void AkSoundEngine_UnloadBank_m74D26BAD913AA5CD7CBAB5C9663B1313873C61F2 (void);
// 0x0000008A System.Void AkSoundEngine::CancelBankCallbackCookie(System.Object)
extern void AkSoundEngine_CancelBankCallbackCookie_mC29B370F1869919E88C5278CC54ED3ECB96E2CA5 (void);
// 0x0000008B AKRESULT AkSoundEngine::PrepareBank(AkPreparationType,System.String,AkBankContent)
extern void AkSoundEngine_PrepareBank_mE4CE543C203DC4AECD18D1B8280B5AA3BFDC0C4D (void);
// 0x0000008C AKRESULT AkSoundEngine::PrepareBank(AkPreparationType,System.String)
extern void AkSoundEngine_PrepareBank_mC4316024C933469C03034E60E84E0C898858A31F (void);
// 0x0000008D AKRESULT AkSoundEngine::PrepareBank(AkPreparationType,System.UInt32,AkBankContent)
extern void AkSoundEngine_PrepareBank_mE2131C6ABC4F2B4F107DCADBBEB25CA6CE2D4E22 (void);
// 0x0000008E AKRESULT AkSoundEngine::PrepareBank(AkPreparationType,System.UInt32)
extern void AkSoundEngine_PrepareBank_m5FD9E5120AB525FAB166A6B27B46F1E6F7F6E655 (void);
// 0x0000008F AKRESULT AkSoundEngine::PrepareBank(AkPreparationType,System.String,AkCallbackManager_BankCallback,System.Object,AkBankContent)
extern void AkSoundEngine_PrepareBank_m6B857982DB2DDF8D7B4C5F81CA25DA18BDB2E7A4 (void);
// 0x00000090 AKRESULT AkSoundEngine::PrepareBank(AkPreparationType,System.String,AkCallbackManager_BankCallback,System.Object)
extern void AkSoundEngine_PrepareBank_m67B437F011DB94ECAB0895CC6F751C603A35617F (void);
// 0x00000091 AKRESULT AkSoundEngine::PrepareBank(AkPreparationType,System.UInt32,AkCallbackManager_BankCallback,System.Object,AkBankContent)
extern void AkSoundEngine_PrepareBank_m9F49547FFB8A54D7EA4F33D46398729B77258E77 (void);
// 0x00000092 AKRESULT AkSoundEngine::PrepareBank(AkPreparationType,System.UInt32,AkCallbackManager_BankCallback,System.Object)
extern void AkSoundEngine_PrepareBank_m06D947982236D11595B87BF95A0F27FE00917330 (void);
// 0x00000093 AKRESULT AkSoundEngine::ClearPreparedEvents()
extern void AkSoundEngine_ClearPreparedEvents_m0207009D9C0C5975FFE3FAC8240BDE5CB698E67F (void);
// 0x00000094 AKRESULT AkSoundEngine::PrepareEvent(AkPreparationType,System.String[],System.UInt32)
extern void AkSoundEngine_PrepareEvent_mF7E4BC30C8928707AC81497C8F9E6E0B63619994 (void);
// 0x00000095 AKRESULT AkSoundEngine::PrepareEvent(AkPreparationType,System.UInt32[],System.UInt32)
extern void AkSoundEngine_PrepareEvent_mCD43F84A762375AE2A37A4946C23567883B346A5 (void);
// 0x00000096 AKRESULT AkSoundEngine::PrepareEvent(AkPreparationType,System.String[],System.UInt32,AkCallbackManager_BankCallback,System.Object)
extern void AkSoundEngine_PrepareEvent_mE89F71654AC668D6198E53EA378342ED88BE1408 (void);
// 0x00000097 AKRESULT AkSoundEngine::PrepareEvent(AkPreparationType,System.UInt32[],System.UInt32,AkCallbackManager_BankCallback,System.Object)
extern void AkSoundEngine_PrepareEvent_m386C86C1D8A6B7F11EBCB4D033EF50E573F9758A (void);
// 0x00000098 AKRESULT AkSoundEngine::SetMedia(AkSourceSettingsArray,System.UInt32)
extern void AkSoundEngine_SetMedia_mD83E625E3366D0783112CF1B497A0AB9C613F9C9 (void);
// 0x00000099 AKRESULT AkSoundEngine::UnsetMedia(AkSourceSettingsArray,System.UInt32)
extern void AkSoundEngine_UnsetMedia_m53250877545843FCCD40292C904FD76D7F9840DC (void);
// 0x0000009A AKRESULT AkSoundEngine::PrepareGameSyncs(AkPreparationType,AkGroupType,System.String,System.String[],System.UInt32)
extern void AkSoundEngine_PrepareGameSyncs_m0866906C83A6680566FD5192DBBBEA0AC7E215FB (void);
// 0x0000009B AKRESULT AkSoundEngine::PrepareGameSyncs(AkPreparationType,AkGroupType,System.UInt32,System.UInt32[],System.UInt32)
extern void AkSoundEngine_PrepareGameSyncs_m0D1630AD10A8F061739D6A796097CE106CD9DF3C (void);
// 0x0000009C AKRESULT AkSoundEngine::PrepareGameSyncs(AkPreparationType,AkGroupType,System.String,System.String[],System.UInt32,AkCallbackManager_BankCallback,System.Object)
extern void AkSoundEngine_PrepareGameSyncs_m0A12E9892D28C5F23FE2F7FECA0DFF03A117D646 (void);
// 0x0000009D AKRESULT AkSoundEngine::PrepareGameSyncs(AkPreparationType,AkGroupType,System.UInt32,System.UInt32[],System.UInt32,AkCallbackManager_BankCallback,System.Object)
extern void AkSoundEngine_PrepareGameSyncs_mFD1026CA21ACF9B98D744286B63EDD116E0B03C8 (void);
// 0x0000009E AKRESULT AkSoundEngine::AddListener(System.UInt64,System.UInt64)
extern void AkSoundEngine_AddListener_m9AC6133C8084170F6EC18F540A6A55E2679E8943 (void);
// 0x0000009F AKRESULT AkSoundEngine::RemoveListener(System.UInt64,System.UInt64)
extern void AkSoundEngine_RemoveListener_mCE869B27636F51F07B7AA920B3229558E00B7A2D (void);
// 0x000000A0 AKRESULT AkSoundEngine::AddDefaultListener(System.UInt64)
extern void AkSoundEngine_AddDefaultListener_mD6B3FED201AB275C99D95A2B1CEFDB9D677566AC (void);
// 0x000000A1 AKRESULT AkSoundEngine::RemoveDefaultListener(System.UInt64)
extern void AkSoundEngine_RemoveDefaultListener_m78FD26085CF14B2652799A584B0C50BB3BEC1A76 (void);
// 0x000000A2 AKRESULT AkSoundEngine::ResetListenersToDefault(System.UInt64)
extern void AkSoundEngine_ResetListenersToDefault_m9D6B943A52A48956EBF10BD2A1FF70E4A2C26C05 (void);
// 0x000000A3 AKRESULT AkSoundEngine::SetListenerSpatialization(System.UInt64,System.Boolean,AkChannelConfig,System.Single[])
extern void AkSoundEngine_SetListenerSpatialization_m3CF234AA2A30BE33758FA854983E741F1FBACEAE (void);
// 0x000000A4 AKRESULT AkSoundEngine::SetListenerSpatialization(System.UInt64,System.Boolean,AkChannelConfig)
extern void AkSoundEngine_SetListenerSpatialization_m04E86FC4326EC24F22161C346673F27B9324C4C0 (void);
// 0x000000A5 AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single,System.UInt64,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_SetRTPCValue_mE22F952C9DD2D3EE3CCFB1BF2E551A8896652B57 (void);
// 0x000000A6 AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single,System.UInt64,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_SetRTPCValue_mBA78710016BF035162E6C519A4DBDCC2B0521A46 (void);
// 0x000000A7 AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single,System.UInt64,System.Int32)
extern void AkSoundEngine_SetRTPCValue_mA96A54AD6AE0AC180EA34BDFA153A537CC272BA9 (void);
// 0x000000A8 AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single,System.UInt64)
extern void AkSoundEngine_SetRTPCValue_mB528BE43F472886E4F2C0EFA0D079759B8B348EE (void);
// 0x000000A9 AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single)
extern void AkSoundEngine_SetRTPCValue_mFD00540F3921139DB4467CAA06A2DAA43DD5EB19 (void);
// 0x000000AA AKRESULT AkSoundEngine::SetRTPCValue(System.String,System.Single,System.UInt64,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_SetRTPCValue_mB62353A91BF9FFAE5A1112B24FE2C15C095BEE4F (void);
// 0x000000AB AKRESULT AkSoundEngine::SetRTPCValue(System.String,System.Single,System.UInt64,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_SetRTPCValue_mAEF327921358879DA203784C0D452AB7891D0038 (void);
// 0x000000AC AKRESULT AkSoundEngine::SetRTPCValue(System.String,System.Single,System.UInt64,System.Int32)
extern void AkSoundEngine_SetRTPCValue_m698DB4CB439EBE3823F88FF2783DC9627D3755D8 (void);
// 0x000000AD AKRESULT AkSoundEngine::SetRTPCValue(System.String,System.Single,System.UInt64)
extern void AkSoundEngine_SetRTPCValue_mC5A4A0D746BEB769790A10F25417D429DC5A7926 (void);
// 0x000000AE AKRESULT AkSoundEngine::SetRTPCValue(System.String,System.Single)
extern void AkSoundEngine_SetRTPCValue_mF4623CB727493A545AC48C3B170492A1228BF715 (void);
// 0x000000AF AKRESULT AkSoundEngine::SetRTPCValueByPlayingID(System.UInt32,System.Single,System.UInt32,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_SetRTPCValueByPlayingID_mDCEE0FB923A0857F9758825FD6144FAA0E8FD8D2 (void);
// 0x000000B0 AKRESULT AkSoundEngine::SetRTPCValueByPlayingID(System.UInt32,System.Single,System.UInt32,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_SetRTPCValueByPlayingID_m318EE5E60E865B7826473C4FBEA7FBC865360B42 (void);
// 0x000000B1 AKRESULT AkSoundEngine::SetRTPCValueByPlayingID(System.UInt32,System.Single,System.UInt32,System.Int32)
extern void AkSoundEngine_SetRTPCValueByPlayingID_mB574CC326E615ED640B3A9B733E8B98C4B05F0B7 (void);
// 0x000000B2 AKRESULT AkSoundEngine::SetRTPCValueByPlayingID(System.UInt32,System.Single,System.UInt32)
extern void AkSoundEngine_SetRTPCValueByPlayingID_m44380B7C4201E3DBA92214FE140C56C90235D41A (void);
// 0x000000B3 AKRESULT AkSoundEngine::SetRTPCValueByPlayingID(System.String,System.Single,System.UInt32,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_SetRTPCValueByPlayingID_m0C7B75C0080E3D8DF749AA6AB7D6E7ADF171913B (void);
// 0x000000B4 AKRESULT AkSoundEngine::SetRTPCValueByPlayingID(System.String,System.Single,System.UInt32,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_SetRTPCValueByPlayingID_m121400048AB99DC13BC010DE75BDF39C7C16FB76 (void);
// 0x000000B5 AKRESULT AkSoundEngine::SetRTPCValueByPlayingID(System.String,System.Single,System.UInt32,System.Int32)
extern void AkSoundEngine_SetRTPCValueByPlayingID_mB0051441D2BC17DC75ACF6CBD88D51A2E2472A2E (void);
// 0x000000B6 AKRESULT AkSoundEngine::SetRTPCValueByPlayingID(System.String,System.Single,System.UInt32)
extern void AkSoundEngine_SetRTPCValueByPlayingID_m6CE9D7318909707AD1081A42DDDFD99BAC720F3A (void);
// 0x000000B7 AKRESULT AkSoundEngine::ResetRTPCValue(System.UInt32,System.UInt64,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_ResetRTPCValue_mC4D24CAB0F4B91359051404EC93EA33B4CEABFEF (void);
// 0x000000B8 AKRESULT AkSoundEngine::ResetRTPCValue(System.UInt32,System.UInt64,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_ResetRTPCValue_mDF3B675FDD96DB9D2A1E72F273F2D79896E77993 (void);
// 0x000000B9 AKRESULT AkSoundEngine::ResetRTPCValue(System.UInt32,System.UInt64,System.Int32)
extern void AkSoundEngine_ResetRTPCValue_mB41D426330EEF4A2A641E0AB704E9AF71A48AB6E (void);
// 0x000000BA AKRESULT AkSoundEngine::ResetRTPCValue(System.UInt32,System.UInt64)
extern void AkSoundEngine_ResetRTPCValue_mAE0EE7998EF80F6F0368A27D1A7BAFB264526174 (void);
// 0x000000BB AKRESULT AkSoundEngine::ResetRTPCValue(System.UInt32)
extern void AkSoundEngine_ResetRTPCValue_mD483945A258F7AF77D4A1C0F679DF8CC2F69F832 (void);
// 0x000000BC AKRESULT AkSoundEngine::ResetRTPCValue(System.String,System.UInt64,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_ResetRTPCValue_m8D53C70F34956A52AA1A6115D1FAE8FB2BE138B3 (void);
// 0x000000BD AKRESULT AkSoundEngine::ResetRTPCValue(System.String,System.UInt64,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_ResetRTPCValue_mFDB3D0DA2F93DF5B3AE88BEF86B84FFFE0A096E9 (void);
// 0x000000BE AKRESULT AkSoundEngine::ResetRTPCValue(System.String,System.UInt64,System.Int32)
extern void AkSoundEngine_ResetRTPCValue_m3923530F4FAFDE8D5A1FE2651BBC61D22AC60BA1 (void);
// 0x000000BF AKRESULT AkSoundEngine::ResetRTPCValue(System.String,System.UInt64)
extern void AkSoundEngine_ResetRTPCValue_m70ABEC427033E652CB684D841B466EBE8C71E675 (void);
// 0x000000C0 AKRESULT AkSoundEngine::ResetRTPCValue(System.String)
extern void AkSoundEngine_ResetRTPCValue_mB22A69E16604101CF9479CD43EA3A3EE107BE040 (void);
// 0x000000C1 AKRESULT AkSoundEngine::SetSwitch(System.UInt32,System.UInt32,System.UInt64)
extern void AkSoundEngine_SetSwitch_m1B4A0F4F5B95B2A523F42865FD3F51E7F7BC7BA2 (void);
// 0x000000C2 AKRESULT AkSoundEngine::SetSwitch(System.String,System.String,System.UInt64)
extern void AkSoundEngine_SetSwitch_m38C61ECAB906150AAFC57DB409EE2D2BB253E42B (void);
// 0x000000C3 AKRESULT AkSoundEngine::PostTrigger(System.UInt32,System.UInt64)
extern void AkSoundEngine_PostTrigger_mDF8C46E4F0634157EB276AACF782415C08DCD544 (void);
// 0x000000C4 AKRESULT AkSoundEngine::PostTrigger(System.String,System.UInt64)
extern void AkSoundEngine_PostTrigger_mBCF3284269CC5FE75BE690892419D78567147851 (void);
// 0x000000C5 AKRESULT AkSoundEngine::SetState(System.UInt32,System.UInt32)
extern void AkSoundEngine_SetState_m27B10E6734080647D4ED57903BF9EA010F60D08C (void);
// 0x000000C6 AKRESULT AkSoundEngine::SetState(System.String,System.String)
extern void AkSoundEngine_SetState_m80E5086D0A25FA443528A7491D668CB87E49EB18 (void);
// 0x000000C7 AKRESULT AkSoundEngine::SetGameObjectAuxSendValues(System.UInt64,AkAuxSendArray,System.UInt32)
extern void AkSoundEngine_SetGameObjectAuxSendValues_m3E4EBD881DEA28BCD96733A400A49BC7524F9FA3 (void);
// 0x000000C8 AKRESULT AkSoundEngine::SetGameObjectOutputBusVolume(System.UInt64,System.UInt64,System.Single)
extern void AkSoundEngine_SetGameObjectOutputBusVolume_m970F4D85B9B9E6F7A95CF018E33D03649029FA0A (void);
// 0x000000C9 AKRESULT AkSoundEngine::SetActorMixerEffect(System.UInt32,System.UInt32,System.UInt32)
extern void AkSoundEngine_SetActorMixerEffect_mA01445089D6947B7DEBCEFDDCAAEF782BEAE558D (void);
// 0x000000CA AKRESULT AkSoundEngine::SetBusEffect(System.UInt32,System.UInt32,System.UInt32)
extern void AkSoundEngine_SetBusEffect_m5320FEA56D02FE2F8781FB4C654A0EA4A6401545 (void);
// 0x000000CB AKRESULT AkSoundEngine::SetBusEffect(System.String,System.UInt32,System.UInt32)
extern void AkSoundEngine_SetBusEffect_m95634064FF2A62BDB122A1A05B525B7226EBB037 (void);
// 0x000000CC AKRESULT AkSoundEngine::SetOutputDeviceEffect(System.UInt64,System.UInt32,System.UInt32)
extern void AkSoundEngine_SetOutputDeviceEffect_mF722DB7533E5A682F87FF9E84D0281DE256083F3 (void);
// 0x000000CD AKRESULT AkSoundEngine::SetMixer(System.UInt32,System.UInt32)
extern void AkSoundEngine_SetMixer_m222A0AABFFABB2C83EC6812E83D076D871C893D7 (void);
// 0x000000CE AKRESULT AkSoundEngine::SetMixer(System.String,System.UInt32)
extern void AkSoundEngine_SetMixer_m0231AF5FAF98F38092A6C904F53647B90EB082C5 (void);
// 0x000000CF AKRESULT AkSoundEngine::SetBusConfig(System.UInt32,AkChannelConfig)
extern void AkSoundEngine_SetBusConfig_m0E3A3261CF5948224F6424914A89A60588669CA6 (void);
// 0x000000D0 AKRESULT AkSoundEngine::SetBusConfig(System.String,AkChannelConfig)
extern void AkSoundEngine_SetBusConfig_m6FB047EB5E8C453123852B5957366393667A8C14 (void);
// 0x000000D1 AKRESULT AkSoundEngine::SetObjectObstructionAndOcclusion(System.UInt64,System.UInt64,System.Single,System.Single)
extern void AkSoundEngine_SetObjectObstructionAndOcclusion_mC5EFB676DC21EF427F03EDAD5A48CCE381FE14FB (void);
// 0x000000D2 AKRESULT AkSoundEngine::SetMultipleObstructionAndOcclusion(System.UInt64,System.UInt64,AkObstructionOcclusionValuesArray,System.UInt32)
extern void AkSoundEngine_SetMultipleObstructionAndOcclusion_mFB958D14564ABF7D66EB6954EA0BD961DE35478C (void);
// 0x000000D3 AKRESULT AkSoundEngine::StartOutputCapture(System.String)
extern void AkSoundEngine_StartOutputCapture_mB087ECAA718C8A90F78BE0D1C68DC9240537F40E (void);
// 0x000000D4 AKRESULT AkSoundEngine::StopOutputCapture()
extern void AkSoundEngine_StopOutputCapture_m2C1C3431FDE4EF8EF31A5F5E032421B35E9B35B0 (void);
// 0x000000D5 AKRESULT AkSoundEngine::AddOutputCaptureMarker(System.String)
extern void AkSoundEngine_AddOutputCaptureMarker_mE05552748D83ECA950CEEA3460E9898C7E7AE227 (void);
// 0x000000D6 AKRESULT AkSoundEngine::StartProfilerCapture(System.String)
extern void AkSoundEngine_StartProfilerCapture_m8EF63839317118041DC709DCB2398E94682B5E5A (void);
// 0x000000D7 AKRESULT AkSoundEngine::StopProfilerCapture()
extern void AkSoundEngine_StopProfilerCapture_m7F65F392C74043E97AE4B0DE5E3868D9911E05E5 (void);
// 0x000000D8 AKRESULT AkSoundEngine::RemoveOutput(System.UInt64)
extern void AkSoundEngine_RemoveOutput_mDB255D4514D7E7C06BB6AA7BBC79899CCBDD34E0 (void);
// 0x000000D9 AKRESULT AkSoundEngine::ReplaceOutput(AkOutputSettings,System.UInt64,System.UInt64&)
extern void AkSoundEngine_ReplaceOutput_m75B4FB31C80FD86AA16FE0D5A24555CEBBA36073 (void);
// 0x000000DA AKRESULT AkSoundEngine::ReplaceOutput(AkOutputSettings,System.UInt64)
extern void AkSoundEngine_ReplaceOutput_mC513F51C38CC272927363C4140F3D8BF10E03908 (void);
// 0x000000DB System.UInt64 AkSoundEngine::GetOutputID(System.UInt32,System.UInt32)
extern void AkSoundEngine_GetOutputID_m8ABF01C8FF599F69629629AA0B245B6B6AF5F997 (void);
// 0x000000DC System.UInt64 AkSoundEngine::GetOutputID(System.String,System.UInt32)
extern void AkSoundEngine_GetOutputID_mC11AEC910F0D72A9D5CA0AEC34435231A6D4574C (void);
// 0x000000DD AKRESULT AkSoundEngine::SetBusDevice(System.UInt32,System.UInt32)
extern void AkSoundEngine_SetBusDevice_m702EEC740434BEC0599ED2DFD19EA71379867CBC (void);
// 0x000000DE AKRESULT AkSoundEngine::SetBusDevice(System.String,System.String)
extern void AkSoundEngine_SetBusDevice_m3263C9151C78C152DBE87C26B12B45B46EE15554 (void);
// 0x000000DF AKRESULT AkSoundEngine::GetDeviceList(System.UInt32,System.UInt32,System.UInt32&,AkDeviceDescriptionArray)
extern void AkSoundEngine_GetDeviceList_mD488784490C6CD01D881BEF39986DCD5BFFC4388 (void);
// 0x000000E0 AKRESULT AkSoundEngine::GetDeviceList(System.UInt32,System.UInt32&,AkDeviceDescriptionArray)
extern void AkSoundEngine_GetDeviceList_mF47D37DCE498B927D7F859351A92E424421B0E7C (void);
// 0x000000E1 AKRESULT AkSoundEngine::SetOutputVolume(System.UInt64,System.Single)
extern void AkSoundEngine_SetOutputVolume_mCD9F311A52006321A2E3008B7073342E2EF22FC7 (void);
// 0x000000E2 AKRESULT AkSoundEngine::GetDeviceSpatialAudioSupport(System.UInt32)
extern void AkSoundEngine_GetDeviceSpatialAudioSupport_mAA211BD06D43CA808E39C0F339E3FC7EF69FC218 (void);
// 0x000000E3 AKRESULT AkSoundEngine::Suspend(System.Boolean)
extern void AkSoundEngine_Suspend_mEF457E422CCC8EDEA1E14FFB3CDC37AEBF96A471 (void);
// 0x000000E4 AKRESULT AkSoundEngine::Suspend()
extern void AkSoundEngine_Suspend_m51C5883B4AAF4E85DB3F43CF87787B632D6B9B48 (void);
// 0x000000E5 AKRESULT AkSoundEngine::WakeupFromSuspend()
extern void AkSoundEngine_WakeupFromSuspend_m21231525B4D49CBA740B37C84AA5F8239D68188E (void);
// 0x000000E6 System.UInt32 AkSoundEngine::GetBufferTick()
extern void AkSoundEngine_GetBufferTick_m075439DA3714C4F4200A4C8C72893E2B2DEA31C3 (void);
// 0x000000E7 System.UInt64 AkSoundEngine::GetSampleTick()
extern void AkSoundEngine_GetSampleTick_m6D99DEED4AEA7044A00520B90F62A0706878B1E1 (void);
// 0x000000E8 System.Byte AkSoundEngine::get_AK_INVALID_MIDI_CHANNEL()
extern void AkSoundEngine_get_AK_INVALID_MIDI_CHANNEL_m6CA41B83DE649A965FF6C3C0798621A0C9505363 (void);
// 0x000000E9 System.Byte AkSoundEngine::get_AK_INVALID_MIDI_NOTE()
extern void AkSoundEngine_get_AK_INVALID_MIDI_NOTE_m9AB39DA683A874D6CBAC92082B319F1C5D546F85 (void);
// 0x000000EA AKRESULT AkSoundEngine::GetPlayingSegmentInfo(System.UInt32,AkSegmentInfo,System.Boolean)
extern void AkSoundEngine_GetPlayingSegmentInfo_mC2C4B0FF19275BAECE18569033FCA2F7BC5A01A5 (void);
// 0x000000EB AKRESULT AkSoundEngine::GetPlayingSegmentInfo(System.UInt32,AkSegmentInfo)
extern void AkSoundEngine_GetPlayingSegmentInfo_m40EFCAE5E13D7BA7062CC24232D15F71E87AFBF0 (void);
// 0x000000EC AKRESULT AkSoundEngine::PostCode(AkMonitorErrorCode,AkMonitorErrorLevel,System.UInt32,System.UInt64,System.UInt32,System.Boolean)
extern void AkSoundEngine_PostCode_m15B7937F7C48D117E3A69F760F426E89C1804C8C (void);
// 0x000000ED AKRESULT AkSoundEngine::PostCode(AkMonitorErrorCode,AkMonitorErrorLevel,System.UInt32,System.UInt64,System.UInt32)
extern void AkSoundEngine_PostCode_mF3EAA81338B1535C4F7E661B08A3CE97BDD4D488 (void);
// 0x000000EE AKRESULT AkSoundEngine::PostCode(AkMonitorErrorCode,AkMonitorErrorLevel,System.UInt32,System.UInt64)
extern void AkSoundEngine_PostCode_m292542C9B8A9C6E0DAD01FBF5FC0EDF331A70B80 (void);
// 0x000000EF AKRESULT AkSoundEngine::PostCode(AkMonitorErrorCode,AkMonitorErrorLevel,System.UInt32)
extern void AkSoundEngine_PostCode_m59C7AD63283301E44BA41FC03B711DA338EC9964 (void);
// 0x000000F0 AKRESULT AkSoundEngine::PostCode(AkMonitorErrorCode,AkMonitorErrorLevel)
extern void AkSoundEngine_PostCode_mF948BF316F5882DE5F692D45F6CEE78EF00243B9 (void);
// 0x000000F1 AKRESULT AkSoundEngine::PostString(System.String,AkMonitorErrorLevel,System.UInt32,System.UInt64,System.UInt32,System.Boolean)
extern void AkSoundEngine_PostString_m590AF46DE3F6E9211168AABB2D9D8B038A1001E5 (void);
// 0x000000F2 AKRESULT AkSoundEngine::PostString(System.String,AkMonitorErrorLevel,System.UInt32,System.UInt64,System.UInt32)
extern void AkSoundEngine_PostString_m6B79D4026C885894C9CBC2A321162B93ABA4AD1E (void);
// 0x000000F3 AKRESULT AkSoundEngine::PostString(System.String,AkMonitorErrorLevel,System.UInt32,System.UInt64)
extern void AkSoundEngine_PostString_mDB4880B7FA2397A153BB94AA2796E1BC92852C2B (void);
// 0x000000F4 AKRESULT AkSoundEngine::PostString(System.String,AkMonitorErrorLevel,System.UInt32)
extern void AkSoundEngine_PostString_m9E84C34052876FEEE93EF066BA3A4D4CA4A327CA (void);
// 0x000000F5 AKRESULT AkSoundEngine::PostString(System.String,AkMonitorErrorLevel)
extern void AkSoundEngine_PostString_mA522766A3C89D3E855053BC3E2723778D63A6AFD (void);
// 0x000000F6 System.Int32 AkSoundEngine::GetTimeStamp()
extern void AkSoundEngine_GetTimeStamp_m16FE70DD8EAA66FC46FFDDB09A8460054F4201C6 (void);
// 0x000000F7 System.Void AkSoundEngine::MonitorStreamMgrInit(AkStreamMgrSettings)
extern void AkSoundEngine_MonitorStreamMgrInit_m67CECB90B639A082E9C97029D1E0CB8B7BF097C7 (void);
// 0x000000F8 System.Void AkSoundEngine::MonitorStreamingDeviceInit(System.UInt32,AkDeviceSettings)
extern void AkSoundEngine_MonitorStreamingDeviceInit_m1589354538D79EAA791719C3732469F88EB82CAB (void);
// 0x000000F9 System.Void AkSoundEngine::MonitorStreamingDeviceDestroyed(System.UInt32)
extern void AkSoundEngine_MonitorStreamingDeviceDestroyed_m8C92FF2FDBA63272B35735ECA3699CD0808E8717 (void);
// 0x000000FA System.Void AkSoundEngine::MonitorStreamMgrTerm()
extern void AkSoundEngine_MonitorStreamMgrTerm_m0698AAD769B76FBF64CE73D4DD335E2D10096A0E (void);
// 0x000000FB System.UInt32 AkSoundEngine::GetNumNonZeroBits(System.UInt32)
extern void AkSoundEngine_GetNumNonZeroBits_m9909AA5D34173A4173C1693B0377AE781914F684 (void);
// 0x000000FC System.UInt32 AkSoundEngine::GetNextPowerOfTwo(System.UInt32)
extern void AkSoundEngine_GetNextPowerOfTwo_mB8FC992EB27818940F6199070E50BFAAD999B524 (void);
// 0x000000FD System.UInt32 AkSoundEngine::ROTL32(System.UInt32,System.UInt32)
extern void AkSoundEngine_ROTL32_m68E6789F000C00C3F6D5E2B4E778F92984CFB878 (void);
// 0x000000FE System.UInt64 AkSoundEngine::ROTL64(System.UInt64,System.UInt64)
extern void AkSoundEngine_ROTL64_m93B2DE47526B61B630FA125F7B89FC289D3B02B3 (void);
// 0x000000FF System.Void AkSoundEngine::AkGetDefaultHighPriorityThreadProperties(AkThreadProperties)
extern void AkSoundEngine_AkGetDefaultHighPriorityThreadProperties_m4E1AFBC32B7A2AB63CEE7C99206E48A608B4FD64 (void);
// 0x00000100 System.UInt32 AkSoundEngine::ResolveDialogueEvent(System.UInt32,System.UInt32[],System.UInt32,System.UInt32)
extern void AkSoundEngine_ResolveDialogueEvent_mDF3CA4F022FA5465BFDFCDF969C9646FC849E2E1 (void);
// 0x00000101 System.UInt32 AkSoundEngine::ResolveDialogueEvent(System.UInt32,System.UInt32[],System.UInt32)
extern void AkSoundEngine_ResolveDialogueEvent_m970557D3E0F243994163762C3D2EC3B9C3898D9E (void);
// 0x00000102 AKRESULT AkSoundEngine::GetDialogueEventCustomPropertyValue(System.UInt32,System.UInt32,System.Int32&)
extern void AkSoundEngine_GetDialogueEventCustomPropertyValue_m76B2165111D53BC8199A7A3E2ABC296DCBC8C86E (void);
// 0x00000103 AKRESULT AkSoundEngine::GetDialogueEventCustomPropertyValue(System.UInt32,System.UInt32,System.Single&)
extern void AkSoundEngine_GetDialogueEventCustomPropertyValue_m3DFE5885F059A0D994B9C4F7487A4D6BE0386340 (void);
// 0x00000104 AKRESULT AkSoundEngine::GetPosition(System.UInt64,AkTransform)
extern void AkSoundEngine_GetPosition_m109AD797204F44EEAD2BFED98AF9A3FE53249E16 (void);
// 0x00000105 AKRESULT AkSoundEngine::GetListenerPosition(System.UInt64,AkTransform)
extern void AkSoundEngine_GetListenerPosition_m9B810AA1EA5E9FFC41F51063BD9B4DB859659477 (void);
// 0x00000106 AKRESULT AkSoundEngine::GetRTPCValue(System.UInt32,System.UInt64,System.UInt32,System.Single&,System.Int32&)
extern void AkSoundEngine_GetRTPCValue_mBFF46C693C29FAAA7DB3489F12A9247DC227EA6D (void);
// 0x00000107 AKRESULT AkSoundEngine::GetRTPCValue(System.String,System.UInt64,System.UInt32,System.Single&,System.Int32&)
extern void AkSoundEngine_GetRTPCValue_mD849D50AB6D73719932E651E2F3D028D726178ED (void);
// 0x00000108 AKRESULT AkSoundEngine::GetSwitch(System.UInt32,System.UInt64,System.UInt32&)
extern void AkSoundEngine_GetSwitch_mC9FD2BD405E011AA8A4EC7D7A12D74FEB9434D6E (void);
// 0x00000109 AKRESULT AkSoundEngine::GetSwitch(System.String,System.UInt64,System.UInt32&)
extern void AkSoundEngine_GetSwitch_m62B2C421EBA5D3E22E0560BA47786886DC4EF1D6 (void);
// 0x0000010A AKRESULT AkSoundEngine::GetState(System.UInt32,System.UInt32&)
extern void AkSoundEngine_GetState_m5E9B49473E6F29AC201622E9158097E284435965 (void);
// 0x0000010B AKRESULT AkSoundEngine::GetState(System.String,System.UInt32&)
extern void AkSoundEngine_GetState_m7A8078C73DB65C03580A903B467364FBC2BC5E82 (void);
// 0x0000010C AKRESULT AkSoundEngine::GetGameObjectAuxSendValues(System.UInt64,AkAuxSendArray,System.UInt32&)
extern void AkSoundEngine_GetGameObjectAuxSendValues_m6F6AC906EBE92856C87EA2888B42000DA7AA743F (void);
// 0x0000010D AKRESULT AkSoundEngine::GetGameObjectDryLevelValue(System.UInt64,System.UInt64,System.Single&)
extern void AkSoundEngine_GetGameObjectDryLevelValue_m9B40E5DEAF07A499B0755BEAA516DE9E630520A7 (void);
// 0x0000010E AKRESULT AkSoundEngine::GetObjectObstructionAndOcclusion(System.UInt64,System.UInt64,System.Single&,System.Single&)
extern void AkSoundEngine_GetObjectObstructionAndOcclusion_mA75E71E4DA854F2190A6325D6875313EF7D8A7DC (void);
// 0x0000010F AKRESULT AkSoundEngine::QueryAudioObjectIDs(System.UInt32,System.UInt32&,AkObjectInfoArray)
extern void AkSoundEngine_QueryAudioObjectIDs_m8D2DF4840431DB150C7EAD480D76CDCF9115F762 (void);
// 0x00000110 AKRESULT AkSoundEngine::QueryAudioObjectIDs(System.String,System.UInt32&,AkObjectInfoArray)
extern void AkSoundEngine_QueryAudioObjectIDs_m7BFECFC79DFD77FFBC2FDFADA6404833B8FA9F91 (void);
// 0x00000111 AKRESULT AkSoundEngine::GetPositioningInfo(System.UInt32,AkPositioningInfo)
extern void AkSoundEngine_GetPositioningInfo_m891551654D1D9548938D653E97F7ED4A79F4B950 (void);
// 0x00000112 System.Boolean AkSoundEngine::GetIsGameObjectActive(System.UInt64)
extern void AkSoundEngine_GetIsGameObjectActive_mD562909248668EC1D9E09EB7C7401FC1D10FCEEF (void);
// 0x00000113 System.Single AkSoundEngine::GetMaxRadius(System.UInt64)
extern void AkSoundEngine_GetMaxRadius_m6B3549451C0F4058A6ADBD381944FEC774A78CD5 (void);
// 0x00000114 System.UInt32 AkSoundEngine::GetEventIDFromPlayingID(System.UInt32)
extern void AkSoundEngine_GetEventIDFromPlayingID_m61F644ACDD60B4868DC8082F4107BE2AEBE6B321 (void);
// 0x00000115 System.UInt64 AkSoundEngine::GetGameObjectFromPlayingID(System.UInt32)
extern void AkSoundEngine_GetGameObjectFromPlayingID_m1DF62805ED65A6046054625BFFCDADECD0CFFFFB (void);
// 0x00000116 AKRESULT AkSoundEngine::GetPlayingIDsFromGameObject(System.UInt64,System.UInt32&,System.UInt32[])
extern void AkSoundEngine_GetPlayingIDsFromGameObject_m28F82D43A637D7196F51EF8BA67E9B3147E51EBD (void);
// 0x00000117 AKRESULT AkSoundEngine::GetCustomPropertyValue(System.UInt32,System.UInt32,System.Int32&)
extern void AkSoundEngine_GetCustomPropertyValue_mFB8A74257EE75C8EC3A5546E84969E8BF093CE26 (void);
// 0x00000118 AKRESULT AkSoundEngine::GetCustomPropertyValue(System.UInt32,System.UInt32,System.Single&)
extern void AkSoundEngine_GetCustomPropertyValue_mD1643FE85A9530D61699F5D7C678E622E664A0ED (void);
// 0x00000119 System.Void AkSoundEngine::AK_SPEAKER_SETUP_FIX_LEFT_TO_CENTER(System.UInt32&)
extern void AkSoundEngine_AK_SPEAKER_SETUP_FIX_LEFT_TO_CENTER_m4ABE09E96F5F353DC8A861FBA20483A440E8292A (void);
// 0x0000011A System.Void AkSoundEngine::AK_SPEAKER_SETUP_FIX_REAR_TO_SIDE(System.UInt32&)
extern void AkSoundEngine_AK_SPEAKER_SETUP_FIX_REAR_TO_SIDE_m4A658C62AC9992D1AF184B04E902F74E7C426C84 (void);
// 0x0000011B System.Void AkSoundEngine::AK_SPEAKER_SETUP_CONVERT_TO_SUPPORTED(System.UInt32&)
extern void AkSoundEngine_AK_SPEAKER_SETUP_CONVERT_TO_SUPPORTED_m525BEDEEB755902BA9064061BF258D6C02646959 (void);
// 0x0000011C System.Byte AkSoundEngine::ChannelMaskToNumChannels(System.UInt32)
extern void AkSoundEngine_ChannelMaskToNumChannels_m85123C0432C093C63F9878E30360CD40532886F9 (void);
// 0x0000011D System.UInt32 AkSoundEngine::ChannelMaskFromNumChannels(System.UInt32)
extern void AkSoundEngine_ChannelMaskFromNumChannels_m22C997D94F9BD02BEADF941DCC255D5BF3F9B468 (void);
// 0x0000011E System.Byte AkSoundEngine::ChannelBitToIndex(System.UInt32,System.UInt32)
extern void AkSoundEngine_ChannelBitToIndex_mD78FB98C1A90BF4D2E938B4B934F293588E137CD (void);
// 0x0000011F System.Boolean AkSoundEngine::HasSurroundChannels(System.UInt32)
extern void AkSoundEngine_HasSurroundChannels_m35EF19D50CF6C2BF6C6A0B2E34E5A8B7C7D0B70B (void);
// 0x00000120 System.Boolean AkSoundEngine::HasStrictlyOnePairOfSurroundChannels(System.UInt32)
extern void AkSoundEngine_HasStrictlyOnePairOfSurroundChannels_m6455DD44C1C43C1BA1706AB415C029DE2A1D0B5E (void);
// 0x00000121 System.Boolean AkSoundEngine::HasSideAndRearChannels(System.UInt32)
extern void AkSoundEngine_HasSideAndRearChannels_m424295DC3D407AA1415377ED88DDCD3E23436E38 (void);
// 0x00000122 System.Boolean AkSoundEngine::HasHeightChannels(System.UInt32)
extern void AkSoundEngine_HasHeightChannels_m8BF4F362BAE4D7D8B233405AED24953680D8FFF5 (void);
// 0x00000123 System.UInt32 AkSoundEngine::BackToSideChannels(System.UInt32)
extern void AkSoundEngine_BackToSideChannels_m2FA5218B631F0E8DB96FD9D4D6320F203A09E8BA (void);
// 0x00000124 System.UInt32 AkSoundEngine::StdChannelIndexToDisplayIndex(AkChannelOrdering,System.UInt32,System.UInt32)
extern void AkSoundEngine_StdChannelIndexToDisplayIndex_m789AF539D3539568E342F6EAACAD89EEE3020B70 (void);
// 0x00000125 System.Single AkSoundEngine::get_kDefaultMaxPathLength()
extern void AkSoundEngine_get_kDefaultMaxPathLength_mD8FC62C0227A25C1809A00759DBAE183EE5F03FD (void);
// 0x00000126 System.UInt32 AkSoundEngine::get_kDefaultDiffractionMaxEdges()
extern void AkSoundEngine_get_kDefaultDiffractionMaxEdges_m79130E47983C14A566B8B4E5F03256D7DD3459DD (void);
// 0x00000127 System.UInt32 AkSoundEngine::get_kDefaultDiffractionMaxPaths()
extern void AkSoundEngine_get_kDefaultDiffractionMaxPaths_m3A5782C7FEB541C9727108507852EEE968F7C76D (void);
// 0x00000128 System.Single AkSoundEngine::get_kMaxDiffraction()
extern void AkSoundEngine_get_kMaxDiffraction_mED22E2C657F730422ED208331D2C57923F133C90 (void);
// 0x00000129 System.UInt32 AkSoundEngine::get_kDiffractionMaxEdges()
extern void AkSoundEngine_get_kDiffractionMaxEdges_mF24CEB4C8461CEF65D7B35FE3A9B568403E7C138 (void);
// 0x0000012A System.UInt32 AkSoundEngine::get_kDiffractionMaxPaths()
extern void AkSoundEngine_get_kDiffractionMaxPaths_mD7505CB9798E648D7B2AA757E41B424EDE6742E4 (void);
// 0x0000012B System.UInt32 AkSoundEngine::get_kPortalToPortalDiffractionMaxPaths()
extern void AkSoundEngine_get_kPortalToPortalDiffractionMaxPaths_m8B3E0C10AEED427912912F10CD85A6CD91768247 (void);
// 0x0000012C AKRESULT AkSoundEngine::SetGameObjectRadius(System.UInt64,System.Single,System.Single)
extern void AkSoundEngine_SetGameObjectRadius_m8F34BDD6408357BDE1C02DC12A12D44508E0CC09 (void);
// 0x0000012D AKRESULT AkSoundEngine::SetImageSource(System.UInt32,AkImageSourceSettings,System.UInt32,System.UInt64,System.UInt64)
extern void AkSoundEngine_SetImageSource_mE73890A9D4C1774C4014FB89C3149C29BDDA0A2E (void);
// 0x0000012E AKRESULT AkSoundEngine::RemoveImageSource(System.UInt32,System.UInt32,System.UInt64)
extern void AkSoundEngine_RemoveImageSource_m6DD58F5F12FFD33B9F53D39DEC2EE78D4E218250 (void);
// 0x0000012F AKRESULT AkSoundEngine::ClearImageSources(System.UInt32,System.UInt64)
extern void AkSoundEngine_ClearImageSources_mDF9D16E5A960E10426955067C52351256AF3B2A8 (void);
// 0x00000130 AKRESULT AkSoundEngine::ClearImageSources(System.UInt32)
extern void AkSoundEngine_ClearImageSources_m5BC8C8F1259C85B7F1BE0D9E6A6CE137E8DCC628 (void);
// 0x00000131 AKRESULT AkSoundEngine::ClearImageSources()
extern void AkSoundEngine_ClearImageSources_m9D5A5D2414DC29D26698CA01DF3F7235D446009B (void);
// 0x00000132 AKRESULT AkSoundEngine::RemoveGeometry(System.UInt64)
extern void AkSoundEngine_RemoveGeometry_m91FC5D08377D0324D7C2BB09EB43BD2EBB528705 (void);
// 0x00000133 AKRESULT AkSoundEngine::QueryReflectionPaths(System.UInt64,System.UInt32,UnityEngine.Vector3&,UnityEngine.Vector3&,AkReflectionPathInfoArray,System.UInt32&)
extern void AkSoundEngine_QueryReflectionPaths_mAB7FF69640C192A87E43987DF7310AE89365179A (void);
// 0x00000134 AKRESULT AkSoundEngine::RemoveRoom(System.UInt64)
extern void AkSoundEngine_RemoveRoom_m397A0D324FFAEF81164AD88C8E4EB1FF4DF6E111 (void);
// 0x00000135 AKRESULT AkSoundEngine::RemovePortal(System.UInt64)
extern void AkSoundEngine_RemovePortal_m6ED6DFC5B0DC35E182182B7BCBDD9CEFFC099B32 (void);
// 0x00000136 AKRESULT AkSoundEngine::SetGameObjectInRoom(System.UInt64,System.UInt64)
extern void AkSoundEngine_SetGameObjectInRoom_mE5FC77B51C17E04ED7CCFAE781BFD8A8E3780796 (void);
// 0x00000137 AKRESULT AkSoundEngine::SetReflectionsOrder(System.UInt32,System.Boolean)
extern void AkSoundEngine_SetReflectionsOrder_m2E9718EF7E519F2A6B5B65F34C7971E1F4BD074A (void);
// 0x00000138 AKRESULT AkSoundEngine::SetNumberOfPrimaryRays(System.UInt32)
extern void AkSoundEngine_SetNumberOfPrimaryRays_m9F33D1AD9AEBC82867465549931A1E4A9AA27CC2 (void);
// 0x00000139 AKRESULT AkSoundEngine::SetEarlyReflectionsAuxSend(System.UInt64,System.UInt32)
extern void AkSoundEngine_SetEarlyReflectionsAuxSend_mA9050A7C9E8D07FEA16A2168C3E89E7F414C7970 (void);
// 0x0000013A AKRESULT AkSoundEngine::SetEarlyReflectionsVolume(System.UInt64,System.Single)
extern void AkSoundEngine_SetEarlyReflectionsVolume_mD32DD3934D93B84A256DF5B67643D16FA803A07A (void);
// 0x0000013B AKRESULT AkSoundEngine::SetPortalObstructionAndOcclusion(System.UInt64,System.Single,System.Single)
extern void AkSoundEngine_SetPortalObstructionAndOcclusion_mBFEAC2BFF17D66C95A87844747808992AF18E4E8 (void);
// 0x0000013C AKRESULT AkSoundEngine::SetGameObjectToPortalObstruction(System.UInt64,System.UInt64,System.Single)
extern void AkSoundEngine_SetGameObjectToPortalObstruction_m710E1FD3B56CBFD6F2C000C80535E488B11CBB61 (void);
// 0x0000013D AKRESULT AkSoundEngine::SetPortalToPortalObstruction(System.UInt64,System.UInt64,System.Single)
extern void AkSoundEngine_SetPortalToPortalObstruction_m3FB0121BFAADD8D5F6767BE97D091512E8E8CF35 (void);
// 0x0000013E AKRESULT AkSoundEngine::QueryWetDiffraction(System.UInt64,System.Single&)
extern void AkSoundEngine_QueryWetDiffraction_m2EBC72F2BEF4278CCC9117DCFF0ED808A310E737 (void);
// 0x0000013F AKRESULT AkSoundEngine::QueryDiffractionPaths(System.UInt64,System.UInt32,UnityEngine.Vector3&,UnityEngine.Vector3&,AkDiffractionPathInfoArray,System.UInt32&)
extern void AkSoundEngine_QueryDiffractionPaths_m44D0032C443AE22FCBD4537F7A00965663EA678E (void);
// 0x00000140 AKRESULT AkSoundEngine::ResetStochasticEngine()
extern void AkSoundEngine_ResetStochasticEngine_mEEC189E18E7F2C3DF479CA4D057149655532AC00 (void);
// 0x00000141 System.UInt32 AkSoundEngine::GetDeviceIDFromName(System.String)
extern void AkSoundEngine_GetDeviceIDFromName_mF3AAE8D16F9CA77DEB5B260CE3D1B50A1F4F225B (void);
// 0x00000142 System.String AkSoundEngine::GetWindowsDeviceName(System.Int32,System.UInt32&,AkAudioDeviceState)
extern void AkSoundEngine_GetWindowsDeviceName_mC224D13204773548E2F5188D8766D8A61CB86042 (void);
// 0x00000143 System.String AkSoundEngine::GetWindowsDeviceName(System.Int32,System.UInt32&)
extern void AkSoundEngine_GetWindowsDeviceName_mEA8BCBDA1789B00BDF6B1F12EA88653CCFAE2C12 (void);
// 0x00000144 System.UInt32 AkSoundEngine::GetWindowsDeviceCount(AkAudioDeviceState)
extern void AkSoundEngine_GetWindowsDeviceCount_m38FB53C671C79DDCB7D6167A63A6017F85A6029B (void);
// 0x00000145 System.UInt32 AkSoundEngine::GetWindowsDeviceCount()
extern void AkSoundEngine_GetWindowsDeviceCount_m2053107DE392545575524DA3B89A33ED01A24C74 (void);
// 0x00000146 System.Void AkSoundEngine::SetErrorLogger(AkLogger_ErrorLoggerInteropDelegate)
extern void AkSoundEngine_SetErrorLogger_mD3FD7A553CF5A894322511CF80D688A30B0D03EA (void);
// 0x00000147 System.Void AkSoundEngine::SetErrorLogger()
extern void AkSoundEngine_SetErrorLogger_m937290CDE61876AFEF0F9256228FB4021D09BB7E (void);
// 0x00000148 System.Void AkSoundEngine::SetAudioInputCallbacks(AkAudioInputManager_AudioSamplesInteropDelegate,AkAudioInputManager_AudioFormatInteropDelegate)
extern void AkSoundEngine_SetAudioInputCallbacks_m5F6FFF905E9C78C994CCCF79D3AEFFC3FCEEE2C9 (void);
// 0x00000149 AKRESULT AkSoundEngine::Init(AkInitializationSettings)
extern void AkSoundEngine_Init_mD6D36E461297B1F6A8B5A5910A43EB588C439BC6 (void);
// 0x0000014A AKRESULT AkSoundEngine::InitSpatialAudio(AkSpatialAudioInitSettings)
extern void AkSoundEngine_InitSpatialAudio_mF9EB33FE95F73DC416AAD6DFC42D93CF37ADABDB (void);
// 0x0000014B AKRESULT AkSoundEngine::InitCommunication(AkCommunicationSettings)
extern void AkSoundEngine_InitCommunication_mEC2E07B9BDD999C7954EC585BC05BE7D89EEAA75 (void);
// 0x0000014C System.Void AkSoundEngine::Term()
extern void AkSoundEngine_Term_mABA25764A840947855A1DBCC37F5866241AEA5E8 (void);
// 0x0000014D AKRESULT AkSoundEngine::RegisterGameObjInternal(System.UInt64)
extern void AkSoundEngine_RegisterGameObjInternal_mAE02846F000E1DE41860178234EF4DAEBF8B55D1 (void);
// 0x0000014E AKRESULT AkSoundEngine::UnregisterGameObjInternal(System.UInt64)
extern void AkSoundEngine_UnregisterGameObjInternal_mD276375C2D713093B92E5EA5CC848DEDE053276D (void);
// 0x0000014F AKRESULT AkSoundEngine::RegisterGameObjInternal_WithName(System.UInt64,System.String)
extern void AkSoundEngine_RegisterGameObjInternal_WithName_m5048E6A0DACF7663ECC9DC17BA7E04A0A9F07101 (void);
// 0x00000150 AKRESULT AkSoundEngine::SetBasePath(System.String)
extern void AkSoundEngine_SetBasePath_m66C80A368D63637645A85793EA00A47558FABCB3 (void);
// 0x00000151 AKRESULT AkSoundEngine::SetCurrentLanguage(System.String)
extern void AkSoundEngine_SetCurrentLanguage_m5999F17AE4E41381F12F72A5B3233EAAD65C9449 (void);
// 0x00000152 AKRESULT AkSoundEngine::LoadFilePackage(System.String,System.UInt32&)
extern void AkSoundEngine_LoadFilePackage_mA9B42A3F2C8319E624A2E8CBB118AD0FD6FA2317 (void);
// 0x00000153 AKRESULT AkSoundEngine::AddBasePath(System.String)
extern void AkSoundEngine_AddBasePath_m6315F9F24652C726A7A3DAD05C6CA5D2DA1FF80D (void);
// 0x00000154 AKRESULT AkSoundEngine::SetGameName(System.String)
extern void AkSoundEngine_SetGameName_m9C8D19B05BADB9FAFF2242203D998F889F3C26DE (void);
// 0x00000155 AKRESULT AkSoundEngine::SetDecodedBankPath(System.String)
extern void AkSoundEngine_SetDecodedBankPath_mD7812F391BDE561139F391960CEAB46FEDE31DCF (void);
// 0x00000156 AKRESULT AkSoundEngine::LoadAndDecodeBank(System.String,System.Boolean,System.UInt32&)
extern void AkSoundEngine_LoadAndDecodeBank_mE93D5F05065EDFDE0E212C682558DBA2D85137E8 (void);
// 0x00000157 AKRESULT AkSoundEngine::LoadAndDecodeBankFromMemory(System.IntPtr,System.UInt32,System.Boolean,System.String,System.Boolean,System.UInt32&)
extern void AkSoundEngine_LoadAndDecodeBankFromMemory_mBC06859EBCF8FE8E7A418211861ABD69E1A2154A (void);
// 0x00000158 System.UInt32 AkSoundEngine::PostEventOnRoom(System.String,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray,System.UInt32)
extern void AkSoundEngine_PostEventOnRoom_mF89A76B5D42B12EDF2203C15AD2641E01ADC6987 (void);
// 0x00000159 System.UInt32 AkSoundEngine::PostEventOnRoom(System.String,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray)
extern void AkSoundEngine_PostEventOnRoom_m8344C7CC27D8272396B37AA8033D005A2B21189C (void);
// 0x0000015A System.UInt32 AkSoundEngine::PostEventOnRoom(System.String,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkSoundEngine_PostEventOnRoom_m8FB367F04ECE724BFC6702A2DB5ACEEDA66B00AB (void);
// 0x0000015B System.UInt32 AkSoundEngine::PostEventOnRoom(System.String,System.UInt64)
extern void AkSoundEngine_PostEventOnRoom_m6DB30727325FE2C44B8FF90EC466FE471FF83E4A (void);
// 0x0000015C System.String AkSoundEngine::GetCurrentLanguage()
extern void AkSoundEngine_GetCurrentLanguage_mCF2C8AE8D61B971AB5111A688CED08A12C11E2B1 (void);
// 0x0000015D AKRESULT AkSoundEngine::UnloadFilePackage(System.UInt32)
extern void AkSoundEngine_UnloadFilePackage_m0F9A2FE046BD9119E4213590E0C638DA16308CF2 (void);
// 0x0000015E AKRESULT AkSoundEngine::UnloadAllFilePackages()
extern void AkSoundEngine_UnloadAllFilePackages_m1BAFDDF3DDBBA93BF4C4F83F127D612F6D5AB451 (void);
// 0x0000015F AKRESULT AkSoundEngine::SetObjectPosition(System.UInt64,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void AkSoundEngine_SetObjectPosition_m3EB797F358A57DB3DBA35F9EE26950583B00E000 (void);
// 0x00000160 AKRESULT AkSoundEngine::GetSourceMultiplePlayPositions(System.UInt32,System.UInt32[],System.UInt32[],System.Int32[],System.UInt32&,System.Boolean)
extern void AkSoundEngine_GetSourceMultiplePlayPositions_mE18ED3711106C9AC87B037833D1ED3778A962244 (void);
// 0x00000161 AKRESULT AkSoundEngine::GetSourceMultiplePlayPositions(System.UInt32,System.UInt32[],System.UInt32[],System.Int32[],System.UInt32&)
extern void AkSoundEngine_GetSourceMultiplePlayPositions_m7BCA31C9BEC55915D43B6BFB5A494B02D5489EE7 (void);
// 0x00000162 AKRESULT AkSoundEngine::SetListeners(System.UInt64,System.UInt64[],System.UInt32)
extern void AkSoundEngine_SetListeners_m187185D9A6F877DAF1DD58C0A4B49AD2DA72554B (void);
// 0x00000163 AKRESULT AkSoundEngine::SetDefaultListeners(System.UInt64[],System.UInt32)
extern void AkSoundEngine_SetDefaultListeners_mA52EE297C10EF2181730C3B76D8995C9611B418D (void);
// 0x00000164 AKRESULT AkSoundEngine::AddOutput(AkOutputSettings,System.UInt64&,System.UInt64[],System.UInt32)
extern void AkSoundEngine_AddOutput_m41B47C9C1765F7CD12A7CC91FA2FD229BD5510B3 (void);
// 0x00000165 AKRESULT AkSoundEngine::AddOutput(AkOutputSettings,System.UInt64&,System.UInt64[])
extern void AkSoundEngine_AddOutput_m5DC9F16A8953695F3F5F60F0E645FE2E8AB24BB7 (void);
// 0x00000166 AKRESULT AkSoundEngine::AddOutput(AkOutputSettings,System.UInt64&)
extern void AkSoundEngine_AddOutput_m570D666D8D9DE5ECEC90A4E031A5822F0745F3E7 (void);
// 0x00000167 AKRESULT AkSoundEngine::AddOutput(AkOutputSettings)
extern void AkSoundEngine_AddOutput_mA91CE03FF34AE8BB7977A7EC7EC41FFCC3F01F22 (void);
// 0x00000168 System.Void AkSoundEngine::GetDefaultStreamSettings(AkStreamMgrSettings)
extern void AkSoundEngine_GetDefaultStreamSettings_mD285B199646EC280039B9CD77CCB29E88EF016E1 (void);
// 0x00000169 System.Void AkSoundEngine::GetDefaultDeviceSettings(AkDeviceSettings)
extern void AkSoundEngine_GetDefaultDeviceSettings_m0DF1B2F2CC61C9766E4DDDE2373C506984CAEE8D (void);
// 0x0000016A System.Void AkSoundEngine::GetDefaultMusicSettings(AkMusicSettings)
extern void AkSoundEngine_GetDefaultMusicSettings_m9EC5D720468350C5B1F27D8735E74A6D1A635B29 (void);
// 0x0000016B System.Void AkSoundEngine::GetDefaultInitSettings(AkInitSettings)
extern void AkSoundEngine_GetDefaultInitSettings_m2855F8E6B3D91C45C65100C0ECD4E4C7ADE5FA34 (void);
// 0x0000016C System.Void AkSoundEngine::GetDefaultPlatformInitSettings(AkPlatformInitSettings)
extern void AkSoundEngine_GetDefaultPlatformInitSettings_m4C75C0BF69E016FECD2A465F52363599D4DC88B3 (void);
// 0x0000016D System.UInt32 AkSoundEngine::GetMajorMinorVersion()
extern void AkSoundEngine_GetMajorMinorVersion_m062BD72411DD1DE1684B9DB91B73F58FD1D48B4E (void);
// 0x0000016E System.UInt32 AkSoundEngine::GetSubminorBuildVersion()
extern void AkSoundEngine_GetSubminorBuildVersion_mDF82E7C1DFB67C9D251C3B8AD8A8EDBD9C5EDCD6 (void);
// 0x0000016F System.Void AkSoundEngine::StartResourceMonitoring()
extern void AkSoundEngine_StartResourceMonitoring_m1DC9A55490046DAE46028527935EA168FC72745B (void);
// 0x00000170 System.Void AkSoundEngine::StopResourceMonitoring()
extern void AkSoundEngine_StopResourceMonitoring_mC637BD82D21C46C78E67513FE53D11E1CF845F52 (void);
// 0x00000171 System.Void AkSoundEngine::GetResourceMonitorDataSummary(AkResourceMonitorDataSummary)
extern void AkSoundEngine_GetResourceMonitorDataSummary_m4D00D1FCB12B1507DB7A4B1DD195C2DAEEA7EF5E (void);
// 0x00000172 AKRESULT AkSoundEngine::SetRoomPortal(System.UInt64,AkTransform,AkExtent,System.Boolean,System.UInt64,System.UInt64)
extern void AkSoundEngine_SetRoomPortal_m128CCE2063D13299F6B82B51F14831762CB3665C (void);
// 0x00000173 AKRESULT AkSoundEngine::SetRoom(System.UInt64,AkRoomParams,System.UInt64,System.String)
extern void AkSoundEngine_SetRoom_mA86064A1B4BD95C8CDE9FC1D10015B76A2C719E0 (void);
// 0x00000174 AKRESULT AkSoundEngine::RegisterSpatialAudioListener(System.UInt64)
extern void AkSoundEngine_RegisterSpatialAudioListener_mFE8F588B76E0947ACA1621AF19D1AB39D3497987 (void);
// 0x00000175 AKRESULT AkSoundEngine::UnregisterSpatialAudioListener(System.UInt64)
extern void AkSoundEngine_UnregisterSpatialAudioListener_mAB61CE861A98364FA6EAB5B991456AC6219CB9E4 (void);
// 0x00000176 AKRESULT AkSoundEngine::SetGeometry(System.UInt64,AkTriangleArray,System.UInt32,UnityEngine.Vector3[],System.UInt32,AkAcousticSurfaceArray,System.UInt32,System.UInt64,System.Boolean,System.Boolean,System.Boolean)
extern void AkSoundEngine_SetGeometry_m556200E8FA608FC35431ACBDC02D8DF969D97CFF (void);
// 0x00000177 System.UInt32 AkSoundEngine::PostEventOnRoom(System.UInt32,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray,System.UInt32)
extern void AkSoundEngine_PostEventOnRoom_mCC4DA02BD18ACCB5CC505888D4FD889F47441D30 (void);
// 0x00000178 System.UInt32 AkSoundEngine::PostEventOnRoom(System.UInt32,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray)
extern void AkSoundEngine_PostEventOnRoom_m707CEE5D5930506419477864E6D644CA3FAA9A5F (void);
// 0x00000179 System.UInt32 AkSoundEngine::PostEventOnRoom(System.UInt32,System.UInt64,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkSoundEngine_PostEventOnRoom_m69EAD9D51B1C04CA22D9019A2F2135F9AEF1C58F (void);
// 0x0000017A System.UInt32 AkSoundEngine::PostEventOnRoom(System.UInt32,System.UInt64)
extern void AkSoundEngine_PostEventOnRoom_m14ACE53AF68AD9038741174E8EADD83B7B48B341 (void);
// 0x0000017B System.String AkSoundEngine::StringFromIntPtrString(System.IntPtr)
extern void AkSoundEngine_StringFromIntPtrString_m183A92BA446C63F725F7EDE8F6F9A498D9ED1E4B (void);
// 0x0000017C System.String AkSoundEngine::StringFromIntPtrWString(System.IntPtr)
extern void AkSoundEngine_StringFromIntPtrWString_mF89EECB36344B06D70D748A8508C94F88992E5BE (void);
// 0x0000017D System.UInt64 AkSoundEngine::InternalGameObjectHash(UnityEngine.GameObject)
extern void AkSoundEngine_InternalGameObjectHash_mE72A602D2F6EBF7D0D9B37C19DD74BE4635834E0 (void);
// 0x0000017E System.Void AkSoundEngine::set_GameObjectHash(AkSoundEngine_GameObjectHashFunction)
extern void AkSoundEngine_set_GameObjectHash_m48A5FE35BBE4F869BD2CFCD080C71D01ABFA6D78 (void);
// 0x0000017F System.UInt64 AkSoundEngine::GetAkGameObjectID(UnityEngine.GameObject)
extern void AkSoundEngine_GetAkGameObjectID_m202ED5D95E2835E58B630C7F2DE7D840D8410E9B (void);
// 0x00000180 AKRESULT AkSoundEngine::RegisterGameObj(UnityEngine.GameObject)
extern void AkSoundEngine_RegisterGameObj_mAD5BD4AAB5492D28803637116C210CDF6B0A92C7 (void);
// 0x00000181 AKRESULT AkSoundEngine::RegisterGameObj(UnityEngine.GameObject,System.String)
extern void AkSoundEngine_RegisterGameObj_m88BEB55AD3B0C6813F0547E8678AFAFED0A26DAA (void);
// 0x00000182 AKRESULT AkSoundEngine::UnregisterGameObj(UnityEngine.GameObject)
extern void AkSoundEngine_UnregisterGameObj_m6383A7D2557EE31C484343C0AE9637669328FA0B (void);
// 0x00000183 System.String AkSoundEngine::get_WwiseVersion()
extern void AkSoundEngine_get_WwiseVersion_m6F901F22BD523F0AF0B2AD8C39519F565DF7E9A3 (void);
// 0x00000184 AKRESULT AkSoundEngine::SetObjectPosition(UnityEngine.GameObject,UnityEngine.Transform)
extern void AkSoundEngine_SetObjectPosition_m7F41BD33AEA4554013B9D17A2B84411726309209 (void);
// 0x00000185 AKRESULT AkSoundEngine::SetObjectPosition(UnityEngine.GameObject,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void AkSoundEngine_SetObjectPosition_mF67940DFD2F6B863C8DF00539C89188A2A89FDEA (void);
// 0x00000186 System.Void AkSoundEngine::PreGameObjectAPICall(UnityEngine.GameObject,System.UInt64)
extern void AkSoundEngine_PreGameObjectAPICall_m48E29E58EC8F748DCA759529B0321A4984909C47 (void);
// 0x00000187 System.Void AkSoundEngine::PreGameObjectAPICallUserHook(UnityEngine.GameObject,System.UInt64)
extern void AkSoundEngine_PreGameObjectAPICallUserHook_m047234B7CF7DB32AD9BADB35170DBD93F03B4A3B (void);
// 0x00000188 System.Void AkSoundEngine::PostRegisterGameObjUserHook(AKRESULT,UnityEngine.GameObject,System.UInt64)
extern void AkSoundEngine_PostRegisterGameObjUserHook_m5E91D7C7266F2EE52754DDE8F491EF677CE00535 (void);
// 0x00000189 System.Void AkSoundEngine::PostUnregisterGameObjUserHook(AKRESULT,UnityEngine.GameObject,System.UInt64)
extern void AkSoundEngine_PostUnregisterGameObjUserHook_m5EE9340C7545A549A229C835D20A6A4497A23343 (void);
// 0x0000018A System.UInt32 AkSoundEngine::DynamicSequenceOpen(UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object,AkDynamicSequenceType)
extern void AkSoundEngine_DynamicSequenceOpen_m70DBF118E596EA85059EB2CD1518C9033876CC90 (void);
// 0x0000018B System.UInt32 AkSoundEngine::DynamicSequenceOpen(UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkSoundEngine_DynamicSequenceOpen_mF992B868159EBD920398CB102F5B27CD1A4EEA00 (void);
// 0x0000018C System.UInt32 AkSoundEngine::DynamicSequenceOpen(UnityEngine.GameObject)
extern void AkSoundEngine_DynamicSequenceOpen_mD4751B11808CAC02CE48E80C00CA360269149E79 (void);
// 0x0000018D System.UInt32 AkSoundEngine::PostEvent(System.UInt32,UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray,System.UInt32)
extern void AkSoundEngine_PostEvent_m7E8938273920D752507439A8EE036EA2818CEE24 (void);
// 0x0000018E System.UInt32 AkSoundEngine::PostEvent(System.UInt32,UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray)
extern void AkSoundEngine_PostEvent_m905B15F711D8FADBD2B40278AC9E0B877392904B (void);
// 0x0000018F System.UInt32 AkSoundEngine::PostEvent(System.UInt32,UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkSoundEngine_PostEvent_m6D65008EA2DF3ABE7F52D42987114D689C5C7F7B (void);
// 0x00000190 System.UInt32 AkSoundEngine::PostEvent(System.UInt32,UnityEngine.GameObject)
extern void AkSoundEngine_PostEvent_m70980C1B8E64FC6974A693637F1C3EF81B599EC5 (void);
// 0x00000191 System.UInt32 AkSoundEngine::PostEvent(System.String,UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray,System.UInt32)
extern void AkSoundEngine_PostEvent_m72417B76B5265CE2A0BAC218C57599CB7D6A7D23 (void);
// 0x00000192 System.UInt32 AkSoundEngine::PostEvent(System.String,UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32,AkExternalSourceInfoArray)
extern void AkSoundEngine_PostEvent_m64457F8AE379D36449CCB761DFFFB87D680AFDA8 (void);
// 0x00000193 System.UInt32 AkSoundEngine::PostEvent(System.String,UnityEngine.GameObject,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkSoundEngine_PostEvent_m94C0D31BE717BFD2B2CBE7DBFD34E8F562B1C7DF (void);
// 0x00000194 System.UInt32 AkSoundEngine::PostEvent(System.String,UnityEngine.GameObject)
extern void AkSoundEngine_PostEvent_m77C9AB5C87BF7BD63E1B3ED2C9E22A1919B08045 (void);
// 0x00000195 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType,UnityEngine.GameObject,System.Int32,AkCurveInterpolation,System.UInt32)
extern void AkSoundEngine_ExecuteActionOnEvent_m02CB0A8128BF2C9219282588AF57131F260ADB15 (void);
// 0x00000196 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType,UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_ExecuteActionOnEvent_mEB060B0245616DD68C515B6BA20C3D0569B04D8E (void);
// 0x00000197 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType,UnityEngine.GameObject,System.Int32)
extern void AkSoundEngine_ExecuteActionOnEvent_m28F981C2A3A7066FC0576B16DCE0B6CA7078BABA (void);
// 0x00000198 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.UInt32,AkActionOnEventType,UnityEngine.GameObject)
extern void AkSoundEngine_ExecuteActionOnEvent_m33770AFE0C9733490BAEA09A3E1CB8E722CE03E9 (void);
// 0x00000199 AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.String,AkActionOnEventType,UnityEngine.GameObject,System.Int32,AkCurveInterpolation,System.UInt32)
extern void AkSoundEngine_ExecuteActionOnEvent_m8BA604E2E8EF30EE4176D032A9C19EEBAF8A531C (void);
// 0x0000019A AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.String,AkActionOnEventType,UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_ExecuteActionOnEvent_m8D8AE05B721C2B2E903DE20010E8E9A557194BB9 (void);
// 0x0000019B AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.String,AkActionOnEventType,UnityEngine.GameObject,System.Int32)
extern void AkSoundEngine_ExecuteActionOnEvent_m9CDB7576D7F70BEF888765AB90843DE19E26628C (void);
// 0x0000019C AKRESULT AkSoundEngine::ExecuteActionOnEvent(System.String,AkActionOnEventType,UnityEngine.GameObject)
extern void AkSoundEngine_ExecuteActionOnEvent_m1154660EB1BBCBCDEEB0F9817CFA022B1622B447 (void);
// 0x0000019D AKRESULT AkSoundEngine::PostMIDIOnEvent(System.UInt32,UnityEngine.GameObject,AkMIDIPostArray,System.UInt16)
extern void AkSoundEngine_PostMIDIOnEvent_mFE7175497B65E0FBB1DC5CBD7DB23470C9629BD0 (void);
// 0x0000019E AKRESULT AkSoundEngine::StopMIDIOnEvent(System.UInt32,UnityEngine.GameObject)
extern void AkSoundEngine_StopMIDIOnEvent_m8E8BD26C821D2DB66D754EB520049AE749D48F32 (void);
// 0x0000019F AKRESULT AkSoundEngine::StopMIDIOnEvent(System.UInt32,UnityEngine.GameObject,System.UInt32)
extern void AkSoundEngine_StopMIDIOnEvent_mBA27C9BB70257A516E54EF22F347CCBD4CA686EA (void);
// 0x000001A0 AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,UnityEngine.GameObject,System.Int32,System.Boolean,System.UInt32)
extern void AkSoundEngine_SeekOnEvent_m3DF6A7B9ED9E2415CB858248DCABB1360AAFC209 (void);
// 0x000001A1 AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,UnityEngine.GameObject,System.Int32,System.Boolean)
extern void AkSoundEngine_SeekOnEvent_m453D6C943CD7F02906C8CF41EFFFA334B2E891C1 (void);
// 0x000001A2 AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,UnityEngine.GameObject,System.Int32)
extern void AkSoundEngine_SeekOnEvent_m77B3EBCB168E88BD1AF64E5D7E9693EF80365718 (void);
// 0x000001A3 AKRESULT AkSoundEngine::SeekOnEvent(System.String,UnityEngine.GameObject,System.Int32,System.Boolean,System.UInt32)
extern void AkSoundEngine_SeekOnEvent_m393F70C546722F5B9F610AD52A3A142158D515DE (void);
// 0x000001A4 AKRESULT AkSoundEngine::SeekOnEvent(System.String,UnityEngine.GameObject,System.Int32,System.Boolean)
extern void AkSoundEngine_SeekOnEvent_m7B51779C89CD3D60A6682915154D0CC4B60013DA (void);
// 0x000001A5 AKRESULT AkSoundEngine::SeekOnEvent(System.String,UnityEngine.GameObject,System.Int32)
extern void AkSoundEngine_SeekOnEvent_mB106554577E9A9688C5084D6E80C2C132F3A2591 (void);
// 0x000001A6 AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,UnityEngine.GameObject,System.Single,System.Boolean,System.UInt32)
extern void AkSoundEngine_SeekOnEvent_m2FC4012852789222D3BD81F03795FABAD574FAA6 (void);
// 0x000001A7 AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,UnityEngine.GameObject,System.Single,System.Boolean)
extern void AkSoundEngine_SeekOnEvent_m1FCF4A0F7EDF41AE5D1637960820FE97609AD35F (void);
// 0x000001A8 AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,UnityEngine.GameObject,System.Single)
extern void AkSoundEngine_SeekOnEvent_m5ABF68DD7A2149E6D7D4AE61D2F597E0B1F60574 (void);
// 0x000001A9 AKRESULT AkSoundEngine::SeekOnEvent(System.String,UnityEngine.GameObject,System.Single,System.Boolean,System.UInt32)
extern void AkSoundEngine_SeekOnEvent_m6EDB30E001422008851CC17E6DFE71EDC0DD4576 (void);
// 0x000001AA AKRESULT AkSoundEngine::SeekOnEvent(System.String,UnityEngine.GameObject,System.Single,System.Boolean)
extern void AkSoundEngine_SeekOnEvent_mD505F18DB178AB78677D8D7E60699A030D7D54E0 (void);
// 0x000001AB AKRESULT AkSoundEngine::SeekOnEvent(System.String,UnityEngine.GameObject,System.Single)
extern void AkSoundEngine_SeekOnEvent_mDB34C6E9B47975209219D155691EB2ABCBEB7AFB (void);
// 0x000001AC System.Void AkSoundEngine::CancelEventCallbackGameObject(UnityEngine.GameObject)
extern void AkSoundEngine_CancelEventCallbackGameObject_mB386120F4928236AC867D065568FCDA3FA60CF57 (void);
// 0x000001AD System.Void AkSoundEngine::StopAll(UnityEngine.GameObject)
extern void AkSoundEngine_StopAll_m2D130395DD6DE8E94BE6A78E2FC9B33FD35D34B4 (void);
// 0x000001AE AKRESULT AkSoundEngine::SendPluginCustomGameData(System.UInt32,UnityEngine.GameObject,AkPluginType,System.UInt32,System.UInt32,System.IntPtr,System.UInt32)
extern void AkSoundEngine_SendPluginCustomGameData_m70E8659586E519C836866791002C40C15FA099F9 (void);
// 0x000001AF AKRESULT AkSoundEngine::SetMultiplePositions(UnityEngine.GameObject,AkPositionArray,System.UInt16,AkMultiPositionType)
extern void AkSoundEngine_SetMultiplePositions_m37B992510C662E4D2165646BC7D926E793B438E1 (void);
// 0x000001B0 AKRESULT AkSoundEngine::SetMultiplePositions(UnityEngine.GameObject,AkPositionArray,System.UInt16)
extern void AkSoundEngine_SetMultiplePositions_mB0D9AB01D2267F7499C48C8519240804208A39B4 (void);
// 0x000001B1 AKRESULT AkSoundEngine::SetMultiplePositions(UnityEngine.GameObject,AkChannelEmitterArray,System.UInt16,AkMultiPositionType)
extern void AkSoundEngine_SetMultiplePositions_mDB29164F0C3E70FE459B2D453C32A3DC8052959C (void);
// 0x000001B2 AKRESULT AkSoundEngine::SetMultiplePositions(UnityEngine.GameObject,AkChannelEmitterArray,System.UInt16)
extern void AkSoundEngine_SetMultiplePositions_mF4F06464238BB58FE6811B3AEFAA949B3E96764B (void);
// 0x000001B3 AKRESULT AkSoundEngine::SetScalingFactor(UnityEngine.GameObject,System.Single)
extern void AkSoundEngine_SetScalingFactor_m4F8EE1CEF8C646A95678BD02CDBE5D54724C9076 (void);
// 0x000001B4 AKRESULT AkSoundEngine::AddListener(UnityEngine.GameObject,UnityEngine.GameObject)
extern void AkSoundEngine_AddListener_m343A49419DBD154D53B621451C337F382BDE710D (void);
// 0x000001B5 AKRESULT AkSoundEngine::RemoveListener(UnityEngine.GameObject,UnityEngine.GameObject)
extern void AkSoundEngine_RemoveListener_m8B8C4D475D8FA6B4110D409A88237A8F4C440CF7 (void);
// 0x000001B6 AKRESULT AkSoundEngine::AddDefaultListener(UnityEngine.GameObject)
extern void AkSoundEngine_AddDefaultListener_m005008CF57169C57449856A8FF89AFDFE60A03FB (void);
// 0x000001B7 AKRESULT AkSoundEngine::RemoveDefaultListener(UnityEngine.GameObject)
extern void AkSoundEngine_RemoveDefaultListener_m21D63A4CE24A3CD3814413E6D61B27D05E6B4A96 (void);
// 0x000001B8 AKRESULT AkSoundEngine::ResetListenersToDefault(UnityEngine.GameObject)
extern void AkSoundEngine_ResetListenersToDefault_m5531389F0B55F072D54B74A346AD7D0DBA0E161A (void);
// 0x000001B9 AKRESULT AkSoundEngine::SetListenerSpatialization(UnityEngine.GameObject,System.Boolean,AkChannelConfig,System.Single[])
extern void AkSoundEngine_SetListenerSpatialization_m316DB4780D3BA7C7079FFBECB9DF23EB14DC2219 (void);
// 0x000001BA AKRESULT AkSoundEngine::SetListenerSpatialization(UnityEngine.GameObject,System.Boolean,AkChannelConfig)
extern void AkSoundEngine_SetListenerSpatialization_mDE1CD479FABCD30D3634DB97C2B1F81DE89EFFDD (void);
// 0x000001BB AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single,UnityEngine.GameObject,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_SetRTPCValue_mACA3423638CCEEC641C69BCD01DFFD1C507A9FE0 (void);
// 0x000001BC AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single,UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_SetRTPCValue_m81662F12666CAA2A756329480A828A440FCB4424 (void);
// 0x000001BD AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single,UnityEngine.GameObject,System.Int32)
extern void AkSoundEngine_SetRTPCValue_m189001A4EDABE657C691CD9D918DAB941BFC5F42 (void);
// 0x000001BE AKRESULT AkSoundEngine::SetRTPCValue(System.UInt32,System.Single,UnityEngine.GameObject)
extern void AkSoundEngine_SetRTPCValue_m18561150273DA0C176DADCBDF426E70613AF356D (void);
// 0x000001BF AKRESULT AkSoundEngine::SetRTPCValue(System.String,System.Single,UnityEngine.GameObject,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_SetRTPCValue_m7D7C415C8DB1F2C0175AEE4FCE788CC164433FD8 (void);
// 0x000001C0 AKRESULT AkSoundEngine::SetRTPCValue(System.String,System.Single,UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_SetRTPCValue_mD304970A58A46F9CB7A74CC602B3ED62C82DEE33 (void);
// 0x000001C1 AKRESULT AkSoundEngine::SetRTPCValue(System.String,System.Single,UnityEngine.GameObject,System.Int32)
extern void AkSoundEngine_SetRTPCValue_m5904921E5AA612C5E25E46AAE6A6D4577665E31C (void);
// 0x000001C2 AKRESULT AkSoundEngine::SetRTPCValue(System.String,System.Single,UnityEngine.GameObject)
extern void AkSoundEngine_SetRTPCValue_m09EAB61110C70A0FC3492A743348E8443CE3BA17 (void);
// 0x000001C3 AKRESULT AkSoundEngine::ResetRTPCValue(System.UInt32,UnityEngine.GameObject,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_ResetRTPCValue_m1DEE4DFCCBC86F5EE1689D99C0DAAF5C8AEE46A3 (void);
// 0x000001C4 AKRESULT AkSoundEngine::ResetRTPCValue(System.UInt32,UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_ResetRTPCValue_mD5DC8E93F51062F3ABA2A9550178E9A06A4F9319 (void);
// 0x000001C5 AKRESULT AkSoundEngine::ResetRTPCValue(System.UInt32,UnityEngine.GameObject,System.Int32)
extern void AkSoundEngine_ResetRTPCValue_mFFB131240CA97BB0DA47254BB616416006E2DF10 (void);
// 0x000001C6 AKRESULT AkSoundEngine::ResetRTPCValue(System.UInt32,UnityEngine.GameObject)
extern void AkSoundEngine_ResetRTPCValue_mA7F5EE2DA7853EF272EC2BD3E1CCE1EF5B58A6CA (void);
// 0x000001C7 AKRESULT AkSoundEngine::ResetRTPCValue(System.String,UnityEngine.GameObject,System.Int32,AkCurveInterpolation,System.Boolean)
extern void AkSoundEngine_ResetRTPCValue_m4CDCB7863073E3A4C1839D3D1B5623861103D9E1 (void);
// 0x000001C8 AKRESULT AkSoundEngine::ResetRTPCValue(System.String,UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
extern void AkSoundEngine_ResetRTPCValue_m35DB08F1688272A36E7276E2A67400126C475747 (void);
// 0x000001C9 AKRESULT AkSoundEngine::ResetRTPCValue(System.String,UnityEngine.GameObject,System.Int32)
extern void AkSoundEngine_ResetRTPCValue_mC590A821B98EF06F069B56CDD9A020E8D0717B3F (void);
// 0x000001CA AKRESULT AkSoundEngine::ResetRTPCValue(System.String,UnityEngine.GameObject)
extern void AkSoundEngine_ResetRTPCValue_mB467791C655970C5CA6B97E7A2E49B55BC526845 (void);
// 0x000001CB AKRESULT AkSoundEngine::SetSwitch(System.UInt32,System.UInt32,UnityEngine.GameObject)
extern void AkSoundEngine_SetSwitch_mB25E783656DD320341B7578E08A40F5EDD5046CA (void);
// 0x000001CC AKRESULT AkSoundEngine::SetSwitch(System.String,System.String,UnityEngine.GameObject)
extern void AkSoundEngine_SetSwitch_m2EB082DE338445EC23A9AE5ADD07C64790C5A7FD (void);
// 0x000001CD AKRESULT AkSoundEngine::PostTrigger(System.UInt32,UnityEngine.GameObject)
extern void AkSoundEngine_PostTrigger_mAE35A465050B381130B8C1710F29A7C204600C0D (void);
// 0x000001CE AKRESULT AkSoundEngine::PostTrigger(System.String,UnityEngine.GameObject)
extern void AkSoundEngine_PostTrigger_mE1CF4655B2A55CE30BDBE79A382CCC5CBF2F1F0D (void);
// 0x000001CF AKRESULT AkSoundEngine::SetGameObjectAuxSendValues(UnityEngine.GameObject,AkAuxSendArray,System.UInt32)
extern void AkSoundEngine_SetGameObjectAuxSendValues_m053C3E4B29BD8E50254487D6BF2645AE4D192FBA (void);
// 0x000001D0 AKRESULT AkSoundEngine::SetGameObjectOutputBusVolume(UnityEngine.GameObject,UnityEngine.GameObject,System.Single)
extern void AkSoundEngine_SetGameObjectOutputBusVolume_m587AB4AF7161076085A8B8A96A300C910156E5AE (void);
// 0x000001D1 AKRESULT AkSoundEngine::SetObjectObstructionAndOcclusion(UnityEngine.GameObject,UnityEngine.GameObject,System.Single,System.Single)
extern void AkSoundEngine_SetObjectObstructionAndOcclusion_m68C2AFD0234DD4DFECED998D1DE2B6B5BB250CCF (void);
// 0x000001D2 AKRESULT AkSoundEngine::SetMultipleObstructionAndOcclusion(UnityEngine.GameObject,UnityEngine.GameObject,AkObstructionOcclusionValuesArray,System.UInt32)
extern void AkSoundEngine_SetMultipleObstructionAndOcclusion_mCA19F81D65393F1E4D915C2E7116204A99857834 (void);
// 0x000001D3 AKRESULT AkSoundEngine::PostCode(AkMonitorErrorCode,AkMonitorErrorLevel,System.UInt32,UnityEngine.GameObject,System.UInt32,System.Boolean)
extern void AkSoundEngine_PostCode_mC7B9BE2BF8A7E00808C9A82370D3A251FCD8BD04 (void);
// 0x000001D4 AKRESULT AkSoundEngine::PostCode(AkMonitorErrorCode,AkMonitorErrorLevel,System.UInt32,UnityEngine.GameObject,System.UInt32)
extern void AkSoundEngine_PostCode_mD470EC99465EA7A8C46FF3F6598A7833B0119308 (void);
// 0x000001D5 AKRESULT AkSoundEngine::PostCode(AkMonitorErrorCode,AkMonitorErrorLevel,System.UInt32,UnityEngine.GameObject)
extern void AkSoundEngine_PostCode_mDA23321BABDE8231AE6D9265D88432A0E401E7E9 (void);
// 0x000001D6 AKRESULT AkSoundEngine::PostString(System.String,AkMonitorErrorLevel,System.UInt32,UnityEngine.GameObject,System.UInt32,System.Boolean)
extern void AkSoundEngine_PostString_m3D5671A6B5AAAAB2AA898E0B7232A02573E1F5F2 (void);
// 0x000001D7 AKRESULT AkSoundEngine::PostString(System.String,AkMonitorErrorLevel,System.UInt32,UnityEngine.GameObject,System.UInt32)
extern void AkSoundEngine_PostString_mDB0703C7E02E99CC91A098A6426F8328A90364AE (void);
// 0x000001D8 AKRESULT AkSoundEngine::PostString(System.String,AkMonitorErrorLevel,System.UInt32,UnityEngine.GameObject)
extern void AkSoundEngine_PostString_m03F125C01DEE62C392A70BAF0E5D3D3C0A0CAF9B (void);
// 0x000001D9 AKRESULT AkSoundEngine::GetPosition(UnityEngine.GameObject,AkTransform)
extern void AkSoundEngine_GetPosition_mDE86210C40A674F6866DEEE0E3E2210A4FA918F5 (void);
// 0x000001DA AKRESULT AkSoundEngine::GetListenerPosition(UnityEngine.GameObject,AkTransform)
extern void AkSoundEngine_GetListenerPosition_mBBC6BF6A90A9D8FC7FDEC7DE4565E29449AF9949 (void);
// 0x000001DB AKRESULT AkSoundEngine::GetRTPCValue(System.UInt32,UnityEngine.GameObject,System.UInt32,System.Single&,System.Int32&)
extern void AkSoundEngine_GetRTPCValue_m09BD553FBF1926B313A4C7FEE2D23221449B03B3 (void);
// 0x000001DC AKRESULT AkSoundEngine::GetRTPCValue(System.String,UnityEngine.GameObject,System.UInt32,System.Single&,System.Int32&)
extern void AkSoundEngine_GetRTPCValue_m1C3F5A34B688C1FADDF5A18CE2D2095F4172E140 (void);
// 0x000001DD AKRESULT AkSoundEngine::GetSwitch(System.UInt32,UnityEngine.GameObject,System.UInt32&)
extern void AkSoundEngine_GetSwitch_m7E6BCCEC6C1C16553FDF882C91A2FB3FCD5F24BF (void);
// 0x000001DE AKRESULT AkSoundEngine::GetSwitch(System.String,UnityEngine.GameObject,System.UInt32&)
extern void AkSoundEngine_GetSwitch_m97F22923A4AB409FB38274E0F2DF68779CE42FC0 (void);
// 0x000001DF AKRESULT AkSoundEngine::GetGameObjectAuxSendValues(UnityEngine.GameObject,AkAuxSendArray,System.UInt32&)
extern void AkSoundEngine_GetGameObjectAuxSendValues_m886009AD9D7DDB286A0701C88E77D99BE7DD602A (void);
// 0x000001E0 AKRESULT AkSoundEngine::GetGameObjectDryLevelValue(UnityEngine.GameObject,UnityEngine.GameObject,System.Single&)
extern void AkSoundEngine_GetGameObjectDryLevelValue_mE43F45A75C37F78542A54F4A58B5660949664462 (void);
// 0x000001E1 AKRESULT AkSoundEngine::GetObjectObstructionAndOcclusion(UnityEngine.GameObject,UnityEngine.GameObject,System.Single&,System.Single&)
extern void AkSoundEngine_GetObjectObstructionAndOcclusion_m1EF941D7227EA14DC57C789D8B15358B3EA665DE (void);
// 0x000001E2 System.Boolean AkSoundEngine::GetIsGameObjectActive(UnityEngine.GameObject)
extern void AkSoundEngine_GetIsGameObjectActive_mE2851C5C354E9BA89EDF55273F73716221E0719F (void);
// 0x000001E3 System.Single AkSoundEngine::GetMaxRadius(UnityEngine.GameObject)
extern void AkSoundEngine_GetMaxRadius_m8E67D78A61DA80FEDA3BEC7572D3D0FAE752A818 (void);
// 0x000001E4 AKRESULT AkSoundEngine::GetPlayingIDsFromGameObject(UnityEngine.GameObject,System.UInt32&,System.UInt32[])
extern void AkSoundEngine_GetPlayingIDsFromGameObject_m6645623B42D3AEB0D68EC11D13E0C430347D09B9 (void);
// 0x000001E5 AKRESULT AkSoundEngine::SetImageSource(System.UInt32,AkImageSourceSettings,System.UInt32,System.UInt64,UnityEngine.GameObject)
extern void AkSoundEngine_SetImageSource_mAA9FDCB5B945E6B32223245DC75FA8405BE3F514 (void);
// 0x000001E6 AKRESULT AkSoundEngine::RemoveImageSource(System.UInt32,System.UInt32,UnityEngine.GameObject)
extern void AkSoundEngine_RemoveImageSource_m3C917A1F8385FBEAC30912C605051877EAC209C1 (void);
// 0x000001E7 AKRESULT AkSoundEngine::ClearImageSources(System.UInt32,UnityEngine.GameObject)
extern void AkSoundEngine_ClearImageSources_m4C678C186121754512FBA716C9F68E5A2F3EDF12 (void);
// 0x000001E8 AKRESULT AkSoundEngine::QueryReflectionPaths(UnityEngine.GameObject,System.UInt32,UnityEngine.Vector3&,UnityEngine.Vector3&,AkReflectionPathInfoArray,System.UInt32&)
extern void AkSoundEngine_QueryReflectionPaths_mDD42C223832C9D720A2A95992A551363C91D35C5 (void);
// 0x000001E9 AKRESULT AkSoundEngine::SetGameObjectInRoom(UnityEngine.GameObject,System.UInt64)
extern void AkSoundEngine_SetGameObjectInRoom_m0D945984EB6E7C0FD0FDFF899B46CD48563A3288 (void);
// 0x000001EA AKRESULT AkSoundEngine::SetEarlyReflectionsAuxSend(UnityEngine.GameObject,System.UInt32)
extern void AkSoundEngine_SetEarlyReflectionsAuxSend_m7EA560C236DBA6841219022DD0E96F212CD6708D (void);
// 0x000001EB AKRESULT AkSoundEngine::SetEarlyReflectionsVolume(UnityEngine.GameObject,System.Single)
extern void AkSoundEngine_SetEarlyReflectionsVolume_m4DA386234E9E8ACE0F7C8B255BFC1A7F14F38B99 (void);
// 0x000001EC AKRESULT AkSoundEngine::QueryDiffractionPaths(UnityEngine.GameObject,System.UInt32,UnityEngine.Vector3&,UnityEngine.Vector3&,AkDiffractionPathInfoArray,System.UInt32&)
extern void AkSoundEngine_QueryDiffractionPaths_m6B8779419173C2B117366767D02A490A946AE345 (void);
// 0x000001ED AKRESULT AkSoundEngine::RegisterGameObjInternal(UnityEngine.GameObject)
extern void AkSoundEngine_RegisterGameObjInternal_m00157626B44732F7AA53017715DCB6E415019980 (void);
// 0x000001EE AKRESULT AkSoundEngine::UnregisterGameObjInternal(UnityEngine.GameObject)
extern void AkSoundEngine_UnregisterGameObjInternal_mA709DC3EEFB0D1B2AFBE423AD257D26A94693E97 (void);
// 0x000001EF AKRESULT AkSoundEngine::RegisterGameObjInternal_WithName(UnityEngine.GameObject,System.String)
extern void AkSoundEngine_RegisterGameObjInternal_WithName_m8D82B28EA957C76BE8BF546D9EE938F13E0766E6 (void);
// 0x000001F0 AKRESULT AkSoundEngine::SetObjectPosition(UnityEngine.GameObject,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void AkSoundEngine_SetObjectPosition_m178B9216AE9EAC6431D5B3A2A4383DCB5E6A829E (void);
// 0x000001F1 AKRESULT AkSoundEngine::SetListeners(UnityEngine.GameObject,System.UInt64[],System.UInt32)
extern void AkSoundEngine_SetListeners_mCC4E464748FF7A3E77BA7FAA80B7499FDA6651A7 (void);
// 0x000001F2 AKRESULT AkSoundEngine::RegisterSpatialAudioListener(UnityEngine.GameObject)
extern void AkSoundEngine_RegisterSpatialAudioListener_m93D0EEEA4455F143DEF63C32AAA2AD30E9AF4BA7 (void);
// 0x000001F3 AKRESULT AkSoundEngine::UnregisterSpatialAudioListener(UnityEngine.GameObject)
extern void AkSoundEngine_UnregisterSpatialAudioListener_m1E79F0AE30EA2CD5FA9EE70EFC4B34C444BF0C46 (void);
// 0x000001F4 System.String AkSoundEngine::StringFromIntPtrOSString(System.IntPtr)
extern void AkSoundEngine_StringFromIntPtrOSString_m4999C4319EDA8D57987FD3D9C4B36371FAFA9A03 (void);
// 0x000001F5 System.Void AkSoundEngine::.ctor()
extern void AkSoundEngine__ctor_mE1859641E97F76C8EE89106C0674F63B4E3EC8F5 (void);
// 0x000001F6 System.Void AkSoundEngine::.cctor()
extern void AkSoundEngine__cctor_m3C9D08B15D23ED6BEEE177C7C1553A66B94BD8A4 (void);
// 0x000001F7 System.Void Ak3DAudioSinkCapabilities::.ctor(System.IntPtr,System.Boolean)
extern void Ak3DAudioSinkCapabilities__ctor_m16694143648C91B4FA740F176F4EEED56336DD92 (void);
// 0x000001F8 System.IntPtr Ak3DAudioSinkCapabilities::getCPtr(Ak3DAudioSinkCapabilities)
extern void Ak3DAudioSinkCapabilities_getCPtr_m947EFAE48FF07713F15133E4F758F0D14ED6BC20 (void);
// 0x000001F9 System.Void Ak3DAudioSinkCapabilities::setCPtr(System.IntPtr)
extern void Ak3DAudioSinkCapabilities_setCPtr_m996DC3C1054D382F791C55750281E30C399A9331 (void);
// 0x000001FA System.Void Ak3DAudioSinkCapabilities::Finalize()
extern void Ak3DAudioSinkCapabilities_Finalize_m558A5306E6E79F96B3E30002E008ADAA209BB9D9 (void);
// 0x000001FB System.Void Ak3DAudioSinkCapabilities::Dispose()
extern void Ak3DAudioSinkCapabilities_Dispose_m50CFDEBCED305BF1309B24AE7DAB4BFF50DF713D (void);
// 0x000001FC System.Void Ak3DAudioSinkCapabilities::set_channelConfig(AkChannelConfig)
extern void Ak3DAudioSinkCapabilities_set_channelConfig_m22DC5035947ECC1E4FA4076846E2BEA34517CB5B (void);
// 0x000001FD AkChannelConfig Ak3DAudioSinkCapabilities::get_channelConfig()
extern void Ak3DAudioSinkCapabilities_get_channelConfig_m0801BE2F1357F81BB065D63FFF2FE7457AA9952E (void);
// 0x000001FE System.Void Ak3DAudioSinkCapabilities::set_uMaxSystemAudioObjects(System.UInt32)
extern void Ak3DAudioSinkCapabilities_set_uMaxSystemAudioObjects_mE419B9E1811466EB321BD450CA63F05DE44259C5 (void);
// 0x000001FF System.UInt32 Ak3DAudioSinkCapabilities::get_uMaxSystemAudioObjects()
extern void Ak3DAudioSinkCapabilities_get_uMaxSystemAudioObjects_mBC8A2826E7454E4E3F9234C82560FB2ED37F771E (void);
// 0x00000200 System.Void Ak3DAudioSinkCapabilities::set_uAvailableSystemAudioObjects(System.UInt32)
extern void Ak3DAudioSinkCapabilities_set_uAvailableSystemAudioObjects_mBECB4E1219983DF572DBFCEBF4D275CE7E224216 (void);
// 0x00000201 System.UInt32 Ak3DAudioSinkCapabilities::get_uAvailableSystemAudioObjects()
extern void Ak3DAudioSinkCapabilities_get_uAvailableSystemAudioObjects_m2DE901E901CB9368630FE7855E836B2D3C437C06 (void);
// 0x00000202 System.Void Ak3DAudioSinkCapabilities::set_bPassthrough(System.Boolean)
extern void Ak3DAudioSinkCapabilities_set_bPassthrough_m1B22B75353F8C7A44C397FFEE4143588F49CA49C (void);
// 0x00000203 System.Boolean Ak3DAudioSinkCapabilities::get_bPassthrough()
extern void Ak3DAudioSinkCapabilities_get_bPassthrough_mDA791DD6FE005231CA431416C72E9A7EBD842AAC (void);
// 0x00000204 System.Void Ak3DAudioSinkCapabilities::set_bMultiChannelObjects(System.Boolean)
extern void Ak3DAudioSinkCapabilities_set_bMultiChannelObjects_m102785E59834AD3E3CE9C03CE0CD55952F8CA517 (void);
// 0x00000205 System.Boolean Ak3DAudioSinkCapabilities::get_bMultiChannelObjects()
extern void Ak3DAudioSinkCapabilities_get_bMultiChannelObjects_m79370435DE12C93525BCA8C2A6F0C434792721EE (void);
// 0x00000206 System.Void Ak3DAudioSinkCapabilities::.ctor()
extern void Ak3DAudioSinkCapabilities__ctor_mA7F77E796CB960B42769FAF85D4A188C5F824A5B (void);
// 0x00000207 System.Void Ak3dData::.ctor(System.IntPtr,System.Boolean)
extern void Ak3dData__ctor_m8E9BEBD59BCADF5F316ED31883F2A4B3884A14E1 (void);
// 0x00000208 System.IntPtr Ak3dData::getCPtr(Ak3dData)
extern void Ak3dData_getCPtr_mD1935D4FBDF8398ECDA0ACE09E868CE3A77CCA35 (void);
// 0x00000209 System.Void Ak3dData::setCPtr(System.IntPtr)
extern void Ak3dData_setCPtr_mD03F98158687002FBF60C62FA60B215F90BAD568 (void);
// 0x0000020A System.Void Ak3dData::Finalize()
extern void Ak3dData_Finalize_m00DFF3312A482106E7177C5ECBC9E4EE6CE9532A (void);
// 0x0000020B System.Void Ak3dData::Dispose()
extern void Ak3dData_Dispose_mB66E0D999D5CEDE040D6DEAFE0A6EBEF6FD92926 (void);
// 0x0000020C System.Void Ak3dData::.ctor()
extern void Ak3dData__ctor_m62C04C13D1CD844B299273BFBD43C86E360C56B4 (void);
// 0x0000020D System.Void Ak3dData::set_xform(AkTransform)
extern void Ak3dData_set_xform_m252383DB7E6B7AEC0B26F423C428245865B5E155 (void);
// 0x0000020E AkTransform Ak3dData::get_xform()
extern void Ak3dData_get_xform_m31181402FF279E5B537E2030A51BF60887885BDF (void);
// 0x0000020F System.Void Ak3dData::set_spread(System.Single)
extern void Ak3dData_set_spread_m42C3187F81188CB63D40E9F2A7F1E535687C7E8B (void);
// 0x00000210 System.Single Ak3dData::get_spread()
extern void Ak3dData_get_spread_mD7649F72064B12AC1566F8663A52F00EBAEE3578 (void);
// 0x00000211 System.Void Ak3dData::set_focus(System.Single)
extern void Ak3dData_set_focus_m36A8FF5BE32A33018EA12761741C0601AB01FC3C (void);
// 0x00000212 System.Single Ak3dData::get_focus()
extern void Ak3dData_get_focus_mAF724B465FC3C1404A0D835A95393379F65696BC (void);
// 0x00000213 System.Void Ak3dData::set_uEmitterChannelMask(System.UInt32)
extern void Ak3dData_set_uEmitterChannelMask_mCE8D9D1194E84E2CC77853D6A2C27DD6A74CB7A2 (void);
// 0x00000214 System.UInt32 Ak3dData::get_uEmitterChannelMask()
extern void Ak3dData_get_uEmitterChannelMask_m65C7F82A985B4401BEDE51F7F32A5D65711E7DD2 (void);
// 0x00000215 System.Void AkAcousticSurface::.ctor(System.IntPtr,System.Boolean)
extern void AkAcousticSurface__ctor_m5A6D4B22AC084006DBE03F4E17DE01B02BEAB46A (void);
// 0x00000216 System.IntPtr AkAcousticSurface::getCPtr(AkAcousticSurface)
extern void AkAcousticSurface_getCPtr_mB9D49F92E0A94E083ADD6D5C360FFD69742534E0 (void);
// 0x00000217 System.Void AkAcousticSurface::setCPtr(System.IntPtr)
extern void AkAcousticSurface_setCPtr_mA94C65DC27090353A084B34B4C8917079D67D031 (void);
// 0x00000218 System.Void AkAcousticSurface::Finalize()
extern void AkAcousticSurface_Finalize_m4FD1F459B57E054E2F67A893809F28EA5531312B (void);
// 0x00000219 System.Void AkAcousticSurface::Dispose()
extern void AkAcousticSurface_Dispose_mFBF85CC5B42109FB987792F6645F66246B3EB790 (void);
// 0x0000021A System.Void AkAcousticSurface::.ctor()
extern void AkAcousticSurface__ctor_mD2EB9DDA17B1B4D300E77BF9DFBEC69EBDD11F06 (void);
// 0x0000021B System.Void AkAcousticSurface::set_textureID(System.UInt32)
extern void AkAcousticSurface_set_textureID_mCCECA46BF32160949FD1BF1CFDC7F1CCF0F7C143 (void);
// 0x0000021C System.UInt32 AkAcousticSurface::get_textureID()
extern void AkAcousticSurface_get_textureID_m00707E9CC7EFBBFC498208A72178E8430ED318DD (void);
// 0x0000021D System.Void AkAcousticSurface::set_transmissionLoss(System.Single)
extern void AkAcousticSurface_set_transmissionLoss_m9E15D05230348B50106CE7A482E173C877CCE14A (void);
// 0x0000021E System.Single AkAcousticSurface::get_transmissionLoss()
extern void AkAcousticSurface_get_transmissionLoss_m1211BA1DD3C2B0F92EAB33713E5CE46AA135392E (void);
// 0x0000021F System.Void AkAcousticSurface::set_strName(System.String)
extern void AkAcousticSurface_set_strName_m0F7BB1848D37C23D6B6E2A752EB764FB04527A25 (void);
// 0x00000220 System.String AkAcousticSurface::get_strName()
extern void AkAcousticSurface_get_strName_m9E84B24F32F98FA4C4276DD3D883A74238178AF6 (void);
// 0x00000221 System.Void AkAcousticSurface::Clear()
extern void AkAcousticSurface_Clear_m08399E44D2BE967189B6B8D7548634D4C22135EF (void);
// 0x00000222 System.Void AkAcousticSurface::DeleteName()
extern void AkAcousticSurface_DeleteName_mC47EACF6A6BE67FC9F205B541B43F23ED2266B61 (void);
// 0x00000223 System.Int32 AkAcousticSurface::GetSizeOf()
extern void AkAcousticSurface_GetSizeOf_m7F99E8CEE43FA6491C1521F72EBE75E22EDCD234 (void);
// 0x00000224 System.Void AkAcousticSurface::Clone(AkAcousticSurface)
extern void AkAcousticSurface_Clone_m257368A068FA94251CC6775DABDC9F121B81E87B (void);
// 0x00000225 System.Void AkAudioFormat::.ctor(System.IntPtr,System.Boolean)
extern void AkAudioFormat__ctor_m5734790434D8BDD2A019D3D4435E23AC73BEAE4D (void);
// 0x00000226 System.IntPtr AkAudioFormat::getCPtr(AkAudioFormat)
extern void AkAudioFormat_getCPtr_m33D3368D15F2172ADE36C91E32C87855A88766E8 (void);
// 0x00000227 System.Void AkAudioFormat::setCPtr(System.IntPtr)
extern void AkAudioFormat_setCPtr_mF8B68B56007F361EFE3FF365435D25C1CBF6986F (void);
// 0x00000228 System.Void AkAudioFormat::Finalize()
extern void AkAudioFormat_Finalize_m6009921F7F31C0EA52DE0B962CA09B18756ECF85 (void);
// 0x00000229 System.Void AkAudioFormat::Dispose()
extern void AkAudioFormat_Dispose_m9754C5251318D62BB122836651BD66E29FDEE896 (void);
// 0x0000022A System.Void AkAudioFormat::set_uSampleRate(System.UInt32)
extern void AkAudioFormat_set_uSampleRate_m5051F67C216FB1E5B4251F8E26559A7B037C90E0 (void);
// 0x0000022B System.UInt32 AkAudioFormat::get_uSampleRate()
extern void AkAudioFormat_get_uSampleRate_m14D65D3EF5D631752398BDC20438C21837E87F07 (void);
// 0x0000022C System.Void AkAudioFormat::set_channelConfig(AkChannelConfig)
extern void AkAudioFormat_set_channelConfig_m79323323A933B1786D107E2CADE64B2DF1B0C484 (void);
// 0x0000022D AkChannelConfig AkAudioFormat::get_channelConfig()
extern void AkAudioFormat_get_channelConfig_m481F364AFA8A6BAEB4E1126887C25E9F27E1EDB9 (void);
// 0x0000022E System.Void AkAudioFormat::set_uBitsPerSample(System.UInt32)
extern void AkAudioFormat_set_uBitsPerSample_mCAAB27154011F877EB94AF008795F7120DB8CFCA (void);
// 0x0000022F System.UInt32 AkAudioFormat::get_uBitsPerSample()
extern void AkAudioFormat_get_uBitsPerSample_m653251DCC92BC77A95EF16976D66B255F09B7BC3 (void);
// 0x00000230 System.Void AkAudioFormat::set_uBlockAlign(System.UInt32)
extern void AkAudioFormat_set_uBlockAlign_mC193C01AC42A7512EB06D36689532D89C8C23D13 (void);
// 0x00000231 System.UInt32 AkAudioFormat::get_uBlockAlign()
extern void AkAudioFormat_get_uBlockAlign_mB93C9359291B549122314597AFCE146257A52435 (void);
// 0x00000232 System.Void AkAudioFormat::set_uTypeID(System.UInt32)
extern void AkAudioFormat_set_uTypeID_m7D423387B1BA1BC8CDE9E5F279549E5B71947AC8 (void);
// 0x00000233 System.UInt32 AkAudioFormat::get_uTypeID()
extern void AkAudioFormat_get_uTypeID_m0447F16D676AB6733AE6A8E435BCB1D12B208D49 (void);
// 0x00000234 System.Void AkAudioFormat::set_uInterleaveID(System.UInt32)
extern void AkAudioFormat_set_uInterleaveID_m7425E10BD1C2965F38192387D9BC712087D15C82 (void);
// 0x00000235 System.UInt32 AkAudioFormat::get_uInterleaveID()
extern void AkAudioFormat_get_uInterleaveID_m33EB44AAB313901243CC5A411CF679D4B6B61CBE (void);
// 0x00000236 System.UInt32 AkAudioFormat::GetNumChannels()
extern void AkAudioFormat_GetNumChannels_m0B06CE645C02D552B14D034F86DAD767F7F98C52 (void);
// 0x00000237 System.UInt32 AkAudioFormat::GetBitsPerSample()
extern void AkAudioFormat_GetBitsPerSample_m6D65D6540A81D383F573D81939DB557BFE6AC827 (void);
// 0x00000238 System.UInt32 AkAudioFormat::GetBlockAlign()
extern void AkAudioFormat_GetBlockAlign_mEB19C9D1C4FD556E62F2ECD62510EF3351BCCCC2 (void);
// 0x00000239 System.UInt32 AkAudioFormat::GetTypeID()
extern void AkAudioFormat_GetTypeID_m1506E67A466A663180FC11DA84860EDE665938B9 (void);
// 0x0000023A System.UInt32 AkAudioFormat::GetInterleaveID()
extern void AkAudioFormat_GetInterleaveID_m60A77FB41F7157C245F91B4B0CC1AB7BE9C016D1 (void);
// 0x0000023B System.Void AkAudioFormat::SetAll(System.UInt32,AkChannelConfig,System.UInt32,System.UInt32,System.UInt32,System.UInt32)
extern void AkAudioFormat_SetAll_m01B7E012099489B17B2E8E43A98964D05E57168E (void);
// 0x0000023C System.Void AkAudioFormat::.ctor()
extern void AkAudioFormat__ctor_m1C9222AF98C0022639CB48350CEF6D58F57E925B (void);
// 0x0000023D System.Void AkAudioInterruptionCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkAudioInterruptionCallbackInfo__ctor_m87D087D4E5A9B771A8222AC9885D5CDD81FBD762 (void);
// 0x0000023E System.IntPtr AkAudioInterruptionCallbackInfo::getCPtr(AkAudioInterruptionCallbackInfo)
extern void AkAudioInterruptionCallbackInfo_getCPtr_mAEC8A1FA717A856796CCFDFE928EFE1207D37012 (void);
// 0x0000023F System.Void AkAudioInterruptionCallbackInfo::setCPtr(System.IntPtr)
extern void AkAudioInterruptionCallbackInfo_setCPtr_mF7A686A50E0EBE14E7EA8D9FBCDE94B2A2FE774B (void);
// 0x00000240 System.Void AkAudioInterruptionCallbackInfo::Finalize()
extern void AkAudioInterruptionCallbackInfo_Finalize_mC860B46910E9B6895220F8015803CFB71872B301 (void);
// 0x00000241 System.Void AkAudioInterruptionCallbackInfo::Dispose()
extern void AkAudioInterruptionCallbackInfo_Dispose_m03CC716316200B42F57AA0DFBB9AAC553990E0BA (void);
// 0x00000242 System.Boolean AkAudioInterruptionCallbackInfo::get_bEnterInterruption()
extern void AkAudioInterruptionCallbackInfo_get_bEnterInterruption_m492795F810086F9AA8D13A014C7B2F126E3BC7E9 (void);
// 0x00000243 System.Void AkAudioInterruptionCallbackInfo::.ctor()
extern void AkAudioInterruptionCallbackInfo__ctor_m7C13C38F339B9A7AF3D89CBE9706BB2C255B042E (void);
// 0x00000244 System.Void AkAudioSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkAudioSettings__ctor_mBDEC3778EE2326F41FA612BA94FA342CD9DD25E4 (void);
// 0x00000245 System.IntPtr AkAudioSettings::getCPtr(AkAudioSettings)
extern void AkAudioSettings_getCPtr_mDA6583827D95B48FBAEED6AE3B75C0D743377BD4 (void);
// 0x00000246 System.Void AkAudioSettings::setCPtr(System.IntPtr)
extern void AkAudioSettings_setCPtr_m241B979B84271D2A7C798523AA3774F9558EB7AC (void);
// 0x00000247 System.Void AkAudioSettings::Finalize()
extern void AkAudioSettings_Finalize_m9926209231144A165E3B2F275496D86B582FE6C5 (void);
// 0x00000248 System.Void AkAudioSettings::Dispose()
extern void AkAudioSettings_Dispose_m96E6B3CB7957080E87038BFFAF6FA42E9F1476B6 (void);
// 0x00000249 System.Void AkAudioSettings::set_uNumSamplesPerFrame(System.UInt32)
extern void AkAudioSettings_set_uNumSamplesPerFrame_mF39771309C31DFF116EF15AFA68489992E422D65 (void);
// 0x0000024A System.UInt32 AkAudioSettings::get_uNumSamplesPerFrame()
extern void AkAudioSettings_get_uNumSamplesPerFrame_m68F02F89229B3E01A08654ED93D42B08FAE8B65B (void);
// 0x0000024B System.Void AkAudioSettings::set_uNumSamplesPerSecond(System.UInt32)
extern void AkAudioSettings_set_uNumSamplesPerSecond_m9D51F6964BE6F9EA1683B56F7AF3CD88CA2CD106 (void);
// 0x0000024C System.UInt32 AkAudioSettings::get_uNumSamplesPerSecond()
extern void AkAudioSettings_get_uNumSamplesPerSecond_m1B1FA295BA8E67667FB606ACB19A760FB9347FB4 (void);
// 0x0000024D System.Void AkAudioSettings::.ctor()
extern void AkAudioSettings__ctor_m2C2D6234B829F4958D7C95C1E575B348F4FCA377 (void);
// 0x0000024E System.Void AkAudioSourceChangeCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkAudioSourceChangeCallbackInfo__ctor_m444BBBCDF0D8530A43ABB6B5FFADE374E6F7276F (void);
// 0x0000024F System.IntPtr AkAudioSourceChangeCallbackInfo::getCPtr(AkAudioSourceChangeCallbackInfo)
extern void AkAudioSourceChangeCallbackInfo_getCPtr_m100E66C0BE579D72B1DA66808041B3C3405BB576 (void);
// 0x00000250 System.Void AkAudioSourceChangeCallbackInfo::setCPtr(System.IntPtr)
extern void AkAudioSourceChangeCallbackInfo_setCPtr_m2093E45E5F9029C1BB2CF0D8FFD1B048979BDC35 (void);
// 0x00000251 System.Void AkAudioSourceChangeCallbackInfo::Finalize()
extern void AkAudioSourceChangeCallbackInfo_Finalize_m31F683CE1D7EAA1C836D96DFAEC7AAC920129E8B (void);
// 0x00000252 System.Void AkAudioSourceChangeCallbackInfo::Dispose()
extern void AkAudioSourceChangeCallbackInfo_Dispose_m901997A5E6BF27B42E72442D5B6325C6FE116D64 (void);
// 0x00000253 System.Boolean AkAudioSourceChangeCallbackInfo::get_bOtherAudioPlaying()
extern void AkAudioSourceChangeCallbackInfo_get_bOtherAudioPlaying_m186269EDE6A779C7BDA040A0DA5D2F73D6979703 (void);
// 0x00000254 System.Void AkAudioSourceChangeCallbackInfo::.ctor()
extern void AkAudioSourceChangeCallbackInfo__ctor_m4DBCDC7D8885B9D8B7449C73AE34ED1A02C726AC (void);
// 0x00000255 System.Void AkAuxSendValue::.ctor(System.IntPtr,System.Boolean)
extern void AkAuxSendValue__ctor_m5952FE9F609878673FC8EEAAAAAC90AFE2E0B8AB (void);
// 0x00000256 System.IntPtr AkAuxSendValue::getCPtr(AkAuxSendValue)
extern void AkAuxSendValue_getCPtr_m77F32981AE8780C855D679105EAD5DA56C0C9D72 (void);
// 0x00000257 System.Void AkAuxSendValue::setCPtr(System.IntPtr)
extern void AkAuxSendValue_setCPtr_m04D7930D3A541F930EEEAE71A7145A2A6D8FD03A (void);
// 0x00000258 System.Void AkAuxSendValue::Finalize()
extern void AkAuxSendValue_Finalize_m10A9D3F3587D4D5CD06BCFF6EB7C45C43F93F6D2 (void);
// 0x00000259 System.Void AkAuxSendValue::Dispose()
extern void AkAuxSendValue_Dispose_mDD80E172129FADDA1ACEF6488F29A3B8CF61D37A (void);
// 0x0000025A System.Void AkAuxSendValue::set_listenerID(System.UInt64)
extern void AkAuxSendValue_set_listenerID_m7AC62724E34CD4D68F1AE7AB71048F39E9BE10B8 (void);
// 0x0000025B System.UInt64 AkAuxSendValue::get_listenerID()
extern void AkAuxSendValue_get_listenerID_m45395362690DC76587D73C203BBD168C6A0A4E21 (void);
// 0x0000025C System.Void AkAuxSendValue::set_auxBusID(System.UInt32)
extern void AkAuxSendValue_set_auxBusID_mE70F5055E04770AD9EA0DFA02633E204C53F4A01 (void);
// 0x0000025D System.UInt32 AkAuxSendValue::get_auxBusID()
extern void AkAuxSendValue_get_auxBusID_m6CD0162E52D42D311B59E9AB3CE4C20C9BF3BF12 (void);
// 0x0000025E System.Void AkAuxSendValue::set_fControlValue(System.Single)
extern void AkAuxSendValue_set_fControlValue_mD4249842891A62BB26CAEDD921F8AD92FC4186B3 (void);
// 0x0000025F System.Single AkAuxSendValue::get_fControlValue()
extern void AkAuxSendValue_get_fControlValue_m2EDC2705C495F8B502E3FD7E3BC879DDC2F3CF44 (void);
// 0x00000260 System.Void AkAuxSendValue::Set(System.UInt64,System.UInt32,System.Single)
extern void AkAuxSendValue_Set_mBBD480900EB83C66DE3712B4DB64E95DA8C6424A (void);
// 0x00000261 System.Boolean AkAuxSendValue::IsSame(System.UInt64,System.UInt32)
extern void AkAuxSendValue_IsSame_m6488A2D7B5062C809680CBC006AC8CB4C2E5A870 (void);
// 0x00000262 System.Void AkAuxSendValue::Set(UnityEngine.GameObject,System.UInt32,System.Single)
extern void AkAuxSendValue_Set_m7EEE12544D62D2CAD9F49D969561FF01F5CB14AA (void);
// 0x00000263 System.Boolean AkAuxSendValue::IsSame(UnityEngine.GameObject,System.UInt32)
extern void AkAuxSendValue_IsSame_m9B3389C41BB4FF9FC30A9518CF2367386A2D4EBE (void);
// 0x00000264 System.Int32 AkAuxSendValue::GetSizeOf()
extern void AkAuxSendValue_GetSizeOf_mC725ED49C8C0AF345947952E32CAFFF5B3BB5A6C (void);
// 0x00000265 System.Void AkBankCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkBankCallbackInfo__ctor_mF6B8DF874DBA4B7D5D23D9DA4416AC21B3362CFC (void);
// 0x00000266 System.IntPtr AkBankCallbackInfo::getCPtr(AkBankCallbackInfo)
extern void AkBankCallbackInfo_getCPtr_m4E358BD184C28E369EBDFD2ACF094AED9117C43D (void);
// 0x00000267 System.Void AkBankCallbackInfo::setCPtr(System.IntPtr)
extern void AkBankCallbackInfo_setCPtr_mBDBBDE3D3110817F6641281D1AAC2E0804534C0E (void);
// 0x00000268 System.Void AkBankCallbackInfo::Finalize()
extern void AkBankCallbackInfo_Finalize_m3B8903780FA78EAAC51F61EC46BCBDF967708B0C (void);
// 0x00000269 System.Void AkBankCallbackInfo::Dispose()
extern void AkBankCallbackInfo_Dispose_mC0E937B5CCD9139B9A4C6E2CE4CABF06A38537E2 (void);
// 0x0000026A System.UInt32 AkBankCallbackInfo::get_bankID()
extern void AkBankCallbackInfo_get_bankID_m97284999C7BDD41232D34B9FD456E8F7AF0C71E2 (void);
// 0x0000026B System.IntPtr AkBankCallbackInfo::get_inMemoryBankPtr()
extern void AkBankCallbackInfo_get_inMemoryBankPtr_mCF91AD5B87A40799742A8E539A352B39F3F72946 (void);
// 0x0000026C AKRESULT AkBankCallbackInfo::get_loadResult()
extern void AkBankCallbackInfo_get_loadResult_mFAED163CAF1F0D940B17702025F681E8C2702506 (void);
// 0x0000026D System.Void AkBankCallbackInfo::.ctor()
extern void AkBankCallbackInfo__ctor_m3920B4E9590D140AC878559E3488926F18BD41CA (void);
// 0x0000026E System.Void AkBehavioralPositioningData::.ctor(System.IntPtr,System.Boolean)
extern void AkBehavioralPositioningData__ctor_mAAE1AA6B45F0C42AC2D1C21AFDF0C214FB63B88D (void);
// 0x0000026F System.IntPtr AkBehavioralPositioningData::getCPtr(AkBehavioralPositioningData)
extern void AkBehavioralPositioningData_getCPtr_m636F7438DED06B4ADB6F71711FA1C419023DC149 (void);
// 0x00000270 System.Void AkBehavioralPositioningData::setCPtr(System.IntPtr)
extern void AkBehavioralPositioningData_setCPtr_m43797B34B9B0AEA615BFF31088FEEB09F45AE1F7 (void);
// 0x00000271 System.Void AkBehavioralPositioningData::Finalize()
extern void AkBehavioralPositioningData_Finalize_mA5F65EFA94C1A81C62006A2801642A89545CFCDB (void);
// 0x00000272 System.Void AkBehavioralPositioningData::Dispose()
extern void AkBehavioralPositioningData_Dispose_m170C5701DA1662B37914695EAFB2885BDD5C795A (void);
// 0x00000273 System.Void AkBehavioralPositioningData::.ctor()
extern void AkBehavioralPositioningData__ctor_mFDD5B99A0A7BED5A9B9D135A2F0C09B532F0304B (void);
// 0x00000274 System.Void AkBehavioralPositioningData::set_center(System.Single)
extern void AkBehavioralPositioningData_set_center_mDCE1282ED087D60F93BA3B466016523E53E8D919 (void);
// 0x00000275 System.Single AkBehavioralPositioningData::get_center()
extern void AkBehavioralPositioningData_get_center_m6B22E5F41E73EBF0631DB0F2F6AFE8223B17675C (void);
// 0x00000276 System.Void AkBehavioralPositioningData::set_panLR(System.Single)
extern void AkBehavioralPositioningData_set_panLR_mC45CF36A6A4453DAAA504316129B561DA8B32584 (void);
// 0x00000277 System.Single AkBehavioralPositioningData::get_panLR()
extern void AkBehavioralPositioningData_get_panLR_mBC42012C9670A16094E2D956BCAE274F761E1C7B (void);
// 0x00000278 System.Void AkBehavioralPositioningData::set_panBF(System.Single)
extern void AkBehavioralPositioningData_set_panBF_mC93D00F8B35FEC30283E247AB048C0BDC792C7FE (void);
// 0x00000279 System.Single AkBehavioralPositioningData::get_panBF()
extern void AkBehavioralPositioningData_get_panBF_m342C791CD66293F5B908467A97759D9FB6F4ECB3 (void);
// 0x0000027A System.Void AkBehavioralPositioningData::set_panDU(System.Single)
extern void AkBehavioralPositioningData_set_panDU_mB95E57A9D1795964F3666772195CA382C690923B (void);
// 0x0000027B System.Single AkBehavioralPositioningData::get_panDU()
extern void AkBehavioralPositioningData_get_panDU_mA34BDB7C22DF82FAD04161EC99533F5AB015D0C9 (void);
// 0x0000027C System.Void AkBehavioralPositioningData::set_panSpatMix(System.Single)
extern void AkBehavioralPositioningData_set_panSpatMix_m12FF543114239616C793E655F5FE46238173128A (void);
// 0x0000027D System.Single AkBehavioralPositioningData::get_panSpatMix()
extern void AkBehavioralPositioningData_get_panSpatMix_mA79ED2E993170E1348DD7468B23BC938974E1BF2 (void);
// 0x0000027E System.Void AkBehavioralPositioningData::set_spatMode(Ak3DSpatializationMode)
extern void AkBehavioralPositioningData_set_spatMode_m2CE143297BCA6C89E9A4368D2DE1749C093D0D18 (void);
// 0x0000027F Ak3DSpatializationMode AkBehavioralPositioningData::get_spatMode()
extern void AkBehavioralPositioningData_get_spatMode_m2F11E2E8A1520B2BD3D69E59A7E767EDC0BCEC9B (void);
// 0x00000280 System.Void AkBehavioralPositioningData::set_panType(AkSpeakerPanningType)
extern void AkBehavioralPositioningData_set_panType_mE41036AC92D188C2D6DC350968666946276978DF (void);
// 0x00000281 AkSpeakerPanningType AkBehavioralPositioningData::get_panType()
extern void AkBehavioralPositioningData_get_panType_m8BBC73904E23E135C72A44A40ABB0F73FE8981E1 (void);
// 0x00000282 System.Void AkBehavioralPositioningData::set_enableHeightSpread(System.Boolean)
extern void AkBehavioralPositioningData_set_enableHeightSpread_mEF74A890B9E6FA4D4ECCEAC3F0A4F149296918D2 (void);
// 0x00000283 System.Boolean AkBehavioralPositioningData::get_enableHeightSpread()
extern void AkBehavioralPositioningData_get_enableHeightSpread_m7E77990EEA0FFE170A346A0DCE8CBF89858FD3A9 (void);
// 0x00000284 System.Void AkCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkCallbackInfo__ctor_m4ED02ED33112DA89B6B4C1CC0A2EC5E545D4D762 (void);
// 0x00000285 System.IntPtr AkCallbackInfo::getCPtr(AkCallbackInfo)
extern void AkCallbackInfo_getCPtr_mA3456C854E893541CBEA41117C541AA6E279C4D9 (void);
// 0x00000286 System.Void AkCallbackInfo::setCPtr(System.IntPtr)
extern void AkCallbackInfo_setCPtr_mF01D727CBE6FCBD0402B524519D870E461AE8A93 (void);
// 0x00000287 System.Void AkCallbackInfo::Finalize()
extern void AkCallbackInfo_Finalize_mDE97E9539682A3BEF3793E0D1CE4FB06D23BEA48 (void);
// 0x00000288 System.Void AkCallbackInfo::Dispose()
extern void AkCallbackInfo_Dispose_mC4C88515653188B22038AC93BE4F7A0AAF8A3C5C (void);
// 0x00000289 System.IntPtr AkCallbackInfo::get_pCookie()
extern void AkCallbackInfo_get_pCookie_m7E82F3E764712A32F478CCD37AD683AEBEC7A82A (void);
// 0x0000028A System.UInt64 AkCallbackInfo::get_gameObjID()
extern void AkCallbackInfo_get_gameObjID_m4EE0B837BB822C20527A14E76176C3DB64D08B89 (void);
// 0x0000028B System.Void AkCallbackInfo::.ctor()
extern void AkCallbackInfo__ctor_mEA6B5F9D853960E871D0BB03A74129E7CE4611AE (void);
// 0x0000028C System.Void AkCallbackSerializer::.ctor(System.IntPtr,System.Boolean)
extern void AkCallbackSerializer__ctor_mCF5A85DD9A518CDCE7391C7C7AF1FD4B4B87AAD6 (void);
// 0x0000028D System.IntPtr AkCallbackSerializer::getCPtr(AkCallbackSerializer)
extern void AkCallbackSerializer_getCPtr_mD4EED749026F4D3EDCDB633C25F9CF78536AAB20 (void);
// 0x0000028E System.Void AkCallbackSerializer::setCPtr(System.IntPtr)
extern void AkCallbackSerializer_setCPtr_mC148F0D5D5631D5661067A46F5849662B8B1DBD3 (void);
// 0x0000028F System.Void AkCallbackSerializer::Finalize()
extern void AkCallbackSerializer_Finalize_m21417685D8936F26F296FDC8F1871E00FE251607 (void);
// 0x00000290 System.Void AkCallbackSerializer::Dispose()
extern void AkCallbackSerializer_Dispose_mDF0C05BD823333AE36CF8B81A865200DC92628A1 (void);
// 0x00000291 AKRESULT AkCallbackSerializer::Init()
extern void AkCallbackSerializer_Init_m42F308599B3B55EDB6D388B93FD09628C7B36685 (void);
// 0x00000292 System.Void AkCallbackSerializer::Term()
extern void AkCallbackSerializer_Term_mB685FCD620C6876D206E9684182727E0163A7AF1 (void);
// 0x00000293 System.IntPtr AkCallbackSerializer::Lock()
extern void AkCallbackSerializer_Lock_mEC48171E191DCE3CD66C1B000928B4144A30231D (void);
// 0x00000294 System.Void AkCallbackSerializer::Unlock()
extern void AkCallbackSerializer_Unlock_mB1F0AC33B3948350B8A97079001B22835F33DCE2 (void);
// 0x00000295 System.Void AkCallbackSerializer::SetLocalOutput(System.UInt32)
extern void AkCallbackSerializer_SetLocalOutput_m5947A4D89D871B6032175146C77F3C5975683329 (void);
// 0x00000296 AKRESULT AkCallbackSerializer::AudioSourceChangeCallbackFunc(System.Boolean,System.Object)
extern void AkCallbackSerializer_AudioSourceChangeCallbackFunc_mD5D1B61D556B9627BB35A726F88A6C124C960A38 (void);
// 0x00000297 System.Void AkCallbackSerializer::.ctor()
extern void AkCallbackSerializer__ctor_m28D00C898D25AB7B791B943EA011B94E7891EF33 (void);
// 0x00000298 System.Void AkChannelConfig::.ctor(System.IntPtr,System.Boolean)
extern void AkChannelConfig__ctor_mCB9D8545FB0EB39F7A3B7926DA2F186160ABBEE0 (void);
// 0x00000299 System.IntPtr AkChannelConfig::getCPtr(AkChannelConfig)
extern void AkChannelConfig_getCPtr_mCD18E1D81542E4554CB2819E8CCB730C7BD9F777 (void);
// 0x0000029A System.Void AkChannelConfig::setCPtr(System.IntPtr)
extern void AkChannelConfig_setCPtr_mF2ACA6B6DEC3054B1CFB6AF66B3FAC1AFB513B05 (void);
// 0x0000029B System.Void AkChannelConfig::Finalize()
extern void AkChannelConfig_Finalize_m22E7E632AAB667294045920B1E3A8F0CD9ECCC8A (void);
// 0x0000029C System.Void AkChannelConfig::Dispose()
extern void AkChannelConfig_Dispose_m8B5C10DD4491301B934472EB0E5181B1FEB8874C (void);
// 0x0000029D System.Void AkChannelConfig::set_uNumChannels(System.UInt32)
extern void AkChannelConfig_set_uNumChannels_mE1C94DD489E951D5A37B52A34AB752CB927B64BC (void);
// 0x0000029E System.UInt32 AkChannelConfig::get_uNumChannels()
extern void AkChannelConfig_get_uNumChannels_mD661B80D5F0E81D0810EE7A6726EBE48EF1F8FA0 (void);
// 0x0000029F System.Void AkChannelConfig::set_eConfigType(System.UInt32)
extern void AkChannelConfig_set_eConfigType_mB87CBAB2AB6866D741E098E74655D9E9F61609FA (void);
// 0x000002A0 System.UInt32 AkChannelConfig::get_eConfigType()
extern void AkChannelConfig_get_eConfigType_mF0760A505103A4CE0EE59FCD96C50501E077DDA4 (void);
// 0x000002A1 System.Void AkChannelConfig::set_uChannelMask(System.UInt32)
extern void AkChannelConfig_set_uChannelMask_mEA95366FFED9E48BF800544BBF79D32060BB5332 (void);
// 0x000002A2 System.UInt32 AkChannelConfig::get_uChannelMask()
extern void AkChannelConfig_get_uChannelMask_mA4D3D601BBE03004A59DFF58F8E2BF71EEFD43E2 (void);
// 0x000002A3 System.Void AkChannelConfig::.ctor()
extern void AkChannelConfig__ctor_m1622C6F1B99DADFADF488D3A94BD4C39797B5EFE (void);
// 0x000002A4 System.Void AkChannelConfig::.ctor(System.UInt32,System.UInt32)
extern void AkChannelConfig__ctor_m5418325A8F43ECB7F9C7D1FFB85C14FB8B417A56 (void);
// 0x000002A5 System.Void AkChannelConfig::Clear()
extern void AkChannelConfig_Clear_m9CBF41A0B612C48337A3F3C478ED2296A41207BB (void);
// 0x000002A6 System.Void AkChannelConfig::SetStandard(System.UInt32)
extern void AkChannelConfig_SetStandard_m3C85D2A71F53E4737FEA6BD191F692AB0C029080 (void);
// 0x000002A7 System.Void AkChannelConfig::SetStandardOrAnonymous(System.UInt32,System.UInt32)
extern void AkChannelConfig_SetStandardOrAnonymous_m5567106262B79E505E6ABC1E339BC0E36C7E83AB (void);
// 0x000002A8 System.Void AkChannelConfig::SetAnonymous(System.UInt32)
extern void AkChannelConfig_SetAnonymous_m2F56048EE2B6B77A952A4A1C785040F7A74B1AD0 (void);
// 0x000002A9 System.Void AkChannelConfig::SetAmbisonic(System.UInt32)
extern void AkChannelConfig_SetAmbisonic_m5DAFE7C1A5DFA24BD3DE95BE2BE401C34101264B (void);
// 0x000002AA System.Void AkChannelConfig::SetObject()
extern void AkChannelConfig_SetObject_m62F32DF06A87F008A667040049DD1C3D3BCDA8DE (void);
// 0x000002AB System.Boolean AkChannelConfig::IsValid()
extern void AkChannelConfig_IsValid_m09179E49F1D8F0FC16F5660791BE070AF0554B42 (void);
// 0x000002AC System.UInt32 AkChannelConfig::Serialize()
extern void AkChannelConfig_Serialize_m4CF64519C43A0D97DF228A3F67D1DBF4DF5633F5 (void);
// 0x000002AD System.Void AkChannelConfig::Deserialize(System.UInt32)
extern void AkChannelConfig_Deserialize_m6072124CB5511E9986CFF2D30022BC6B31CD2990 (void);
// 0x000002AE AkChannelConfig AkChannelConfig::RemoveLFE()
extern void AkChannelConfig_RemoveLFE_m8C764FD85928D0AD590EC9401A11286161592BCB (void);
// 0x000002AF AkChannelConfig AkChannelConfig::RemoveCenter()
extern void AkChannelConfig_RemoveCenter_m5D804810D6D08647E6D77F0284CF242BF318DB10 (void);
// 0x000002B0 System.Void AkChannelEmitter::.ctor(System.IntPtr,System.Boolean)
extern void AkChannelEmitter__ctor_mBE57C67A52B8252FE10158C1F0044992BC05B7F6 (void);
// 0x000002B1 System.IntPtr AkChannelEmitter::getCPtr(AkChannelEmitter)
extern void AkChannelEmitter_getCPtr_m61FB7714FF57B3C6FA45E28BB1A0126E3C26A3AA (void);
// 0x000002B2 System.Void AkChannelEmitter::setCPtr(System.IntPtr)
extern void AkChannelEmitter_setCPtr_mB5CA3C5FEF6E6589D03C4134F2735CD250157E45 (void);
// 0x000002B3 System.Void AkChannelEmitter::Finalize()
extern void AkChannelEmitter_Finalize_m9B0486ECB153553F0DA8E55BB9C7338D1324F048 (void);
// 0x000002B4 System.Void AkChannelEmitter::Dispose()
extern void AkChannelEmitter_Dispose_mC5E614BC8356D9E2284608DA7C5426859FF6FC5F (void);
// 0x000002B5 System.Void AkChannelEmitter::set_position(AkTransform)
extern void AkChannelEmitter_set_position_m67D313F65ADC57F9A84E535633163EF1305FF8B8 (void);
// 0x000002B6 AkTransform AkChannelEmitter::get_position()
extern void AkChannelEmitter_get_position_m56CEA579F882040EA1F4A75026A7F2F1D3F89B58 (void);
// 0x000002B7 System.Void AkChannelEmitter::set_uInputChannels(System.UInt32)
extern void AkChannelEmitter_set_uInputChannels_m217B14136AFC98269E391EE9EC4B9DEC94C69D43 (void);
// 0x000002B8 System.UInt32 AkChannelEmitter::get_uInputChannels()
extern void AkChannelEmitter_get_uInputChannels_m3001EC197707CB7AA7BFA71E1E4A67245CF5EA01 (void);
// 0x000002B9 System.Void AkDeviceDescription::.ctor(System.IntPtr,System.Boolean)
extern void AkDeviceDescription__ctor_m06BF7180DF4E20D413798484BFAE53D3A96C3B88 (void);
// 0x000002BA System.IntPtr AkDeviceDescription::getCPtr(AkDeviceDescription)
extern void AkDeviceDescription_getCPtr_m5932B18B957F94D0D167825631AA9BD39B9E7392 (void);
// 0x000002BB System.Void AkDeviceDescription::setCPtr(System.IntPtr)
extern void AkDeviceDescription_setCPtr_mB47AE9FC9C884EC8F9851CE7F0DB8EDA51706ECA (void);
// 0x000002BC System.Void AkDeviceDescription::Finalize()
extern void AkDeviceDescription_Finalize_m783CD6C73A858E8BE76D69F95716A776C24B36A1 (void);
// 0x000002BD System.Void AkDeviceDescription::Dispose()
extern void AkDeviceDescription_Dispose_m402441508C6F4231FCB8BBEC1CAB0D6C0EC83381 (void);
// 0x000002BE System.Void AkDeviceDescription::set_idDevice(System.UInt32)
extern void AkDeviceDescription_set_idDevice_m445A879BCA83BC5761FA905742A3C9FED0329163 (void);
// 0x000002BF System.UInt32 AkDeviceDescription::get_idDevice()
extern void AkDeviceDescription_get_idDevice_m01D1AC997715D3DE8A55A76FD77CFBB5B2887A08 (void);
// 0x000002C0 System.Void AkDeviceDescription::set_deviceName(System.String)
extern void AkDeviceDescription_set_deviceName_m497F041D0539BA02ABBFDC18043DD3AC4BFFD7D5 (void);
// 0x000002C1 System.String AkDeviceDescription::get_deviceName()
extern void AkDeviceDescription_get_deviceName_m7B611C7C6188F4E2DB87FBB4EEF689F543CE8CAC (void);
// 0x000002C2 System.Void AkDeviceDescription::set_deviceStateMask(AkAudioDeviceState)
extern void AkDeviceDescription_set_deviceStateMask_m58933DD4EFF7ADC6ED23258441C33E6D66D36D71 (void);
// 0x000002C3 AkAudioDeviceState AkDeviceDescription::get_deviceStateMask()
extern void AkDeviceDescription_get_deviceStateMask_m28B8C3F56A520DC1F286CC92A4738C0EF301AB17 (void);
// 0x000002C4 System.Void AkDeviceDescription::set_isDefaultDevice(System.Boolean)
extern void AkDeviceDescription_set_isDefaultDevice_m5BE3BBFCBC7B290BF2EA0FB88DC750157C28218B (void);
// 0x000002C5 System.Boolean AkDeviceDescription::get_isDefaultDevice()
extern void AkDeviceDescription_get_isDefaultDevice_m008664B7F7F6B94912C88E2F27E9D94F02A4A1D7 (void);
// 0x000002C6 System.Void AkDeviceDescription::Clear()
extern void AkDeviceDescription_Clear_m90A24092F300BAFF60051A1C8EB8088D57FE3582 (void);
// 0x000002C7 System.Int32 AkDeviceDescription::GetSizeOf()
extern void AkDeviceDescription_GetSizeOf_m13334BEAE39D8B122CC51EC2AE154912D54C2B25 (void);
// 0x000002C8 System.Void AkDeviceDescription::Clone(AkDeviceDescription)
extern void AkDeviceDescription_Clone_m3B345714B62C8EEA4F0128E9D5F69F3C33A7B319 (void);
// 0x000002C9 System.Void AkDeviceDescription::.ctor()
extern void AkDeviceDescription__ctor_mA1F37A0D6201722EA12FDE7CEF7B07B7AF8F6B59 (void);
// 0x000002CA System.Void AkDeviceSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkDeviceSettings__ctor_m775E6A5B47254363AFC57684B377CDC0E3233734 (void);
// 0x000002CB System.IntPtr AkDeviceSettings::getCPtr(AkDeviceSettings)
extern void AkDeviceSettings_getCPtr_m18CD7B679D1959C299BCB21102EEB02872BBDE3A (void);
// 0x000002CC System.Void AkDeviceSettings::setCPtr(System.IntPtr)
extern void AkDeviceSettings_setCPtr_mA8EED52D385487EADC38E17CDB8C5AE7550B829A (void);
// 0x000002CD System.Void AkDeviceSettings::Finalize()
extern void AkDeviceSettings_Finalize_m60AC346305ACD65B5D9E5B363C87E40F9F883B61 (void);
// 0x000002CE System.Void AkDeviceSettings::Dispose()
extern void AkDeviceSettings_Dispose_m5F2C2BCBEB835B79D9E5B4144EF9FA71313EF27A (void);
// 0x000002CF System.Void AkDeviceSettings::set_pIOMemory(System.IntPtr)
extern void AkDeviceSettings_set_pIOMemory_m0676CD349254CA63CD728C21D049EDF3A6FBFA04 (void);
// 0x000002D0 System.IntPtr AkDeviceSettings::get_pIOMemory()
extern void AkDeviceSettings_get_pIOMemory_m0A6F4B706BA320BE4C6666BC1FA07E092A6F6187 (void);
// 0x000002D1 System.Void AkDeviceSettings::set_uIOMemorySize(System.UInt32)
extern void AkDeviceSettings_set_uIOMemorySize_mBCF53CD1D71E26759FCD742F232980B202D0F04F (void);
// 0x000002D2 System.UInt32 AkDeviceSettings::get_uIOMemorySize()
extern void AkDeviceSettings_get_uIOMemorySize_m4CE9FE4345BF1699AD527CD0988EA8E940770E92 (void);
// 0x000002D3 System.Void AkDeviceSettings::set_uIOMemoryAlignment(System.UInt32)
extern void AkDeviceSettings_set_uIOMemoryAlignment_mAE372FDE63D7AA24B5DF1E97A16854FD5DE2ADC9 (void);
// 0x000002D4 System.UInt32 AkDeviceSettings::get_uIOMemoryAlignment()
extern void AkDeviceSettings_get_uIOMemoryAlignment_m232AE7D769C52BDC376823C787073BB5A86D9E76 (void);
// 0x000002D5 System.Void AkDeviceSettings::set_ePoolAttributes(System.UInt32)
extern void AkDeviceSettings_set_ePoolAttributes_mD5EF8B04E7D83FE16F6AE81D28368B9E3F2D38D8 (void);
// 0x000002D6 System.UInt32 AkDeviceSettings::get_ePoolAttributes()
extern void AkDeviceSettings_get_ePoolAttributes_mFFDF74FC8786289AC6EF709FD1E724323C48C2C1 (void);
// 0x000002D7 System.Void AkDeviceSettings::set_uGranularity(System.UInt32)
extern void AkDeviceSettings_set_uGranularity_mDFCB31C61E587F3D5E3D960A350C5C2EE9C56509 (void);
// 0x000002D8 System.UInt32 AkDeviceSettings::get_uGranularity()
extern void AkDeviceSettings_get_uGranularity_m063846E4B7CD18B41EE87622B94767D0F09A8E71 (void);
// 0x000002D9 System.Void AkDeviceSettings::set_uSchedulerTypeFlags(System.UInt32)
extern void AkDeviceSettings_set_uSchedulerTypeFlags_m8E881751B2BE680C5EFD12C57B97DD18B2EE6251 (void);
// 0x000002DA System.UInt32 AkDeviceSettings::get_uSchedulerTypeFlags()
extern void AkDeviceSettings_get_uSchedulerTypeFlags_mAB1DCCFA0B7DA24AAFD6AA8F80A41BD536C71F3A (void);
// 0x000002DB System.Void AkDeviceSettings::set_threadProperties(AkThreadProperties)
extern void AkDeviceSettings_set_threadProperties_m7380AABF5116568B251F8C9E3AA88B2630AA1163 (void);
// 0x000002DC AkThreadProperties AkDeviceSettings::get_threadProperties()
extern void AkDeviceSettings_get_threadProperties_mD6A5320E14917206B3139FB93DBE5A6CED5E7F45 (void);
// 0x000002DD System.Void AkDeviceSettings::set_fTargetAutoStmBufferLength(System.Single)
extern void AkDeviceSettings_set_fTargetAutoStmBufferLength_m8896CB456A85A4066D7CB7D7FBA5BEE4FBAB04AE (void);
// 0x000002DE System.Single AkDeviceSettings::get_fTargetAutoStmBufferLength()
extern void AkDeviceSettings_get_fTargetAutoStmBufferLength_m78D983D190826696963A47C524A552C840748273 (void);
// 0x000002DF System.Void AkDeviceSettings::set_uMaxConcurrentIO(System.UInt32)
extern void AkDeviceSettings_set_uMaxConcurrentIO_mAD46F8AE20435451D1AD3ED373925CEE451E0D28 (void);
// 0x000002E0 System.UInt32 AkDeviceSettings::get_uMaxConcurrentIO()
extern void AkDeviceSettings_get_uMaxConcurrentIO_m8B7B6437DB6D11841FC977AB54C83BE49359DF5B (void);
// 0x000002E1 System.Void AkDeviceSettings::set_bUseStreamCache(System.Boolean)
extern void AkDeviceSettings_set_bUseStreamCache_m682F252739D007C6CF933B01BA2DC5BBC619E942 (void);
// 0x000002E2 System.Boolean AkDeviceSettings::get_bUseStreamCache()
extern void AkDeviceSettings_get_bUseStreamCache_mD66042296D11DE01E2796185B845744755AB0EA1 (void);
// 0x000002E3 System.Void AkDeviceSettings::set_uMaxCachePinnedBytes(System.UInt32)
extern void AkDeviceSettings_set_uMaxCachePinnedBytes_m9A64FDC211F5E96756E831F038F6EFE4D7D6128E (void);
// 0x000002E4 System.UInt32 AkDeviceSettings::get_uMaxCachePinnedBytes()
extern void AkDeviceSettings_get_uMaxCachePinnedBytes_m123C0026E4068EB18ED3AD76563EA2A0FC35BA06 (void);
// 0x000002E5 System.Void AkDiffractionPathInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkDiffractionPathInfo__ctor_m4C6CD3051B3BC5E96BE963A8957489BE51E26B33 (void);
// 0x000002E6 System.IntPtr AkDiffractionPathInfo::getCPtr(AkDiffractionPathInfo)
extern void AkDiffractionPathInfo_getCPtr_m0BE5C4FAC72ACA585BF4E53034845CC8A38561F9 (void);
// 0x000002E7 System.Void AkDiffractionPathInfo::setCPtr(System.IntPtr)
extern void AkDiffractionPathInfo_setCPtr_m2186FECFC92D9BBFD91E46F5C561BEDD2308D0F6 (void);
// 0x000002E8 System.Void AkDiffractionPathInfo::Finalize()
extern void AkDiffractionPathInfo_Finalize_mECE17D8565D2299191372BAA5FE2BE601FAF6275 (void);
// 0x000002E9 System.Void AkDiffractionPathInfo::Dispose()
extern void AkDiffractionPathInfo_Dispose_mA64DD78597168C168460591EFE088233D8093A77 (void);
// 0x000002EA System.Void AkDiffractionPathInfo::set_emitterPos(UnityEngine.Vector3)
extern void AkDiffractionPathInfo_set_emitterPos_m1A7A8521C4CED2DEDE651CF4DFA3F1A142369C00 (void);
// 0x000002EB UnityEngine.Vector3 AkDiffractionPathInfo::get_emitterPos()
extern void AkDiffractionPathInfo_get_emitterPos_m987B25DEE493870742A4BE16556CB6CD92D69897 (void);
// 0x000002EC System.Void AkDiffractionPathInfo::set_virtualPos(AkTransform)
extern void AkDiffractionPathInfo_set_virtualPos_m142AB8DB5FAB8B6E1CDB03321DDDEB9EFC7D7329 (void);
// 0x000002ED AkTransform AkDiffractionPathInfo::get_virtualPos()
extern void AkDiffractionPathInfo_get_virtualPos_mE6A9284D90BBA6C14A3E63239460828CC39B3858 (void);
// 0x000002EE System.Void AkDiffractionPathInfo::set_nodeCount(System.UInt32)
extern void AkDiffractionPathInfo_set_nodeCount_m4F71AAE2118CCBCCACF08BA70CE8748EE24BC8F3 (void);
// 0x000002EF System.UInt32 AkDiffractionPathInfo::get_nodeCount()
extern void AkDiffractionPathInfo_get_nodeCount_m589B9B9690E393E5275DF61B4C55C45D7BD5FE78 (void);
// 0x000002F0 System.Void AkDiffractionPathInfo::set_diffraction(System.Single)
extern void AkDiffractionPathInfo_set_diffraction_m15FC4A7E6B831B7B05BBC106EB56CE2570C4D9F3 (void);
// 0x000002F1 System.Single AkDiffractionPathInfo::get_diffraction()
extern void AkDiffractionPathInfo_get_diffraction_mB9334EB9A3CCD42DD53C2618ACD04414892AB926 (void);
// 0x000002F2 System.Void AkDiffractionPathInfo::set_transmissionLoss(System.Single)
extern void AkDiffractionPathInfo_set_transmissionLoss_mCE0FEA84541994F315C577A31BC28949C31A8ADD (void);
// 0x000002F3 System.Single AkDiffractionPathInfo::get_transmissionLoss()
extern void AkDiffractionPathInfo_get_transmissionLoss_m975EB493F92875E89C55D424155B8092FFABAC36 (void);
// 0x000002F4 System.Void AkDiffractionPathInfo::set_totLength(System.Single)
extern void AkDiffractionPathInfo_set_totLength_mB3877052580307C030CF7DB5FA585EAA19453916 (void);
// 0x000002F5 System.Single AkDiffractionPathInfo::get_totLength()
extern void AkDiffractionPathInfo_get_totLength_m26460775F26319D6DAC12418F74A8F211027848D (void);
// 0x000002F6 System.Void AkDiffractionPathInfo::set_obstructionValue(System.Single)
extern void AkDiffractionPathInfo_set_obstructionValue_mA9A60C13BA8D7023FA5183766344881BB10D449D (void);
// 0x000002F7 System.Single AkDiffractionPathInfo::get_obstructionValue()
extern void AkDiffractionPathInfo_get_obstructionValue_mDEC6E5D059085B26C0318B57D1F5E8C72DD76C80 (void);
// 0x000002F8 System.Int32 AkDiffractionPathInfo::GetSizeOf()
extern void AkDiffractionPathInfo_GetSizeOf_m7F89871E7BAA1DA2FFC637A399314B1ED8766008 (void);
// 0x000002F9 UnityEngine.Vector3 AkDiffractionPathInfo::GetNodes(System.UInt32)
extern void AkDiffractionPathInfo_GetNodes_m42A20F9483BAD32A106F8D6B070C8EB4210698B5 (void);
// 0x000002FA System.Single AkDiffractionPathInfo::GetAngles(System.UInt32)
extern void AkDiffractionPathInfo_GetAngles_m76955570C05C7D02BB7516ECB5495B5B80562C30 (void);
// 0x000002FB System.UInt64 AkDiffractionPathInfo::GetPortals(System.UInt32)
extern void AkDiffractionPathInfo_GetPortals_m1AA187E65A1CE758FF182169BC61231F0FA69A0F (void);
// 0x000002FC System.UInt64 AkDiffractionPathInfo::GetRooms(System.UInt32)
extern void AkDiffractionPathInfo_GetRooms_m7958D7567612F60F2C359C32D7C1165980CC1375 (void);
// 0x000002FD System.Void AkDiffractionPathInfo::Clone(AkDiffractionPathInfo)
extern void AkDiffractionPathInfo_Clone_mBBA3D76D31316F88CDC7407D3F989985F0416F20 (void);
// 0x000002FE System.Void AkDiffractionPathInfo::.ctor()
extern void AkDiffractionPathInfo__ctor_m13389FC12708DF339B781726D9208C42E2497B0E (void);
// 0x000002FF System.Void AkDurationCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkDurationCallbackInfo__ctor_m14BD5BB7E5ABAF4156150D1C1132277B9E8B637C (void);
// 0x00000300 System.IntPtr AkDurationCallbackInfo::getCPtr(AkDurationCallbackInfo)
extern void AkDurationCallbackInfo_getCPtr_mE4F9C4735B8676AE23DD83DABE56BEBCBA099463 (void);
// 0x00000301 System.Void AkDurationCallbackInfo::setCPtr(System.IntPtr)
extern void AkDurationCallbackInfo_setCPtr_m54AFBDB424B12D5E59EEC56384D55CEE65AEE749 (void);
// 0x00000302 System.Void AkDurationCallbackInfo::Finalize()
extern void AkDurationCallbackInfo_Finalize_mD382BE5D412F99467BA0413954A24DED6C8E3ECC (void);
// 0x00000303 System.Void AkDurationCallbackInfo::Dispose()
extern void AkDurationCallbackInfo_Dispose_mEAE6AC7200E449771C906A6745BA6E850B0A0C35 (void);
// 0x00000304 System.Single AkDurationCallbackInfo::get_fDuration()
extern void AkDurationCallbackInfo_get_fDuration_m830E5F299DD0207D31797BAB53A9A4384EABA4F6 (void);
// 0x00000305 System.Single AkDurationCallbackInfo::get_fEstimatedDuration()
extern void AkDurationCallbackInfo_get_fEstimatedDuration_m309CD6D65AA0299C965EF62F2A598A8C50E41A3D (void);
// 0x00000306 System.UInt32 AkDurationCallbackInfo::get_audioNodeID()
extern void AkDurationCallbackInfo_get_audioNodeID_m730FA702CD3028C3DC05599E3E94D4CEAC411613 (void);
// 0x00000307 System.UInt32 AkDurationCallbackInfo::get_mediaID()
extern void AkDurationCallbackInfo_get_mediaID_mD3FEC0B8BA029E31E0A054A55C90ED3D3F8F34FF (void);
// 0x00000308 System.Boolean AkDurationCallbackInfo::get_bStreaming()
extern void AkDurationCallbackInfo_get_bStreaming_mF8125E1B99AF6A9023F42C3CE81D2CD339515197 (void);
// 0x00000309 System.Void AkDurationCallbackInfo::.ctor()
extern void AkDurationCallbackInfo__ctor_mBC9EB3501202B6A2951597333F097DF2DD8F3508 (void);
// 0x0000030A System.Void AkDynamicSequenceItemCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkDynamicSequenceItemCallbackInfo__ctor_mE41286ABF799F3CEDC82BE69FBD84E5819C58156 (void);
// 0x0000030B System.IntPtr AkDynamicSequenceItemCallbackInfo::getCPtr(AkDynamicSequenceItemCallbackInfo)
extern void AkDynamicSequenceItemCallbackInfo_getCPtr_mBF4BBB5FF93CC31BBAF1C1DE12751E10AD7AA33F (void);
// 0x0000030C System.Void AkDynamicSequenceItemCallbackInfo::setCPtr(System.IntPtr)
extern void AkDynamicSequenceItemCallbackInfo_setCPtr_mB5635DB2C39BDC899E410FA425407EB75CC05688 (void);
// 0x0000030D System.Void AkDynamicSequenceItemCallbackInfo::Finalize()
extern void AkDynamicSequenceItemCallbackInfo_Finalize_m721011A56AC5A36B5C89E6B60A8FF20B2C67B580 (void);
// 0x0000030E System.Void AkDynamicSequenceItemCallbackInfo::Dispose()
extern void AkDynamicSequenceItemCallbackInfo_Dispose_m3F014506DBCBE024F4E577767A7B0F643D64B217 (void);
// 0x0000030F System.UInt32 AkDynamicSequenceItemCallbackInfo::get_playingID()
extern void AkDynamicSequenceItemCallbackInfo_get_playingID_mD084DB2FFCE7C702FE2F0FBC988E3B064454F864 (void);
// 0x00000310 System.UInt32 AkDynamicSequenceItemCallbackInfo::get_audioNodeID()
extern void AkDynamicSequenceItemCallbackInfo_get_audioNodeID_m226854157CA328CF30EA8077DDDE33B9FE483DBE (void);
// 0x00000311 System.IntPtr AkDynamicSequenceItemCallbackInfo::get_pCustomInfo()
extern void AkDynamicSequenceItemCallbackInfo_get_pCustomInfo_m1AFBBB407058689BF58C9F7E360EEFEC46E826C0 (void);
// 0x00000312 System.Void AkDynamicSequenceItemCallbackInfo::.ctor()
extern void AkDynamicSequenceItemCallbackInfo__ctor_m5D956097663677B2CD8F3DE2276021A018C0469B (void);
// 0x00000313 System.Void AkEventCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkEventCallbackInfo__ctor_m808146131B4EA8A6B7123668F6BC683D8C11B7B5 (void);
// 0x00000314 System.IntPtr AkEventCallbackInfo::getCPtr(AkEventCallbackInfo)
extern void AkEventCallbackInfo_getCPtr_mAD468BF2120D9F023A73A42151ACB84E4D77D356 (void);
// 0x00000315 System.Void AkEventCallbackInfo::setCPtr(System.IntPtr)
extern void AkEventCallbackInfo_setCPtr_m22B20A3E3FA3135DC5B931B9A5EF41907C1EDCAB (void);
// 0x00000316 System.Void AkEventCallbackInfo::Finalize()
extern void AkEventCallbackInfo_Finalize_mD75F2F2FF539C6303EB469C6B50AA02991E77ECA (void);
// 0x00000317 System.Void AkEventCallbackInfo::Dispose()
extern void AkEventCallbackInfo_Dispose_mBAF74B91C8FBFA5CDBCC58C8C56A84255EC22587 (void);
// 0x00000318 System.UInt32 AkEventCallbackInfo::get_playingID()
extern void AkEventCallbackInfo_get_playingID_mEABED67AEBC8FADD6EF98ED20D046002A8B1B5BB (void);
// 0x00000319 System.UInt32 AkEventCallbackInfo::get_eventID()
extern void AkEventCallbackInfo_get_eventID_m5CCF607DE8BFFFC37F450D8DE688E3EACCA5A47E (void);
// 0x0000031A System.Void AkEventCallbackInfo::.ctor()
extern void AkEventCallbackInfo__ctor_mB13B533A20F689C69DBD97815D05E11E5D18C408 (void);
// 0x0000031B System.Void AkExtent::.ctor(System.IntPtr,System.Boolean)
extern void AkExtent__ctor_mDC6345EBED671A436837E5B99F80826BAD17B9EF (void);
// 0x0000031C System.IntPtr AkExtent::getCPtr(AkExtent)
extern void AkExtent_getCPtr_m0A90B9AEC3ABC233D67921F3334B95D32CEEECAA (void);
// 0x0000031D System.Void AkExtent::setCPtr(System.IntPtr)
extern void AkExtent_setCPtr_mE4DC624B37B455044C34184D6553C15DD8D0A0DB (void);
// 0x0000031E System.Void AkExtent::Finalize()
extern void AkExtent_Finalize_mFF0ACE8EEDF1D245CF8FDDFD26E651ED22CB141A (void);
// 0x0000031F System.Void AkExtent::Dispose()
extern void AkExtent_Dispose_m6B545D4A8FECCA28C1F040601C850CEE274CAA40 (void);
// 0x00000320 System.Void AkExtent::.ctor()
extern void AkExtent__ctor_m72BFBAD1053EBF01DFEDD8654FA034327490A1C1 (void);
// 0x00000321 System.Void AkExtent::.ctor(System.Single,System.Single,System.Single)
extern void AkExtent__ctor_m6A9F34E38CA14D9AA5D5E8BA56D42EDDBD0E12C2 (void);
// 0x00000322 System.Void AkExtent::set_halfWidth(System.Single)
extern void AkExtent_set_halfWidth_m16C0A7D9EB6325D940F8617509169A29670AA33C (void);
// 0x00000323 System.Single AkExtent::get_halfWidth()
extern void AkExtent_get_halfWidth_m8D5DCD3C9ADB0F43DF0CAACF85835FB4FA64FD6B (void);
// 0x00000324 System.Void AkExtent::set_halfHeight(System.Single)
extern void AkExtent_set_halfHeight_m09AEC70C4AA4D077F862F6D37B8BF8A03D5588DD (void);
// 0x00000325 System.Single AkExtent::get_halfHeight()
extern void AkExtent_get_halfHeight_m0DF0780077B74D2E0779DE0E68244B93697719F4 (void);
// 0x00000326 System.Void AkExtent::set_halfDepth(System.Single)
extern void AkExtent_set_halfDepth_m1AFC8121D1034D1CA5F9B2B7D147B04CB14216A9 (void);
// 0x00000327 System.Single AkExtent::get_halfDepth()
extern void AkExtent_get_halfDepth_m9AB82140A8FBFE62454351E1E2ADB53B63236AD3 (void);
// 0x00000328 System.Void AkExternalSourceInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkExternalSourceInfo__ctor_m99C6AE9E48A6657954037A12CABE4A80D7E321BD (void);
// 0x00000329 System.IntPtr AkExternalSourceInfo::getCPtr(AkExternalSourceInfo)
extern void AkExternalSourceInfo_getCPtr_m7C64848455C6483B4B1DE5032C2F02C89DD62C59 (void);
// 0x0000032A System.Void AkExternalSourceInfo::setCPtr(System.IntPtr)
extern void AkExternalSourceInfo_setCPtr_m346013D0361CA376E7B64DDCB5AB735E121FCB95 (void);
// 0x0000032B System.Void AkExternalSourceInfo::Finalize()
extern void AkExternalSourceInfo_Finalize_m92420EBCAC01A4F77B3CAC8BF90289AD1D732C64 (void);
// 0x0000032C System.Void AkExternalSourceInfo::Dispose()
extern void AkExternalSourceInfo_Dispose_m1EFB45EE1FC0CA4BB44CF1369BB34F39C4C2C3CD (void);
// 0x0000032D System.Void AkExternalSourceInfo::.ctor()
extern void AkExternalSourceInfo__ctor_mA391D63B19134A880C2044168EA004E89FB57DFD (void);
// 0x0000032E System.Void AkExternalSourceInfo::.ctor(System.IntPtr,System.UInt32,System.UInt32,System.UInt32)
extern void AkExternalSourceInfo__ctor_m1A422B384CBBA373C12FBE1AC37E31FC2E5DBEBA (void);
// 0x0000032F System.Void AkExternalSourceInfo::.ctor(System.String,System.UInt32,System.UInt32)
extern void AkExternalSourceInfo__ctor_m2BD0C04C5F5FA35625662C013DCE042BEF677C56 (void);
// 0x00000330 System.Void AkExternalSourceInfo::.ctor(System.UInt32,System.UInt32,System.UInt32)
extern void AkExternalSourceInfo__ctor_m9F307AF3DF0525F70A01E7E7AAFF8041E6215C6F (void);
// 0x00000331 System.Void AkExternalSourceInfo::Clear()
extern void AkExternalSourceInfo_Clear_m35B20D5768EE4698B2ECF402F2BE82559F2E1B05 (void);
// 0x00000332 System.Void AkExternalSourceInfo::Clone(AkExternalSourceInfo)
extern void AkExternalSourceInfo_Clone_mEB61F6F030F01668F1379A8B7622A2AF65F3E45A (void);
// 0x00000333 System.Int32 AkExternalSourceInfo::GetSizeOf()
extern void AkExternalSourceInfo_GetSizeOf_mF7DDBAF35FC1895ABBCA2C38B61CEA6DFAB7B03E (void);
// 0x00000334 System.Void AkExternalSourceInfo::set_iExternalSrcCookie(System.UInt32)
extern void AkExternalSourceInfo_set_iExternalSrcCookie_mBFC816EFFB92C7C6B92F5F7E269BB57605071D1E (void);
// 0x00000335 System.UInt32 AkExternalSourceInfo::get_iExternalSrcCookie()
extern void AkExternalSourceInfo_get_iExternalSrcCookie_mF352A62C08064D780FBA38E428C2BA3AA7C9F734 (void);
// 0x00000336 System.Void AkExternalSourceInfo::set_idCodec(System.UInt32)
extern void AkExternalSourceInfo_set_idCodec_m1EF71662DEE575CC207944A2B5B4CAF09CDDC4F7 (void);
// 0x00000337 System.UInt32 AkExternalSourceInfo::get_idCodec()
extern void AkExternalSourceInfo_get_idCodec_m79D9995D089873D22F93EFDAA2536B752D61B9E1 (void);
// 0x00000338 System.Void AkExternalSourceInfo::set_szFile(System.String)
extern void AkExternalSourceInfo_set_szFile_m64AA98557C0E6A584C653CC4C18141E7F2401148 (void);
// 0x00000339 System.String AkExternalSourceInfo::get_szFile()
extern void AkExternalSourceInfo_get_szFile_m583964EA5561807C15A3CE233BD65F5D3AF86E30 (void);
// 0x0000033A System.Void AkExternalSourceInfo::set_pInMemory(System.IntPtr)
extern void AkExternalSourceInfo_set_pInMemory_mC944A203E96743A4E7972CB0ACD47DFEB1E2FE99 (void);
// 0x0000033B System.IntPtr AkExternalSourceInfo::get_pInMemory()
extern void AkExternalSourceInfo_get_pInMemory_m7E3F17FF8DA48B621C17B8C9A117C136C97D510F (void);
// 0x0000033C System.Void AkExternalSourceInfo::set_uiMemorySize(System.UInt32)
extern void AkExternalSourceInfo_set_uiMemorySize_mF5138D9ED9685CD2B22401E5EEB548DC504BC77C (void);
// 0x0000033D System.UInt32 AkExternalSourceInfo::get_uiMemorySize()
extern void AkExternalSourceInfo_get_uiMemorySize_m5D83C88E106D5F242CA96B545DC446AE798537DF (void);
// 0x0000033E System.Void AkExternalSourceInfo::set_idFile(System.UInt32)
extern void AkExternalSourceInfo_set_idFile_m296F81F8F318D8D77AB5618A0DB610538C699B04 (void);
// 0x0000033F System.UInt32 AkExternalSourceInfo::get_idFile()
extern void AkExternalSourceInfo_get_idFile_m1C17022D73CD2AB0ED9278D842702505EF980B29 (void);
// 0x00000340 System.Void AkImageSourceParams::.ctor(System.IntPtr,System.Boolean)
extern void AkImageSourceParams__ctor_mAC7E00659C2F10FD544F56D8598654EB413BC4F8 (void);
// 0x00000341 System.IntPtr AkImageSourceParams::getCPtr(AkImageSourceParams)
extern void AkImageSourceParams_getCPtr_m31DB2FCB1B928A49887A600155380DD8EB20E694 (void);
// 0x00000342 System.Void AkImageSourceParams::setCPtr(System.IntPtr)
extern void AkImageSourceParams_setCPtr_m729A3951A997667492B075C6665AB1B354722D4D (void);
// 0x00000343 System.Void AkImageSourceParams::Finalize()
extern void AkImageSourceParams_Finalize_mB81B30206FF25117FCDB0D1A7C1E7430F8BC5096 (void);
// 0x00000344 System.Void AkImageSourceParams::Dispose()
extern void AkImageSourceParams_Dispose_m98E07E6B1D1640E2D98280074D4EC0B3B3DA2227 (void);
// 0x00000345 System.Void AkImageSourceParams::.ctor()
extern void AkImageSourceParams__ctor_m0D27147FB1C23D1A82809BCECB62D734AE930BC7 (void);
// 0x00000346 System.Void AkImageSourceParams::.ctor(UnityEngine.Vector3,System.Single,System.Single)
extern void AkImageSourceParams__ctor_mB6E3165B9838BD8E1D9D33A64A044186A3B9292D (void);
// 0x00000347 System.Void AkImageSourceParams::set_sourcePosition(UnityEngine.Vector3)
extern void AkImageSourceParams_set_sourcePosition_mA1DE8939EA87B5B8A1022C6226444F96D4258F6D (void);
// 0x00000348 UnityEngine.Vector3 AkImageSourceParams::get_sourcePosition()
extern void AkImageSourceParams_get_sourcePosition_m78A1F71BDDC4DA8F76DDEB30FC1B38AEDE93573B (void);
// 0x00000349 System.Void AkImageSourceParams::set_fDistanceScalingFactor(System.Single)
extern void AkImageSourceParams_set_fDistanceScalingFactor_m52527D670D660002549F1343B003E6D28CB02BA8 (void);
// 0x0000034A System.Single AkImageSourceParams::get_fDistanceScalingFactor()
extern void AkImageSourceParams_get_fDistanceScalingFactor_m8E68F9A9250C679C7E4ED2AEE1EC6AF33B51D989 (void);
// 0x0000034B System.Void AkImageSourceParams::set_fLevel(System.Single)
extern void AkImageSourceParams_set_fLevel_mDB504008930B6025200C04C94F7C92345C4DF3D4 (void);
// 0x0000034C System.Single AkImageSourceParams::get_fLevel()
extern void AkImageSourceParams_get_fLevel_m28147BB825CBF5CFC566E8C9BBFCEA23829F7BC4 (void);
// 0x0000034D System.Void AkImageSourceParams::set_fDiffraction(System.Single)
extern void AkImageSourceParams_set_fDiffraction_m36978E477A52FCC2A138219FE75B88EA86153025 (void);
// 0x0000034E System.Single AkImageSourceParams::get_fDiffraction()
extern void AkImageSourceParams_get_fDiffraction_mB968697B7BEE50A98C49DF8B1FCF294DB9FFA0E8 (void);
// 0x0000034F System.Void AkImageSourceParams::set_uDiffractionEmitterSide(System.Byte)
extern void AkImageSourceParams_set_uDiffractionEmitterSide_mAEDA3BE278F9CE0F4FCED212B6CF5C47FBC2E727 (void);
// 0x00000350 System.Byte AkImageSourceParams::get_uDiffractionEmitterSide()
extern void AkImageSourceParams_get_uDiffractionEmitterSide_m2FD68E269CA15FD014C48E36C1089149E4CCA90D (void);
// 0x00000351 System.Void AkImageSourceParams::set_uDiffractionListenerSide(System.Byte)
extern void AkImageSourceParams_set_uDiffractionListenerSide_m25953D6391A1D324D835F7760ED80E6055FB440C (void);
// 0x00000352 System.Byte AkImageSourceParams::get_uDiffractionListenerSide()
extern void AkImageSourceParams_get_uDiffractionListenerSide_m696D9C4CD07263DA3BDF5C3B63F60B85993B50DB (void);
// 0x00000353 System.Void AkImageSourceSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkImageSourceSettings__ctor_m2AC71C56CB383A8E080CE331FFC496C270A494C0 (void);
// 0x00000354 System.IntPtr AkImageSourceSettings::getCPtr(AkImageSourceSettings)
extern void AkImageSourceSettings_getCPtr_m5E551016ED5FA827C8E402FCA39ACA86B16980B2 (void);
// 0x00000355 System.Void AkImageSourceSettings::setCPtr(System.IntPtr)
extern void AkImageSourceSettings_setCPtr_mCB2E291C53EA3558133798148300E27ABE4EB9A2 (void);
// 0x00000356 System.Void AkImageSourceSettings::Finalize()
extern void AkImageSourceSettings_Finalize_mDBF0D5462C82B376B7FF94CE1EBE2D7687486C83 (void);
// 0x00000357 System.Void AkImageSourceSettings::Dispose()
extern void AkImageSourceSettings_Dispose_mF4C3DC4417D4004CFF6B8A8719A8A727FBAF1493 (void);
// 0x00000358 System.Void AkImageSourceSettings::.ctor()
extern void AkImageSourceSettings__ctor_mEC375D456CA6D1530813D2687E9CA32A8770861C (void);
// 0x00000359 System.Void AkImageSourceSettings::.ctor(UnityEngine.Vector3,System.Single,System.Single)
extern void AkImageSourceSettings__ctor_m5700D69929BE633D927957A6A0BBDBCB20245AF9 (void);
// 0x0000035A System.Void AkImageSourceSettings::SetOneTexture(System.UInt32)
extern void AkImageSourceSettings_SetOneTexture_m30F250846984D18F139C65CBBC8EF2BC5430D84D (void);
// 0x0000035B System.Void AkImageSourceSettings::SetName(System.String)
extern void AkImageSourceSettings_SetName_m6CEF2DC451E6E8569827B9F9119BC1F1085802A4 (void);
// 0x0000035C System.Void AkImageSourceSettings::set_params_(AkImageSourceParams)
extern void AkImageSourceSettings_set_params__mBE6A65ADA2F7EE58178BA34E47E350C43A4E5982 (void);
// 0x0000035D AkImageSourceParams AkImageSourceSettings::get_params_()
extern void AkImageSourceSettings_get_params__m69C3C51534E3491A89504E2FC3EFAFF59FD3A759 (void);
// 0x0000035E System.Void AkInitSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkInitSettings__ctor_mF5C4DAE2359237F2F186517982F884C700D0DC55 (void);
// 0x0000035F System.IntPtr AkInitSettings::getCPtr(AkInitSettings)
extern void AkInitSettings_getCPtr_m53AFC738173CDD55A17BDA1D1BEA22995557D019 (void);
// 0x00000360 System.Void AkInitSettings::setCPtr(System.IntPtr)
extern void AkInitSettings_setCPtr_m319E79A8812EB66FE647E7A0250F27111D0F2171 (void);
// 0x00000361 System.Void AkInitSettings::Finalize()
extern void AkInitSettings_Finalize_mEEEC1DA20BE38D9C01596E9D87BB151EFE5B433C (void);
// 0x00000362 System.Void AkInitSettings::Dispose()
extern void AkInitSettings_Dispose_m92EC70E3E0D3D9D4BD106B2370D0CE36F10ACAD4 (void);
// 0x00000363 System.Void AkInitSettings::set_uMaxNumPaths(System.UInt32)
extern void AkInitSettings_set_uMaxNumPaths_m3F844CB63EE0AD41E375E60DD957544B81F8B9D3 (void);
// 0x00000364 System.UInt32 AkInitSettings::get_uMaxNumPaths()
extern void AkInitSettings_get_uMaxNumPaths_mF4DF96126F4A2905ADC0924332D54C6E9DFC2BAE (void);
// 0x00000365 System.Void AkInitSettings::set_uCommandQueueSize(System.UInt32)
extern void AkInitSettings_set_uCommandQueueSize_m04188483C59F8D981A31659C48976E8DD317C09F (void);
// 0x00000366 System.UInt32 AkInitSettings::get_uCommandQueueSize()
extern void AkInitSettings_get_uCommandQueueSize_m7E59EA8C6B0D2E69BEDD1FF002722F286296E7A1 (void);
// 0x00000367 System.Void AkInitSettings::set_bEnableGameSyncPreparation(System.Boolean)
extern void AkInitSettings_set_bEnableGameSyncPreparation_m42C02C6A00EE6DA7FEA684D5569D47C7F1287BA9 (void);
// 0x00000368 System.Boolean AkInitSettings::get_bEnableGameSyncPreparation()
extern void AkInitSettings_get_bEnableGameSyncPreparation_m486118B5892DC0714803C11DAFF2F59C2D111D34 (void);
// 0x00000369 System.Void AkInitSettings::set_uContinuousPlaybackLookAhead(System.UInt32)
extern void AkInitSettings_set_uContinuousPlaybackLookAhead_mEBEACFA767377AEA9C43BF807AE451F8B03133E6 (void);
// 0x0000036A System.UInt32 AkInitSettings::get_uContinuousPlaybackLookAhead()
extern void AkInitSettings_get_uContinuousPlaybackLookAhead_m92A5F3BA6B774795FB1D3A832E04EA301F54FAAD (void);
// 0x0000036B System.Void AkInitSettings::set_uNumSamplesPerFrame(System.UInt32)
extern void AkInitSettings_set_uNumSamplesPerFrame_mAA0DFF7683F7F0B5E8F9687526ADA3A41D456DF9 (void);
// 0x0000036C System.UInt32 AkInitSettings::get_uNumSamplesPerFrame()
extern void AkInitSettings_get_uNumSamplesPerFrame_mEA08D318271B688226D0B1182701A7D54E68E8BF (void);
// 0x0000036D System.Void AkInitSettings::set_uMonitorQueuePoolSize(System.UInt32)
extern void AkInitSettings_set_uMonitorQueuePoolSize_m125555EA745D9249379BA72474B2A18A3D76FD53 (void);
// 0x0000036E System.UInt32 AkInitSettings::get_uMonitorQueuePoolSize()
extern void AkInitSettings_get_uMonitorQueuePoolSize_mF6E6B2D806F2DAAC86011E4AEBFD1B0867606673 (void);
// 0x0000036F System.Void AkInitSettings::set_settingsMainOutput(AkOutputSettings)
extern void AkInitSettings_set_settingsMainOutput_mE8E47A34A71D053DBD9B19F39B660B0719094D03 (void);
// 0x00000370 AkOutputSettings AkInitSettings::get_settingsMainOutput()
extern void AkInitSettings_get_settingsMainOutput_m99EF138993D72D548C443AE3EF641DE475402E24 (void);
// 0x00000371 System.Void AkInitSettings::set_uMaxHardwareTimeoutMs(System.UInt32)
extern void AkInitSettings_set_uMaxHardwareTimeoutMs_m7EE90AE016E7F34D44D58ECCE92C57B0A65C9E4A (void);
// 0x00000372 System.UInt32 AkInitSettings::get_uMaxHardwareTimeoutMs()
extern void AkInitSettings_get_uMaxHardwareTimeoutMs_m4C8792D48F287CF84C5A7BD72F607D3E84288D27 (void);
// 0x00000373 System.Void AkInitSettings::set_bUseSoundBankMgrThread(System.Boolean)
extern void AkInitSettings_set_bUseSoundBankMgrThread_m455A7051CD62D21015EA847927E7B23BF8742E47 (void);
// 0x00000374 System.Boolean AkInitSettings::get_bUseSoundBankMgrThread()
extern void AkInitSettings_get_bUseSoundBankMgrThread_mFC0F009D095798DC1B0A2AA2C9A11736872EFB19 (void);
// 0x00000375 System.Void AkInitSettings::set_bUseLEngineThread(System.Boolean)
extern void AkInitSettings_set_bUseLEngineThread_mB65810A80D04A66D2A77D097911861E71BFE95D5 (void);
// 0x00000376 System.Boolean AkInitSettings::get_bUseLEngineThread()
extern void AkInitSettings_get_bUseLEngineThread_mF2158E53EEE217CBA7AC17796EF1BDAB29C102A2 (void);
// 0x00000377 System.Void AkInitSettings::set_szPluginDLLPath(System.String)
extern void AkInitSettings_set_szPluginDLLPath_mD21B225CDD2DED91D89BF360B546035E04764961 (void);
// 0x00000378 System.String AkInitSettings::get_szPluginDLLPath()
extern void AkInitSettings_get_szPluginDLLPath_m055F970F7FDC77F02F60FBB82B35B276531708BC (void);
// 0x00000379 System.Void AkInitSettings::set_eFloorPlane(AkFloorPlane)
extern void AkInitSettings_set_eFloorPlane_m032D89DB9FADDA587BF158878891ED65DD856600 (void);
// 0x0000037A AkFloorPlane AkInitSettings::get_eFloorPlane()
extern void AkInitSettings_get_eFloorPlane_m809EE5A98AB33FADB407C0186EE37B28F705A87A (void);
// 0x0000037B System.Void AkInitSettings::set_fGameUnitsToMeters(System.Single)
extern void AkInitSettings_set_fGameUnitsToMeters_m3DF273E0BD550DD094B6D61033F88E0A5477AAEF (void);
// 0x0000037C System.Single AkInitSettings::get_fGameUnitsToMeters()
extern void AkInitSettings_get_fGameUnitsToMeters_m7CD648470B24B8626047FA719DA92804A539F8BE (void);
// 0x0000037D System.Void AkInitSettings::set_uBankReadBufferSize(System.UInt32)
extern void AkInitSettings_set_uBankReadBufferSize_mE9F13C77DEC68E55030DD050FB62B246EFCB7AE0 (void);
// 0x0000037E System.UInt32 AkInitSettings::get_uBankReadBufferSize()
extern void AkInitSettings_get_uBankReadBufferSize_mD7FE80B3456DBC4F6D763F6AFCE0E72AAEA72DF4 (void);
// 0x0000037F System.Void AkInitSettings::set_fDebugOutOfRangeLimit(System.Single)
extern void AkInitSettings_set_fDebugOutOfRangeLimit_mB319A4F79922FF5EBCB3702D44FEA5B70A82C189 (void);
// 0x00000380 System.Single AkInitSettings::get_fDebugOutOfRangeLimit()
extern void AkInitSettings_get_fDebugOutOfRangeLimit_m71D6CDFCC1EF58698DDFC11CABC925B85B15F640 (void);
// 0x00000381 System.Void AkInitSettings::set_bDebugOutOfRangeCheckEnabled(System.Boolean)
extern void AkInitSettings_set_bDebugOutOfRangeCheckEnabled_mA34D50B76F9B4075C774666BCF8C6036743074A2 (void);
// 0x00000382 System.Boolean AkInitSettings::get_bDebugOutOfRangeCheckEnabled()
extern void AkInitSettings_get_bDebugOutOfRangeCheckEnabled_m59C04367C7A769278B006ABF0338F200199B84CD (void);
// 0x00000383 System.Void AkInitializationSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkInitializationSettings__ctor_m6CBF904B928FA05E661E5252F22A249515A44626 (void);
// 0x00000384 System.IntPtr AkInitializationSettings::getCPtr(AkInitializationSettings)
extern void AkInitializationSettings_getCPtr_m8E359B71164512FD12A2BA409DD1547A9DF2187D (void);
// 0x00000385 System.Void AkInitializationSettings::setCPtr(System.IntPtr)
extern void AkInitializationSettings_setCPtr_m754B6CA2EAD60F9095F924DBDA70E0D29D6B267B (void);
// 0x00000386 System.Void AkInitializationSettings::Finalize()
extern void AkInitializationSettings_Finalize_m96861CCC56AB5912E87F9FB0B4CFD205CF966315 (void);
// 0x00000387 System.Void AkInitializationSettings::Dispose()
extern void AkInitializationSettings_Dispose_m712B70CA2DDE850640D80D8981B5FF8F7722B98C (void);
// 0x00000388 System.Void AkInitializationSettings::.ctor()
extern void AkInitializationSettings__ctor_m23024BFFFF01FF565B2A24181B76FE93FD5DB9EA (void);
// 0x00000389 System.Void AkInitializationSettings::set_streamMgrSettings(AkStreamMgrSettings)
extern void AkInitializationSettings_set_streamMgrSettings_m79E9838E943176BFFCED075DBCA9C9C7DB1FD8A9 (void);
// 0x0000038A AkStreamMgrSettings AkInitializationSettings::get_streamMgrSettings()
extern void AkInitializationSettings_get_streamMgrSettings_mA7317DAD2BABFD60C3C030AD479D1C62243E4701 (void);
// 0x0000038B System.Void AkInitializationSettings::set_deviceSettings(AkDeviceSettings)
extern void AkInitializationSettings_set_deviceSettings_m616AF154B9BE98172B802B0E8863DE8AE3BFE44E (void);
// 0x0000038C AkDeviceSettings AkInitializationSettings::get_deviceSettings()
extern void AkInitializationSettings_get_deviceSettings_m8289907C7DAFE2BBD7B1CECA13CA3AAD09EE9354 (void);
// 0x0000038D System.Void AkInitializationSettings::set_initSettings(AkInitSettings)
extern void AkInitializationSettings_set_initSettings_m0FC73305EE9FF79D94638F330968C0F39E74F090 (void);
// 0x0000038E AkInitSettings AkInitializationSettings::get_initSettings()
extern void AkInitializationSettings_get_initSettings_m08943885603F9E5B98CF6EE8059E089FFB785EA1 (void);
// 0x0000038F System.Void AkInitializationSettings::set_platformSettings(AkPlatformInitSettings)
extern void AkInitializationSettings_set_platformSettings_m3342F25CF4D0594B4338E4C11FE5B5314064DB0C (void);
// 0x00000390 AkPlatformInitSettings AkInitializationSettings::get_platformSettings()
extern void AkInitializationSettings_get_platformSettings_mDE1760C7772A8225DF7DC079D2217E4B57382EC4 (void);
// 0x00000391 System.Void AkInitializationSettings::set_musicSettings(AkMusicSettings)
extern void AkInitializationSettings_set_musicSettings_mF08A196348BCCB65843422C90EF608D060E43E3C (void);
// 0x00000392 AkMusicSettings AkInitializationSettings::get_musicSettings()
extern void AkInitializationSettings_get_musicSettings_mB765326E1A317D9FDBA39641122B9A583B0598EC (void);
// 0x00000393 System.Void AkInitializationSettings::set_unityPlatformSpecificSettings(AkUnityPlatformSpecificSettings)
extern void AkInitializationSettings_set_unityPlatformSpecificSettings_mE73FC5FDBB99C484FF7437FA295066751B1DE6AA (void);
// 0x00000394 AkUnityPlatformSpecificSettings AkInitializationSettings::get_unityPlatformSpecificSettings()
extern void AkInitializationSettings_get_unityPlatformSpecificSettings_m46CAF63971A636F9339C42953F197909ECDAE6CF (void);
// 0x00000395 System.Void AkInitializationSettings::set_useAsyncOpen(System.Boolean)
extern void AkInitializationSettings_set_useAsyncOpen_m25ED29D225AE8A6AAA9C8993EBC7E575794D70B0 (void);
// 0x00000396 System.Boolean AkInitializationSettings::get_useAsyncOpen()
extern void AkInitializationSettings_get_useAsyncOpen_m09D01B3D04CC686BBD15A8590C050ABA33E61A98 (void);
// 0x00000397 System.Void AkIterator::.ctor(System.IntPtr,System.Boolean)
extern void AkIterator__ctor_m09F365F13CC620C70D7EB509D6662E8A93AD68E3 (void);
// 0x00000398 System.IntPtr AkIterator::getCPtr(AkIterator)
extern void AkIterator_getCPtr_m4CDF29F2EEA84DB02DB73C3EC13CB0BE598DC5FB (void);
// 0x00000399 System.Void AkIterator::setCPtr(System.IntPtr)
extern void AkIterator_setCPtr_m1F60CE74DDDD643486DA64EB833215FDE40EE634 (void);
// 0x0000039A System.Void AkIterator::Finalize()
extern void AkIterator_Finalize_mD7E0B3A966C2D8CD4602C03EC453D877648259EB (void);
// 0x0000039B System.Void AkIterator::Dispose()
extern void AkIterator_Dispose_m9B985ECD92BD6CEF253C5130A7113B0E12F52D44 (void);
// 0x0000039C System.Void AkIterator::set_pItem(AkPlaylistItem)
extern void AkIterator_set_pItem_m5145D14C6912AA92BA004700AD6902FAB1FBC958 (void);
// 0x0000039D AkPlaylistItem AkIterator::get_pItem()
extern void AkIterator_get_pItem_mE58CE379A5F57498B369790B95C54993540D767A (void);
// 0x0000039E AkIterator AkIterator::NextIter()
extern void AkIterator_NextIter_m05FA16C2E69A784A3EBD8408A00E7A811F6E62A8 (void);
// 0x0000039F AkIterator AkIterator::PrevIter()
extern void AkIterator_PrevIter_mC818F2094334BC375B1D9792B677B120615291F4 (void);
// 0x000003A0 AkPlaylistItem AkIterator::GetItem()
extern void AkIterator_GetItem_mCB139AD5A9C0AFA3142D685A5470978380D125A9 (void);
// 0x000003A1 System.Boolean AkIterator::IsEqualTo(AkIterator)
extern void AkIterator_IsEqualTo_m15E93ED663BED69B8AD08657D541CB9DE2B6F1BD (void);
// 0x000003A2 System.Boolean AkIterator::IsDifferentFrom(AkIterator)
extern void AkIterator_IsDifferentFrom_mFB052FC0CDF663141DAF53B5F19D744E9568C867 (void);
// 0x000003A3 System.Void AkIterator::.ctor()
extern void AkIterator__ctor_mDCC891036B47E29B80A07090A7224CCDC96E07D5 (void);
// 0x000003A4 System.Void AkMIDIEvent::.ctor(System.IntPtr,System.Boolean)
extern void AkMIDIEvent__ctor_m2429E9823EDAB4F76CD8F81244551999CE9AF35A (void);
// 0x000003A5 System.IntPtr AkMIDIEvent::getCPtr(AkMIDIEvent)
extern void AkMIDIEvent_getCPtr_m79E03337A1D43D991EF119DA21864B50EA3C7949 (void);
// 0x000003A6 System.Void AkMIDIEvent::setCPtr(System.IntPtr)
extern void AkMIDIEvent_setCPtr_m6A9AA31FB8E0B261B0945BFBC921C0E6CAFB0CFA (void);
// 0x000003A7 System.Void AkMIDIEvent::Finalize()
extern void AkMIDIEvent_Finalize_mEB1863E2CFEA093A9D546BAB0B1C1884CFBFC32B (void);
// 0x000003A8 System.Void AkMIDIEvent::Dispose()
extern void AkMIDIEvent_Dispose_mC843DA875D22F5D5448692134BF61D1F0E28FDD4 (void);
// 0x000003A9 System.Void AkMIDIEvent::set_byChan(System.Byte)
extern void AkMIDIEvent_set_byChan_m43F2DB46EEE7FF0421F0E586C365A31C65279CD6 (void);
// 0x000003AA System.Byte AkMIDIEvent::get_byChan()
extern void AkMIDIEvent_get_byChan_m2F838957323FCEA77CFC35A2DFEFD65DAE3A6420 (void);
// 0x000003AB System.Void AkMIDIEvent::set_Gen(AkMIDIEvent_tGen)
extern void AkMIDIEvent_set_Gen_m8CAE193E342862DA4CA130302FF5338484B72226 (void);
// 0x000003AC AkMIDIEvent_tGen AkMIDIEvent::get_Gen()
extern void AkMIDIEvent_get_Gen_m00BC2913B7C11F25C536D9F2A9A5FE5FBF937D8F (void);
// 0x000003AD System.Void AkMIDIEvent::set_Cc(AkMIDIEvent_tCc)
extern void AkMIDIEvent_set_Cc_m3C209D0ABE5C0691CB447DA7DB8E222967F0A696 (void);
// 0x000003AE AkMIDIEvent_tCc AkMIDIEvent::get_Cc()
extern void AkMIDIEvent_get_Cc_mA9D09B9F4AABA9D995CD2EDA3383F40C6BDEEED5 (void);
// 0x000003AF System.Void AkMIDIEvent::set_NoteOnOff(AkMIDIEvent_tNoteOnOff)
extern void AkMIDIEvent_set_NoteOnOff_m9E8F67B81B3563CA4DB05FF9F0FB57791E1F28A1 (void);
// 0x000003B0 AkMIDIEvent_tNoteOnOff AkMIDIEvent::get_NoteOnOff()
extern void AkMIDIEvent_get_NoteOnOff_mB2540E1FADAF3ED6406596F0C0B9CFE41C1A0886 (void);
// 0x000003B1 System.Void AkMIDIEvent::set_PitchBend(AkMIDIEvent_tPitchBend)
extern void AkMIDIEvent_set_PitchBend_mCD8EB0300504836A90F0D4B156162CBC19451AFE (void);
// 0x000003B2 AkMIDIEvent_tPitchBend AkMIDIEvent::get_PitchBend()
extern void AkMIDIEvent_get_PitchBend_m8056A2DB2913108DBA7E50AA25348B6DA94B5758 (void);
// 0x000003B3 System.Void AkMIDIEvent::set_NoteAftertouch(AkMIDIEvent_tNoteAftertouch)
extern void AkMIDIEvent_set_NoteAftertouch_mBBB4C225D9CE203A239835E577513ADA1F0FF343 (void);
// 0x000003B4 AkMIDIEvent_tNoteAftertouch AkMIDIEvent::get_NoteAftertouch()
extern void AkMIDIEvent_get_NoteAftertouch_m0091950DF507EECA9651D9EB1B461830818483E1 (void);
// 0x000003B5 System.Void AkMIDIEvent::set_ChanAftertouch(AkMIDIEvent_tChanAftertouch)
extern void AkMIDIEvent_set_ChanAftertouch_m7BC7ABED2E1727E910107FA91F9510E62C7AAEDB (void);
// 0x000003B6 AkMIDIEvent_tChanAftertouch AkMIDIEvent::get_ChanAftertouch()
extern void AkMIDIEvent_get_ChanAftertouch_mF8E083DA50EC920D36DA583F85FCE099E9D886BA (void);
// 0x000003B7 System.Void AkMIDIEvent::set_ProgramChange(AkMIDIEvent_tProgramChange)
extern void AkMIDIEvent_set_ProgramChange_mAEF6F34174B4D1F8A559E4EFF5DABDEC3F6EC5B4 (void);
// 0x000003B8 AkMIDIEvent_tProgramChange AkMIDIEvent::get_ProgramChange()
extern void AkMIDIEvent_get_ProgramChange_m96DE2DAAA6AC931948AE8B371D86282C70AB6FE3 (void);
// 0x000003B9 System.Void AkMIDIEvent::set_WwiseCmd(AkMIDIEvent_tWwiseCmd)
extern void AkMIDIEvent_set_WwiseCmd_m195046F7B5221745182C02D87A619CCC341257C9 (void);
// 0x000003BA AkMIDIEvent_tWwiseCmd AkMIDIEvent::get_WwiseCmd()
extern void AkMIDIEvent_get_WwiseCmd_m80B88305B1FA65EA2A5F0A9E9A816793785A1EE2 (void);
// 0x000003BB System.Void AkMIDIEvent::set_byType(AkMIDIEventTypes)
extern void AkMIDIEvent_set_byType_m455D47611FEA5D55BED0E3E747B0563833DD6FFD (void);
// 0x000003BC AkMIDIEventTypes AkMIDIEvent::get_byType()
extern void AkMIDIEvent_get_byType_m1396067478A555B1E53EECA978B874D45B50D44C (void);
// 0x000003BD System.Void AkMIDIEvent::set_byOnOffNote(System.Byte)
extern void AkMIDIEvent_set_byOnOffNote_mBE7538BE54E0FC59E1760AF3FDD2F3A9AA3CDCA1 (void);
// 0x000003BE System.Byte AkMIDIEvent::get_byOnOffNote()
extern void AkMIDIEvent_get_byOnOffNote_m72AD01919CDC77FE2455FCE1A674A1A7AA206BF4 (void);
// 0x000003BF System.Void AkMIDIEvent::set_byVelocity(System.Byte)
extern void AkMIDIEvent_set_byVelocity_m11EAF9B44053146DC42616576E9FA29E527385E2 (void);
// 0x000003C0 System.Byte AkMIDIEvent::get_byVelocity()
extern void AkMIDIEvent_get_byVelocity_m3CC88689C6FF01F0D950C05ED2843E005D755CF5 (void);
// 0x000003C1 System.Void AkMIDIEvent::set_byCc(AkMIDICcTypes)
extern void AkMIDIEvent_set_byCc_m8D26F94B9937D93F5271C723F4AB932821321869 (void);
// 0x000003C2 AkMIDICcTypes AkMIDIEvent::get_byCc()
extern void AkMIDIEvent_get_byCc_mC88C7095BF0B1C4DE5490572962CC4B4B4EDA571 (void);
// 0x000003C3 System.Void AkMIDIEvent::set_byCcValue(System.Byte)
extern void AkMIDIEvent_set_byCcValue_mA0EF74100FB599FA90BB4D96F2D19A05973078BB (void);
// 0x000003C4 System.Byte AkMIDIEvent::get_byCcValue()
extern void AkMIDIEvent_get_byCcValue_m8990541C7B0D1E5FBE67E243C84CAE2C1C69E163 (void);
// 0x000003C5 System.Void AkMIDIEvent::set_byValueLsb(System.Byte)
extern void AkMIDIEvent_set_byValueLsb_mE6CFC8E3DF52C79A4A84BBA4C9B9F0BB4B812ABC (void);
// 0x000003C6 System.Byte AkMIDIEvent::get_byValueLsb()
extern void AkMIDIEvent_get_byValueLsb_mF49A363DFC9D69193DEDA13AA730FDC187CF15B9 (void);
// 0x000003C7 System.Void AkMIDIEvent::set_byValueMsb(System.Byte)
extern void AkMIDIEvent_set_byValueMsb_mBCBF4E647C4B1F3B153CE832AE1130C6731316C5 (void);
// 0x000003C8 System.Byte AkMIDIEvent::get_byValueMsb()
extern void AkMIDIEvent_get_byValueMsb_m606B7398D6CD30F1CCDB60A0741C6F575A7F2BD4 (void);
// 0x000003C9 System.Void AkMIDIEvent::set_byAftertouchNote(System.Byte)
extern void AkMIDIEvent_set_byAftertouchNote_m6241BC1EB151880B5F4DDCA9615B0DF325F39765 (void);
// 0x000003CA System.Byte AkMIDIEvent::get_byAftertouchNote()
extern void AkMIDIEvent_get_byAftertouchNote_m4931AE5361FC8239AEE849159EAC52D54424571F (void);
// 0x000003CB System.Void AkMIDIEvent::set_byNoteAftertouchValue(System.Byte)
extern void AkMIDIEvent_set_byNoteAftertouchValue_m4A5CE36B428DB6D190F4C8B7C4596BA4629F16CA (void);
// 0x000003CC System.Byte AkMIDIEvent::get_byNoteAftertouchValue()
extern void AkMIDIEvent_get_byNoteAftertouchValue_m5D9F68A07A5E5B937EC7FE12A5E17B663ED2BC5A (void);
// 0x000003CD System.Void AkMIDIEvent::set_byChanAftertouchValue(System.Byte)
extern void AkMIDIEvent_set_byChanAftertouchValue_m5CCCCC25EB62C54CBF1C4BAA7DFAC3FE63D146FE (void);
// 0x000003CE System.Byte AkMIDIEvent::get_byChanAftertouchValue()
extern void AkMIDIEvent_get_byChanAftertouchValue_mA1E3B5A2E23EBC380A17EB7F33E38DB4784A09BD (void);
// 0x000003CF System.Void AkMIDIEvent::set_byProgramNum(System.Byte)
extern void AkMIDIEvent_set_byProgramNum_m5916207481B15370C578E8304B24B7B09F0D690F (void);
// 0x000003D0 System.Byte AkMIDIEvent::get_byProgramNum()
extern void AkMIDIEvent_get_byProgramNum_m0FF5EC6B1C42051B779CE09F4672BE5E64252676 (void);
// 0x000003D1 System.Void AkMIDIEvent::set_uCmd(System.UInt16)
extern void AkMIDIEvent_set_uCmd_mE75B708FC82C2DC9EB03DC63B50EA4BF89DA6CF9 (void);
// 0x000003D2 System.UInt16 AkMIDIEvent::get_uCmd()
extern void AkMIDIEvent_get_uCmd_mBA82A0C04CDB92FA6A86B2DC5C72D946B24A3C77 (void);
// 0x000003D3 System.Void AkMIDIEvent::set_uArg(System.UInt32)
extern void AkMIDIEvent_set_uArg_m5B48CCB597F7A356B0B3B60496FEB1D4D7B02FC2 (void);
// 0x000003D4 System.UInt32 AkMIDIEvent::get_uArg()
extern void AkMIDIEvent_get_uArg_m6FBED906331B2746C3A976027164C5A09729EF64 (void);
// 0x000003D5 System.Void AkMIDIEvent::.ctor()
extern void AkMIDIEvent__ctor_m04EC9ACFF7FCBB7082C5AFEB5B37A2C321DA5CE7 (void);
// 0x000003D6 System.Void AkMIDIEventCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkMIDIEventCallbackInfo__ctor_mCC77C68428CD41EC578BCDC77EF642B0F76FF94C (void);
// 0x000003D7 System.IntPtr AkMIDIEventCallbackInfo::getCPtr(AkMIDIEventCallbackInfo)
extern void AkMIDIEventCallbackInfo_getCPtr_m6310CADA62FB4A89E44A280C901A40A9D6CBB922 (void);
// 0x000003D8 System.Void AkMIDIEventCallbackInfo::setCPtr(System.IntPtr)
extern void AkMIDIEventCallbackInfo_setCPtr_mF907FBD526D61B847EB2EA55294DFD695C4D2E95 (void);
// 0x000003D9 System.Void AkMIDIEventCallbackInfo::Finalize()
extern void AkMIDIEventCallbackInfo_Finalize_mBD75FC910EA8A62E20DEECC91260C98E195150E1 (void);
// 0x000003DA System.Void AkMIDIEventCallbackInfo::Dispose()
extern void AkMIDIEventCallbackInfo_Dispose_m2F30BEF9F39324A9CF25B77E6D1ECAA78C2BF2A3 (void);
// 0x000003DB System.Byte AkMIDIEventCallbackInfo::get_byChan()
extern void AkMIDIEventCallbackInfo_get_byChan_m5C11DFEDF0141CB07572AC9A84C697A1F0A23AD1 (void);
// 0x000003DC System.Byte AkMIDIEventCallbackInfo::get_byParam1()
extern void AkMIDIEventCallbackInfo_get_byParam1_m8AEAA7FB04A94595FE29F76E5D8531C2147851D8 (void);
// 0x000003DD System.Byte AkMIDIEventCallbackInfo::get_byParam2()
extern void AkMIDIEventCallbackInfo_get_byParam2_mDB2997E6EAA8706AE3A6A8C1955FD11C9AEF817F (void);
// 0x000003DE AkMIDIEventTypes AkMIDIEventCallbackInfo::get_byType()
extern void AkMIDIEventCallbackInfo_get_byType_m78610B32354AE9E9734BA2FF474D7640465B0AD0 (void);
// 0x000003DF System.Byte AkMIDIEventCallbackInfo::get_byOnOffNote()
extern void AkMIDIEventCallbackInfo_get_byOnOffNote_m6A21C94CE77C88682A51F03772413B4D0B3A4119 (void);
// 0x000003E0 System.Byte AkMIDIEventCallbackInfo::get_byVelocity()
extern void AkMIDIEventCallbackInfo_get_byVelocity_mD84AA2BEF14294CF82A5D2BCEC9D099F9DFA6146 (void);
// 0x000003E1 AkMIDICcTypes AkMIDIEventCallbackInfo::get_byCc()
extern void AkMIDIEventCallbackInfo_get_byCc_m943F519B45E592F85BD9E7BA4DB79918D76B67EA (void);
// 0x000003E2 System.Byte AkMIDIEventCallbackInfo::get_byCcValue()
extern void AkMIDIEventCallbackInfo_get_byCcValue_mD52B03D8A1DF970276B88C52842193F2CFB22034 (void);
// 0x000003E3 System.Byte AkMIDIEventCallbackInfo::get_byValueLsb()
extern void AkMIDIEventCallbackInfo_get_byValueLsb_m54C2CCF80AF726795F69F49530A5E0E57DBB1E8C (void);
// 0x000003E4 System.Byte AkMIDIEventCallbackInfo::get_byValueMsb()
extern void AkMIDIEventCallbackInfo_get_byValueMsb_m59986163649109BBE828CA479D8DF522928C638A (void);
// 0x000003E5 System.Byte AkMIDIEventCallbackInfo::get_byAftertouchNote()
extern void AkMIDIEventCallbackInfo_get_byAftertouchNote_mC3C6D09436A7E4F5687A10510ACA5314F13F0E2F (void);
// 0x000003E6 System.Byte AkMIDIEventCallbackInfo::get_byNoteAftertouchValue()
extern void AkMIDIEventCallbackInfo_get_byNoteAftertouchValue_mFE922D416950DFA1FC1270D942D2F9ECD92E7341 (void);
// 0x000003E7 System.Byte AkMIDIEventCallbackInfo::get_byChanAftertouchValue()
extern void AkMIDIEventCallbackInfo_get_byChanAftertouchValue_m4BD234B670224839CE5648C303BA3A38F76D40AF (void);
// 0x000003E8 System.Byte AkMIDIEventCallbackInfo::get_byProgramNum()
extern void AkMIDIEventCallbackInfo_get_byProgramNum_m59C26FA1110B9F221FE4133210E23A2D8EC21C94 (void);
// 0x000003E9 System.Void AkMIDIEventCallbackInfo::.ctor()
extern void AkMIDIEventCallbackInfo__ctor_m430E59304554624DC7340300409BAC9E7616BF95 (void);
// 0x000003EA System.Void AkMIDIPost::.ctor(System.IntPtr,System.Boolean)
extern void AkMIDIPost__ctor_mE3A9F6FB67919965C8C284537F0ECF1866B0D0B1 (void);
// 0x000003EB System.IntPtr AkMIDIPost::getCPtr(AkMIDIPost)
extern void AkMIDIPost_getCPtr_m2645902933827C43AD19AC18029273230595D286 (void);
// 0x000003EC System.Void AkMIDIPost::setCPtr(System.IntPtr)
extern void AkMIDIPost_setCPtr_mB6438CCC677646C0B3F5A1A9B8C21D3136FE9DD8 (void);
// 0x000003ED System.Void AkMIDIPost::Finalize()
extern void AkMIDIPost_Finalize_m5FC9B3B503E48520AA69320A0FD46B696CC96850 (void);
// 0x000003EE System.Void AkMIDIPost::Dispose()
extern void AkMIDIPost_Dispose_mF6B24D3101138082E1B3D27C3FBC32731FF2C7A0 (void);
// 0x000003EF System.Void AkMIDIPost::set_uOffset(System.UInt64)
extern void AkMIDIPost_set_uOffset_m22912C02D1D34248ED3966C5A2C34716C29A77FF (void);
// 0x000003F0 System.UInt64 AkMIDIPost::get_uOffset()
extern void AkMIDIPost_get_uOffset_m66C9CDEDE69F75E96474BABA5FFCF2CDB2C92E73 (void);
// 0x000003F1 System.UInt32 AkMIDIPost::PostOnEvent(System.UInt32,System.UInt64,System.UInt32)
extern void AkMIDIPost_PostOnEvent_m40AE53920D5B3AD771735FDBFEAB6C99873B4A33 (void);
// 0x000003F2 System.UInt32 AkMIDIPost::PostOnEvent(System.UInt32,System.UInt64,System.UInt32,System.Boolean)
extern void AkMIDIPost_PostOnEvent_m6256923A53523E64C4F4F0E675D65A69E408A135 (void);
// 0x000003F3 System.UInt32 AkMIDIPost::PostOnEvent(System.UInt32,System.UInt64,System.UInt32,System.Boolean,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkMIDIPost_PostOnEvent_m9CD4BFA71ABB2B194E40710F440CD05B1B2B1AE0 (void);
// 0x000003F4 System.UInt32 AkMIDIPost::PostOnEvent(System.UInt32,System.UInt64,System.UInt32,System.Boolean,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32)
extern void AkMIDIPost_PostOnEvent_m87B3A256A87B982FB89FA9470BCC89C04667BE53 (void);
// 0x000003F5 System.UInt32 AkMIDIPost::PostOnEvent(System.UInt32,UnityEngine.GameObject,System.UInt32)
extern void AkMIDIPost_PostOnEvent_m4A9A779EF90B6F6E5961149A48D1B7564AF85AA6 (void);
// 0x000003F6 System.UInt32 AkMIDIPost::PostOnEvent(System.UInt32,UnityEngine.GameObject,System.UInt32,System.Boolean)
extern void AkMIDIPost_PostOnEvent_mDD58DC19FE7F8FA473B2604636B804F192D0ABB4 (void);
// 0x000003F7 System.UInt32 AkMIDIPost::PostOnEvent(System.UInt32,UnityEngine.GameObject,System.UInt32,System.Boolean,System.UInt32,AkCallbackManager_EventCallback,System.Object)
extern void AkMIDIPost_PostOnEvent_m3A6F37AEF34EB96850D29F1EA5AEEFC3896609A2 (void);
// 0x000003F8 System.UInt32 AkMIDIPost::PostOnEvent(System.UInt32,UnityEngine.GameObject,System.UInt32,System.Boolean,System.UInt32,AkCallbackManager_EventCallback,System.Object,System.UInt32)
extern void AkMIDIPost_PostOnEvent_mF1799B409F9E1D286E9619A620A9801F97A10917 (void);
// 0x000003F9 System.Void AkMIDIPost::Clone(AkMIDIPost)
extern void AkMIDIPost_Clone_m104429B9CF59FDD03A992CCA79A7C4F25768560E (void);
// 0x000003FA System.Int32 AkMIDIPost::GetSizeOf()
extern void AkMIDIPost_GetSizeOf_m41DAD94A9700391F59D5A3A12EA788E154123040 (void);
// 0x000003FB System.Void AkMIDIPost::.ctor()
extern void AkMIDIPost__ctor_m39846270986B43FE999860B209CE318036785D19 (void);
// 0x000003FC System.Void AkMarkerCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkMarkerCallbackInfo__ctor_m0F8F2E2EAFB53DABADD5E2D21F3B892B19636CA5 (void);
// 0x000003FD System.IntPtr AkMarkerCallbackInfo::getCPtr(AkMarkerCallbackInfo)
extern void AkMarkerCallbackInfo_getCPtr_m49A5CE9C641F04B87F3B8DD7791F1C8A44EA539B (void);
// 0x000003FE System.Void AkMarkerCallbackInfo::setCPtr(System.IntPtr)
extern void AkMarkerCallbackInfo_setCPtr_m95C983BEB23B5CB8D628DDB637330FCB66424553 (void);
// 0x000003FF System.Void AkMarkerCallbackInfo::Finalize()
extern void AkMarkerCallbackInfo_Finalize_mCE562CD710E2DA6883D3B4C378BB80478EA8601E (void);
// 0x00000400 System.Void AkMarkerCallbackInfo::Dispose()
extern void AkMarkerCallbackInfo_Dispose_m08989A9F3BB273C4319E93AFE2531747A366B649 (void);
// 0x00000401 System.UInt32 AkMarkerCallbackInfo::get_uIdentifier()
extern void AkMarkerCallbackInfo_get_uIdentifier_m56C8E938D75CBBDCAF2B5C08AB39828A7E592326 (void);
// 0x00000402 System.UInt32 AkMarkerCallbackInfo::get_uPosition()
extern void AkMarkerCallbackInfo_get_uPosition_m267DC25F4E09E13DB200B14CC648B7C1404B178F (void);
// 0x00000403 System.String AkMarkerCallbackInfo::get_strLabel()
extern void AkMarkerCallbackInfo_get_strLabel_mA32112C949C692CCD451F5FE75FAD8033D4F35D1 (void);
// 0x00000404 System.Void AkMarkerCallbackInfo::.ctor()
extern void AkMarkerCallbackInfo__ctor_m246B1ED9C838FFC4EBC809B96D4CA13135D4857F (void);
// 0x00000405 System.Void AkMonitoringCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkMonitoringCallbackInfo__ctor_m19BF8DFCC52A8763BF0F9641FEBDC5A116856467 (void);
// 0x00000406 System.IntPtr AkMonitoringCallbackInfo::getCPtr(AkMonitoringCallbackInfo)
extern void AkMonitoringCallbackInfo_getCPtr_m00C1336A27A3EBD1B55982ABCFF3DD124AFC2B94 (void);
// 0x00000407 System.Void AkMonitoringCallbackInfo::setCPtr(System.IntPtr)
extern void AkMonitoringCallbackInfo_setCPtr_m4E33746A607EC6BAE626C771BA62DD8DBF1913DF (void);
// 0x00000408 System.Void AkMonitoringCallbackInfo::Finalize()
extern void AkMonitoringCallbackInfo_Finalize_m546AFFED5C7E2FA7517FA0D5EC2016EFB87B149C (void);
// 0x00000409 System.Void AkMonitoringCallbackInfo::Dispose()
extern void AkMonitoringCallbackInfo_Dispose_mD5FC9371F15B71E9279A2F4B83DBEE58A66B6242 (void);
// 0x0000040A AkMonitorErrorCode AkMonitoringCallbackInfo::get_errorCode()
extern void AkMonitoringCallbackInfo_get_errorCode_mAD77F4C49EE1D0F9DE890C92C4EA559DEB2B083D (void);
// 0x0000040B AkMonitorErrorLevel AkMonitoringCallbackInfo::get_errorLevel()
extern void AkMonitoringCallbackInfo_get_errorLevel_mBD5DA1AAEF6C80EB2BDCB136A8BFF4B440CD1B18 (void);
// 0x0000040C System.UInt32 AkMonitoringCallbackInfo::get_playingID()
extern void AkMonitoringCallbackInfo_get_playingID_mD77CAD6F8BE2E5AD8D0EE58E6084F87037B2F2EA (void);
// 0x0000040D System.UInt64 AkMonitoringCallbackInfo::get_gameObjID()
extern void AkMonitoringCallbackInfo_get_gameObjID_m8A9DED5C834C76337E75BE2402E149F681E917CF (void);
// 0x0000040E System.String AkMonitoringCallbackInfo::get_message()
extern void AkMonitoringCallbackInfo_get_message_m086A9F21F6617B387485F4CCBD3C6421BFE9B821 (void);
// 0x0000040F System.Void AkMonitoringCallbackInfo::.ctor()
extern void AkMonitoringCallbackInfo__ctor_m9CC946E2AE120D373E4C7BFA1D60601421C6953A (void);
// 0x00000410 System.Void AkMusicPlaylistCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkMusicPlaylistCallbackInfo__ctor_m41A867A49422A234F1C595296B898CD09B67889E (void);
// 0x00000411 System.IntPtr AkMusicPlaylistCallbackInfo::getCPtr(AkMusicPlaylistCallbackInfo)
extern void AkMusicPlaylistCallbackInfo_getCPtr_m118BDECE9D6DB9AC6789B2094444FD65E71E524E (void);
// 0x00000412 System.Void AkMusicPlaylistCallbackInfo::setCPtr(System.IntPtr)
extern void AkMusicPlaylistCallbackInfo_setCPtr_m037DB0EE5E234E9609F3628985BA232296053796 (void);
// 0x00000413 System.Void AkMusicPlaylistCallbackInfo::Finalize()
extern void AkMusicPlaylistCallbackInfo_Finalize_m4A48ED5301D6723D96A70A9ACE914F4DF40736EA (void);
// 0x00000414 System.Void AkMusicPlaylistCallbackInfo::Dispose()
extern void AkMusicPlaylistCallbackInfo_Dispose_mA41E91439403748F677DC9BDB8ED6FC2E617A16A (void);
// 0x00000415 System.UInt32 AkMusicPlaylistCallbackInfo::get_playlistID()
extern void AkMusicPlaylistCallbackInfo_get_playlistID_mA51E213B3BC6D9A92AE6AA5F310F86FA99A88C40 (void);
// 0x00000416 System.UInt32 AkMusicPlaylistCallbackInfo::get_uNumPlaylistItems()
extern void AkMusicPlaylistCallbackInfo_get_uNumPlaylistItems_m12B3069523C8B43298FC8075F010FE94694B5414 (void);
// 0x00000417 System.UInt32 AkMusicPlaylistCallbackInfo::get_uPlaylistSelection()
extern void AkMusicPlaylistCallbackInfo_get_uPlaylistSelection_mBFDECB4AF0298A4A46FA48FD9F89B28269995540 (void);
// 0x00000418 System.UInt32 AkMusicPlaylistCallbackInfo::get_uPlaylistItemDone()
extern void AkMusicPlaylistCallbackInfo_get_uPlaylistItemDone_m70E0A6B129C683EB93059BF1540EA030287F6FA2 (void);
// 0x00000419 System.Void AkMusicPlaylistCallbackInfo::.ctor()
extern void AkMusicPlaylistCallbackInfo__ctor_mE1C15A8CD248780B78992258EB161273973B9B5C (void);
// 0x0000041A System.Void AkMusicSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkMusicSettings__ctor_m8AB5CDF0D9C3C232595E816AA8D65305BB3D3D10 (void);
// 0x0000041B System.IntPtr AkMusicSettings::getCPtr(AkMusicSettings)
extern void AkMusicSettings_getCPtr_mF5CC926DB6082C5874185070E70755C9EA5925FC (void);
// 0x0000041C System.Void AkMusicSettings::setCPtr(System.IntPtr)
extern void AkMusicSettings_setCPtr_mB7CA4DB0DBCF66904295B6C0A8515FA06F03A037 (void);
// 0x0000041D System.Void AkMusicSettings::Finalize()
extern void AkMusicSettings_Finalize_m2A5D941C44485993D5B4EF913A749CFB47916DA3 (void);
// 0x0000041E System.Void AkMusicSettings::Dispose()
extern void AkMusicSettings_Dispose_m4124740EE43EAEF22FFB2ED7D45C1402290E87B6 (void);
// 0x0000041F System.Void AkMusicSettings::set_fStreamingLookAheadRatio(System.Single)
extern void AkMusicSettings_set_fStreamingLookAheadRatio_mB9ED31CC028609982811B59A9C3117F40D860156 (void);
// 0x00000420 System.Single AkMusicSettings::get_fStreamingLookAheadRatio()
extern void AkMusicSettings_get_fStreamingLookAheadRatio_m0D092BD9D256CF3E38DDB2FF8F339F512A376B00 (void);
// 0x00000421 System.Void AkMusicSyncCallbackInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkMusicSyncCallbackInfo__ctor_m1B851650BEB0212ED09EB6925B796034F5BE1174 (void);
// 0x00000422 System.IntPtr AkMusicSyncCallbackInfo::getCPtr(AkMusicSyncCallbackInfo)
extern void AkMusicSyncCallbackInfo_getCPtr_m024D1192A2BE9B17552349C4ACDA7C22BC0F2696 (void);
// 0x00000423 System.Void AkMusicSyncCallbackInfo::setCPtr(System.IntPtr)
extern void AkMusicSyncCallbackInfo_setCPtr_m1A2D171AF908D436CB2365F6B8FEF3E54DFD8674 (void);
// 0x00000424 System.Void AkMusicSyncCallbackInfo::Finalize()
extern void AkMusicSyncCallbackInfo_Finalize_m20000EAE0E37CDA082F9449D106112095B2378AC (void);
// 0x00000425 System.Void AkMusicSyncCallbackInfo::Dispose()
extern void AkMusicSyncCallbackInfo_Dispose_mCF45EF969E9765D6063FB4695E4E5D64EAD4DE39 (void);
// 0x00000426 System.UInt32 AkMusicSyncCallbackInfo::get_playingID()
extern void AkMusicSyncCallbackInfo_get_playingID_m4C5A261742E57D3B2F58C0517746FEF6988F2588 (void);
// 0x00000427 System.Int32 AkMusicSyncCallbackInfo::get_segmentInfo_iCurrentPosition()
extern void AkMusicSyncCallbackInfo_get_segmentInfo_iCurrentPosition_m13D9593F0BE1C68A6EA2BB3E1CBFDB24A0DF2AF2 (void);
// 0x00000428 System.Int32 AkMusicSyncCallbackInfo::get_segmentInfo_iPreEntryDuration()
extern void AkMusicSyncCallbackInfo_get_segmentInfo_iPreEntryDuration_m5FFA9D846AB074BFB18EEA163A7403D9434558FE (void);
// 0x00000429 System.Int32 AkMusicSyncCallbackInfo::get_segmentInfo_iActiveDuration()
extern void AkMusicSyncCallbackInfo_get_segmentInfo_iActiveDuration_m8C3EC58D1690B7CFBD1D314617C7D17E81032455 (void);
// 0x0000042A System.Int32 AkMusicSyncCallbackInfo::get_segmentInfo_iPostExitDuration()
extern void AkMusicSyncCallbackInfo_get_segmentInfo_iPostExitDuration_m331522F2AAD349A1F318E09FD1A375317EBBD446 (void);
// 0x0000042B System.Int32 AkMusicSyncCallbackInfo::get_segmentInfo_iRemainingLookAheadTime()
extern void AkMusicSyncCallbackInfo_get_segmentInfo_iRemainingLookAheadTime_mAFF0FD306DABC269D2B4FE0AC0B65429657C19B4 (void);
// 0x0000042C System.Single AkMusicSyncCallbackInfo::get_segmentInfo_fBeatDuration()
extern void AkMusicSyncCallbackInfo_get_segmentInfo_fBeatDuration_m124FD91883DDDE9A62562ADE360D657C8A27B8BD (void);
// 0x0000042D System.Single AkMusicSyncCallbackInfo::get_segmentInfo_fBarDuration()
extern void AkMusicSyncCallbackInfo_get_segmentInfo_fBarDuration_m7BF27650911F2817E41B8F85A9F6CBFDFC303450 (void);
// 0x0000042E System.Single AkMusicSyncCallbackInfo::get_segmentInfo_fGridDuration()
extern void AkMusicSyncCallbackInfo_get_segmentInfo_fGridDuration_m0D5255CB0ACE636DD01F2BC47BAF74631147F283 (void);
// 0x0000042F System.Single AkMusicSyncCallbackInfo::get_segmentInfo_fGridOffset()
extern void AkMusicSyncCallbackInfo_get_segmentInfo_fGridOffset_m1511349A96EF9270B8CE368E98A5F3AF0D85AF91 (void);
// 0x00000430 AkCallbackType AkMusicSyncCallbackInfo::get_musicSyncType()
extern void AkMusicSyncCallbackInfo_get_musicSyncType_mB6B873B8587474ED7BEC1623C431041F7EC59420 (void);
// 0x00000431 System.String AkMusicSyncCallbackInfo::get_userCueName()
extern void AkMusicSyncCallbackInfo_get_userCueName_mD3F76A73BB1CB12B1B9725EBB0611F56584230DF (void);
// 0x00000432 System.Void AkMusicSyncCallbackInfo::.ctor()
extern void AkMusicSyncCallbackInfo__ctor_m3E85EA55F4D73603641026965A27F198500EFB66 (void);
// 0x00000433 System.Void AkObjectInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkObjectInfo__ctor_mCE5EDE94A80E0454FEDF5D5DCBC6E3BC101AB929 (void);
// 0x00000434 System.IntPtr AkObjectInfo::getCPtr(AkObjectInfo)
extern void AkObjectInfo_getCPtr_m0F55EE0D28B9FC78C361D87555AA029AF285D7D1 (void);
// 0x00000435 System.Void AkObjectInfo::setCPtr(System.IntPtr)
extern void AkObjectInfo_setCPtr_m9038823F52B346165229069D8C6A79A35C6C0361 (void);
// 0x00000436 System.Void AkObjectInfo::Finalize()
extern void AkObjectInfo_Finalize_m96DD1202453EE5FBC7EE851E6F93BC810AF9A9DF (void);
// 0x00000437 System.Void AkObjectInfo::Dispose()
extern void AkObjectInfo_Dispose_m294DD7BBF2DD9320E9A6F5430B0F5DE16870F6DB (void);
// 0x00000438 System.Void AkObjectInfo::set_objID(System.UInt32)
extern void AkObjectInfo_set_objID_mABAF64988353B9ECFC2043E3378696C4CBF61DDE (void);
// 0x00000439 System.UInt32 AkObjectInfo::get_objID()
extern void AkObjectInfo_get_objID_m7BD11D1EF3FED8B205253A49361B0A8559AD2D72 (void);
// 0x0000043A System.Void AkObjectInfo::set_parentID(System.UInt32)
extern void AkObjectInfo_set_parentID_m0FA6509B888496FA341A0EAF56FB05C9A218E2AB (void);
// 0x0000043B System.UInt32 AkObjectInfo::get_parentID()
extern void AkObjectInfo_get_parentID_mB01DDE2B7C325C6A1631F70712512AB137CDF49D (void);
// 0x0000043C System.Void AkObjectInfo::set_iDepth(System.Int32)
extern void AkObjectInfo_set_iDepth_mC2E1FAC3565B6037FD7D8C7D1F5032772E5499C3 (void);
// 0x0000043D System.Int32 AkObjectInfo::get_iDepth()
extern void AkObjectInfo_get_iDepth_mA2F49C28213AB4150D9EA3A421D50D125F77F611 (void);
// 0x0000043E System.Void AkObjectInfo::Clear()
extern void AkObjectInfo_Clear_mC16209B1AFE6F6348977BF885B5AD99DCE0BBF19 (void);
// 0x0000043F System.Int32 AkObjectInfo::GetSizeOf()
extern void AkObjectInfo_GetSizeOf_mDA596C1F0675A03D10E45FD72ACB28369BB3B8F9 (void);
// 0x00000440 System.Void AkObjectInfo::Clone(AkObjectInfo)
extern void AkObjectInfo_Clone_m13735FF3C6582CD4AB65F8BAE227576D14C7191A (void);
// 0x00000441 System.Void AkObjectInfo::.ctor()
extern void AkObjectInfo__ctor_m071FAB0D84211977A17F8A52D843E240955D0280 (void);
// 0x00000442 System.Void AkObstructionOcclusionValues::.ctor(System.IntPtr,System.Boolean)
extern void AkObstructionOcclusionValues__ctor_mC767E62D54100FCD66B8C05D2CADEE19897466C3 (void);
// 0x00000443 System.IntPtr AkObstructionOcclusionValues::getCPtr(AkObstructionOcclusionValues)
extern void AkObstructionOcclusionValues_getCPtr_m309A1D245D8829B2C3A1957EBA94C255223155E7 (void);
// 0x00000444 System.Void AkObstructionOcclusionValues::setCPtr(System.IntPtr)
extern void AkObstructionOcclusionValues_setCPtr_mF5E0BBB2E07A02EE030EA17422883D7B6C55FC8B (void);
// 0x00000445 System.Void AkObstructionOcclusionValues::Finalize()
extern void AkObstructionOcclusionValues_Finalize_mAB62C3153A7CD26F49BF75E40ECDF3C21966B1B6 (void);
// 0x00000446 System.Void AkObstructionOcclusionValues::Dispose()
extern void AkObstructionOcclusionValues_Dispose_m601972A77CF2E69CFF360A84C9C661D83364E66C (void);
// 0x00000447 System.Void AkObstructionOcclusionValues::set_occlusion(System.Single)
extern void AkObstructionOcclusionValues_set_occlusion_m9244588BCC19732AB43F0635B711E84AA428EAF3 (void);
// 0x00000448 System.Single AkObstructionOcclusionValues::get_occlusion()
extern void AkObstructionOcclusionValues_get_occlusion_mE31FB65675EFDA59C99C60135AB089BF6675F026 (void);
// 0x00000449 System.Void AkObstructionOcclusionValues::set_obstruction(System.Single)
extern void AkObstructionOcclusionValues_set_obstruction_mD19BB96124A194EBFE59226EBE708E4AD5BD3A57 (void);
// 0x0000044A System.Single AkObstructionOcclusionValues::get_obstruction()
extern void AkObstructionOcclusionValues_get_obstruction_m5546ED73392A3ABA8979B7E63A751DF514225309 (void);
// 0x0000044B System.Void AkObstructionOcclusionValues::Clear()
extern void AkObstructionOcclusionValues_Clear_m0A1088476B897FD97285185E248E206D57B357F5 (void);
// 0x0000044C System.Int32 AkObstructionOcclusionValues::GetSizeOf()
extern void AkObstructionOcclusionValues_GetSizeOf_m532BEBB849E87245B96BDA269B2C13886536E138 (void);
// 0x0000044D System.Void AkObstructionOcclusionValues::Clone(AkObstructionOcclusionValues)
extern void AkObstructionOcclusionValues_Clone_m6A570F4247666CB3DD8542C51ABB144AD2AFFC91 (void);
// 0x0000044E System.Void AkObstructionOcclusionValues::.ctor()
extern void AkObstructionOcclusionValues__ctor_m5247D4ECDCCABF62D71DB9EDFBBF1CD8F961923D (void);
// 0x0000044F System.Void AkOutputSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkOutputSettings__ctor_m94F6A987DE5CE11AEF2B0554061B615410087EFD (void);
// 0x00000450 System.IntPtr AkOutputSettings::getCPtr(AkOutputSettings)
extern void AkOutputSettings_getCPtr_m2B9DEC290ACF5E2D3B2F5B1AEFE65B1DC864A550 (void);
// 0x00000451 System.Void AkOutputSettings::setCPtr(System.IntPtr)
extern void AkOutputSettings_setCPtr_m0DF074DC6D0C948698A3D12FE0364349EFF6892E (void);
// 0x00000452 System.Void AkOutputSettings::Finalize()
extern void AkOutputSettings_Finalize_mCF499B454C5651D95BB7F65E5F7AA1450030F7E1 (void);
// 0x00000453 System.Void AkOutputSettings::Dispose()
extern void AkOutputSettings_Dispose_m4E98E5DE73BAB7BD2A8D9B6C1518E5481D74DAC4 (void);
// 0x00000454 System.Void AkOutputSettings::.ctor()
extern void AkOutputSettings__ctor_m0D702C118AD9BE970AA0853F5A6401E44DE41E48 (void);
// 0x00000455 System.Void AkOutputSettings::.ctor(System.String,System.UInt32,AkChannelConfig,AkPanningRule)
extern void AkOutputSettings__ctor_mB4F504389D225B58799FF6CBCC0A9B5EC947B2C4 (void);
// 0x00000456 System.Void AkOutputSettings::.ctor(System.String,System.UInt32,AkChannelConfig)
extern void AkOutputSettings__ctor_m09FC0A94AFD4343C9499B6A816A5705331BE646B (void);
// 0x00000457 System.Void AkOutputSettings::.ctor(System.String,System.UInt32)
extern void AkOutputSettings__ctor_m12ADFA61446E19203DD6037A1DF1652705C01F10 (void);
// 0x00000458 System.Void AkOutputSettings::.ctor(System.String)
extern void AkOutputSettings__ctor_mACDBF336CC49A3A367ACEF0EF74570FAFFB2079F (void);
// 0x00000459 System.Void AkOutputSettings::set_audioDeviceShareset(System.UInt32)
extern void AkOutputSettings_set_audioDeviceShareset_m8C7B491066383092A581A542DA892517F507CF97 (void);
// 0x0000045A System.UInt32 AkOutputSettings::get_audioDeviceShareset()
extern void AkOutputSettings_get_audioDeviceShareset_m8F21357A81AF417450CFF62725050160E9A9B16D (void);
// 0x0000045B System.Void AkOutputSettings::set_idDevice(System.UInt32)
extern void AkOutputSettings_set_idDevice_mCE6412A4C4409E2A6D836F7DEBED0539E4F9CA9B (void);
// 0x0000045C System.UInt32 AkOutputSettings::get_idDevice()
extern void AkOutputSettings_get_idDevice_m209D285C0E9662472BD572BB7FE72FB45B473859 (void);
// 0x0000045D System.Void AkOutputSettings::set_ePanningRule(AkPanningRule)
extern void AkOutputSettings_set_ePanningRule_m0E99676034DD44CD04A8D2C8DC736C2280D3284C (void);
// 0x0000045E AkPanningRule AkOutputSettings::get_ePanningRule()
extern void AkOutputSettings_get_ePanningRule_mF0C091B7FEC05A69B95CB0E9019D78DFE8744924 (void);
// 0x0000045F System.Void AkOutputSettings::set_channelConfig(AkChannelConfig)
extern void AkOutputSettings_set_channelConfig_m5F784D9F7FD062F29CDFB0F0A4801A6FD58A6B5C (void);
// 0x00000460 AkChannelConfig AkOutputSettings::get_channelConfig()
extern void AkOutputSettings_get_channelConfig_m9502A0BEEA8558D9BCEBF5163758820BB399A741 (void);
// 0x00000461 System.Void AkPlaylist::.ctor(System.IntPtr,System.Boolean)
extern void AkPlaylist__ctor_mD0226CA32624E1BDA01AAF209C57A313A3D5AEE3 (void);
// 0x00000462 System.IntPtr AkPlaylist::getCPtr(AkPlaylist)
extern void AkPlaylist_getCPtr_mFD08226E6D45C0E2D06B0762F727E1E169830D11 (void);
// 0x00000463 System.Void AkPlaylist::setCPtr(System.IntPtr)
extern void AkPlaylist_setCPtr_m468C888D576A54D6D388CEE1537406DB6DA06F43 (void);
// 0x00000464 System.Void AkPlaylist::Finalize()
extern void AkPlaylist_Finalize_m52CCF78FFC75817CB469752BCD223814A003D53B (void);
// 0x00000465 System.Void AkPlaylist::Dispose()
extern void AkPlaylist_Dispose_mB26BFCBEDCD7A8CD34DBCECE09CF799BDB748577 (void);
// 0x00000466 AKRESULT AkPlaylist::Enqueue(System.UInt32,System.Int32,System.IntPtr,System.UInt32,AkExternalSourceInfoArray)
extern void AkPlaylist_Enqueue_m5CA62DE89A0C4BE46336E2306AA21EB72073CBAC (void);
// 0x00000467 AKRESULT AkPlaylist::Enqueue(System.UInt32,System.Int32,System.IntPtr,System.UInt32)
extern void AkPlaylist_Enqueue_mBADFF3B679BA5AFEF8F766AE3E711B926C65A90B (void);
// 0x00000468 AKRESULT AkPlaylist::Enqueue(System.UInt32,System.Int32,System.IntPtr)
extern void AkPlaylist_Enqueue_m842C0B4DAF6F23FB835E7F3D530E646D4711F85F (void);
// 0x00000469 AKRESULT AkPlaylist::Enqueue(System.UInt32,System.Int32)
extern void AkPlaylist_Enqueue_m1535BA40E5D3553EBF3C9D1012CC210281EB7E3B (void);
// 0x0000046A AKRESULT AkPlaylist::Enqueue(System.UInt32)
extern void AkPlaylist_Enqueue_m00E5007C9F1FE774CAE9B86B8AC37203FB3F5C8B (void);
// 0x0000046B System.Void AkPlaylist::.ctor()
extern void AkPlaylist__ctor_m44251DFDC4ECE6C169D92C7ABF1FC1313A14D461 (void);
// 0x0000046C System.Void AkPlaylistArray::.ctor(System.IntPtr,System.Boolean)
extern void AkPlaylistArray__ctor_m0759B47BA9F1DC28C556960145A5BC3814FCA23A (void);
// 0x0000046D System.IntPtr AkPlaylistArray::getCPtr(AkPlaylistArray)
extern void AkPlaylistArray_getCPtr_mE6AF99C52066C23D9AB287201B2C318B74B60203 (void);
// 0x0000046E System.Void AkPlaylistArray::setCPtr(System.IntPtr)
extern void AkPlaylistArray_setCPtr_mC433C2F9AF53681A16573B0CBE32C773B881CCC3 (void);
// 0x0000046F System.Void AkPlaylistArray::Finalize()
extern void AkPlaylistArray_Finalize_mF9083996CC7E8A8D2CBD1D50E1EFCC8F132F97C8 (void);
// 0x00000470 System.Void AkPlaylistArray::Dispose()
extern void AkPlaylistArray_Dispose_m7C2D39317A378BE45E6C73382EA03E6D152FB3E0 (void);
// 0x00000471 System.Void AkPlaylistArray::.ctor()
extern void AkPlaylistArray__ctor_mD02FE2DDB4E7A7D90878BDE3CA67497800428A6D (void);
// 0x00000472 AkIterator AkPlaylistArray::Begin()
extern void AkPlaylistArray_Begin_mC017D6D4CE157B3701625F2D9AE159C84A5BC773 (void);
// 0x00000473 AkIterator AkPlaylistArray::End()
extern void AkPlaylistArray_End_mC72C28BE7561FA603475752BA5F2BE92F058BDDC (void);
// 0x00000474 AkIterator AkPlaylistArray::FindEx(AkPlaylistItem)
extern void AkPlaylistArray_FindEx_m1F057428E445EEA23EF98C5226C78B5F1C524EA8 (void);
// 0x00000475 AkIterator AkPlaylistArray::Erase(AkIterator)
extern void AkPlaylistArray_Erase_mDC84B985BE79EF8517507ECA1EB159950111B053 (void);
// 0x00000476 System.Void AkPlaylistArray::Erase(System.UInt32)
extern void AkPlaylistArray_Erase_m3B4B063C2C3A6F1B64E481A8F8CA22345674BAB2 (void);
// 0x00000477 AkIterator AkPlaylistArray::EraseSwap(AkIterator)
extern void AkPlaylistArray_EraseSwap_m16F2770A9AECC5080A932404DE1B8D0A9D7899E9 (void);
// 0x00000478 System.Void AkPlaylistArray::EraseSwap(System.UInt32)
extern void AkPlaylistArray_EraseSwap_m68115D1272722DF0994B9B6079C0D6DF0C202D31 (void);
// 0x00000479 System.Boolean AkPlaylistArray::IsGrowingAllowed()
extern void AkPlaylistArray_IsGrowingAllowed_mC52F132449AC4A31BDB7C3DD0C78A2912441A009 (void);
// 0x0000047A AKRESULT AkPlaylistArray::Reserve(System.UInt32)
extern void AkPlaylistArray_Reserve_mC318B4E3EEEB365BBFBE4E65E9C25FF2E6AAD90A (void);
// 0x0000047B System.UInt32 AkPlaylistArray::Reserved()
extern void AkPlaylistArray_Reserved_mDC5B468B7F4013AD1371237BDFD61585B3F88085 (void);
// 0x0000047C System.Void AkPlaylistArray::Term()
extern void AkPlaylistArray_Term_m2886D469B824B71ACC23F52DB8E021EE4CFEC679 (void);
// 0x0000047D System.UInt32 AkPlaylistArray::Length()
extern void AkPlaylistArray_Length_mBAF1739BE5919147FBEF092D5DD199CF6B4E1B25 (void);
// 0x0000047E AkPlaylistItem AkPlaylistArray::Data()
extern void AkPlaylistArray_Data_mE986D51527A505E0236943AF8FB46D3853F741AC (void);
// 0x0000047F System.Boolean AkPlaylistArray::IsEmpty()
extern void AkPlaylistArray_IsEmpty_m16D4C7E401C6B66CEA24889BA5A9331788AB0B88 (void);
// 0x00000480 AkPlaylistItem AkPlaylistArray::Exists(AkPlaylistItem)
extern void AkPlaylistArray_Exists_mE63DAD1C6D51E3D8CCC16B0C1D8812E823E55E03 (void);
// 0x00000481 AkPlaylistItem AkPlaylistArray::AddLast()
extern void AkPlaylistArray_AddLast_mE0B04A5CE47C9B98466F85D0B57F83E5DD14F3CD (void);
// 0x00000482 AkPlaylistItem AkPlaylistArray::AddLast(AkPlaylistItem)
extern void AkPlaylistArray_AddLast_m98F01E8835F1A9FB78B912C4BEAC0BA9E477ACCA (void);
// 0x00000483 AkPlaylistItem AkPlaylistArray::Last()
extern void AkPlaylistArray_Last_m13DED1C1650BEF557BE703B9A713801B71827170 (void);
// 0x00000484 System.Void AkPlaylistArray::RemoveLast()
extern void AkPlaylistArray_RemoveLast_m7470823E8C2CC0C027E742F477CE7BF049F70652 (void);
// 0x00000485 AKRESULT AkPlaylistArray::Remove(AkPlaylistItem)
extern void AkPlaylistArray_Remove_m3E419A3D0B95F910AA3D3D340FA38F93669DFE76 (void);
// 0x00000486 AKRESULT AkPlaylistArray::RemoveSwap(AkPlaylistItem)
extern void AkPlaylistArray_RemoveSwap_mEEB9982115602E0A54FECE3467ADE598123A8D11 (void);
// 0x00000487 System.Void AkPlaylistArray::RemoveAll()
extern void AkPlaylistArray_RemoveAll_mC7E4F5FF99AF9A22D7B19762C5C6096D38556BC2 (void);
// 0x00000488 AkPlaylistItem AkPlaylistArray::ItemAtIndex(System.UInt32)
extern void AkPlaylistArray_ItemAtIndex_m38699BD0B9E9D88EB3FDDCADFFB336E172261D3B (void);
// 0x00000489 AkPlaylistItem AkPlaylistArray::Insert(System.UInt32)
extern void AkPlaylistArray_Insert_m5ECDEA3BD4F1F55085CA54F3EA1AF54887DCA37A (void);
// 0x0000048A System.Boolean AkPlaylistArray::GrowArray()
extern void AkPlaylistArray_GrowArray_mBE360F4DB483F06A2A4F669EB512783E7F2C5915 (void);
// 0x0000048B System.Boolean AkPlaylistArray::GrowArray(System.UInt32)
extern void AkPlaylistArray_GrowArray_m02214440EDB48B46940AA75B94C24D523500E928 (void);
// 0x0000048C System.Boolean AkPlaylistArray::Resize(System.UInt32)
extern void AkPlaylistArray_Resize_m6502AD1A6141ADF2DE5243F864514BB37E67C78C (void);
// 0x0000048D System.Void AkPlaylistArray::Transfer(AkPlaylistArray)
extern void AkPlaylistArray_Transfer_m9345AE40160BCA596B01FB3178E7DDA63DDA6F34 (void);
// 0x0000048E AKRESULT AkPlaylistArray::Copy(AkPlaylistArray)
extern void AkPlaylistArray_Copy_mA1A0443FB71521F9BED511F243B740624155A749 (void);
// 0x0000048F System.Void AkPlaylistItem::.ctor(System.IntPtr,System.Boolean)
extern void AkPlaylistItem__ctor_m6CF9FCED0497CEEBB134D3D3FB68392C6AB0A883 (void);
// 0x00000490 System.IntPtr AkPlaylistItem::getCPtr(AkPlaylistItem)
extern void AkPlaylistItem_getCPtr_m904B0CF53B67DF7F5E8641E328720A3C6DF61C26 (void);
// 0x00000491 System.Void AkPlaylistItem::setCPtr(System.IntPtr)
extern void AkPlaylistItem_setCPtr_mBEEDED36050ADFD2AAD3C8C6732831DC9385CDDD (void);
// 0x00000492 System.Void AkPlaylistItem::Finalize()
extern void AkPlaylistItem_Finalize_mB34CFFD4F7D8D15E72E2D0AF796DDC8E1CDBD6E6 (void);
// 0x00000493 System.Void AkPlaylistItem::Dispose()
extern void AkPlaylistItem_Dispose_mB76B1832E5506A9A2C2517615E7DF16059611796 (void);
// 0x00000494 System.Void AkPlaylistItem::.ctor()
extern void AkPlaylistItem__ctor_m520817A16B0A8200E712FD7B827EE3C9A74B68D2 (void);
// 0x00000495 System.Void AkPlaylistItem::.ctor(AkPlaylistItem)
extern void AkPlaylistItem__ctor_mAE148F5012C40BBAE7BA3507FBDA80A1D93E3877 (void);
// 0x00000496 AkPlaylistItem AkPlaylistItem::Assign(AkPlaylistItem)
extern void AkPlaylistItem_Assign_mA72EFB621DFEBD7783E2B717D674E03D01B79461 (void);
// 0x00000497 System.Boolean AkPlaylistItem::IsEqualTo(AkPlaylistItem)
extern void AkPlaylistItem_IsEqualTo_m57A86E834867AA88FDF4BAFA23DF9CDCF20FE29E (void);
// 0x00000498 AKRESULT AkPlaylistItem::SetExternalSources(System.UInt32,AkExternalSourceInfoArray)
extern void AkPlaylistItem_SetExternalSources_mEE05FB8D15A845A419A36B260D05B715134DECC2 (void);
// 0x00000499 System.Void AkPlaylistItem::set_audioNodeID(System.UInt32)
extern void AkPlaylistItem_set_audioNodeID_m55232347C8E19FA68FC877F4BD3096DBB7B5BD5D (void);
// 0x0000049A System.UInt32 AkPlaylistItem::get_audioNodeID()
extern void AkPlaylistItem_get_audioNodeID_m5C684B722F699D8AA364A0DF5F9F16ABE83A7CA4 (void);
// 0x0000049B System.Void AkPlaylistItem::set_msDelay(System.Int32)
extern void AkPlaylistItem_set_msDelay_mF7837BF8B97166AED4B4EAF2159FED9C905C2A7D (void);
// 0x0000049C System.Int32 AkPlaylistItem::get_msDelay()
extern void AkPlaylistItem_get_msDelay_m08790522F1A441E79A6690C3CE341C8E2FAB3641 (void);
// 0x0000049D System.Void AkPlaylistItem::set_pCustomInfo(System.IntPtr)
extern void AkPlaylistItem_set_pCustomInfo_mF10EE391BB63A7DA64DC63921A7BD7A745EAEA51 (void);
// 0x0000049E System.IntPtr AkPlaylistItem::get_pCustomInfo()
extern void AkPlaylistItem_get_pCustomInfo_m347988D07006E24B74B46895D08AF6C0CDA7677F (void);
// 0x0000049F System.Void AkPositioningData::.ctor(System.IntPtr,System.Boolean)
extern void AkPositioningData__ctor_m382B6977A4AB2F521971947B0ADBB8F3F84569BE (void);
// 0x000004A0 System.IntPtr AkPositioningData::getCPtr(AkPositioningData)
extern void AkPositioningData_getCPtr_mE4866F7A10976A8369B9ACF57E53A54AF1D60D4E (void);
// 0x000004A1 System.Void AkPositioningData::setCPtr(System.IntPtr)
extern void AkPositioningData_setCPtr_m3CDDB1B7790E1A8ADC555804F056B74FEB07D13B (void);
// 0x000004A2 System.Void AkPositioningData::Finalize()
extern void AkPositioningData_Finalize_mD190DB60FD9C8E86C06ECCC4D35E9FEFBE716A1A (void);
// 0x000004A3 System.Void AkPositioningData::Dispose()
extern void AkPositioningData_Dispose_mD2658D2EF052AD50052C2F2126953E94117176B7 (void);
// 0x000004A4 System.Void AkPositioningData::set_threeD(Ak3dData)
extern void AkPositioningData_set_threeD_m639B0E1887E8A184723A79ADCB66DCD8563B49DC (void);
// 0x000004A5 Ak3dData AkPositioningData::get_threeD()
extern void AkPositioningData_get_threeD_m8B9BE39B5090C816B789B21ABDDDF660148D96A7 (void);
// 0x000004A6 System.Void AkPositioningData::set_behavioral(AkBehavioralPositioningData)
extern void AkPositioningData_set_behavioral_m51C86D86D5B79B454A657AAA1A7B3BB8D3029E70 (void);
// 0x000004A7 AkBehavioralPositioningData AkPositioningData::get_behavioral()
extern void AkPositioningData_get_behavioral_m9DC77E9C3B463495A73CD7CD664ED48C964854D8 (void);
// 0x000004A8 System.Void AkPositioningData::.ctor()
extern void AkPositioningData__ctor_m2837A5A084DC0EC47E74D67C4FCCB2FD6A18E480 (void);
// 0x000004A9 System.Void AkPositioningInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkPositioningInfo__ctor_mF3A55D4ADA8A105617DBB1CA809615418C34997C (void);
// 0x000004AA System.IntPtr AkPositioningInfo::getCPtr(AkPositioningInfo)
extern void AkPositioningInfo_getCPtr_m1EB4A693753BDCB822FC6F6E72F2DEEC3456D493 (void);
// 0x000004AB System.Void AkPositioningInfo::setCPtr(System.IntPtr)
extern void AkPositioningInfo_setCPtr_m048EB48569F6AF27D75C3C530F0F5D6175269524 (void);
// 0x000004AC System.Void AkPositioningInfo::Finalize()
extern void AkPositioningInfo_Finalize_m55292DB38C5A2A09F54B2D4D5A68902A3F5EF1F2 (void);
// 0x000004AD System.Void AkPositioningInfo::Dispose()
extern void AkPositioningInfo_Dispose_m3AF4968F9880DC63CA60721EE32C7D183D23DE49 (void);
// 0x000004AE System.Void AkPositioningInfo::set_fCenterPct(System.Single)
extern void AkPositioningInfo_set_fCenterPct_mE811EA2BD163789A5997CC873E3643238B2E2DB2 (void);
// 0x000004AF System.Single AkPositioningInfo::get_fCenterPct()
extern void AkPositioningInfo_get_fCenterPct_mEC61D36692E858F660258ADC3267B48B9FF1EB2D (void);
// 0x000004B0 System.Void AkPositioningInfo::set_pannerType(AkSpeakerPanningType)
extern void AkPositioningInfo_set_pannerType_m7C00914F1D0CD93A177043456114B6710EA98106 (void);
// 0x000004B1 AkSpeakerPanningType AkPositioningInfo::get_pannerType()
extern void AkPositioningInfo_get_pannerType_mD4A1B7FA9A4857C50AC72C7512ED628DF9CA232A (void);
// 0x000004B2 System.Void AkPositioningInfo::set_e3dPositioningType(Ak3DPositionType)
extern void AkPositioningInfo_set_e3dPositioningType_m6CB19208E55074619A778790B1F60C1CAB04F583 (void);
// 0x000004B3 Ak3DPositionType AkPositioningInfo::get_e3dPositioningType()
extern void AkPositioningInfo_get_e3dPositioningType_m996668167C41E7B49AA5B0BBD3839E8371B9B594 (void);
// 0x000004B4 System.Void AkPositioningInfo::set_bHoldEmitterPosAndOrient(System.Boolean)
extern void AkPositioningInfo_set_bHoldEmitterPosAndOrient_m1A9FF1E178D96711621FDFD9D477D6FEC98ED5BB (void);
// 0x000004B5 System.Boolean AkPositioningInfo::get_bHoldEmitterPosAndOrient()
extern void AkPositioningInfo_get_bHoldEmitterPosAndOrient_m56358BE54306E5C7EA2AF06791F1CB251C862F38 (void);
// 0x000004B6 System.Void AkPositioningInfo::set_e3DSpatializationMode(Ak3DSpatializationMode)
extern void AkPositioningInfo_set_e3DSpatializationMode_m41370F6B0AB6E53A0E64C322EC868D414EA1B7AE (void);
// 0x000004B7 Ak3DSpatializationMode AkPositioningInfo::get_e3DSpatializationMode()
extern void AkPositioningInfo_get_e3DSpatializationMode_mFC7EC296E74D68D6606DCD7CEEF7D40F16FFD5FD (void);
// 0x000004B8 System.Void AkPositioningInfo::set_bEnableAttenuation(System.Boolean)
extern void AkPositioningInfo_set_bEnableAttenuation_m337F0341DD66BD43C2FC728ADBB522B9B8AAE0FB (void);
// 0x000004B9 System.Boolean AkPositioningInfo::get_bEnableAttenuation()
extern void AkPositioningInfo_get_bEnableAttenuation_m9B739DECB33AB05849F9FC238184B00E8F50292A (void);
// 0x000004BA System.Void AkPositioningInfo::set_bUseConeAttenuation(System.Boolean)
extern void AkPositioningInfo_set_bUseConeAttenuation_mBE6C1050A468F3715B03A86E4473739D3B0AE0C1 (void);
// 0x000004BB System.Boolean AkPositioningInfo::get_bUseConeAttenuation()
extern void AkPositioningInfo_get_bUseConeAttenuation_mBB43BD30D50CDD62D58E023E940D2087B71A1D56 (void);
// 0x000004BC System.Void AkPositioningInfo::set_fInnerAngle(System.Single)
extern void AkPositioningInfo_set_fInnerAngle_mF039B0960158C135BFEDC47888641445E6A385DB (void);
// 0x000004BD System.Single AkPositioningInfo::get_fInnerAngle()
extern void AkPositioningInfo_get_fInnerAngle_mC919D775F6AB2B98EA408AFC3D4A2DE81CCAEF88 (void);
// 0x000004BE System.Void AkPositioningInfo::set_fOuterAngle(System.Single)
extern void AkPositioningInfo_set_fOuterAngle_m8F1E3F2BFCEFEC4FC4EBAF22F1DEB607745DFAF5 (void);
// 0x000004BF System.Single AkPositioningInfo::get_fOuterAngle()
extern void AkPositioningInfo_get_fOuterAngle_m72F086E3CD15C8CD436549F32E6BDEA5814F4A63 (void);
// 0x000004C0 System.Void AkPositioningInfo::set_fConeMaxAttenuation(System.Single)
extern void AkPositioningInfo_set_fConeMaxAttenuation_m1547C2C4A9D810F45776987FC647E30DA3CA0473 (void);
// 0x000004C1 System.Single AkPositioningInfo::get_fConeMaxAttenuation()
extern void AkPositioningInfo_get_fConeMaxAttenuation_mDDCC51FE497991B280F6D00986C3EAAC90A5CA9F (void);
// 0x000004C2 System.Void AkPositioningInfo::set_LPFCone(System.Single)
extern void AkPositioningInfo_set_LPFCone_m9145499B694484B98727E345312D151FF8AD4F83 (void);
// 0x000004C3 System.Single AkPositioningInfo::get_LPFCone()
extern void AkPositioningInfo_get_LPFCone_mE67629EDD9CD73BD87A7E3BAF18562403AF17768 (void);
// 0x000004C4 System.Void AkPositioningInfo::set_HPFCone(System.Single)
extern void AkPositioningInfo_set_HPFCone_m6EDC1BEA46FAD67F75EF1F46ECC8F06E490117F2 (void);
// 0x000004C5 System.Single AkPositioningInfo::get_HPFCone()
extern void AkPositioningInfo_get_HPFCone_m6ED5362AB0A28315CDF5667C0B217A1D108BE05B (void);
// 0x000004C6 System.Void AkPositioningInfo::set_fMaxDistance(System.Single)
extern void AkPositioningInfo_set_fMaxDistance_m66084F52AAC77C532AC943A08F76F19BAE9E04E7 (void);
// 0x000004C7 System.Single AkPositioningInfo::get_fMaxDistance()
extern void AkPositioningInfo_get_fMaxDistance_mF70257193D64B4BA82C3A19DCAB1B8A17E150CF9 (void);
// 0x000004C8 System.Void AkPositioningInfo::set_fVolDryAtMaxDist(System.Single)
extern void AkPositioningInfo_set_fVolDryAtMaxDist_m0FF1AA3FE96162A182993AB8E0410F8047F77B3A (void);
// 0x000004C9 System.Single AkPositioningInfo::get_fVolDryAtMaxDist()
extern void AkPositioningInfo_get_fVolDryAtMaxDist_m466124554A0E5BB0B1A7DA0636B554A31E230E15 (void);
// 0x000004CA System.Void AkPositioningInfo::set_fVolAuxGameDefAtMaxDist(System.Single)
extern void AkPositioningInfo_set_fVolAuxGameDefAtMaxDist_m1024FE6B0AFC95A1BF586681831920BD8B057093 (void);
// 0x000004CB System.Single AkPositioningInfo::get_fVolAuxGameDefAtMaxDist()
extern void AkPositioningInfo_get_fVolAuxGameDefAtMaxDist_m9B07A6B4BECFE02387B71147646D70A25697AB49 (void);
// 0x000004CC System.Void AkPositioningInfo::set_fVolAuxUserDefAtMaxDist(System.Single)
extern void AkPositioningInfo_set_fVolAuxUserDefAtMaxDist_mF3C168EDAAC19CA0EBA144182204E6CF250A5AA7 (void);
// 0x000004CD System.Single AkPositioningInfo::get_fVolAuxUserDefAtMaxDist()
extern void AkPositioningInfo_get_fVolAuxUserDefAtMaxDist_m1747E0AF3565FED83D12FD20A2C66184ADE72A46 (void);
// 0x000004CE System.Void AkPositioningInfo::set_LPFValueAtMaxDist(System.Single)
extern void AkPositioningInfo_set_LPFValueAtMaxDist_m54C7ED72EA4B5DD2A47D19DBF11C5B9276FF96AE (void);
// 0x000004CF System.Single AkPositioningInfo::get_LPFValueAtMaxDist()
extern void AkPositioningInfo_get_LPFValueAtMaxDist_m91C746F27380AB3ECC7D666CF305B1E565B2E71C (void);
// 0x000004D0 System.Void AkPositioningInfo::set_HPFValueAtMaxDist(System.Single)
extern void AkPositioningInfo_set_HPFValueAtMaxDist_mC1F9DB8536E83848AC65E4DB7C0872EDFD934868 (void);
// 0x000004D1 System.Single AkPositioningInfo::get_HPFValueAtMaxDist()
extern void AkPositioningInfo_get_HPFValueAtMaxDist_m14A222BDAE644FB47496530CA4F86EFFAC50ADBD (void);
// 0x000004D2 System.Void AkPositioningInfo::.ctor()
extern void AkPositioningInfo__ctor_m7F9E18056344E7F1C4EE9FDE70F4526A7D63201A (void);
// 0x000004D3 System.Void AkRamp::.ctor(System.IntPtr,System.Boolean)
extern void AkRamp__ctor_m3FF2A1707945C9CF161967A81B264BC106CA3306 (void);
// 0x000004D4 System.IntPtr AkRamp::getCPtr(AkRamp)
extern void AkRamp_getCPtr_m45D872273A71AF96E4E137ECEDE28029C61A3091 (void);
// 0x000004D5 System.Void AkRamp::setCPtr(System.IntPtr)
extern void AkRamp_setCPtr_m09A8E5D5B1EEE12132D84ED348AD028A017A1A20 (void);
// 0x000004D6 System.Void AkRamp::Finalize()
extern void AkRamp_Finalize_mFF2392CE0CDDD356BFE1A65CFDE57E6B12FD8A9E (void);
// 0x000004D7 System.Void AkRamp::Dispose()
extern void AkRamp_Dispose_m131628278CD90939C2F6EB517C3F367355ACD14B (void);
// 0x000004D8 System.Void AkRamp::.ctor()
extern void AkRamp__ctor_m529EEA4D3047E0D23CB26B929C178BB467A69992 (void);
// 0x000004D9 System.Void AkRamp::.ctor(System.Single,System.Single)
extern void AkRamp__ctor_m93AE55AF12DD86EAB21D1CAAD72DCBBEDC26FD29 (void);
// 0x000004DA System.Void AkRamp::set_fPrev(System.Single)
extern void AkRamp_set_fPrev_mA063AF173D60EDB4E1187222D216E9E1590B8B14 (void);
// 0x000004DB System.Single AkRamp::get_fPrev()
extern void AkRamp_get_fPrev_mA0BC780B34A607DBCCE9674F9E299A5FE0D72861 (void);
// 0x000004DC System.Void AkRamp::set_fNext(System.Single)
extern void AkRamp_set_fNext_mE9CAE211BBE45F7DB7020626B0844DBBF9814296 (void);
// 0x000004DD System.Single AkRamp::get_fNext()
extern void AkRamp_get_fNext_mB1D661A74AF3E9A27908E4C3561AC15464E2702B (void);
// 0x000004DE System.Void AkReflectionPathInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkReflectionPathInfo__ctor_mB63E1CD8087321E1EEDD009BD7A38A269D3195CF (void);
// 0x000004DF System.IntPtr AkReflectionPathInfo::getCPtr(AkReflectionPathInfo)
extern void AkReflectionPathInfo_getCPtr_mE7084FE3F7A89D86F02B0D6785C14E2407FE4291 (void);
// 0x000004E0 System.Void AkReflectionPathInfo::setCPtr(System.IntPtr)
extern void AkReflectionPathInfo_setCPtr_mE721C90C49017A25166A4EDFFCFF34127161D113 (void);
// 0x000004E1 System.Void AkReflectionPathInfo::Finalize()
extern void AkReflectionPathInfo_Finalize_m6288011C7F78C5E03602F9045F84A571F63F4E78 (void);
// 0x000004E2 System.Void AkReflectionPathInfo::Dispose()
extern void AkReflectionPathInfo_Dispose_m7980991119F17D490F5B845AD84237D4E8C8D3DB (void);
// 0x000004E3 System.Void AkReflectionPathInfo::set_imageSource(UnityEngine.Vector3)
extern void AkReflectionPathInfo_set_imageSource_m86BE4AA0CF4AC33FA37BC7F26958CF835630C9AF (void);
// 0x000004E4 UnityEngine.Vector3 AkReflectionPathInfo::get_imageSource()
extern void AkReflectionPathInfo_get_imageSource_mEEB87AB5D687F8DD471A45D03C6C6D6878438BEE (void);
// 0x000004E5 System.Void AkReflectionPathInfo::set_numPathPoints(System.UInt32)
extern void AkReflectionPathInfo_set_numPathPoints_mD0C020863361E84A7C3846B04D5F8D238C806F95 (void);
// 0x000004E6 System.UInt32 AkReflectionPathInfo::get_numPathPoints()
extern void AkReflectionPathInfo_get_numPathPoints_m7BCF03836D78ADF11A54433DB1140A37FE036C2F (void);
// 0x000004E7 System.Void AkReflectionPathInfo::set_numReflections(System.UInt32)
extern void AkReflectionPathInfo_set_numReflections_m2A9C03A50E4B5D8611BF8060BC0993C191DDFA92 (void);
// 0x000004E8 System.UInt32 AkReflectionPathInfo::get_numReflections()
extern void AkReflectionPathInfo_get_numReflections_m31FE6771406B958FC297EB58AF552DC74D8ED3AA (void);
// 0x000004E9 System.Void AkReflectionPathInfo::set_level(System.Single)
extern void AkReflectionPathInfo_set_level_m70327C7D790C8D1743FD33C6855F3C94870F292B (void);
// 0x000004EA System.Single AkReflectionPathInfo::get_level()
extern void AkReflectionPathInfo_get_level_m6FAF7CBE5A6F4472993B723A232C8542F07F4976 (void);
// 0x000004EB System.Void AkReflectionPathInfo::set_isOccluded(System.Boolean)
extern void AkReflectionPathInfo_set_isOccluded_mFEFF39D99FB67FD9FD39926A77D87C23D6CA399F (void);
// 0x000004EC System.Boolean AkReflectionPathInfo::get_isOccluded()
extern void AkReflectionPathInfo_get_isOccluded_mF0D3952B217679DDE564A638FEBB29B689A59325 (void);
// 0x000004ED System.Int32 AkReflectionPathInfo::GetSizeOf()
extern void AkReflectionPathInfo_GetSizeOf_m0EEB68CD65D01C974CADEA47E6C06F2EBC3BF035 (void);
// 0x000004EE UnityEngine.Vector3 AkReflectionPathInfo::GetPathPoint(System.UInt32)
extern void AkReflectionPathInfo_GetPathPoint_m543DB40337D1C5F297989752AB77A4DFDA07FBC8 (void);
// 0x000004EF AkAcousticSurface AkReflectionPathInfo::GetAcousticSurface(System.UInt32)
extern void AkReflectionPathInfo_GetAcousticSurface_m7B39C3C1098C53AD74AAF6F3E1DA6A031EBB0B69 (void);
// 0x000004F0 System.Single AkReflectionPathInfo::GetDiffraction(System.UInt32)
extern void AkReflectionPathInfo_GetDiffraction_m9CB7BEF28D21A24E8801C6DE876CC615F927D78F (void);
// 0x000004F1 System.Void AkReflectionPathInfo::Clone(AkReflectionPathInfo)
extern void AkReflectionPathInfo_Clone_m8A5619C3DF7B83296A7F2096DCF35A6900880386 (void);
// 0x000004F2 System.Void AkReflectionPathInfo::.ctor()
extern void AkReflectionPathInfo__ctor_m86B4488E6C855F22BF780BBEA80013C147028942 (void);
// 0x000004F3 System.Void AkResourceMonitorDataSummary::.ctor(System.IntPtr,System.Boolean)
extern void AkResourceMonitorDataSummary__ctor_m59EF9A275C7F27E43B4C314F7AC54EC9E873170E (void);
// 0x000004F4 System.IntPtr AkResourceMonitorDataSummary::getCPtr(AkResourceMonitorDataSummary)
extern void AkResourceMonitorDataSummary_getCPtr_mE67D22BF7E72477CE32A7C403ED10EFA3CA95D00 (void);
// 0x000004F5 System.Void AkResourceMonitorDataSummary::setCPtr(System.IntPtr)
extern void AkResourceMonitorDataSummary_setCPtr_m60E5CD3151B065E28F7A647AF7A54C2A1167B15E (void);
// 0x000004F6 System.Void AkResourceMonitorDataSummary::Finalize()
extern void AkResourceMonitorDataSummary_Finalize_m28404386949BCB64FD9D994FA9B25F96CAC85EAD (void);
// 0x000004F7 System.Void AkResourceMonitorDataSummary::Dispose()
extern void AkResourceMonitorDataSummary_Dispose_mA5050EEF0926DD9B64F06C4A88719AAD15D7AF6C (void);
// 0x000004F8 System.Void AkResourceMonitorDataSummary::set_totalCPU(System.Single)
extern void AkResourceMonitorDataSummary_set_totalCPU_mCB785F0DAF2051C04B42BEC3FD7C3EECE5ADD2C2 (void);
// 0x000004F9 System.Single AkResourceMonitorDataSummary::get_totalCPU()
extern void AkResourceMonitorDataSummary_get_totalCPU_mF6E7F5AF81791965C990EEDE57D809E100614AD4 (void);
// 0x000004FA System.Void AkResourceMonitorDataSummary::set_pluginCPU(System.Single)
extern void AkResourceMonitorDataSummary_set_pluginCPU_m32E0059DA823F968C581F67B12CC334ED33CF197 (void);
// 0x000004FB System.Single AkResourceMonitorDataSummary::get_pluginCPU()
extern void AkResourceMonitorDataSummary_get_pluginCPU_m7269A904417C69C43C3B1B162861E3DD738EBD2A (void);
// 0x000004FC System.Void AkResourceMonitorDataSummary::set_physicalVoices(System.UInt32)
extern void AkResourceMonitorDataSummary_set_physicalVoices_m2103FFC630F0BADA96A25AF4D3ED4B5BD1F00A76 (void);
// 0x000004FD System.UInt32 AkResourceMonitorDataSummary::get_physicalVoices()
extern void AkResourceMonitorDataSummary_get_physicalVoices_mC2A2673C6F0E20FC2141371EC7B9871F974566BD (void);
// 0x000004FE System.Void AkResourceMonitorDataSummary::set_virtualVoices(System.UInt32)
extern void AkResourceMonitorDataSummary_set_virtualVoices_m2B9CD4B1A3A265A8E54AC755CEF645357CC09EF8 (void);
// 0x000004FF System.UInt32 AkResourceMonitorDataSummary::get_virtualVoices()
extern void AkResourceMonitorDataSummary_get_virtualVoices_m0B063561D17DEE255245776257FE6E2C2A06E9E7 (void);
// 0x00000500 System.Void AkResourceMonitorDataSummary::set_totalVoices(System.UInt32)
extern void AkResourceMonitorDataSummary_set_totalVoices_mAF8BB437389A387B92690ABB30422A550EF458B6 (void);
// 0x00000501 System.UInt32 AkResourceMonitorDataSummary::get_totalVoices()
extern void AkResourceMonitorDataSummary_get_totalVoices_mE2C265533F8014266CCCB2CA7C4B94B23E434DD5 (void);
// 0x00000502 System.Void AkResourceMonitorDataSummary::set_nbActiveEvents(System.UInt32)
extern void AkResourceMonitorDataSummary_set_nbActiveEvents_mEC3EABE86ABC537F8DE86A3077C183FB6B9E4A39 (void);
// 0x00000503 System.UInt32 AkResourceMonitorDataSummary::get_nbActiveEvents()
extern void AkResourceMonitorDataSummary_get_nbActiveEvents_m4BA1961670AA7EDED320CB53600A2A8D771DE9D3 (void);
// 0x00000504 System.Void AkResourceMonitorDataSummary::.ctor()
extern void AkResourceMonitorDataSummary__ctor_m26D38808869AC1C63CC53FC50F282A9D92C14BF9 (void);
// 0x00000505 System.Void AkRoomParams::.ctor(System.IntPtr,System.Boolean)
extern void AkRoomParams__ctor_mC9E905DC3408059A38A6C3206352DDABE3E3981E (void);
// 0x00000506 System.IntPtr AkRoomParams::getCPtr(AkRoomParams)
extern void AkRoomParams_getCPtr_mF004C6DD82FF71EF27335950782AB98BEC766EA2 (void);
// 0x00000507 System.Void AkRoomParams::setCPtr(System.IntPtr)
extern void AkRoomParams_setCPtr_m526AC81A7DEA16E3FFEC7BCCFD987C1533B2B860 (void);
// 0x00000508 System.Void AkRoomParams::Finalize()
extern void AkRoomParams_Finalize_m4BDEF557A43A4E3CB4525C0ECB9C7D14E0AC633D (void);
// 0x00000509 System.Void AkRoomParams::Dispose()
extern void AkRoomParams_Dispose_m504E98E1510BACA2206C989BBFD1B519208F39C5 (void);
// 0x0000050A System.Void AkRoomParams::.ctor()
extern void AkRoomParams__ctor_m0AB869F8BCE06C89FE7D196E66CC5EEF3ED447FF (void);
// 0x0000050B System.Void AkRoomParams::.ctor(AkRoomParams)
extern void AkRoomParams__ctor_mCC754257A489C158FE7081DDDDAE11FBD834B904 (void);
// 0x0000050C System.Void AkRoomParams::set_Front(UnityEngine.Vector3)
extern void AkRoomParams_set_Front_mF4DAFD1DB1828488BED1580442F5F72B94783F6C (void);
// 0x0000050D UnityEngine.Vector3 AkRoomParams::get_Front()
extern void AkRoomParams_get_Front_m0C8B5D4C659736AC282F150E6CA0F37B3C98C2F2 (void);
// 0x0000050E System.Void AkRoomParams::set_Up(UnityEngine.Vector3)
extern void AkRoomParams_set_Up_mB4D6713A70AC1505B7435A1AD7D82A19337FA1EB (void);
// 0x0000050F UnityEngine.Vector3 AkRoomParams::get_Up()
extern void AkRoomParams_get_Up_m66B7F4BC389D8A7BE41AD635CD282C8D81B26E50 (void);
// 0x00000510 System.Void AkRoomParams::set_ReverbAuxBus(System.UInt32)
extern void AkRoomParams_set_ReverbAuxBus_m835F821EE215A0A88F999984662A85ADB29523CA (void);
// 0x00000511 System.UInt32 AkRoomParams::get_ReverbAuxBus()
extern void AkRoomParams_get_ReverbAuxBus_mE78876F1138AE708E33F3B0B11B774DD9B01111B (void);
// 0x00000512 System.Void AkRoomParams::set_ReverbLevel(System.Single)
extern void AkRoomParams_set_ReverbLevel_m0A47F69EBC118F91886225FF0CA2A361F1392F85 (void);
// 0x00000513 System.Single AkRoomParams::get_ReverbLevel()
extern void AkRoomParams_get_ReverbLevel_m9F3270F5747D73E91DE9818ED54E9E580F33AF00 (void);
// 0x00000514 System.Void AkRoomParams::set_TransmissionLoss(System.Single)
extern void AkRoomParams_set_TransmissionLoss_mD472C1E730113CC08D7B5E5A23A1AD1103D4E1AC (void);
// 0x00000515 System.Single AkRoomParams::get_TransmissionLoss()
extern void AkRoomParams_get_TransmissionLoss_mEFDF49C6C063624C418A680D237FC3E6A21A4DD8 (void);
// 0x00000516 System.Void AkRoomParams::set_RoomGameObj_AuxSendLevelToSelf(System.Single)
extern void AkRoomParams_set_RoomGameObj_AuxSendLevelToSelf_m17626967746433B76783C1F7EB92B43856783F91 (void);
// 0x00000517 System.Single AkRoomParams::get_RoomGameObj_AuxSendLevelToSelf()
extern void AkRoomParams_get_RoomGameObj_AuxSendLevelToSelf_mCB8B89F24892E7AC3E6C6595263E80F8C3C03327 (void);
// 0x00000518 System.Void AkRoomParams::set_RoomGameObj_KeepRegistered(System.Boolean)
extern void AkRoomParams_set_RoomGameObj_KeepRegistered_m3FE97F6C172836DAED9614075AF0E6C755B2C262 (void);
// 0x00000519 System.Boolean AkRoomParams::get_RoomGameObj_KeepRegistered()
extern void AkRoomParams_get_RoomGameObj_KeepRegistered_mE34FFA7D8469054507C6EFF53F99FEC651DCBD01 (void);
// 0x0000051A System.Void AkSegmentInfo::.ctor(System.IntPtr,System.Boolean)
extern void AkSegmentInfo__ctor_m14176C30446456BA50502D4C9489E1F45D138582 (void);
// 0x0000051B System.IntPtr AkSegmentInfo::getCPtr(AkSegmentInfo)
extern void AkSegmentInfo_getCPtr_m76067467B415A59DEADBD3F721E008F60A8C52C6 (void);
// 0x0000051C System.Void AkSegmentInfo::setCPtr(System.IntPtr)
extern void AkSegmentInfo_setCPtr_m406347FB3A4C872EFE8958A5D7AF834C1CAB9185 (void);
// 0x0000051D System.Void AkSegmentInfo::Finalize()
extern void AkSegmentInfo_Finalize_m18247AC55C678A2D1417AC59F21AA5874E28D399 (void);
// 0x0000051E System.Void AkSegmentInfo::Dispose()
extern void AkSegmentInfo_Dispose_mD54D958C43372E3297F170408AD4941019477E29 (void);
// 0x0000051F System.Void AkSegmentInfo::set_iCurrentPosition(System.Int32)
extern void AkSegmentInfo_set_iCurrentPosition_m1AD96F327811304B878DB92C262FDA70D9140A9B (void);
// 0x00000520 System.Int32 AkSegmentInfo::get_iCurrentPosition()
extern void AkSegmentInfo_get_iCurrentPosition_mA3AACE1F7588701CBB7AFCE743B239E53629D5F5 (void);
// 0x00000521 System.Void AkSegmentInfo::set_iPreEntryDuration(System.Int32)
extern void AkSegmentInfo_set_iPreEntryDuration_m9206E9EC219DA9711AB8015AD23106674C01B146 (void);
// 0x00000522 System.Int32 AkSegmentInfo::get_iPreEntryDuration()
extern void AkSegmentInfo_get_iPreEntryDuration_m41041698DDCD6CBFA8AF7144C4EB1328FEE53582 (void);
// 0x00000523 System.Void AkSegmentInfo::set_iActiveDuration(System.Int32)
extern void AkSegmentInfo_set_iActiveDuration_mEBF354CA1E4EF296E92E35155A7A9589D93E067B (void);
// 0x00000524 System.Int32 AkSegmentInfo::get_iActiveDuration()
extern void AkSegmentInfo_get_iActiveDuration_m8ECC61C145FCCD1B8BA3A84131AC3F6A1A7D0117 (void);
// 0x00000525 System.Void AkSegmentInfo::set_iPostExitDuration(System.Int32)
extern void AkSegmentInfo_set_iPostExitDuration_mA5194506252B06E6611F98E65ED3708C59B06FEF (void);
// 0x00000526 System.Int32 AkSegmentInfo::get_iPostExitDuration()
extern void AkSegmentInfo_get_iPostExitDuration_m90B666FBF46F4FCF1B3B137A7E749E7AE833488E (void);
// 0x00000527 System.Void AkSegmentInfo::set_iRemainingLookAheadTime(System.Int32)
extern void AkSegmentInfo_set_iRemainingLookAheadTime_mF416A1D73E9D1801794C9F8F61D99A3FF6CDA1EB (void);
// 0x00000528 System.Int32 AkSegmentInfo::get_iRemainingLookAheadTime()
extern void AkSegmentInfo_get_iRemainingLookAheadTime_m62773B25FCC66E4611A9475982C2198FEB03D171 (void);
// 0x00000529 System.Void AkSegmentInfo::set_fBeatDuration(System.Single)
extern void AkSegmentInfo_set_fBeatDuration_mC39E1C0D78E25FCB35A7FFFCB43E5939AB2CEAF3 (void);
// 0x0000052A System.Single AkSegmentInfo::get_fBeatDuration()
extern void AkSegmentInfo_get_fBeatDuration_mEAC65283557C7017A2E3355578060686B7BBA28C (void);
// 0x0000052B System.Void AkSegmentInfo::set_fBarDuration(System.Single)
extern void AkSegmentInfo_set_fBarDuration_mADC0534D7AC7B04B674003062D744BF3561848DC (void);
// 0x0000052C System.Single AkSegmentInfo::get_fBarDuration()
extern void AkSegmentInfo_get_fBarDuration_mA2492856A6B608FAC9C3424AEAB9355EC3E0D6E1 (void);
// 0x0000052D System.Void AkSegmentInfo::set_fGridDuration(System.Single)
extern void AkSegmentInfo_set_fGridDuration_m352C4B2C2B28F865097073806F11DF5DC90F1AA6 (void);
// 0x0000052E System.Single AkSegmentInfo::get_fGridDuration()
extern void AkSegmentInfo_get_fGridDuration_m8717610BCBA38EC45BA5ABA9154369F69AE74C03 (void);
// 0x0000052F System.Void AkSegmentInfo::set_fGridOffset(System.Single)
extern void AkSegmentInfo_set_fGridOffset_m048A94A531BE001F9C0703958FEF65D91BA81C09 (void);
// 0x00000530 System.Single AkSegmentInfo::get_fGridOffset()
extern void AkSegmentInfo_get_fGridOffset_m5FBCCB4DB6EF7A5745495DFBFFC3017E826D648F (void);
// 0x00000531 System.Void AkSegmentInfo::.ctor()
extern void AkSegmentInfo__ctor_mD9754B7276B47CFD653135FF5BB04965DBB39C25 (void);
// 0x00000532 System.Void AkSerializedCallbackHeader::.ctor(System.IntPtr,System.Boolean)
extern void AkSerializedCallbackHeader__ctor_mD7FE279F1CACFCF2A392265FC4696FB478BBCA3B (void);
// 0x00000533 System.IntPtr AkSerializedCallbackHeader::getCPtr(AkSerializedCallbackHeader)
extern void AkSerializedCallbackHeader_getCPtr_m90BF79CE557EC41B8D49E56F91D33A76464FCD23 (void);
// 0x00000534 System.Void AkSerializedCallbackHeader::setCPtr(System.IntPtr)
extern void AkSerializedCallbackHeader_setCPtr_mA175B98EA0310FDF14DA4551C102DFF12BA56460 (void);
// 0x00000535 System.Void AkSerializedCallbackHeader::Finalize()
extern void AkSerializedCallbackHeader_Finalize_m73F5C3C40F45F7B8B5BAC8AE161C87E0458492D5 (void);
// 0x00000536 System.Void AkSerializedCallbackHeader::Dispose()
extern void AkSerializedCallbackHeader_Dispose_m6A2D4FC58227C613DEB75002960C580D9399AB07 (void);
// 0x00000537 System.IntPtr AkSerializedCallbackHeader::get_pPackage()
extern void AkSerializedCallbackHeader_get_pPackage_mCA96D390EB82EBD90292AAF399372CBC0D60C56C (void);
// 0x00000538 System.UInt32 AkSerializedCallbackHeader::get_eType()
extern void AkSerializedCallbackHeader_get_eType_mD1A2E0317F0EE234BA00CC6EDEE479BF5C645BD9 (void);
// 0x00000539 System.IntPtr AkSerializedCallbackHeader::GetData()
extern void AkSerializedCallbackHeader_GetData_mB542BCFFDA4DED93ACE5F98DE4AAD47CE8343CE2 (void);
// 0x0000053A AkSerializedCallbackHeader AkSerializedCallbackHeader::get_pNext()
extern void AkSerializedCallbackHeader_get_pNext_m27525EB109C28898BCC7FF2564532536302EE71D (void);
// 0x0000053B System.Void AkSerializedCallbackHeader::.ctor()
extern void AkSerializedCallbackHeader__ctor_mB8EC07CB9238A0C5F066F9A54E0D5B0379F6C289 (void);
// 0x0000053C System.Void AkSourceSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkSourceSettings__ctor_mE4FA70D3678EE6ABA6A11901B56312A0E18EFBD9 (void);
// 0x0000053D System.IntPtr AkSourceSettings::getCPtr(AkSourceSettings)
extern void AkSourceSettings_getCPtr_m7820771D19008FB0896E89C40B1C1F42DE80ED33 (void);
// 0x0000053E System.Void AkSourceSettings::setCPtr(System.IntPtr)
extern void AkSourceSettings_setCPtr_m6A8D8829B7172AE70D3E1EC0EE5AED3DB80AF390 (void);
// 0x0000053F System.Void AkSourceSettings::Finalize()
extern void AkSourceSettings_Finalize_m0570A3D56B605C6C9171EDED0A9C8B1A5DA9F829 (void);
// 0x00000540 System.Void AkSourceSettings::Dispose()
extern void AkSourceSettings_Dispose_mE543B3A4BADBACAFEA0417683470EFC90FB3D01F (void);
// 0x00000541 System.Void AkSourceSettings::set_sourceID(System.UInt32)
extern void AkSourceSettings_set_sourceID_m6034C7D15D260D6173D96BFA86E63A46F0BC70EB (void);
// 0x00000542 System.UInt32 AkSourceSettings::get_sourceID()
extern void AkSourceSettings_get_sourceID_m16AEF0745BED9CD0DC99DC527927EDB40BE00390 (void);
// 0x00000543 System.Void AkSourceSettings::set_pMediaMemory(System.IntPtr)
extern void AkSourceSettings_set_pMediaMemory_mAD5E8F1CA97729F5E14A59C9D2B3E61825C6688A (void);
// 0x00000544 System.IntPtr AkSourceSettings::get_pMediaMemory()
extern void AkSourceSettings_get_pMediaMemory_m1FFB5ADFA5D96BDB09C56DBFB75897D0AD47D1BD (void);
// 0x00000545 System.Void AkSourceSettings::set_uMediaSize(System.UInt32)
extern void AkSourceSettings_set_uMediaSize_m2E1411207B7AB0BFADFF2213C48FC6F5CED96727 (void);
// 0x00000546 System.UInt32 AkSourceSettings::get_uMediaSize()
extern void AkSourceSettings_get_uMediaSize_m51C4AF6462CFC74870167E3CE181F319F929271F (void);
// 0x00000547 System.Void AkSourceSettings::Clear()
extern void AkSourceSettings_Clear_mC4DB6124F322EAE9C3818ED9324C2A4BCBF9F705 (void);
// 0x00000548 System.Int32 AkSourceSettings::GetSizeOf()
extern void AkSourceSettings_GetSizeOf_mE8DFC3716EBB5DF8ADBB47E4C7D350CC84D83EAC (void);
// 0x00000549 System.Void AkSourceSettings::Clone(AkSourceSettings)
extern void AkSourceSettings_Clone_mE9F4C8978FBCE0F0A54551FF0D7EBB0556141668 (void);
// 0x0000054A System.Void AkSourceSettings::.ctor()
extern void AkSourceSettings__ctor_m4B8C5E03E2362A6B858D8F2230BC1EE08C29F541 (void);
// 0x0000054B System.Void AkSpatialAudioInitSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkSpatialAudioInitSettings__ctor_m18F6EB447C4F16A2EA131E1ECEAFE79B0ADF888E (void);
// 0x0000054C System.IntPtr AkSpatialAudioInitSettings::getCPtr(AkSpatialAudioInitSettings)
extern void AkSpatialAudioInitSettings_getCPtr_mC1DF9735A18AB5BD49E160CDDF7FB02562D8555C (void);
// 0x0000054D System.Void AkSpatialAudioInitSettings::setCPtr(System.IntPtr)
extern void AkSpatialAudioInitSettings_setCPtr_m9716AE3A8D8315920CEB69C60C0DCD214A552CCB (void);
// 0x0000054E System.Void AkSpatialAudioInitSettings::Finalize()
extern void AkSpatialAudioInitSettings_Finalize_mD88BA1747521B9475971D2FF0F15753631F8EF34 (void);
// 0x0000054F System.Void AkSpatialAudioInitSettings::Dispose()
extern void AkSpatialAudioInitSettings_Dispose_m84D6AE8540D6FB2F7AA050C9775A5C5AD3AB65BE (void);
// 0x00000550 System.Void AkSpatialAudioInitSettings::.ctor()
extern void AkSpatialAudioInitSettings__ctor_m763FBE831EF3E096164B6FF5D278125275656581 (void);
// 0x00000551 System.Void AkSpatialAudioInitSettings::set_uMaxSoundPropagationDepth(System.UInt32)
extern void AkSpatialAudioInitSettings_set_uMaxSoundPropagationDepth_m2654ADEE6AC3B5654D06DCA68E85073E59AE6042 (void);
// 0x00000552 System.UInt32 AkSpatialAudioInitSettings::get_uMaxSoundPropagationDepth()
extern void AkSpatialAudioInitSettings_get_uMaxSoundPropagationDepth_mB4096F4C67DE96C14477E7D4FF76C629F2B5BFC8 (void);
// 0x00000553 System.Void AkSpatialAudioInitSettings::set_fMovementThreshold(System.Single)
extern void AkSpatialAudioInitSettings_set_fMovementThreshold_m3EBB1F9403311A4D16A8C06E7A2D162018A3A053 (void);
// 0x00000554 System.Single AkSpatialAudioInitSettings::get_fMovementThreshold()
extern void AkSpatialAudioInitSettings_get_fMovementThreshold_m8E40B556637EFD1CA01A148D16B2C44946C81749 (void);
// 0x00000555 System.Void AkSpatialAudioInitSettings::set_uNumberOfPrimaryRays(System.UInt32)
extern void AkSpatialAudioInitSettings_set_uNumberOfPrimaryRays_m5EF782B01F32CF2AD3A9E4F7226ACB5E1A331659 (void);
// 0x00000556 System.UInt32 AkSpatialAudioInitSettings::get_uNumberOfPrimaryRays()
extern void AkSpatialAudioInitSettings_get_uNumberOfPrimaryRays_m242FC4132778C6B7AD7955570BE57BB79D8D7B93 (void);
// 0x00000557 System.Void AkSpatialAudioInitSettings::set_uMaxReflectionOrder(System.UInt32)
extern void AkSpatialAudioInitSettings_set_uMaxReflectionOrder_m460964F899BB75932EFF4B1BEA3152F4F38C0AB0 (void);
// 0x00000558 System.UInt32 AkSpatialAudioInitSettings::get_uMaxReflectionOrder()
extern void AkSpatialAudioInitSettings_get_uMaxReflectionOrder_mFEF00D3580AC09C5857AB62B6C80328882610359 (void);
// 0x00000559 System.Void AkSpatialAudioInitSettings::set_fMaxPathLength(System.Single)
extern void AkSpatialAudioInitSettings_set_fMaxPathLength_m70CE3F0FD470499DC90C90860CC748038912A85B (void);
// 0x0000055A System.Single AkSpatialAudioInitSettings::get_fMaxPathLength()
extern void AkSpatialAudioInitSettings_get_fMaxPathLength_m2F4EB5A69D920CB1C9BA8802C0F465A45B379440 (void);
// 0x0000055B System.Void AkSpatialAudioInitSettings::set_fCPULimitPercentage(System.Single)
extern void AkSpatialAudioInitSettings_set_fCPULimitPercentage_mDC38650EDE9AF110E0C7DF2F3D8FB3B7B37166FA (void);
// 0x0000055C System.Single AkSpatialAudioInitSettings::get_fCPULimitPercentage()
extern void AkSpatialAudioInitSettings_get_fCPULimitPercentage_mAE87BBB598B79A6E92458960BEB1A37AD8FC51FA (void);
// 0x0000055D System.Void AkSpatialAudioInitSettings::set_bEnableDiffractionOnReflection(System.Boolean)
extern void AkSpatialAudioInitSettings_set_bEnableDiffractionOnReflection_m36A51F7B96AB456AD9C9D26BD25E4FE838B6D04F (void);
// 0x0000055E System.Boolean AkSpatialAudioInitSettings::get_bEnableDiffractionOnReflection()
extern void AkSpatialAudioInitSettings_get_bEnableDiffractionOnReflection_mC0A3A68A903748FFEF4A5DEBE43460082C134B7F (void);
// 0x0000055F System.Void AkSpatialAudioInitSettings::set_bEnableGeometricDiffractionAndTransmission(System.Boolean)
extern void AkSpatialAudioInitSettings_set_bEnableGeometricDiffractionAndTransmission_mFC8C52117F0CF07FFD7991203B20113D5F08F4CE (void);
// 0x00000560 System.Boolean AkSpatialAudioInitSettings::get_bEnableGeometricDiffractionAndTransmission()
extern void AkSpatialAudioInitSettings_get_bEnableGeometricDiffractionAndTransmission_m84D303E3D30012A1B20975611DDCD30E6E844702 (void);
// 0x00000561 System.Void AkSpatialAudioInitSettings::set_bCalcEmitterVirtualPosition(System.Boolean)
extern void AkSpatialAudioInitSettings_set_bCalcEmitterVirtualPosition_m16AE0286CD7984E9E3BF72C8B5795079D57010BE (void);
// 0x00000562 System.Boolean AkSpatialAudioInitSettings::get_bCalcEmitterVirtualPosition()
extern void AkSpatialAudioInitSettings_get_bCalcEmitterVirtualPosition_mEA7CF69CA3E11A284948542875FE40B3E3D8F108 (void);
// 0x00000563 System.Void AkSpatialAudioInitSettings::set_bUseObstruction(System.Boolean)
extern void AkSpatialAudioInitSettings_set_bUseObstruction_m28D90F5776B7115B948DA189A5414F3C8A64B2D9 (void);
// 0x00000564 System.Boolean AkSpatialAudioInitSettings::get_bUseObstruction()
extern void AkSpatialAudioInitSettings_get_bUseObstruction_m7C3D5FA2D2E2862483B400F91489A1E9CFD3DF0D (void);
// 0x00000565 System.Void AkSpatialAudioInitSettings::set_bUseOcclusion(System.Boolean)
extern void AkSpatialAudioInitSettings_set_bUseOcclusion_m8ED71297470A804C1A1EBFF30850E4738A41CBD4 (void);
// 0x00000566 System.Boolean AkSpatialAudioInitSettings::get_bUseOcclusion()
extern void AkSpatialAudioInitSettings_get_bUseOcclusion_mBE2FF9B03C96EFB424FC0AD4FF508EA76218836A (void);
// 0x00000567 System.Void AkStreamMgrSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkStreamMgrSettings__ctor_m173FF7010F37289E25679D9FCDB5CABA9536C848 (void);
// 0x00000568 System.IntPtr AkStreamMgrSettings::getCPtr(AkStreamMgrSettings)
extern void AkStreamMgrSettings_getCPtr_m50B56CDA673D153763C6ED773DEC2E8545B25983 (void);
// 0x00000569 System.Void AkStreamMgrSettings::setCPtr(System.IntPtr)
extern void AkStreamMgrSettings_setCPtr_mA1985F59D2208B3D2104B4456F42F859234E65B7 (void);
// 0x0000056A System.Void AkStreamMgrSettings::Finalize()
extern void AkStreamMgrSettings_Finalize_m3DD6ADE30E703F8DE77FB1217C4A9DD391A47006 (void);
// 0x0000056B System.Void AkStreamMgrSettings::Dispose()
extern void AkStreamMgrSettings_Dispose_m0AF10C7CAD9A549D40930A2DDEA168E3746DC4BB (void);
// 0x0000056C System.Void AkTaskContext::.ctor(System.IntPtr,System.Boolean)
extern void AkTaskContext__ctor_mED566DFD9B67437B66D4C4C2D69ABE56EB0208F7 (void);
// 0x0000056D System.IntPtr AkTaskContext::getCPtr(AkTaskContext)
extern void AkTaskContext_getCPtr_m3F7ED5FF7166CB48B6484B61D6176F9CE85670CF (void);
// 0x0000056E System.Void AkTaskContext::setCPtr(System.IntPtr)
extern void AkTaskContext_setCPtr_mCD8E0C2FB5BC55D9835BF383C729229E328EC0F1 (void);
// 0x0000056F System.Void AkTaskContext::Finalize()
extern void AkTaskContext_Finalize_m5A5A83EC977AA1FD4F1EC6967EEFF27373FABC7F (void);
// 0x00000570 System.Void AkTaskContext::Dispose()
extern void AkTaskContext_Dispose_m55137333F8C81F55243E4A9037A0916238E05A20 (void);
// 0x00000571 System.Void AkTaskContext::set_uIdxThread(System.UInt32)
extern void AkTaskContext_set_uIdxThread_m7971ECCB4154CD267AB5B5F999F7F9629F3A93E3 (void);
// 0x00000572 System.UInt32 AkTaskContext::get_uIdxThread()
extern void AkTaskContext_get_uIdxThread_mA3C7239C55D55FA7963FA3A93D3A206020E4510A (void);
// 0x00000573 System.Void AkTaskContext::.ctor()
extern void AkTaskContext__ctor_m90E92731BA689854816628A6217B03E76F7B20D2 (void);
// 0x00000574 System.Void AkTransform::.ctor(System.IntPtr,System.Boolean)
extern void AkTransform__ctor_m27233AF6CC1533254D198344514E5EEB3E6BFCE4 (void);
// 0x00000575 System.IntPtr AkTransform::getCPtr(AkTransform)
extern void AkTransform_getCPtr_m385FC89C5AA97536D591E0E95753E73A85188A2E (void);
// 0x00000576 System.Void AkTransform::setCPtr(System.IntPtr)
extern void AkTransform_setCPtr_m63942CED891633FDB35D831E0BDA21EB7F407FF7 (void);
// 0x00000577 System.Void AkTransform::Finalize()
extern void AkTransform_Finalize_m8DB45BA7BEED066BFAEB15F6C60D4816B5B862D9 (void);
// 0x00000578 System.Void AkTransform::Dispose()
extern void AkTransform_Dispose_mA5DFDBABC70CA67F09FEA8B8E37E38A9D64235BE (void);
// 0x00000579 UnityEngine.Vector3 AkTransform::Position()
extern void AkTransform_Position_m1F2877EAA623FC7692E3AEC9F0963701A77C9D4C (void);
// 0x0000057A UnityEngine.Vector3 AkTransform::OrientationFront()
extern void AkTransform_OrientationFront_mFB88AE7AB2BC09A3E93EB09012CD48E28ACE9794 (void);
// 0x0000057B UnityEngine.Vector3 AkTransform::OrientationTop()
extern void AkTransform_OrientationTop_m0D17728773797399E740EAFE587FA629B3A1A960 (void);
// 0x0000057C System.Void AkTransform::Set(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void AkTransform_Set_m6803CD84FC472C40011053F343EB3350F7C54672 (void);
// 0x0000057D System.Void AkTransform::Set(System.Single,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void AkTransform_Set_m06A4525F60A1C344194F00277A5D1A9DB6A52C51 (void);
// 0x0000057E System.Void AkTransform::SetPosition(UnityEngine.Vector3)
extern void AkTransform_SetPosition_m3E128635391ED0451C819E8635FEF074C94F09F8 (void);
// 0x0000057F System.Void AkTransform::SetPosition(System.Single,System.Single,System.Single)
extern void AkTransform_SetPosition_mF2685AFD98DB121812FAFD64E4A7CBC3FB4EAC08 (void);
// 0x00000580 System.Void AkTransform::SetOrientation(UnityEngine.Vector3,UnityEngine.Vector3)
extern void AkTransform_SetOrientation_m199D92FD83E98096DD38BE7E4981044C334FBCF7 (void);
// 0x00000581 System.Void AkTransform::SetOrientation(System.Single,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void AkTransform_SetOrientation_mF79CBB2DB768967252307C2E6B0495A248A3D51C (void);
// 0x00000582 System.Void AkTransform::.ctor()
extern void AkTransform__ctor_m0EF930A9A7EB2588B4C9B73865DF2D834A0F487B (void);
// 0x00000583 System.Void AkTriangle::.ctor(System.IntPtr,System.Boolean)
extern void AkTriangle__ctor_m9259B083C327267C67F45C5F2BE7071EB57E0CE9 (void);
// 0x00000584 System.IntPtr AkTriangle::getCPtr(AkTriangle)
extern void AkTriangle_getCPtr_m06C64F2BAB865720CAD887BE111AA5043CAB81F2 (void);
// 0x00000585 System.Void AkTriangle::setCPtr(System.IntPtr)
extern void AkTriangle_setCPtr_m60B86F0D118D13076FADEFC09A16E9F8DAF46D48 (void);
// 0x00000586 System.Void AkTriangle::Finalize()
extern void AkTriangle_Finalize_m63390660F16A4A8E04169C4581C38B6EC1202E10 (void);
// 0x00000587 System.Void AkTriangle::Dispose()
extern void AkTriangle_Dispose_mC8FC02238DFC050936D77F7E9A91150223907F2D (void);
// 0x00000588 System.Void AkTriangle::.ctor()
extern void AkTriangle__ctor_m51802CA7A4BF0339A0A14331C9445BAA9941729E (void);
// 0x00000589 System.Void AkTriangle::.ctor(System.UInt16,System.UInt16,System.UInt16,System.UInt16)
extern void AkTriangle__ctor_mC1135590F5032F5F21D518E5AC4A0E07A4F0E369 (void);
// 0x0000058A System.Void AkTriangle::set_point0(System.UInt16)
extern void AkTriangle_set_point0_m0A4CAD0515C7410444C80B9A4EF535D4E5AA0749 (void);
// 0x0000058B System.UInt16 AkTriangle::get_point0()
extern void AkTriangle_get_point0_mA893E90EE745ABAD47EF3C09751D20909A51ABEC (void);
// 0x0000058C System.Void AkTriangle::set_point1(System.UInt16)
extern void AkTriangle_set_point1_m189F0E744E2292DBC28C90310E12A81920A23DC2 (void);
// 0x0000058D System.UInt16 AkTriangle::get_point1()
extern void AkTriangle_get_point1_m190A7769CD2A12E8575AD6D30B1C5303C8652717 (void);
// 0x0000058E System.Void AkTriangle::set_point2(System.UInt16)
extern void AkTriangle_set_point2_mF689255BE07E51E5688B0C94A4A06D205A246265 (void);
// 0x0000058F System.UInt16 AkTriangle::get_point2()
extern void AkTriangle_get_point2_mCC8E4731AC8ACB47F877244BA2B5AD19BACC7778 (void);
// 0x00000590 System.Void AkTriangle::set_surface(System.UInt16)
extern void AkTriangle_set_surface_m25E0847348D849AC7BBEDB70AFC2365C36C70ACA (void);
// 0x00000591 System.UInt16 AkTriangle::get_surface()
extern void AkTriangle_get_surface_mAFFBDEAD7BEBE00797D9E051787EFA775FB4FC9A (void);
// 0x00000592 System.Void AkTriangle::Clear()
extern void AkTriangle_Clear_mE28F1A5D42DD4270DC1477D6125E25D27011416D (void);
// 0x00000593 System.Int32 AkTriangle::GetSizeOf()
extern void AkTriangle_GetSizeOf_m7FBD630BDD0ED6F7C8ECA03A74464E860505BFAA (void);
// 0x00000594 System.Void AkTriangle::Clone(AkTriangle)
extern void AkTriangle_Clone_m7B0A36612F05AA0040C24E2F8790D749E18AED4F (void);
// 0x00000595 System.Void AkCommunicationSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkCommunicationSettings__ctor_mBD6AFF45BBA6726EF5822E09BDEC485B1588A814 (void);
// 0x00000596 System.IntPtr AkCommunicationSettings::getCPtr(AkCommunicationSettings)
extern void AkCommunicationSettings_getCPtr_mA681CD6239AB9709C591B271FF7150A2BABDAA63 (void);
// 0x00000597 System.Void AkCommunicationSettings::setCPtr(System.IntPtr)
extern void AkCommunicationSettings_setCPtr_mA79684CEDAD3DE80B20B496D7A169714D5F4E3ED (void);
// 0x00000598 System.Void AkCommunicationSettings::Finalize()
extern void AkCommunicationSettings_Finalize_mFDB896CF5CC94113D1F20EE3BCE67F1B3D1B86BD (void);
// 0x00000599 System.Void AkCommunicationSettings::Dispose()
extern void AkCommunicationSettings_Dispose_mCBECCF1E50D33FC514186B0705C39A6DB045A65B (void);
// 0x0000059A System.Void AkCommunicationSettings::.ctor()
extern void AkCommunicationSettings__ctor_mD02B5665A84BECB1FE5FB5F90BAA5C7D8F95217E (void);
// 0x0000059B System.Void AkCommunicationSettings::set_uPoolSize(System.UInt32)
extern void AkCommunicationSettings_set_uPoolSize_mAF46234F38AA624559E87F9AEB38AC3012883C82 (void);
// 0x0000059C System.UInt32 AkCommunicationSettings::get_uPoolSize()
extern void AkCommunicationSettings_get_uPoolSize_m74007BFDD73B56E0764697A11112DF1F074348FB (void);
// 0x0000059D System.Void AkCommunicationSettings::set_uDiscoveryBroadcastPort(System.UInt16)
extern void AkCommunicationSettings_set_uDiscoveryBroadcastPort_mC5D817108BB4D0C6D9A1D9B5E6C0BACD19AEA11C (void);
// 0x0000059E System.UInt16 AkCommunicationSettings::get_uDiscoveryBroadcastPort()
extern void AkCommunicationSettings_get_uDiscoveryBroadcastPort_mACAC44C9D3BEE6BDCDFF0D82724F58E58E3C0482 (void);
// 0x0000059F System.Void AkCommunicationSettings::set_uCommandPort(System.UInt16)
extern void AkCommunicationSettings_set_uCommandPort_mDA0D61EFAA006B63E75B098470D03D23B2A4DFBF (void);
// 0x000005A0 System.UInt16 AkCommunicationSettings::get_uCommandPort()
extern void AkCommunicationSettings_get_uCommandPort_mA9393A3C4485A46C61ED71E12686C47211874587 (void);
// 0x000005A1 System.Void AkCommunicationSettings::set_uNotificationPort(System.UInt16)
extern void AkCommunicationSettings_set_uNotificationPort_m396DD5C8BA47A8DEA43CAF3A0488F7DEA44ACD9B (void);
// 0x000005A2 System.UInt16 AkCommunicationSettings::get_uNotificationPort()
extern void AkCommunicationSettings_get_uNotificationPort_m5736D4E4CD1BC7AD4F57FF622C8E03A1D489F6DA (void);
// 0x000005A3 System.Void AkCommunicationSettings::set_commSystem(AkCommunicationSettings_AkCommSystem)
extern void AkCommunicationSettings_set_commSystem_m1C23199126CBB5999337C9DA65D68D04D9CB18F3 (void);
// 0x000005A4 AkCommunicationSettings_AkCommSystem AkCommunicationSettings::get_commSystem()
extern void AkCommunicationSettings_get_commSystem_m1168C7C37779FDD98FD95A9F2791E5F0BEC46FB7 (void);
// 0x000005A5 System.Void AkCommunicationSettings::set_bInitSystemLib(System.Boolean)
extern void AkCommunicationSettings_set_bInitSystemLib_m0AC7B7CC4BCD686FBA61956703EDEA08D6D47DAE (void);
// 0x000005A6 System.Boolean AkCommunicationSettings::get_bInitSystemLib()
extern void AkCommunicationSettings_get_bInitSystemLib_m70896BDB3C5EE15D8BDD1475C1C9AF6650C6E3A4 (void);
// 0x000005A7 System.Void AkCommunicationSettings::set_szAppNetworkName(System.String)
extern void AkCommunicationSettings_set_szAppNetworkName_m3CE19FD889AD3C942C2B062F027080244FAB7205 (void);
// 0x000005A8 System.String AkCommunicationSettings::get_szAppNetworkName()
extern void AkCommunicationSettings_get_szAppNetworkName_m7C50585503E7D34EC069D55ED7386A7D390DFBFD (void);
// 0x000005A9 System.Void AkPlatformInitSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkPlatformInitSettings__ctor_mDCBC09ACE2847E689801BE20BEFFA0A03DCAD876 (void);
// 0x000005AA System.IntPtr AkPlatformInitSettings::getCPtr(AkPlatformInitSettings)
extern void AkPlatformInitSettings_getCPtr_m996BD96C413412D866319E1E8AB6108232BD42F9 (void);
// 0x000005AB System.Void AkPlatformInitSettings::setCPtr(System.IntPtr)
extern void AkPlatformInitSettings_setCPtr_m3103B37ACDA9B62E3F123E3690EE9D9F343B57C4 (void);
// 0x000005AC System.Void AkPlatformInitSettings::Finalize()
extern void AkPlatformInitSettings_Finalize_mFF9EDAA7015D43549C4D77D0468A448114CA2CAB (void);
// 0x000005AD System.Void AkPlatformInitSettings::Dispose()
extern void AkPlatformInitSettings_Dispose_m4737E3FE5EB22B119DD56C182DFD7B30D1382FA2 (void);
// 0x000005AE System.Void AkPlatformInitSettings::set_threadLEngine(AkThreadProperties)
extern void AkPlatformInitSettings_set_threadLEngine_mCB88D15C5B9131DC41507150591AD3A62F3FD951 (void);
// 0x000005AF AkThreadProperties AkPlatformInitSettings::get_threadLEngine()
extern void AkPlatformInitSettings_get_threadLEngine_m854E2A76ACED949F70CD9CCE79186AC9345F48E5 (void);
// 0x000005B0 System.Void AkPlatformInitSettings::set_threadOutputMgr(AkThreadProperties)
extern void AkPlatformInitSettings_set_threadOutputMgr_mC46C839294CC73E9320D5D3ACA8406C875F36DF1 (void);
// 0x000005B1 AkThreadProperties AkPlatformInitSettings::get_threadOutputMgr()
extern void AkPlatformInitSettings_get_threadOutputMgr_mFF53F398E954D3527BFFC23813EFBB8F5BED1230 (void);
// 0x000005B2 System.Void AkPlatformInitSettings::set_threadBankManager(AkThreadProperties)
extern void AkPlatformInitSettings_set_threadBankManager_m2567C493F9DE436D689E92AB2D9D7B4D7B58125E (void);
// 0x000005B3 AkThreadProperties AkPlatformInitSettings::get_threadBankManager()
extern void AkPlatformInitSettings_get_threadBankManager_m86EF3F2A42AFF85FF7CB545BD0230CB2E9ACD2BC (void);
// 0x000005B4 System.Void AkPlatformInitSettings::set_threadMonitor(AkThreadProperties)
extern void AkPlatformInitSettings_set_threadMonitor_m078A8C62A7474E076FD21F7FEF7C544C55033099 (void);
// 0x000005B5 AkThreadProperties AkPlatformInitSettings::get_threadMonitor()
extern void AkPlatformInitSettings_get_threadMonitor_m6C430A78A064506787FA9D519CC5228945D003BA (void);
// 0x000005B6 System.Void AkPlatformInitSettings::set_uNumRefillsInVoice(System.UInt16)
extern void AkPlatformInitSettings_set_uNumRefillsInVoice_m9ED1B6CB89781B9D2C95EB6AB82F4FAA7FBFB012 (void);
// 0x000005B7 System.UInt16 AkPlatformInitSettings::get_uNumRefillsInVoice()
extern void AkPlatformInitSettings_get_uNumRefillsInVoice_m521FD708D60427A0F13970C3E58DCC4F0B0FDED4 (void);
// 0x000005B8 System.Void AkPlatformInitSettings::set_uSampleRate(System.UInt32)
extern void AkPlatformInitSettings_set_uSampleRate_mFBB91E39D3567FC3CBA2E9F7FBA86A6866883D87 (void);
// 0x000005B9 System.UInt32 AkPlatformInitSettings::get_uSampleRate()
extern void AkPlatformInitSettings_get_uSampleRate_mA503DD8264AF7B55213B25D39A62D5CBED429CCA (void);
// 0x000005BA System.Void AkPlatformInitSettings::set_bEnableAvxSupport(System.Boolean)
extern void AkPlatformInitSettings_set_bEnableAvxSupport_m7E688B4F43AD6321B1F8A0B013FDAD464E50157A (void);
// 0x000005BB System.Boolean AkPlatformInitSettings::get_bEnableAvxSupport()
extern void AkPlatformInitSettings_get_bEnableAvxSupport_mD9C15CB78E073A9B3881D07935893E2EB7173F75 (void);
// 0x000005BC System.Void AkPlatformInitSettings::set_uMaxSystemAudioObjects(System.UInt32)
extern void AkPlatformInitSettings_set_uMaxSystemAudioObjects_m795A95878C920A6163E8118F85863E197BD4CF43 (void);
// 0x000005BD System.UInt32 AkPlatformInitSettings::get_uMaxSystemAudioObjects()
extern void AkPlatformInitSettings_get_uMaxSystemAudioObjects_mF0B3B1BC3B28A610B04D7FB3C5FC1B5D87796379 (void);
// 0x000005BE System.Void AkSoundEnginePINVOKE::.cctor()
extern void AkSoundEnginePINVOKE__cctor_m3CDB4875B017F190F663E304A1140FECD458B8FE (void);
// 0x000005BF System.UInt32 AkSoundEnginePINVOKE::CSharp_AK_INVALID_PIPELINE_ID_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_INVALID_PIPELINE_ID_get_mC1199E07D98D3DC35E0B3B773DAFC8CD97EC2CD0 (void);
// 0x000005C0 System.UInt64 AkSoundEnginePINVOKE::CSharp_AK_INVALID_AUDIO_OBJECT_ID_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_INVALID_AUDIO_OBJECT_ID_get_m83B8E0EDDDE40291D3383CF43C259AD3B5AC2194 (void);
// 0x000005C1 System.UInt32 AkSoundEnginePINVOKE::CSharp_AK_SOUNDBANK_VERSION_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_SOUNDBANK_VERSION_get_m8FEBC947AE5A86B7CE82C903A1AFAB2D53CBC13F (void);
// 0x000005C2 System.Void AkSoundEnginePINVOKE::CSharp_AkAudioSettings_uNumSamplesPerFrame_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioSettings_uNumSamplesPerFrame_set_mB36C9FBC77AED95FFEE123936CC03D8BCD2259EE (void);
// 0x000005C3 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioSettings_uNumSamplesPerFrame_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioSettings_uNumSamplesPerFrame_get_m6D1C5B29F49332215D68C796305CB6A056C76EF3 (void);
// 0x000005C4 System.Void AkSoundEnginePINVOKE::CSharp_AkAudioSettings_uNumSamplesPerSecond_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioSettings_uNumSamplesPerSecond_set_mD85113F7A35C25FDD898CCA7B69802C9B16D67BA (void);
// 0x000005C5 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioSettings_uNumSamplesPerSecond_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioSettings_uNumSamplesPerSecond_get_mC6995733F185E04D3DF8B1B05769E9CBDC53232A (void);
// 0x000005C6 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkAudioSettings()
extern void AkSoundEnginePINVOKE_CSharp_new_AkAudioSettings_m86E8D90E30C29FED086AB775AA24448CC7DBEC0A (void);
// 0x000005C7 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkAudioSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkAudioSettings_mD7D1D14E0F651B8AC1EE06A48D3945544AF41392 (void);
// 0x000005C8 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_idDevice_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_idDevice_set_m314A02CD66362ED19ABFDD69A786044438BD1CFA (void);
// 0x000005C9 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_idDevice_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_idDevice_get_m62A38BA34D4FDF4FB0B734C3BF716ACE80026FB4 (void);
// 0x000005CA System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_deviceName_set(System.IntPtr,System.String)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_deviceName_set_m150F02C7A30964E9B4FD8520FB6D02859FEFCFBC (void);
// 0x000005CB System.IntPtr AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_deviceName_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_deviceName_get_m6DFAB2A8A85661FB089E0D8F909D9BCB1D2C80E7 (void);
// 0x000005CC System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_deviceStateMask_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_deviceStateMask_set_m39C8BCAF79691A0EE170887D87A2EAA3F87ABB4F (void);
// 0x000005CD System.Int32 AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_deviceStateMask_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_deviceStateMask_get_m4CD09341127C14607E17CD727713A1F319202431 (void);
// 0x000005CE System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_isDefaultDevice_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_isDefaultDevice_set_m5BD25BE79EBEF6EF918575A85EE75C5DFB8D33E3 (void);
// 0x000005CF System.Boolean AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_isDefaultDevice_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_isDefaultDevice_get_mB4996E093D453E7A0D83189E098F38374EFC0D20 (void);
// 0x000005D0 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_Clear(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_Clear_mA23C79C38275A071003A056372EE933002B8BFEE (void);
// 0x000005D1 System.Int32 AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_GetSizeOf_mB599867FC4C22DA1835E695CAC045D268F86DC5E (void);
// 0x000005D2 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceDescription_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_Clone_m04214C6CA5BB085F699D5950542271E7F7B5D7A1 (void);
// 0x000005D3 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkDeviceDescription()
extern void AkSoundEnginePINVOKE_CSharp_new_AkDeviceDescription_m22C706816FF0D67763A1F47AAAF8E727ED34CE74 (void);
// 0x000005D4 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkDeviceDescription(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkDeviceDescription_mB3984BA77CF2303152D8BDA58F5F463523C29558 (void);
// 0x000005D5 UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkTransform_Position(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTransform_Position_mC609C435B13CB4E0A579ADDF68B23ABFC7FF80BE (void);
// 0x000005D6 UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkTransform_OrientationFront(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTransform_OrientationFront_m25EFD830C42D34288B49C97AB7867CF45F4A73BE (void);
// 0x000005D7 UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkTransform_OrientationTop(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTransform_OrientationTop_mE80DC52583AA9439B4FB84A6FFF5D91F482CAD93 (void);
// 0x000005D8 System.Void AkSoundEnginePINVOKE::CSharp_AkTransform_Set__SWIG_0(System.IntPtr,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void AkSoundEnginePINVOKE_CSharp_AkTransform_Set__SWIG_0_m36E60BE4D3A4F1B0E745E456EC61E0F88CECE81D (void);
// 0x000005D9 System.Void AkSoundEnginePINVOKE::CSharp_AkTransform_Set__SWIG_1(System.IntPtr,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkTransform_Set__SWIG_1_mCB8F85DA07C3474DCAC3DCEE84E92F430F76AC46 (void);
// 0x000005DA System.Void AkSoundEnginePINVOKE::CSharp_AkTransform_SetPosition__SWIG_0(System.IntPtr,UnityEngine.Vector3)
extern void AkSoundEnginePINVOKE_CSharp_AkTransform_SetPosition__SWIG_0_m4F463B805D08468079882BF2478033AA2E122F04 (void);
// 0x000005DB System.Void AkSoundEnginePINVOKE::CSharp_AkTransform_SetPosition__SWIG_1(System.IntPtr,System.Single,System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkTransform_SetPosition__SWIG_1_mC3ABECBBFFAB8FFFD2A2E5C35BD2AD7D01B7BB2B (void);
// 0x000005DC System.Void AkSoundEnginePINVOKE::CSharp_AkTransform_SetOrientation__SWIG_0(System.IntPtr,UnityEngine.Vector3,UnityEngine.Vector3)
extern void AkSoundEnginePINVOKE_CSharp_AkTransform_SetOrientation__SWIG_0_mAC63FDC2AB6D4730A352DEAF12B75145AEF06B7B (void);
// 0x000005DD System.Void AkSoundEnginePINVOKE::CSharp_AkTransform_SetOrientation__SWIG_1(System.IntPtr,System.Single,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkTransform_SetOrientation__SWIG_1_m534132CBF8669126804385E246C7499A8B636586 (void);
// 0x000005DE System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkTransform()
extern void AkSoundEnginePINVOKE_CSharp_new_AkTransform_mC2A3B0C0A52A8C45E40283D764D280CF81E19C29 (void);
// 0x000005DF System.Void AkSoundEnginePINVOKE::CSharp_delete_AkTransform(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkTransform_mE37027733677C69FFB41D848B6EB3B54E592D773 (void);
// 0x000005E0 System.Void AkSoundEnginePINVOKE::CSharp_AkObstructionOcclusionValues_occlusion_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_occlusion_set_m1429BBFE69017940FC7792E11CD192E38655B5F3 (void);
// 0x000005E1 System.Single AkSoundEnginePINVOKE::CSharp_AkObstructionOcclusionValues_occlusion_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_occlusion_get_mA1356E1E241D76884BBC1F87DA60112EE3D4E5B6 (void);
// 0x000005E2 System.Void AkSoundEnginePINVOKE::CSharp_AkObstructionOcclusionValues_obstruction_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_obstruction_set_m877D5FADBB18971D10632AE5CC2A06ADF4FEEFD2 (void);
// 0x000005E3 System.Single AkSoundEnginePINVOKE::CSharp_AkObstructionOcclusionValues_obstruction_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_obstruction_get_mA186D9996D17454D7848DEC361C522FBB336ABF8 (void);
// 0x000005E4 System.Void AkSoundEnginePINVOKE::CSharp_AkObstructionOcclusionValues_Clear(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_Clear_m10FEFBAE8D3EA5C90706D838533E04A24938FBE8 (void);
// 0x000005E5 System.Int32 AkSoundEnginePINVOKE::CSharp_AkObstructionOcclusionValues_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_GetSizeOf_m614123407AEC0D0A9441CCAE553778C056887CD9 (void);
// 0x000005E6 System.Void AkSoundEnginePINVOKE::CSharp_AkObstructionOcclusionValues_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_Clone_m554B03DA9E60B83D1001BF67BE41391BB62DAB7E (void);
// 0x000005E7 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkObstructionOcclusionValues()
extern void AkSoundEnginePINVOKE_CSharp_new_AkObstructionOcclusionValues_m0AA23D27BA65715E8D5419AD99F4B50ABBEAC60E (void);
// 0x000005E8 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkObstructionOcclusionValues(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkObstructionOcclusionValues_m058F5CF44D8029B65A41181F15D602F172E1E5AB (void);
// 0x000005E9 System.Void AkSoundEnginePINVOKE::CSharp_AkChannelEmitter_position_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelEmitter_position_set_mF8B4B9A21B2FE3F4545A51DE4129C661A86D5E79 (void);
// 0x000005EA System.IntPtr AkSoundEnginePINVOKE::CSharp_AkChannelEmitter_position_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelEmitter_position_get_m6FB71F01BAB59F5E7F1EFC6578465D2D4403A46B (void);
// 0x000005EB System.Void AkSoundEnginePINVOKE::CSharp_AkChannelEmitter_uInputChannels_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelEmitter_uInputChannels_set_m2A8E9629CC40ECBB3CE69CAB3FD9A254B6D0F308 (void);
// 0x000005EC System.UInt32 AkSoundEnginePINVOKE::CSharp_AkChannelEmitter_uInputChannels_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelEmitter_uInputChannels_get_m231F02478380AF0D0B61E90FEA3C0248C2B2F42A (void);
// 0x000005ED System.Void AkSoundEnginePINVOKE::CSharp_delete_AkChannelEmitter(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkChannelEmitter_m92CABFE5796CAD460178C389B65448E8BDBBF192 (void);
// 0x000005EE System.Void AkSoundEnginePINVOKE::CSharp_AkAuxSendValue_listenerID_set(System.IntPtr,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_listenerID_set_mF33F4ECC0CD1846F468B1E23C5C07392944ADF86 (void);
// 0x000005EF System.UInt64 AkSoundEnginePINVOKE::CSharp_AkAuxSendValue_listenerID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_listenerID_get_mB974605D9F959141D228297977D7B06CF65D93F5 (void);
// 0x000005F0 System.Void AkSoundEnginePINVOKE::CSharp_AkAuxSendValue_auxBusID_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_auxBusID_set_mC93CAB5E7DC668B3CBF495778F2A46EDC3860372 (void);
// 0x000005F1 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAuxSendValue_auxBusID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_auxBusID_get_m48D9F7917CD8F0DA295A333E9F5A763BA7E1948F (void);
// 0x000005F2 System.Void AkSoundEnginePINVOKE::CSharp_AkAuxSendValue_fControlValue_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_fControlValue_set_mB64A3B7AD457838BA142622DB6FE7152F5FD4862 (void);
// 0x000005F3 System.Single AkSoundEnginePINVOKE::CSharp_AkAuxSendValue_fControlValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_fControlValue_get_mF327FEC82F76AAA865E9554E767EA27F60DB69C6 (void);
// 0x000005F4 System.Void AkSoundEnginePINVOKE::CSharp_AkAuxSendValue_Set(System.IntPtr,System.UInt64,System.UInt32,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_Set_mB7E3EE05EAAD73330FC4BD81806B2B125240EB50 (void);
// 0x000005F5 System.Boolean AkSoundEnginePINVOKE::CSharp_AkAuxSendValue_IsSame(System.IntPtr,System.UInt64,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_IsSame_m406BE7CB605D5842EE2E54B89C3F8B23DAA222BB (void);
// 0x000005F6 System.Int32 AkSoundEnginePINVOKE::CSharp_AkAuxSendValue_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_GetSizeOf_m6A772FD34FF68CACA5A6A0676BFE60BEF31B6580 (void);
// 0x000005F7 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkAuxSendValue(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkAuxSendValue_m0DA776811BA6D7623A428470FDF749A931EA248D (void);
// 0x000005F8 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkRamp__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkRamp__SWIG_0_mFB6443518A53FB1CC7954D9396B8FB07DCCD0FE5 (void);
// 0x000005F9 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkRamp__SWIG_1(System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_new_AkRamp__SWIG_1_mCA1703C810CF0FFDC87E45126DB6E60BDB9A6236 (void);
// 0x000005FA System.Void AkSoundEnginePINVOKE::CSharp_AkRamp_fPrev_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkRamp_fPrev_set_mA57A3545BEEA57B92C3C098DD2D5885D733D6F6A (void);
// 0x000005FB System.Single AkSoundEnginePINVOKE::CSharp_AkRamp_fPrev_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkRamp_fPrev_get_mB393EC0FF1AD741D0A5688440CE01B231D70CFCE (void);
// 0x000005FC System.Void AkSoundEnginePINVOKE::CSharp_AkRamp_fNext_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkRamp_fNext_set_mC4F784865DE5B4A6558D990839A109CCF8AE50C2 (void);
// 0x000005FD System.Single AkSoundEnginePINVOKE::CSharp_AkRamp_fNext_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkRamp_fNext_get_m9DEE21F7072CF5823A1F61590468931DA2244D93 (void);
// 0x000005FE System.Void AkSoundEnginePINVOKE::CSharp_delete_AkRamp(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkRamp_mBB1191E67E33FB7FE9461A81E678CB0D2DE1E57D (void);
// 0x000005FF System.UInt16 AkSoundEnginePINVOKE::CSharp_AK_INT_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_INT_get_m3B425C6F73456C124486DEFC56F946ADF27FF8FD (void);
// 0x00000600 System.UInt16 AkSoundEnginePINVOKE::CSharp_AK_FLOAT_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_FLOAT_get_mEC122811F6BC8056DD5B23C71C5579DCA1A2CA90 (void);
// 0x00000601 System.Byte AkSoundEnginePINVOKE::CSharp_AK_INTERLEAVED_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_INTERLEAVED_get_m868307F8BA3B8C4CD98220B2735D8475E8223BCC (void);
// 0x00000602 System.Byte AkSoundEnginePINVOKE::CSharp_AK_NONINTERLEAVED_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_NONINTERLEAVED_get_mA919EA03A575A5B29822E64614B30019F529730E (void);
// 0x00000603 System.UInt32 AkSoundEnginePINVOKE::CSharp_AK_LE_NATIVE_BITSPERSAMPLE_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_LE_NATIVE_BITSPERSAMPLE_get_m3DD8AFD591CEBCBB5CA92966B22AE251C6CFD851 (void);
// 0x00000604 System.UInt32 AkSoundEnginePINVOKE::CSharp_AK_LE_NATIVE_SAMPLETYPE_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_LE_NATIVE_SAMPLETYPE_get_m9B26F9221DA7B5AF830A5E78504EF677EC26D648 (void);
// 0x00000605 System.UInt32 AkSoundEnginePINVOKE::CSharp_AK_LE_NATIVE_INTERLEAVE_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_LE_NATIVE_INTERLEAVE_get_mDED7CBD85CC806998E90EB9EB56EED2B7D43FC9E (void);
// 0x00000606 System.Void AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uSampleRate_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uSampleRate_set_m183FE3141AA58D976C7DE81A029D497E0217DE97 (void);
// 0x00000607 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uSampleRate_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uSampleRate_get_mC5BAE9D608C3F9041E5D383CCA982F2A6FC9B11E (void);
// 0x00000608 System.Void AkSoundEnginePINVOKE::CSharp_AkAudioFormat_channelConfig_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_channelConfig_set_m1B35F19449CA0C7B8BC827C038F1AA398FA4E079 (void);
// 0x00000609 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkAudioFormat_channelConfig_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_channelConfig_get_mF40BFD6770D97223CBED076EE163A3B7C2EFFF62 (void);
// 0x0000060A System.Void AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uBitsPerSample_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uBitsPerSample_set_mD303A3A4FC98A4C753B98C3D0AFAC9CB71CE85AE (void);
// 0x0000060B System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uBitsPerSample_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uBitsPerSample_get_mBCB3294207D9CAFBADB68B5608DF20B7D1F53A15 (void);
// 0x0000060C System.Void AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uBlockAlign_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uBlockAlign_set_m4B6AF07B622848630691294D3FF66BB4BB0104FA (void);
// 0x0000060D System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uBlockAlign_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uBlockAlign_get_m3B323F0E270871BF0AB9858715B205CC4D22D83C (void);
// 0x0000060E System.Void AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uTypeID_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uTypeID_set_m17ECC64A9ACE970170937CB2AAE0817630212BF5 (void);
// 0x0000060F System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uTypeID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uTypeID_get_m56178D289B1A4C7FE7914F9EC97B166BF849E0C2 (void);
// 0x00000610 System.Void AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uInterleaveID_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uInterleaveID_set_m1B3DDAFF15653009DE517579F981448CFFF129B1 (void);
// 0x00000611 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_uInterleaveID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uInterleaveID_get_m122C003AE8A364B9E4410EC2DE9EB671807469AB (void);
// 0x00000612 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_GetNumChannels(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetNumChannels_mDF268E2098D747BF4684EE6E989F4BB96E6EB090 (void);
// 0x00000613 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_GetBitsPerSample(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetBitsPerSample_m12F1128704D9771AC44005DC554C899F02EE6B74 (void);
// 0x00000614 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_GetBlockAlign(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetBlockAlign_m8945F5258221C5334E24A3CA309E953E773C62CA (void);
// 0x00000615 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_GetTypeID(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetTypeID_m8E5B5D617603BA2454893805197ED6D772AEEF6B (void);
// 0x00000616 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAudioFormat_GetInterleaveID(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetInterleaveID_m89D9C35F06A45E4F2A948EBB976AD8D68E6876E7 (void);
// 0x00000617 System.Void AkSoundEnginePINVOKE::CSharp_AkAudioFormat_SetAll(System.IntPtr,System.UInt32,System.IntPtr,System.UInt32,System.UInt32,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioFormat_SetAll_mF32B1D4019A0B15FE0E7E0C06D74D394E06DF5FF (void);
// 0x00000618 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkAudioFormat()
extern void AkSoundEnginePINVOKE_CSharp_new_AkAudioFormat_mB893B87AB573D95C6A4E6BCE6F74A8FE3E877C7B (void);
// 0x00000619 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkAudioFormat(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkAudioFormat_mE6B9D67F1074805A1973E908613696ADB3BCBF05 (void);
// 0x0000061A System.IntPtr AkSoundEnginePINVOKE::CSharp_new_Ak3dData()
extern void AkSoundEnginePINVOKE_CSharp_new_Ak3dData_mB672949CF43BA9507A6C3B8FE23F04C6B2C85A04 (void);
// 0x0000061B System.Void AkSoundEnginePINVOKE::CSharp_Ak3dData_xform_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3dData_xform_set_mEF7BB20DD6C3E75622A5BD01EA7617586EB173F4 (void);
// 0x0000061C System.IntPtr AkSoundEnginePINVOKE::CSharp_Ak3dData_xform_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3dData_xform_get_mDE1F91C5AF1C0077D4E59C091B8E0FF1F06D071E (void);
// 0x0000061D System.Void AkSoundEnginePINVOKE::CSharp_Ak3dData_spread_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_Ak3dData_spread_set_m7A4FA5F985F56AF49F20DE05931FDA2A8B117D08 (void);
// 0x0000061E System.Single AkSoundEnginePINVOKE::CSharp_Ak3dData_spread_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3dData_spread_get_m89D5663C7B3D009BEA4C6C957F5FE9ACE9A6BDA2 (void);
// 0x0000061F System.Void AkSoundEnginePINVOKE::CSharp_Ak3dData_focus_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_Ak3dData_focus_set_m6E6F8CA1F029EC09DD546C477EEFEF12E4228A00 (void);
// 0x00000620 System.Single AkSoundEnginePINVOKE::CSharp_Ak3dData_focus_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3dData_focus_get_m134C500D4615B0A93F454CD46F45C1E820D4F613 (void);
// 0x00000621 System.Void AkSoundEnginePINVOKE::CSharp_Ak3dData_uEmitterChannelMask_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_Ak3dData_uEmitterChannelMask_set_m0F5423456E54BBD4F31218D7CD83D1748C70BE11 (void);
// 0x00000622 System.UInt32 AkSoundEnginePINVOKE::CSharp_Ak3dData_uEmitterChannelMask_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3dData_uEmitterChannelMask_get_m7D9045EB91DA2561EFCC25D69F1EEA0999802147 (void);
// 0x00000623 System.Void AkSoundEnginePINVOKE::CSharp_delete_Ak3dData(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_Ak3dData_m64D2A1B5ED936423C33229E1C71DC8408AE8392B (void);
// 0x00000624 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkBehavioralPositioningData()
extern void AkSoundEnginePINVOKE_CSharp_new_AkBehavioralPositioningData_m2374C1C7E9EBEE4B5FD1700DFF50874C8FA28673 (void);
// 0x00000625 System.Void AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_center_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_center_set_m770C86EF6A6C954E0B8393C30B570E5DC714BCA5 (void);
// 0x00000626 System.Single AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_center_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_center_get_m50C7CFFADDA9A58D74378B89381F3C98B21C8091 (void);
// 0x00000627 System.Void AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panLR_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panLR_set_mA9A9CFDCE6F654B16BF5CF16AC5112986C6DC8C9 (void);
// 0x00000628 System.Single AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panLR_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panLR_get_m606A5A8148ADE490CF9A970ABFEAFC3799F05E40 (void);
// 0x00000629 System.Void AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panBF_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panBF_set_mF860D34AED6F9D0988771FC15784EB880A24C9C6 (void);
// 0x0000062A System.Single AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panBF_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panBF_get_mDDE82EA8757281A1129CDEE4F10529506E3E6A47 (void);
// 0x0000062B System.Void AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panDU_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panDU_set_mAD5900CD477BEBE8170C674A5924B89BA785E70B (void);
// 0x0000062C System.Single AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panDU_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panDU_get_mC53F6C75294DEB1569765967DBCD6789DE7350A1 (void);
// 0x0000062D System.Void AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panSpatMix_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panSpatMix_set_m33BAC00AFD84722DD59F40241EDC35D7EDA11183 (void);
// 0x0000062E System.Single AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panSpatMix_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panSpatMix_get_m33204FE266CFD5370B014CFD2E4ECB0132AB4B37 (void);
// 0x0000062F System.Void AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_spatMode_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_spatMode_set_m917B6D3A2C3CE97370949D0F76397FC8B36984D8 (void);
// 0x00000630 System.Int32 AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_spatMode_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_spatMode_get_mC9BC076AFFAED68E14A69DEA2D8529BF4906CC44 (void);
// 0x00000631 System.Void AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panType_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panType_set_m2329EA35B9E09C00E2F48B72AADA5C7871CF15CD (void);
// 0x00000632 System.Int32 AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_panType_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panType_get_mF961F102673625B8A5358946B1A2335A1F300E3A (void);
// 0x00000633 System.Void AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_enableHeightSpread_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_enableHeightSpread_set_mC94772EE380BC915F638EDCF438B5EE6183E9DE7 (void);
// 0x00000634 System.Boolean AkSoundEnginePINVOKE::CSharp_AkBehavioralPositioningData_enableHeightSpread_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_enableHeightSpread_get_mEAFC7DC8852E48FD357C6B26527B915DBC48B912 (void);
// 0x00000635 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkBehavioralPositioningData(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkBehavioralPositioningData_mF2CCFA57F29BC023CE8B32DE72667B196A338FD4 (void);
// 0x00000636 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningData_threeD_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningData_threeD_set_m3F0F2F7F321B6D124B11B584A07EDBE71681159C (void);
// 0x00000637 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPositioningData_threeD_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningData_threeD_get_mA5E1973D4C97012FADFD26D8916C2C4A5DDE1BEE (void);
// 0x00000638 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningData_behavioral_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningData_behavioral_set_mEEDC537227FA61464782C02276395A9C0DCE2E92 (void);
// 0x00000639 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPositioningData_behavioral_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningData_behavioral_get_mBA84AC6729DBCB14F9BDD108EED06B578C111AE1 (void);
// 0x0000063A System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkPositioningData()
extern void AkSoundEnginePINVOKE_CSharp_new_AkPositioningData_m6956F7BC25D8B9CFC66A5B1C583539796D291B5C (void);
// 0x0000063B System.Void AkSoundEnginePINVOKE::CSharp_delete_AkPositioningData(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkPositioningData_mD9596314842F4923F4F814CD164982B348856846 (void);
// 0x0000063C System.Void AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_channelConfig_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_channelConfig_set_m60A4EC2F33A72678BFD51F034111586A7F711FED (void);
// 0x0000063D System.IntPtr AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_channelConfig_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_channelConfig_get_m446E9A9DB70929064EA847DE24A361C062788AEF (void);
// 0x0000063E System.Void AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_uMaxSystemAudioObjects_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_uMaxSystemAudioObjects_set_m8ED393F0779E23884FBD1A5EF9C0B4E721296775 (void);
// 0x0000063F System.UInt32 AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_uMaxSystemAudioObjects_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_uMaxSystemAudioObjects_get_mC3E61D2CE4EF98C420D4A4900A0D2C37069F5826 (void);
// 0x00000640 System.Void AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_uAvailableSystemAudioObjects_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_uAvailableSystemAudioObjects_set_m7BA9F371BF9777509BE89F28E7D254C4338E97A6 (void);
// 0x00000641 System.UInt32 AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_uAvailableSystemAudioObjects_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_uAvailableSystemAudioObjects_get_m7E1C581BE5F5E79802637850B5727C44926AFDAC (void);
// 0x00000642 System.Void AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_bPassthrough_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_bPassthrough_set_m875E228A3F71CE7CF8B1E1200598F0417E4DA17D (void);
// 0x00000643 System.Boolean AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_bPassthrough_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_bPassthrough_get_mE73B311C1196719985EF326C977A08ED405FF793 (void);
// 0x00000644 System.Void AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_bMultiChannelObjects_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_bMultiChannelObjects_set_m8B5F2C477EDC3B0F3AB39ADBECF1427C2BBA85D1 (void);
// 0x00000645 System.Boolean AkSoundEnginePINVOKE::CSharp_Ak3DAudioSinkCapabilities_bMultiChannelObjects_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_bMultiChannelObjects_get_m9E63B2F5096D837A9A16240641DF142B20D55643 (void);
// 0x00000646 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_Ak3DAudioSinkCapabilities()
extern void AkSoundEnginePINVOKE_CSharp_new_Ak3DAudioSinkCapabilities_mDE3B8EE0DC4FA22EEE47EAB4C5AAA563B6285FF0 (void);
// 0x00000647 System.Void AkSoundEnginePINVOKE::CSharp_delete_Ak3DAudioSinkCapabilities(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_Ak3DAudioSinkCapabilities_mF40928449B385DC37428F7A23225EA068766CFA7 (void);
// 0x00000648 System.Void AkSoundEnginePINVOKE::CSharp_AkIterator_pItem_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkIterator_pItem_set_m3FAD6C8BC39A33E2C0BC7C4E7C1E218657C2003E (void);
// 0x00000649 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkIterator_pItem_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkIterator_pItem_get_m0857CF5DE0275F7664E5B0B0A132FB8F13D9D5D5 (void);
// 0x0000064A System.IntPtr AkSoundEnginePINVOKE::CSharp_AkIterator_NextIter(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkIterator_NextIter_m29EE0296F290FEEC2C3EC31BFDCC9D8B0F509A59 (void);
// 0x0000064B System.IntPtr AkSoundEnginePINVOKE::CSharp_AkIterator_PrevIter(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkIterator_PrevIter_m38F6D1DCD5F6EE0C8A58E11C85307B4E788053E9 (void);
// 0x0000064C System.IntPtr AkSoundEnginePINVOKE::CSharp_AkIterator_GetItem(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkIterator_GetItem_m977E140F5524D6E39965266F83CAEC8730795262 (void);
// 0x0000064D System.Boolean AkSoundEnginePINVOKE::CSharp_AkIterator_IsEqualTo(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkIterator_IsEqualTo_mE76B1D622D991CA468C685AAF37B8F0ABC37D989 (void);
// 0x0000064E System.Boolean AkSoundEnginePINVOKE::CSharp_AkIterator_IsDifferentFrom(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkIterator_IsDifferentFrom_mA2E42FF0A4518B0DAFC16044C4884261528F41BC (void);
// 0x0000064F System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkIterator()
extern void AkSoundEnginePINVOKE_CSharp_new_AkIterator_m209F010E6CF5DE74147E6FFA3F9BD0CC59462F85 (void);
// 0x00000650 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkIterator(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkIterator_mB4D6DDA1E82F2AC04A47CE30553E8C249F493402 (void);
// 0x00000651 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkPlaylistItem__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkPlaylistItem__SWIG_0_m0706DFB942116604528CC82913B7ED28391E1351 (void);
// 0x00000652 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkPlaylistItem__SWIG_1(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_new_AkPlaylistItem__SWIG_1_m61D61484F12EAA67EDEC303AE50BBECCAF48B2D0 (void);
// 0x00000653 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkPlaylistItem(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkPlaylistItem_mC1C138D30CD1EC34D8D8A4BDB54816ED5AF91A76 (void);
// 0x00000654 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistItem_Assign(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_Assign_mF8D5AC0ACFC802038267CA1ED3D2522CD8157D29 (void);
// 0x00000655 System.Boolean AkSoundEnginePINVOKE::CSharp_AkPlaylistItem_IsEqualTo(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_IsEqualTo_m80639ABBBF14D2848A07B6AF1A3B32E48860F5CE (void);
// 0x00000656 System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylistItem_SetExternalSources(System.IntPtr,System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_SetExternalSources_mD2DE07035C1F2BE6BEF86352C6776F1855234E3A (void);
// 0x00000657 System.Void AkSoundEnginePINVOKE::CSharp_AkPlaylistItem_audioNodeID_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_audioNodeID_set_m6E344964CCDB06967B5EF382C7A1D18B244B1286 (void);
// 0x00000658 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkPlaylistItem_audioNodeID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_audioNodeID_get_m75EEDC060098E65806A6E6FC39E41311DF5A9457 (void);
// 0x00000659 System.Void AkSoundEnginePINVOKE::CSharp_AkPlaylistItem_msDelay_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_msDelay_set_m5284276CE505739BC9AD67AE5897F118754C1A4A (void);
// 0x0000065A System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylistItem_msDelay_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_msDelay_get_mB83FB0ED5CFD69163CA23538E831D6635F55EDC4 (void);
// 0x0000065B System.Void AkSoundEnginePINVOKE::CSharp_AkPlaylistItem_pCustomInfo_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_pCustomInfo_set_m81F94D3B0D685EDA850FE7B1855AB08AE8B9895D (void);
// 0x0000065C System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistItem_pCustomInfo_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_pCustomInfo_get_mBEA02F5EE9993AD425778B88EF223DD4F09E12C5 (void);
// 0x0000065D System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkPlaylistArray()
extern void AkSoundEnginePINVOKE_CSharp_new_AkPlaylistArray_m73FAEE78BDD7FE40D1362BC8B4EC22B5AF96223D (void);
// 0x0000065E System.Void AkSoundEnginePINVOKE::CSharp_delete_AkPlaylistArray(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkPlaylistArray_mF788C4137DFE32303C0AC8200D42BD20A15BE6DC (void);
// 0x0000065F System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Begin(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Begin_mDE0BECD0C8687DD7875FF8B02105D27AC6CD9DA5 (void);
// 0x00000660 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_End(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_End_mB2F295D79C54DFF15F0CAE2DB36A3E2A967A10DC (void);
// 0x00000661 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_FindEx(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_FindEx_m3DCF45768C87778B4DF45CFFB28604C2D809CD9C (void);
// 0x00000662 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Erase__SWIG_0(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Erase__SWIG_0_m31A3F9E57C795640E0CB637D355C30969FBCBEA9 (void);
// 0x00000663 System.Void AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Erase__SWIG_1(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Erase__SWIG_1_m41099D1B22E63AFEEDE70714F6CA960B3D95B756 (void);
// 0x00000664 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_EraseSwap__SWIG_0(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_EraseSwap__SWIG_0_m09CD8812999456FD4267467FA27A19F6C04A3D50 (void);
// 0x00000665 System.Void AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_EraseSwap__SWIG_1(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_EraseSwap__SWIG_1_m072CA8618344F0699619EA9F3D12853F14520DBA (void);
// 0x00000666 System.Boolean AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_IsGrowingAllowed(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_IsGrowingAllowed_m2FAFBC444B742657F7A3EC519D19E90B711AF7A5 (void);
// 0x00000667 System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Reserve(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Reserve_mE3611AC76F5D84208812F5867399DF4476E73DA1 (void);
// 0x00000668 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Reserved(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Reserved_m63D1593A78663EFB1FB5E74B51EDEC73154F864B (void);
// 0x00000669 System.Void AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Term(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Term_mC187F4887CAA70447D51C9A2736AE4F9A6770FCE (void);
// 0x0000066A System.UInt32 AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Length(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Length_m7D1B13B3DA8EEFFCE861667C3E00E51D46BB89AF (void);
// 0x0000066B System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Data(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Data_m4FA10CA83AE519CE57247BFD5CA5970B48975032 (void);
// 0x0000066C System.Boolean AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_IsEmpty(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_IsEmpty_m97D4B1161D9A1D27BCD2112F52654D714F72E481 (void);
// 0x0000066D System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Exists(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Exists_m642CB4DED450C56AE46C26A82514DA4CA04BCABF (void);
// 0x0000066E System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_AddLast__SWIG_0(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_AddLast__SWIG_0_mEA700ED6FF3D3C7DF51BC25D8B35870967B8F0EE (void);
// 0x0000066F System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_AddLast__SWIG_1(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_AddLast__SWIG_1_mFC86828B5D7004C3A8AF3BC8DEA6ADBBF7A18999 (void);
// 0x00000670 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Last(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Last_m41593BEEF9685C809634FE30421A94A7FB7CE2BC (void);
// 0x00000671 System.Void AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_RemoveLast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_RemoveLast_m4CEED04269A58FEDCD0DBA197291E20840DB8D23 (void);
// 0x00000672 System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Remove(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Remove_mCCDEF80616CDBD7AFAAA442D6B159EA865BD1149 (void);
// 0x00000673 System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_RemoveSwap(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_RemoveSwap_m03A89A785888456B6286CC0C8FA9F36F45052CCE (void);
// 0x00000674 System.Void AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_RemoveAll(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_RemoveAll_mE6FE8987FDFACF1F38E86B256FA626DA01EE967A (void);
// 0x00000675 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_ItemAtIndex(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_ItemAtIndex_m014DCAEE27B2E8AFD7EE4393B014BD21D01820CB (void);
// 0x00000676 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Insert(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Insert_mA15424F01C49ABD7C8BC140396C3950D55018769 (void);
// 0x00000677 System.Boolean AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_GrowArray__SWIG_0(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_GrowArray__SWIG_0_m9C3C9BCB0088BD74BB92F5B74347C523C7A76F85 (void);
// 0x00000678 System.Boolean AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_GrowArray__SWIG_1(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_GrowArray__SWIG_1_m5ECF80EBD12EB877700766B5D00D2FC460D50B5B (void);
// 0x00000679 System.Boolean AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Resize(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Resize_m70796A85E6306B0DADCD7FD7023A170ACAC402B9 (void);
// 0x0000067A System.Void AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Transfer(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Transfer_mBF57B3610DCE2F022832A42928544952279649C3 (void);
// 0x0000067B System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylistArray_Copy(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Copy_mDA8BD377129C53D9D1A401FC8EE877BF79A57417 (void);
// 0x0000067C System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylist_Enqueue__SWIG_0(System.IntPtr,System.UInt32,System.Int32,System.IntPtr,System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_0_m31F1EC41F62A3793DB303DE0DF667F5726940DD5 (void);
// 0x0000067D System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylist_Enqueue__SWIG_1(System.IntPtr,System.UInt32,System.Int32,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_1_mCA27D8A4D51F2C2026F4B0CB73937FBC6E06CFA6 (void);
// 0x0000067E System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylist_Enqueue__SWIG_2(System.IntPtr,System.UInt32,System.Int32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_2_m669BCFC004879B1D028B5972C4A75CBF9D6D5270 (void);
// 0x0000067F System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylist_Enqueue__SWIG_3(System.IntPtr,System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_3_mA1F059D8570369A39095B402172B4B028A643AEE (void);
// 0x00000680 System.Int32 AkSoundEnginePINVOKE::CSharp_AkPlaylist_Enqueue__SWIG_4(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_4_mA4067000DEAFEBB0564EFAD3610B710D2C82C96C (void);
// 0x00000681 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkPlaylist()
extern void AkSoundEnginePINVOKE_CSharp_new_AkPlaylist_m8DC13485E2A99BB54BE5CD67CB0AB3E22EFBCFD0 (void);
// 0x00000682 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkPlaylist(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkPlaylist_m6AF5457522C9A6CCD3209D5AFE7375D01A35750A (void);
// 0x00000683 System.UInt32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceOpen__SWIG_0(System.UInt64,System.UInt32,System.IntPtr,System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceOpen__SWIG_0_m1F355066BD0A5D4FFCFC5F5A12D415535560374A (void);
// 0x00000684 System.UInt32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceOpen__SWIG_1(System.UInt64,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceOpen__SWIG_1_mC15EFAD3A69A222AE13C88D1E3B63ECC54C19C9D (void);
// 0x00000685 System.UInt32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceOpen__SWIG_2(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceOpen__SWIG_2_m8233A45FB4C5741FFBF17CDDD70CC841BD44414F (void);
// 0x00000686 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceClose(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceClose_mC8B5F221A38AEA3AE217C356048F83CC6DA59C99 (void);
// 0x00000687 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequencePlay__SWIG_0(System.UInt32,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequencePlay__SWIG_0_m69A365BD11C005C3F0382638D061189DBB7C6197 (void);
// 0x00000688 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequencePlay__SWIG_1(System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequencePlay__SWIG_1_mC1419579D022A6D64D4A44EE9FBF7444A8FE6654 (void);
// 0x00000689 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequencePlay__SWIG_2(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequencePlay__SWIG_2_m583FA013DFFA41906EADAA64DC76B236D6CCFE42 (void);
// 0x0000068A System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequencePause__SWIG_0(System.UInt32,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequencePause__SWIG_0_mA6623A8AD3840F762F2853866E33CA666BFD75EA (void);
// 0x0000068B System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequencePause__SWIG_1(System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequencePause__SWIG_1_m344C4C5008023432FF68E769AFBD8BC46C5E90C6 (void);
// 0x0000068C System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequencePause__SWIG_2(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequencePause__SWIG_2_m7ED416260F85C32E2ED495AB3051E38E81EAE10C (void);
// 0x0000068D System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceResume__SWIG_0(System.UInt32,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceResume__SWIG_0_mD6AB009E546C4AA26748ADF3AEC51A12F7B68D65 (void);
// 0x0000068E System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceResume__SWIG_1(System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceResume__SWIG_1_m072D9BC66995A6B6997A1ACCAEE7C3BAE0EBBAF5 (void);
// 0x0000068F System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceResume__SWIG_2(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceResume__SWIG_2_m99498189FD999E15A843E39F832D7AB0FBBD9B41 (void);
// 0x00000690 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceStop__SWIG_0(System.UInt32,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceStop__SWIG_0_m0908A3DA11191C583CAC93C10A57DD66BF1615C6 (void);
// 0x00000691 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceStop__SWIG_1(System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceStop__SWIG_1_m1B65C62E9E268290704D18EB68D701FC541AE2D6 (void);
// 0x00000692 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceStop__SWIG_2(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceStop__SWIG_2_m550D2347CFEFB6D59167F507C6CF88D6BA503A74 (void);
// 0x00000693 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceBreak(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceBreak_m43F1ADF041EB21C60DE6A32AD1C00FAA2C23E984 (void);
// 0x00000694 System.Int32 AkSoundEnginePINVOKE::CSharp_Seek__SWIG_0(System.UInt32,System.Int32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_Seek__SWIG_0_mA3CA606BB82C615A676DE8FCDFE955F2E7F4DFD3 (void);
// 0x00000695 System.Int32 AkSoundEnginePINVOKE::CSharp_Seek__SWIG_1(System.UInt32,System.Single,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_Seek__SWIG_1_mE1BF533AA61A43DBBF9144F8F18D8B7F1FFA3C31 (void);
// 0x00000696 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceGetPauseTimes(System.UInt32,System.UInt32&,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceGetPauseTimes_m09DA809BB9B84F582E233A09A09F02C346D6DBAA (void);
// 0x00000697 System.IntPtr AkSoundEnginePINVOKE::CSharp_DynamicSequenceLockPlaylist(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceLockPlaylist_m1526649355ABEC1212DF3ED6C5E8D9BED2031FE1 (void);
// 0x00000698 System.Int32 AkSoundEnginePINVOKE::CSharp_DynamicSequenceUnlockPlaylist(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_DynamicSequenceUnlockPlaylist_m79E10EA52AD38AED00BA01192A0E76F3954036A4 (void);
// 0x00000699 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkOutputSettings__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_0_mA218D47F9C42E30403F7386BE4C2C8D7B9EDDD45 (void);
// 0x0000069A System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkOutputSettings__SWIG_1(System.String,System.UInt32,System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_1_m276C31672DCF04B5FC97BBC8AECF755985924CAC (void);
// 0x0000069B System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkOutputSettings__SWIG_2(System.String,System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_2_m650A98ED0841E38C14F46A011BD1C4CD9C07514B (void);
// 0x0000069C System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkOutputSettings__SWIG_3(System.String,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_3_m29A7965031F5217E4996ADEB4696AD6560457092 (void);
// 0x0000069D System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkOutputSettings__SWIG_4(System.String)
extern void AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_4_mEED05F2531388C2287F2DE93EA15F8938D181B44 (void);
// 0x0000069E System.Void AkSoundEnginePINVOKE::CSharp_AkOutputSettings_audioDeviceShareset_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkOutputSettings_audioDeviceShareset_set_mA9C6ABDCD26078102FF007E194F88D5CD00C41AF (void);
// 0x0000069F System.UInt32 AkSoundEnginePINVOKE::CSharp_AkOutputSettings_audioDeviceShareset_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkOutputSettings_audioDeviceShareset_get_mC96F312E493753659A215FD893C1B70DDD6C2B67 (void);
// 0x000006A0 System.Void AkSoundEnginePINVOKE::CSharp_AkOutputSettings_idDevice_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkOutputSettings_idDevice_set_m12DDD7FBF2D513D65CEBECD828EFB4A522FBC77F (void);
// 0x000006A1 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkOutputSettings_idDevice_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkOutputSettings_idDevice_get_mEBC5A6237F2E5342A7E7461BB2CA1F52525F3703 (void);
// 0x000006A2 System.Void AkSoundEnginePINVOKE::CSharp_AkOutputSettings_ePanningRule_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkOutputSettings_ePanningRule_set_mF51F096F6931D4BCF49B16A119BDE5813654DEF7 (void);
// 0x000006A3 System.Int32 AkSoundEnginePINVOKE::CSharp_AkOutputSettings_ePanningRule_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkOutputSettings_ePanningRule_get_m449B0165358904B56E05559FD2A4D4673191A379 (void);
// 0x000006A4 System.Void AkSoundEnginePINVOKE::CSharp_AkOutputSettings_channelConfig_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkOutputSettings_channelConfig_set_m22B4B24755472AF1944BD370F76B37DB1A7111FD (void);
// 0x000006A5 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkOutputSettings_channelConfig_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkOutputSettings_channelConfig_get_m374C10FBDF08C08574710A93532BAA33B18DEBB2 (void);
// 0x000006A6 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkOutputSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkOutputSettings_m0090E7732FCADFCA94E05F3D07651587DC0057D6 (void);
// 0x000006A7 System.Void AkSoundEnginePINVOKE::CSharp_AkTaskContext_uIdxThread_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkTaskContext_uIdxThread_set_m98A40716A31DFF1F94E19929D25BA7233BB32E0D (void);
// 0x000006A8 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkTaskContext_uIdxThread_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTaskContext_uIdxThread_get_m3FBFEF98FC93398C69984D2F37F0E372D4613CC5 (void);
// 0x000006A9 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkTaskContext()
extern void AkSoundEnginePINVOKE_CSharp_new_AkTaskContext_m0A2FBD206B41FD7CA0AAF3F8C91BC5FB736D8AE9 (void);
// 0x000006AA System.Void AkSoundEnginePINVOKE::CSharp_delete_AkTaskContext(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkTaskContext_m28ACE0BD2747B94ECB0188651A52B05CB8A738D7 (void);
// 0x000006AB System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_uMaxNumPaths_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMaxNumPaths_set_m1BDB25B03254EE33870EC40333174541243C16A9 (void);
// 0x000006AC System.UInt32 AkSoundEnginePINVOKE::CSharp_AkInitSettings_uMaxNumPaths_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMaxNumPaths_get_m600485842BF380550FE93CB7B9B55ABAB62688BE (void);
// 0x000006AD System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_uCommandQueueSize_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uCommandQueueSize_set_m5EA87AD25C346A890A824C0CA00ACE1A0D0B05BD (void);
// 0x000006AE System.UInt32 AkSoundEnginePINVOKE::CSharp_AkInitSettings_uCommandQueueSize_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uCommandQueueSize_get_mDF1803B40831E31DE0F034E33CD9FD9AF87BED5A (void);
// 0x000006AF System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_bEnableGameSyncPreparation_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_bEnableGameSyncPreparation_set_mDD71643B3BCA366487352C270974B3F58F3BCFDC (void);
// 0x000006B0 System.Boolean AkSoundEnginePINVOKE::CSharp_AkInitSettings_bEnableGameSyncPreparation_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_bEnableGameSyncPreparation_get_m681DC66A972C85BD48EFA68309CE8E84AE9462F3 (void);
// 0x000006B1 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_uContinuousPlaybackLookAhead_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uContinuousPlaybackLookAhead_set_mBE55AA1089694768E070B929F24D6099ED545DA3 (void);
// 0x000006B2 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkInitSettings_uContinuousPlaybackLookAhead_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uContinuousPlaybackLookAhead_get_m89B98C37F7DE61CEFC5EB27924F8789A374D135A (void);
// 0x000006B3 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_uNumSamplesPerFrame_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uNumSamplesPerFrame_set_m5D0DF3B5237B8AE4C78F5886DF18BECF1A6015E7 (void);
// 0x000006B4 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkInitSettings_uNumSamplesPerFrame_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uNumSamplesPerFrame_get_m20E13CBBEA5BDFE89E695952987C3772017A15B9 (void);
// 0x000006B5 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_uMonitorQueuePoolSize_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMonitorQueuePoolSize_set_mED33768078F5D2B4816DA00F6CA7DD4FF41F90E9 (void);
// 0x000006B6 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkInitSettings_uMonitorQueuePoolSize_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMonitorQueuePoolSize_get_m480D7755630C8E7263D05C04D8984227BCC671C3 (void);
// 0x000006B7 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_settingsMainOutput_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_settingsMainOutput_set_m8E7B95ABD2831E07EFA378CE9F2A1B921AA3ED7D (void);
// 0x000006B8 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkInitSettings_settingsMainOutput_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_settingsMainOutput_get_mB3A69D85A76EC8EE106C3435A5E7891E46E76EA1 (void);
// 0x000006B9 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_uMaxHardwareTimeoutMs_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMaxHardwareTimeoutMs_set_mC1216F8BE668EB9F46772F14A5BA6BD55B920D1B (void);
// 0x000006BA System.UInt32 AkSoundEnginePINVOKE::CSharp_AkInitSettings_uMaxHardwareTimeoutMs_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMaxHardwareTimeoutMs_get_mA195A544D208448857149276CBD6E72E50E2BFC2 (void);
// 0x000006BB System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_bUseSoundBankMgrThread_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_bUseSoundBankMgrThread_set_m09DE89FA4E7049C97F7A084B646D1EEE2898D258 (void);
// 0x000006BC System.Boolean AkSoundEnginePINVOKE::CSharp_AkInitSettings_bUseSoundBankMgrThread_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_bUseSoundBankMgrThread_get_m4548518F9D5B9E1BBC4FE12618BCA80BE5ECD139 (void);
// 0x000006BD System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_bUseLEngineThread_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_bUseLEngineThread_set_m15633143705B06CF5248AA4D64C13D40FE703569 (void);
// 0x000006BE System.Boolean AkSoundEnginePINVOKE::CSharp_AkInitSettings_bUseLEngineThread_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_bUseLEngineThread_get_m6723F57F7285E6D3D8D74A1131BDED656DF5E01C (void);
// 0x000006BF System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_szPluginDLLPath_set(System.IntPtr,System.String)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_szPluginDLLPath_set_m885DFFF22919A6B148CF9326657AA4F23CE5A185 (void);
// 0x000006C0 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkInitSettings_szPluginDLLPath_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_szPluginDLLPath_get_mF55A0C7D3BAAE505FF6864D9D891F79966096E0E (void);
// 0x000006C1 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_eFloorPlane_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_eFloorPlane_set_m5D28B0043C7E09C54826A9B5DC56B73C431C83CB (void);
// 0x000006C2 System.Int32 AkSoundEnginePINVOKE::CSharp_AkInitSettings_eFloorPlane_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_eFloorPlane_get_m5384F206F2C872932719A0F0FA4A8E0AECC05568 (void);
// 0x000006C3 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_fGameUnitsToMeters_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_fGameUnitsToMeters_set_m2413ECB587C1A2A74547D1FE22A002945249BFF1 (void);
// 0x000006C4 System.Single AkSoundEnginePINVOKE::CSharp_AkInitSettings_fGameUnitsToMeters_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_fGameUnitsToMeters_get_m1F69C51E0415D0BCF997F6345CAA6AC803E125A2 (void);
// 0x000006C5 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_uBankReadBufferSize_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uBankReadBufferSize_set_mF4578F5FCE3484FC694A1B0F936F079164A351F8 (void);
// 0x000006C6 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkInitSettings_uBankReadBufferSize_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_uBankReadBufferSize_get_m37410F7AE35CCAC8C2F018009AD92A9A37F05601 (void);
// 0x000006C7 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_fDebugOutOfRangeLimit_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_fDebugOutOfRangeLimit_set_m2910E271038EECA83A6D77EC4C8688C124CE30C8 (void);
// 0x000006C8 System.Single AkSoundEnginePINVOKE::CSharp_AkInitSettings_fDebugOutOfRangeLimit_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_fDebugOutOfRangeLimit_get_m64C11096D5D2FDEF53780F6D40A5F2875752D285 (void);
// 0x000006C9 System.Void AkSoundEnginePINVOKE::CSharp_AkInitSettings_bDebugOutOfRangeCheckEnabled_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_bDebugOutOfRangeCheckEnabled_set_m8AC50A7BD63E5B5685E4571D6FFA1199A9AAC272 (void);
// 0x000006CA System.Boolean AkSoundEnginePINVOKE::CSharp_AkInitSettings_bDebugOutOfRangeCheckEnabled_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitSettings_bDebugOutOfRangeCheckEnabled_get_m9A784B8311C476581C07CD6B592C31B140A1284D (void);
// 0x000006CB System.Void AkSoundEnginePINVOKE::CSharp_delete_AkInitSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkInitSettings_m27CB4E78F8C9E18FC0CE8E436837A32A426EC972 (void);
// 0x000006CC System.Void AkSoundEnginePINVOKE::CSharp_AkSourceSettings_sourceID_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkSourceSettings_sourceID_set_mAD890B3751FF5E74A4653E6255B87F4D062AF281 (void);
// 0x000006CD System.UInt32 AkSoundEnginePINVOKE::CSharp_AkSourceSettings_sourceID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSourceSettings_sourceID_get_mB763CE8E808CE676BE327CE1F5C7FCF7C8ACB450 (void);
// 0x000006CE System.Void AkSoundEnginePINVOKE::CSharp_AkSourceSettings_pMediaMemory_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSourceSettings_pMediaMemory_set_mCCA7E3B5E8F20FF39BD7F63F66CA214C254DC12E (void);
// 0x000006CF System.IntPtr AkSoundEnginePINVOKE::CSharp_AkSourceSettings_pMediaMemory_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSourceSettings_pMediaMemory_get_mD67E86C1337B55516CBFB23151E8FDF757EA5150 (void);
// 0x000006D0 System.Void AkSoundEnginePINVOKE::CSharp_AkSourceSettings_uMediaSize_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkSourceSettings_uMediaSize_set_mA13532BEDE731D0CB1185A1ABB0CDABC4203A067 (void);
// 0x000006D1 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkSourceSettings_uMediaSize_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSourceSettings_uMediaSize_get_m56ED8F938B0394DE0FB0DB41ACB5CC604A4F2771 (void);
// 0x000006D2 System.Void AkSoundEnginePINVOKE::CSharp_AkSourceSettings_Clear(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSourceSettings_Clear_m02E248B4172D71B0DB002B5C26317376A2429BFF (void);
// 0x000006D3 System.Int32 AkSoundEnginePINVOKE::CSharp_AkSourceSettings_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkSourceSettings_GetSizeOf_m02D0A93C257EE23B752EA29786778C0EAFC3E7A2 (void);
// 0x000006D4 System.Void AkSoundEnginePINVOKE::CSharp_AkSourceSettings_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSourceSettings_Clone_m8AD470DD6446312CDD28A8A930BDB7DFC84E51D2 (void);
// 0x000006D5 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkSourceSettings()
extern void AkSoundEnginePINVOKE_CSharp_new_AkSourceSettings_mE11367D5D14E0108AC61D1B155A881B5A00ADF79 (void);
// 0x000006D6 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkSourceSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkSourceSettings_m934F977AEB73E35426A9BB8D0BC4E734D36D3A31 (void);
// 0x000006D7 System.Boolean AkSoundEnginePINVOKE::CSharp_IsInitialized()
extern void AkSoundEnginePINVOKE_CSharp_IsInitialized_mE1ECBD46A83C16F914E12B6DDAEFB3F1C493D267 (void);
// 0x000006D8 System.Int32 AkSoundEnginePINVOKE::CSharp_GetAudioSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetAudioSettings_m6F05727EBA048C28E8CB25B4174155ED9F65EF22 (void);
// 0x000006D9 System.IntPtr AkSoundEnginePINVOKE::CSharp_GetSpeakerConfiguration__SWIG_0(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_GetSpeakerConfiguration__SWIG_0_m7490CA296547BC9199F9F88FB0569B7C4937EE0A (void);
// 0x000006DA System.IntPtr AkSoundEnginePINVOKE::CSharp_GetSpeakerConfiguration__SWIG_1()
extern void AkSoundEnginePINVOKE_CSharp_GetSpeakerConfiguration__SWIG_1_m85066A6F2E5F56DE6A2ECF35E13AC5633B4660A9 (void);
// 0x000006DB System.Int32 AkSoundEnginePINVOKE::CSharp_GetOutputDeviceConfiguration(System.UInt64,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetOutputDeviceConfiguration_mB57FF4EE08BFE6F91A470BB6E2CC63B0627CCEB8 (void);
// 0x000006DC System.Int32 AkSoundEnginePINVOKE::CSharp_GetPanningRule__SWIG_0(System.Int32&,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_GetPanningRule__SWIG_0_mFD962009F85CAF40E902B9E40780D00E43D1AF7F (void);
// 0x000006DD System.Int32 AkSoundEnginePINVOKE::CSharp_GetPanningRule__SWIG_1(System.Int32&)
extern void AkSoundEnginePINVOKE_CSharp_GetPanningRule__SWIG_1_m3312219EC4D406CA67E7D3F2AF5D818E0B3D662E (void);
// 0x000006DE System.Int32 AkSoundEnginePINVOKE::CSharp_SetPanningRule__SWIG_0(System.Int32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_SetPanningRule__SWIG_0_mFD8E970C2B8710EBFFE9875E65D1A4676AD104F6 (void);
// 0x000006DF System.Int32 AkSoundEnginePINVOKE::CSharp_SetPanningRule__SWIG_1(System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetPanningRule__SWIG_1_m3024E08F128F70751ACC70FD86DBC4C74082D899 (void);
// 0x000006E0 System.Int32 AkSoundEnginePINVOKE::CSharp_GetSpeakerAngles__SWIG_0(System.Single[],System.UInt32&,System.Single&,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_GetSpeakerAngles__SWIG_0_mB26E98FF61B129B1B47A4B6796DBE86CCACDDC73 (void);
// 0x000006E1 System.Int32 AkSoundEnginePINVOKE::CSharp_GetSpeakerAngles__SWIG_1(System.Single[],System.UInt32&,System.Single&)
extern void AkSoundEnginePINVOKE_CSharp_GetSpeakerAngles__SWIG_1_mFF47D6BC9675BC0DDEF9DCAF45F1228005627D23 (void);
// 0x000006E2 System.Int32 AkSoundEnginePINVOKE::CSharp_SetSpeakerAngles__SWIG_0(System.Single[],System.UInt32,System.Single,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_SetSpeakerAngles__SWIG_0_mFE520847B32911957E354CCBCC09171D1381FE3F (void);
// 0x000006E3 System.Int32 AkSoundEnginePINVOKE::CSharp_SetSpeakerAngles__SWIG_1(System.Single[],System.UInt32,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetSpeakerAngles__SWIG_1_m2FEF1FE7547C0D79F02E036DD9F982D7232166CC (void);
// 0x000006E4 System.Int32 AkSoundEnginePINVOKE::CSharp_SetVolumeThreshold(System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetVolumeThreshold_mEE4DB005135BFFFE52B279900F9A946A321BB396 (void);
// 0x000006E5 System.Int32 AkSoundEnginePINVOKE::CSharp_SetMaxNumVoicesLimit(System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_SetMaxNumVoicesLimit_mBF3800B3CBB85662FF3629009A21FAE488828983 (void);
// 0x000006E6 System.Int32 AkSoundEnginePINVOKE::CSharp_RenderAudio__SWIG_0(System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_RenderAudio__SWIG_0_m09F4C47B01A096AD0E822D9153CB3706EFED0C3D (void);
// 0x000006E7 System.Int32 AkSoundEnginePINVOKE::CSharp_RenderAudio__SWIG_1()
extern void AkSoundEnginePINVOKE_CSharp_RenderAudio__SWIG_1_m8E11221C93807893E011E9FDCC99BB57F28014F4 (void);
// 0x000006E8 System.Int32 AkSoundEnginePINVOKE::CSharp_RegisterPluginDLL__SWIG_0(System.String,System.String)
extern void AkSoundEnginePINVOKE_CSharp_RegisterPluginDLL__SWIG_0_m7A4EC8760A256EE7D8016365560E16FDF0B56C40 (void);
// 0x000006E9 System.Int32 AkSoundEnginePINVOKE::CSharp_RegisterPluginDLL__SWIG_1(System.String)
extern void AkSoundEnginePINVOKE_CSharp_RegisterPluginDLL__SWIG_1_m7F577B708326E2244B270792C268AE5AD2042937 (void);
// 0x000006EA System.UInt32 AkSoundEnginePINVOKE::CSharp_GetIDFromString__SWIG_0(System.String)
extern void AkSoundEnginePINVOKE_CSharp_GetIDFromString__SWIG_0_m4C9D9E377A3FADA5BCA73F8835E9E837004534DD (void);
// 0x000006EB System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEvent__SWIG_0(System.UInt32,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_0_m1A62532A467B4457FE1427583ADFA9B2ACEF636D (void);
// 0x000006EC System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEvent__SWIG_1(System.UInt32,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_1_m4724996CA00E3A233B87A52DEC4D0B42148C4C23 (void);
// 0x000006ED System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEvent__SWIG_2(System.UInt32,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_2_mF23C56F203744AC4A968005737FE544045623F24 (void);
// 0x000006EE System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEvent__SWIG_3(System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_3_m2F994B707BB0541A17FC1E5E579C7F7FD1D9B441 (void);
// 0x000006EF System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEvent__SWIG_4(System.String,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_4_mA544D4F4FA3E827F6A3863935B51D83E7B03C115 (void);
// 0x000006F0 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEvent__SWIG_5(System.String,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_5_mD2717A2E1C642E16DBA7F825C67DC2C766ACF710 (void);
// 0x000006F1 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEvent__SWIG_6(System.String,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_6_m312C30B85567C4A04C77AEFCFAC1F0B2E541C72E (void);
// 0x000006F2 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEvent__SWIG_7(System.String,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_7_m2AD24E8F3DE7D5D5E6CC5F250DD75C382AF9CAB8 (void);
// 0x000006F3 System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_0(System.UInt32,System.Int32,System.UInt64,System.Int32,System.Int32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_0_m587FF54BE03B90895EC2D6227FC598C3401BAE85 (void);
// 0x000006F4 System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_1(System.UInt32,System.Int32,System.UInt64,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_1_m84FBFE2B44A191AC3D2E7DA96AD78BB754801BC4 (void);
// 0x000006F5 System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_2(System.UInt32,System.Int32,System.UInt64,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_2_mCE07A652864596605A55841CC5885902BBBC3449 (void);
// 0x000006F6 System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_3(System.UInt32,System.Int32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_3_mCFD6749D1C9C8547A50B9D55E26816279D4BAC5C (void);
// 0x000006F7 System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_4(System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_4_m055142057D49971AF4C256055251FAF05E78A944 (void);
// 0x000006F8 System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_5(System.String,System.Int32,System.UInt64,System.Int32,System.Int32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_5_m31DDBB38A18A61176B630CAFE42D66086C5A1EA8 (void);
// 0x000006F9 System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_6(System.String,System.Int32,System.UInt64,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_6_mBED1F819FA89DA400988DF633C259E2E8313A5A6 (void);
// 0x000006FA System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_7(System.String,System.Int32,System.UInt64,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_7_m497ADD90EFB814C88E784CC9F5699F8E01C5C422 (void);
// 0x000006FB System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_8(System.String,System.Int32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_8_m08928B5384ED4350F33C75C8B1C1ED015D66F3DA (void);
// 0x000006FC System.Int32 AkSoundEnginePINVOKE::CSharp_ExecuteActionOnEvent__SWIG_9(System.String,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_9_mE2B1F23E58C9049D0E419EE1EB07876D19FC3B51 (void);
// 0x000006FD System.UInt32 AkSoundEnginePINVOKE::CSharp_PostMIDIOnEvent__SWIG_0(System.UInt32,System.UInt64,System.IntPtr,System.UInt16,System.Boolean,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PostMIDIOnEvent__SWIG_0_m35415AE2DAD2017D111F9F8D819AA42C841C430F (void);
// 0x000006FE System.UInt32 AkSoundEnginePINVOKE::CSharp_PostMIDIOnEvent__SWIG_1(System.UInt32,System.UInt64,System.IntPtr,System.UInt16,System.Boolean,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PostMIDIOnEvent__SWIG_1_mFCDABC1CBF9631688F91BF14935B5678918683DB (void);
// 0x000006FF System.UInt32 AkSoundEnginePINVOKE::CSharp_PostMIDIOnEvent__SWIG_2(System.UInt32,System.UInt64,System.IntPtr,System.UInt16,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_PostMIDIOnEvent__SWIG_2_m9E9D538A53E4822430CC965E6E6CA14107299610 (void);
// 0x00000700 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostMIDIOnEvent__SWIG_3(System.UInt32,System.UInt64,System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_PostMIDIOnEvent__SWIG_3_mD2D9A0E72D5CBF7F8FED06242E680B010E4DA253 (void);
// 0x00000701 System.Int32 AkSoundEnginePINVOKE::CSharp_StopMIDIOnEvent__SWIG_0(System.UInt32,System.UInt64,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_StopMIDIOnEvent__SWIG_0_m471FCF518FFE02BC0D4DB8206E1AF1F6F3B1681C (void);
// 0x00000702 System.Int32 AkSoundEnginePINVOKE::CSharp_StopMIDIOnEvent__SWIG_1(System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_StopMIDIOnEvent__SWIG_1_m02CDE09B4CF472E5ECA1F0B56C62EED1D4CFADDE (void);
// 0x00000703 System.Int32 AkSoundEnginePINVOKE::CSharp_StopMIDIOnEvent__SWIG_2(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_StopMIDIOnEvent__SWIG_2_mC8FFE4059845EBC333B1AEC660A315FC2D45C431 (void);
// 0x00000704 System.Int32 AkSoundEnginePINVOKE::CSharp_StopMIDIOnEvent__SWIG_3()
extern void AkSoundEnginePINVOKE_CSharp_StopMIDIOnEvent__SWIG_3_mB4B0B92C82471C7D5DB4DF1B6C6274E40C19348E (void);
// 0x00000705 System.Int32 AkSoundEnginePINVOKE::CSharp_PinEventInStreamCache__SWIG_0(System.UInt32,System.SByte,System.SByte)
extern void AkSoundEnginePINVOKE_CSharp_PinEventInStreamCache__SWIG_0_mC480731B7BB6F2F8E11B0F75075063F5B4EB03D5 (void);
// 0x00000706 System.Int32 AkSoundEnginePINVOKE::CSharp_PinEventInStreamCache__SWIG_1(System.String,System.SByte,System.SByte)
extern void AkSoundEnginePINVOKE_CSharp_PinEventInStreamCache__SWIG_1_mCCEA05A87C1F23ADEC177EE2CF46202DE5DBD824 (void);
// 0x00000707 System.Int32 AkSoundEnginePINVOKE::CSharp_UnpinEventInStreamCache__SWIG_0(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_UnpinEventInStreamCache__SWIG_0_m82AB9C58544A2964F097653B9032F814FABB73B7 (void);
// 0x00000708 System.Int32 AkSoundEnginePINVOKE::CSharp_UnpinEventInStreamCache__SWIG_1(System.String)
extern void AkSoundEnginePINVOKE_CSharp_UnpinEventInStreamCache__SWIG_1_m2CDD264F6647D77ECAB7641FA5CB4F905297C11A (void);
// 0x00000709 System.Int32 AkSoundEnginePINVOKE::CSharp_GetBufferStatusForPinnedEvent__SWIG_0(System.UInt32,System.Single&,System.Int32&)
extern void AkSoundEnginePINVOKE_CSharp_GetBufferStatusForPinnedEvent__SWIG_0_mA09076B04B836E99C595DE2180071A3067B296A0 (void);
// 0x0000070A System.Int32 AkSoundEnginePINVOKE::CSharp_GetBufferStatusForPinnedEvent__SWIG_1(System.String,System.Single&,System.Int32&)
extern void AkSoundEnginePINVOKE_CSharp_GetBufferStatusForPinnedEvent__SWIG_1_mB5EBAA6BAD9515204B2E3A737E44FCCBA66AFB55 (void);
// 0x0000070B System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_0(System.UInt32,System.UInt64,System.Int32,System.Boolean,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_0_m8A74F6404FE746DB5E69511E7CE8E8790F3E4736 (void);
// 0x0000070C System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_1(System.UInt32,System.UInt64,System.Int32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_1_m4610B2A0E3A3B9441ED51A7D0CC2EF457FEC2BBD (void);
// 0x0000070D System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_2(System.UInt32,System.UInt64,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_2_m0DF8B0D5396D234C2E7E4C0C7E744358B2C7F46B (void);
// 0x0000070E System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_3(System.String,System.UInt64,System.Int32,System.Boolean,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_3_m9094CC1BB128003F9C995E39CEC7774456FBC581 (void);
// 0x0000070F System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_4(System.String,System.UInt64,System.Int32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_4_mA38B24B7485253A0B1605167525C46AB55CE1084 (void);
// 0x00000710 System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_5(System.String,System.UInt64,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_5_m4D6FAAB63116A625AAB2DC907395ABAB137FAF67 (void);
// 0x00000711 System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_9(System.UInt32,System.UInt64,System.Single,System.Boolean,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_9_mA08D48BF7341059E8BD5DC0096444CF5FD7F4322 (void);
// 0x00000712 System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_10(System.UInt32,System.UInt64,System.Single,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_10_m1AC0D0C9807F567FA34C96D35ADD199B5DC12208 (void);
// 0x00000713 System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_11(System.UInt32,System.UInt64,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_11_m977C697D2867BC7C1488CBDAEC45C83B2942FAB3 (void);
// 0x00000714 System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_12(System.String,System.UInt64,System.Single,System.Boolean,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_12_m1C0C95044D1D0BB9B2C04001DD25743A0C74C160 (void);
// 0x00000715 System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_13(System.String,System.UInt64,System.Single,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_13_mC6F90E01E137FEA375273D342E74FE26C64B164A (void);
// 0x00000716 System.Int32 AkSoundEnginePINVOKE::CSharp_SeekOnEvent__SWIG_14(System.String,System.UInt64,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_14_m2DFFE48865231926EE3FB809CB352038A9415E7F (void);
// 0x00000717 System.Void AkSoundEnginePINVOKE::CSharp_CancelEventCallbackCookie(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_CancelEventCallbackCookie_m435A745F70BE5A8E57BBDF10CAD73A972546FEE8 (void);
// 0x00000718 System.Void AkSoundEnginePINVOKE::CSharp_CancelEventCallbackGameObject(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_CancelEventCallbackGameObject_m82BE60BFE89FF7C1DE3BA2BA748489B83443265C (void);
// 0x00000719 System.Void AkSoundEnginePINVOKE::CSharp_CancelEventCallback(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_CancelEventCallback_mFF9619A5C69B19F4D6515A5F2554DD06A96E1B7B (void);
// 0x0000071A System.Int32 AkSoundEnginePINVOKE::CSharp_GetSourcePlayPosition__SWIG_0(System.UInt32,System.Int32&,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_GetSourcePlayPosition__SWIG_0_mC75357818A772CBBC11EBFF583ED1000B6146CA7 (void);
// 0x0000071B System.Int32 AkSoundEnginePINVOKE::CSharp_GetSourcePlayPosition__SWIG_1(System.UInt32,System.Int32&)
extern void AkSoundEnginePINVOKE_CSharp_GetSourcePlayPosition__SWIG_1_m8B4509848CCC254675A9691E2789FCB2B31D9123 (void);
// 0x0000071C System.Int32 AkSoundEnginePINVOKE::CSharp_GetSourceStreamBuffering(System.UInt32,System.Int32&,System.Int32&)
extern void AkSoundEnginePINVOKE_CSharp_GetSourceStreamBuffering_m75898A4AA0FD52CA561092AE6CEF333B1EBEEF61 (void);
// 0x0000071D System.Void AkSoundEnginePINVOKE::CSharp_StopAll__SWIG_0(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_StopAll__SWIG_0_m65515A14551E4552EDC2DA234A7B967020AE2A64 (void);
// 0x0000071E System.Void AkSoundEnginePINVOKE::CSharp_StopAll__SWIG_1()
extern void AkSoundEnginePINVOKE_CSharp_StopAll__SWIG_1_m4010AAD2B17165852C71BF7D743ABCD99E4E816B (void);
// 0x0000071F System.Void AkSoundEnginePINVOKE::CSharp_StopPlayingID__SWIG_0(System.UInt32,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_StopPlayingID__SWIG_0_m4594A3AFD28819D7368A5A90E78867BFF13065CB (void);
// 0x00000720 System.Void AkSoundEnginePINVOKE::CSharp_StopPlayingID__SWIG_1(System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_StopPlayingID__SWIG_1_m7AD719F65E141249CD1E6C18C4C2D73B726CC2CD (void);
// 0x00000721 System.Void AkSoundEnginePINVOKE::CSharp_StopPlayingID__SWIG_2(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_StopPlayingID__SWIG_2_m33053BB2AD5133BE659881C59EB410B7ADDBB190 (void);
// 0x00000722 System.Void AkSoundEnginePINVOKE::CSharp_ExecuteActionOnPlayingID__SWIG_0(System.Int32,System.UInt32,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnPlayingID__SWIG_0_mD789F38D3913C0D16F9336E28FA50323BA9DCC19 (void);
// 0x00000723 System.Void AkSoundEnginePINVOKE::CSharp_ExecuteActionOnPlayingID__SWIG_1(System.Int32,System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnPlayingID__SWIG_1_mC61208E6B0CA6697FC628D31D5C092716AC20FBE (void);
// 0x00000724 System.Void AkSoundEnginePINVOKE::CSharp_ExecuteActionOnPlayingID__SWIG_2(System.Int32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ExecuteActionOnPlayingID__SWIG_2_mD34CCABE09DA1E0AC42CA955C9746F5EB9074A07 (void);
// 0x00000725 System.Void AkSoundEnginePINVOKE::CSharp_SetRandomSeed(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetRandomSeed_m0C76A4A026B73E7FA01A1F6517CE78343DF465BC (void);
// 0x00000726 System.Void AkSoundEnginePINVOKE::CSharp_MuteBackgroundMusic(System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_MuteBackgroundMusic_mBF42F5AD7F16D5B490E3D9943E6E397C61CD49AB (void);
// 0x00000727 System.Boolean AkSoundEnginePINVOKE::CSharp_GetBackgroundMusicMute()
extern void AkSoundEnginePINVOKE_CSharp_GetBackgroundMusicMute_m9C119901E915DF798FDECCDD66775D5912B6350E (void);
// 0x00000728 System.Int32 AkSoundEnginePINVOKE::CSharp_SendPluginCustomGameData(System.UInt32,System.UInt64,System.Int32,System.UInt32,System.UInt32,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SendPluginCustomGameData_mE2EE75A3465D41A468E46B7A0AFFA6F36FA2B936 (void);
// 0x00000729 System.Int32 AkSoundEnginePINVOKE::CSharp_UnregisterAllGameObj()
extern void AkSoundEnginePINVOKE_CSharp_UnregisterAllGameObj_m7ECCAB451F34749FFAAAA6AE4B8DD3D24148A6DD (void);
// 0x0000072A System.Int32 AkSoundEnginePINVOKE::CSharp_SetMultiplePositions__SWIG_0(System.UInt64,System.IntPtr,System.UInt16,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetMultiplePositions__SWIG_0_m80EEA40D1339BF2321C8695D73C36F4A3654B829 (void);
// 0x0000072B System.Int32 AkSoundEnginePINVOKE::CSharp_SetMultiplePositions__SWIG_1(System.UInt64,System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_SetMultiplePositions__SWIG_1_m216AA880F1E7DCD806C4F96775163B41B6A28681 (void);
// 0x0000072C System.Int32 AkSoundEnginePINVOKE::CSharp_SetMultiplePositions__SWIG_2(System.UInt64,System.IntPtr,System.UInt16,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetMultiplePositions__SWIG_2_m6486EF4A8BD7D458D577EAE68B662692495E3389 (void);
// 0x0000072D System.Int32 AkSoundEnginePINVOKE::CSharp_SetMultiplePositions__SWIG_3(System.UInt64,System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_SetMultiplePositions__SWIG_3_mEFB04A335B96C9D7AEEAEC7E34B117B84CE6F82C (void);
// 0x0000072E System.Int32 AkSoundEnginePINVOKE::CSharp_SetScalingFactor(System.UInt64,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetScalingFactor_m2A0159C50AE0B201CF2A054194888FEA456434B6 (void);
// 0x0000072F System.Int32 AkSoundEnginePINVOKE::CSharp_ClearBanks()
extern void AkSoundEnginePINVOKE_CSharp_ClearBanks_m941F8C93545A9ADED3AB067B4BC5FF5AE987DD1A (void);
// 0x00000730 System.Int32 AkSoundEnginePINVOKE::CSharp_SetBankLoadIOSettings(System.Single,System.SByte)
extern void AkSoundEnginePINVOKE_CSharp_SetBankLoadIOSettings_m3AAF107C4B146474F3DD114E83E2E115AB3DE8EC (void);
// 0x00000731 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadBank__SWIG_0(System.String,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_LoadBank__SWIG_0_mF699A2F2BEEC6B1E372D5F534A513ACA7C641737 (void);
// 0x00000732 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadBank__SWIG_2(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_LoadBank__SWIG_2_mEBCB8D1401313CAB5AD208C0BD73783949FAD3B9 (void);
// 0x00000733 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadBankMemoryView__SWIG_0(System.IntPtr,System.UInt32,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_LoadBankMemoryView__SWIG_0_m1ADFBBFC4DBB40D90CCA68FD0C31B7C1725D7AF6 (void);
// 0x00000734 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadBankMemoryCopy__SWIG_0(System.IntPtr,System.UInt32,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_LoadBankMemoryCopy__SWIG_0_m6FAF64A75E39D241B9F525BE5FEC09AC52ED3B14 (void);
// 0x00000735 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadBank__SWIG_3(System.String,System.IntPtr,System.IntPtr,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_LoadBank__SWIG_3_m803188B80BEE5BD1A399DC6E8D737F00F3973DF5 (void);
// 0x00000736 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadBank__SWIG_5(System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_LoadBank__SWIG_5_m35A31DA70E7EA028F43C149F1B8F4CE12BD6D29D (void);
// 0x00000737 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadBankMemoryView__SWIG_1(System.IntPtr,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_LoadBankMemoryView__SWIG_1_m370433FC10CBE08EAE9CC6EDBD6CAF8DF5FA5040 (void);
// 0x00000738 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadBankMemoryCopy__SWIG_1(System.IntPtr,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_LoadBankMemoryCopy__SWIG_1_mAB068DFF02CB0B2B2BC1985051D624B117564150 (void);
// 0x00000739 System.Int32 AkSoundEnginePINVOKE::CSharp_UnloadBank__SWIG_0(System.String,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_UnloadBank__SWIG_0_mB3CBD182D4CB441830BBB468463D4CD87AFED15F (void);
// 0x0000073A System.Int32 AkSoundEnginePINVOKE::CSharp_UnloadBank__SWIG_2(System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_UnloadBank__SWIG_2_mD1201F99806B946C31EECD6B60DB4F7BA3DB88C0 (void);
// 0x0000073B System.Int32 AkSoundEnginePINVOKE::CSharp_UnloadBank__SWIG_3(System.String,System.IntPtr,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_UnloadBank__SWIG_3_mD44AFC5C0F2F51940F06E070074622785CE4311B (void);
// 0x0000073C System.Int32 AkSoundEnginePINVOKE::CSharp_UnloadBank__SWIG_5(System.UInt32,System.IntPtr,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_UnloadBank__SWIG_5_mC8CBCE9F15E22231FBFF58EA65C1026733FCB9EE (void);
// 0x0000073D System.Void AkSoundEnginePINVOKE::CSharp_CancelBankCallbackCookie(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_CancelBankCallbackCookie_m711F8303CCCB66A741BE721AB95B0B9885E2BCD7 (void);
// 0x0000073E System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareBank__SWIG_0(System.Int32,System.String,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_0_m07EE44E01D30F3E35977D48C76B8033E558B94D0 (void);
// 0x0000073F System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareBank__SWIG_1(System.Int32,System.String)
extern void AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_1_mCDF5E73D12C99C499EA88F19C42A55981A55AFDE (void);
// 0x00000740 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareBank__SWIG_4(System.Int32,System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_4_m330E4053347A75DBFD48F579618BC43C61F6F6F3 (void);
// 0x00000741 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareBank__SWIG_5(System.Int32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_5_m45B64FEC3624136C9108A7D42D3387568BF6CD43 (void);
// 0x00000742 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareBank__SWIG_6(System.Int32,System.String,System.IntPtr,System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_6_m009AEDB01EA9DCC95BEAC8D9CC8B6F95E285D740 (void);
// 0x00000743 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareBank__SWIG_7(System.Int32,System.String,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_7_mAC5851342E7181301B124FF358FECE05E2DFBC59 (void);
// 0x00000744 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareBank__SWIG_10(System.Int32,System.UInt32,System.IntPtr,System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_10_m5262B6F4365497663419109B1BB3E75A4E05BDF1 (void);
// 0x00000745 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareBank__SWIG_11(System.Int32,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_11_mCA612E1DD976C75D8C96DE64A258CD8BC6C11259 (void);
// 0x00000746 System.Int32 AkSoundEnginePINVOKE::CSharp_ClearPreparedEvents()
extern void AkSoundEnginePINVOKE_CSharp_ClearPreparedEvents_m468E2C48731E42DFCCEBA31357F82036AF45F49C (void);
// 0x00000747 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareEvent__SWIG_0(System.Int32,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PrepareEvent__SWIG_0_m0E785F24D0EFD6383E74962AAA83495773C8F9D4 (void);
// 0x00000748 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareEvent__SWIG_1(System.Int32,System.UInt32[],System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PrepareEvent__SWIG_1_m82A1850E3B8E31BFF2C0C7C6065C7C3AE448031B (void);
// 0x00000749 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareEvent__SWIG_2(System.Int32,System.IntPtr,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PrepareEvent__SWIG_2_m31AFE7F422FD3C8E826629A69A1F739308CDDBD4 (void);
// 0x0000074A System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareEvent__SWIG_3(System.Int32,System.UInt32[],System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PrepareEvent__SWIG_3_m161D4701E0F4F4FE0F1FC17008D37E88E6DB859B (void);
// 0x0000074B System.Int32 AkSoundEnginePINVOKE::CSharp_SetMedia(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetMedia_m743B2FD153893E1DC71F3DCF1E36CCCDBFACD182 (void);
// 0x0000074C System.Int32 AkSoundEnginePINVOKE::CSharp_UnsetMedia(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_UnsetMedia_m3AB05EDDE4ADB56E78039C0EF6F2C2FBFFB3E29E (void);
// 0x0000074D System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareGameSyncs__SWIG_0(System.Int32,System.Int32,System.String,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PrepareGameSyncs__SWIG_0_mCF9E64BE721959DA1F43C080155FC0DF261EEA03 (void);
// 0x0000074E System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareGameSyncs__SWIG_1(System.Int32,System.Int32,System.UInt32,System.UInt32[],System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PrepareGameSyncs__SWIG_1_m45AE09D50C723B8A922600AEDC6CC086436B646D (void);
// 0x0000074F System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareGameSyncs__SWIG_2(System.Int32,System.Int32,System.String,System.IntPtr,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PrepareGameSyncs__SWIG_2_mA1C80FBCEA5F14836C3A3EA2BE1884B48685CA53 (void);
// 0x00000750 System.Int32 AkSoundEnginePINVOKE::CSharp_PrepareGameSyncs__SWIG_3(System.Int32,System.Int32,System.UInt32,System.UInt32[],System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PrepareGameSyncs__SWIG_3_mDFF4A85DADB3909BC7CCB5AE9050F4F9CC01DE59 (void);
// 0x00000751 System.Int32 AkSoundEnginePINVOKE::CSharp_AddListener(System.UInt64,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_AddListener_m0B1DF95C83606BCE7B0DA9F4D1FAB19E407A4EAD (void);
// 0x00000752 System.Int32 AkSoundEnginePINVOKE::CSharp_RemoveListener(System.UInt64,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_RemoveListener_m9CD214CD879F6EEE970F971247EC451D4B4F8625 (void);
// 0x00000753 System.Int32 AkSoundEnginePINVOKE::CSharp_AddDefaultListener(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_AddDefaultListener_m091190D2F0F74577CB02FC0669CCC0306FD59059 (void);
// 0x00000754 System.Int32 AkSoundEnginePINVOKE::CSharp_RemoveDefaultListener(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_RemoveDefaultListener_m4BC5FDE3AA52B33DA83126EF0FAA10731F48C270 (void);
// 0x00000755 System.Int32 AkSoundEnginePINVOKE::CSharp_ResetListenersToDefault(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_ResetListenersToDefault_m830592B82770552B49CED798AEA8388E14B96A6C (void);
// 0x00000756 System.Int32 AkSoundEnginePINVOKE::CSharp_SetListenerSpatialization__SWIG_0(System.UInt64,System.Boolean,System.IntPtr,System.Single[])
extern void AkSoundEnginePINVOKE_CSharp_SetListenerSpatialization__SWIG_0_mED83AE8BF07A5019F0AFB3C87AEC9AEE3BBD6642 (void);
// 0x00000757 System.Int32 AkSoundEnginePINVOKE::CSharp_SetListenerSpatialization__SWIG_1(System.UInt64,System.Boolean,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_SetListenerSpatialization__SWIG_1_m736945B107FBE36B8F8BB52C1207480DB8FA4820 (void);
// 0x00000758 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_0(System.UInt32,System.Single,System.UInt64,System.Int32,System.Int32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_0_mCA26E38B5CCAF872938C20E3A573C17C420D0ACC (void);
// 0x00000759 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_1(System.UInt32,System.Single,System.UInt64,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_1_m4C53E317DC503F7B6BFEA69CF4D75F15330BBA88 (void);
// 0x0000075A System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_2(System.UInt32,System.Single,System.UInt64,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_2_m8B8AAD6C4A02099219FA7400E2EF971001F45F0D (void);
// 0x0000075B System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_3(System.UInt32,System.Single,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_3_mA4217AC353993A00A64D215A3F41C67F9A5F1659 (void);
// 0x0000075C System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_4(System.UInt32,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_4_mED7B84D6C9152B553724D00E603C1FEACB94A908 (void);
// 0x0000075D System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_5(System.String,System.Single,System.UInt64,System.Int32,System.Int32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_5_mC45777606C709035028DBE493A7F427A3A23C172 (void);
// 0x0000075E System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_6(System.String,System.Single,System.UInt64,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_6_mD4473DBB16F58E5D592324A798C1F3DB2A0DB82F (void);
// 0x0000075F System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_7(System.String,System.Single,System.UInt64,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_7_m05A30A70391EC4ABC1AB03ECD0DA95DA5A4046E3 (void);
// 0x00000760 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_8(System.String,System.Single,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_8_m98E4C56A6F59D54460D6786F655AD06B6FE0EB08 (void);
// 0x00000761 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValue__SWIG_9(System.String,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_9_m67B46D3601BEC653A3B2401B0F8795C202D54E92 (void);
// 0x00000762 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValueByPlayingID__SWIG_0(System.UInt32,System.Single,System.UInt32,System.Int32,System.Int32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_0_m793E1CFC88A85E679BAAFAA335E1FF981C6EB086 (void);
// 0x00000763 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValueByPlayingID__SWIG_1(System.UInt32,System.Single,System.UInt32,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_1_m2AB2ED1F74FCBE14F546C8A1CBA07FBC2B03026A (void);
// 0x00000764 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValueByPlayingID__SWIG_2(System.UInt32,System.Single,System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_2_mAB60AAB895E2CA4DADA95B26B00D5182C2DABD9B (void);
// 0x00000765 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValueByPlayingID__SWIG_3(System.UInt32,System.Single,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_3_m3A087BC1DF81667A748FAE0766A51F576585B469 (void);
// 0x00000766 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValueByPlayingID__SWIG_4(System.String,System.Single,System.UInt32,System.Int32,System.Int32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_4_mC189F8FB9F7CF101AFB94F40A725C53A9AC12C8C (void);
// 0x00000767 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValueByPlayingID__SWIG_5(System.String,System.Single,System.UInt32,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_5_m47D8E38489B6CB9A4C11C033F7A3307484C724F4 (void);
// 0x00000768 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValueByPlayingID__SWIG_6(System.String,System.Single,System.UInt32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_6_m0301F94772263D9AF0920E599C21F932227A8884 (void);
// 0x00000769 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRTPCValueByPlayingID__SWIG_7(System.String,System.Single,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_7_mBA0F428281D485F3EB48EA24643D2F07512E9622 (void);
// 0x0000076A System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_0(System.UInt32,System.UInt64,System.Int32,System.Int32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_0_mCB8157A19966EDE97EDEF1D95E4D1C2A67083737 (void);
// 0x0000076B System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_1(System.UInt32,System.UInt64,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_1_m5136481C732FC6819F817E9B8E831C24855FC326 (void);
// 0x0000076C System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_2(System.UInt32,System.UInt64,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_2_mFB4CFCB47716A9A864866172CFE90553DEFED6E6 (void);
// 0x0000076D System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_3(System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_3_m969F44468D15C6CBA981E69743D19C4081E6CCF0 (void);
// 0x0000076E System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_4(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_4_mB73CBB05E1CA1904769F1FCF8E98A998B8AC0AD9 (void);
// 0x0000076F System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_5(System.String,System.UInt64,System.Int32,System.Int32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_5_m9AB87151CE5A6F698AF83D7A66111B684641B38E (void);
// 0x00000770 System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_6(System.String,System.UInt64,System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_6_m6151AD0E3AC59C20021FFE2EB2C74B322623A698 (void);
// 0x00000771 System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_7(System.String,System.UInt64,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_7_mA67C97FD5AA37C14E5785D8337D3FF8B88BE02E8 (void);
// 0x00000772 System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_8(System.String,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_8_mC7816070649E74D36843289E7C6E12B086042561 (void);
// 0x00000773 System.Int32 AkSoundEnginePINVOKE::CSharp_ResetRTPCValue__SWIG_9(System.String)
extern void AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_9_m9047E91A72E2CBAFFC696FA85D15C2E23C7F8B60 (void);
// 0x00000774 System.Int32 AkSoundEnginePINVOKE::CSharp_SetSwitch__SWIG_0(System.UInt32,System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_SetSwitch__SWIG_0_m0E1CC7DC62B7052692A726AF82CE0214B0191D34 (void);
// 0x00000775 System.Int32 AkSoundEnginePINVOKE::CSharp_SetSwitch__SWIG_1(System.String,System.String,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_SetSwitch__SWIG_1_m78ACB665638657B73F1068C67C09E2BC9B9B1B7E (void);
// 0x00000776 System.Int32 AkSoundEnginePINVOKE::CSharp_PostTrigger__SWIG_0(System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_PostTrigger__SWIG_0_mC510D2FA09DFAE69805CAF285A42140715E0BDE4 (void);
// 0x00000777 System.Int32 AkSoundEnginePINVOKE::CSharp_PostTrigger__SWIG_1(System.String,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_PostTrigger__SWIG_1_m517AAEBD77E21D4B05E30A013C4DA63C712FD1A1 (void);
// 0x00000778 System.Int32 AkSoundEnginePINVOKE::CSharp_SetState__SWIG_0(System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetState__SWIG_0_mBE4E03857B9F7121568449A48FA1610197CE73AB (void);
// 0x00000779 System.Int32 AkSoundEnginePINVOKE::CSharp_SetState__SWIG_1(System.String,System.String)
extern void AkSoundEnginePINVOKE_CSharp_SetState__SWIG_1_m8E69277B297538E9CF9A6085A1B132A4D29ADB0C (void);
// 0x0000077A System.Int32 AkSoundEnginePINVOKE::CSharp_SetGameObjectAuxSendValues(System.UInt64,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetGameObjectAuxSendValues_mEC889A005505A3A40204C99CE602EB1FA4B0BA15 (void);
// 0x0000077B System.Int32 AkSoundEnginePINVOKE::CSharp_SetGameObjectOutputBusVolume(System.UInt64,System.UInt64,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetGameObjectOutputBusVolume_m5728B90FD48A873540A7A2DD1E411AE70F8AFC37 (void);
// 0x0000077C System.Int32 AkSoundEnginePINVOKE::CSharp_SetActorMixerEffect(System.UInt32,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetActorMixerEffect_mE6754EA0734463CB1C03A8AD743CB11E0777FDE7 (void);
// 0x0000077D System.Int32 AkSoundEnginePINVOKE::CSharp_SetBusEffect__SWIG_0(System.UInt32,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetBusEffect__SWIG_0_m55783EB360065E68147E20B7E7045C5B0CD4D787 (void);
// 0x0000077E System.Int32 AkSoundEnginePINVOKE::CSharp_SetBusEffect__SWIG_1(System.String,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetBusEffect__SWIG_1_mFC8AEDEF6A5B7E88F40FBD26A7324C19C7B92FCE (void);
// 0x0000077F System.Int32 AkSoundEnginePINVOKE::CSharp_SetOutputDeviceEffect(System.UInt64,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetOutputDeviceEffect_m5D40B5CE451FE4BACD4C04260910B0C3A6812412 (void);
// 0x00000780 System.Int32 AkSoundEnginePINVOKE::CSharp_SetMixer__SWIG_0(System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetMixer__SWIG_0_mACE44FDA22CE6DD69A0D8D5E6BB560D37EE34A7A (void);
// 0x00000781 System.Int32 AkSoundEnginePINVOKE::CSharp_SetMixer__SWIG_1(System.String,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetMixer__SWIG_1_mBD8124BDC416C06F98990A436A3BBAF5A652C71D (void);
// 0x00000782 System.Int32 AkSoundEnginePINVOKE::CSharp_SetBusConfig__SWIG_0(System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_SetBusConfig__SWIG_0_m2F2C6D45B2BC28A9B8B61F25D23E38F88B611AFF (void);
// 0x00000783 System.Int32 AkSoundEnginePINVOKE::CSharp_SetBusConfig__SWIG_1(System.String,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_SetBusConfig__SWIG_1_m884EC6B814EF0F4A6D6E97B612C500F61B0BA059 (void);
// 0x00000784 System.Int32 AkSoundEnginePINVOKE::CSharp_SetObjectObstructionAndOcclusion(System.UInt64,System.UInt64,System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetObjectObstructionAndOcclusion_mA1811677DB0F992103B008EE04930D2CCD0CB840 (void);
// 0x00000785 System.Int32 AkSoundEnginePINVOKE::CSharp_SetMultipleObstructionAndOcclusion(System.UInt64,System.UInt64,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetMultipleObstructionAndOcclusion_m495D2231D3F1E06EF3579F2CF9D079C057F35286 (void);
// 0x00000786 System.Int32 AkSoundEnginePINVOKE::CSharp_StartOutputCapture(System.String)
extern void AkSoundEnginePINVOKE_CSharp_StartOutputCapture_m1F0D0CE3DA938D1E7B2B4E9DFDCE7B69B3052A29 (void);
// 0x00000787 System.Int32 AkSoundEnginePINVOKE::CSharp_StopOutputCapture()
extern void AkSoundEnginePINVOKE_CSharp_StopOutputCapture_mA2453F05A9DF771B2FA70C028FF2AE29C219D699 (void);
// 0x00000788 System.Int32 AkSoundEnginePINVOKE::CSharp_AddOutputCaptureMarker(System.String)
extern void AkSoundEnginePINVOKE_CSharp_AddOutputCaptureMarker_m3D1DE8E2AA6B2906F7470631A0F26744959EDCA9 (void);
// 0x00000789 System.Int32 AkSoundEnginePINVOKE::CSharp_StartProfilerCapture(System.String)
extern void AkSoundEnginePINVOKE_CSharp_StartProfilerCapture_m99469F4FFB91CDBB5FB491592CC80A5D94A7423E (void);
// 0x0000078A System.Int32 AkSoundEnginePINVOKE::CSharp_StopProfilerCapture()
extern void AkSoundEnginePINVOKE_CSharp_StopProfilerCapture_mA8506159EEC48F2D11D08537186D62519C433B49 (void);
// 0x0000078B System.Int32 AkSoundEnginePINVOKE::CSharp_RemoveOutput(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_RemoveOutput_mC13CD69859211808857E7F8FBB7A3C72839B137C (void);
// 0x0000078C System.Int32 AkSoundEnginePINVOKE::CSharp_ReplaceOutput__SWIG_0(System.IntPtr,System.UInt64,System.UInt64&)
extern void AkSoundEnginePINVOKE_CSharp_ReplaceOutput__SWIG_0_m5AF5F54F0A1CC2854267C31F9169F3F53664AA8F (void);
// 0x0000078D System.Int32 AkSoundEnginePINVOKE::CSharp_ReplaceOutput__SWIG_1(System.IntPtr,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_ReplaceOutput__SWIG_1_mA97026DBD2AA7910C042BC786E1E22E4D497FA28 (void);
// 0x0000078E System.UInt64 AkSoundEnginePINVOKE::CSharp_GetOutputID__SWIG_0(System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_GetOutputID__SWIG_0_m693858935F0F5D19013A0FFB3FB2980FD6891FB5 (void);
// 0x0000078F System.UInt64 AkSoundEnginePINVOKE::CSharp_GetOutputID__SWIG_1(System.String,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_GetOutputID__SWIG_1_m1F12261D38850E4CEB8D685F7F24FC63301B01AF (void);
// 0x00000790 System.Int32 AkSoundEnginePINVOKE::CSharp_SetBusDevice__SWIG_0(System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetBusDevice__SWIG_0_m0D3CF561A0A2B362C19F087AE88750B760066413 (void);
// 0x00000791 System.Int32 AkSoundEnginePINVOKE::CSharp_SetBusDevice__SWIG_1(System.String,System.String)
extern void AkSoundEnginePINVOKE_CSharp_SetBusDevice__SWIG_1_m68B8B224F8E93C2C254FA85A9782F6E0833FBA4F (void);
// 0x00000792 System.Int32 AkSoundEnginePINVOKE::CSharp_GetDeviceList__SWIG_0(System.UInt32,System.UInt32,System.UInt32&,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetDeviceList__SWIG_0_m876C9E2BFB9F46438DB49FC10E0F992D186BB73E (void);
// 0x00000793 System.Int32 AkSoundEnginePINVOKE::CSharp_GetDeviceList__SWIG_1(System.UInt32,System.UInt32&,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetDeviceList__SWIG_1_mCCEAA8C4FD303EE4A2C666A61449B154FD3D2367 (void);
// 0x00000794 System.Int32 AkSoundEnginePINVOKE::CSharp_SetOutputVolume(System.UInt64,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetOutputVolume_m691C483D7E67EAA2C83EE465A67D0DD7602ED99F (void);
// 0x00000795 System.Int32 AkSoundEnginePINVOKE::CSharp_GetDeviceSpatialAudioSupport(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_GetDeviceSpatialAudioSupport_m85551E23267CABA5470122AEBB6E07E9096CAB2F (void);
// 0x00000796 System.Int32 AkSoundEnginePINVOKE::CSharp_Suspend__SWIG_0(System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_Suspend__SWIG_0_m7422AD9A5816131106FC64C8B86E907687F67F8B (void);
// 0x00000797 System.Int32 AkSoundEnginePINVOKE::CSharp_Suspend__SWIG_1()
extern void AkSoundEnginePINVOKE_CSharp_Suspend__SWIG_1_m4406E7E60DC44C6449A916AD8A9B7CED4F1447D1 (void);
// 0x00000798 System.Int32 AkSoundEnginePINVOKE::CSharp_WakeupFromSuspend()
extern void AkSoundEnginePINVOKE_CSharp_WakeupFromSuspend_m6B3640C66BB2F3853B344A56E4F01978BE8FE85B (void);
// 0x00000799 System.UInt32 AkSoundEnginePINVOKE::CSharp_GetBufferTick()
extern void AkSoundEnginePINVOKE_CSharp_GetBufferTick_m19A08B04A6FF8960BC47ABBB34E6090D8D75919F (void);
// 0x0000079A System.UInt64 AkSoundEnginePINVOKE::CSharp_GetSampleTick()
extern void AkSoundEnginePINVOKE_CSharp_GetSampleTick_m9D210EA755FEE492C84E5DE91E88FA38A5E586B9 (void);
// 0x0000079B System.Void AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iCurrentPosition_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iCurrentPosition_set_m91EC79422DAA75EEB58273415CD609794FF9FB1A (void);
// 0x0000079C System.Int32 AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iCurrentPosition_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iCurrentPosition_get_mA3615745E3648831E758FF163063721CF7F7F0E4 (void);
// 0x0000079D System.Void AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iPreEntryDuration_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iPreEntryDuration_set_m43880323389E13D3BC5B02780664818481E99FC2 (void);
// 0x0000079E System.Int32 AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iPreEntryDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iPreEntryDuration_get_mF73A06B43E5C0C1AB4579A5F6A42676070BCEF32 (void);
// 0x0000079F System.Void AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iActiveDuration_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iActiveDuration_set_m06606E1AC250119C2D59D4C7F98F05CDFED7E7C8 (void);
// 0x000007A0 System.Int32 AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iActiveDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iActiveDuration_get_m21A01114BC0C5699A3453BF8F99F7B28CA0DE469 (void);
// 0x000007A1 System.Void AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iPostExitDuration_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iPostExitDuration_set_m6C4A608E715D6EA285C22FF03F909FBAA2641DD0 (void);
// 0x000007A2 System.Int32 AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iPostExitDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iPostExitDuration_get_mE51B30DB05AA7BD09A019FE99028EE89D56853DD (void);
// 0x000007A3 System.Void AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iRemainingLookAheadTime_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iRemainingLookAheadTime_set_mD9D79EF5B030BDD1BE770DB7E1C2614F2AA485C6 (void);
// 0x000007A4 System.Int32 AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_iRemainingLookAheadTime_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iRemainingLookAheadTime_get_m2D1622D621B6516EF041781ECC606B30CCB10204 (void);
// 0x000007A5 System.Void AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_fBeatDuration_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fBeatDuration_set_m45B10AF51387D20ED92E11649D74A20C3A83790D (void);
// 0x000007A6 System.Single AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_fBeatDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fBeatDuration_get_m59547A975519C59A3D69830894F2553E752DD416 (void);
// 0x000007A7 System.Void AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_fBarDuration_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fBarDuration_set_mE878EF699979116995B28EAC215CF363A934F389 (void);
// 0x000007A8 System.Single AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_fBarDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fBarDuration_get_m7A5A39D1584047F19E003391ADFCE6ADF106D28B (void);
// 0x000007A9 System.Void AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_fGridDuration_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fGridDuration_set_mC814B96D66820A7FDC23A1134FA7FFA3F22564C2 (void);
// 0x000007AA System.Single AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_fGridDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fGridDuration_get_m31C9806D774E4E8FDB8ACA67185C1D458EB5A789 (void);
// 0x000007AB System.Void AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_fGridOffset_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fGridOffset_set_mF3BC012D0378D8F344019E7BDD116AB5FD6486E4 (void);
// 0x000007AC System.Single AkSoundEnginePINVOKE::CSharp_AkSegmentInfo_fGridOffset_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fGridOffset_get_mAAE830A2461B17247A61FAC5FD3D9BE68634CC61 (void);
// 0x000007AD System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkSegmentInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkSegmentInfo_m0C848C2A9CE299BC51D69FC4BE90DE3E31AA24D6 (void);
// 0x000007AE System.Void AkSoundEnginePINVOKE::CSharp_delete_AkSegmentInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkSegmentInfo_mC0CBA51E55253B13C961EF8A208B07B8C741C874 (void);
// 0x000007AF System.Void AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_totalCPU_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_totalCPU_set_mC43D385F2E2C1B12E482A665861C4B3F763ED149 (void);
// 0x000007B0 System.Single AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_totalCPU_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_totalCPU_get_mA5DC173B395F78440AD2AC3FD2560DB426219FCE (void);
// 0x000007B1 System.Void AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_pluginCPU_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_pluginCPU_set_m68AE5DA99C19957F261696F22FD835226AC3E4F1 (void);
// 0x000007B2 System.Single AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_pluginCPU_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_pluginCPU_get_mBB0514BEEED26FC530EFF6E440E90D87D40B3892 (void);
// 0x000007B3 System.Void AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_physicalVoices_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_physicalVoices_set_m66DD236A09142AD0E1D4D3B3F5D244F8AC2F60B9 (void);
// 0x000007B4 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_physicalVoices_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_physicalVoices_get_m13B5E33AF10B5847AF7551F4D77EBFB85340F358 (void);
// 0x000007B5 System.Void AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_virtualVoices_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_virtualVoices_set_m68AD3838CACAE5BB424AB0D84D2B8A96D1D5611B (void);
// 0x000007B6 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_virtualVoices_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_virtualVoices_get_m518C7F8AAD0A477DAC210B784B0B97A083B83AF6 (void);
// 0x000007B7 System.Void AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_totalVoices_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_totalVoices_set_m965E644EB394A6EFF8F4636E668F2178A17072E9 (void);
// 0x000007B8 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_totalVoices_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_totalVoices_get_mA344E06316495A1CFC94CF8420022CFC0200BB17 (void);
// 0x000007B9 System.Void AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_nbActiveEvents_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_nbActiveEvents_set_m7EA21625A923644376366285E834F5263BC5609D (void);
// 0x000007BA System.UInt32 AkSoundEnginePINVOKE::CSharp_AkResourceMonitorDataSummary_nbActiveEvents_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_nbActiveEvents_get_m8357FD374E2A70820B85E69EA65BE233E67949E9 (void);
// 0x000007BB System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkResourceMonitorDataSummary()
extern void AkSoundEnginePINVOKE_CSharp_new_AkResourceMonitorDataSummary_mB0C66803B7F479D165868ADBCDC960D41BC70ED2 (void);
// 0x000007BC System.Void AkSoundEnginePINVOKE::CSharp_delete_AkResourceMonitorDataSummary(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkResourceMonitorDataSummary_m348B99839A6A3376D25F563A04B97EE6CD4EEA54 (void);
// 0x000007BD System.Byte AkSoundEnginePINVOKE::CSharp_AK_INVALID_MIDI_CHANNEL_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_INVALID_MIDI_CHANNEL_get_mFD8C9666736FA229D5B56EF26B55C31E06DBEE77 (void);
// 0x000007BE System.Byte AkSoundEnginePINVOKE::CSharp_AK_INVALID_MIDI_NOTE_get()
extern void AkSoundEnginePINVOKE_CSharp_AK_INVALID_MIDI_NOTE_get_m7B3F076D25285A2D00E5A0BC966BA3AFD70D2DC2 (void);
// 0x000007BF System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byChan_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byChan_set_m6431CAABA5ABBA862956BB98CC39D285967A2BB2 (void);
// 0x000007C0 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byChan_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byChan_get_m4FD141256C1BFA8D87D26461B5355030DE50A998 (void);
// 0x000007C1 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tGen_byParam1_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tGen_byParam1_set_m47F4567CA94B010A9269A5FB70726549F4FCA59D (void);
// 0x000007C2 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tGen_byParam1_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tGen_byParam1_get_m8659E3C1C2DA104F42A58CF49533B45E6E96D1C0 (void);
// 0x000007C3 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tGen_byParam2_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tGen_byParam2_set_m2265096B5BBA8B7F70FCFE86D86450200B835F87 (void);
// 0x000007C4 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tGen_byParam2_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tGen_byParam2_get_mF3E5584D8FB5985194975FC27AA4CF88ACD2B31D (void);
// 0x000007C5 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEvent_tGen()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tGen_m582F6C3E67C5F0581A47C2A97755CF3F23178979 (void);
// 0x000007C6 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEvent_tGen(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tGen_m15AED6AD4B80BC9F9D66F1CB51152F25E92A466A (void);
// 0x000007C7 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tNoteOnOff_byNote_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteOnOff_byNote_set_mA7BBD46FE4D48ACA43C61B38970BA3295D96B3E2 (void);
// 0x000007C8 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tNoteOnOff_byNote_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteOnOff_byNote_get_mE690DA0AF6FFF644EC966BC22D15008AB44F8975 (void);
// 0x000007C9 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tNoteOnOff_byVelocity_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteOnOff_byVelocity_set_m9F1FF3BB31A45794BEC8968FD427F330F50C522D (void);
// 0x000007CA System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tNoteOnOff_byVelocity_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteOnOff_byVelocity_get_m419CDF6E0D0DD4ADD93AF281DE25B085ECF9039D (void);
// 0x000007CB System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEvent_tNoteOnOff()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tNoteOnOff_m0F4E36C96AC372EB190A8477B435274BE7C82FD0 (void);
// 0x000007CC System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEvent_tNoteOnOff(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tNoteOnOff_m1EF89B6645975841187EA8E9728DB31E5D618013 (void);
// 0x000007CD System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tCc_byCc_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tCc_byCc_set_m1B09E54D7B20E9ABD06EA02172C14B5D2E6C8A23 (void);
// 0x000007CE System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tCc_byCc_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tCc_byCc_get_m03F37E963FCFD948CA52CDD733349BEE3C010019 (void);
// 0x000007CF System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tCc_byValue_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tCc_byValue_set_mFA63082C54C98FB672823DBB5986603A8255707D (void);
// 0x000007D0 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tCc_byValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tCc_byValue_get_m9C69AD35C43074D10E18ECCC435C479A94C1AABB (void);
// 0x000007D1 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEvent_tCc()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tCc_m49D994BC6571774A7A8980CC001579C11E2E75F6 (void);
// 0x000007D2 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEvent_tCc(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tCc_mD7D67567FC05CCECF214813A27D1E96D3EA7AA0B (void);
// 0x000007D3 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tPitchBend_byValueLsb_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tPitchBend_byValueLsb_set_m82CFD0C22451B72B571669814F6F2C7D6DC74060 (void);
// 0x000007D4 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tPitchBend_byValueLsb_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tPitchBend_byValueLsb_get_m78C193510A40F97B4A8C50DB57721F19BBE6AFB3 (void);
// 0x000007D5 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tPitchBend_byValueMsb_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tPitchBend_byValueMsb_set_m7FA65CEC8589E924AE3CB25050DCC4BA9CD55C77 (void);
// 0x000007D6 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tPitchBend_byValueMsb_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tPitchBend_byValueMsb_get_m178DC1943AD786F920FD88A5553667B331EC960D (void);
// 0x000007D7 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEvent_tPitchBend()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tPitchBend_m902C47759F2FF8FE6BE77C3D539774C65B469A25 (void);
// 0x000007D8 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEvent_tPitchBend(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tPitchBend_m63B1A2FA42938D97C12FBD3C38D12B36A95273A8 (void);
// 0x000007D9 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tNoteAftertouch_byNote_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteAftertouch_byNote_set_m69246B3F0D294E1CA22A6325415F8574C0BCA0D9 (void);
// 0x000007DA System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tNoteAftertouch_byNote_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteAftertouch_byNote_get_mA7F0D69E7860864E088A9F5FF992466506CFAB3A (void);
// 0x000007DB System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tNoteAftertouch_byValue_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteAftertouch_byValue_set_m9D5ED60C6BF8E02D53E176D8514B2754D2E0E8B0 (void);
// 0x000007DC System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tNoteAftertouch_byValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteAftertouch_byValue_get_m0BBBB9B4CA78742811F3634196C8C7B4F176C780 (void);
// 0x000007DD System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEvent_tNoteAftertouch()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tNoteAftertouch_m6472F96D0B16B72817F1A623BCDE7A4720AC2E14 (void);
// 0x000007DE System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEvent_tNoteAftertouch(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tNoteAftertouch_mAA422A986C29C88201035E6A6A89A6BEE1937C83 (void);
// 0x000007DF System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tChanAftertouch_byValue_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tChanAftertouch_byValue_set_m10AF6188C42D02E245C82AD60B9FDDDAFB789334 (void);
// 0x000007E0 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tChanAftertouch_byValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tChanAftertouch_byValue_get_mFBAC29B98A53DB5447D2620A273344424053FFF7 (void);
// 0x000007E1 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEvent_tChanAftertouch()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tChanAftertouch_m33DF9C7B2541A25124CBEDB4CB7756E0D55E6249 (void);
// 0x000007E2 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEvent_tChanAftertouch(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tChanAftertouch_m06EC370679B2A8B892A1A84C33095C5BDDA568D3 (void);
// 0x000007E3 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tProgramChange_byProgramNum_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tProgramChange_byProgramNum_set_mB83831FE1D830053A94D411B71C72BB7B5AC945D (void);
// 0x000007E4 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tProgramChange_byProgramNum_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tProgramChange_byProgramNum_get_mEC42D04326BA71579513DB201B67C76230C950E9 (void);
// 0x000007E5 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEvent_tProgramChange()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tProgramChange_m451C55B8F2A3AAA6CAB371CFE44D4A001CD90A94 (void);
// 0x000007E6 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEvent_tProgramChange(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tProgramChange_m90538AC4BF3B99FA29126E813992A8F7EADE2178 (void);
// 0x000007E7 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tWwiseCmd_uCmd_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tWwiseCmd_uCmd_set_mFF3A1884425FADBAB24CF01D8BEE2A9F4F6C9671 (void);
// 0x000007E8 System.UInt16 AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tWwiseCmd_uCmd_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tWwiseCmd_uCmd_get_m66840325018DE4974F9BF152477F606F43217C9D (void);
// 0x000007E9 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tWwiseCmd_uArg_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tWwiseCmd_uArg_set_mF6004511726005CB7CB98DF2836C1503084662D8 (void);
// 0x000007EA System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_tWwiseCmd_uArg_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tWwiseCmd_uArg_get_mBC513EF3C73EA51048047727F1A3403357E42000 (void);
// 0x000007EB System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEvent_tWwiseCmd()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tWwiseCmd_m2F21C14D49C5E1F1A633D90822B3317758E2AB9B (void);
// 0x000007EC System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEvent_tWwiseCmd(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tWwiseCmd_m2CA58B051232CEA59BB9EEDEE4A50F1C9F645691 (void);
// 0x000007ED System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_Gen_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_Gen_set_mCEC79C3F4E75EBF431F2C3674BBF9B0E912C5439 (void);
// 0x000007EE System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_Gen_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_Gen_get_m8D9DD8F099CFFA8E287AF1413B35BA93DDB9A01B (void);
// 0x000007EF System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_Cc_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_Cc_set_mDD677681AE881E653A059A055B301BAB8C22C12D (void);
// 0x000007F0 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_Cc_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_Cc_get_m01BF34BB5C27FF37DD39A88CAA615896EF070C41 (void);
// 0x000007F1 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_NoteOnOff_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_NoteOnOff_set_mF1D1F7970DBE695231B1EB26A97EAB170EBA0E4E (void);
// 0x000007F2 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_NoteOnOff_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_NoteOnOff_get_mF3196BEEFB684E3D24CFF270845DD00025685017 (void);
// 0x000007F3 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_PitchBend_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_PitchBend_set_m0DEEF071A0F21160924B73C5E51639ED1CD00615 (void);
// 0x000007F4 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_PitchBend_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_PitchBend_get_m57D7085B81ED5A0AD3CD911DD55DBA8C82BF559D (void);
// 0x000007F5 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_NoteAftertouch_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_NoteAftertouch_set_m1FCAE5C24830465B27572DC562A4EA9386786E93 (void);
// 0x000007F6 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_NoteAftertouch_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_NoteAftertouch_get_m7AC179320954A3676B77CD1D03019E5A99A7DE21 (void);
// 0x000007F7 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_ChanAftertouch_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_ChanAftertouch_set_m0F69BA87D4E8D9F49D305E5B7D749F785BD6CE9D (void);
// 0x000007F8 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_ChanAftertouch_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_ChanAftertouch_get_mD1737283650474043A72A89EC4AB6AE77675DC25 (void);
// 0x000007F9 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_ProgramChange_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_ProgramChange_set_m0FCEA9D529D0C64BAF399250D52E71AE678BABD2 (void);
// 0x000007FA System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_ProgramChange_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_ProgramChange_get_m44E9A772298C51D1496918AF4EC3F075DD9BBDF1 (void);
// 0x000007FB System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_WwiseCmd_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_WwiseCmd_set_m1D3F2E42E8CE923E8BAD2756968371B4B9AB78AA (void);
// 0x000007FC System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_WwiseCmd_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_WwiseCmd_get_m85B16070C6E2471639ED78447A350B6B9B6F2FFC (void);
// 0x000007FD System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byType_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byType_set_mEDDA6920CDA1FBC041C4A93F8CCDF995BB02E404 (void);
// 0x000007FE System.Int32 AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byType_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byType_get_m3E8EFB8C01D9630A90FA6CBE1CA634BF09091DCC (void);
// 0x000007FF System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byOnOffNote_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byOnOffNote_set_mF3D08D0DA53B38DDE9C48619D5D093BE86E88172 (void);
// 0x00000800 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byOnOffNote_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byOnOffNote_get_m6433C26CFF47306E86130E740AD5DB40728BB6D0 (void);
// 0x00000801 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byVelocity_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byVelocity_set_m948304DE8B91983B5023B24AB02A4C0F678BE72E (void);
// 0x00000802 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byVelocity_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byVelocity_get_m541CB2AF5B8F6D4D13639D21A1F466650B1691AB (void);
// 0x00000803 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byCc_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byCc_set_m1AD433EB10685B653D86160507D5E85FE6F569B1 (void);
// 0x00000804 System.Int32 AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byCc_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byCc_get_m6A4E1EB8C9440714BCC70BAA1AC2AEA579CE8F27 (void);
// 0x00000805 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byCcValue_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byCcValue_set_m37C806A7DF7587745A644E2698858D84B5C9C878 (void);
// 0x00000806 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byCcValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byCcValue_get_mA32C01BC72188C9DB2D4518B21F288B39185CA0D (void);
// 0x00000807 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byValueLsb_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byValueLsb_set_m9366A625D1E3B9455C981218F61C2FF92AA10B0D (void);
// 0x00000808 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byValueLsb_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byValueLsb_get_m9677D1863287C46074B48EF3E93E14CAF53AB149 (void);
// 0x00000809 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byValueMsb_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byValueMsb_set_mA6BC86D32F44D7C334B373B76CD18FFC1BF9B46C (void);
// 0x0000080A System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byValueMsb_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byValueMsb_get_m4C83A574E48D6383640DE61D01E892D7FDF2B181 (void);
// 0x0000080B System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byAftertouchNote_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byAftertouchNote_set_m68557BC8443AB8BD6A2360AFE158660CB0F030BB (void);
// 0x0000080C System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byAftertouchNote_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byAftertouchNote_get_m5F89D34E0ACC5C177B651AA229A2F254BC290050 (void);
// 0x0000080D System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byNoteAftertouchValue_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byNoteAftertouchValue_set_m143B25861B1E02E528DAE2CF65F80AF287FD2D3C (void);
// 0x0000080E System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byNoteAftertouchValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byNoteAftertouchValue_get_m3B050D127F9F7216FD912A7C8EC41E83B2E27305 (void);
// 0x0000080F System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byChanAftertouchValue_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byChanAftertouchValue_set_m10CE2586B9D1B05B859696FAD1A220DB1F34E29C (void);
// 0x00000810 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byChanAftertouchValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byChanAftertouchValue_get_m0F64C65DAA26A195F1A57B76C2BED9E3D8AEA46B (void);
// 0x00000811 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byProgramNum_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byProgramNum_set_m96909F65B2BA318E2264CE241876DBE30AF3D380 (void);
// 0x00000812 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_byProgramNum_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byProgramNum_get_m36812EB66FE9A22EC771E45DA72FBDB10B623D6D (void);
// 0x00000813 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_uCmd_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_uCmd_set_m65392895A0F099C233FAC0CCEB19B20EF0C60D86 (void);
// 0x00000814 System.UInt16 AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_uCmd_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_uCmd_get_mF260F11EC6FD426DE3086863A6D690E8C8630131 (void);
// 0x00000815 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_uArg_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_uArg_set_m19B5FC52F51B913FDAC7DAB33FB9D23F54D948DD (void);
// 0x00000816 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMIDIEvent_uArg_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_uArg_get_mB7BC4DE252B163CCB6291B1136F5D3358E2A9532 (void);
// 0x00000817 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEvent()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_mC2F185382A955CF5369F31D4622316B1815F6AC2 (void);
// 0x00000818 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEvent(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_m1858A364C8352566E9643F97D3415B14D0B8D863 (void);
// 0x00000819 System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIPost_uOffset_set(System.IntPtr,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIPost_uOffset_set_m0723579E2B93C6F72E174F5BD3D2269DE32BBBA7 (void);
// 0x0000081A System.UInt64 AkSoundEnginePINVOKE::CSharp_AkMIDIPost_uOffset_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIPost_uOffset_get_m73BA68B3C26E879B976102B897483FC7FCF3CBC7 (void);
// 0x0000081B System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMIDIPost_PostOnEvent__SWIG_0(System.IntPtr,System.UInt32,System.UInt64,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIPost_PostOnEvent__SWIG_0_m1ACE59A0E96643B42D4837B954301450FF9FBBAC (void);
// 0x0000081C System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMIDIPost_PostOnEvent__SWIG_1(System.IntPtr,System.UInt32,System.UInt64,System.UInt32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIPost_PostOnEvent__SWIG_1_m4010BF50F475C7FDF85F61E599EBEDC0585C3508 (void);
// 0x0000081D System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMIDIPost_PostOnEvent__SWIG_2(System.IntPtr,System.UInt32,System.UInt64,System.UInt32,System.Boolean,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIPost_PostOnEvent__SWIG_2_m51674819985E07DC467EAB8D83D60BA96A28CCC2 (void);
// 0x0000081E System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMIDIPost_PostOnEvent__SWIG_3(System.IntPtr,System.UInt32,System.UInt64,System.UInt32,System.Boolean,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIPost_PostOnEvent__SWIG_3_m3626C5B8FB1CBEF8D7627B0DBBB653227288D326 (void);
// 0x0000081F System.Void AkSoundEnginePINVOKE::CSharp_AkMIDIPost_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIPost_Clone_m9480C58648CFD3D5F938C4A1EEFF030FF9A09440 (void);
// 0x00000820 System.Int32 AkSoundEnginePINVOKE::CSharp_AkMIDIPost_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIPost_GetSizeOf_m518125F299A4142138D0804BC40D1BFD341A8CC6 (void);
// 0x00000821 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIPost()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIPost_m1A487ED08A07DF01A4A81A71C7E6671CF7F781D2 (void);
// 0x00000822 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIPost(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIPost_m2503E03269714B57527CEE4964FCD02BA1D78A06 (void);
// 0x00000823 System.Void AkSoundEnginePINVOKE::CSharp_AkMusicSettings_fStreamingLookAheadRatio_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSettings_fStreamingLookAheadRatio_set_mBB62C196B0C2BC1FC415E855A63987FC1697037B (void);
// 0x00000824 System.Single AkSoundEnginePINVOKE::CSharp_AkMusicSettings_fStreamingLookAheadRatio_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSettings_fStreamingLookAheadRatio_get_m4583D4B60A06752AA12149757DBA19A65B446690 (void);
// 0x00000825 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMusicSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMusicSettings_m5ED43223C2F35C105C0D7763B4C1052D0B4B0956 (void);
// 0x00000826 System.Int32 AkSoundEnginePINVOKE::CSharp_GetPlayingSegmentInfo__SWIG_0(System.UInt32,System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_GetPlayingSegmentInfo__SWIG_0_m2A86888844D2FAAFE9C30E46B212638921104EEB (void);
// 0x00000827 System.Int32 AkSoundEnginePINVOKE::CSharp_GetPlayingSegmentInfo__SWIG_1(System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetPlayingSegmentInfo__SWIG_1_m40DA1669D120EC95F0719FDCF5937ABB187A4E69 (void);
// 0x00000828 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkSerializedCallbackHeader_pPackage_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSerializedCallbackHeader_pPackage_get_m8E22B84CA3448326ED5177C8AE6857B70822E04F (void);
// 0x00000829 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkSerializedCallbackHeader_eType_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSerializedCallbackHeader_eType_get_m620C0266DD937168D65509A16687BAD619B0B8E1 (void);
// 0x0000082A System.IntPtr AkSoundEnginePINVOKE::CSharp_AkSerializedCallbackHeader_GetData(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSerializedCallbackHeader_GetData_m83ED01869F6A73E32C43E70E4A0586B8CE4FD0D3 (void);
// 0x0000082B System.IntPtr AkSoundEnginePINVOKE::CSharp_AkSerializedCallbackHeader_pNext_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSerializedCallbackHeader_pNext_get_m9DEA157B79CA1F0C31593EE493AA44A1B4BD227B (void);
// 0x0000082C System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkSerializedCallbackHeader()
extern void AkSoundEnginePINVOKE_CSharp_new_AkSerializedCallbackHeader_m0A89EDA2DDB1CBF73497A1B43D65F8D78E632896 (void);
// 0x0000082D System.Void AkSoundEnginePINVOKE::CSharp_delete_AkSerializedCallbackHeader(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkSerializedCallbackHeader_m7F5F076CF97CBCCEEAF9E3BBEB8532347402D700 (void);
// 0x0000082E System.IntPtr AkSoundEnginePINVOKE::CSharp_AkCallbackInfo_pCookie_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCallbackInfo_pCookie_get_mE5B4C90A8EBDF8C86798375D5C6B06EDE535F4CD (void);
// 0x0000082F System.UInt64 AkSoundEnginePINVOKE::CSharp_AkCallbackInfo_gameObjID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCallbackInfo_gameObjID_get_m3A8FF45DF937C8330B47C414F54AB9355D894389 (void);
// 0x00000830 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkCallbackInfo_mBDBA2F087B4730A6D52921E889EFBB2859F4E0D0 (void);
// 0x00000831 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkCallbackInfo_mADD00F6FDAB1C5E6DA882DF3FA711C4948D90900 (void);
// 0x00000832 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkEventCallbackInfo_playingID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkEventCallbackInfo_playingID_get_m28D2BDB39E211AE53C550CC0F96573B8057469B7 (void);
// 0x00000833 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkEventCallbackInfo_eventID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkEventCallbackInfo_eventID_get_mE6F3D5912FDA0D85F11C9B368A5E762A3587F7BC (void);
// 0x00000834 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkEventCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkEventCallbackInfo_m93101C636CC55E54C896B93B3E03FAF40FE0F44E (void);
// 0x00000835 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkEventCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkEventCallbackInfo_m343BB5A52A24501601C2836735504AAF24121344 (void);
// 0x00000836 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byChan_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byChan_get_m1B4F1E3E3C232D8392CE49FA44C390D96E2F7B9B (void);
// 0x00000837 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byParam1_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byParam1_get_m49794E96381C0BD30188441E3698BA80292965B0 (void);
// 0x00000838 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byParam2_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byParam2_get_m3DEC2B34C898FF6CCFF9A8548368B87C1A7621ED (void);
// 0x00000839 System.Int32 AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byType_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byType_get_mC4E4786F5ECA5CAC5101D3578BF752C2710E4E2C (void);
// 0x0000083A System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byOnOffNote_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byOnOffNote_get_mEA2D3D2345599EB82C8031517938FB94AD5B99B7 (void);
// 0x0000083B System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byVelocity_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byVelocity_get_mA48C28793C291CAFFE2138BE36D8A87E15DA466F (void);
// 0x0000083C System.Int32 AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byCc_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byCc_get_m2449EDC29D9C1907DC727E99600D0C5B542B5FBA (void);
// 0x0000083D System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byCcValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byCcValue_get_mF939CD88F9DEA798829C568169B6F42FCAEC3FB0 (void);
// 0x0000083E System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byValueLsb_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byValueLsb_get_m850F669976BB94A57B74B3AE13DD700C175B80CB (void);
// 0x0000083F System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byValueMsb_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byValueMsb_get_mDEB35FF64290467AFA8C508B3371A3863C7F5AD8 (void);
// 0x00000840 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byAftertouchNote_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byAftertouchNote_get_m487BCFCF1C2557530E05A4363ED7DB49E427C7F6 (void);
// 0x00000841 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byNoteAftertouchValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byNoteAftertouchValue_get_m9B536B90442964D1D3DF308331FBF9AB5457AFD4 (void);
// 0x00000842 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byChanAftertouchValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byChanAftertouchValue_get_m6A406037AB7F5F850FA6B4BBE6BE7307BD9D4445 (void);
// 0x00000843 System.Byte AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_byProgramNum_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byProgramNum_get_mE33CDABE0DFA06DB7EF176747B7C68366139464B (void);
// 0x00000844 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMIDIEventCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMIDIEventCallbackInfo_mA6251508C2A0156D68D67BFB8E721DC7E743B200 (void);
// 0x00000845 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMIDIEventCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEventCallbackInfo_mCD8067CEA09D26AD46721A950A27958548CD322C (void);
// 0x00000846 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMarkerCallbackInfo_uIdentifier_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMarkerCallbackInfo_uIdentifier_get_mE8780FC2569C21F665F6475A84CDC3D8B3812837 (void);
// 0x00000847 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMarkerCallbackInfo_uPosition_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMarkerCallbackInfo_uPosition_get_m1220D946B34E316CCF6DFF0329DEC39B7A115F8F (void);
// 0x00000848 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMarkerCallbackInfo_strLabel_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMarkerCallbackInfo_strLabel_get_m274CBA5B395BAE11273B33AFDCB7BA31D4E80A18 (void);
// 0x00000849 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMarkerCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMarkerCallbackInfo_mC00EAB3A981456C8D2E0439E7DFC9CE52C8D5428 (void);
// 0x0000084A System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMarkerCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMarkerCallbackInfo_mA94DE78D6EB1B5BA391A9C5E30FAE195E8A0CA53 (void);
// 0x0000084B System.Single AkSoundEnginePINVOKE::CSharp_AkDurationCallbackInfo_fDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_fDuration_get_m909B5C5AB572FED5AE6A2BB70816BAA6D8FAB0C4 (void);
// 0x0000084C System.Single AkSoundEnginePINVOKE::CSharp_AkDurationCallbackInfo_fEstimatedDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_fEstimatedDuration_get_m8A2A54D9352C0BB44FBB59FC63AF5262D73141D8 (void);
// 0x0000084D System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDurationCallbackInfo_audioNodeID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_audioNodeID_get_m19C744140B2DB36428DCE784A2F907252320145B (void);
// 0x0000084E System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDurationCallbackInfo_mediaID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_mediaID_get_m62A1FA8B61BE10A9E9DDC87A5934381AEEF5CF46 (void);
// 0x0000084F System.Boolean AkSoundEnginePINVOKE::CSharp_AkDurationCallbackInfo_bStreaming_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_bStreaming_get_m5F85E2F04634C2FBD7AA0F8B020DA093872051B9 (void);
// 0x00000850 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkDurationCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkDurationCallbackInfo_m358AB36682F59E5D5B7E035F3D9DB0A65311EA57 (void);
// 0x00000851 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkDurationCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkDurationCallbackInfo_m7B262D4B4C2B95F1D9EC39DA4D5140FD816B629C (void);
// 0x00000852 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDynamicSequenceItemCallbackInfo_playingID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDynamicSequenceItemCallbackInfo_playingID_get_mFE0E5215666B10B00F3B161CB88F44EF4E49D716 (void);
// 0x00000853 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDynamicSequenceItemCallbackInfo_audioNodeID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDynamicSequenceItemCallbackInfo_audioNodeID_get_mA5AAFA924A84B4E67AB067EDB3A0818FD9FAEAC1 (void);
// 0x00000854 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkDynamicSequenceItemCallbackInfo_pCustomInfo_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDynamicSequenceItemCallbackInfo_pCustomInfo_get_m5ED0203AA237741EBA28FE6A56413834202D3239 (void);
// 0x00000855 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkDynamicSequenceItemCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkDynamicSequenceItemCallbackInfo_m80F372F0C3B9E239C6DC4326DC1210B68A8C4F48 (void);
// 0x00000856 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkDynamicSequenceItemCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkDynamicSequenceItemCallbackInfo_m3657EA8A6767DED2F192EE4829B0308DF1E6CE85 (void);
// 0x00000857 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_playingID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_playingID_get_mA1FFF69F537254346C36EE6F8D49B19AEFDD971F (void);
// 0x00000858 System.Int32 AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_segmentInfo_iCurrentPosition_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iCurrentPosition_get_mC64DD077AEABF720B2E8BA96DB37B01B2E7FF20C (void);
// 0x00000859 System.Int32 AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_segmentInfo_iPreEntryDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iPreEntryDuration_get_mEE180386BC44FA394460758DA412D35D7B8CAF2E (void);
// 0x0000085A System.Int32 AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_segmentInfo_iActiveDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iActiveDuration_get_m26CF6D15A833EB9CC019D7CCD71356849EF63C0B (void);
// 0x0000085B System.Int32 AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_segmentInfo_iPostExitDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iPostExitDuration_get_m6C52FE36C7BF37A451D1E3E678E6CC2722DE3B2C (void);
// 0x0000085C System.Int32 AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_segmentInfo_iRemainingLookAheadTime_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iRemainingLookAheadTime_get_m2474CF688AA1B77F63650833CD91068A62680549 (void);
// 0x0000085D System.Single AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_segmentInfo_fBeatDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_fBeatDuration_get_mB2D45332D2D6FB0B82D18B75261A482E667D6A55 (void);
// 0x0000085E System.Single AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_segmentInfo_fBarDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_fBarDuration_get_m02799AE5DE6587D9F1351727183551A1757257B0 (void);
// 0x0000085F System.Single AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_segmentInfo_fGridDuration_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_fGridDuration_get_m13B8A7C8BAF0F26B8106B70208E761AE19131F5D (void);
// 0x00000860 System.Single AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_segmentInfo_fGridOffset_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_fGridOffset_get_m86439010DFE7D9C1F0DFC95E4C07A053970B469D (void);
// 0x00000861 System.Int32 AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_musicSyncType_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_musicSyncType_get_m61C460BE9A149C9692F97F1AB00C310E24B113F2 (void);
// 0x00000862 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_userCueName_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_userCueName_get_mE5C6222341B4DF855A4D93E88DE63F6EBDAE6330 (void);
// 0x00000863 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMusicSyncCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMusicSyncCallbackInfo_mFA75035E67106EF6C071657B763FEDBA6E6C5F08 (void);
// 0x00000864 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMusicSyncCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMusicSyncCallbackInfo_mAFB4F335BABEB3BE2C36C28353778192A73F9B32 (void);
// 0x00000865 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMusicPlaylistCallbackInfo_playlistID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_playlistID_get_m261930B60258C47E9428ADD099F9201AE7FC32DD (void);
// 0x00000866 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMusicPlaylistCallbackInfo_uNumPlaylistItems_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_uNumPlaylistItems_get_mA951B4E7B39E42E0FE684794F4EE000A0BE4CB92 (void);
// 0x00000867 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMusicPlaylistCallbackInfo_uPlaylistSelection_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_uPlaylistSelection_get_m0028098A0F5EEE65AA1EB2566BD7225B51D083E4 (void);
// 0x00000868 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMusicPlaylistCallbackInfo_uPlaylistItemDone_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_uPlaylistItemDone_get_m35B9A7EDDBD88090E23F8738E7F4FFB0412548AD (void);
// 0x00000869 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMusicPlaylistCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMusicPlaylistCallbackInfo_m807EC56CEA99A66444DD4FB03280970931EC46EA (void);
// 0x0000086A System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMusicPlaylistCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMusicPlaylistCallbackInfo_mD05D6EEBDF8FCCCFDE76F0882D04F773F9BD45BE (void);
// 0x0000086B System.UInt32 AkSoundEnginePINVOKE::CSharp_AkBankCallbackInfo_bankID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBankCallbackInfo_bankID_get_mEF83E1CD9EB7FFB15C408C1F6D0CBB5436E267FE (void);
// 0x0000086C System.IntPtr AkSoundEnginePINVOKE::CSharp_AkBankCallbackInfo_inMemoryBankPtr_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBankCallbackInfo_inMemoryBankPtr_get_m9BE6C1B1A53B41551C30D3EC7A8AC3132F063E6F (void);
// 0x0000086D System.Int32 AkSoundEnginePINVOKE::CSharp_AkBankCallbackInfo_loadResult_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkBankCallbackInfo_loadResult_get_m3CC4D8E1E5D96B77252F6687F327D6A98CDD20D1 (void);
// 0x0000086E System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkBankCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkBankCallbackInfo_mE1C8B8D58CBF03195341E3B6276239DE84B82075 (void);
// 0x0000086F System.Void AkSoundEnginePINVOKE::CSharp_delete_AkBankCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkBankCallbackInfo_mE83EAFE086D2F7315FC4D1275FD9B0966EB4A8DF (void);
// 0x00000870 System.Int32 AkSoundEnginePINVOKE::CSharp_AkMonitoringCallbackInfo_errorCode_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_errorCode_get_mFBBB32FEAB860BCA204D52FE8EC49055CA6FAFAD (void);
// 0x00000871 System.Int32 AkSoundEnginePINVOKE::CSharp_AkMonitoringCallbackInfo_errorLevel_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_errorLevel_get_m626F75148B1D775C2AF700C99C3744D7343DAAD1 (void);
// 0x00000872 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkMonitoringCallbackInfo_playingID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_playingID_get_mC31E6B3351E3D8279DC37E82E57329DF50F28B7E (void);
// 0x00000873 System.UInt64 AkSoundEnginePINVOKE::CSharp_AkMonitoringCallbackInfo_gameObjID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_gameObjID_get_mBAF8F793BF95AC2377845B798FBBC741990294E6 (void);
// 0x00000874 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMonitoringCallbackInfo_message_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_message_get_mF0BBD79DFA6C55B2DF55ABB293A93A97F3AEDACF (void);
// 0x00000875 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkMonitoringCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkMonitoringCallbackInfo_mD06AEF1B39B7A5DF169D27E1BBD031FC546F1A8F (void);
// 0x00000876 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkMonitoringCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkMonitoringCallbackInfo_mA3C67C5AF90D4D352020BE44EDC8DA7C96F6CD0E (void);
// 0x00000877 System.Boolean AkSoundEnginePINVOKE::CSharp_AkAudioInterruptionCallbackInfo_bEnterInterruption_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioInterruptionCallbackInfo_bEnterInterruption_get_mED181F6D5CD1B7609DBB745AE66272102E10E944 (void);
// 0x00000878 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkAudioInterruptionCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkAudioInterruptionCallbackInfo_m1BE8C795C3E251D1FCD0F5683CCB2AFEDF179462 (void);
// 0x00000879 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkAudioInterruptionCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkAudioInterruptionCallbackInfo_m9B94C77D151AD71C0B08CB06582C6C6A8892F7D7 (void);
// 0x0000087A System.Boolean AkSoundEnginePINVOKE::CSharp_AkAudioSourceChangeCallbackInfo_bOtherAudioPlaying_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAudioSourceChangeCallbackInfo_bOtherAudioPlaying_get_m93AE2DBD1EC1C0083278ECBBB64AA3140C0A3BEB (void);
// 0x0000087B System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkAudioSourceChangeCallbackInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkAudioSourceChangeCallbackInfo_m4EAD31B5216E49FED68F19560D22F1FD044B7F07 (void);
// 0x0000087C System.Void AkSoundEnginePINVOKE::CSharp_delete_AkAudioSourceChangeCallbackInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkAudioSourceChangeCallbackInfo_m5D2C530EA08F331F7E36EBF0D8F0FE5533920851 (void);
// 0x0000087D System.Int32 AkSoundEnginePINVOKE::CSharp_AkCallbackSerializer_Init()
extern void AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_Init_m3C7B6B87ED929AA6DB3D3B8D9D6C31B19E3A2BFF (void);
// 0x0000087E System.Void AkSoundEnginePINVOKE::CSharp_AkCallbackSerializer_Term()
extern void AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_Term_mF0171698CFE3CCF040E9AD3FDA61337EC5B4205F (void);
// 0x0000087F System.IntPtr AkSoundEnginePINVOKE::CSharp_AkCallbackSerializer_Lock()
extern void AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_Lock_mF2341C3D62E6AC230E1F44D3AE71BBE2E9FD3A2E (void);
// 0x00000880 System.Void AkSoundEnginePINVOKE::CSharp_AkCallbackSerializer_Unlock()
extern void AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_Unlock_mDC1339010C4F254C3E3585AB418FFD270FD95D2A (void);
// 0x00000881 System.Void AkSoundEnginePINVOKE::CSharp_AkCallbackSerializer_SetLocalOutput(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_SetLocalOutput_mB66048FFB5A6264CC8E78D941225FD24508F485B (void);
// 0x00000882 System.Int32 AkSoundEnginePINVOKE::CSharp_AkCallbackSerializer_AudioSourceChangeCallbackFunc(System.Boolean,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_AudioSourceChangeCallbackFunc_m3A446B8FA6B77DFCC8222245E757322BBF077C4A (void);
// 0x00000883 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkCallbackSerializer()
extern void AkSoundEnginePINVOKE_CSharp_new_AkCallbackSerializer_mF84DB82CD6089C13DC9BB0EEE24C04C4E5C839E6 (void);
// 0x00000884 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkCallbackSerializer(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkCallbackSerializer_m278D8285E95264CA99FA36DDC28ADE10F3F786C2 (void);
// 0x00000885 System.Int32 AkSoundEnginePINVOKE::CSharp_PostCode__SWIG_0(System.Int32,System.Int32,System.UInt32,System.UInt64,System.UInt32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_0_mC5E43ED1A61911C6BBB3205E784E615663DB3D80 (void);
// 0x00000886 System.Int32 AkSoundEnginePINVOKE::CSharp_PostCode__SWIG_1(System.Int32,System.Int32,System.UInt32,System.UInt64,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_1_mD5202D476E3E7F9FF79F5AA3A5DDCF44FE98656F (void);
// 0x00000887 System.Int32 AkSoundEnginePINVOKE::CSharp_PostCode__SWIG_2(System.Int32,System.Int32,System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_2_m84CBFCC1E5D6EE6B9AB8B2DD56EC29EF10D1B33B (void);
// 0x00000888 System.Int32 AkSoundEnginePINVOKE::CSharp_PostCode__SWIG_3(System.Int32,System.Int32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_3_m927FF6AB9054B22B2852848CA383D8ED594DD05D (void);
// 0x00000889 System.Int32 AkSoundEnginePINVOKE::CSharp_PostCode__SWIG_4(System.Int32,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_4_mC9B2F3F42C12CE06FC34C1ADA3D4A653690072F0 (void);
// 0x0000088A System.Int32 AkSoundEnginePINVOKE::CSharp_PostString__SWIG_0(System.String,System.Int32,System.UInt32,System.UInt64,System.UInt32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_PostString__SWIG_0_m1479489703B2B1349A2CE97F8183A9E7FC643BC2 (void);
// 0x0000088B System.Int32 AkSoundEnginePINVOKE::CSharp_PostString__SWIG_1(System.String,System.Int32,System.UInt32,System.UInt64,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PostString__SWIG_1_mF366464D4D6A8C6D119E983E7E60D59D38CBA8B4 (void);
// 0x0000088C System.Int32 AkSoundEnginePINVOKE::CSharp_PostString__SWIG_2(System.String,System.Int32,System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_PostString__SWIG_2_m8C249D7651153DBBBC08BE8D3AD2F6FB09D3D2B9 (void);
// 0x0000088D System.Int32 AkSoundEnginePINVOKE::CSharp_PostString__SWIG_3(System.String,System.Int32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PostString__SWIG_3_mF1C867EDDDECD637BE0A8037924692D5612B717F (void);
// 0x0000088E System.Int32 AkSoundEnginePINVOKE::CSharp_PostString__SWIG_4(System.String,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_PostString__SWIG_4_mCCE2A2562D4C285D93CCA3F9A8C13671A4EA6495 (void);
// 0x0000088F System.Int32 AkSoundEnginePINVOKE::CSharp_GetTimeStamp()
extern void AkSoundEnginePINVOKE_CSharp_GetTimeStamp_m772FC717D04686CA270F3407EB98767E28806B5E (void);
// 0x00000890 System.Void AkSoundEnginePINVOKE::CSharp_MonitorStreamMgrInit(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_MonitorStreamMgrInit_m68317B41FB009CE07EBFC93B26C0F311CB84CCC5 (void);
// 0x00000891 System.Void AkSoundEnginePINVOKE::CSharp_MonitorStreamingDeviceInit(System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_MonitorStreamingDeviceInit_mF2BB3CB07C1E923D8C83C6CDE79A4451DB0DF037 (void);
// 0x00000892 System.Void AkSoundEnginePINVOKE::CSharp_MonitorStreamingDeviceDestroyed(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_MonitorStreamingDeviceDestroyed_m4FE8A1C8031D38CAA7F371089C5C0DEDEA2708D5 (void);
// 0x00000893 System.Void AkSoundEnginePINVOKE::CSharp_MonitorStreamMgrTerm()
extern void AkSoundEnginePINVOKE_CSharp_MonitorStreamMgrTerm_mBA5A54551A13D642222ADEDD37407AF58352432C (void);
// 0x00000894 System.UInt32 AkSoundEnginePINVOKE::CSharp_GetNumNonZeroBits(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_GetNumNonZeroBits_mB7FC6CFE390FC5E4ED9DEB9C2194538E400A241F (void);
// 0x00000895 System.UInt32 AkSoundEnginePINVOKE::CSharp_GetNextPowerOfTwo(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_GetNextPowerOfTwo_m79662C048F357EB815C5BDEDBF76083F02223E4F (void);
// 0x00000896 System.UInt32 AkSoundEnginePINVOKE::CSharp_ROTL32(System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ROTL32_mBBC4670095BE5F0B9F4C275AC3FD9F7E1B2A587B (void);
// 0x00000897 System.UInt64 AkSoundEnginePINVOKE::CSharp_ROTL64(System.UInt64,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_ROTL64_m490201DE6AA2EEC6EBD6575002C7FF661B2E1FCB (void);
// 0x00000898 System.Void AkSoundEnginePINVOKE::CSharp_AkGetDefaultHighPriorityThreadProperties(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkGetDefaultHighPriorityThreadProperties_m9E72CD34732D54FCF66C5636849419F05C482DC6 (void);
// 0x00000899 System.UInt32 AkSoundEnginePINVOKE::CSharp_ResolveDialogueEvent__SWIG_0(System.UInt32,System.UInt32[],System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ResolveDialogueEvent__SWIG_0_mB108B761502D4357459C80FF4ECBB181B7E80989 (void);
// 0x0000089A System.UInt32 AkSoundEnginePINVOKE::CSharp_ResolveDialogueEvent__SWIG_1(System.UInt32,System.UInt32[],System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ResolveDialogueEvent__SWIG_1_mC675A5C349E47353CEDE89FA2D837A1F0D995C23 (void);
// 0x0000089B System.Int32 AkSoundEnginePINVOKE::CSharp_GetDialogueEventCustomPropertyValue__SWIG_0(System.UInt32,System.UInt32,System.Int32&)
extern void AkSoundEnginePINVOKE_CSharp_GetDialogueEventCustomPropertyValue__SWIG_0_mA15F45A2973B43D132BDDB19B426DC20D36F6D9D (void);
// 0x0000089C System.Int32 AkSoundEnginePINVOKE::CSharp_GetDialogueEventCustomPropertyValue__SWIG_1(System.UInt32,System.UInt32,System.Single&)
extern void AkSoundEnginePINVOKE_CSharp_GetDialogueEventCustomPropertyValue__SWIG_1_m967CEE9A1B51E9B2411AEF0CA36FAB85546BE258 (void);
// 0x0000089D System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fCenterPct_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fCenterPct_set_mA7C88FE401BC97ACEEA5A21A2B54E88128B74F64 (void);
// 0x0000089E System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fCenterPct_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fCenterPct_get_mA34EF617E0E211C568BBC82808433DC9E09EE6E1 (void);
// 0x0000089F System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_pannerType_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_pannerType_set_m8B770E3C2EAB279ACBD3D2C7C00CA7F6B9EBC39D (void);
// 0x000008A0 System.Int32 AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_pannerType_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_pannerType_get_m4D8C209A73F46258812D55B51FA5F87F63BB6FA2 (void);
// 0x000008A1 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_e3dPositioningType_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_e3dPositioningType_set_mE122A56AC9200628C70C559A08AE8873A7BD849A (void);
// 0x000008A2 System.Int32 AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_e3dPositioningType_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_e3dPositioningType_get_mAC43745A85B812CEAF8727E5183EEE12AF22EC7C (void);
// 0x000008A3 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_bHoldEmitterPosAndOrient_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bHoldEmitterPosAndOrient_set_m61739BE3BB14E39508926C1CCF2FED5B91D53449 (void);
// 0x000008A4 System.Boolean AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_bHoldEmitterPosAndOrient_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bHoldEmitterPosAndOrient_get_m2DADB9D7F32968E6C196E4425883978258B65338 (void);
// 0x000008A5 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_e3DSpatializationMode_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_e3DSpatializationMode_set_m174D3BB8CD54E55190C891FBAF0C46FBA482A02B (void);
// 0x000008A6 System.Int32 AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_e3DSpatializationMode_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_e3DSpatializationMode_get_m6AE2927F60B8E03C099A8E689F375D43C0F9368C (void);
// 0x000008A7 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_bEnableAttenuation_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bEnableAttenuation_set_m42118CC31BD3498C99F3265FD19DE679FD488B53 (void);
// 0x000008A8 System.Boolean AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_bEnableAttenuation_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bEnableAttenuation_get_mBA0BE2BDD6B2DE1611D5710FE8346D7BF082C85F (void);
// 0x000008A9 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_bUseConeAttenuation_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bUseConeAttenuation_set_m8E5B47924567A065C331F5517045A069DD11FB86 (void);
// 0x000008AA System.Boolean AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_bUseConeAttenuation_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bUseConeAttenuation_get_mD3F14BD7FD7F428F875AF124BF6EAD6A1AB1E899 (void);
// 0x000008AB System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fInnerAngle_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fInnerAngle_set_mDF36C07A2A87ED7A3CAFD94C80664B6246F97F9E (void);
// 0x000008AC System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fInnerAngle_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fInnerAngle_get_mC4876B838FCB9917B697AFA1C5D8274F6B9521CE (void);
// 0x000008AD System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fOuterAngle_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fOuterAngle_set_m0FD82AC6656B20D9E2BEAFC9BE2B901004503BF9 (void);
// 0x000008AE System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fOuterAngle_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fOuterAngle_get_m6A7E7D40F32FEC07A28BAB5377647F4DB8E48B69 (void);
// 0x000008AF System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fConeMaxAttenuation_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fConeMaxAttenuation_set_m84D5430D1A01979F5D9DFD2B9C09DB1DD8D03801 (void);
// 0x000008B0 System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fConeMaxAttenuation_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fConeMaxAttenuation_get_mE1570D943276969C242E552673B5F730865C5A02 (void);
// 0x000008B1 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_LPFCone_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_LPFCone_set_m9EB186FC208BF1A755FD4362243BFBB145E2195A (void);
// 0x000008B2 System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_LPFCone_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_LPFCone_get_m93B5FEF056F31354AEED103A3974F7C4F98489C3 (void);
// 0x000008B3 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_HPFCone_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_HPFCone_set_mD03D463A1F0329441102D2631D8661A34ABF9267 (void);
// 0x000008B4 System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_HPFCone_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_HPFCone_get_m0E9EEC1FAF3BDA0086747F5CE5A39830CEF3F2B9 (void);
// 0x000008B5 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fMaxDistance_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fMaxDistance_set_m1EBE1FD34160C09E6060FA4C82A931BF87F3A36E (void);
// 0x000008B6 System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fMaxDistance_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fMaxDistance_get_mC9F2023C17C3549D5A69DFF5B8B73811D4151B5E (void);
// 0x000008B7 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fVolDryAtMaxDist_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolDryAtMaxDist_set_mB7EFFC03A89C08BC567B3C8A33C7B90F215CA622 (void);
// 0x000008B8 System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fVolDryAtMaxDist_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolDryAtMaxDist_get_m260DE814B6271245E802D63D1E76DA97DEE840A6 (void);
// 0x000008B9 System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fVolAuxGameDefAtMaxDist_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolAuxGameDefAtMaxDist_set_m8EED39C41269F39D9B9D7DD20B42B15C0322D89B (void);
// 0x000008BA System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fVolAuxGameDefAtMaxDist_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolAuxGameDefAtMaxDist_get_m0F785313D04C2BE2F5C591BF61BCD8F4022227BE (void);
// 0x000008BB System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fVolAuxUserDefAtMaxDist_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolAuxUserDefAtMaxDist_set_m32264130F87187FAC72071BECF0C5B301177FA09 (void);
// 0x000008BC System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_fVolAuxUserDefAtMaxDist_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolAuxUserDefAtMaxDist_get_m33EF52DC5147A88C491AFCF7256F1360EEF523D4 (void);
// 0x000008BD System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_LPFValueAtMaxDist_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_LPFValueAtMaxDist_set_mAA3390C1053F0509CC71EC432D7E2417FF1359E9 (void);
// 0x000008BE System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_LPFValueAtMaxDist_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_LPFValueAtMaxDist_get_m7EDBC358EFCCC00B9827A4D2ED6AE28B016C6DCA (void);
// 0x000008BF System.Void AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_HPFValueAtMaxDist_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_HPFValueAtMaxDist_set_mA801D79C8A35D73222AE53CF9B65E453932A1D2A (void);
// 0x000008C0 System.Single AkSoundEnginePINVOKE::CSharp_AkPositioningInfo_HPFValueAtMaxDist_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_HPFValueAtMaxDist_get_m19071995DF542EB69A930858470E3731730AA6D7 (void);
// 0x000008C1 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkPositioningInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkPositioningInfo_mA319ACC1FFE5497EECF95F27A7B29F5F59E05FE1 (void);
// 0x000008C2 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkPositioningInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkPositioningInfo_m328FCEAB409BE9EC3D19D35AEFE842C2C94DCC6C (void);
// 0x000008C3 System.Void AkSoundEnginePINVOKE::CSharp_AkObjectInfo_objID_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkObjectInfo_objID_set_mFDB67DA7E86442339DD53345623EB1DB6F413277 (void);
// 0x000008C4 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkObjectInfo_objID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkObjectInfo_objID_get_mB3AA85C9B50E7968EE0AC8346637FE4813A47ED1 (void);
// 0x000008C5 System.Void AkSoundEnginePINVOKE::CSharp_AkObjectInfo_parentID_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkObjectInfo_parentID_set_mD54DB58305065D1DC63DF66008E1E567A2B60960 (void);
// 0x000008C6 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkObjectInfo_parentID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkObjectInfo_parentID_get_m00384DE821470FE80D3A77B245658188BF1AE3D2 (void);
// 0x000008C7 System.Void AkSoundEnginePINVOKE::CSharp_AkObjectInfo_iDepth_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkObjectInfo_iDepth_set_m3AA94DFCE04F0F4C6A4A9D03AA5D519739BA7348 (void);
// 0x000008C8 System.Int32 AkSoundEnginePINVOKE::CSharp_AkObjectInfo_iDepth_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkObjectInfo_iDepth_get_m3845EB8342F431B1E7404D8DF3943059D62C2D87 (void);
// 0x000008C9 System.Void AkSoundEnginePINVOKE::CSharp_AkObjectInfo_Clear(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkObjectInfo_Clear_m0337C80CA59E7DDF1E940CA55FE1B78FA2D89C5B (void);
// 0x000008CA System.Int32 AkSoundEnginePINVOKE::CSharp_AkObjectInfo_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkObjectInfo_GetSizeOf_m34258A7608E5568BE7AED7D556138E0EF37F472F (void);
// 0x000008CB System.Void AkSoundEnginePINVOKE::CSharp_AkObjectInfo_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkObjectInfo_Clone_mD0246C1517BA4A78503BDA8DCA078EE07F99F6FD (void);
// 0x000008CC System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkObjectInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkObjectInfo_mE3A23EBECEAB2021BE957AF6E69CA28674EA2F89 (void);
// 0x000008CD System.Void AkSoundEnginePINVOKE::CSharp_delete_AkObjectInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkObjectInfo_m285444E109DD8B0FD5EE6A6C1FF6370046453BB7 (void);
// 0x000008CE System.Int32 AkSoundEnginePINVOKE::CSharp_GetPosition(System.UInt64,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetPosition_mC39BCD7A8D456C23F862A6D8060EEE908081F2ED (void);
// 0x000008CF System.Int32 AkSoundEnginePINVOKE::CSharp_GetListenerPosition(System.UInt64,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetListenerPosition_m6614DBF7F8E88D7FCBBE21F5FE72715A0AE5B97B (void);
// 0x000008D0 System.Int32 AkSoundEnginePINVOKE::CSharp_GetRTPCValue__SWIG_0(System.UInt32,System.UInt64,System.UInt32,System.Single&,System.Int32&)
extern void AkSoundEnginePINVOKE_CSharp_GetRTPCValue__SWIG_0_m76576C86AD77E31B4079D67125F77E2492D20398 (void);
// 0x000008D1 System.Int32 AkSoundEnginePINVOKE::CSharp_GetRTPCValue__SWIG_1(System.String,System.UInt64,System.UInt32,System.Single&,System.Int32&)
extern void AkSoundEnginePINVOKE_CSharp_GetRTPCValue__SWIG_1_m3C1238F84D68BB1F521FE6AB27969BEE314EC157 (void);
// 0x000008D2 System.Int32 AkSoundEnginePINVOKE::CSharp_GetSwitch__SWIG_0(System.UInt32,System.UInt64,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_GetSwitch__SWIG_0_m088536208719C3B462E1243845E97ED28830061C (void);
// 0x000008D3 System.Int32 AkSoundEnginePINVOKE::CSharp_GetSwitch__SWIG_1(System.String,System.UInt64,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_GetSwitch__SWIG_1_m5E65011F8084B1E1F679A7E5D88D23C5B6716EAB (void);
// 0x000008D4 System.Int32 AkSoundEnginePINVOKE::CSharp_GetState__SWIG_0(System.UInt32,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_GetState__SWIG_0_m46F5C162BF4A449269B9A942A7ECCD33EE0004DB (void);
// 0x000008D5 System.Int32 AkSoundEnginePINVOKE::CSharp_GetState__SWIG_1(System.String,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_GetState__SWIG_1_m6CEF665E33F314DC597223AAB6211DB0AF6E5E19 (void);
// 0x000008D6 System.Int32 AkSoundEnginePINVOKE::CSharp_GetGameObjectAuxSendValues(System.UInt64,System.IntPtr,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_GetGameObjectAuxSendValues_mD90B4E205016417C5AA760ED12C9A9D33988493F (void);
// 0x000008D7 System.Int32 AkSoundEnginePINVOKE::CSharp_GetGameObjectDryLevelValue(System.UInt64,System.UInt64,System.Single&)
extern void AkSoundEnginePINVOKE_CSharp_GetGameObjectDryLevelValue_mC1F1E854E09BFB9E72E719BAE3E296D0C379EAF7 (void);
// 0x000008D8 System.Int32 AkSoundEnginePINVOKE::CSharp_GetObjectObstructionAndOcclusion(System.UInt64,System.UInt64,System.Single&,System.Single&)
extern void AkSoundEnginePINVOKE_CSharp_GetObjectObstructionAndOcclusion_m23BB6CC46E2AD115804AAC01D3A8BD4BE0451FF3 (void);
// 0x000008D9 System.Int32 AkSoundEnginePINVOKE::CSharp_QueryAudioObjectIDs__SWIG_0(System.UInt32,System.UInt32&,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_QueryAudioObjectIDs__SWIG_0_mDB31A1FFFBDEE7FAF538C5FD8A79C639CE20A998 (void);
// 0x000008DA System.Int32 AkSoundEnginePINVOKE::CSharp_QueryAudioObjectIDs__SWIG_1(System.String,System.UInt32&,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_QueryAudioObjectIDs__SWIG_1_m07CCF5CAC3C23B4EAFEA04DADD2FC3BD36C3B7D5 (void);
// 0x000008DB System.Int32 AkSoundEnginePINVOKE::CSharp_GetPositioningInfo(System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetPositioningInfo_m90D3A3B31E37EF1CB00C7A76D3BCD398CFF72AB7 (void);
// 0x000008DC System.Boolean AkSoundEnginePINVOKE::CSharp_GetIsGameObjectActive(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_GetIsGameObjectActive_m55613DE2C37683F29EB52BD4A0DDCC1B1219613E (void);
// 0x000008DD System.Single AkSoundEnginePINVOKE::CSharp_GetMaxRadius(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_GetMaxRadius_m7FF94E96ACBAD994AAD619DF6CE918D55D0E435F (void);
// 0x000008DE System.UInt32 AkSoundEnginePINVOKE::CSharp_GetEventIDFromPlayingID(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_GetEventIDFromPlayingID_m4C5B67D1639004BBA7E4196B644F4AD375726E71 (void);
// 0x000008DF System.UInt64 AkSoundEnginePINVOKE::CSharp_GetGameObjectFromPlayingID(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_GetGameObjectFromPlayingID_mDEC78DCBEFCDC80E6F9863A945D14BBFFA1F5305 (void);
// 0x000008E0 System.Int32 AkSoundEnginePINVOKE::CSharp_GetPlayingIDsFromGameObject(System.UInt64,System.UInt32&,System.UInt32[])
extern void AkSoundEnginePINVOKE_CSharp_GetPlayingIDsFromGameObject_m39B5DEF97C3920410E6E1F7D197DE7256E25D7EA (void);
// 0x000008E1 System.Int32 AkSoundEnginePINVOKE::CSharp_GetCustomPropertyValue__SWIG_0(System.UInt32,System.UInt32,System.Int32&)
extern void AkSoundEnginePINVOKE_CSharp_GetCustomPropertyValue__SWIG_0_mF6E4C2D7E4FB1EA829C0F7BFE7513DC606A23AAF (void);
// 0x000008E2 System.Int32 AkSoundEnginePINVOKE::CSharp_GetCustomPropertyValue__SWIG_1(System.UInt32,System.UInt32,System.Single&)
extern void AkSoundEnginePINVOKE_CSharp_GetCustomPropertyValue__SWIG_1_mE456485F58561B1F1148085516160D5CC37D60BF (void);
// 0x000008E3 System.Void AkSoundEnginePINVOKE::CSharp_AK_SPEAKER_SETUP_FIX_LEFT_TO_CENTER(System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_AK_SPEAKER_SETUP_FIX_LEFT_TO_CENTER_m850CFD5A66D6946FC98CB1305573B6DBA0F684F6 (void);
// 0x000008E4 System.Void AkSoundEnginePINVOKE::CSharp_AK_SPEAKER_SETUP_FIX_REAR_TO_SIDE(System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_AK_SPEAKER_SETUP_FIX_REAR_TO_SIDE_mB5BB1F24224A9E90E7ED3CADB3ED50F2E7095EB2 (void);
// 0x000008E5 System.Void AkSoundEnginePINVOKE::CSharp_AK_SPEAKER_SETUP_CONVERT_TO_SUPPORTED(System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_AK_SPEAKER_SETUP_CONVERT_TO_SUPPORTED_m663CAB3AF095D4BC34D818E134330D841F8C63C5 (void);
// 0x000008E6 System.Byte AkSoundEnginePINVOKE::CSharp_ChannelMaskToNumChannels(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ChannelMaskToNumChannels_m623FB2DFD860D62C08A614E4468504C853CF683B (void);
// 0x000008E7 System.UInt32 AkSoundEnginePINVOKE::CSharp_ChannelMaskFromNumChannels(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ChannelMaskFromNumChannels_m3633CC1B01EC7C52A0B87B42E9CC226080898C1F (void);
// 0x000008E8 System.Byte AkSoundEnginePINVOKE::CSharp_ChannelBitToIndex(System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ChannelBitToIndex_mCB9A64AFA3FCF62008EB788F47D5238F492744D5 (void);
// 0x000008E9 System.Boolean AkSoundEnginePINVOKE::CSharp_HasSurroundChannels(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_HasSurroundChannels_m733A02D081B2B0D905FD989C18A4D3E2874F7DAC (void);
// 0x000008EA System.Boolean AkSoundEnginePINVOKE::CSharp_HasStrictlyOnePairOfSurroundChannels(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_HasStrictlyOnePairOfSurroundChannels_m00C48FA757067D23B6F3013942179841AEDA5AC5 (void);
// 0x000008EB System.Boolean AkSoundEnginePINVOKE::CSharp_HasSideAndRearChannels(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_HasSideAndRearChannels_mF5A03E7D0C1EFC00FA25F91E21FC28D08FF5A9A2 (void);
// 0x000008EC System.Boolean AkSoundEnginePINVOKE::CSharp_HasHeightChannels(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_HasHeightChannels_m46A4893ED73D1E2DA57887DDD6D3C2A5FC677072 (void);
// 0x000008ED System.UInt32 AkSoundEnginePINVOKE::CSharp_BackToSideChannels(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_BackToSideChannels_mD7BA9DD062575C60B601A9536B0E1F0440AB59D1 (void);
// 0x000008EE System.UInt32 AkSoundEnginePINVOKE::CSharp_StdChannelIndexToDisplayIndex(System.Int32,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_StdChannelIndexToDisplayIndex_m42D969B7F77B9CE9D920635EBF7A7212ED4CE9C7 (void);
// 0x000008EF System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_uNumChannels_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_uNumChannels_set_mB4DA8FB38024C684F31AAE57337B2663BBEF1A8C (void);
// 0x000008F0 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkChannelConfig_uNumChannels_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_uNumChannels_get_mB0F3FDE40932C5F25FB91EEF1D81FEDE41A1247C (void);
// 0x000008F1 System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_eConfigType_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_eConfigType_set_m356AE8360470E856E4988232C0FAFE0D5B751261 (void);
// 0x000008F2 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkChannelConfig_eConfigType_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_eConfigType_get_mA33BA699C22CB4AFA569BD674A85933071F0954C (void);
// 0x000008F3 System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_uChannelMask_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_uChannelMask_set_m3413FCA33CE3F0B2DBFAC6ED8E20E08D9FA1F5EB (void);
// 0x000008F4 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkChannelConfig_uChannelMask_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_uChannelMask_get_m41300A21173D586584A0D1044F357F6E5651E1F5 (void);
// 0x000008F5 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkChannelConfig__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkChannelConfig__SWIG_0_m24897E360C4F9388502975F63AD73DD8CE4439F2 (void);
// 0x000008F6 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkChannelConfig__SWIG_1(System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_new_AkChannelConfig__SWIG_1_m9C129DB8C42043B320C291E57C6D17E2E97ACF64 (void);
// 0x000008F7 System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_Clear(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_Clear_mC6D1778DE625EDF94FBE7A331974EAE8AA56A25D (void);
// 0x000008F8 System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_SetStandard(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetStandard_mBC5AC12D93479FB9751BD078E7BCBD375E306807 (void);
// 0x000008F9 System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_SetStandardOrAnonymous(System.IntPtr,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetStandardOrAnonymous_m7F170DC697FA5DD5803DF88C4CD3058367EF578C (void);
// 0x000008FA System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_SetAnonymous(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetAnonymous_mCEBD41600AAF06563FD9F15E706E236FDD772F15 (void);
// 0x000008FB System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_SetAmbisonic(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetAmbisonic_m91F3D6BEE9AD409F0F0A1383ECA287293AD83049 (void);
// 0x000008FC System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_SetObject(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetObject_mA8A5CA1BD56AA109486CD181CCAC0BEE385C2D55 (void);
// 0x000008FD System.Boolean AkSoundEnginePINVOKE::CSharp_AkChannelConfig_IsValid(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_IsValid_mAA59DB0549429D720DDBD8A6B0A697E6A68C69D3 (void);
// 0x000008FE System.UInt32 AkSoundEnginePINVOKE::CSharp_AkChannelConfig_Serialize(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_Serialize_m0B836F2F96C738765CCD011CBD5ECFF4F6DA558E (void);
// 0x000008FF System.Void AkSoundEnginePINVOKE::CSharp_AkChannelConfig_Deserialize(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_Deserialize_m5AF6760E273FAF6605BE3EC35FA845535265E1BA (void);
// 0x00000900 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkChannelConfig_RemoveLFE(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_RemoveLFE_mC598D3C8A11A22E4527D58E0380946C04F40AAB2 (void);
// 0x00000901 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkChannelConfig_RemoveCenter(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkChannelConfig_RemoveCenter_m35336BB500314A79EDD8CB0C281E2E981013F50F (void);
// 0x00000902 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkChannelConfig(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkChannelConfig_m9DB5C4CECBAC1BD5381FEEE89EE48BFAC338CEDA (void);
// 0x00000903 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkImageSourceParams__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkImageSourceParams__SWIG_0_m03F047DDF379F73D0513AEDD0C8F10D61FED21C0 (void);
// 0x00000904 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkImageSourceParams__SWIG_1(UnityEngine.Vector3,System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_new_AkImageSourceParams__SWIG_1_mCD835F81C2C106C3215962A038189486F2F811D8 (void);
// 0x00000905 System.Void AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_sourcePosition_set(System.IntPtr,UnityEngine.Vector3)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_sourcePosition_set_m42BB6ECC162693EF1A07ACF883F50DD33F4794F5 (void);
// 0x00000906 UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_sourcePosition_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_sourcePosition_get_m73E680C873ED5444D717A141EEE905547BBC8866 (void);
// 0x00000907 System.Void AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_fDistanceScalingFactor_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fDistanceScalingFactor_set_m5D5502220CF3658893FAF74A7C77AD212CCCCBD3 (void);
// 0x00000908 System.Single AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_fDistanceScalingFactor_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fDistanceScalingFactor_get_m9DDB70C0D411B9E8D1FFE0ABCF9DF8C8D3BFCC8F (void);
// 0x00000909 System.Void AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_fLevel_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fLevel_set_m216E7A9868B2C8D88557ADAC34F270B13ACF4B79 (void);
// 0x0000090A System.Single AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_fLevel_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fLevel_get_m326CD11846B10846067BC05BDE970E10A9BE64B9 (void);
// 0x0000090B System.Void AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_fDiffraction_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fDiffraction_set_m080BE0BCA57892468286828402F666BEC37BFA8E (void);
// 0x0000090C System.Single AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_fDiffraction_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fDiffraction_get_m0A977AF100EC17E66305A05A064BD74D635308D5 (void);
// 0x0000090D System.Void AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_uDiffractionEmitterSide_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_uDiffractionEmitterSide_set_m5DA39DDCD185C1BA2399E1F8A27D962E51D5A5F0 (void);
// 0x0000090E System.Byte AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_uDiffractionEmitterSide_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_uDiffractionEmitterSide_get_m6AAC90318170AC21D6FB00FECBCB2C24D73A627D (void);
// 0x0000090F System.Void AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_uDiffractionListenerSide_set(System.IntPtr,System.Byte)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_uDiffractionListenerSide_set_mF53C68D9B07EBF6FB67DA84E6651B9FE5BA5B0F0 (void);
// 0x00000910 System.Byte AkSoundEnginePINVOKE::CSharp_AkImageSourceParams_uDiffractionListenerSide_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_uDiffractionListenerSide_get_mBE93C135752D3B8BA8D751600774DF874F2C8747 (void);
// 0x00000911 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkImageSourceParams(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkImageSourceParams_mEBE7F5547A81E11E9E85A266B60ABCFE61B33797 (void);
// 0x00000912 System.Single AkSoundEnginePINVOKE::CSharp_kDefaultMaxPathLength_get()
extern void AkSoundEnginePINVOKE_CSharp_kDefaultMaxPathLength_get_m398B35F49C6E7D10ADF35A8E46FB0CD49C4328F5 (void);
// 0x00000913 System.UInt32 AkSoundEnginePINVOKE::CSharp_kDefaultDiffractionMaxEdges_get()
extern void AkSoundEnginePINVOKE_CSharp_kDefaultDiffractionMaxEdges_get_m6E265261E260BE50EAF288276033880C3DE21C13 (void);
// 0x00000914 System.UInt32 AkSoundEnginePINVOKE::CSharp_kDefaultDiffractionMaxPaths_get()
extern void AkSoundEnginePINVOKE_CSharp_kDefaultDiffractionMaxPaths_get_m8E8483065ABBC9679054B19093004B747B827BF3 (void);
// 0x00000915 System.Single AkSoundEnginePINVOKE::CSharp_kMaxDiffraction_get()
extern void AkSoundEnginePINVOKE_CSharp_kMaxDiffraction_get_mFDD2E532255F4C5464A0F87BC4BC0B06FA36131C (void);
// 0x00000916 System.UInt32 AkSoundEnginePINVOKE::CSharp_kDiffractionMaxEdges_get()
extern void AkSoundEnginePINVOKE_CSharp_kDiffractionMaxEdges_get_m756885408A7FBBAE539A312EBD81108FF3CF2C7C (void);
// 0x00000917 System.UInt32 AkSoundEnginePINVOKE::CSharp_kDiffractionMaxPaths_get()
extern void AkSoundEnginePINVOKE_CSharp_kDiffractionMaxPaths_get_m965154082477C762D4AF2DFF489847A69EF78A74 (void);
// 0x00000918 System.UInt32 AkSoundEnginePINVOKE::CSharp_kPortalToPortalDiffractionMaxPaths_get()
extern void AkSoundEnginePINVOKE_CSharp_kPortalToPortalDiffractionMaxPaths_get_mC888764C072834A41E9728569C4D3D0774B40170 (void);
// 0x00000919 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkSpatialAudioInitSettings()
extern void AkSoundEnginePINVOKE_CSharp_new_AkSpatialAudioInitSettings_m29E15D5330E3531CC76573E6D1A02E1A7904E2DB (void);
// 0x0000091A System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_uMaxSoundPropagationDepth_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uMaxSoundPropagationDepth_set_m1A7298FB213458A44EA960C4E42D09FBD48F78FF (void);
// 0x0000091B System.UInt32 AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_uMaxSoundPropagationDepth_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uMaxSoundPropagationDepth_get_mBC593B6840A1DA5906E1AA10A4C90683096DDF93 (void);
// 0x0000091C System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_fMovementThreshold_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fMovementThreshold_set_m32B47005F02A004CC4B002C19408415E15B2AA67 (void);
// 0x0000091D System.Single AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_fMovementThreshold_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fMovementThreshold_get_mB13E5AFCEEF0746DFEED6AF048B14FB2D9BD711E (void);
// 0x0000091E System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_uNumberOfPrimaryRays_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uNumberOfPrimaryRays_set_mE3CDCAF67B07B586C5953B6D4BEF57AD800D65CF (void);
// 0x0000091F System.UInt32 AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_uNumberOfPrimaryRays_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uNumberOfPrimaryRays_get_m6C4B011AEB7A865BADAEC208C4E2166D15CB17EE (void);
// 0x00000920 System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_uMaxReflectionOrder_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uMaxReflectionOrder_set_mB65CA8E4C4433A290CE08E4A537F4A261FB11CAB (void);
// 0x00000921 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_uMaxReflectionOrder_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uMaxReflectionOrder_get_m01D2AFECBF9B1DB74A57A1A37D1BF25E43DDCE64 (void);
// 0x00000922 System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_fMaxPathLength_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fMaxPathLength_set_m7C5C5E1D2F5609254ECBB2D03A31F7D64442ABB2 (void);
// 0x00000923 System.Single AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_fMaxPathLength_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fMaxPathLength_get_m2E230F9029C7DB5E6E367FBBE0B4509425CC232D (void);
// 0x00000924 System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_fCPULimitPercentage_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fCPULimitPercentage_set_m2F53E27C6D0934B31AA92C2535E653B00D5B556C (void);
// 0x00000925 System.Single AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_fCPULimitPercentage_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fCPULimitPercentage_get_mD98A958FEFDF8B6DCBC9E8A317F79D762866EF26 (void);
// 0x00000926 System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bEnableDiffractionOnReflection_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bEnableDiffractionOnReflection_set_mBCB34454FAACA8281544BDA781D5D0FD029AB8CA (void);
// 0x00000927 System.Boolean AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bEnableDiffractionOnReflection_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bEnableDiffractionOnReflection_get_mB866EF496ED1813DD57BB88597CC107B36B2AC83 (void);
// 0x00000928 System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bEnableGeometricDiffractionAndTransmission_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bEnableGeometricDiffractionAndTransmission_set_mF9BDBC8DB3141368B8923EA443903B691184AD6F (void);
// 0x00000929 System.Boolean AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bEnableGeometricDiffractionAndTransmission_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bEnableGeometricDiffractionAndTransmission_get_mFFC4C6FBAA331043E72BDC7E6950995CCC669691 (void);
// 0x0000092A System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bCalcEmitterVirtualPosition_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bCalcEmitterVirtualPosition_set_mC25CD67C4CC8A38C05D3105C9BDD09051E4A3202 (void);
// 0x0000092B System.Boolean AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bCalcEmitterVirtualPosition_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bCalcEmitterVirtualPosition_get_mD83EC7DB2FD2A90774B0CE58F49136887A486955 (void);
// 0x0000092C System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bUseObstruction_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bUseObstruction_set_mB38D0DEA92AE0D4E3FD7C1B30685C836483F663A (void);
// 0x0000092D System.Boolean AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bUseObstruction_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bUseObstruction_get_mDE2C96F5187A73093C89B920FEB34F734E7DE5A8 (void);
// 0x0000092E System.Void AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bUseOcclusion_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bUseOcclusion_set_m96178A3922A7571900F26093AA8480D1FD512F60 (void);
// 0x0000092F System.Boolean AkSoundEnginePINVOKE::CSharp_AkSpatialAudioInitSettings_bUseOcclusion_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bUseOcclusion_get_m1D6C367F89BA3A776C34177981F2BF2CD68FBB84 (void);
// 0x00000930 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkSpatialAudioInitSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkSpatialAudioInitSettings_m9444AED8922099F8E916E2A93695AA23D0BBFF20 (void);
// 0x00000931 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkImageSourceSettings__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkImageSourceSettings__SWIG_0_m66C0D0E8E98115DDB8FA43B4F5E7E6B4D388E945 (void);
// 0x00000932 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkImageSourceSettings__SWIG_1(UnityEngine.Vector3,System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_new_AkImageSourceSettings__SWIG_1_mD55B0516D9550649912D72D2A3A1B6E69BFC310D (void);
// 0x00000933 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkImageSourceSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkImageSourceSettings_mFB8BB4478E4B9E8776C9AF9C8C70B80C98018777 (void);
// 0x00000934 System.Void AkSoundEnginePINVOKE::CSharp_AkImageSourceSettings_SetOneTexture(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceSettings_SetOneTexture_mD2FF656F32F801C349F7328EAEBF5D61F2C25AE9 (void);
// 0x00000935 System.Void AkSoundEnginePINVOKE::CSharp_AkImageSourceSettings_SetName(System.IntPtr,System.String)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceSettings_SetName_m4F9943373583D251C9374F84BF6EE375BB430A55 (void);
// 0x00000936 System.Void AkSoundEnginePINVOKE::CSharp_AkImageSourceSettings_params__set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceSettings_params__set_mF0CD88DE0E8AC7FF3CDC0F463695DFE714F55FC0 (void);
// 0x00000937 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkImageSourceSettings_params__get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkImageSourceSettings_params__get_mA14717004E08E1E2E4173A5B140C820591D75F8E (void);
// 0x00000938 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkExtent__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkExtent__SWIG_0_m0E653D2B633EAFBC8814DAA5503CE4486F06132B (void);
// 0x00000939 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkExtent__SWIG_1(System.Single,System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_new_AkExtent__SWIG_1_mA6AD2ADE0EAC3EC1B1B4BBCDF59CE224EEC70507 (void);
// 0x0000093A System.Void AkSoundEnginePINVOKE::CSharp_AkExtent_halfWidth_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkExtent_halfWidth_set_m73AA7931A2673A6C6CBB7D1C842AC805DAC51E66 (void);
// 0x0000093B System.Single AkSoundEnginePINVOKE::CSharp_AkExtent_halfWidth_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExtent_halfWidth_get_mDF1EDF435065595D3E1F35C5A19756AE2B3FD22D (void);
// 0x0000093C System.Void AkSoundEnginePINVOKE::CSharp_AkExtent_halfHeight_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkExtent_halfHeight_set_mEC71DEC1C922A64BF20567AACE01D4199AACB58D (void);
// 0x0000093D System.Single AkSoundEnginePINVOKE::CSharp_AkExtent_halfHeight_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExtent_halfHeight_get_m0DFE579DFDF0ED60BF2C180C1A0030C82A486B3C (void);
// 0x0000093E System.Void AkSoundEnginePINVOKE::CSharp_AkExtent_halfDepth_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkExtent_halfDepth_set_m79E8922045145C8D8BC8AD789C1EE728EF259558 (void);
// 0x0000093F System.Single AkSoundEnginePINVOKE::CSharp_AkExtent_halfDepth_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExtent_halfDepth_get_m467FCFA7F4A875A15098BADADC6D7BB1406B7DA8 (void);
// 0x00000940 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkExtent(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkExtent_mE57FDB779C0DF80C34C8D670EFAEFB56D76A1E71 (void);
// 0x00000941 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkTriangle__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkTriangle__SWIG_0_m4E629B89867AC9A51899353485760B36740A0113 (void);
// 0x00000942 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkTriangle__SWIG_1(System.UInt16,System.UInt16,System.UInt16,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_new_AkTriangle__SWIG_1_m4571276AABB70E12F28702D1E0BE05B34C189B12 (void);
// 0x00000943 System.Void AkSoundEnginePINVOKE::CSharp_AkTriangle_point0_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_point0_set_m27BA68A7C4DDF1614637770A4D3DB8279254D002 (void);
// 0x00000944 System.UInt16 AkSoundEnginePINVOKE::CSharp_AkTriangle_point0_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_point0_get_m8484D01EC2DD2BB0502EFAB5EFAADC6CC1CB0D3F (void);
// 0x00000945 System.Void AkSoundEnginePINVOKE::CSharp_AkTriangle_point1_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_point1_set_mC62371D03AA6B18ACF6E9D3E1CFFC19AE63AEF25 (void);
// 0x00000946 System.UInt16 AkSoundEnginePINVOKE::CSharp_AkTriangle_point1_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_point1_get_m80E9706AFCCF924C23D9696FF4D58951577BB06D (void);
// 0x00000947 System.Void AkSoundEnginePINVOKE::CSharp_AkTriangle_point2_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_point2_set_m1BE85B820B2B349BDBF00A6DF0A405BAB7391184 (void);
// 0x00000948 System.UInt16 AkSoundEnginePINVOKE::CSharp_AkTriangle_point2_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_point2_get_m55B1FF16F098B17A1BE8DAE85C8F497862CA7CA0 (void);
// 0x00000949 System.Void AkSoundEnginePINVOKE::CSharp_AkTriangle_surface_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_surface_set_m5A72292CCD72AB24C144ED9698DC8FE173FE85E0 (void);
// 0x0000094A System.UInt16 AkSoundEnginePINVOKE::CSharp_AkTriangle_surface_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_surface_get_m8A617C9B8442FA0CC7FA1E25AD3CE0A480DE3FCA (void);
// 0x0000094B System.Void AkSoundEnginePINVOKE::CSharp_AkTriangle_Clear(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_Clear_m10AF5416A9A7D19C9467CA1C9847C37B0358AB49 (void);
// 0x0000094C System.Int32 AkSoundEnginePINVOKE::CSharp_AkTriangle_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_GetSizeOf_m7F5AE9B059445A7F1D1F28C1D5F2CEF5B8F5F238 (void);
// 0x0000094D System.Void AkSoundEnginePINVOKE::CSharp_AkTriangle_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkTriangle_Clone_mD26A971387BC7039CF7B59890EB875258A62CF1F (void);
// 0x0000094E System.Void AkSoundEnginePINVOKE::CSharp_delete_AkTriangle(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkTriangle_m9B957C05F0AD1AF9A4C16405E4666F679FC4C851 (void);
// 0x0000094F System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkAcousticSurface()
extern void AkSoundEnginePINVOKE_CSharp_new_AkAcousticSurface_m34106517C1334D836459BD736598118BDC39AED3 (void);
// 0x00000950 System.Void AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_textureID_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_textureID_set_mC307A635235FDBBAED617A7D6DDF93E68D773B41 (void);
// 0x00000951 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_textureID_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_textureID_get_m6F34F0D7D172D1D065B7FF0D6A90BB98842F5CDF (void);
// 0x00000952 System.Void AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_transmissionLoss_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_transmissionLoss_set_mFD45A2C4E08AB06E164E8DB59F2C6778379605A4 (void);
// 0x00000953 System.Single AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_transmissionLoss_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_transmissionLoss_get_m39953F871BA3E45953B8D432EC193720E04BF862 (void);
// 0x00000954 System.Void AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_strName_set(System.IntPtr,System.String)
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_strName_set_m8C1ADFE9C4EA79C5620F9FEF4975E4304980AE7A (void);
// 0x00000955 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_strName_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_strName_get_m1C16B55C82E316E90F12D2BA7BF8BB49458577B2 (void);
// 0x00000956 System.Void AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_Clear(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_Clear_m193357C604652192A7F733759BF1300179F844E5 (void);
// 0x00000957 System.Void AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_DeleteName(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_DeleteName_m7BC8C8EA8DB7E0941471BE5A7AF5DF46BCDFA94B (void);
// 0x00000958 System.Int32 AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_GetSizeOf_m9034A17938D421388C2563C704E9AD91826F154F (void);
// 0x00000959 System.Void AkSoundEnginePINVOKE::CSharp_AkAcousticSurface_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_Clone_m6AD430C5B86FC4098C76E0F1E11FF4D01EDFE5F6 (void);
// 0x0000095A System.Void AkSoundEnginePINVOKE::CSharp_delete_AkAcousticSurface(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkAcousticSurface_m378080FB838B70E0435DDF2CCA050DF05106136A (void);
// 0x0000095B System.Void AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_imageSource_set(System.IntPtr,UnityEngine.Vector3)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_imageSource_set_m230F6A28F8EC07D67C8E4A46EE8263699D56F99C (void);
// 0x0000095C UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_imageSource_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_imageSource_get_mC9C980B1443259F160236B8F80627DF609CD1610 (void);
// 0x0000095D System.Void AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_numPathPoints_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_numPathPoints_set_m425F780CD825D00FCB345BEAEF444669E31E4F25 (void);
// 0x0000095E System.UInt32 AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_numPathPoints_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_numPathPoints_get_m51470E8BAC751937535FC34C2563958CA25CD06B (void);
// 0x0000095F System.Void AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_numReflections_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_numReflections_set_mDEA1D964F3043F2F57D0DAB5938E831C2FB1E3B3 (void);
// 0x00000960 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_numReflections_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_numReflections_get_mED5EC0012B98621F56309064DCB39DE6E13469AB (void);
// 0x00000961 System.Void AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_level_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_level_set_m1AFBC0D7ED1F18D6E0516EADACFCAECA487172CD (void);
// 0x00000962 System.Single AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_level_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_level_get_mB0F31693FACDDDD9E548A105955B50DAE270453B (void);
// 0x00000963 System.Void AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_isOccluded_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_isOccluded_set_m6D71C70D2C464DBED93AE32776806ABB05AB535B (void);
// 0x00000964 System.Boolean AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_isOccluded_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_isOccluded_get_mF75DEF0C3D9CBD4D49F4695A25E4C336C5E8A7CE (void);
// 0x00000965 System.Int32 AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_GetSizeOf_m3CDDF861E2E9D66B015930741A4BE959B8511E21 (void);
// 0x00000966 UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_GetPathPoint(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_GetPathPoint_m535FB9AE5A2F4227F7C4D93CB8F8ACEC6AEE15C1 (void);
// 0x00000967 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_GetAcousticSurface(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_GetAcousticSurface_mE51C5523BE720957C84377502F1C86D495794788 (void);
// 0x00000968 System.Single AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_GetDiffraction(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_GetDiffraction_m164ECCFDD5C7D1FE9D61AD6D71308CA96700EDA0 (void);
// 0x00000969 System.Void AkSoundEnginePINVOKE::CSharp_AkReflectionPathInfo_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_Clone_m067F448AF471765E71FD42BF08F1FE1EC24566AA (void);
// 0x0000096A System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkReflectionPathInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkReflectionPathInfo_m65494A4F26DBD73BB727711CFE0B11FC5999F42D (void);
// 0x0000096B System.Void AkSoundEnginePINVOKE::CSharp_delete_AkReflectionPathInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkReflectionPathInfo_m0C2988F446DD2BBD856F152D2202469E2FCCB1F8 (void);
// 0x0000096C System.Void AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_emitterPos_set(System.IntPtr,UnityEngine.Vector3)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_emitterPos_set_m8F98AD84FD768B9150D5E693559F1B265A860B69 (void);
// 0x0000096D UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_emitterPos_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_emitterPos_get_mEAE8829D91A1A7739B757C6226B06C7434AC9507 (void);
// 0x0000096E System.Void AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_virtualPos_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_virtualPos_set_m497B9E44D93ECC0356B6D5CA5366E1C21F1E2406 (void);
// 0x0000096F System.IntPtr AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_virtualPos_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_virtualPos_get_mBF5AB5EF70ED3C5655584F224C4A31C09195F159 (void);
// 0x00000970 System.Void AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_nodeCount_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_nodeCount_set_mA0FDDC532EBE3E6B739BBA7EAADCE1C98BDC363D (void);
// 0x00000971 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_nodeCount_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_nodeCount_get_m1B5C9E59B991D58C9EE04713A577865CBD5DCD7D (void);
// 0x00000972 System.Void AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_diffraction_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_diffraction_set_mE5BCB9DADE5C4AC35FD197489922D25410D7E1F8 (void);
// 0x00000973 System.Single AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_diffraction_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_diffraction_get_m3D53606457791F70436D6A5CD103DDFC24A91B65 (void);
// 0x00000974 System.Void AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_transmissionLoss_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_transmissionLoss_set_m15BAD3092E860198EA79AE1356C9129958E6682A (void);
// 0x00000975 System.Single AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_transmissionLoss_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_transmissionLoss_get_mD1A214494417BF1D95C40BC30304A99AF90858DC (void);
// 0x00000976 System.Void AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_totLength_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_totLength_set_m04276D01AF68DBCC5F9D0882383DCA0437D0AF83 (void);
// 0x00000977 System.Single AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_totLength_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_totLength_get_m6C2F9EDA29BA5714903362C2C4660171B828BA37 (void);
// 0x00000978 System.Void AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_obstructionValue_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_obstructionValue_set_mC5829628F8353CE9B5C98C9B065E2F85E2B003F1 (void);
// 0x00000979 System.Single AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_obstructionValue_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_obstructionValue_get_m1255AF1A5A7A21D488DE23A48CC750BDAD91B187 (void);
// 0x0000097A System.Int32 AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetSizeOf_mEE08A2EE805BDD5287BF346912B7D4BC6CFFE8BE (void);
// 0x0000097B UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_GetNodes(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetNodes_m57EEF11D548808F5F22F10701E3073BD500FF12E (void);
// 0x0000097C System.Single AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_GetAngles(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetAngles_m76737C6DB7F4E59363B6EFD85374AB769A00E7EA (void);
// 0x0000097D System.UInt64 AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_GetPortals(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetPortals_m954A688F0B01D62CF5AEF389A10CFD7AF01764CE (void);
// 0x0000097E System.UInt64 AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_GetRooms(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetRooms_mF2A8FDDE9D82E0A6F8094351F667EFDA701FAC04 (void);
// 0x0000097F System.Void AkSoundEnginePINVOKE::CSharp_AkDiffractionPathInfo_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_Clone_mEE9AA0C6D0A1E49221C8EB39A993D88E354D4FC9 (void);
// 0x00000980 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkDiffractionPathInfo()
extern void AkSoundEnginePINVOKE_CSharp_new_AkDiffractionPathInfo_m1B4275043D1642E6A056B2CDA90370C3D0DE94B2 (void);
// 0x00000981 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkDiffractionPathInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkDiffractionPathInfo_mFFF5CE398391C96B588CB6ED28516B9995854E15 (void);
// 0x00000982 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkRoomParams__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkRoomParams__SWIG_0_m78B2FC1011B980BAEF354FE14457BE946078DD37 (void);
// 0x00000983 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkRoomParams__SWIG_1(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_new_AkRoomParams__SWIG_1_m21F304FAA8DFD8146850E85408C8DF2BF6018A50 (void);
// 0x00000984 System.Void AkSoundEnginePINVOKE::CSharp_AkRoomParams_Front_set(System.IntPtr,UnityEngine.Vector3)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_Front_set_m7251CA3A7E70C087B0C0A30FBEC7668F1D80CCE1 (void);
// 0x00000985 UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkRoomParams_Front_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_Front_get_mFFF6425C85369748F4FCB621BF195F325E097142 (void);
// 0x00000986 System.Void AkSoundEnginePINVOKE::CSharp_AkRoomParams_Up_set(System.IntPtr,UnityEngine.Vector3)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_Up_set_mD76FAF0A8F6F323E4EE6D8A4C1E1351BADE22293 (void);
// 0x00000987 UnityEngine.Vector3 AkSoundEnginePINVOKE::CSharp_AkRoomParams_Up_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_Up_get_m6798495DE1105BC4C4E8CC70ABB0F967E58DBC78 (void);
// 0x00000988 System.Void AkSoundEnginePINVOKE::CSharp_AkRoomParams_ReverbAuxBus_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_ReverbAuxBus_set_mDF399BB46A3C8E7EB971458BF569BA6056C59427 (void);
// 0x00000989 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkRoomParams_ReverbAuxBus_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_ReverbAuxBus_get_m535BB5821C3827095A60ECCA4DD147D175083C7D (void);
// 0x0000098A System.Void AkSoundEnginePINVOKE::CSharp_AkRoomParams_ReverbLevel_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_ReverbLevel_set_mD76F5621A27A98D0A06323A93FE8E90EAD9C2F70 (void);
// 0x0000098B System.Single AkSoundEnginePINVOKE::CSharp_AkRoomParams_ReverbLevel_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_ReverbLevel_get_m6DF005A7EEBE913E2788E408CEFC061E19276E9C (void);
// 0x0000098C System.Void AkSoundEnginePINVOKE::CSharp_AkRoomParams_TransmissionLoss_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_TransmissionLoss_set_m892D75009C11190EB5EA775126EC046D5646D4C6 (void);
// 0x0000098D System.Single AkSoundEnginePINVOKE::CSharp_AkRoomParams_TransmissionLoss_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_TransmissionLoss_get_m18F4932B4CD23FEF3ECCFF240059C58FE0D36C26 (void);
// 0x0000098E System.Void AkSoundEnginePINVOKE::CSharp_AkRoomParams_RoomGameObj_AuxSendLevelToSelf_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_RoomGameObj_AuxSendLevelToSelf_set_mA167FD0D67AA9191CEDDD529EB6687541ACE9620 (void);
// 0x0000098F System.Single AkSoundEnginePINVOKE::CSharp_AkRoomParams_RoomGameObj_AuxSendLevelToSelf_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_RoomGameObj_AuxSendLevelToSelf_get_m7E198F0FB28A5FC5C3E80D5D1098E25347241CA0 (void);
// 0x00000990 System.Void AkSoundEnginePINVOKE::CSharp_AkRoomParams_RoomGameObj_KeepRegistered_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_RoomGameObj_KeepRegistered_set_mE183A0BCC4D5AB23A230809A1C97FD6F61026922 (void);
// 0x00000991 System.Boolean AkSoundEnginePINVOKE::CSharp_AkRoomParams_RoomGameObj_KeepRegistered_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkRoomParams_RoomGameObj_KeepRegistered_get_mF47172737BA2B457A7AFBAC100AC5AFD91E2A5B1 (void);
// 0x00000992 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkRoomParams(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkRoomParams_m9063155289D000127FF03560F46508F55259263F (void);
// 0x00000993 System.Int32 AkSoundEnginePINVOKE::CSharp_SetGameObjectRadius(System.UInt64,System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetGameObjectRadius_mC16F81ECA0333B27145F4ED25FE87323DD1F8CF7 (void);
// 0x00000994 System.Int32 AkSoundEnginePINVOKE::CSharp_SetImageSource(System.UInt32,System.IntPtr,System.UInt32,System.UInt64,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_SetImageSource_m9EC0506CD4F2CF1C7C209617D91247C4D94BF1CC (void);
// 0x00000995 System.Int32 AkSoundEnginePINVOKE::CSharp_RemoveImageSource(System.UInt32,System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_RemoveImageSource_m902AED77F66B461CF5DD7571C38BA4B0FED7FF0E (void);
// 0x00000996 System.Int32 AkSoundEnginePINVOKE::CSharp_ClearImageSources__SWIG_0(System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_ClearImageSources__SWIG_0_m2653BA51502D8EE387CECB20D8460B7A569F7847 (void);
// 0x00000997 System.Int32 AkSoundEnginePINVOKE::CSharp_ClearImageSources__SWIG_1(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_ClearImageSources__SWIG_1_mFDBE8FC3C60AC067990409F7DBC2CC099B882F45 (void);
// 0x00000998 System.Int32 AkSoundEnginePINVOKE::CSharp_ClearImageSources__SWIG_2()
extern void AkSoundEnginePINVOKE_CSharp_ClearImageSources__SWIG_2_mBA9C69842599D51FB13CBB058D4783E5BA42B597 (void);
// 0x00000999 System.Int32 AkSoundEnginePINVOKE::CSharp_RemoveGeometry(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_RemoveGeometry_mFECCFB77B034397C85A4EFE412FD08C2245EB1F1 (void);
// 0x0000099A System.Int32 AkSoundEnginePINVOKE::CSharp_QueryReflectionPaths(System.UInt64,System.UInt32,UnityEngine.Vector3&,UnityEngine.Vector3&,System.IntPtr,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_QueryReflectionPaths_mE3876F6E5583DD911326BD937C3324768D4BF52B (void);
// 0x0000099B System.Int32 AkSoundEnginePINVOKE::CSharp_RemoveRoom(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_RemoveRoom_mFEEA7F4E05533961A884DC7F2FD918067B1D49F0 (void);
// 0x0000099C System.Int32 AkSoundEnginePINVOKE::CSharp_RemovePortal(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_RemovePortal_mDAE5939072901E12F9A0283A8A2C4676D05C7127 (void);
// 0x0000099D System.Int32 AkSoundEnginePINVOKE::CSharp_SetGameObjectInRoom(System.UInt64,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_SetGameObjectInRoom_mF7751850DCE44FE4396FEC5926860764DF765F78 (void);
// 0x0000099E System.Int32 AkSoundEnginePINVOKE::CSharp_SetReflectionsOrder(System.UInt32,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SetReflectionsOrder_m9019509F48917A6B1C997169600278B0980D9DCE (void);
// 0x0000099F System.Int32 AkSoundEnginePINVOKE::CSharp_SetNumberOfPrimaryRays(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetNumberOfPrimaryRays_mF90068F26913A6FF916B1525C2F7399E826DB300 (void);
// 0x000009A0 System.Int32 AkSoundEnginePINVOKE::CSharp_SetEarlyReflectionsAuxSend(System.UInt64,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetEarlyReflectionsAuxSend_m54CD0ECB1BDEEB6285286912965EFAAB9BDBD0E2 (void);
// 0x000009A1 System.Int32 AkSoundEnginePINVOKE::CSharp_SetEarlyReflectionsVolume(System.UInt64,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetEarlyReflectionsVolume_m8071AC48FAA7D5EFA669EE775507D3A008FACD01 (void);
// 0x000009A2 System.Int32 AkSoundEnginePINVOKE::CSharp_SetPortalObstructionAndOcclusion(System.UInt64,System.Single,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetPortalObstructionAndOcclusion_m456275263529BB4CA4394135FE92896124CCC0F9 (void);
// 0x000009A3 System.Int32 AkSoundEnginePINVOKE::CSharp_SetGameObjectToPortalObstruction(System.UInt64,System.UInt64,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetGameObjectToPortalObstruction_m54535828E1638B7BA462A65D1EE466BA26699657 (void);
// 0x000009A4 System.Int32 AkSoundEnginePINVOKE::CSharp_SetPortalToPortalObstruction(System.UInt64,System.UInt64,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_SetPortalToPortalObstruction_mFAEA091AED27C764D4D03DFBCF49EC48DCDAC7AB (void);
// 0x000009A5 System.Int32 AkSoundEnginePINVOKE::CSharp_QueryWetDiffraction(System.UInt64,System.Single&)
extern void AkSoundEnginePINVOKE_CSharp_QueryWetDiffraction_m87EBC01C3E6BBD6CD2610C99CC593256AA1E78AE (void);
// 0x000009A6 System.Int32 AkSoundEnginePINVOKE::CSharp_QueryDiffractionPaths(System.UInt64,System.UInt32,UnityEngine.Vector3&,UnityEngine.Vector3&,System.IntPtr,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_QueryDiffractionPaths_m3040EBE4383503DDD4AEC18A1538C85BF5E9F995 (void);
// 0x000009A7 System.Int32 AkSoundEnginePINVOKE::CSharp_ResetStochasticEngine()
extern void AkSoundEnginePINVOKE_CSharp_ResetStochasticEngine_mED5DFD43653A58C0D70EED09DBF181B73153A689 (void);
// 0x000009A8 System.Void AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_threadLEngine_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadLEngine_set_m710BFFE348A6DB283725F0A8D31CF01F8CE1BD4B (void);
// 0x000009A9 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_threadLEngine_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadLEngine_get_m039C24850B5556B2A71A100E2FD69A3CA1D3FBB7 (void);
// 0x000009AA System.Void AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_threadOutputMgr_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadOutputMgr_set_m37AD985B460F5E415D2F80254F632EC4F3F88165 (void);
// 0x000009AB System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_threadOutputMgr_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadOutputMgr_get_mF9A492BF96FB079493A7E5B55F4155FA1ED340A4 (void);
// 0x000009AC System.Void AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_threadBankManager_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadBankManager_set_m3AA6D779D1B295C727A21D6C68AA9C5B416F8390 (void);
// 0x000009AD System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_threadBankManager_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadBankManager_get_m0AA459A52550A375FADD1935D8ED35E00F8C1CE0 (void);
// 0x000009AE System.Void AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_threadMonitor_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadMonitor_set_m6687CB75293A5264AB4584AB8303EF84BF0CE2FB (void);
// 0x000009AF System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_threadMonitor_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadMonitor_get_m4AFD038B699572C101D9BD59C9D370148F17D700 (void);
// 0x000009B0 System.Void AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_uNumRefillsInVoice_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uNumRefillsInVoice_set_mAE7F42106DBCA83FC85A4DB4E60C56A415B342B7 (void);
// 0x000009B1 System.UInt16 AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_uNumRefillsInVoice_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uNumRefillsInVoice_get_mD4DC6B7A4C437C429F309C8B618BB1807373F616 (void);
// 0x000009B2 System.Void AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_uSampleRate_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uSampleRate_set_mE6E1F02B8E7BA695C3EF7B1B2E75B1EA0A48D62D (void);
// 0x000009B3 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_uSampleRate_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uSampleRate_get_m1B56462B0399E8EDC97793E5B207AB09784C2C68 (void);
// 0x000009B4 System.Void AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_bEnableAvxSupport_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_bEnableAvxSupport_set_m67420304379CE560C4440EDD423DF66C3F91AC04 (void);
// 0x000009B5 System.Boolean AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_bEnableAvxSupport_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_bEnableAvxSupport_get_m4E584738FA406AD1B13BCF5B3D151C655421C68C (void);
// 0x000009B6 System.Void AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_uMaxSystemAudioObjects_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uMaxSystemAudioObjects_set_m574F7B7E657BC0F62E07359CC735AD0338CAD06C (void);
// 0x000009B7 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkPlatformInitSettings_uMaxSystemAudioObjects_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uMaxSystemAudioObjects_get_mC9E62D74DDC85DD4FDCAEA866C8D4781BDC9095E (void);
// 0x000009B8 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkPlatformInitSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkPlatformInitSettings_m5EAB08474F37BC8CE5F3B6E3C0E828A1D336520E (void);
// 0x000009B9 System.UInt32 AkSoundEnginePINVOKE::CSharp_GetDeviceIDFromName(System.String)
extern void AkSoundEnginePINVOKE_CSharp_GetDeviceIDFromName_m9D82F6B0D4EEA2E63E2D8ABD90A7D8F12EDE869C (void);
// 0x000009BA System.IntPtr AkSoundEnginePINVOKE::CSharp_GetWindowsDeviceName__SWIG_0(System.Int32,System.UInt32&,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_GetWindowsDeviceName__SWIG_0_mE31907AA3741ADA2BA44A54927B7D64710BA2DFD (void);
// 0x000009BB System.IntPtr AkSoundEnginePINVOKE::CSharp_GetWindowsDeviceName__SWIG_1(System.Int32,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_GetWindowsDeviceName__SWIG_1_mC80D528EE642442B2AC6635775B5BCAF771E9D11 (void);
// 0x000009BC System.UInt32 AkSoundEnginePINVOKE::CSharp_GetWindowsDeviceCount__SWIG_0(System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_GetWindowsDeviceCount__SWIG_0_m9E7AC212252262B31544079C754E39B96F3ADE3C (void);
// 0x000009BD System.UInt32 AkSoundEnginePINVOKE::CSharp_GetWindowsDeviceCount__SWIG_1()
extern void AkSoundEnginePINVOKE_CSharp_GetWindowsDeviceCount__SWIG_1_m2CFD4361CB087E1AF1143FC877196113323C32D5 (void);
// 0x000009BE System.Void AkSoundEnginePINVOKE::CSharp_delete_AkStreamMgrSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkStreamMgrSettings_m04A5203B27402CD330743098920811266791A567 (void);
// 0x000009BF System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_pIOMemory_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_pIOMemory_set_m8286D8A950E5559BB6A34C6CE43EA42100FAFD38 (void);
// 0x000009C0 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_pIOMemory_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_pIOMemory_get_m76B8BAE3920F799BB9FCD20AD5E150C8AE53C709 (void);
// 0x000009C1 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uIOMemorySize_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uIOMemorySize_set_mF02C8D587A2B8F7DE60AB5A95633520732A5F0EB (void);
// 0x000009C2 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uIOMemorySize_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uIOMemorySize_get_mFDE9D83E4E8A1806707262B211BC77171689F797 (void);
// 0x000009C3 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uIOMemoryAlignment_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uIOMemoryAlignment_set_m4E6FE0647202A7D987B452CBF16244EFD2066FE7 (void);
// 0x000009C4 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uIOMemoryAlignment_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uIOMemoryAlignment_get_mE40CB89E46C9823AA4133A4988B29C1E482447FA (void);
// 0x000009C5 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_ePoolAttributes_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_ePoolAttributes_set_m67AA40B995BD2819B46314681F82985D230C065A (void);
// 0x000009C6 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_ePoolAttributes_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_ePoolAttributes_get_m9483A66E795BEA167B81EBAFAE4947F0F004A7E6 (void);
// 0x000009C7 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uGranularity_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uGranularity_set_m9E702C3E2D9A91831467F7B209893CF1257B3F72 (void);
// 0x000009C8 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uGranularity_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uGranularity_get_m3D81A1FEBEB558A771E6F7C87823A7BAE2CD8748 (void);
// 0x000009C9 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uSchedulerTypeFlags_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uSchedulerTypeFlags_set_m59A6B9AF84D53735CE51D7514848FC4B419C38AC (void);
// 0x000009CA System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uSchedulerTypeFlags_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uSchedulerTypeFlags_get_mEF050078DFB527D3FB0977D2D9F4E0CBD9707D81 (void);
// 0x000009CB System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_threadProperties_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_threadProperties_set_mC5786AA6990E71C7E3B8904FB0686A704B8FB634 (void);
// 0x000009CC System.IntPtr AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_threadProperties_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_threadProperties_get_mCF93A98668C8AE79E786A368091C4909E5DB09AF (void);
// 0x000009CD System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_fTargetAutoStmBufferLength_set(System.IntPtr,System.Single)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_fTargetAutoStmBufferLength_set_mF401CF54CDFD7E5E52C30FCF6F59B50D93FAA0D4 (void);
// 0x000009CE System.Single AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_fTargetAutoStmBufferLength_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_fTargetAutoStmBufferLength_get_mE98CDB72DDC1A3BC623584F4CA2F3BD41BB11180 (void);
// 0x000009CF System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uMaxConcurrentIO_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uMaxConcurrentIO_set_m8D8F47A8D1BDFE8F131D2D00D2A2CE35744BF738 (void);
// 0x000009D0 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uMaxConcurrentIO_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uMaxConcurrentIO_get_m30C435988A298EAAC42071046DB74BE6D5658B93 (void);
// 0x000009D1 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_bUseStreamCache_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_bUseStreamCache_set_m91C364145E5399DA337BD8A4FE13C0304D8BCAB5 (void);
// 0x000009D2 System.Boolean AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_bUseStreamCache_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_bUseStreamCache_get_m753D97DF88D8C3E4BAA4C419BE7E69F77378093D (void);
// 0x000009D3 System.Void AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uMaxCachePinnedBytes_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uMaxCachePinnedBytes_set_m434F1ACDB833F7802AC42BABA38F396F2E5876A3 (void);
// 0x000009D4 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkDeviceSettings_uMaxCachePinnedBytes_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uMaxCachePinnedBytes_get_m497B96C4031D0039A04C3F418C84735ED8E560FD (void);
// 0x000009D5 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkDeviceSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkDeviceSettings_m95260F865973F418A7FB8E6FBF0405C254321197 (void);
// 0x000009D6 System.Void AkSoundEnginePINVOKE::CSharp_AkThreadProperties_nPriority_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkThreadProperties_nPriority_set_mF726FABCBE045DBF9F361A9D48666D067FFF3AC1 (void);
// 0x000009D7 System.Int32 AkSoundEnginePINVOKE::CSharp_AkThreadProperties_nPriority_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkThreadProperties_nPriority_get_mEE3A49683C9A0230B63EB3020F8E93BF6169F52F (void);
// 0x000009D8 System.Void AkSoundEnginePINVOKE::CSharp_AkThreadProperties_dwAffinityMask_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkThreadProperties_dwAffinityMask_set_mF08EDD4960BDA1736ED357E073A9D15A5C17E7E5 (void);
// 0x000009D9 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkThreadProperties_dwAffinityMask_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkThreadProperties_dwAffinityMask_get_m2A3680AD21C66A5A6FBA6ACA16CB362F46D9B2B4 (void);
// 0x000009DA System.Void AkSoundEnginePINVOKE::CSharp_AkThreadProperties_uStackSize_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkThreadProperties_uStackSize_set_mEF331699000F24EAB58AC459893FF46439DAB7C4 (void);
// 0x000009DB System.UInt32 AkSoundEnginePINVOKE::CSharp_AkThreadProperties_uStackSize_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkThreadProperties_uStackSize_get_m65133E15826735937DCD1AACEA63A0FC0C86ADA5 (void);
// 0x000009DC System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkThreadProperties()
extern void AkSoundEnginePINVOKE_CSharp_new_AkThreadProperties_mFFAFC88E17DA93E9CD11AD01CA704AF84725B3FE (void);
// 0x000009DD System.Void AkSoundEnginePINVOKE::CSharp_delete_AkThreadProperties(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkThreadProperties_m51D0C3AE9FC244344C96E552ABAC5BAA038A453F (void);
// 0x000009DE System.Void AkSoundEnginePINVOKE::CSharp_SetErrorLogger__SWIG_0(AkLogger_ErrorLoggerInteropDelegate)
extern void AkSoundEnginePINVOKE_CSharp_SetErrorLogger__SWIG_0_m68384E32C4CBFD7903EA083542FD43653A90B217 (void);
// 0x000009DF System.Void AkSoundEnginePINVOKE::CSharp_SetErrorLogger__SWIG_1()
extern void AkSoundEnginePINVOKE_CSharp_SetErrorLogger__SWIG_1_mD7CF5BD29C515837CB916C970AA871E1DD40A3B8 (void);
// 0x000009E0 System.Void AkSoundEnginePINVOKE::CSharp_SetAudioInputCallbacks(AkAudioInputManager_AudioSamplesInteropDelegate,AkAudioInputManager_AudioFormatInteropDelegate)
extern void AkSoundEnginePINVOKE_CSharp_SetAudioInputCallbacks_mAA8D3245B6079D1D9CE587AF583F62DEBE6D0A3E (void);
// 0x000009E1 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkUnityPlatformSpecificSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkUnityPlatformSpecificSettings_m32BB0DA479787772FB49A633AB8DE06A2FD24CD1 (void);
// 0x000009E2 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkCommunicationSettings()
extern void AkSoundEnginePINVOKE_CSharp_new_AkCommunicationSettings_m6AF6E8060C2794E681F947FEEA9ADCD1B5B0BD61 (void);
// 0x000009E3 System.Void AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_uPoolSize_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uPoolSize_set_mA4870B41E99D81958442C4A44AA829D533925D45 (void);
// 0x000009E4 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_uPoolSize_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uPoolSize_get_m34CCD5DD89C2F9B5783AA90152E62C62D9143BD4 (void);
// 0x000009E5 System.Void AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_uDiscoveryBroadcastPort_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uDiscoveryBroadcastPort_set_mCC3E30CD7B847E11FAF5AA9AC0C772806A955568 (void);
// 0x000009E6 System.UInt16 AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_uDiscoveryBroadcastPort_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uDiscoveryBroadcastPort_get_m0E554924E0FA0564713739EFB9E855E04547B8DE (void);
// 0x000009E7 System.Void AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_uCommandPort_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uCommandPort_set_m1C3937D09F907F4B6861F158A80C6E07AA3695EF (void);
// 0x000009E8 System.UInt16 AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_uCommandPort_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uCommandPort_get_mD8A6DDAF8C84EA1BC199E558B432D3654351C2B3 (void);
// 0x000009E9 System.Void AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_uNotificationPort_set(System.IntPtr,System.UInt16)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uNotificationPort_set_m02359870647C731EFF76F03DC1F88FA6E4ACECFC (void);
// 0x000009EA System.UInt16 AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_uNotificationPort_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uNotificationPort_get_m680BB3440A859142F22956A4FFD9DF7CCA24C99B (void);
// 0x000009EB System.Void AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_commSystem_set(System.IntPtr,System.Int32)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_commSystem_set_m0F6E9010D8C1F9C26B4553F84942B678FDB660C3 (void);
// 0x000009EC System.Int32 AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_commSystem_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_commSystem_get_m79365E910BCFED56C9A62D72256E53329A2A3291 (void);
// 0x000009ED System.Void AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_bInitSystemLib_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_bInitSystemLib_set_mCDCFE7E140EB93A457D85F735BF0826FD97D0A3E (void);
// 0x000009EE System.Boolean AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_bInitSystemLib_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_bInitSystemLib_get_m11ED25B17BDC89D4FA4AE47EC969EC6A8C52BC2E (void);
// 0x000009EF System.Void AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_szAppNetworkName_set(System.IntPtr,System.String)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_szAppNetworkName_set_m5C361481C871B3301C14D9B379E43997EA987416 (void);
// 0x000009F0 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkCommunicationSettings_szAppNetworkName_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_szAppNetworkName_get_m745758F2BCAE9E6EED09D3FD2534483CE2B4DC02 (void);
// 0x000009F1 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkCommunicationSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkCommunicationSettings_mEBB83365A3A19DA97085FCB8275AA6E34F4EB020 (void);
// 0x000009F2 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkInitializationSettings()
extern void AkSoundEnginePINVOKE_CSharp_new_AkInitializationSettings_m0212DB5EFDD620A571EB74C9985E2A9FC5A98F99 (void);
// 0x000009F3 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkInitializationSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkInitializationSettings_mE12A13A61F3A0A56DAC3F2F9779553EF7F898A97 (void);
// 0x000009F4 System.Void AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_streamMgrSettings_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_streamMgrSettings_set_mB8B068C2512DD333251D11FC9202D172237DA673 (void);
// 0x000009F5 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_streamMgrSettings_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_streamMgrSettings_get_m8AB1D842D2803554043373DCC770A2744A2824A7 (void);
// 0x000009F6 System.Void AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_deviceSettings_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_deviceSettings_set_m481A3198813883572CB71BC73C9056E33271ECC4 (void);
// 0x000009F7 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_deviceSettings_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_deviceSettings_get_mC8E89A1E43B6A372981B4199E66B0B47C0534D0A (void);
// 0x000009F8 System.Void AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_initSettings_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_initSettings_set_m44AAA3F99B90DA0F78642305BE4D1AD5686BC923 (void);
// 0x000009F9 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_initSettings_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_initSettings_get_m6FDB9E9DD58FF6D86CE7A7654BBA762829432569 (void);
// 0x000009FA System.Void AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_platformSettings_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_platformSettings_set_mDFF03C61F46AD247CA99919502974D9756F78129 (void);
// 0x000009FB System.IntPtr AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_platformSettings_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_platformSettings_get_m995D39B22BDE6496DE27186D1542CE4E4C1707D0 (void);
// 0x000009FC System.Void AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_musicSettings_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_musicSettings_set_mD51AC53481A4DE754A3F2F3C60302F36B196238E (void);
// 0x000009FD System.IntPtr AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_musicSettings_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_musicSettings_get_m9B6C008BCCB4448AEA53135169F128EC4B80BA6E (void);
// 0x000009FE System.Void AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_unityPlatformSpecificSettings_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_unityPlatformSpecificSettings_set_m4B8C637D232E0E44BF7333F898B9BCAABFF47426 (void);
// 0x000009FF System.IntPtr AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_unityPlatformSpecificSettings_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_unityPlatformSpecificSettings_get_m67B7A327FC092DCEE503FE1FB5CCC981A6EB20A4 (void);
// 0x00000A00 System.Void AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_useAsyncOpen_set(System.IntPtr,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_useAsyncOpen_set_mFF624DC0905F4299F0E27987E9CB08BFFDB8C7F0 (void);
// 0x00000A01 System.Boolean AkSoundEnginePINVOKE::CSharp_AkInitializationSettings_useAsyncOpen_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_useAsyncOpen_get_m341C38A0349784C82F6F89A657D0B994E1F73503 (void);
// 0x00000A02 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkExternalSourceInfo__SWIG_0()
extern void AkSoundEnginePINVOKE_CSharp_new_AkExternalSourceInfo__SWIG_0_m3EF33CA1520A68C6F9AA3EFB764D1D827395A88A (void);
// 0x00000A03 System.Void AkSoundEnginePINVOKE::CSharp_delete_AkExternalSourceInfo(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_delete_AkExternalSourceInfo_m7C68034107F6E67EAC9BA412F51276F9AFEF1D8F (void);
// 0x00000A04 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkExternalSourceInfo__SWIG_1(System.IntPtr,System.UInt32,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_new_AkExternalSourceInfo__SWIG_1_mFDEF4FC85E8A909D59E083F350493BE2E0B05E7F (void);
// 0x00000A05 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkExternalSourceInfo__SWIG_2(System.String,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_new_AkExternalSourceInfo__SWIG_2_m9E22C6556D5ADDE4FCF632DB4B051B315B3BDE57 (void);
// 0x00000A06 System.IntPtr AkSoundEnginePINVOKE::CSharp_new_AkExternalSourceInfo__SWIG_3(System.UInt32,System.UInt32,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_new_AkExternalSourceInfo__SWIG_3_m97B9AD0DA0C13AA34D9FE31F1545694AFCD666E6 (void);
// 0x00000A07 System.Void AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_Clear(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_Clear_m2D4BF472DE807F7E0EB714935BCEBF5E87CD7E14 (void);
// 0x00000A08 System.Void AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_Clone(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_Clone_mDE25C1D520AF9E2C0B39A0692072A7BFA92B2759 (void);
// 0x00000A09 System.Int32 AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_GetSizeOf()
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_GetSizeOf_mABA01B235D6D670FF24049CFD45B5D3227C7033B (void);
// 0x00000A0A System.Void AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_iExternalSrcCookie_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_iExternalSrcCookie_set_m5E2F66CEE3047302017C441AAA7CB35E8C207BC5 (void);
// 0x00000A0B System.UInt32 AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_iExternalSrcCookie_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_iExternalSrcCookie_get_mD477AF334E9FB18D5F35BED5A01D4A24AEDC33D0 (void);
// 0x00000A0C System.Void AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_idCodec_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_idCodec_set_m72F3CB1C28119F257418E34264D175B337A8FD16 (void);
// 0x00000A0D System.UInt32 AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_idCodec_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_idCodec_get_mE122A04C220D43B060D506890D31FB940FD1298B (void);
// 0x00000A0E System.Void AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_szFile_set(System.IntPtr,System.String)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_szFile_set_mB3118F243EE29E3120EA83F1B04EF3C2B726DD53 (void);
// 0x00000A0F System.IntPtr AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_szFile_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_szFile_get_m52FC98B8225A6BE7E12E607064D53242AE01DACA (void);
// 0x00000A10 System.Void AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_pInMemory_set(System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_pInMemory_set_m26ED0D0DFC42F8259C4F12671E3F6C40F0DF0CFB (void);
// 0x00000A11 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_pInMemory_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_pInMemory_get_m5A4C9BC418DE7677C0082EA9825E3B634F5A5EA0 (void);
// 0x00000A12 System.Void AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_uiMemorySize_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_uiMemorySize_set_m76E0A49CEC84D42CD74153C161E615B7D8EB108B (void);
// 0x00000A13 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_uiMemorySize_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_uiMemorySize_get_m72060DF3038DDEA7362CB7CF0C4BD8C20B95A6FE (void);
// 0x00000A14 System.Void AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_idFile_set(System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_idFile_set_m20F61C9E416A13BA5DFEDCB60F533208785992D5 (void);
// 0x00000A15 System.UInt32 AkSoundEnginePINVOKE::CSharp_AkExternalSourceInfo_idFile_get(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_idFile_get_m9311AFDC0D4CD1DDFA21110FD096AEFBF73C3258 (void);
// 0x00000A16 System.Int32 AkSoundEnginePINVOKE::CSharp_Init(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_Init_mCA72E0E34A79850320826CD1DDAE665566D4D278 (void);
// 0x00000A17 System.Int32 AkSoundEnginePINVOKE::CSharp_InitSpatialAudio(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_InitSpatialAudio_m3D652E3529941F79630C258219B366CFF507D1A5 (void);
// 0x00000A18 System.Int32 AkSoundEnginePINVOKE::CSharp_InitCommunication(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_InitCommunication_mD08CDFFD475A4590F07D2C64003DEB07FA302094 (void);
// 0x00000A19 System.Void AkSoundEnginePINVOKE::CSharp_Term()
extern void AkSoundEnginePINVOKE_CSharp_Term_mA1E44FF3B26A1BF0ACC8DEDA020915CDEEFF85AD (void);
// 0x00000A1A System.Int32 AkSoundEnginePINVOKE::CSharp_RegisterGameObjInternal(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_RegisterGameObjInternal_m71316D587F319943FEC530D9C6741B5D96194E37 (void);
// 0x00000A1B System.Int32 AkSoundEnginePINVOKE::CSharp_UnregisterGameObjInternal(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_UnregisterGameObjInternal_mF10321F56FD632B6042DFD06E78301975DF263DA (void);
// 0x00000A1C System.Int32 AkSoundEnginePINVOKE::CSharp_RegisterGameObjInternal_WithName(System.UInt64,System.String)
extern void AkSoundEnginePINVOKE_CSharp_RegisterGameObjInternal_WithName_m1E6659FFA28CAB76BFEF5E3B89A5EF91685EC1BF (void);
// 0x00000A1D System.Int32 AkSoundEnginePINVOKE::CSharp_SetBasePath(System.String)
extern void AkSoundEnginePINVOKE_CSharp_SetBasePath_m5A45603628E650AC75C27E20A99F7C994661AAFE (void);
// 0x00000A1E System.Int32 AkSoundEnginePINVOKE::CSharp_SetCurrentLanguage(System.String)
extern void AkSoundEnginePINVOKE_CSharp_SetCurrentLanguage_mCA50FC85F97AED294864255689725514DEEC7AAA (void);
// 0x00000A1F System.Int32 AkSoundEnginePINVOKE::CSharp_LoadFilePackage(System.String,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_LoadFilePackage_m6934F49AF4A0F492BA628C2E70F1CC13F1FCA081 (void);
// 0x00000A20 System.Int32 AkSoundEnginePINVOKE::CSharp_AddBasePath(System.String)
extern void AkSoundEnginePINVOKE_CSharp_AddBasePath_m75FE1EC9C77B62CCF7F04E43E67DA0390607DBD0 (void);
// 0x00000A21 System.Int32 AkSoundEnginePINVOKE::CSharp_SetGameName(System.String)
extern void AkSoundEnginePINVOKE_CSharp_SetGameName_m564B8E316381AD09DB75B8AE0618F1F7707ECBE2 (void);
// 0x00000A22 System.Int32 AkSoundEnginePINVOKE::CSharp_SetDecodedBankPath(System.String)
extern void AkSoundEnginePINVOKE_CSharp_SetDecodedBankPath_mAF3195F1EAAFB65B9960A8DC24E5259F7F912DF2 (void);
// 0x00000A23 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadAndDecodeBank(System.String,System.Boolean,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_LoadAndDecodeBank_m5F7136B76FE49441FE77B1BBE7EC3BD23778FDC9 (void);
// 0x00000A24 System.Int32 AkSoundEnginePINVOKE::CSharp_LoadAndDecodeBankFromMemory(System.IntPtr,System.UInt32,System.Boolean,System.String,System.Boolean,System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_LoadAndDecodeBankFromMemory_mEAC3F71F479D9644491A9E8AFE6D17D178ACBD8E (void);
// 0x00000A25 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEventOnRoom__SWIG_0(System.String,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_0_m38B88A3EA476F6A4D0E2772512A976A55BCD534C (void);
// 0x00000A26 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEventOnRoom__SWIG_1(System.String,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_1_m3E7606B76483D42BE01BC8DA9F2345FE75983FB8 (void);
// 0x00000A27 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEventOnRoom__SWIG_2(System.String,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_2_mD301F3964B413BA64EF1D8392BB1F303FC9F5305 (void);
// 0x00000A28 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEventOnRoom__SWIG_3(System.String,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_3_mBB886149EACA859B0E1790AAE05074D9E4ACA15C (void);
// 0x00000A29 System.IntPtr AkSoundEnginePINVOKE::CSharp_GetCurrentLanguage()
extern void AkSoundEnginePINVOKE_CSharp_GetCurrentLanguage_m1F1319E062F4E3E1C141282586AF956D3DCC8913 (void);
// 0x00000A2A System.Int32 AkSoundEnginePINVOKE::CSharp_UnloadFilePackage(System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_UnloadFilePackage_m1E1020A6C68D3156940DBBD507F6BBA1C3E391AE (void);
// 0x00000A2B System.Int32 AkSoundEnginePINVOKE::CSharp_UnloadAllFilePackages()
extern void AkSoundEnginePINVOKE_CSharp_UnloadAllFilePackages_mC7599F61A96DB355D029A9500D7B7B78DF52EA48 (void);
// 0x00000A2C System.Int32 AkSoundEnginePINVOKE::CSharp_SetObjectPosition(System.UInt64,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void AkSoundEnginePINVOKE_CSharp_SetObjectPosition_m42C2CD41D5E766349C9BDB5EBA986AA47587D270 (void);
// 0x00000A2D System.Int32 AkSoundEnginePINVOKE::CSharp_GetSourceMultiplePlayPositions__SWIG_0(System.UInt32,System.UInt32[],System.UInt32[],System.Int32[],System.UInt32&,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_GetSourceMultiplePlayPositions__SWIG_0_mA8CEFBACD47549AEE90F82F938B890D804782B24 (void);
// 0x00000A2E System.Int32 AkSoundEnginePINVOKE::CSharp_GetSourceMultiplePlayPositions__SWIG_1(System.UInt32,System.UInt32[],System.UInt32[],System.Int32[],System.UInt32&)
extern void AkSoundEnginePINVOKE_CSharp_GetSourceMultiplePlayPositions__SWIG_1_m38873CD2D16A32228EBE9D4CE76863803B85F1F6 (void);
// 0x00000A2F System.Int32 AkSoundEnginePINVOKE::CSharp_SetListeners(System.UInt64,System.UInt64[],System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetListeners_m272FAF7CC0CC72A6CDA6A4F01C4CE5451E30D967 (void);
// 0x00000A30 System.Int32 AkSoundEnginePINVOKE::CSharp_SetDefaultListeners(System.UInt64[],System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_SetDefaultListeners_mB40014804F991336EDE11782A85BA876006CA8F4 (void);
// 0x00000A31 System.Int32 AkSoundEnginePINVOKE::CSharp_AddOutput__SWIG_0(System.IntPtr,System.UInt64&,System.UInt64[],System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_AddOutput__SWIG_0_m2575DED1E32E55187551201C1B1741AABC5DC6FC (void);
// 0x00000A32 System.Int32 AkSoundEnginePINVOKE::CSharp_AddOutput__SWIG_1(System.IntPtr,System.UInt64&,System.UInt64[])
extern void AkSoundEnginePINVOKE_CSharp_AddOutput__SWIG_1_m61D2835EBC9497D181A46B067603C6DF2879D2CD (void);
// 0x00000A33 System.Int32 AkSoundEnginePINVOKE::CSharp_AddOutput__SWIG_2(System.IntPtr,System.UInt64&)
extern void AkSoundEnginePINVOKE_CSharp_AddOutput__SWIG_2_m9218105968724275303DC3F0E35854AC45CA0EBE (void);
// 0x00000A34 System.Int32 AkSoundEnginePINVOKE::CSharp_AddOutput__SWIG_3(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AddOutput__SWIG_3_mA214BA3082FB81166926FA3873329CF1E3B32067 (void);
// 0x00000A35 System.Void AkSoundEnginePINVOKE::CSharp_GetDefaultStreamSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetDefaultStreamSettings_m8C8B3B9B16D5B45FB2B9AFAD06D36674623F143C (void);
// 0x00000A36 System.Void AkSoundEnginePINVOKE::CSharp_GetDefaultDeviceSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetDefaultDeviceSettings_m4FD0A580ECF94AE2D259B3E4AF6AE23BC4AB359F (void);
// 0x00000A37 System.Void AkSoundEnginePINVOKE::CSharp_GetDefaultMusicSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetDefaultMusicSettings_m26404C6FD2E2C3DDB33298E653C146210C9F0BD7 (void);
// 0x00000A38 System.Void AkSoundEnginePINVOKE::CSharp_GetDefaultInitSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetDefaultInitSettings_mE5BE839FA7DAF6C6BD0A42CAA42B640B6DE890E6 (void);
// 0x00000A39 System.Void AkSoundEnginePINVOKE::CSharp_GetDefaultPlatformInitSettings(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetDefaultPlatformInitSettings_m6E51299D36934822341AABF0645F06D671536895 (void);
// 0x00000A3A System.UInt32 AkSoundEnginePINVOKE::CSharp_GetMajorMinorVersion()
extern void AkSoundEnginePINVOKE_CSharp_GetMajorMinorVersion_m29668FC17B0028AA0BC973817D3F5E01A4EBD5B8 (void);
// 0x00000A3B System.UInt32 AkSoundEnginePINVOKE::CSharp_GetSubminorBuildVersion()
extern void AkSoundEnginePINVOKE_CSharp_GetSubminorBuildVersion_mE8C62F6FEF1E8154083D8A3A775F4E78124C88F6 (void);
// 0x00000A3C System.Void AkSoundEnginePINVOKE::CSharp_StartResourceMonitoring()
extern void AkSoundEnginePINVOKE_CSharp_StartResourceMonitoring_m8C6C468B5135AE21F907841E822FBFB0563B5E93 (void);
// 0x00000A3D System.Void AkSoundEnginePINVOKE::CSharp_StopResourceMonitoring()
extern void AkSoundEnginePINVOKE_CSharp_StopResourceMonitoring_m01D00EA06E51C17A0552D20FB4D3C6A3E756DEDC (void);
// 0x00000A3E System.Void AkSoundEnginePINVOKE::CSharp_GetResourceMonitorDataSummary(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_GetResourceMonitorDataSummary_m9AC8D1F10682BE6785F0BB045D08672DCDA6D31C (void);
// 0x00000A3F System.Int32 AkSoundEnginePINVOKE::CSharp_SetRoomPortal(System.UInt64,System.IntPtr,System.IntPtr,System.Boolean,System.UInt64,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_SetRoomPortal_m8D8DF85B11D6019541CC499E9D7CE1A8B22A2BD7 (void);
// 0x00000A40 System.Int32 AkSoundEnginePINVOKE::CSharp_SetRoom(System.UInt64,System.IntPtr,System.UInt64,System.String)
extern void AkSoundEnginePINVOKE_CSharp_SetRoom_mBE8D2179088554999E2514B50350952ABF84C6CA (void);
// 0x00000A41 System.Int32 AkSoundEnginePINVOKE::CSharp_RegisterSpatialAudioListener(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_RegisterSpatialAudioListener_m3C56A4FADC83779A4F6F47BE93EBF27CDB78FBC8 (void);
// 0x00000A42 System.Int32 AkSoundEnginePINVOKE::CSharp_UnregisterSpatialAudioListener(System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_UnregisterSpatialAudioListener_m78E1FA6CF743264AAE9DB3CD4F18BA1D5E87ADEB (void);
// 0x00000A43 System.Int32 AkSoundEnginePINVOKE::CSharp_SetGeometry(System.UInt64,System.IntPtr,System.UInt32,UnityEngine.Vector3[],System.UInt32,System.IntPtr,System.UInt32,System.UInt64,System.Boolean,System.Boolean,System.Boolean)
extern void AkSoundEnginePINVOKE_CSharp_SetGeometry_m9C35BCB21E97641C0E1CAEFC5FBB45F704DDB65F (void);
// 0x00000A44 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEventOnRoom__SWIG_4(System.UInt32,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32,System.IntPtr,System.UInt32)
extern void AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_4_m6D2FF5D956EADB64A80E4FDEFD2476F24ACE4816 (void);
// 0x00000A45 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEventOnRoom__SWIG_5(System.UInt32,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr,System.UInt32,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_5_m98E7F6B36367D73940D5FBBA538E3CC266532A20 (void);
// 0x00000A46 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEventOnRoom__SWIG_6(System.UInt32,System.UInt64,System.UInt32,System.IntPtr,System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_6_m4E28BD26E96A393104A963D8F533BF9C59A73D3A (void);
// 0x00000A47 System.UInt32 AkSoundEnginePINVOKE::CSharp_PostEventOnRoom__SWIG_7(System.UInt32,System.UInt64)
extern void AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_7_m13A0037EBFA01558A9A8AE1978771B8D4633BCCD (void);
// 0x00000A48 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkPlaylist_SWIGUpcast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkPlaylist_SWIGUpcast_m6AEFA5A30ED8AC76E3F5B7C7A50E0DBE06127B56 (void);
// 0x00000A49 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIPost_SWIGUpcast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIPost_SWIGUpcast_m5A8944C6B7565ED0FF24BF32BE8AA6AA6AEBC2DA (void);
// 0x00000A4A System.IntPtr AkSoundEnginePINVOKE::CSharp_AkEventCallbackInfo_SWIGUpcast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkEventCallbackInfo_SWIGUpcast_m1862D28D4EECC82E8BD279F11CB1CAC836052EF7 (void);
// 0x00000A4B System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMIDIEventCallbackInfo_SWIGUpcast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_SWIGUpcast_mC5C9E688014D3E2C2735CAF748F9DF24D915AEAC (void);
// 0x00000A4C System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMarkerCallbackInfo_SWIGUpcast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMarkerCallbackInfo_SWIGUpcast_mE6EFE30EFE41698181B6C24537747A9249D63A19 (void);
// 0x00000A4D System.IntPtr AkSoundEnginePINVOKE::CSharp_AkDurationCallbackInfo_SWIGUpcast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_SWIGUpcast_m8984C9C351F706BF44130F6070DF958E9F7E4896 (void);
// 0x00000A4E System.IntPtr AkSoundEnginePINVOKE::CSharp_AkDynamicSequenceItemCallbackInfo_SWIGUpcast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkDynamicSequenceItemCallbackInfo_SWIGUpcast_m7A4BE1F2C0F8FB1AF31212183E936B19AFF8CBBE (void);
// 0x00000A4F System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMusicSyncCallbackInfo_SWIGUpcast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_SWIGUpcast_m1FDA60723B08468276164561F00049A998101FBF (void);
// 0x00000A50 System.IntPtr AkSoundEnginePINVOKE::CSharp_AkMusicPlaylistCallbackInfo_SWIGUpcast(System.IntPtr)
extern void AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_SWIGUpcast_mD93C3EE7D2A628E6BDEB366F93DB1383C36B8718 (void);
// 0x00000A51 System.Void AkSoundEnginePINVOKE::.ctor()
extern void AkSoundEnginePINVOKE__ctor_m5EDA6A97C30248A81AE8403CC75D2BC1AEB25E7E (void);
// 0x00000A52 System.Void AkThreadProperties::.ctor(System.IntPtr,System.Boolean)
extern void AkThreadProperties__ctor_m68FB5DD35372D5E59C55624B891F6C1069FCA63A (void);
// 0x00000A53 System.IntPtr AkThreadProperties::getCPtr(AkThreadProperties)
extern void AkThreadProperties_getCPtr_mE179538CA24EC5EA946902A7BD6003FBE39512C4 (void);
// 0x00000A54 System.Void AkThreadProperties::setCPtr(System.IntPtr)
extern void AkThreadProperties_setCPtr_m6E2743DEAEC5A7EFD6AF639202449F555F8E02D3 (void);
// 0x00000A55 System.Void AkThreadProperties::Finalize()
extern void AkThreadProperties_Finalize_m9462629FA8565D01840AB5B1C1C0DBBE3FAA52F4 (void);
// 0x00000A56 System.Void AkThreadProperties::Dispose()
extern void AkThreadProperties_Dispose_mFB81FB3F1392DF9FF3DBEF3DD8B30766203ECCDD (void);
// 0x00000A57 System.Void AkThreadProperties::set_nPriority(System.Int32)
extern void AkThreadProperties_set_nPriority_mF425446CB56D86D6E12CE4A3762B939514E54E0E (void);
// 0x00000A58 System.Int32 AkThreadProperties::get_nPriority()
extern void AkThreadProperties_get_nPriority_mDEA865CFDFF8E199C96039E5C0EBF78D0B1004A8 (void);
// 0x00000A59 System.Void AkThreadProperties::set_dwAffinityMask(System.UInt32)
extern void AkThreadProperties_set_dwAffinityMask_m30B6B5F76B9B584C03F3457C5C1938FEE4B371F4 (void);
// 0x00000A5A System.UInt32 AkThreadProperties::get_dwAffinityMask()
extern void AkThreadProperties_get_dwAffinityMask_mB8C72F6955C8C5E7C1D60FEA27F775A00FC45647 (void);
// 0x00000A5B System.Void AkThreadProperties::set_uStackSize(System.UInt32)
extern void AkThreadProperties_set_uStackSize_m43A99513848D580C1FC17684ED0B4726F0F7961B (void);
// 0x00000A5C System.UInt32 AkThreadProperties::get_uStackSize()
extern void AkThreadProperties_get_uStackSize_m4D1F327C1C760D2DDA9A5210457819BD61F6D77D (void);
// 0x00000A5D System.Void AkThreadProperties::.ctor()
extern void AkThreadProperties__ctor_mF18E611850AC8B66957F4DDE33424C0CA8C05D3E (void);
// 0x00000A5E System.Void AkUnityPlatformSpecificSettings::.ctor(System.IntPtr,System.Boolean)
extern void AkUnityPlatformSpecificSettings__ctor_mF41C9776D3F48F0ACE9E52572ABE43E89E26E9D1 (void);
// 0x00000A5F System.IntPtr AkUnityPlatformSpecificSettings::getCPtr(AkUnityPlatformSpecificSettings)
extern void AkUnityPlatformSpecificSettings_getCPtr_mE3FA3A16724A5CE8AE44A026BC036BC0E332AC27 (void);
// 0x00000A60 System.Void AkUnityPlatformSpecificSettings::setCPtr(System.IntPtr)
extern void AkUnityPlatformSpecificSettings_setCPtr_mD1305B3E9CC81E9CF0E88F9D204EF86BEBB761C1 (void);
// 0x00000A61 System.Void AkUnityPlatformSpecificSettings::Finalize()
extern void AkUnityPlatformSpecificSettings_Finalize_mB318CA860E8B6C8723C7026961D8F2B584668302 (void);
// 0x00000A62 System.Void AkUnityPlatformSpecificSettings::Dispose()
extern void AkUnityPlatformSpecificSettings_Dispose_m22CC518233AAF8E090D453E925CDA864261784E5 (void);
// 0x00000A63 System.UInt32 AkAudioInputManager::PostAudioInputEvent(System.UInt32,UnityEngine.GameObject,AkAudioInputManager_AudioSamplesDelegate,AkAudioInputManager_AudioFormatDelegate)
extern void AkAudioInputManager_PostAudioInputEvent_m3DACAD19669F1E935D6452EE2B5E726DF0B55A39 (void);
// 0x00000A64 System.UInt32 AkAudioInputManager::PostAudioInputEvent(System.String,UnityEngine.GameObject,AkAudioInputManager_AudioSamplesDelegate,AkAudioInputManager_AudioFormatDelegate)
extern void AkAudioInputManager_PostAudioInputEvent_m7DA318CBF68F49E058C094DD5BBEFD49923C29B4 (void);
// 0x00000A65 System.Boolean AkAudioInputManager::InternalAudioSamplesDelegate(System.UInt32,System.Single[],System.UInt32,System.UInt32)
extern void AkAudioInputManager_InternalAudioSamplesDelegate_mCC8ACFBA434E55CA478271AC70312599C48729D8 (void);
// 0x00000A66 System.Void AkAudioInputManager::InternalAudioFormatDelegate(System.UInt32,System.IntPtr)
extern void AkAudioInputManager_InternalAudioFormatDelegate_mE65C58A009B2CCE12BF2D66527E4DBA94359AE2F (void);
// 0x00000A67 System.Void AkAudioInputManager::TryInitialize()
extern void AkAudioInputManager_TryInitialize_m6152025586F44B67D0E11CC63B6EA4182A9A6469 (void);
// 0x00000A68 System.Void AkAudioInputManager::AddPlayingID(System.UInt32,AkAudioInputManager_AudioSamplesDelegate,AkAudioInputManager_AudioFormatDelegate)
extern void AkAudioInputManager_AddPlayingID_m93C8EECFA27F42CC254C0027C5BC6195F38242A9 (void);
// 0x00000A69 System.Void AkAudioInputManager::EventCallback(System.Object,AkCallbackType,AkCallbackInfo)
extern void AkAudioInputManager_EventCallback_mFF401B177FC074D2DBD6F062B472112838ACFBFA (void);
// 0x00000A6A System.Void AkAudioInputManager::.cctor()
extern void AkAudioInputManager__cctor_m0D6D922E7D4D3243DE40FFCF43C8911701368AE0 (void);
// 0x00000A6B System.Void AkBankManager::DoUnloadBanks()
extern void AkBankManager_DoUnloadBanks_m5A1C59BE48FF8D81A4C1F62BBAEA3E6E84A6477D (void);
// 0x00000A6C System.Void AkBankManager::Reset()
extern void AkBankManager_Reset_mD18059D585802F4578BE52135D22C1968D499961 (void);
// 0x00000A6D System.Void AkBankManager::ReloadAllBanks()
extern void AkBankManager_ReloadAllBanks_mAECBEF2E4321CD8DCFD7EE650F69153DDD131E2C (void);
// 0x00000A6E System.Void AkBankManager::LoadInitBank(System.Boolean)
extern void AkBankManager_LoadInitBank_m520C83FABEE8871F69548C2099FBC176C1010B91 (void);
// 0x00000A6F System.Void AkBankManager::UnloadInitBank()
extern void AkBankManager_UnloadInitBank_mA0EB0194C1B805BE7C32680B0F494DEAFF38F816 (void);
// 0x00000A70 System.Void AkBankManager::LoadBank(System.String,System.Boolean,System.Boolean)
extern void AkBankManager_LoadBank_m2FCDED8CCBE26E9012699F88428103CA152FFDB9 (void);
// 0x00000A71 System.Void AkBankManager::LoadBankAsync(System.String,AkCallbackManager_BankCallback)
extern void AkBankManager_LoadBankAsync_mB0619AEA4718877300B46F9110C9E96C1041A5D8 (void);
// 0x00000A72 System.Void AkBankManager::UnloadBank(System.String)
extern void AkBankManager_UnloadBank_m9403088BE5722AE8633024748E68EA2B3542FB28 (void);
// 0x00000A73 System.Void AkBankManager::.cctor()
extern void AkBankManager__cctor_m5F7502D173CAD5CFF49831283C70E7FA945E824C (void);
// 0x00000A74 System.String AkBasePathGetter::GetPlatformName()
extern void AkBasePathGetter_GetPlatformName_m5B6056F1A006F5D49F680D0DA0586D1073D05BF4 (void);
// 0x00000A75 System.Boolean AkBasePathGetter::get_LogWarnings()
extern void AkBasePathGetter_get_LogWarnings_m5370B844E65A0C5FA7C717FEDB8662C6E926B8E5 (void);
// 0x00000A76 System.Void AkBasePathGetter::set_LogWarnings(System.Boolean)
extern void AkBasePathGetter_set_LogWarnings_m52AC1ABC184B8130AB4B1C57B0E5C9E6D6A97D65 (void);
// 0x00000A77 System.String AkBasePathGetter::GetPlatformBasePath()
extern void AkBasePathGetter_GetPlatformBasePath_m8A61E9AAD685D6C3D5372A5AEB53A84907A1FC45 (void);
// 0x00000A78 System.Void AkBasePathGetter::EvaluateGamePaths()
extern void AkBasePathGetter_EvaluateGamePaths_m6FC8522650BC981090205D45E0B9BDBC42AD3621 (void);
// 0x00000A79 System.String AkBasePathGetter::get_SoundBankBasePath()
extern void AkBasePathGetter_get_SoundBankBasePath_mFF37914305D82413A6C5E4C7BEC774971FBF37DC (void);
// 0x00000A7A System.Void AkBasePathGetter::set_SoundBankBasePath(System.String)
extern void AkBasePathGetter_set_SoundBankBasePath_mCBDB3C66B5841313F1DC37A9345A10A5D8EA8C16 (void);
// 0x00000A7B System.String AkBasePathGetter::get_PersistentDataPath()
extern void AkBasePathGetter_get_PersistentDataPath_mA4694BE2FC23EEA6CE1C6A54D5CB2F4DD3F0C06D (void);
// 0x00000A7C System.Void AkBasePathGetter::set_PersistentDataPath(System.String)
extern void AkBasePathGetter_set_PersistentDataPath_m5567799489F0E42B7D2371CAB357EA214DBDC11A (void);
// 0x00000A7D System.String AkBasePathGetter::get_DecodedBankFullPath()
extern void AkBasePathGetter_get_DecodedBankFullPath_mE1FBE73F6FD2318F7FE1D086375D1C6339C2318D (void);
// 0x00000A7E System.Void AkBasePathGetter::set_DecodedBankFullPath(System.String)
extern void AkBasePathGetter_set_DecodedBankFullPath_m0AE2D4A3720FFA0E48F1CB4A3880DC3EA2A9D8F5 (void);
// 0x00000A7F System.Void AkBasePathGetter::.ctor()
extern void AkBasePathGetter__ctor_m55832DAC85D4A872CC404481281C9307D0F723EE (void);
// 0x00000A80 System.Void AkBasePathGetter::.cctor()
extern void AkBasePathGetter__cctor_m8E0383BD80196D3007236E8BD5F3BCFA95217867 (void);
// 0x00000A81 System.Boolean AkCallbackManager::get_IsLoggingEnabled()
extern void AkCallbackManager_get_IsLoggingEnabled_m747B56368C4A653CB85919E99FC1352C5372B349 (void);
// 0x00000A82 System.Void AkCallbackManager::set_IsLoggingEnabled(System.Boolean)
extern void AkCallbackManager_set_IsLoggingEnabled_mB3E093A8EFC5199C3FA0C8C3BEF3E851BC62125A (void);
// 0x00000A83 System.Void AkCallbackManager::RemoveEventCallback(System.UInt32)
extern void AkCallbackManager_RemoveEventCallback_m4904775CAC14A41BE5A819B12D1511DA1FA14D87 (void);
// 0x00000A84 System.Void AkCallbackManager::RemoveEventCallbackCookie(System.Object)
extern void AkCallbackManager_RemoveEventCallbackCookie_m5759FC16D1B084B4B66695C480D2153567B4AF95 (void);
// 0x00000A85 System.Void AkCallbackManager::RemoveBankCallback(System.Object)
extern void AkCallbackManager_RemoveBankCallback_m7728A8D046B1E8BFB5C18F80CB17170D72D92C18 (void);
// 0x00000A86 System.Void AkCallbackManager::SetLastAddedPlayingID(System.UInt32)
extern void AkCallbackManager_SetLastAddedPlayingID_m48467303044E493244505E875567C37617E33053 (void);
// 0x00000A87 System.Void AkCallbackManager::Init(AkCallbackManager_InitializationSettings)
extern void AkCallbackManager_Init_m3F3B56B493F15FC320D6A8C0AF23B0F81EA8C1FD (void);
// 0x00000A88 System.Void AkCallbackManager::Term()
extern void AkCallbackManager_Term_m72C2BC7F8410479B9991175247378E07FA57AD20 (void);
// 0x00000A89 System.Void AkCallbackManager::SetMonitoringCallback(AkMonitorErrorLevel,AkCallbackManager_MonitoringCallback)
extern void AkCallbackManager_SetMonitoringCallback_mACCE793124EFEE77BF7E1C0980DD6A30C15080C5 (void);
// 0x00000A8A System.Void AkCallbackManager::SetBGMCallback(AkCallbackManager_BGMCallback,System.Object)
extern void AkCallbackManager_SetBGMCallback_m0BBBE911E54745247F33E75A9A83121DF14181F7 (void);
// 0x00000A8B System.Int32 AkCallbackManager::PostCallbacks()
extern void AkCallbackManager_PostCallbacks_mD1DDCD4320730A9D510CD38DC6ECFEB930FF3F9F (void);
// 0x00000A8C System.Void AkCallbackManager::.cctor()
extern void AkCallbackManager__cctor_mA6744AE1AA229C05E3067DE7B2C99DE859F88B67 (void);
// 0x00000A8D AkInitializationSettings AkBasePlatformSettings::get_AkInitializationSettings()
extern void AkBasePlatformSettings_get_AkInitializationSettings_mF8DC5CCD8A11C78843814542E4C7F7E8CF365299 (void);
// 0x00000A8E AkSpatialAudioInitSettings AkBasePlatformSettings::get_AkSpatialAudioInitSettings()
extern void AkBasePlatformSettings_get_AkSpatialAudioInitSettings_mBC8B617C274C3429781243D47C76248D2C606B4D (void);
// 0x00000A8F AkCallbackManager_InitializationSettings AkBasePlatformSettings::get_CallbackManagerInitializationSettings()
extern void AkBasePlatformSettings_get_CallbackManagerInitializationSettings_m2A28AC2C1A78C944BA969B28F861F5895FA26BEC (void);
// 0x00000A90 System.String AkBasePlatformSettings::get_SoundBankPersistentDataPath()
extern void AkBasePlatformSettings_get_SoundBankPersistentDataPath_m325C39CD465D7363383AB38DD49BAC9C266F3FED (void);
// 0x00000A91 System.String AkBasePlatformSettings::get_InitialLanguage()
extern void AkBasePlatformSettings_get_InitialLanguage_m5BE09F487A79A07C0E002E2E178A86B3351E9453 (void);
// 0x00000A92 System.Boolean AkBasePlatformSettings::get_RenderDuringFocusLoss()
extern void AkBasePlatformSettings_get_RenderDuringFocusLoss_mB20AC116B0555D0D4AE45E2528CB682EB173586E (void);
// 0x00000A93 System.String AkBasePlatformSettings::get_SoundbankPath()
extern void AkBasePlatformSettings_get_SoundbankPath_m135AC92BE0A1715E568F6373F8DDD47E6DD18B32 (void);
// 0x00000A94 AkCommunicationSettings AkBasePlatformSettings::get_AkCommunicationSettings()
extern void AkBasePlatformSettings_get_AkCommunicationSettings_m3E06F499A7FB4554BC2F768F1F700146BC62414C (void);
// 0x00000A95 System.Boolean AkBasePlatformSettings::get_UseAsyncOpen()
extern void AkBasePlatformSettings_get_UseAsyncOpen_m91D8A83BD7556E9CC23019D7AD94D664D7BC8F8F (void);
// 0x00000A96 System.Void AkBasePlatformSettings::.ctor()
extern void AkBasePlatformSettings__ctor_m11C22C7D79830B8858541CB9711A6CACC0A5A1CA (void);
// 0x00000A97 System.Void AkCommonOutputSettings::CopyTo(AkOutputSettings)
extern void AkCommonOutputSettings_CopyTo_mBFC4B2D3A3780E6C5560F168607D9A515F0AF20F (void);
// 0x00000A98 System.Void AkCommonOutputSettings::.ctor()
extern void AkCommonOutputSettings__ctor_m8E8483E9FA3E153308674BE84A190B3FEE965631 (void);
// 0x00000A99 System.String AkCommonUserSettings::GetPluginPath()
extern void AkCommonUserSettings_GetPluginPath_m35131B8053333A7DAC9EBA011B56BD8ECC87001B (void);
// 0x00000A9A System.Void AkCommonUserSettings::CopyTo(AkInitSettings)
extern void AkCommonUserSettings_CopyTo_m755F95E2953EE469529F53914C008AEDB9A90099 (void);
// 0x00000A9B System.Void AkCommonUserSettings::CopyTo(AkMusicSettings)
extern void AkCommonUserSettings_CopyTo_m22E111D528FE6CB643832AD54B2A3D058CB55F02 (void);
// 0x00000A9C System.Void AkCommonUserSettings::CopyTo(AkStreamMgrSettings)
extern void AkCommonUserSettings_CopyTo_mBA2147CDA01F088919E470B631947AE3726C8452 (void);
// 0x00000A9D System.Void AkCommonUserSettings::CopyTo(AkDeviceSettings)
extern void AkCommonUserSettings_CopyTo_mD1238DDADE1198DDCBFE185D6A55AB5D3B549E8A (void);
// 0x00000A9E System.Void AkCommonUserSettings::SetSampleRate(AkPlatformInitSettings)
extern void AkCommonUserSettings_SetSampleRate_m96F55180D65227D9D877BC9D68940A1CA5367C00 (void);
// 0x00000A9F System.Void AkCommonUserSettings::CopyTo(AkPlatformInitSettings)
extern void AkCommonUserSettings_CopyTo_m396F597D4DFC2C07BC008D108032F712FCD94390 (void);
// 0x00000AA0 System.Void AkCommonUserSettings::CopyTo(AkSpatialAudioInitSettings)
extern void AkCommonUserSettings_CopyTo_mBB89CD013082F60521429F68FACE5EFE98800036 (void);
// 0x00000AA1 System.Void AkCommonUserSettings::CopyTo(AkUnityPlatformSpecificSettings)
extern void AkCommonUserSettings_CopyTo_mF8171036EBD3BCB224D8666A598B06A2D826A95F (void);
// 0x00000AA2 System.Void AkCommonUserSettings::Validate()
extern void AkCommonUserSettings_Validate_mB418D5C6D89D226D77946A7CE8077958940D401E (void);
// 0x00000AA3 System.Void AkCommonUserSettings::.ctor()
extern void AkCommonUserSettings__ctor_m593D8225F5CE79C4ED37EC23459735B911CC43C8 (void);
// 0x00000AA4 System.Void AkCommonAdvancedSettings::CopyTo(AkDeviceSettings)
extern void AkCommonAdvancedSettings_CopyTo_m2DE2246EABCD4AB5C30673AE4EA3D6B40624A0D0 (void);
// 0x00000AA5 System.Void AkCommonAdvancedSettings::CopyTo(AkInitSettings)
extern void AkCommonAdvancedSettings_CopyTo_m6EDDDD3C7A1E8507EF57550D4BAB8180FEEF5FD7 (void);
// 0x00000AA6 System.Void AkCommonAdvancedSettings::CopyTo(AkPlatformInitSettings)
extern void AkCommonAdvancedSettings_CopyTo_m010250A32CCD4FF7BDEF95953819E67C586BA805 (void);
// 0x00000AA7 System.Void AkCommonAdvancedSettings::CopyTo(AkUnityPlatformSpecificSettings)
extern void AkCommonAdvancedSettings_CopyTo_mAB2693F2D3F70071CD816F64FBF2A6E35AD06286 (void);
// 0x00000AA8 System.Void AkCommonAdvancedSettings::.ctor()
extern void AkCommonAdvancedSettings__ctor_m462DBC7E0D14B54C55783D18D1EC3E6B4DBD1A07 (void);
// 0x00000AA9 System.Void AkCommonCommSettings::CopyTo(AkCommunicationSettings)
extern void AkCommonCommSettings_CopyTo_m857E7F597EEC0217D7B4FF0DA3E8353DECC507A0 (void);
// 0x00000AAA System.Void AkCommonCommSettings::Validate()
extern void AkCommonCommSettings_Validate_m71E12AF8552FD41AD18057817C76F9BD627FE551 (void);
// 0x00000AAB System.Void AkCommonCommSettings::.ctor()
extern void AkCommonCommSettings__ctor_m5FD6925417E746A998076939D3996425BD85F5C2 (void);
// 0x00000AAC System.Void AkCommonCommSettings::.cctor()
extern void AkCommonCommSettings__cctor_m68E62D5BE7995925B8172E8697049F6307B49FE3 (void);
// 0x00000AAD AkCommonUserSettings AkCommonPlatformSettings::GetUserSettings()
// 0x00000AAE AkCommonAdvancedSettings AkCommonPlatformSettings::GetAdvancedSettings()
// 0x00000AAF AkCommonCommSettings AkCommonPlatformSettings::GetCommsSettings()
// 0x00000AB0 AkInitializationSettings AkCommonPlatformSettings::get_AkInitializationSettings()
extern void AkCommonPlatformSettings_get_AkInitializationSettings_m20AD5A940DD50BA40716BF8B1B921D25C1F27E5A (void);
// 0x00000AB1 AkSpatialAudioInitSettings AkCommonPlatformSettings::get_AkSpatialAudioInitSettings()
extern void AkCommonPlatformSettings_get_AkSpatialAudioInitSettings_m458D2A3B0BA7FACC8C8D1A037B93CA68A604B086 (void);
// 0x00000AB2 AkCallbackManager_InitializationSettings AkCommonPlatformSettings::get_CallbackManagerInitializationSettings()
extern void AkCommonPlatformSettings_get_CallbackManagerInitializationSettings_mDB7719F782946466BA24F9D51166AAAA7B94784E (void);
// 0x00000AB3 System.String AkCommonPlatformSettings::get_InitialLanguage()
extern void AkCommonPlatformSettings_get_InitialLanguage_mE611A9617BF895865869E9AA0775DD187A8A2A22 (void);
// 0x00000AB4 System.String AkCommonPlatformSettings::get_SoundBankPersistentDataPath()
extern void AkCommonPlatformSettings_get_SoundBankPersistentDataPath_m00B99FD30F5569B138648324D97D49C3AD5E7D8E (void);
// 0x00000AB5 System.Boolean AkCommonPlatformSettings::get_RenderDuringFocusLoss()
extern void AkCommonPlatformSettings_get_RenderDuringFocusLoss_m873AD4FE9B86DDF19BC1BF9B774400A089A4088E (void);
// 0x00000AB6 System.String AkCommonPlatformSettings::get_SoundbankPath()
extern void AkCommonPlatformSettings_get_SoundbankPath_m1038DF225B1B3EEFEE6C166B5E6EAAF4D73F923A (void);
// 0x00000AB7 System.Boolean AkCommonPlatformSettings::get_UseAsyncOpen()
extern void AkCommonPlatformSettings_get_UseAsyncOpen_m31C94249938FC5B8C5C927D8B1B91D6DDB6F2E25 (void);
// 0x00000AB8 AkCommunicationSettings AkCommonPlatformSettings::get_AkCommunicationSettings()
extern void AkCommonPlatformSettings_get_AkCommunicationSettings_m79DF1B391C4EC98150A1DAF29CF943CEA01EA162 (void);
// 0x00000AB9 System.Void AkCommonPlatformSettings::.ctor()
extern void AkCommonPlatformSettings__ctor_m6677F3BE8ED33C74C0A87E8A92F83F351C5151C2 (void);
// 0x00000ABA System.Void AkEnumFlagAttribute::.ctor(System.Type)
extern void AkEnumFlagAttribute__ctor_mB576291CEF8DDADB9F11862CE9EB6162606D626A (void);
// 0x00000ABB System.Void AkLogger::.ctor()
extern void AkLogger__ctor_mFB694A090E52BDC67C4DDBB9CA7994A89F305BBD (void);
// 0x00000ABC AkLogger AkLogger::get_Instance()
extern void AkLogger_get_Instance_mFAA1F4D1F73B3E58F1318E4F400BDDB3B4B4B111 (void);
// 0x00000ABD System.Void AkLogger::Finalize()
extern void AkLogger_Finalize_m39137B18876DBDA1B1DFD0FF5F052BE4FA6B9696 (void);
// 0x00000ABE System.Void AkLogger::Init()
extern void AkLogger_Init_m18A46EAD20BAE9AF7A1599CAD5BA57A9F4D135FA (void);
// 0x00000ABF System.Void AkLogger::WwiseInternalLogError(System.String)
extern void AkLogger_WwiseInternalLogError_m74B4525C94A2B9D382CF3025E8B7AE1CBE92EA8A (void);
// 0x00000AC0 System.Void AkLogger::Message(System.String)
extern void AkLogger_Message_m215F343D0F5A090192D4EC152E7DA5862A78466B (void);
// 0x00000AC1 System.Void AkLogger::Warning(System.String)
extern void AkLogger_Warning_mE93F27F246C4B6F4E807A1A5A2EBE1F7649D4EF7 (void);
// 0x00000AC2 System.Void AkLogger::Error(System.String)
extern void AkLogger_Error_mE29B2156E521C9C134F92F937CFFD44A381608B8 (void);
// 0x00000AC3 System.Void AkLogger::.cctor()
extern void AkLogger__cctor_m0A405E34989E06C75665F7BF26642E3501188AC7 (void);
// 0x00000AC4 System.Void AkShowOnlyAttribute::.ctor()
extern void AkShowOnlyAttribute__ctor_mBEF724F5E2DBE9829879733367E315763B21A0C5 (void);
// 0x00000AC5 System.Void AkUtilities::FixSlashes(System.String&,System.Char,System.Char,System.Boolean)
extern void AkUtilities_FixSlashes_mA0743D33CAC05020465751B0019718C69DF4E9C5 (void);
// 0x00000AC6 System.Void AkUtilities::FixSlashes(System.String&)
extern void AkUtilities_FixSlashes_mB334E8159887FC2BA232AB25DCFC38B7571BF5AB (void);
// 0x00000AC7 System.String AkUtilities::GetPathInPackage(System.String)
extern void AkUtilities_GetPathInPackage_mA932A5B99B5773048356F649D3820433C3ABA34C (void);
// 0x00000AC8 System.Void AkUtilities::.ctor()
extern void AkUtilities__ctor_mE963EE8469289270C6245C4D440B046B18FD9B95 (void);
// 0x00000AC9 System.Void AkVector::Zero()
extern void AkVector_Zero_mFCAE57AE094FDE2AC58B7B9DA42B418C5836AFD7 (void);
// 0x00000ACA System.Void AkVector::set_X(System.Single)
extern void AkVector_set_X_m6B3A9C5A7B395D3B65A94FBE82811ADE336CE437 (void);
// 0x00000ACB System.Single AkVector::get_X()
extern void AkVector_get_X_m2ECE56E65C77131BE9AEC5C3EA9F24E4E3A0F20E (void);
// 0x00000ACC System.Void AkVector::set_Y(System.Single)
extern void AkVector_set_Y_m54129B134C34D2DA8E729062D3507791F9D1BA2D (void);
// 0x00000ACD System.Single AkVector::get_Y()
extern void AkVector_get_Y_m20BF983A1E113D50600FE308AA795D378B9F33E3 (void);
// 0x00000ACE System.Void AkVector::set_Z(System.Single)
extern void AkVector_set_Z_m2B4EF55114D6C4C7C580A1584962B0528E842A8B (void);
// 0x00000ACF System.Single AkVector::get_Z()
extern void AkVector_get_Z_m3BC08A869D45D3E00C75DFF05DAA32D0539F31AB (void);
// 0x00000AD0 UnityEngine.Vector3 AkVector::op_Implicit(AkVector)
extern void AkVector_op_Implicit_m2EA3A8F2DA43F97EEF626213FCA051CF587C2695 (void);
// 0x00000AD1 System.Void AkVector::.ctor()
extern void AkVector__ctor_m3EBFF473ECA73553A3413B2EA675638145DA9BBB (void);
// 0x00000AD2 System.Void AkVertex::Zero()
extern void AkVertex_Zero_m9EADA834FB0956E15ACED8D0EF21AB58931797FF (void);
// 0x00000AD3 System.Void AkVertex::set_X(System.Single)
extern void AkVertex_set_X_m34B7C25FBD05F7C287663C6525B02BF1725CF48B (void);
// 0x00000AD4 System.Single AkVertex::get_X()
extern void AkVertex_get_X_mDA0462C5A59588C2CA05C3610F233B5E3FF89144 (void);
// 0x00000AD5 System.Void AkVertex::set_Y(System.Single)
extern void AkVertex_set_Y_m300FDF1E5000A819872515F52E8C15482BC99B9D (void);
// 0x00000AD6 System.Single AkVertex::get_Y()
extern void AkVertex_get_Y_m4B629761B224C778A1222B031460C087DB0E6F7E (void);
// 0x00000AD7 System.Void AkVertex::set_Z(System.Single)
extern void AkVertex_set_Z_m9BDB8CBBE1B2B1B14E87036A5A4468026C33D132 (void);
// 0x00000AD8 System.Single AkVertex::get_Z()
extern void AkVertex_get_Z_mDB8C6082A12E70B1BEDEED47310A21891ABD79B0 (void);
// 0x00000AD9 UnityEngine.Vector3 AkVertex::op_Implicit(AkVertex)
extern void AkVertex_op_Implicit_m551F2293DDF4D6A62B5531A5A9E770A0AB2B8E96 (void);
// 0x00000ADA System.Void AkVertex::.ctor()
extern void AkVertex__ctor_m2C3F33BCA3E6623D4B8FFB52DB1C2BAAF9C90B70 (void);
// 0x00000ADB System.Void AkVertex::.ctor(System.Single,System.Single,System.Single)
extern void AkVertex__ctor_m318ABB5D37113E249747436197EB1630D6E7B525 (void);
// 0x00000ADC System.Void AkVertex::Clear()
extern void AkVertex_Clear_m5CCC6157E7554BC3C1176DC3A35AB45834A39E05 (void);
// 0x00000ADD System.Int32 AkVertex::GetSizeOf()
extern void AkVertex_GetSizeOf_m027E4C8CE2D36A9390CF2C368E23BD278A08323E (void);
// 0x00000ADE System.Void AkVertex::Clone(AkVertex)
extern void AkVertex_Clone_m40681415E2A8A76506117A7247C68A2F530A5E85 (void);
// 0x00000ADF System.Void AkVertexArray::.ctor(System.Int32)
extern void AkVertexArray__ctor_m2F2BF210C5C3B6750F16396821113BA793FB1987 (void);
// 0x00000AE0 System.Int32 AkVertexArray::get_StructureSize()
extern void AkVertexArray_get_StructureSize_m2550E15C5855E683E252BC8337F82E4B874C315E (void);
// 0x00000AE1 AkVertex AkVertexArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkVertexArray_CreateNewReferenceFromIntPtr_m5654D2FEB6F076A2B099C3EA858816B4F05FBEA7 (void);
// 0x00000AE2 System.Void AkVertexArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkVertex)
extern void AkVertexArray_CloneIntoReferenceFromIntPtr_m7F3A4D7CA6C1FFA51151BE50900B87E858D5B332 (void);
// 0x00000AE3 System.Boolean AkWwiseInitializationSettings::get_IsValid()
extern void AkWwiseInitializationSettings_get_IsValid_mC25AC4417E256701AC45689504123E26FBC1B488 (void);
// 0x00000AE4 System.Int32 AkWwiseInitializationSettings::get_Count()
extern void AkWwiseInitializationSettings_get_Count_m52BD1806B0C99740C92724849743852D7A52B1B6 (void);
// 0x00000AE5 AkCommonUserSettings AkWwiseInitializationSettings::GetUserSettings()
extern void AkWwiseInitializationSettings_GetUserSettings_m7E445567B7AA9E05A45444AE98EFFA2F0D6977F5 (void);
// 0x00000AE6 AkCommonAdvancedSettings AkWwiseInitializationSettings::GetAdvancedSettings()
extern void AkWwiseInitializationSettings_GetAdvancedSettings_m75BC8A846DD4B7CD8A18E0EBDDCFB7147252E9C5 (void);
// 0x00000AE7 AkCommonCommSettings AkWwiseInitializationSettings::GetCommsSettings()
extern void AkWwiseInitializationSettings_GetCommsSettings_mE11B0655D91E5D44AECDE291DBF98185971F102C (void);
// 0x00000AE8 AkWwiseInitializationSettings AkWwiseInitializationSettings::get_Instance()
extern void AkWwiseInitializationSettings_get_Instance_m6E6FB63FA5E48DF5452447107F3363D57B7974D8 (void);
// 0x00000AE9 AkBasePlatformSettings AkWwiseInitializationSettings::GetPlatformSettings(System.String)
extern void AkWwiseInitializationSettings_GetPlatformSettings_mC4936C945D36BE10EEA8546EB4FD20EADE3802AF (void);
// 0x00000AEA AkBasePlatformSettings AkWwiseInitializationSettings::get_ActivePlatformSettings()
extern void AkWwiseInitializationSettings_get_ActivePlatformSettings_m0B310444793AB12260C0FC8339EB7D82CE925C14 (void);
// 0x00000AEB System.Void AkWwiseInitializationSettings::OnEnable()
extern void AkWwiseInitializationSettings_OnEnable_mDE6578AEBADCA5449BE8B069B1B91C33521491F4 (void);
// 0x00000AEC System.Boolean AkWwiseInitializationSettings::InitializeSoundEngine()
extern void AkWwiseInitializationSettings_InitializeSoundEngine_mD3E127DF97C7704A311BBE1B11F122CAE19A2E4B (void);
// 0x00000AED System.Void AkWwiseInitializationSettings::LoadInitBank()
extern void AkWwiseInitializationSettings_LoadInitBank_mC6F30BC60D6D9CD98A0A3DA43E87BB73A3CB8EF7 (void);
// 0x00000AEE System.Void AkWwiseInitializationSettings::ClearBanks()
extern void AkWwiseInitializationSettings_ClearBanks_mC07824E6D1FA0679D69CDFCC867C4081C7117434 (void);
// 0x00000AEF System.Void AkWwiseInitializationSettings::ResetBanks()
extern void AkWwiseInitializationSettings_ResetBanks_mDA9BAA324B3FD9CBC9970769AB0D211423873B4E (void);
// 0x00000AF0 System.Boolean AkWwiseInitializationSettings::ResetSoundEngine(System.Boolean)
extern void AkWwiseInitializationSettings_ResetSoundEngine_m5F5F77BEDFD0D9143A6E212A648568560A248A74 (void);
// 0x00000AF1 System.Void AkWwiseInitializationSettings::TerminateSoundEngine()
extern void AkWwiseInitializationSettings_TerminateSoundEngine_m0236F55ECF2973E4490DD05099865593E08E8A0D (void);
// 0x00000AF2 System.Void AkWwiseInitializationSettings::SleepForMilliseconds(System.Double)
extern void AkWwiseInitializationSettings_SleepForMilliseconds_m7292C0FD27A810D44F5C3375D3DC5D4DD9CA9F9E (void);
// 0x00000AF3 System.Void AkWwiseInitializationSettings::.ctor()
extern void AkWwiseInitializationSettings__ctor_mF696F4D9DE9F2E0755944A483E6673959810ADFE (void);
// 0x00000AF4 System.Void AkWwiseInitializationSettings::.cctor()
extern void AkWwiseInitializationSettings__cctor_mBD1E8D0EE71CF82F28771D814DBCB19DF86405AD (void);
// 0x00000AF5 System.Void AkAcousticSurfaceArray::.ctor(System.Int32)
extern void AkAcousticSurfaceArray__ctor_mFB01E32E3367DB49C6BE86D9390A6692B6A719B9 (void);
// 0x00000AF6 System.Int32 AkAcousticSurfaceArray::get_StructureSize()
extern void AkAcousticSurfaceArray_get_StructureSize_mE6101C8DF3767C6F116341B6D4E66AEFD765150F (void);
// 0x00000AF7 System.Void AkAcousticSurfaceArray::DefaultConstructAtIntPtr(System.IntPtr)
extern void AkAcousticSurfaceArray_DefaultConstructAtIntPtr_m6BD558FBBAF254AE74B2E164E579D6C6ED253101 (void);
// 0x00000AF8 AkAcousticSurface AkAcousticSurfaceArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkAcousticSurfaceArray_CreateNewReferenceFromIntPtr_m881A879B41F35DF16178D6373A665EE72FE096D3 (void);
// 0x00000AF9 System.Void AkAcousticSurfaceArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkAcousticSurface)
extern void AkAcousticSurfaceArray_CloneIntoReferenceFromIntPtr_mE9F99459B3E6FE4C66AE26D965B1F9F3E3DD519D (void);
// 0x00000AFA System.Void AkAuxSendArray::.ctor()
extern void AkAuxSendArray__ctor_m2CC55DBE0CE4988F5B6221F2E4975C74DFA9DE4B (void);
// 0x00000AFB AkAuxSendValue AkAuxSendArray::get_Item(System.Int32)
extern void AkAuxSendArray_get_Item_mA0BCF03E5CAFDAD341C17B9D1F0B6F7B66FB59D9 (void);
// 0x00000AFC System.Boolean AkAuxSendArray::get_isFull()
extern void AkAuxSendArray_get_isFull_m6C3C7E9938B4FF760F110701C83C493FFEBD19EE (void);
// 0x00000AFD System.Void AkAuxSendArray::Dispose()
extern void AkAuxSendArray_Dispose_m5F8574B54A165EC206E91453AAD05907AB66C2A7 (void);
// 0x00000AFE System.Void AkAuxSendArray::Finalize()
extern void AkAuxSendArray_Finalize_m8BB0B410D23E99C8EE553FE96EC555ECB0E6A370 (void);
// 0x00000AFF System.Void AkAuxSendArray::Reset()
extern void AkAuxSendArray_Reset_m82D457CD9D77A0F7E3481C5C4A003BC22077F07D (void);
// 0x00000B00 System.Boolean AkAuxSendArray::Add(UnityEngine.GameObject,System.UInt32,System.Single)
extern void AkAuxSendArray_Add_mC8F9C0BACA0C54F85D47F9A14C4882FF2D93B003 (void);
// 0x00000B01 System.Boolean AkAuxSendArray::Add(System.UInt32,System.Single)
extern void AkAuxSendArray_Add_m0130263D8274B5A73B014595A7CE9FD6EDB790EA (void);
// 0x00000B02 System.Boolean AkAuxSendArray::Contains(UnityEngine.GameObject,System.UInt32)
extern void AkAuxSendArray_Contains_m57C6986BA08D9A94649279E5D5597212E5ADECDA (void);
// 0x00000B03 System.Boolean AkAuxSendArray::Contains(System.UInt32)
extern void AkAuxSendArray_Contains_m59668BE9FB75EC174A8481D42E0102640A7E556C (void);
// 0x00000B04 AKRESULT AkAuxSendArray::SetValues(UnityEngine.GameObject)
extern void AkAuxSendArray_SetValues_mA58AC0E878ED32CFAD1665C8B64A84373A93D64B (void);
// 0x00000B05 AKRESULT AkAuxSendArray::GetValues(UnityEngine.GameObject)
extern void AkAuxSendArray_GetValues_m44062710BD760F5947B97A55F2775BBF57898270 (void);
// 0x00000B06 System.IntPtr AkAuxSendArray::GetBuffer()
extern void AkAuxSendArray_GetBuffer_m3A1829A42DA19A3ECBA04C1C5BF26BC421F95AEE (void);
// 0x00000B07 System.Int32 AkAuxSendArray::Count()
extern void AkAuxSendArray_Count_m3B071A1EC18E11E1F31658988E65572E4207E385 (void);
// 0x00000B08 System.IntPtr AkAuxSendArray::GetObjectPtr(System.Int32)
extern void AkAuxSendArray_GetObjectPtr_m304DFF898EA8A6699E7C608A6C831839ECE78CA9 (void);
// 0x00000B09 System.Void AkBaseArray`1::.ctor(System.Int32)
// 0x00000B0A System.Void AkBaseArray`1::Dispose()
// 0x00000B0B System.Void AkBaseArray`1::Finalize()
// 0x00000B0C System.Int32 AkBaseArray`1::get_Capacity()
// 0x00000B0D System.Void AkBaseArray`1::set_Capacity(System.Int32)
// 0x00000B0E System.Int32 AkBaseArray`1::Count()
// 0x00000B0F System.Int32 AkBaseArray`1::get_StructureSize()
// 0x00000B10 System.Void AkBaseArray`1::DefaultConstructAtIntPtr(System.IntPtr)
// 0x00000B11 System.Void AkBaseArray`1::ReleaseAllocatedMemoryFromReferenceAtIntPtr(System.IntPtr)
// 0x00000B12 T AkBaseArray`1::CreateNewReferenceFromIntPtr(System.IntPtr)
// 0x00000B13 System.Void AkBaseArray`1::CloneIntoReferenceFromIntPtr(System.IntPtr,T)
// 0x00000B14 T AkBaseArray`1::get_Item(System.Int32)
// 0x00000B15 System.Void AkBaseArray`1::set_Item(System.Int32,T)
// 0x00000B16 System.IntPtr AkBaseArray`1::GetBuffer()
// 0x00000B17 System.IntPtr AkBaseArray`1::GetObjectPtr(System.Int32)
// 0x00000B18 System.Void AkChannelEmitterArray::.ctor(System.UInt32)
extern void AkChannelEmitterArray__ctor_m63B72D3DBB381CDA0DFB1677BD8E4D8AC2BCDA48 (void);
// 0x00000B19 System.UInt32 AkChannelEmitterArray::get_Count()
extern void AkChannelEmitterArray_get_Count_mECFF4AB75A258C161EA9FBD3EDDB946AFF3244CF (void);
// 0x00000B1A System.Void AkChannelEmitterArray::set_Count(System.UInt32)
extern void AkChannelEmitterArray_set_Count_m1922B570DA1A40D8E7C87A92566E1BCDFC23D54A (void);
// 0x00000B1B System.Void AkChannelEmitterArray::Dispose()
extern void AkChannelEmitterArray_Dispose_m36F114D62F3B238DC9534C6E2940DA4E7F442E70 (void);
// 0x00000B1C System.Void AkChannelEmitterArray::Finalize()
extern void AkChannelEmitterArray_Finalize_m2DB38CDE7CE2259449E5B66EF222E5BE499140B0 (void);
// 0x00000B1D System.Void AkChannelEmitterArray::Reset()
extern void AkChannelEmitterArray_Reset_mD53F20CFDFD92963629533EF282735F895242796 (void);
// 0x00000B1E System.Void AkChannelEmitterArray::Add(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.UInt32)
extern void AkChannelEmitterArray_Add_m47EFA9678BD96F657221DF5057A206B87E751986 (void);
// 0x00000B1F System.Void AkDeviceDescriptionArray::.ctor(System.Int32)
extern void AkDeviceDescriptionArray__ctor_m3DC91301ABAC77194D02AAAAA89D945E5FCDA734 (void);
// 0x00000B20 System.Int32 AkDeviceDescriptionArray::get_StructureSize()
extern void AkDeviceDescriptionArray_get_StructureSize_mFB5B17D28324B689264FB2C657552537D4AF5C0C (void);
// 0x00000B21 System.Void AkDeviceDescriptionArray::DefaultConstructAtIntPtr(System.IntPtr)
extern void AkDeviceDescriptionArray_DefaultConstructAtIntPtr_m365D24254CFB386E8BD9B9C75BE0C129E88D9904 (void);
// 0x00000B22 AkDeviceDescription AkDeviceDescriptionArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkDeviceDescriptionArray_CreateNewReferenceFromIntPtr_m7F2565E85AC6B55B49371F0AA061161C3746177B (void);
// 0x00000B23 System.Void AkDeviceDescriptionArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkDeviceDescription)
extern void AkDeviceDescriptionArray_CloneIntoReferenceFromIntPtr_m507146ED5FF33208419AB1159ED2D34E10F6D1B3 (void);
// 0x00000B24 System.Void AkDiffractionPathInfoArray::.ctor(System.Int32)
extern void AkDiffractionPathInfoArray__ctor_m5870A0095AB3EB37BBE047914C651B69BDEA4B93 (void);
// 0x00000B25 System.Int32 AkDiffractionPathInfoArray::get_StructureSize()
extern void AkDiffractionPathInfoArray_get_StructureSize_mFC9D4E45C28D855E6CDD68DAD394CBCE671DE43A (void);
// 0x00000B26 AkDiffractionPathInfo AkDiffractionPathInfoArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkDiffractionPathInfoArray_CreateNewReferenceFromIntPtr_mFAF76507F219F20D477F112764652A21CFD6B9AA (void);
// 0x00000B27 System.Void AkDiffractionPathInfoArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkDiffractionPathInfo)
extern void AkDiffractionPathInfoArray_CloneIntoReferenceFromIntPtr_mEAE294D36604AA64F562827D902CE6E7045A6694 (void);
// 0x00000B28 System.Void AkExternalSourceInfoArray::.ctor(System.Int32)
extern void AkExternalSourceInfoArray__ctor_m49432949AB060DE6F3DCE44D0E38B046C5273135 (void);
// 0x00000B29 System.Int32 AkExternalSourceInfoArray::get_StructureSize()
extern void AkExternalSourceInfoArray_get_StructureSize_m9F8FC9ED4DBB6E31D04F8705C159D512EC12E86F (void);
// 0x00000B2A System.Void AkExternalSourceInfoArray::DefaultConstructAtIntPtr(System.IntPtr)
extern void AkExternalSourceInfoArray_DefaultConstructAtIntPtr_m9898F8A9D889A6552F4EE4954CD826C726ED1567 (void);
// 0x00000B2B System.Void AkExternalSourceInfoArray::ReleaseAllocatedMemoryFromReferenceAtIntPtr(System.IntPtr)
extern void AkExternalSourceInfoArray_ReleaseAllocatedMemoryFromReferenceAtIntPtr_m316DA1BFBDEBD18EEAF4296EE5A3F5310F8356E8 (void);
// 0x00000B2C AkExternalSourceInfo AkExternalSourceInfoArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkExternalSourceInfoArray_CreateNewReferenceFromIntPtr_m50B0A42A19B41AEEF24D4553EEF60A0E0AF4A70D (void);
// 0x00000B2D System.Void AkExternalSourceInfoArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkExternalSourceInfo)
extern void AkExternalSourceInfoArray_CloneIntoReferenceFromIntPtr_m5CF791D5962130F972DEE26F1EE0284371A0C813 (void);
// 0x00000B2E System.Void AkMIDIPostArray::.ctor(System.Int32)
extern void AkMIDIPostArray__ctor_m42B1CEA21201A93C91DDD89E202EA7153FF73F86 (void);
// 0x00000B2F AkMIDIPost AkMIDIPostArray::get_Item(System.Int32)
extern void AkMIDIPostArray_get_Item_m4B16DB53F8970AFE08031B126C5F913E42C437F3 (void);
// 0x00000B30 System.Void AkMIDIPostArray::set_Item(System.Int32,AkMIDIPost)
extern void AkMIDIPostArray_set_Item_mB38DF3927B096DE29F531461642C7E82F4B06AA6 (void);
// 0x00000B31 System.Void AkMIDIPostArray::Finalize()
extern void AkMIDIPostArray_Finalize_m49E30F77C094B7BEF1F4481D42696C2701A7481F (void);
// 0x00000B32 System.Void AkMIDIPostArray::PostOnEvent(System.UInt32,UnityEngine.GameObject)
extern void AkMIDIPostArray_PostOnEvent_m66EC148F3ABCB245B84A636549488C4ACFF6FD4D (void);
// 0x00000B33 System.Void AkMIDIPostArray::PostOnEvent(System.UInt32,UnityEngine.GameObject,System.Int32)
extern void AkMIDIPostArray_PostOnEvent_mFA194E3A82334997EF5B4C7FFC44ED64668CBE79 (void);
// 0x00000B34 System.IntPtr AkMIDIPostArray::GetBuffer()
extern void AkMIDIPostArray_GetBuffer_mE90D18001F03BCB84107423C32CEDAB8FC0D9DB3 (void);
// 0x00000B35 System.Int32 AkMIDIPostArray::Count()
extern void AkMIDIPostArray_Count_m404ACDFB587655E03A42837AED589ED9228BCF86 (void);
// 0x00000B36 System.IntPtr AkMIDIPostArray::GetObjectPtr(System.Int32)
extern void AkMIDIPostArray_GetObjectPtr_mEA27EC60CD0E4F5933B6E99D97F31096288292CF (void);
// 0x00000B37 System.Void AkObjectInfoArray::.ctor(System.Int32)
extern void AkObjectInfoArray__ctor_mE638E5B2551282C1DDFD1412908CBDAD48529B32 (void);
// 0x00000B38 System.Int32 AkObjectInfoArray::get_StructureSize()
extern void AkObjectInfoArray_get_StructureSize_mA6CE34433A5DF2210A7867125A24A50A6987E391 (void);
// 0x00000B39 System.Void AkObjectInfoArray::DefaultConstructAtIntPtr(System.IntPtr)
extern void AkObjectInfoArray_DefaultConstructAtIntPtr_m4DA52E071AB2F8F50FDE23D64980A8F741ED376E (void);
// 0x00000B3A AkObjectInfo AkObjectInfoArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkObjectInfoArray_CreateNewReferenceFromIntPtr_mD5E42F280B800F36EA8D44FDC794516EFC2D8EB4 (void);
// 0x00000B3B System.Void AkObjectInfoArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkObjectInfo)
extern void AkObjectInfoArray_CloneIntoReferenceFromIntPtr_m9299C579512EFF3F873D7A4D4B1F64363DD3F54A (void);
// 0x00000B3C System.Void AkObstructionOcclusionValuesArray::.ctor(System.Int32)
extern void AkObstructionOcclusionValuesArray__ctor_m4F681ACDB369D85A25A2365D6B81A653118EDB78 (void);
// 0x00000B3D System.Int32 AkObstructionOcclusionValuesArray::get_StructureSize()
extern void AkObstructionOcclusionValuesArray_get_StructureSize_m47AB19A8E6FBFA7D8FB0B4BE3E88B64E7A750FD2 (void);
// 0x00000B3E System.Void AkObstructionOcclusionValuesArray::DefaultConstructAtIntPtr(System.IntPtr)
extern void AkObstructionOcclusionValuesArray_DefaultConstructAtIntPtr_m943659761634AFA044564E73DB3B9BBC4CAA01C6 (void);
// 0x00000B3F AkObstructionOcclusionValues AkObstructionOcclusionValuesArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkObstructionOcclusionValuesArray_CreateNewReferenceFromIntPtr_mBAE5CF74CC0700B1C2D776DF77A1B7E46E82C054 (void);
// 0x00000B40 System.Void AkObstructionOcclusionValuesArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkObstructionOcclusionValues)
extern void AkObstructionOcclusionValuesArray_CloneIntoReferenceFromIntPtr_m02C4ADC7608E9ECE549C50F07552CF55B973B2D1 (void);
// 0x00000B41 System.Void AkPositionArray::.ctor(System.UInt32)
extern void AkPositionArray__ctor_mDBD619966527FE9A680E70FFA5DB806ABF6D0384 (void);
// 0x00000B42 System.UInt32 AkPositionArray::get_Count()
extern void AkPositionArray_get_Count_m36D2BB7C64B6B913D5EF1E88F8374E079CDFB780 (void);
// 0x00000B43 System.Void AkPositionArray::set_Count(System.UInt32)
extern void AkPositionArray_set_Count_mEA3274A0672D52D690E3443DDD332C5E72606A92 (void);
// 0x00000B44 System.Void AkPositionArray::Dispose()
extern void AkPositionArray_Dispose_mA7A51D8147C23C806BA0609E7D43FA71F39E0D86 (void);
// 0x00000B45 System.Void AkPositionArray::Finalize()
extern void AkPositionArray_Finalize_mB2FD5C94858BEEC95FC3EA052F070595550E22D8 (void);
// 0x00000B46 System.Void AkPositionArray::Reset()
extern void AkPositionArray_Reset_mCBFB27259756774AD5955801D4BE7AF7F0B21CEC (void);
// 0x00000B47 System.Void AkPositionArray::Add(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void AkPositionArray_Add_m92B7D8F91A43E0417FF5CC04776B1D470CDF91A4 (void);
// 0x00000B48 System.Void AkReflectionPathInfoArray::.ctor(System.Int32)
extern void AkReflectionPathInfoArray__ctor_m01635A85C9EE987415065062390F6D29DE4FCA95 (void);
// 0x00000B49 System.Int32 AkReflectionPathInfoArray::get_StructureSize()
extern void AkReflectionPathInfoArray_get_StructureSize_mB54901CF97FA0D19C3944A744A0CFF76BEAF8732 (void);
// 0x00000B4A AkReflectionPathInfo AkReflectionPathInfoArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkReflectionPathInfoArray_CreateNewReferenceFromIntPtr_m33EF46DBAD88331306F282E716582D65D6E9C750 (void);
// 0x00000B4B System.Void AkReflectionPathInfoArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkReflectionPathInfo)
extern void AkReflectionPathInfoArray_CloneIntoReferenceFromIntPtr_m00E59C43A8667C174134659A8A7AC1BE47ADE2B4 (void);
// 0x00000B4C System.Void AkSourceSettingsArray::.ctor(System.Int32)
extern void AkSourceSettingsArray__ctor_m6FA8739924BB2E8501DB32B1474AD33C486D8480 (void);
// 0x00000B4D System.Int32 AkSourceSettingsArray::get_StructureSize()
extern void AkSourceSettingsArray_get_StructureSize_m5191F056647DCFAF521115AD2D4AEDEEFDA0144D (void);
// 0x00000B4E System.Void AkSourceSettingsArray::DefaultConstructAtIntPtr(System.IntPtr)
extern void AkSourceSettingsArray_DefaultConstructAtIntPtr_mABE845681DFF04332364F42B5C00C4C00B094D51 (void);
// 0x00000B4F AkSourceSettings AkSourceSettingsArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkSourceSettingsArray_CreateNewReferenceFromIntPtr_m73980A42690C971527ED3BC3A42E9BA22D93F868 (void);
// 0x00000B50 System.Void AkSourceSettingsArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkSourceSettings)
extern void AkSourceSettingsArray_CloneIntoReferenceFromIntPtr_m4F5E129B34788867E25563150D03A56BE315E544 (void);
// 0x00000B51 System.Void AkTriangleArray::.ctor(System.Int32)
extern void AkTriangleArray__ctor_mFB8C29919EF377DA27A2D2C884822F691BEE00A3 (void);
// 0x00000B52 System.Int32 AkTriangleArray::get_StructureSize()
extern void AkTriangleArray_get_StructureSize_m62BC1DAC02180D51AA7F8EAA9009F5E6ACF674FA (void);
// 0x00000B53 System.Void AkTriangleArray::DefaultConstructAtIntPtr(System.IntPtr)
extern void AkTriangleArray_DefaultConstructAtIntPtr_m4F68267CAF24FF6FFC59BC3F9C00608D208A08E5 (void);
// 0x00000B54 AkTriangle AkTriangleArray::CreateNewReferenceFromIntPtr(System.IntPtr)
extern void AkTriangleArray_CreateNewReferenceFromIntPtr_mC6A7291A09B5DDA03A65E9BB3D9E7EDF0663E7CA (void);
// 0x00000B55 System.Void AkTriangleArray::CloneIntoReferenceFromIntPtr(System.IntPtr,AkTriangle)
extern void AkTriangleArray_CloneIntoReferenceFromIntPtr_m247D08E75488EDF12ABBC9DA6594944C5425B240 (void);
// 0x00000B56 System.Void AkMacSettings::.ctor()
extern void AkMacSettings__ctor_mE0F543B25AF80416B555C41C4819D1E1EB968FBE (void);
// 0x00000B57 AkCommonUserSettings AkWindowsSettings::GetUserSettings()
extern void AkWindowsSettings_GetUserSettings_mCA039A4E7850B4519A51419BEA4DCF79DA77EAEB (void);
// 0x00000B58 AkCommonAdvancedSettings AkWindowsSettings::GetAdvancedSettings()
extern void AkWindowsSettings_GetAdvancedSettings_mA3A9F187A00EF0608EF42929028B296C79A1769B (void);
// 0x00000B59 AkCommonCommSettings AkWindowsSettings::GetCommsSettings()
extern void AkWindowsSettings_GetCommsSettings_mCE2699401C92309886E167E42478BAFE0BF6FA27 (void);
// 0x00000B5A System.Void AkWindowsSettings::.ctor()
extern void AkWindowsSettings__ctor_mF108F8FBB74666C60128BFFD74CDC021DD6D9294 (void);
// 0x00000B5B System.Void AkSoundEngine_AutoObject::.ctor(UnityEngine.GameObject)
extern void AutoObject__ctor_mB48CB2F40528061C9D44D21EEEEE765DAED76407 (void);
// 0x00000B5C System.Void AkSoundEngine_AutoObject::Finalize()
extern void AutoObject_Finalize_mA227CA7A221B6EDC16E8F6E9C128973FEA7044CB (void);
// 0x00000B5D System.Void AkSoundEngine_GameObjectHashFunction::.ctor(System.Object,System.IntPtr)
extern void GameObjectHashFunction__ctor_mE328C3AAB1EBE1DF80C6A536406EBF65D8DF4933 (void);
// 0x00000B5E System.UInt64 AkSoundEngine_GameObjectHashFunction::Invoke(UnityEngine.GameObject)
extern void GameObjectHashFunction_Invoke_m31ABA413190DE167D940BCFBA02278355BECF61C (void);
// 0x00000B5F System.IAsyncResult AkSoundEngine_GameObjectHashFunction::BeginInvoke(UnityEngine.GameObject,System.AsyncCallback,System.Object)
extern void GameObjectHashFunction_BeginInvoke_m44C28348EAE2EBAA88D3701B10603B5BC970ADD3 (void);
// 0x00000B60 System.UInt64 AkSoundEngine_GameObjectHashFunction::EndInvoke(System.IAsyncResult)
extern void GameObjectHashFunction_EndInvoke_mDEA01AA6171097AA4A96CAF9A59961EB7F4869F1 (void);
// 0x00000B61 System.Void AkMIDIEvent_tGen::.ctor(System.IntPtr,System.Boolean)
extern void tGen__ctor_mED34BE8A990C0E6240BDAC04BC23F41875330473 (void);
// 0x00000B62 System.IntPtr AkMIDIEvent_tGen::getCPtr(AkMIDIEvent_tGen)
extern void tGen_getCPtr_m54170BB5F74F1C863D9CB99B3DC59ADBB855BF9C (void);
// 0x00000B63 System.Void AkMIDIEvent_tGen::setCPtr(System.IntPtr)
extern void tGen_setCPtr_mAB7852F0FA11FF0E041A0E65EE45623E54D3D2FD (void);
// 0x00000B64 System.Void AkMIDIEvent_tGen::Finalize()
extern void tGen_Finalize_m37D540E4D6423AA2B3C07E05E0DB0FC4EDDC1107 (void);
// 0x00000B65 System.Void AkMIDIEvent_tGen::Dispose()
extern void tGen_Dispose_m94F5978702922F44C8F9ADBD149749373C10B19F (void);
// 0x00000B66 System.Void AkMIDIEvent_tGen::set_byParam1(System.Byte)
extern void tGen_set_byParam1_mA08AE2D401A0C46803252BA755A095153C4DF85E (void);
// 0x00000B67 System.Byte AkMIDIEvent_tGen::get_byParam1()
extern void tGen_get_byParam1_mCB50441CBDBE4D57C486EA10BF1829A0A466D302 (void);
// 0x00000B68 System.Void AkMIDIEvent_tGen::set_byParam2(System.Byte)
extern void tGen_set_byParam2_mA5E3666E4C5DF5048E189A6350B1AE16FAFFCFE3 (void);
// 0x00000B69 System.Byte AkMIDIEvent_tGen::get_byParam2()
extern void tGen_get_byParam2_mB8B3881B9568E4F763277047E3050B0122927B48 (void);
// 0x00000B6A System.Void AkMIDIEvent_tGen::.ctor()
extern void tGen__ctor_m0CB778707388BA33C33C899982BE9B9E9CA32F70 (void);
// 0x00000B6B System.Void AkMIDIEvent_tNoteOnOff::.ctor(System.IntPtr,System.Boolean)
extern void tNoteOnOff__ctor_mF23EB7EA2679622A3A10B95212A8DB5D96F362CE (void);
// 0x00000B6C System.IntPtr AkMIDIEvent_tNoteOnOff::getCPtr(AkMIDIEvent_tNoteOnOff)
extern void tNoteOnOff_getCPtr_m3B13CD49D75FF24CF36A1611C7E169DC247205A4 (void);
// 0x00000B6D System.Void AkMIDIEvent_tNoteOnOff::setCPtr(System.IntPtr)
extern void tNoteOnOff_setCPtr_m28E41CE03A56800D6C6029AC48463166814F2C50 (void);
// 0x00000B6E System.Void AkMIDIEvent_tNoteOnOff::Finalize()
extern void tNoteOnOff_Finalize_m0046B44C2CC5EAE55690415231BA477547CB1DBD (void);
// 0x00000B6F System.Void AkMIDIEvent_tNoteOnOff::Dispose()
extern void tNoteOnOff_Dispose_mA754D5D64309A610606D4BD07C740256F2151299 (void);
// 0x00000B70 System.Void AkMIDIEvent_tNoteOnOff::set_byNote(System.Byte)
extern void tNoteOnOff_set_byNote_mE0D0913EAAB01A05F1DADF82814CD9DA340298E1 (void);
// 0x00000B71 System.Byte AkMIDIEvent_tNoteOnOff::get_byNote()
extern void tNoteOnOff_get_byNote_m152BD0BC61BB62DA736D88C0DDAA244166E129E0 (void);
// 0x00000B72 System.Void AkMIDIEvent_tNoteOnOff::set_byVelocity(System.Byte)
extern void tNoteOnOff_set_byVelocity_m140620BB96A246DD69B5545180E75A1546846D6E (void);
// 0x00000B73 System.Byte AkMIDIEvent_tNoteOnOff::get_byVelocity()
extern void tNoteOnOff_get_byVelocity_m4F208DDADC70C64CB8F08E23A31EFF8912AD891D (void);
// 0x00000B74 System.Void AkMIDIEvent_tNoteOnOff::.ctor()
extern void tNoteOnOff__ctor_m5406A71A45F002C7A44D6DF2ABE31013A319111B (void);
// 0x00000B75 System.Void AkMIDIEvent_tCc::.ctor(System.IntPtr,System.Boolean)
extern void tCc__ctor_m19E9B9504668AD5C85E36F27841517664C938624 (void);
// 0x00000B76 System.IntPtr AkMIDIEvent_tCc::getCPtr(AkMIDIEvent_tCc)
extern void tCc_getCPtr_m616346F39B42CA61C6F886AB562F10E0D0F50AF8 (void);
// 0x00000B77 System.Void AkMIDIEvent_tCc::setCPtr(System.IntPtr)
extern void tCc_setCPtr_m8F86AA5B0434CC6621ADC0E6B0ED37AEDEF7986E (void);
// 0x00000B78 System.Void AkMIDIEvent_tCc::Finalize()
extern void tCc_Finalize_mC8F7BFFF8B9EA8E0BAA81B65AAD7FD2E62C84E9D (void);
// 0x00000B79 System.Void AkMIDIEvent_tCc::Dispose()
extern void tCc_Dispose_m53DF723295194FB0E770AC4BCC16645A8CC2B2D0 (void);
// 0x00000B7A System.Void AkMIDIEvent_tCc::set_byCc(System.Byte)
extern void tCc_set_byCc_m89CC06246354724EC3F12E359D5D5E6654E2A0C0 (void);
// 0x00000B7B System.Byte AkMIDIEvent_tCc::get_byCc()
extern void tCc_get_byCc_m109126C525D3EBDA51792654F9A8E2A672ADA5E8 (void);
// 0x00000B7C System.Void AkMIDIEvent_tCc::set_byValue(System.Byte)
extern void tCc_set_byValue_m679439CA37E0D8E2439DED569AC0E7C59DBE7D13 (void);
// 0x00000B7D System.Byte AkMIDIEvent_tCc::get_byValue()
extern void tCc_get_byValue_m19E8B49C9E1AAB0297AF826E0571EA188287FD16 (void);
// 0x00000B7E System.Void AkMIDIEvent_tCc::.ctor()
extern void tCc__ctor_mD575E0AD96428A9C8EEBC374EAF1882244301FDB (void);
// 0x00000B7F System.Void AkMIDIEvent_tPitchBend::.ctor(System.IntPtr,System.Boolean)
extern void tPitchBend__ctor_mA9332CDB7FDCCF50649A8C358A50B7F34498BB33 (void);
// 0x00000B80 System.IntPtr AkMIDIEvent_tPitchBend::getCPtr(AkMIDIEvent_tPitchBend)
extern void tPitchBend_getCPtr_m53CF450D3B6074F58D5ED25016259B3F56C1A26A (void);
// 0x00000B81 System.Void AkMIDIEvent_tPitchBend::setCPtr(System.IntPtr)
extern void tPitchBend_setCPtr_m16DFBFA4A573FEB9525702FC7BCD7F2C79DEDDB9 (void);
// 0x00000B82 System.Void AkMIDIEvent_tPitchBend::Finalize()
extern void tPitchBend_Finalize_mA3D48D6B394FDED23465F9FA9DFB5EF0D767720F (void);
// 0x00000B83 System.Void AkMIDIEvent_tPitchBend::Dispose()
extern void tPitchBend_Dispose_m51CE0BC17AD136D8BFCF2523553ECC219BCCF72E (void);
// 0x00000B84 System.Void AkMIDIEvent_tPitchBend::set_byValueLsb(System.Byte)
extern void tPitchBend_set_byValueLsb_m26CB84EEEA5703A61B03F2424D4F9454457AADAC (void);
// 0x00000B85 System.Byte AkMIDIEvent_tPitchBend::get_byValueLsb()
extern void tPitchBend_get_byValueLsb_m9CEF30CB9830E99CC2F2F156D7AF6C696BAA8770 (void);
// 0x00000B86 System.Void AkMIDIEvent_tPitchBend::set_byValueMsb(System.Byte)
extern void tPitchBend_set_byValueMsb_m1A82344C6B8C7AFC6D4CA6687B95DC76D8D98570 (void);
// 0x00000B87 System.Byte AkMIDIEvent_tPitchBend::get_byValueMsb()
extern void tPitchBend_get_byValueMsb_mE6537FA35FA55FEF2368873CBA439243C351B1C5 (void);
// 0x00000B88 System.Void AkMIDIEvent_tPitchBend::.ctor()
extern void tPitchBend__ctor_m4C7E99A9AC201BBECB7153EE10934F87676C20EB (void);
// 0x00000B89 System.Void AkMIDIEvent_tNoteAftertouch::.ctor(System.IntPtr,System.Boolean)
extern void tNoteAftertouch__ctor_mA01146E6AFAB2F68174BECD9331B313E15E78606 (void);
// 0x00000B8A System.IntPtr AkMIDIEvent_tNoteAftertouch::getCPtr(AkMIDIEvent_tNoteAftertouch)
extern void tNoteAftertouch_getCPtr_m89E6DEAA4AB492A157EC457523AE95F0950B8BEE (void);
// 0x00000B8B System.Void AkMIDIEvent_tNoteAftertouch::setCPtr(System.IntPtr)
extern void tNoteAftertouch_setCPtr_m2B2100C113F76C79E8FF08720871D755EC1E8502 (void);
// 0x00000B8C System.Void AkMIDIEvent_tNoteAftertouch::Finalize()
extern void tNoteAftertouch_Finalize_m9AF707B720807406EE1FD7D938A8894E00C094D6 (void);
// 0x00000B8D System.Void AkMIDIEvent_tNoteAftertouch::Dispose()
extern void tNoteAftertouch_Dispose_m872964D9BDDD357D90974295C33F70AE22EB59ED (void);
// 0x00000B8E System.Void AkMIDIEvent_tNoteAftertouch::set_byNote(System.Byte)
extern void tNoteAftertouch_set_byNote_m89659F0D4537BF8E9E804DFA52872D674342A7AD (void);
// 0x00000B8F System.Byte AkMIDIEvent_tNoteAftertouch::get_byNote()
extern void tNoteAftertouch_get_byNote_m39E6D08A7A036FB5FB6321ADA921FB96941E0504 (void);
// 0x00000B90 System.Void AkMIDIEvent_tNoteAftertouch::set_byValue(System.Byte)
extern void tNoteAftertouch_set_byValue_mBF2496210FADD86D5D25F7E0E104979E552FA23C (void);
// 0x00000B91 System.Byte AkMIDIEvent_tNoteAftertouch::get_byValue()
extern void tNoteAftertouch_get_byValue_m53AFBF2EE1D17145DF56A06505D451A7D0A1739A (void);
// 0x00000B92 System.Void AkMIDIEvent_tNoteAftertouch::.ctor()
extern void tNoteAftertouch__ctor_mD881311D7B029B15D8C4989063B8B8A97F14ADFA (void);
// 0x00000B93 System.Void AkMIDIEvent_tChanAftertouch::.ctor(System.IntPtr,System.Boolean)
extern void tChanAftertouch__ctor_m4748E89AE7C9461E623EF431B7601B21ABAC7416 (void);
// 0x00000B94 System.IntPtr AkMIDIEvent_tChanAftertouch::getCPtr(AkMIDIEvent_tChanAftertouch)
extern void tChanAftertouch_getCPtr_m670F05F12B28E91DDF08525A159F381DB4948A7A (void);
// 0x00000B95 System.Void AkMIDIEvent_tChanAftertouch::setCPtr(System.IntPtr)
extern void tChanAftertouch_setCPtr_mE7174C46B057DE128D5068B2BC3C00F67D62F1B1 (void);
// 0x00000B96 System.Void AkMIDIEvent_tChanAftertouch::Finalize()
extern void tChanAftertouch_Finalize_mF6CF2DB41A8C55798723BE03D68763DF72A8A08A (void);
// 0x00000B97 System.Void AkMIDIEvent_tChanAftertouch::Dispose()
extern void tChanAftertouch_Dispose_mE7C83E02A5DA22911D75659BC2E0CD991DDDA82E (void);
// 0x00000B98 System.Void AkMIDIEvent_tChanAftertouch::set_byValue(System.Byte)
extern void tChanAftertouch_set_byValue_m8808EEFCDE8BCD50E2B1037E9CDBFEECBE61B043 (void);
// 0x00000B99 System.Byte AkMIDIEvent_tChanAftertouch::get_byValue()
extern void tChanAftertouch_get_byValue_m16845A577A058ADF4DF94E1B8801C5297B5BB9CA (void);
// 0x00000B9A System.Void AkMIDIEvent_tChanAftertouch::.ctor()
extern void tChanAftertouch__ctor_m1FF5CDE95E52497142CC697DBEA2DC00837874ED (void);
// 0x00000B9B System.Void AkMIDIEvent_tProgramChange::.ctor(System.IntPtr,System.Boolean)
extern void tProgramChange__ctor_mE7ECD6C6274549F29A7139735C24269FF1260AF6 (void);
// 0x00000B9C System.IntPtr AkMIDIEvent_tProgramChange::getCPtr(AkMIDIEvent_tProgramChange)
extern void tProgramChange_getCPtr_m7B6695E1F5D173D62B3662FE5D9AC5A80F97EE0F (void);
// 0x00000B9D System.Void AkMIDIEvent_tProgramChange::setCPtr(System.IntPtr)
extern void tProgramChange_setCPtr_mB839E79887521F8F1FE14023524E1BF77DDE0CA6 (void);
// 0x00000B9E System.Void AkMIDIEvent_tProgramChange::Finalize()
extern void tProgramChange_Finalize_m218DDFC425A4BB798355DF9E3E6DD1B308DE4917 (void);
// 0x00000B9F System.Void AkMIDIEvent_tProgramChange::Dispose()
extern void tProgramChange_Dispose_mDFCD6A0A69D07139373BEB8681902E2937280F2D (void);
// 0x00000BA0 System.Void AkMIDIEvent_tProgramChange::set_byProgramNum(System.Byte)
extern void tProgramChange_set_byProgramNum_m25421B107EED036CC273963AC2C508C597F4C818 (void);
// 0x00000BA1 System.Byte AkMIDIEvent_tProgramChange::get_byProgramNum()
extern void tProgramChange_get_byProgramNum_mFDC7D2CB7F4568B1978C9565F5BEB1F8BB6CE73A (void);
// 0x00000BA2 System.Void AkMIDIEvent_tProgramChange::.ctor()
extern void tProgramChange__ctor_m38FC93E25FF0975CC7D6CE52A29C9A3DE72D26F8 (void);
// 0x00000BA3 System.Void AkMIDIEvent_tWwiseCmd::.ctor(System.IntPtr,System.Boolean)
extern void tWwiseCmd__ctor_m6AB93DEFE0F97076A5735F39F00D7488E52DF86A (void);
// 0x00000BA4 System.IntPtr AkMIDIEvent_tWwiseCmd::getCPtr(AkMIDIEvent_tWwiseCmd)
extern void tWwiseCmd_getCPtr_m43C0EA0E375D8F23520C182062971717FEE6DDC5 (void);
// 0x00000BA5 System.Void AkMIDIEvent_tWwiseCmd::setCPtr(System.IntPtr)
extern void tWwiseCmd_setCPtr_mFAA62772A18E4BED6A0CDBA9163691039DE3EC23 (void);
// 0x00000BA6 System.Void AkMIDIEvent_tWwiseCmd::Finalize()
extern void tWwiseCmd_Finalize_mD6FACC185E1F4D63CC09628083D275C998154633 (void);
// 0x00000BA7 System.Void AkMIDIEvent_tWwiseCmd::Dispose()
extern void tWwiseCmd_Dispose_mAD9249FC2431CA0E8F88B22469B30CED25D8AC39 (void);
// 0x00000BA8 System.Void AkMIDIEvent_tWwiseCmd::set_uCmd(System.UInt16)
extern void tWwiseCmd_set_uCmd_m8ACA3ADBE9258DDA033A48E8942197A93CD45286 (void);
// 0x00000BA9 System.UInt16 AkMIDIEvent_tWwiseCmd::get_uCmd()
extern void tWwiseCmd_get_uCmd_m0728518543660A5265E92613A7CBFD22138D20BF (void);
// 0x00000BAA System.Void AkMIDIEvent_tWwiseCmd::set_uArg(System.UInt32)
extern void tWwiseCmd_set_uArg_mC7D8C5E6C8C5D241DBB11CA027A2C063FF2F1AE5 (void);
// 0x00000BAB System.UInt32 AkMIDIEvent_tWwiseCmd::get_uArg()
extern void tWwiseCmd_get_uArg_mED202B570121975CFBC817F3DEBC1E9224D323BC (void);
// 0x00000BAC System.Void AkMIDIEvent_tWwiseCmd::.ctor()
extern void tWwiseCmd__ctor_m655E3D2DDFB0E988DBE0F7E21112882A8D2EF544 (void);
// 0x00000BAD System.Void AkAudioInputManager_AudioFormatDelegate::.ctor(System.Object,System.IntPtr)
extern void AudioFormatDelegate__ctor_m26D3A26D03E8BAF0BDDDF5F9709FA48BBF829DC4 (void);
// 0x00000BAE System.Void AkAudioInputManager_AudioFormatDelegate::Invoke(System.UInt32,AkAudioFormat)
extern void AudioFormatDelegate_Invoke_m165C5B67766ED086A2075E152902777498E139B9 (void);
// 0x00000BAF System.IAsyncResult AkAudioInputManager_AudioFormatDelegate::BeginInvoke(System.UInt32,AkAudioFormat,System.AsyncCallback,System.Object)
extern void AudioFormatDelegate_BeginInvoke_mD6D5929BE3DA085EBC3DD37E1C2B7A83B360EBB9 (void);
// 0x00000BB0 System.Void AkAudioInputManager_AudioFormatDelegate::EndInvoke(System.IAsyncResult)
extern void AudioFormatDelegate_EndInvoke_mA2C9BE8D268B5C118A6A1B71B3E973482707C2E2 (void);
// 0x00000BB1 System.Void AkAudioInputManager_AudioFormatInteropDelegate::.ctor(System.Object,System.IntPtr)
extern void AudioFormatInteropDelegate__ctor_m65EEE5473BA3B8C96B6A615505449F2CCAF3FD5F (void);
// 0x00000BB2 System.Void AkAudioInputManager_AudioFormatInteropDelegate::Invoke(System.UInt32,System.IntPtr)
extern void AudioFormatInteropDelegate_Invoke_m817CC4849CAA04868CA9AAECCD2BB562B788E666 (void);
// 0x00000BB3 System.IAsyncResult AkAudioInputManager_AudioFormatInteropDelegate::BeginInvoke(System.UInt32,System.IntPtr,System.AsyncCallback,System.Object)
extern void AudioFormatInteropDelegate_BeginInvoke_m98A4E007881BCBC3BF38B8835340761275C74A28 (void);
// 0x00000BB4 System.Void AkAudioInputManager_AudioFormatInteropDelegate::EndInvoke(System.IAsyncResult)
extern void AudioFormatInteropDelegate_EndInvoke_m192D595A22E8B3167DC59EE6773E1E0BF2C83B99 (void);
// 0x00000BB5 System.Void AkAudioInputManager_AudioSamplesDelegate::.ctor(System.Object,System.IntPtr)
extern void AudioSamplesDelegate__ctor_m943CEAECC1F04DDFBD92309E08AD2A1D7F1EB6BF (void);
// 0x00000BB6 System.Boolean AkAudioInputManager_AudioSamplesDelegate::Invoke(System.UInt32,System.UInt32,System.Single[])
extern void AudioSamplesDelegate_Invoke_m2C090ED478829D7AA4831BA5CBC612867B331115 (void);
// 0x00000BB7 System.IAsyncResult AkAudioInputManager_AudioSamplesDelegate::BeginInvoke(System.UInt32,System.UInt32,System.Single[],System.AsyncCallback,System.Object)
extern void AudioSamplesDelegate_BeginInvoke_m18B1C132E26001122A436A9915387FB9BD6FC12A (void);
// 0x00000BB8 System.Boolean AkAudioInputManager_AudioSamplesDelegate::EndInvoke(System.IAsyncResult)
extern void AudioSamplesDelegate_EndInvoke_m5D310A376BA706A597051AD3FBA12274FF88C194 (void);
// 0x00000BB9 System.Void AkAudioInputManager_AudioSamplesInteropDelegate::.ctor(System.Object,System.IntPtr)
extern void AudioSamplesInteropDelegate__ctor_mDD33A5EDA4A6D9D24D55CA65328A12B3AD3B7E8A (void);
// 0x00000BBA System.Boolean AkAudioInputManager_AudioSamplesInteropDelegate::Invoke(System.UInt32,System.Single[],System.UInt32,System.UInt32)
extern void AudioSamplesInteropDelegate_Invoke_m29A1F8B48F7D5723EF9C59EC9D0B8F49E0181322 (void);
// 0x00000BBB System.IAsyncResult AkAudioInputManager_AudioSamplesInteropDelegate::BeginInvoke(System.UInt32,System.Single[],System.UInt32,System.UInt32,System.AsyncCallback,System.Object)
extern void AudioSamplesInteropDelegate_BeginInvoke_m2E81B7D3DFA8573EBC9DC0BCEA1A0772300D75FB (void);
// 0x00000BBC System.Boolean AkAudioInputManager_AudioSamplesInteropDelegate::EndInvoke(System.IAsyncResult)
extern void AudioSamplesInteropDelegate_EndInvoke_mB8AD9406E92C350DA400C78A521BC5AD73B20ECE (void);
// 0x00000BBD System.Void AkBankManager_BankHandle::.ctor(System.String)
extern void BankHandle__ctor_m6488C3A828926884ED9BB0D3CC0D2B435364B3E4 (void);
// 0x00000BBE System.Int32 AkBankManager_BankHandle::get_RefCount()
extern void BankHandle_get_RefCount_mC89DD09927733FE654BDBFE6C4259206F3BF7374 (void);
// 0x00000BBF System.Void AkBankManager_BankHandle::set_RefCount(System.Int32)
extern void BankHandle_set_RefCount_m618653EFF0B29CCE01CB3E46C97AF9ED1D8BC83B (void);
// 0x00000BC0 AKRESULT AkBankManager_BankHandle::DoLoadBank()
extern void BankHandle_DoLoadBank_mD6C1F9A110ECD8ACFAE14BB2BCEB251474D0EAFF (void);
// 0x00000BC1 System.Void AkBankManager_BankHandle::LoadBank()
extern void BankHandle_LoadBank_m74BBDA41D27E555AEDF1BA77F73D5D375F1A5E14 (void);
// 0x00000BC2 System.Void AkBankManager_BankHandle::UnloadBank(System.Boolean)
extern void BankHandle_UnloadBank_m0D193B924C4D2738D8F58BC9357481D06B96A017 (void);
// 0x00000BC3 System.Void AkBankManager_BankHandle::IncRef()
extern void BankHandle_IncRef_m7598E53A3AC6CFB6D41484708B68E53ADC10FC4F (void);
// 0x00000BC4 System.Void AkBankManager_BankHandle::DecRef()
extern void BankHandle_DecRef_m144AEE8F725BF475744F6596C1B20CDAEFE95CC2 (void);
// 0x00000BC5 System.Void AkBankManager_BankHandle::LogLoadResult(AKRESULT)
extern void BankHandle_LogLoadResult_mE51076B28F70049696BD63148DCE4E26E60A297E (void);
// 0x00000BC6 System.Void AkBankManager_AsyncBankHandle::.ctor(System.String,AkCallbackManager_BankCallback)
extern void AsyncBankHandle__ctor_mF5355FF8E5F66803D01F182298E0F46639E93F23 (void);
// 0x00000BC7 System.Void AkBankManager_AsyncBankHandle::GlobalBankCallback(System.UInt32,System.IntPtr,AKRESULT,System.Object)
extern void AsyncBankHandle_GlobalBankCallback_m3EEA16A9EF3A60EFD4888B93FADEFB290E749CBA (void);
// 0x00000BC8 AKRESULT AkBankManager_AsyncBankHandle::DoLoadBank()
extern void AsyncBankHandle_DoLoadBank_mC1FF07673F3EBC086E41F914668F38F3EA95A3E4 (void);
// 0x00000BC9 System.Void AkBankManager_DecodableBankHandle::.ctor(System.String,System.Boolean)
extern void DecodableBankHandle__ctor_m03E4082DF88C58C05C7F0608EF031548C21EB80A (void);
// 0x00000BCA AKRESULT AkBankManager_DecodableBankHandle::DoLoadBank()
extern void DecodableBankHandle_DoLoadBank_m4752EAD9215F2B3CADB0698788FD19CD00A07667 (void);
// 0x00000BCB System.Void AkBankManager_DecodableBankHandle::UnloadBank(System.Boolean)
extern void DecodableBankHandle_UnloadBank_mE35B06FF00428F25BAFC4B59448FB1A2B6D098A3 (void);
// 0x00000BCC System.Void AkBasePathGetter_CustomPlatformNameGetter::.ctor(System.Object,System.IntPtr)
extern void CustomPlatformNameGetter__ctor_m81AE2C4EA40997058EB8F41A2833071368C0F504 (void);
// 0x00000BCD System.Void AkBasePathGetter_CustomPlatformNameGetter::Invoke(System.String&)
extern void CustomPlatformNameGetter_Invoke_mBF1DA69B8FF7206236A1DF1C89BB002299EAA7E4 (void);
// 0x00000BCE System.IAsyncResult AkBasePathGetter_CustomPlatformNameGetter::BeginInvoke(System.String&,System.AsyncCallback,System.Object)
extern void CustomPlatformNameGetter_BeginInvoke_m72FC27CDA13C2B836090C7DA781EC106B9AAC96C (void);
// 0x00000BCF System.Void AkBasePathGetter_CustomPlatformNameGetter::EndInvoke(System.String&,System.IAsyncResult)
extern void CustomPlatformNameGetter_EndInvoke_mAFE496AFD14A619795898BF8C8DE5C07C63E5381 (void);
// 0x00000BD0 System.Void AkCallbackManager_EventCallback::.ctor(System.Object,System.IntPtr)
extern void EventCallback__ctor_m8CEF34110B8FAB336F2211A3ED290453F048C6E2 (void);
// 0x00000BD1 System.Void AkCallbackManager_EventCallback::Invoke(System.Object,AkCallbackType,AkCallbackInfo)
extern void EventCallback_Invoke_mC78B589037D5D279B1F9CA1E5516602C23C476EF (void);
// 0x00000BD2 System.IAsyncResult AkCallbackManager_EventCallback::BeginInvoke(System.Object,AkCallbackType,AkCallbackInfo,System.AsyncCallback,System.Object)
extern void EventCallback_BeginInvoke_m112ADF53A6539ABBE34538A9175C2EC2825601CD (void);
// 0x00000BD3 System.Void AkCallbackManager_EventCallback::EndInvoke(System.IAsyncResult)
extern void EventCallback_EndInvoke_mC57D01FF5211594182867390D728FE2A5BA1A871 (void);
// 0x00000BD4 System.Void AkCallbackManager_MonitoringCallback::.ctor(System.Object,System.IntPtr)
extern void MonitoringCallback__ctor_m6080A7E5C98F6A8BB6003E15F2CB2925A7DB69AE (void);
// 0x00000BD5 System.Void AkCallbackManager_MonitoringCallback::Invoke(AkMonitorErrorCode,AkMonitorErrorLevel,System.UInt32,System.UInt64,System.String)
extern void MonitoringCallback_Invoke_m73E971D60180F1BB10302FFD2E85CC770956DD6E (void);
// 0x00000BD6 System.IAsyncResult AkCallbackManager_MonitoringCallback::BeginInvoke(AkMonitorErrorCode,AkMonitorErrorLevel,System.UInt32,System.UInt64,System.String,System.AsyncCallback,System.Object)
extern void MonitoringCallback_BeginInvoke_m16C17EA4029AAD77CE546F9557BA69DF18BE8833 (void);
// 0x00000BD7 System.Void AkCallbackManager_MonitoringCallback::EndInvoke(System.IAsyncResult)
extern void MonitoringCallback_EndInvoke_mC6660AE307EF8521424BDC8082AED38BFCBAF868 (void);
// 0x00000BD8 System.Void AkCallbackManager_BankCallback::.ctor(System.Object,System.IntPtr)
extern void BankCallback__ctor_m285B00D6B758CE1EFDFED2FFA3685D484551D2FC (void);
// 0x00000BD9 System.Void AkCallbackManager_BankCallback::Invoke(System.UInt32,System.IntPtr,AKRESULT,System.Object)
extern void BankCallback_Invoke_m911FAA6CB8664FF41419E07035C4693A77DEFC35 (void);
// 0x00000BDA System.IAsyncResult AkCallbackManager_BankCallback::BeginInvoke(System.UInt32,System.IntPtr,AKRESULT,System.Object,System.AsyncCallback,System.Object)
extern void BankCallback_BeginInvoke_m5E407E173D7311B0B8F4E7DC608BB8E7174A0164 (void);
// 0x00000BDB System.Void AkCallbackManager_BankCallback::EndInvoke(System.IAsyncResult)
extern void BankCallback_EndInvoke_mEC1618AB0A49B480CB8B10987258FDAA1F240A60 (void);
// 0x00000BDC AkCallbackManager_EventCallbackPackage AkCallbackManager_EventCallbackPackage::Create(AkCallbackManager_EventCallback,System.Object,System.UInt32&)
extern void EventCallbackPackage_Create_mA60BD3579147DA80B1F38F846AE0957A70438237 (void);
// 0x00000BDD System.Void AkCallbackManager_EventCallbackPackage::.ctor()
extern void EventCallbackPackage__ctor_m3964D3C93FA67EC6EE8994D4DB758F4E152896DD (void);
// 0x00000BDE System.Void AkCallbackManager_BankCallbackPackage::.ctor(AkCallbackManager_BankCallback,System.Object)
extern void BankCallbackPackage__ctor_mA28A09C45CCADA39EAC444D7AEFAA530E47C1AA4 (void);
// 0x00000BDF System.Void AkCallbackManager_BGMCallback::.ctor(System.Object,System.IntPtr)
extern void BGMCallback__ctor_mB043BEBC921A9B833E78347A34CDA79A32010FB0 (void);
// 0x00000BE0 AKRESULT AkCallbackManager_BGMCallback::Invoke(System.Boolean,System.Object)
extern void BGMCallback_Invoke_m696F74D61E8C4CF7AE4D81E09827EE72E7C59ECC (void);
// 0x00000BE1 System.IAsyncResult AkCallbackManager_BGMCallback::BeginInvoke(System.Boolean,System.Object,System.AsyncCallback,System.Object)
extern void BGMCallback_BeginInvoke_m848CD222B52F203A38E2EFCAAFEA4ADFFE9BDC50 (void);
// 0x00000BE2 AKRESULT AkCallbackManager_BGMCallback::EndInvoke(System.IAsyncResult)
extern void BGMCallback_EndInvoke_mCCE022726989B5E7B449AF3AFC45E9EB4CCFE15B (void);
// 0x00000BE3 System.Void AkCallbackManager_BGMCallbackPackage::.ctor()
extern void BGMCallbackPackage__ctor_m6D2BB11093ECC5103837F2E8918F180376E64F23 (void);
// 0x00000BE4 System.Void AkCallbackManager_InitializationSettings::.ctor()
extern void InitializationSettings__ctor_m5709E6CDC151DEF5941B51E3CAD0EF5AF22144FE (void);
// 0x00000BE5 System.Void AkCommonOutputSettings_ChannelConfiguration::CopyTo(AkChannelConfig)
extern void ChannelConfiguration_CopyTo_mC4554E23E9E8A46D9D9C1596CA3C6CEEEABF2103 (void);
// 0x00000BE6 System.Void AkCommonOutputSettings_ChannelConfiguration::.ctor()
extern void ChannelConfiguration__ctor_m2FA0077E7E1FE35A24840D29D935DB7210005E28 (void);
// 0x00000BE7 System.Void AkCommonUserSettings_SpatialAudioSettings::.ctor()
extern void SpatialAudioSettings__ctor_m75352F0F654CEB0DAC4C0407F5580FBF516B67C6 (void);
// 0x00000BE8 System.Void AkLogger_ErrorLoggerInteropDelegate::.ctor(System.Object,System.IntPtr)
extern void ErrorLoggerInteropDelegate__ctor_m6A7E9D58E8F714CF53556E3F7E223A7721A1FB76 (void);
// 0x00000BE9 System.Void AkLogger_ErrorLoggerInteropDelegate::Invoke(System.String)
extern void ErrorLoggerInteropDelegate_Invoke_mE9AA83146B5D4D81685C1177D60FB0FB75B55A9D (void);
// 0x00000BEA System.IAsyncResult AkLogger_ErrorLoggerInteropDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void ErrorLoggerInteropDelegate_BeginInvoke_mE1E657B5C467610DA01ADB99FF5BB87BA72626C3 (void);
// 0x00000BEB System.Void AkLogger_ErrorLoggerInteropDelegate::EndInvoke(System.IAsyncResult)
extern void ErrorLoggerInteropDelegate_EndInvoke_mFE261ECB10784FAC459D8D4097444F792158C533 (void);
// 0x00000BEC System.Void AkUtilities_ShortIDGenerator::.cctor()
extern void ShortIDGenerator__cctor_mEB1B5ADFE7E54F75673C3BB9A4D46E0EC10B200D (void);
// 0x00000BED System.Byte AkUtilities_ShortIDGenerator::get_HashSize()
extern void ShortIDGenerator_get_HashSize_m467742C012DEE673CE0E6F9F5779481BC9546A1C (void);
// 0x00000BEE System.Void AkUtilities_ShortIDGenerator::set_HashSize(System.Byte)
extern void ShortIDGenerator_set_HashSize_mAE8B03DA9922587EEFD15F4C009E28AB2ED890D6 (void);
// 0x00000BEF System.UInt32 AkUtilities_ShortIDGenerator::Compute(System.String)
extern void ShortIDGenerator_Compute_m6733604177C46DBF4E00A0823B7A52D4079752B9 (void);
// 0x00000BF0 System.Void AkUtilities_ShortIDGenerator::.ctor()
extern void ShortIDGenerator__ctor_mE06C6B14E01A529592C8118B3A433D7AEA92E445 (void);
// 0x00000BF1 System.Void AkWwiseInitializationSettings_PlatformSettings::IgnorePropertyValue(System.String)
extern void PlatformSettings_IgnorePropertyValue_mE1A1D57046679532F1406D0A6A8748DD9FF057A1 (void);
// 0x00000BF2 System.Boolean AkWwiseInitializationSettings_PlatformSettings::IsPropertyIgnored(System.String)
extern void PlatformSettings_IsPropertyIgnored_mE7DB819CBAF4582641B48D90F28EDF6E141EEC79 (void);
// 0x00000BF3 System.Void AkWwiseInitializationSettings_PlatformSettings::.ctor()
extern void PlatformSettings__ctor_m9F38465A62E5ED8FB3DCD9CF044C36ACF871C16D (void);
// 0x00000BF4 System.Void AkWwiseInitializationSettings_PlatformSettings::SetUseGlobalPropertyValue(System.String,System.Boolean)
extern void PlatformSettings_SetUseGlobalPropertyValue_m16DA3C574240EAC8F7E2A7C6F632D5E3A7EC9535 (void);
// 0x00000BF5 System.Void AkWwiseInitializationSettings_PlatformSettings::SetGlobalPropertyValues(System.Collections.IEnumerable)
extern void PlatformSettings_SetGlobalPropertyValues_m7E754C40D8DE0CC35EEA33DAEE04D8AE37B69C73 (void);
// 0x00000BF6 System.Boolean AkWwiseInitializationSettings_PlatformSettings::IsUsingGlobalPropertyValue(System.String)
extern void PlatformSettings_IsUsingGlobalPropertyValue_m35BCB13ED366A683D2385AA09D5F7E22F5C748B5 (void);
// 0x00000BF7 System.Collections.Generic.HashSet`1<System.String> AkWwiseInitializationSettings_PlatformSettings::get_GlobalPropertyHashSet()
extern void PlatformSettings_get_GlobalPropertyHashSet_m08A247C9C52836D003B5FD63ABFE1EF1C9899E9E (void);
// 0x00000BF8 System.Void AkWwiseInitializationSettings_PlatformSettings::set_GlobalPropertyHashSet(System.Collections.Generic.HashSet`1<System.String>)
extern void PlatformSettings_set_GlobalPropertyHashSet_m430574331E47C51C0AE9DEA55008AC7B43512483 (void);
// 0x00000BF9 AkCommonUserSettings AkWwiseInitializationSettings_CommonPlatformSettings::GetUserSettings()
extern void CommonPlatformSettings_GetUserSettings_m724B6A6429EDBBB318C5E21E81C11CED6827E482 (void);
// 0x00000BFA AkCommonAdvancedSettings AkWwiseInitializationSettings_CommonPlatformSettings::GetAdvancedSettings()
extern void CommonPlatformSettings_GetAdvancedSettings_m0901B094DAB6C113FEDB0CDA9790A0A583FCA94B (void);
// 0x00000BFB AkCommonCommSettings AkWwiseInitializationSettings_CommonPlatformSettings::GetCommsSettings()
extern void CommonPlatformSettings_GetCommsSettings_mE5B68C83AE57BD6AE5EE37BA544B3D9B0A4DFB20 (void);
// 0x00000BFC System.Void AkWwiseInitializationSettings_CommonPlatformSettings::.ctor()
extern void CommonPlatformSettings__ctor_m63AFE4F3130D2792C7A0C8F0488F9BB533089D6F (void);
// 0x00000BFD System.Void AkWindowsSettings_PlatformAdvancedSettings::CopyTo(AkPlatformInitSettings)
extern void PlatformAdvancedSettings_CopyTo_m3EB0EFAD0D069B067EA2D00ADFDA259156F6D328 (void);
// 0x00000BFE System.Void AkWindowsSettings_PlatformAdvancedSettings::.ctor()
extern void PlatformAdvancedSettings__ctor_mBBBF33AECD834ED49676D7F2EA3416BA9AFFA9FC (void);
static Il2CppMethodPointer s_methodPointers[3070] = 
{
	AkSoundEngine_AutoRegister_m8932B8FA8793D0AEFD84E8F30AD3B572A914925A,
	AkSoundEngine_IsInRegisteredList_m3A75ABB32DF33F3AA09D7CE30DAB57081A88102A,
	AkSoundEngine_IsGameObjectRegistered_mF122C3BF59940F5C71EF907937729D30B11A233D,
	AkSoundEngine_get_AK_INVALID_PIPELINE_ID_mF5C71D7C362AC29EB90DDBB8CBC77E2ADE243E89,
	AkSoundEngine_get_AK_INVALID_AUDIO_OBJECT_ID_m5561B0DF8DE56279E6F1E48CF32A58E2A62D5D3C,
	AkSoundEngine_get_AK_SOUNDBANK_VERSION_mB94FA41C12CFF4DC8C5A93FC7F93F1C38F78F3D9,
	AkSoundEngine_get_AK_INT_m6192F8AF098FECF2B870A2E2C66A4364F48DED70,
	AkSoundEngine_get_AK_FLOAT_m9A2F3FD79B6D5F6ECEF4F71FCE681CDA6992EA25,
	AkSoundEngine_get_AK_INTERLEAVED_m7FDB1A9E1B5C7C2010472D5ED197C1DF101F3403,
	AkSoundEngine_get_AK_NONINTERLEAVED_m83B89B43ADE6C2B7A0C1C29F2A15029D4EEC875A,
	AkSoundEngine_get_AK_LE_NATIVE_BITSPERSAMPLE_mAA2E7C87B512233902F0F968FC2BA3DCAE146CF8,
	AkSoundEngine_get_AK_LE_NATIVE_SAMPLETYPE_m9058942DB9054156BDCBC3716D8541E28DFEF234,
	AkSoundEngine_get_AK_LE_NATIVE_INTERLEAVE_m3AF96BB342384948CD9F1F107876CC50AC42C5FA,
	AkSoundEngine_DynamicSequenceOpen_m75549F0F10FB4C0B13F2FE3BDFF35436095E2E5C,
	AkSoundEngine_DynamicSequenceOpen_mC2F8BD01EB260B461477B5EEE6F81B3EAE561068,
	AkSoundEngine_DynamicSequenceOpen_m6A479FFAE89868BD8EC01A462D437D984192F75B,
	AkSoundEngine_DynamicSequenceClose_m3FC07027C4C8A11B1E731370064A46CA64A1798C,
	AkSoundEngine_DynamicSequencePlay_m1F99BF38AEAEF2A27E47231106344260F51E1BCB,
	AkSoundEngine_DynamicSequencePlay_m1BE6341A84CDB2C34F0F63376DC76EEE5B944A34,
	AkSoundEngine_DynamicSequencePlay_mB51918F2DDDF967F76852ABE8A86013044BEC59A,
	AkSoundEngine_DynamicSequencePause_m9709C70C75B76FF0D4B90AD467FE2FA9AD449000,
	AkSoundEngine_DynamicSequencePause_mE4A4D6AE0BA5E8DDCBA99D6A49A1224557DDE206,
	AkSoundEngine_DynamicSequencePause_m38B12E64402F114CCE586BC5AA3E0F8DC263DC46,
	AkSoundEngine_DynamicSequenceResume_m0BA7A5130DDE1F4F1E27196DEE5A2F651AE7D41E,
	AkSoundEngine_DynamicSequenceResume_m6D989532E5DCFEAB67021E7FDC24EE6F5406317B,
	AkSoundEngine_DynamicSequenceResume_m521995569CC007694E610BD0016BE3CBC5248CD0,
	AkSoundEngine_DynamicSequenceStop_m0EC643E1A5A77D1A0D5EB389F7DE802093C93458,
	AkSoundEngine_DynamicSequenceStop_m75B8F20505FF898E934D09E06FD6CD160641D71D,
	AkSoundEngine_DynamicSequenceStop_mC2183C1A8559575D6FCFB410EC4B81A353ED495F,
	AkSoundEngine_DynamicSequenceBreak_m046931243D333118B99032A4C1F344E6F21C68A0,
	AkSoundEngine_Seek_mAE1227F6DE74DB17F3539C4C6CBA655C31054D90,
	AkSoundEngine_Seek_m27692CF524E42EB4B6183AAA523F144BE90499F3,
	AkSoundEngine_DynamicSequenceGetPauseTimes_m6E9EBF5319B4614E41388BBAF8CADE5518ED6612,
	AkSoundEngine_DynamicSequenceLockPlaylist_m590D9126338E75C819BC40EA436C1D240AC00292,
	AkSoundEngine_DynamicSequenceUnlockPlaylist_m4F98F95DB569FF9C09ACF407D0B98F4DA52ADECB,
	AkSoundEngine_IsInitialized_m76B4274558657C0E3F450F9B384D0B03A786844D,
	AkSoundEngine_GetAudioSettings_mEE83D45194A13F313954F4140CF8EB2AD4C00E37,
	AkSoundEngine_GetSpeakerConfiguration_m4B4DD31D864097157C174A7579FE7FE1F2DC343B,
	AkSoundEngine_GetSpeakerConfiguration_m7FEA2842CB52D59A3A0158A7EC0378B707E529C5,
	AkSoundEngine_GetOutputDeviceConfiguration_m96D272CA1186C4945D1FC40F91D8316587EBDEA7,
	AkSoundEngine_GetPanningRule_m00638BE10262167BD09940E66681D2486C0F65FA,
	AkSoundEngine_GetPanningRule_m12B23D5E9EFBFDFDFDA73FA3C0CA7130E505D7E1,
	AkSoundEngine_SetPanningRule_mB9DA34AFDE63A9217AA23AD7F125F72A0E98FDF8,
	AkSoundEngine_SetPanningRule_mF7B69C801F24CC46FC5B6D70D088F8D8DF35808E,
	AkSoundEngine_GetSpeakerAngles_m7129F49C663AA5B0531050E153740FBF01460EDA,
	AkSoundEngine_GetSpeakerAngles_m6B1AD30A39D160AB2E76F2FA141D72FC2193F4B7,
	AkSoundEngine_SetSpeakerAngles_mEF1E26AF3A4A715E948DE8073B9C7CC6193619A8,
	AkSoundEngine_SetSpeakerAngles_mF0B6E739E8F1B918418664AEBEFACD8E6CB7B77F,
	AkSoundEngine_SetVolumeThreshold_mE12690FD2F823C335B6EA66350C42901F5E48E2B,
	AkSoundEngine_SetMaxNumVoicesLimit_m75646AF062EE1250083888EEFD9738BAD1D2FD0B,
	AkSoundEngine_RenderAudio_m04C66D07ED8F0A9D6033C3343AECC1CC7B6C89B8,
	AkSoundEngine_RenderAudio_m0F159D5B99B42A2AE3EED95BEEB6746E6C7ED0B6,
	AkSoundEngine_RegisterPluginDLL_m1AD7645945F49003326A277B0255CD5FE801673E,
	AkSoundEngine_RegisterPluginDLL_mC2D01851CC8ADE1EC8F4A85FD3B4B42DA6581BC7,
	AkSoundEngine_GetIDFromString_mEA872321C202FCF9F08189AF74F58853FCA9DB63,
	AkSoundEngine_PostEvent_mAB665E57B07C35D4DA253B8F51C3292571B6D5A5,
	AkSoundEngine_PostEvent_mBF27F3E62716299C08EA98D60E4BB06E7F8908FE,
	AkSoundEngine_PostEvent_m997A7668B975E941F91CDBD192BA46E862745061,
	AkSoundEngine_PostEvent_mD400F73D4C60220DE61D6AD7B4C5431E70030F17,
	AkSoundEngine_PostEvent_m1EF119D5BA7EEAAF115CB16FEBE4D9B9960B8064,
	AkSoundEngine_PostEvent_m5DDC87259E41D9FC13FF4A2E8D18635BB0716A78,
	AkSoundEngine_PostEvent_m36FA0E8E7E020CD2CD1D73AC122AAC6A97E4126F,
	AkSoundEngine_PostEvent_m4C77A39AD8F95FAA22D7260B66419ECF45CB2C71,
	AkSoundEngine_ExecuteActionOnEvent_m04C957F393FBEC288BBA56E1AE85A6AD78E03F12,
	AkSoundEngine_ExecuteActionOnEvent_mC6896E088058423EA8EA51B34789251E9038E225,
	AkSoundEngine_ExecuteActionOnEvent_m449ECDA042B36FE27A1154FEB74F88860190FF2B,
	AkSoundEngine_ExecuteActionOnEvent_m2BEF57503DD2B3D189557A02E419DDD26FFA6D31,
	AkSoundEngine_ExecuteActionOnEvent_m5799002F93C9D6E956CC5AA47055146E310CC1E0,
	AkSoundEngine_ExecuteActionOnEvent_m0B665A2327721EF957D348EF8EAE44AED75F54BA,
	AkSoundEngine_ExecuteActionOnEvent_m4DE7A11CC88E759C9602ABD6E451C6B80332C5CB,
	AkSoundEngine_ExecuteActionOnEvent_mFE2B678EF9F9A376C9C8DEFB97B35E32F36EA546,
	AkSoundEngine_ExecuteActionOnEvent_m50B404C9F1352422590312E9FE885E1E5C751580,
	AkSoundEngine_ExecuteActionOnEvent_m40581760C5529B7789E545DB9B4D8DF80250DBA2,
	AkSoundEngine_PostMIDIOnEvent_m99C5BD6A4694E18D5C32CB10B7B5A4AE0B5B129F,
	AkSoundEngine_PostMIDIOnEvent_mDBDE91EE1F181F17FD9FFD1BD4949CF847085838,
	AkSoundEngine_PostMIDIOnEvent_m0D874DF3109285F82FFBBF44BC0C44515E0B9616,
	AkSoundEngine_PostMIDIOnEvent_m877A330AD811A57843DE7D2AFCBE174BC8522430,
	AkSoundEngine_StopMIDIOnEvent_m30E40360A044A6FE86E048E70C6876845213CA1A,
	AkSoundEngine_StopMIDIOnEvent_mCB261628179A521B1ACD880F21F94ABDC40ECC4E,
	AkSoundEngine_StopMIDIOnEvent_mFFB9A53556646A6E3FB7E4F782DEBDC5AE29E156,
	AkSoundEngine_StopMIDIOnEvent_m8C95C0CB26382E1A089DF0F46AE12B0C6E4BC1B7,
	AkSoundEngine_PinEventInStreamCache_m25A2F7107A92575D920FB3AA3C7BAB5DE0F94D8D,
	AkSoundEngine_PinEventInStreamCache_m8879102CE2FC407338B55F9FDF520C5B9FCB52D4,
	AkSoundEngine_UnpinEventInStreamCache_m308A334A1E3315B82E9C2521A1C2D0E5F7F3F3C7,
	AkSoundEngine_UnpinEventInStreamCache_mD1130A7F70B444B198E9D24E7D04576288055B8C,
	AkSoundEngine_GetBufferStatusForPinnedEvent_m01299F325EF5A28C45C88A4808D833D2437A9CA6,
	AkSoundEngine_GetBufferStatusForPinnedEvent_m3D6A9203AA266F62018A8FFD82EEED1517D935D6,
	AkSoundEngine_SeekOnEvent_m308CC21BA7EC669933EE94D75EEE6B9249DC42B0,
	AkSoundEngine_SeekOnEvent_m51BEC0069AB8B2F6CFC10F85BF677BB9EF794A86,
	AkSoundEngine_SeekOnEvent_m8272746694E03C7D6443DF568480E2E687085731,
	AkSoundEngine_SeekOnEvent_m6A209FAC89DB2CBC42898F0EEEC9420C6FBC8386,
	AkSoundEngine_SeekOnEvent_m41DD52D02AAE3E77CBF9B2506073CE7811321847,
	AkSoundEngine_SeekOnEvent_m3DE03447673A93B3C54C03D413E5E847C72CAC7B,
	AkSoundEngine_SeekOnEvent_m3C04059DA86FF6573B8E426C56D39A3D258F0886,
	AkSoundEngine_SeekOnEvent_m519C768432590722333467DE690FD1F473DCBEF6,
	AkSoundEngine_SeekOnEvent_m39D61E482DCB6129EB53DC0A94C8F481F7C1A55C,
	AkSoundEngine_SeekOnEvent_mD3D07B98208AFB3F9AD6933C7DFC12ED2B2B8C15,
	AkSoundEngine_SeekOnEvent_mCAD27A774BDEF235A220B9F0553C1E66D4F29AB5,
	AkSoundEngine_SeekOnEvent_m6CC84805B582C89D9F7F0450777C90FD599F2E3F,
	AkSoundEngine_CancelEventCallbackCookie_m396B8B106A208CE221BD669F8520D0FB1B0467FB,
	AkSoundEngine_CancelEventCallbackGameObject_m592D5B60AE7BC7CF1EC1469B5E00BEF2BD6D1F7E,
	AkSoundEngine_CancelEventCallback_m3E8F27765FCB26443A255BAAE11FAD6E60F849BF,
	AkSoundEngine_GetSourcePlayPosition_m786F17819CC01810FF61202B1A8408B1A55F6AD5,
	AkSoundEngine_GetSourcePlayPosition_m2A69E8D40B7FCB6F82573E998162D005BC5BA16F,
	AkSoundEngine_GetSourceStreamBuffering_m925BCEC4777CCAC225BB772D7DD5EEFB23D0354F,
	AkSoundEngine_StopAll_m1C809EDFDEAFDFD59ACC47339E570E5D511FB400,
	AkSoundEngine_StopAll_mFA9DADB215FBBBA1999DA7F3FD83F2218B16B6D1,
	AkSoundEngine_StopPlayingID_mB94A9850776C16C6A7AA0FF0DD908AC1322F8E4F,
	AkSoundEngine_StopPlayingID_mC0374253D4C3F4B234604776C25686F7CFD42636,
	AkSoundEngine_StopPlayingID_m74BF7B85B5153C84EFAD4B94101D9FD97F048095,
	AkSoundEngine_ExecuteActionOnPlayingID_m41002219A542A94A65832C3D29F9ACF7A987C666,
	AkSoundEngine_ExecuteActionOnPlayingID_mAEE806664B8258F37BCE8078019ED45FFE87931C,
	AkSoundEngine_ExecuteActionOnPlayingID_mB56BE92390D1852440374B5CC5D5C17DFCDB4F5D,
	AkSoundEngine_SetRandomSeed_m769F9A2670DE35FFAE8E696C55BBE0C282B9B301,
	AkSoundEngine_MuteBackgroundMusic_m5DFC91D5DD8DEC88FBC60D4F30AB3758C0132179,
	AkSoundEngine_GetBackgroundMusicMute_mC901D1474927B37C95D1C2A0E5252BD438FBB58A,
	AkSoundEngine_SendPluginCustomGameData_m624DF4DE5C9B90949889A012E98DE64840995CA2,
	AkSoundEngine_UnregisterAllGameObj_mB77917B8A31301DEFADFBDC99D0962543816F8AA,
	AkSoundEngine_SetMultiplePositions_m4C19EE8DB342C6432FEA7CD65E446F1549B60D78,
	AkSoundEngine_SetMultiplePositions_m1FDD3A4706B34960E7E71DD98B983264CEFB4AB6,
	AkSoundEngine_SetMultiplePositions_mDBDCBB2F4A9CBFC5B8463F558BDD1B389768CA0D,
	AkSoundEngine_SetMultiplePositions_mAFD26C2CB8223669B94F3C4A9DB88013261BFB11,
	AkSoundEngine_SetScalingFactor_m1EA6DC9A5F4FF7DF088E275F22A8F1004D932345,
	AkSoundEngine_ClearBanks_m25BA2D588E317FA01EBAC637D2E227C18D8250AA,
	AkSoundEngine_SetBankLoadIOSettings_m6BFFB95FF88BABF183E11965ED4FAD8FC1416586,
	AkSoundEngine_LoadBank_mEABF8DDB0CDAA2D9928245374B055CE7DB391ED2,
	AkSoundEngine_LoadBank_mCF3CE3DDE26F1260E8BFF29C7E8247D309A0B70C,
	AkSoundEngine_LoadBankMemoryView_mC4D1D0C818ABFBDC028C5C6387292F8865214585,
	AkSoundEngine_LoadBankMemoryCopy_m4E8F32303DB8F16FF4CBFB4E1F2D70294E434D3C,
	AkSoundEngine_LoadBank_m97EC88CC63821A30D8D568DF4B48332392FA23B1,
	AkSoundEngine_LoadBank_mAD5170A2BBB0938AAE7A458C6C8B2C6414BFD263,
	AkSoundEngine_LoadBankMemoryView_m56BC3666D73157DFEA1D136B98CD4498B99CDA30,
	AkSoundEngine_LoadBankMemoryCopy_mC9CE36B08E3B875E5990FEF269B5DF0BA7CF5DAA,
	AkSoundEngine_UnloadBank_m8E40BFA3897D3381DE7E211608CAF145C0BCB9AF,
	AkSoundEngine_UnloadBank_m89A742A422BFC4DBE2EFAA2E4D2574E0D9F8AD8B,
	AkSoundEngine_UnloadBank_m80CCFB3DC6C45532A371DB171F442196E465A216,
	AkSoundEngine_UnloadBank_m74D26BAD913AA5CD7CBAB5C9663B1313873C61F2,
	AkSoundEngine_CancelBankCallbackCookie_mC29B370F1869919E88C5278CC54ED3ECB96E2CA5,
	AkSoundEngine_PrepareBank_mE4CE543C203DC4AECD18D1B8280B5AA3BFDC0C4D,
	AkSoundEngine_PrepareBank_mC4316024C933469C03034E60E84E0C898858A31F,
	AkSoundEngine_PrepareBank_mE2131C6ABC4F2B4F107DCADBBEB25CA6CE2D4E22,
	AkSoundEngine_PrepareBank_m5FD9E5120AB525FAB166A6B27B46F1E6F7F6E655,
	AkSoundEngine_PrepareBank_m6B857982DB2DDF8D7B4C5F81CA25DA18BDB2E7A4,
	AkSoundEngine_PrepareBank_m67B437F011DB94ECAB0895CC6F751C603A35617F,
	AkSoundEngine_PrepareBank_m9F49547FFB8A54D7EA4F33D46398729B77258E77,
	AkSoundEngine_PrepareBank_m06D947982236D11595B87BF95A0F27FE00917330,
	AkSoundEngine_ClearPreparedEvents_m0207009D9C0C5975FFE3FAC8240BDE5CB698E67F,
	AkSoundEngine_PrepareEvent_mF7E4BC30C8928707AC81497C8F9E6E0B63619994,
	AkSoundEngine_PrepareEvent_mCD43F84A762375AE2A37A4946C23567883B346A5,
	AkSoundEngine_PrepareEvent_mE89F71654AC668D6198E53EA378342ED88BE1408,
	AkSoundEngine_PrepareEvent_m386C86C1D8A6B7F11EBCB4D033EF50E573F9758A,
	AkSoundEngine_SetMedia_mD83E625E3366D0783112CF1B497A0AB9C613F9C9,
	AkSoundEngine_UnsetMedia_m53250877545843FCCD40292C904FD76D7F9840DC,
	AkSoundEngine_PrepareGameSyncs_m0866906C83A6680566FD5192DBBBEA0AC7E215FB,
	AkSoundEngine_PrepareGameSyncs_m0D1630AD10A8F061739D6A796097CE106CD9DF3C,
	AkSoundEngine_PrepareGameSyncs_m0A12E9892D28C5F23FE2F7FECA0DFF03A117D646,
	AkSoundEngine_PrepareGameSyncs_mFD1026CA21ACF9B98D744286B63EDD116E0B03C8,
	AkSoundEngine_AddListener_m9AC6133C8084170F6EC18F540A6A55E2679E8943,
	AkSoundEngine_RemoveListener_mCE869B27636F51F07B7AA920B3229558E00B7A2D,
	AkSoundEngine_AddDefaultListener_mD6B3FED201AB275C99D95A2B1CEFDB9D677566AC,
	AkSoundEngine_RemoveDefaultListener_m78FD26085CF14B2652799A584B0C50BB3BEC1A76,
	AkSoundEngine_ResetListenersToDefault_m9D6B943A52A48956EBF10BD2A1FF70E4A2C26C05,
	AkSoundEngine_SetListenerSpatialization_m3CF234AA2A30BE33758FA854983E741F1FBACEAE,
	AkSoundEngine_SetListenerSpatialization_m04E86FC4326EC24F22161C346673F27B9324C4C0,
	AkSoundEngine_SetRTPCValue_mE22F952C9DD2D3EE3CCFB1BF2E551A8896652B57,
	AkSoundEngine_SetRTPCValue_mBA78710016BF035162E6C519A4DBDCC2B0521A46,
	AkSoundEngine_SetRTPCValue_mA96A54AD6AE0AC180EA34BDFA153A537CC272BA9,
	AkSoundEngine_SetRTPCValue_mB528BE43F472886E4F2C0EFA0D079759B8B348EE,
	AkSoundEngine_SetRTPCValue_mFD00540F3921139DB4467CAA06A2DAA43DD5EB19,
	AkSoundEngine_SetRTPCValue_mB62353A91BF9FFAE5A1112B24FE2C15C095BEE4F,
	AkSoundEngine_SetRTPCValue_mAEF327921358879DA203784C0D452AB7891D0038,
	AkSoundEngine_SetRTPCValue_m698DB4CB439EBE3823F88FF2783DC9627D3755D8,
	AkSoundEngine_SetRTPCValue_mC5A4A0D746BEB769790A10F25417D429DC5A7926,
	AkSoundEngine_SetRTPCValue_mF4623CB727493A545AC48C3B170492A1228BF715,
	AkSoundEngine_SetRTPCValueByPlayingID_mDCEE0FB923A0857F9758825FD6144FAA0E8FD8D2,
	AkSoundEngine_SetRTPCValueByPlayingID_m318EE5E60E865B7826473C4FBEA7FBC865360B42,
	AkSoundEngine_SetRTPCValueByPlayingID_mB574CC326E615ED640B3A9B733E8B98C4B05F0B7,
	AkSoundEngine_SetRTPCValueByPlayingID_m44380B7C4201E3DBA92214FE140C56C90235D41A,
	AkSoundEngine_SetRTPCValueByPlayingID_m0C7B75C0080E3D8DF749AA6AB7D6E7ADF171913B,
	AkSoundEngine_SetRTPCValueByPlayingID_m121400048AB99DC13BC010DE75BDF39C7C16FB76,
	AkSoundEngine_SetRTPCValueByPlayingID_mB0051441D2BC17DC75ACF6CBD88D51A2E2472A2E,
	AkSoundEngine_SetRTPCValueByPlayingID_m6CE9D7318909707AD1081A42DDDFD99BAC720F3A,
	AkSoundEngine_ResetRTPCValue_mC4D24CAB0F4B91359051404EC93EA33B4CEABFEF,
	AkSoundEngine_ResetRTPCValue_mDF3B675FDD96DB9D2A1E72F273F2D79896E77993,
	AkSoundEngine_ResetRTPCValue_mB41D426330EEF4A2A641E0AB704E9AF71A48AB6E,
	AkSoundEngine_ResetRTPCValue_mAE0EE7998EF80F6F0368A27D1A7BAFB264526174,
	AkSoundEngine_ResetRTPCValue_mD483945A258F7AF77D4A1C0F679DF8CC2F69F832,
	AkSoundEngine_ResetRTPCValue_m8D53C70F34956A52AA1A6115D1FAE8FB2BE138B3,
	AkSoundEngine_ResetRTPCValue_mFDB3D0DA2F93DF5B3AE88BEF86B84FFFE0A096E9,
	AkSoundEngine_ResetRTPCValue_m3923530F4FAFDE8D5A1FE2651BBC61D22AC60BA1,
	AkSoundEngine_ResetRTPCValue_m70ABEC427033E652CB684D841B466EBE8C71E675,
	AkSoundEngine_ResetRTPCValue_mB22A69E16604101CF9479CD43EA3A3EE107BE040,
	AkSoundEngine_SetSwitch_m1B4A0F4F5B95B2A523F42865FD3F51E7F7BC7BA2,
	AkSoundEngine_SetSwitch_m38C61ECAB906150AAFC57DB409EE2D2BB253E42B,
	AkSoundEngine_PostTrigger_mDF8C46E4F0634157EB276AACF782415C08DCD544,
	AkSoundEngine_PostTrigger_mBCF3284269CC5FE75BE690892419D78567147851,
	AkSoundEngine_SetState_m27B10E6734080647D4ED57903BF9EA010F60D08C,
	AkSoundEngine_SetState_m80E5086D0A25FA443528A7491D668CB87E49EB18,
	AkSoundEngine_SetGameObjectAuxSendValues_m3E4EBD881DEA28BCD96733A400A49BC7524F9FA3,
	AkSoundEngine_SetGameObjectOutputBusVolume_m970F4D85B9B9E6F7A95CF018E33D03649029FA0A,
	AkSoundEngine_SetActorMixerEffect_mA01445089D6947B7DEBCEFDDCAAEF782BEAE558D,
	AkSoundEngine_SetBusEffect_m5320FEA56D02FE2F8781FB4C654A0EA4A6401545,
	AkSoundEngine_SetBusEffect_m95634064FF2A62BDB122A1A05B525B7226EBB037,
	AkSoundEngine_SetOutputDeviceEffect_mF722DB7533E5A682F87FF9E84D0281DE256083F3,
	AkSoundEngine_SetMixer_m222A0AABFFABB2C83EC6812E83D076D871C893D7,
	AkSoundEngine_SetMixer_m0231AF5FAF98F38092A6C904F53647B90EB082C5,
	AkSoundEngine_SetBusConfig_m0E3A3261CF5948224F6424914A89A60588669CA6,
	AkSoundEngine_SetBusConfig_m6FB047EB5E8C453123852B5957366393667A8C14,
	AkSoundEngine_SetObjectObstructionAndOcclusion_mC5EFB676DC21EF427F03EDAD5A48CCE381FE14FB,
	AkSoundEngine_SetMultipleObstructionAndOcclusion_mFB958D14564ABF7D66EB6954EA0BD961DE35478C,
	AkSoundEngine_StartOutputCapture_mB087ECAA718C8A90F78BE0D1C68DC9240537F40E,
	AkSoundEngine_StopOutputCapture_m2C1C3431FDE4EF8EF31A5F5E032421B35E9B35B0,
	AkSoundEngine_AddOutputCaptureMarker_mE05552748D83ECA950CEEA3460E9898C7E7AE227,
	AkSoundEngine_StartProfilerCapture_m8EF63839317118041DC709DCB2398E94682B5E5A,
	AkSoundEngine_StopProfilerCapture_m7F65F392C74043E97AE4B0DE5E3868D9911E05E5,
	AkSoundEngine_RemoveOutput_mDB255D4514D7E7C06BB6AA7BBC79899CCBDD34E0,
	AkSoundEngine_ReplaceOutput_m75B4FB31C80FD86AA16FE0D5A24555CEBBA36073,
	AkSoundEngine_ReplaceOutput_mC513F51C38CC272927363C4140F3D8BF10E03908,
	AkSoundEngine_GetOutputID_m8ABF01C8FF599F69629629AA0B245B6B6AF5F997,
	AkSoundEngine_GetOutputID_mC11AEC910F0D72A9D5CA0AEC34435231A6D4574C,
	AkSoundEngine_SetBusDevice_m702EEC740434BEC0599ED2DFD19EA71379867CBC,
	AkSoundEngine_SetBusDevice_m3263C9151C78C152DBE87C26B12B45B46EE15554,
	AkSoundEngine_GetDeviceList_mD488784490C6CD01D881BEF39986DCD5BFFC4388,
	AkSoundEngine_GetDeviceList_mF47D37DCE498B927D7F859351A92E424421B0E7C,
	AkSoundEngine_SetOutputVolume_mCD9F311A52006321A2E3008B7073342E2EF22FC7,
	AkSoundEngine_GetDeviceSpatialAudioSupport_mAA211BD06D43CA808E39C0F339E3FC7EF69FC218,
	AkSoundEngine_Suspend_mEF457E422CCC8EDEA1E14FFB3CDC37AEBF96A471,
	AkSoundEngine_Suspend_m51C5883B4AAF4E85DB3F43CF87787B632D6B9B48,
	AkSoundEngine_WakeupFromSuspend_m21231525B4D49CBA740B37C84AA5F8239D68188E,
	AkSoundEngine_GetBufferTick_m075439DA3714C4F4200A4C8C72893E2B2DEA31C3,
	AkSoundEngine_GetSampleTick_m6D99DEED4AEA7044A00520B90F62A0706878B1E1,
	AkSoundEngine_get_AK_INVALID_MIDI_CHANNEL_m6CA41B83DE649A965FF6C3C0798621A0C9505363,
	AkSoundEngine_get_AK_INVALID_MIDI_NOTE_m9AB39DA683A874D6CBAC92082B319F1C5D546F85,
	AkSoundEngine_GetPlayingSegmentInfo_mC2C4B0FF19275BAECE18569033FCA2F7BC5A01A5,
	AkSoundEngine_GetPlayingSegmentInfo_m40EFCAE5E13D7BA7062CC24232D15F71E87AFBF0,
	AkSoundEngine_PostCode_m15B7937F7C48D117E3A69F760F426E89C1804C8C,
	AkSoundEngine_PostCode_mF3EAA81338B1535C4F7E661B08A3CE97BDD4D488,
	AkSoundEngine_PostCode_m292542C9B8A9C6E0DAD01FBF5FC0EDF331A70B80,
	AkSoundEngine_PostCode_m59C7AD63283301E44BA41FC03B711DA338EC9964,
	AkSoundEngine_PostCode_mF948BF316F5882DE5F692D45F6CEE78EF00243B9,
	AkSoundEngine_PostString_m590AF46DE3F6E9211168AABB2D9D8B038A1001E5,
	AkSoundEngine_PostString_m6B79D4026C885894C9CBC2A321162B93ABA4AD1E,
	AkSoundEngine_PostString_mDB4880B7FA2397A153BB94AA2796E1BC92852C2B,
	AkSoundEngine_PostString_m9E84C34052876FEEE93EF066BA3A4D4CA4A327CA,
	AkSoundEngine_PostString_mA522766A3C89D3E855053BC3E2723778D63A6AFD,
	AkSoundEngine_GetTimeStamp_m16FE70DD8EAA66FC46FFDDB09A8460054F4201C6,
	AkSoundEngine_MonitorStreamMgrInit_m67CECB90B639A082E9C97029D1E0CB8B7BF097C7,
	AkSoundEngine_MonitorStreamingDeviceInit_m1589354538D79EAA791719C3732469F88EB82CAB,
	AkSoundEngine_MonitorStreamingDeviceDestroyed_m8C92FF2FDBA63272B35735ECA3699CD0808E8717,
	AkSoundEngine_MonitorStreamMgrTerm_m0698AAD769B76FBF64CE73D4DD335E2D10096A0E,
	AkSoundEngine_GetNumNonZeroBits_m9909AA5D34173A4173C1693B0377AE781914F684,
	AkSoundEngine_GetNextPowerOfTwo_mB8FC992EB27818940F6199070E50BFAAD999B524,
	AkSoundEngine_ROTL32_m68E6789F000C00C3F6D5E2B4E778F92984CFB878,
	AkSoundEngine_ROTL64_m93B2DE47526B61B630FA125F7B89FC289D3B02B3,
	AkSoundEngine_AkGetDefaultHighPriorityThreadProperties_m4E1AFBC32B7A2AB63CEE7C99206E48A608B4FD64,
	AkSoundEngine_ResolveDialogueEvent_mDF3CA4F022FA5465BFDFCDF969C9646FC849E2E1,
	AkSoundEngine_ResolveDialogueEvent_m970557D3E0F243994163762C3D2EC3B9C3898D9E,
	AkSoundEngine_GetDialogueEventCustomPropertyValue_m76B2165111D53BC8199A7A3E2ABC296DCBC8C86E,
	AkSoundEngine_GetDialogueEventCustomPropertyValue_m3DFE5885F059A0D994B9C4F7487A4D6BE0386340,
	AkSoundEngine_GetPosition_m109AD797204F44EEAD2BFED98AF9A3FE53249E16,
	AkSoundEngine_GetListenerPosition_m9B810AA1EA5E9FFC41F51063BD9B4DB859659477,
	AkSoundEngine_GetRTPCValue_mBFF46C693C29FAAA7DB3489F12A9247DC227EA6D,
	AkSoundEngine_GetRTPCValue_mD849D50AB6D73719932E651E2F3D028D726178ED,
	AkSoundEngine_GetSwitch_mC9FD2BD405E011AA8A4EC7D7A12D74FEB9434D6E,
	AkSoundEngine_GetSwitch_m62B2C421EBA5D3E22E0560BA47786886DC4EF1D6,
	AkSoundEngine_GetState_m5E9B49473E6F29AC201622E9158097E284435965,
	AkSoundEngine_GetState_m7A8078C73DB65C03580A903B467364FBC2BC5E82,
	AkSoundEngine_GetGameObjectAuxSendValues_m6F6AC906EBE92856C87EA2888B42000DA7AA743F,
	AkSoundEngine_GetGameObjectDryLevelValue_m9B40E5DEAF07A499B0755BEAA516DE9E630520A7,
	AkSoundEngine_GetObjectObstructionAndOcclusion_mA75E71E4DA854F2190A6325D6875313EF7D8A7DC,
	AkSoundEngine_QueryAudioObjectIDs_m8D2DF4840431DB150C7EAD480D76CDCF9115F762,
	AkSoundEngine_QueryAudioObjectIDs_m7BFECFC79DFD77FFBC2FDFADA6404833B8FA9F91,
	AkSoundEngine_GetPositioningInfo_m891551654D1D9548938D653E97F7ED4A79F4B950,
	AkSoundEngine_GetIsGameObjectActive_mD562909248668EC1D9E09EB7C7401FC1D10FCEEF,
	AkSoundEngine_GetMaxRadius_m6B3549451C0F4058A6ADBD381944FEC774A78CD5,
	AkSoundEngine_GetEventIDFromPlayingID_m61F644ACDD60B4868DC8082F4107BE2AEBE6B321,
	AkSoundEngine_GetGameObjectFromPlayingID_m1DF62805ED65A6046054625BFFCDADECD0CFFFFB,
	AkSoundEngine_GetPlayingIDsFromGameObject_m28F82D43A637D7196F51EF8BA67E9B3147E51EBD,
	AkSoundEngine_GetCustomPropertyValue_mFB8A74257EE75C8EC3A5546E84969E8BF093CE26,
	AkSoundEngine_GetCustomPropertyValue_mD1643FE85A9530D61699F5D7C678E622E664A0ED,
	AkSoundEngine_AK_SPEAKER_SETUP_FIX_LEFT_TO_CENTER_m4ABE09E96F5F353DC8A861FBA20483A440E8292A,
	AkSoundEngine_AK_SPEAKER_SETUP_FIX_REAR_TO_SIDE_m4A658C62AC9992D1AF184B04E902F74E7C426C84,
	AkSoundEngine_AK_SPEAKER_SETUP_CONVERT_TO_SUPPORTED_m525BEDEEB755902BA9064061BF258D6C02646959,
	AkSoundEngine_ChannelMaskToNumChannels_m85123C0432C093C63F9878E30360CD40532886F9,
	AkSoundEngine_ChannelMaskFromNumChannels_m22C997D94F9BD02BEADF941DCC255D5BF3F9B468,
	AkSoundEngine_ChannelBitToIndex_mD78FB98C1A90BF4D2E938B4B934F293588E137CD,
	AkSoundEngine_HasSurroundChannels_m35EF19D50CF6C2BF6C6A0B2E34E5A8B7C7D0B70B,
	AkSoundEngine_HasStrictlyOnePairOfSurroundChannels_m6455DD44C1C43C1BA1706AB415C029DE2A1D0B5E,
	AkSoundEngine_HasSideAndRearChannels_m424295DC3D407AA1415377ED88DDCD3E23436E38,
	AkSoundEngine_HasHeightChannels_m8BF4F362BAE4D7D8B233405AED24953680D8FFF5,
	AkSoundEngine_BackToSideChannels_m2FA5218B631F0E8DB96FD9D4D6320F203A09E8BA,
	AkSoundEngine_StdChannelIndexToDisplayIndex_m789AF539D3539568E342F6EAACAD89EEE3020B70,
	AkSoundEngine_get_kDefaultMaxPathLength_mD8FC62C0227A25C1809A00759DBAE183EE5F03FD,
	AkSoundEngine_get_kDefaultDiffractionMaxEdges_m79130E47983C14A566B8B4E5F03256D7DD3459DD,
	AkSoundEngine_get_kDefaultDiffractionMaxPaths_m3A5782C7FEB541C9727108507852EEE968F7C76D,
	AkSoundEngine_get_kMaxDiffraction_mED22E2C657F730422ED208331D2C57923F133C90,
	AkSoundEngine_get_kDiffractionMaxEdges_mF24CEB4C8461CEF65D7B35FE3A9B568403E7C138,
	AkSoundEngine_get_kDiffractionMaxPaths_mD7505CB9798E648D7B2AA757E41B424EDE6742E4,
	AkSoundEngine_get_kPortalToPortalDiffractionMaxPaths_m8B3E0C10AEED427912912F10CD85A6CD91768247,
	AkSoundEngine_SetGameObjectRadius_m8F34BDD6408357BDE1C02DC12A12D44508E0CC09,
	AkSoundEngine_SetImageSource_mE73890A9D4C1774C4014FB89C3149C29BDDA0A2E,
	AkSoundEngine_RemoveImageSource_m6DD58F5F12FFD33B9F53D39DEC2EE78D4E218250,
	AkSoundEngine_ClearImageSources_mDF9D16E5A960E10426955067C52351256AF3B2A8,
	AkSoundEngine_ClearImageSources_m5BC8C8F1259C85B7F1BE0D9E6A6CE137E8DCC628,
	AkSoundEngine_ClearImageSources_m9D5A5D2414DC29D26698CA01DF3F7235D446009B,
	AkSoundEngine_RemoveGeometry_m91FC5D08377D0324D7C2BB09EB43BD2EBB528705,
	AkSoundEngine_QueryReflectionPaths_mAB7FF69640C192A87E43987DF7310AE89365179A,
	AkSoundEngine_RemoveRoom_m397A0D324FFAEF81164AD88C8E4EB1FF4DF6E111,
	AkSoundEngine_RemovePortal_m6ED6DFC5B0DC35E182182B7BCBDD9CEFFC099B32,
	AkSoundEngine_SetGameObjectInRoom_mE5FC77B51C17E04ED7CCFAE781BFD8A8E3780796,
	AkSoundEngine_SetReflectionsOrder_m2E9718EF7E519F2A6B5B65F34C7971E1F4BD074A,
	AkSoundEngine_SetNumberOfPrimaryRays_m9F33D1AD9AEBC82867465549931A1E4A9AA27CC2,
	AkSoundEngine_SetEarlyReflectionsAuxSend_mA9050A7C9E8D07FEA16A2168C3E89E7F414C7970,
	AkSoundEngine_SetEarlyReflectionsVolume_mD32DD3934D93B84A256DF5B67643D16FA803A07A,
	AkSoundEngine_SetPortalObstructionAndOcclusion_mBFEAC2BFF17D66C95A87844747808992AF18E4E8,
	AkSoundEngine_SetGameObjectToPortalObstruction_m710E1FD3B56CBFD6F2C000C80535E488B11CBB61,
	AkSoundEngine_SetPortalToPortalObstruction_m3FB0121BFAADD8D5F6767BE97D091512E8E8CF35,
	AkSoundEngine_QueryWetDiffraction_m2EBC72F2BEF4278CCC9117DCFF0ED808A310E737,
	AkSoundEngine_QueryDiffractionPaths_m44D0032C443AE22FCBD4537F7A00965663EA678E,
	AkSoundEngine_ResetStochasticEngine_mEEC189E18E7F2C3DF479CA4D057149655532AC00,
	AkSoundEngine_GetDeviceIDFromName_mF3AAE8D16F9CA77DEB5B260CE3D1B50A1F4F225B,
	AkSoundEngine_GetWindowsDeviceName_mC224D13204773548E2F5188D8766D8A61CB86042,
	AkSoundEngine_GetWindowsDeviceName_mEA8BCBDA1789B00BDF6B1F12EA88653CCFAE2C12,
	AkSoundEngine_GetWindowsDeviceCount_m38FB53C671C79DDCB7D6167A63A6017F85A6029B,
	AkSoundEngine_GetWindowsDeviceCount_m2053107DE392545575524DA3B89A33ED01A24C74,
	AkSoundEngine_SetErrorLogger_mD3FD7A553CF5A894322511CF80D688A30B0D03EA,
	AkSoundEngine_SetErrorLogger_m937290CDE61876AFEF0F9256228FB4021D09BB7E,
	AkSoundEngine_SetAudioInputCallbacks_m5F6FFF905E9C78C994CCCF79D3AEFFC3FCEEE2C9,
	AkSoundEngine_Init_mD6D36E461297B1F6A8B5A5910A43EB588C439BC6,
	AkSoundEngine_InitSpatialAudio_mF9EB33FE95F73DC416AAD6DFC42D93CF37ADABDB,
	AkSoundEngine_InitCommunication_mEC2E07B9BDD999C7954EC585BC05BE7D89EEAA75,
	AkSoundEngine_Term_mABA25764A840947855A1DBCC37F5866241AEA5E8,
	AkSoundEngine_RegisterGameObjInternal_mAE02846F000E1DE41860178234EF4DAEBF8B55D1,
	AkSoundEngine_UnregisterGameObjInternal_mD276375C2D713093B92E5EA5CC848DEDE053276D,
	AkSoundEngine_RegisterGameObjInternal_WithName_m5048E6A0DACF7663ECC9DC17BA7E04A0A9F07101,
	AkSoundEngine_SetBasePath_m66C80A368D63637645A85793EA00A47558FABCB3,
	AkSoundEngine_SetCurrentLanguage_m5999F17AE4E41381F12F72A5B3233EAAD65C9449,
	AkSoundEngine_LoadFilePackage_mA9B42A3F2C8319E624A2E8CBB118AD0FD6FA2317,
	AkSoundEngine_AddBasePath_m6315F9F24652C726A7A3DAD05C6CA5D2DA1FF80D,
	AkSoundEngine_SetGameName_m9C8D19B05BADB9FAFF2242203D998F889F3C26DE,
	AkSoundEngine_SetDecodedBankPath_mD7812F391BDE561139F391960CEAB46FEDE31DCF,
	AkSoundEngine_LoadAndDecodeBank_mE93D5F05065EDFDE0E212C682558DBA2D85137E8,
	AkSoundEngine_LoadAndDecodeBankFromMemory_mBC06859EBCF8FE8E7A418211861ABD69E1A2154A,
	AkSoundEngine_PostEventOnRoom_mF89A76B5D42B12EDF2203C15AD2641E01ADC6987,
	AkSoundEngine_PostEventOnRoom_m8344C7CC27D8272396B37AA8033D005A2B21189C,
	AkSoundEngine_PostEventOnRoom_m8FB367F04ECE724BFC6702A2DB5ACEEDA66B00AB,
	AkSoundEngine_PostEventOnRoom_m6DB30727325FE2C44B8FF90EC466FE471FF83E4A,
	AkSoundEngine_GetCurrentLanguage_mCF2C8AE8D61B971AB5111A688CED08A12C11E2B1,
	AkSoundEngine_UnloadFilePackage_m0F9A2FE046BD9119E4213590E0C638DA16308CF2,
	AkSoundEngine_UnloadAllFilePackages_m1BAFDDF3DDBBA93BF4C4F83F127D612F6D5AB451,
	AkSoundEngine_SetObjectPosition_m3EB797F358A57DB3DBA35F9EE26950583B00E000,
	AkSoundEngine_GetSourceMultiplePlayPositions_mE18ED3711106C9AC87B037833D1ED3778A962244,
	AkSoundEngine_GetSourceMultiplePlayPositions_m7BCA31C9BEC55915D43B6BFB5A494B02D5489EE7,
	AkSoundEngine_SetListeners_m187185D9A6F877DAF1DD58C0A4B49AD2DA72554B,
	AkSoundEngine_SetDefaultListeners_mA52EE297C10EF2181730C3B76D8995C9611B418D,
	AkSoundEngine_AddOutput_m41B47C9C1765F7CD12A7CC91FA2FD229BD5510B3,
	AkSoundEngine_AddOutput_m5DC9F16A8953695F3F5F60F0E645FE2E8AB24BB7,
	AkSoundEngine_AddOutput_m570D666D8D9DE5ECEC90A4E031A5822F0745F3E7,
	AkSoundEngine_AddOutput_mA91CE03FF34AE8BB7977A7EC7EC41FFCC3F01F22,
	AkSoundEngine_GetDefaultStreamSettings_mD285B199646EC280039B9CD77CCB29E88EF016E1,
	AkSoundEngine_GetDefaultDeviceSettings_m0DF1B2F2CC61C9766E4DDDE2373C506984CAEE8D,
	AkSoundEngine_GetDefaultMusicSettings_m9EC5D720468350C5B1F27D8735E74A6D1A635B29,
	AkSoundEngine_GetDefaultInitSettings_m2855F8E6B3D91C45C65100C0ECD4E4C7ADE5FA34,
	AkSoundEngine_GetDefaultPlatformInitSettings_m4C75C0BF69E016FECD2A465F52363599D4DC88B3,
	AkSoundEngine_GetMajorMinorVersion_m062BD72411DD1DE1684B9DB91B73F58FD1D48B4E,
	AkSoundEngine_GetSubminorBuildVersion_mDF82E7C1DFB67C9D251C3B8AD8A8EDBD9C5EDCD6,
	AkSoundEngine_StartResourceMonitoring_m1DC9A55490046DAE46028527935EA168FC72745B,
	AkSoundEngine_StopResourceMonitoring_mC637BD82D21C46C78E67513FE53D11E1CF845F52,
	AkSoundEngine_GetResourceMonitorDataSummary_m4D00D1FCB12B1507DB7A4B1DD195C2DAEEA7EF5E,
	AkSoundEngine_SetRoomPortal_m128CCE2063D13299F6B82B51F14831762CB3665C,
	AkSoundEngine_SetRoom_mA86064A1B4BD95C8CDE9FC1D10015B76A2C719E0,
	AkSoundEngine_RegisterSpatialAudioListener_mFE8F588B76E0947ACA1621AF19D1AB39D3497987,
	AkSoundEngine_UnregisterSpatialAudioListener_mAB61CE861A98364FA6EAB5B991456AC6219CB9E4,
	AkSoundEngine_SetGeometry_m556200E8FA608FC35431ACBDC02D8DF969D97CFF,
	AkSoundEngine_PostEventOnRoom_mCC4DA02BD18ACCB5CC505888D4FD889F47441D30,
	AkSoundEngine_PostEventOnRoom_m707CEE5D5930506419477864E6D644CA3FAA9A5F,
	AkSoundEngine_PostEventOnRoom_m69EAD9D51B1C04CA22D9019A2F2135F9AEF1C58F,
	AkSoundEngine_PostEventOnRoom_m14ACE53AF68AD9038741174E8EADD83B7B48B341,
	AkSoundEngine_StringFromIntPtrString_m183A92BA446C63F725F7EDE8F6F9A498D9ED1E4B,
	AkSoundEngine_StringFromIntPtrWString_mF89EECB36344B06D70D748A8508C94F88992E5BE,
	AkSoundEngine_InternalGameObjectHash_mE72A602D2F6EBF7D0D9B37C19DD74BE4635834E0,
	AkSoundEngine_set_GameObjectHash_m48A5FE35BBE4F869BD2CFCD080C71D01ABFA6D78,
	AkSoundEngine_GetAkGameObjectID_m202ED5D95E2835E58B630C7F2DE7D840D8410E9B,
	AkSoundEngine_RegisterGameObj_mAD5BD4AAB5492D28803637116C210CDF6B0A92C7,
	AkSoundEngine_RegisterGameObj_m88BEB55AD3B0C6813F0547E8678AFAFED0A26DAA,
	AkSoundEngine_UnregisterGameObj_m6383A7D2557EE31C484343C0AE9637669328FA0B,
	AkSoundEngine_get_WwiseVersion_m6F901F22BD523F0AF0B2AD8C39519F565DF7E9A3,
	AkSoundEngine_SetObjectPosition_m7F41BD33AEA4554013B9D17A2B84411726309209,
	AkSoundEngine_SetObjectPosition_mF67940DFD2F6B863C8DF00539C89188A2A89FDEA,
	AkSoundEngine_PreGameObjectAPICall_m48E29E58EC8F748DCA759529B0321A4984909C47,
	AkSoundEngine_PreGameObjectAPICallUserHook_m047234B7CF7DB32AD9BADB35170DBD93F03B4A3B,
	AkSoundEngine_PostRegisterGameObjUserHook_m5E91D7C7266F2EE52754DDE8F491EF677CE00535,
	AkSoundEngine_PostUnregisterGameObjUserHook_m5EE9340C7545A549A229C835D20A6A4497A23343,
	AkSoundEngine_DynamicSequenceOpen_m70DBF118E596EA85059EB2CD1518C9033876CC90,
	AkSoundEngine_DynamicSequenceOpen_mF992B868159EBD920398CB102F5B27CD1A4EEA00,
	AkSoundEngine_DynamicSequenceOpen_mD4751B11808CAC02CE48E80C00CA360269149E79,
	AkSoundEngine_PostEvent_m7E8938273920D752507439A8EE036EA2818CEE24,
	AkSoundEngine_PostEvent_m905B15F711D8FADBD2B40278AC9E0B877392904B,
	AkSoundEngine_PostEvent_m6D65008EA2DF3ABE7F52D42987114D689C5C7F7B,
	AkSoundEngine_PostEvent_m70980C1B8E64FC6974A693637F1C3EF81B599EC5,
	AkSoundEngine_PostEvent_m72417B76B5265CE2A0BAC218C57599CB7D6A7D23,
	AkSoundEngine_PostEvent_m64457F8AE379D36449CCB761DFFFB87D680AFDA8,
	AkSoundEngine_PostEvent_m94C0D31BE717BFD2B2CBE7DBFD34E8F562B1C7DF,
	AkSoundEngine_PostEvent_m77C9AB5C87BF7BD63E1B3ED2C9E22A1919B08045,
	AkSoundEngine_ExecuteActionOnEvent_m02CB0A8128BF2C9219282588AF57131F260ADB15,
	AkSoundEngine_ExecuteActionOnEvent_mEB060B0245616DD68C515B6BA20C3D0569B04D8E,
	AkSoundEngine_ExecuteActionOnEvent_m28F981C2A3A7066FC0576B16DCE0B6CA7078BABA,
	AkSoundEngine_ExecuteActionOnEvent_m33770AFE0C9733490BAEA09A3E1CB8E722CE03E9,
	AkSoundEngine_ExecuteActionOnEvent_m8BA604E2E8EF30EE4176D032A9C19EEBAF8A531C,
	AkSoundEngine_ExecuteActionOnEvent_m8D8AE05B721C2B2E903DE20010E8E9A557194BB9,
	AkSoundEngine_ExecuteActionOnEvent_m9CDB7576D7F70BEF888765AB90843DE19E26628C,
	AkSoundEngine_ExecuteActionOnEvent_m1154660EB1BBCBCDEEB0F9817CFA022B1622B447,
	AkSoundEngine_PostMIDIOnEvent_mFE7175497B65E0FBB1DC5CBD7DB23470C9629BD0,
	AkSoundEngine_StopMIDIOnEvent_m8E8BD26C821D2DB66D754EB520049AE749D48F32,
	AkSoundEngine_StopMIDIOnEvent_mBA27C9BB70257A516E54EF22F347CCBD4CA686EA,
	AkSoundEngine_SeekOnEvent_m3DF6A7B9ED9E2415CB858248DCABB1360AAFC209,
	AkSoundEngine_SeekOnEvent_m453D6C943CD7F02906C8CF41EFFFA334B2E891C1,
	AkSoundEngine_SeekOnEvent_m77B3EBCB168E88BD1AF64E5D7E9693EF80365718,
	AkSoundEngine_SeekOnEvent_m393F70C546722F5B9F610AD52A3A142158D515DE,
	AkSoundEngine_SeekOnEvent_m7B51779C89CD3D60A6682915154D0CC4B60013DA,
	AkSoundEngine_SeekOnEvent_mB106554577E9A9688C5084D6E80C2C132F3A2591,
	AkSoundEngine_SeekOnEvent_m2FC4012852789222D3BD81F03795FABAD574FAA6,
	AkSoundEngine_SeekOnEvent_m1FCF4A0F7EDF41AE5D1637960820FE97609AD35F,
	AkSoundEngine_SeekOnEvent_m5ABF68DD7A2149E6D7D4AE61D2F597E0B1F60574,
	AkSoundEngine_SeekOnEvent_m6EDB30E001422008851CC17E6DFE71EDC0DD4576,
	AkSoundEngine_SeekOnEvent_mD505F18DB178AB78677D8D7E60699A030D7D54E0,
	AkSoundEngine_SeekOnEvent_mDB34C6E9B47975209219D155691EB2ABCBEB7AFB,
	AkSoundEngine_CancelEventCallbackGameObject_mB386120F4928236AC867D065568FCDA3FA60CF57,
	AkSoundEngine_StopAll_m2D130395DD6DE8E94BE6A78E2FC9B33FD35D34B4,
	AkSoundEngine_SendPluginCustomGameData_m70E8659586E519C836866791002C40C15FA099F9,
	AkSoundEngine_SetMultiplePositions_m37B992510C662E4D2165646BC7D926E793B438E1,
	AkSoundEngine_SetMultiplePositions_mB0D9AB01D2267F7499C48C8519240804208A39B4,
	AkSoundEngine_SetMultiplePositions_mDB29164F0C3E70FE459B2D453C32A3DC8052959C,
	AkSoundEngine_SetMultiplePositions_mF4F06464238BB58FE6811B3AEFAA949B3E96764B,
	AkSoundEngine_SetScalingFactor_m4F8EE1CEF8C646A95678BD02CDBE5D54724C9076,
	AkSoundEngine_AddListener_m343A49419DBD154D53B621451C337F382BDE710D,
	AkSoundEngine_RemoveListener_m8B8C4D475D8FA6B4110D409A88237A8F4C440CF7,
	AkSoundEngine_AddDefaultListener_m005008CF57169C57449856A8FF89AFDFE60A03FB,
	AkSoundEngine_RemoveDefaultListener_m21D63A4CE24A3CD3814413E6D61B27D05E6B4A96,
	AkSoundEngine_ResetListenersToDefault_m5531389F0B55F072D54B74A346AD7D0DBA0E161A,
	AkSoundEngine_SetListenerSpatialization_m316DB4780D3BA7C7079FFBECB9DF23EB14DC2219,
	AkSoundEngine_SetListenerSpatialization_mDE1CD479FABCD30D3634DB97C2B1F81DE89EFFDD,
	AkSoundEngine_SetRTPCValue_mACA3423638CCEEC641C69BCD01DFFD1C507A9FE0,
	AkSoundEngine_SetRTPCValue_m81662F12666CAA2A756329480A828A440FCB4424,
	AkSoundEngine_SetRTPCValue_m189001A4EDABE657C691CD9D918DAB941BFC5F42,
	AkSoundEngine_SetRTPCValue_m18561150273DA0C176DADCBDF426E70613AF356D,
	AkSoundEngine_SetRTPCValue_m7D7C415C8DB1F2C0175AEE4FCE788CC164433FD8,
	AkSoundEngine_SetRTPCValue_mD304970A58A46F9CB7A74CC602B3ED62C82DEE33,
	AkSoundEngine_SetRTPCValue_m5904921E5AA612C5E25E46AAE6A6D4577665E31C,
	AkSoundEngine_SetRTPCValue_m09EAB61110C70A0FC3492A743348E8443CE3BA17,
	AkSoundEngine_ResetRTPCValue_m1DEE4DFCCBC86F5EE1689D99C0DAAF5C8AEE46A3,
	AkSoundEngine_ResetRTPCValue_mD5DC8E93F51062F3ABA2A9550178E9A06A4F9319,
	AkSoundEngine_ResetRTPCValue_mFFB131240CA97BB0DA47254BB616416006E2DF10,
	AkSoundEngine_ResetRTPCValue_mA7F5EE2DA7853EF272EC2BD3E1CCE1EF5B58A6CA,
	AkSoundEngine_ResetRTPCValue_m4CDCB7863073E3A4C1839D3D1B5623861103D9E1,
	AkSoundEngine_ResetRTPCValue_m35DB08F1688272A36E7276E2A67400126C475747,
	AkSoundEngine_ResetRTPCValue_mC590A821B98EF06F069B56CDD9A020E8D0717B3F,
	AkSoundEngine_ResetRTPCValue_mB467791C655970C5CA6B97E7A2E49B55BC526845,
	AkSoundEngine_SetSwitch_mB25E783656DD320341B7578E08A40F5EDD5046CA,
	AkSoundEngine_SetSwitch_m2EB082DE338445EC23A9AE5ADD07C64790C5A7FD,
	AkSoundEngine_PostTrigger_mAE35A465050B381130B8C1710F29A7C204600C0D,
	AkSoundEngine_PostTrigger_mE1CF4655B2A55CE30BDBE79A382CCC5CBF2F1F0D,
	AkSoundEngine_SetGameObjectAuxSendValues_m053C3E4B29BD8E50254487D6BF2645AE4D192FBA,
	AkSoundEngine_SetGameObjectOutputBusVolume_m587AB4AF7161076085A8B8A96A300C910156E5AE,
	AkSoundEngine_SetObjectObstructionAndOcclusion_m68C2AFD0234DD4DFECED998D1DE2B6B5BB250CCF,
	AkSoundEngine_SetMultipleObstructionAndOcclusion_mCA19F81D65393F1E4D915C2E7116204A99857834,
	AkSoundEngine_PostCode_mC7B9BE2BF8A7E00808C9A82370D3A251FCD8BD04,
	AkSoundEngine_PostCode_mD470EC99465EA7A8C46FF3F6598A7833B0119308,
	AkSoundEngine_PostCode_mDA23321BABDE8231AE6D9265D88432A0E401E7E9,
	AkSoundEngine_PostString_m3D5671A6B5AAAAB2AA898E0B7232A02573E1F5F2,
	AkSoundEngine_PostString_mDB0703C7E02E99CC91A098A6426F8328A90364AE,
	AkSoundEngine_PostString_m03F125C01DEE62C392A70BAF0E5D3D3C0A0CAF9B,
	AkSoundEngine_GetPosition_mDE86210C40A674F6866DEEE0E3E2210A4FA918F5,
	AkSoundEngine_GetListenerPosition_mBBC6BF6A90A9D8FC7FDEC7DE4565E29449AF9949,
	AkSoundEngine_GetRTPCValue_m09BD553FBF1926B313A4C7FEE2D23221449B03B3,
	AkSoundEngine_GetRTPCValue_m1C3F5A34B688C1FADDF5A18CE2D2095F4172E140,
	AkSoundEngine_GetSwitch_m7E6BCCEC6C1C16553FDF882C91A2FB3FCD5F24BF,
	AkSoundEngine_GetSwitch_m97F22923A4AB409FB38274E0F2DF68779CE42FC0,
	AkSoundEngine_GetGameObjectAuxSendValues_m886009AD9D7DDB286A0701C88E77D99BE7DD602A,
	AkSoundEngine_GetGameObjectDryLevelValue_mE43F45A75C37F78542A54F4A58B5660949664462,
	AkSoundEngine_GetObjectObstructionAndOcclusion_m1EF941D7227EA14DC57C789D8B15358B3EA665DE,
	AkSoundEngine_GetIsGameObjectActive_mE2851C5C354E9BA89EDF55273F73716221E0719F,
	AkSoundEngine_GetMaxRadius_m8E67D78A61DA80FEDA3BEC7572D3D0FAE752A818,
	AkSoundEngine_GetPlayingIDsFromGameObject_m6645623B42D3AEB0D68EC11D13E0C430347D09B9,
	AkSoundEngine_SetImageSource_mAA9FDCB5B945E6B32223245DC75FA8405BE3F514,
	AkSoundEngine_RemoveImageSource_m3C917A1F8385FBEAC30912C605051877EAC209C1,
	AkSoundEngine_ClearImageSources_m4C678C186121754512FBA716C9F68E5A2F3EDF12,
	AkSoundEngine_QueryReflectionPaths_mDD42C223832C9D720A2A95992A551363C91D35C5,
	AkSoundEngine_SetGameObjectInRoom_m0D945984EB6E7C0FD0FDFF899B46CD48563A3288,
	AkSoundEngine_SetEarlyReflectionsAuxSend_m7EA560C236DBA6841219022DD0E96F212CD6708D,
	AkSoundEngine_SetEarlyReflectionsVolume_m4DA386234E9E8ACE0F7C8B255BFC1A7F14F38B99,
	AkSoundEngine_QueryDiffractionPaths_m6B8779419173C2B117366767D02A490A946AE345,
	AkSoundEngine_RegisterGameObjInternal_m00157626B44732F7AA53017715DCB6E415019980,
	AkSoundEngine_UnregisterGameObjInternal_mA709DC3EEFB0D1B2AFBE423AD257D26A94693E97,
	AkSoundEngine_RegisterGameObjInternal_WithName_m8D82B28EA957C76BE8BF546D9EE938F13E0766E6,
	AkSoundEngine_SetObjectPosition_m178B9216AE9EAC6431D5B3A2A4383DCB5E6A829E,
	AkSoundEngine_SetListeners_mCC4E464748FF7A3E77BA7FAA80B7499FDA6651A7,
	AkSoundEngine_RegisterSpatialAudioListener_m93D0EEEA4455F143DEF63C32AAA2AD30E9AF4BA7,
	AkSoundEngine_UnregisterSpatialAudioListener_m1E79F0AE30EA2CD5FA9EE70EFC4B34C444BF0C46,
	AkSoundEngine_StringFromIntPtrOSString_m4999C4319EDA8D57987FD3D9C4B36371FAFA9A03,
	AkSoundEngine__ctor_mE1859641E97F76C8EE89106C0674F63B4E3EC8F5,
	AkSoundEngine__cctor_m3C9D08B15D23ED6BEEE177C7C1553A66B94BD8A4,
	Ak3DAudioSinkCapabilities__ctor_m16694143648C91B4FA740F176F4EEED56336DD92,
	Ak3DAudioSinkCapabilities_getCPtr_m947EFAE48FF07713F15133E4F758F0D14ED6BC20,
	Ak3DAudioSinkCapabilities_setCPtr_m996DC3C1054D382F791C55750281E30C399A9331,
	Ak3DAudioSinkCapabilities_Finalize_m558A5306E6E79F96B3E30002E008ADAA209BB9D9,
	Ak3DAudioSinkCapabilities_Dispose_m50CFDEBCED305BF1309B24AE7DAB4BFF50DF713D,
	Ak3DAudioSinkCapabilities_set_channelConfig_m22DC5035947ECC1E4FA4076846E2BEA34517CB5B,
	Ak3DAudioSinkCapabilities_get_channelConfig_m0801BE2F1357F81BB065D63FFF2FE7457AA9952E,
	Ak3DAudioSinkCapabilities_set_uMaxSystemAudioObjects_mE419B9E1811466EB321BD450CA63F05DE44259C5,
	Ak3DAudioSinkCapabilities_get_uMaxSystemAudioObjects_mBC8A2826E7454E4E3F9234C82560FB2ED37F771E,
	Ak3DAudioSinkCapabilities_set_uAvailableSystemAudioObjects_mBECB4E1219983DF572DBFCEBF4D275CE7E224216,
	Ak3DAudioSinkCapabilities_get_uAvailableSystemAudioObjects_m2DE901E901CB9368630FE7855E836B2D3C437C06,
	Ak3DAudioSinkCapabilities_set_bPassthrough_m1B22B75353F8C7A44C397FFEE4143588F49CA49C,
	Ak3DAudioSinkCapabilities_get_bPassthrough_mDA791DD6FE005231CA431416C72E9A7EBD842AAC,
	Ak3DAudioSinkCapabilities_set_bMultiChannelObjects_m102785E59834AD3E3CE9C03CE0CD55952F8CA517,
	Ak3DAudioSinkCapabilities_get_bMultiChannelObjects_m79370435DE12C93525BCA8C2A6F0C434792721EE,
	Ak3DAudioSinkCapabilities__ctor_mA7F77E796CB960B42769FAF85D4A188C5F824A5B,
	Ak3dData__ctor_m8E9BEBD59BCADF5F316ED31883F2A4B3884A14E1,
	Ak3dData_getCPtr_mD1935D4FBDF8398ECDA0ACE09E868CE3A77CCA35,
	Ak3dData_setCPtr_mD03F98158687002FBF60C62FA60B215F90BAD568,
	Ak3dData_Finalize_m00DFF3312A482106E7177C5ECBC9E4EE6CE9532A,
	Ak3dData_Dispose_mB66E0D999D5CEDE040D6DEAFE0A6EBEF6FD92926,
	Ak3dData__ctor_m62C04C13D1CD844B299273BFBD43C86E360C56B4,
	Ak3dData_set_xform_m252383DB7E6B7AEC0B26F423C428245865B5E155,
	Ak3dData_get_xform_m31181402FF279E5B537E2030A51BF60887885BDF,
	Ak3dData_set_spread_m42C3187F81188CB63D40E9F2A7F1E535687C7E8B,
	Ak3dData_get_spread_mD7649F72064B12AC1566F8663A52F00EBAEE3578,
	Ak3dData_set_focus_m36A8FF5BE32A33018EA12761741C0601AB01FC3C,
	Ak3dData_get_focus_mAF724B465FC3C1404A0D835A95393379F65696BC,
	Ak3dData_set_uEmitterChannelMask_mCE8D9D1194E84E2CC77853D6A2C27DD6A74CB7A2,
	Ak3dData_get_uEmitterChannelMask_m65C7F82A985B4401BEDE51F7F32A5D65711E7DD2,
	AkAcousticSurface__ctor_m5A6D4B22AC084006DBE03F4E17DE01B02BEAB46A,
	AkAcousticSurface_getCPtr_mB9D49F92E0A94E083ADD6D5C360FFD69742534E0,
	AkAcousticSurface_setCPtr_mA94C65DC27090353A084B34B4C8917079D67D031,
	AkAcousticSurface_Finalize_m4FD1F459B57E054E2F67A893809F28EA5531312B,
	AkAcousticSurface_Dispose_mFBF85CC5B42109FB987792F6645F66246B3EB790,
	AkAcousticSurface__ctor_mD2EB9DDA17B1B4D300E77BF9DFBEC69EBDD11F06,
	AkAcousticSurface_set_textureID_mCCECA46BF32160949FD1BF1CFDC7F1CCF0F7C143,
	AkAcousticSurface_get_textureID_m00707E9CC7EFBBFC498208A72178E8430ED318DD,
	AkAcousticSurface_set_transmissionLoss_m9E15D05230348B50106CE7A482E173C877CCE14A,
	AkAcousticSurface_get_transmissionLoss_m1211BA1DD3C2B0F92EAB33713E5CE46AA135392E,
	AkAcousticSurface_set_strName_m0F7BB1848D37C23D6B6E2A752EB764FB04527A25,
	AkAcousticSurface_get_strName_m9E84B24F32F98FA4C4276DD3D883A74238178AF6,
	AkAcousticSurface_Clear_m08399E44D2BE967189B6B8D7548634D4C22135EF,
	AkAcousticSurface_DeleteName_mC47EACF6A6BE67FC9F205B541B43F23ED2266B61,
	AkAcousticSurface_GetSizeOf_m7F99E8CEE43FA6491C1521F72EBE75E22EDCD234,
	AkAcousticSurface_Clone_m257368A068FA94251CC6775DABDC9F121B81E87B,
	AkAudioFormat__ctor_m5734790434D8BDD2A019D3D4435E23AC73BEAE4D,
	AkAudioFormat_getCPtr_m33D3368D15F2172ADE36C91E32C87855A88766E8,
	AkAudioFormat_setCPtr_mF8B68B56007F361EFE3FF365435D25C1CBF6986F,
	AkAudioFormat_Finalize_m6009921F7F31C0EA52DE0B962CA09B18756ECF85,
	AkAudioFormat_Dispose_m9754C5251318D62BB122836651BD66E29FDEE896,
	AkAudioFormat_set_uSampleRate_m5051F67C216FB1E5B4251F8E26559A7B037C90E0,
	AkAudioFormat_get_uSampleRate_m14D65D3EF5D631752398BDC20438C21837E87F07,
	AkAudioFormat_set_channelConfig_m79323323A933B1786D107E2CADE64B2DF1B0C484,
	AkAudioFormat_get_channelConfig_m481F364AFA8A6BAEB4E1126887C25E9F27E1EDB9,
	AkAudioFormat_set_uBitsPerSample_mCAAB27154011F877EB94AF008795F7120DB8CFCA,
	AkAudioFormat_get_uBitsPerSample_m653251DCC92BC77A95EF16976D66B255F09B7BC3,
	AkAudioFormat_set_uBlockAlign_mC193C01AC42A7512EB06D36689532D89C8C23D13,
	AkAudioFormat_get_uBlockAlign_mB93C9359291B549122314597AFCE146257A52435,
	AkAudioFormat_set_uTypeID_m7D423387B1BA1BC8CDE9E5F279549E5B71947AC8,
	AkAudioFormat_get_uTypeID_m0447F16D676AB6733AE6A8E435BCB1D12B208D49,
	AkAudioFormat_set_uInterleaveID_m7425E10BD1C2965F38192387D9BC712087D15C82,
	AkAudioFormat_get_uInterleaveID_m33EB44AAB313901243CC5A411CF679D4B6B61CBE,
	AkAudioFormat_GetNumChannels_m0B06CE645C02D552B14D034F86DAD767F7F98C52,
	AkAudioFormat_GetBitsPerSample_m6D65D6540A81D383F573D81939DB557BFE6AC827,
	AkAudioFormat_GetBlockAlign_mEB19C9D1C4FD556E62F2ECD62510EF3351BCCCC2,
	AkAudioFormat_GetTypeID_m1506E67A466A663180FC11DA84860EDE665938B9,
	AkAudioFormat_GetInterleaveID_m60A77FB41F7157C245F91B4B0CC1AB7BE9C016D1,
	AkAudioFormat_SetAll_m01B7E012099489B17B2E8E43A98964D05E57168E,
	AkAudioFormat__ctor_m1C9222AF98C0022639CB48350CEF6D58F57E925B,
	AkAudioInterruptionCallbackInfo__ctor_m87D087D4E5A9B771A8222AC9885D5CDD81FBD762,
	AkAudioInterruptionCallbackInfo_getCPtr_mAEC8A1FA717A856796CCFDFE928EFE1207D37012,
	AkAudioInterruptionCallbackInfo_setCPtr_mF7A686A50E0EBE14E7EA8D9FBCDE94B2A2FE774B,
	AkAudioInterruptionCallbackInfo_Finalize_mC860B46910E9B6895220F8015803CFB71872B301,
	AkAudioInterruptionCallbackInfo_Dispose_m03CC716316200B42F57AA0DFBB9AAC553990E0BA,
	AkAudioInterruptionCallbackInfo_get_bEnterInterruption_m492795F810086F9AA8D13A014C7B2F126E3BC7E9,
	AkAudioInterruptionCallbackInfo__ctor_m7C13C38F339B9A7AF3D89CBE9706BB2C255B042E,
	AkAudioSettings__ctor_mBDEC3778EE2326F41FA612BA94FA342CD9DD25E4,
	AkAudioSettings_getCPtr_mDA6583827D95B48FBAEED6AE3B75C0D743377BD4,
	AkAudioSettings_setCPtr_m241B979B84271D2A7C798523AA3774F9558EB7AC,
	AkAudioSettings_Finalize_m9926209231144A165E3B2F275496D86B582FE6C5,
	AkAudioSettings_Dispose_m96E6B3CB7957080E87038BFFAF6FA42E9F1476B6,
	AkAudioSettings_set_uNumSamplesPerFrame_mF39771309C31DFF116EF15AFA68489992E422D65,
	AkAudioSettings_get_uNumSamplesPerFrame_m68F02F89229B3E01A08654ED93D42B08FAE8B65B,
	AkAudioSettings_set_uNumSamplesPerSecond_m9D51F6964BE6F9EA1683B56F7AF3CD88CA2CD106,
	AkAudioSettings_get_uNumSamplesPerSecond_m1B1FA295BA8E67667FB606ACB19A760FB9347FB4,
	AkAudioSettings__ctor_m2C2D6234B829F4958D7C95C1E575B348F4FCA377,
	AkAudioSourceChangeCallbackInfo__ctor_m444BBBCDF0D8530A43ABB6B5FFADE374E6F7276F,
	AkAudioSourceChangeCallbackInfo_getCPtr_m100E66C0BE579D72B1DA66808041B3C3405BB576,
	AkAudioSourceChangeCallbackInfo_setCPtr_m2093E45E5F9029C1BB2CF0D8FFD1B048979BDC35,
	AkAudioSourceChangeCallbackInfo_Finalize_m31F683CE1D7EAA1C836D96DFAEC7AAC920129E8B,
	AkAudioSourceChangeCallbackInfo_Dispose_m901997A5E6BF27B42E72442D5B6325C6FE116D64,
	AkAudioSourceChangeCallbackInfo_get_bOtherAudioPlaying_m186269EDE6A779C7BDA040A0DA5D2F73D6979703,
	AkAudioSourceChangeCallbackInfo__ctor_m4DBCDC7D8885B9D8B7449C73AE34ED1A02C726AC,
	AkAuxSendValue__ctor_m5952FE9F609878673FC8EEAAAAAC90AFE2E0B8AB,
	AkAuxSendValue_getCPtr_m77F32981AE8780C855D679105EAD5DA56C0C9D72,
	AkAuxSendValue_setCPtr_m04D7930D3A541F930EEEAE71A7145A2A6D8FD03A,
	AkAuxSendValue_Finalize_m10A9D3F3587D4D5CD06BCFF6EB7C45C43F93F6D2,
	AkAuxSendValue_Dispose_mDD80E172129FADDA1ACEF6488F29A3B8CF61D37A,
	AkAuxSendValue_set_listenerID_m7AC62724E34CD4D68F1AE7AB71048F39E9BE10B8,
	AkAuxSendValue_get_listenerID_m45395362690DC76587D73C203BBD168C6A0A4E21,
	AkAuxSendValue_set_auxBusID_mE70F5055E04770AD9EA0DFA02633E204C53F4A01,
	AkAuxSendValue_get_auxBusID_m6CD0162E52D42D311B59E9AB3CE4C20C9BF3BF12,
	AkAuxSendValue_set_fControlValue_mD4249842891A62BB26CAEDD921F8AD92FC4186B3,
	AkAuxSendValue_get_fControlValue_m2EDC2705C495F8B502E3FD7E3BC879DDC2F3CF44,
	AkAuxSendValue_Set_mBBD480900EB83C66DE3712B4DB64E95DA8C6424A,
	AkAuxSendValue_IsSame_m6488A2D7B5062C809680CBC006AC8CB4C2E5A870,
	AkAuxSendValue_Set_m7EEE12544D62D2CAD9F49D969561FF01F5CB14AA,
	AkAuxSendValue_IsSame_m9B3389C41BB4FF9FC30A9518CF2367386A2D4EBE,
	AkAuxSendValue_GetSizeOf_mC725ED49C8C0AF345947952E32CAFFF5B3BB5A6C,
	AkBankCallbackInfo__ctor_mF6B8DF874DBA4B7D5D23D9DA4416AC21B3362CFC,
	AkBankCallbackInfo_getCPtr_m4E358BD184C28E369EBDFD2ACF094AED9117C43D,
	AkBankCallbackInfo_setCPtr_mBDBBDE3D3110817F6641281D1AAC2E0804534C0E,
	AkBankCallbackInfo_Finalize_m3B8903780FA78EAAC51F61EC46BCBDF967708B0C,
	AkBankCallbackInfo_Dispose_mC0E937B5CCD9139B9A4C6E2CE4CABF06A38537E2,
	AkBankCallbackInfo_get_bankID_m97284999C7BDD41232D34B9FD456E8F7AF0C71E2,
	AkBankCallbackInfo_get_inMemoryBankPtr_mCF91AD5B87A40799742A8E539A352B39F3F72946,
	AkBankCallbackInfo_get_loadResult_mFAED163CAF1F0D940B17702025F681E8C2702506,
	AkBankCallbackInfo__ctor_m3920B4E9590D140AC878559E3488926F18BD41CA,
	AkBehavioralPositioningData__ctor_mAAE1AA6B45F0C42AC2D1C21AFDF0C214FB63B88D,
	AkBehavioralPositioningData_getCPtr_m636F7438DED06B4ADB6F71711FA1C419023DC149,
	AkBehavioralPositioningData_setCPtr_m43797B34B9B0AEA615BFF31088FEEB09F45AE1F7,
	AkBehavioralPositioningData_Finalize_mA5F65EFA94C1A81C62006A2801642A89545CFCDB,
	AkBehavioralPositioningData_Dispose_m170C5701DA1662B37914695EAFB2885BDD5C795A,
	AkBehavioralPositioningData__ctor_mFDD5B99A0A7BED5A9B9D135A2F0C09B532F0304B,
	AkBehavioralPositioningData_set_center_mDCE1282ED087D60F93BA3B466016523E53E8D919,
	AkBehavioralPositioningData_get_center_m6B22E5F41E73EBF0631DB0F2F6AFE8223B17675C,
	AkBehavioralPositioningData_set_panLR_mC45CF36A6A4453DAAA504316129B561DA8B32584,
	AkBehavioralPositioningData_get_panLR_mBC42012C9670A16094E2D956BCAE274F761E1C7B,
	AkBehavioralPositioningData_set_panBF_mC93D00F8B35FEC30283E247AB048C0BDC792C7FE,
	AkBehavioralPositioningData_get_panBF_m342C791CD66293F5B908467A97759D9FB6F4ECB3,
	AkBehavioralPositioningData_set_panDU_mB95E57A9D1795964F3666772195CA382C690923B,
	AkBehavioralPositioningData_get_panDU_mA34BDB7C22DF82FAD04161EC99533F5AB015D0C9,
	AkBehavioralPositioningData_set_panSpatMix_m12FF543114239616C793E655F5FE46238173128A,
	AkBehavioralPositioningData_get_panSpatMix_mA79ED2E993170E1348DD7468B23BC938974E1BF2,
	AkBehavioralPositioningData_set_spatMode_m2CE143297BCA6C89E9A4368D2DE1749C093D0D18,
	AkBehavioralPositioningData_get_spatMode_m2F11E2E8A1520B2BD3D69E59A7E767EDC0BCEC9B,
	AkBehavioralPositioningData_set_panType_mE41036AC92D188C2D6DC350968666946276978DF,
	AkBehavioralPositioningData_get_panType_m8BBC73904E23E135C72A44A40ABB0F73FE8981E1,
	AkBehavioralPositioningData_set_enableHeightSpread_mEF74A890B9E6FA4D4ECCEAC3F0A4F149296918D2,
	AkBehavioralPositioningData_get_enableHeightSpread_m7E77990EEA0FFE170A346A0DCE8CBF89858FD3A9,
	AkCallbackInfo__ctor_m4ED02ED33112DA89B6B4C1CC0A2EC5E545D4D762,
	AkCallbackInfo_getCPtr_mA3456C854E893541CBEA41117C541AA6E279C4D9,
	AkCallbackInfo_setCPtr_mF01D727CBE6FCBD0402B524519D870E461AE8A93,
	AkCallbackInfo_Finalize_mDE97E9539682A3BEF3793E0D1CE4FB06D23BEA48,
	AkCallbackInfo_Dispose_mC4C88515653188B22038AC93BE4F7A0AAF8A3C5C,
	AkCallbackInfo_get_pCookie_m7E82F3E764712A32F478CCD37AD683AEBEC7A82A,
	AkCallbackInfo_get_gameObjID_m4EE0B837BB822C20527A14E76176C3DB64D08B89,
	AkCallbackInfo__ctor_mEA6B5F9D853960E871D0BB03A74129E7CE4611AE,
	AkCallbackSerializer__ctor_mCF5A85DD9A518CDCE7391C7C7AF1FD4B4B87AAD6,
	AkCallbackSerializer_getCPtr_mD4EED749026F4D3EDCDB633C25F9CF78536AAB20,
	AkCallbackSerializer_setCPtr_mC148F0D5D5631D5661067A46F5849662B8B1DBD3,
	AkCallbackSerializer_Finalize_m21417685D8936F26F296FDC8F1871E00FE251607,
	AkCallbackSerializer_Dispose_mDF0C05BD823333AE36CF8B81A865200DC92628A1,
	AkCallbackSerializer_Init_m42F308599B3B55EDB6D388B93FD09628C7B36685,
	AkCallbackSerializer_Term_mB685FCD620C6876D206E9684182727E0163A7AF1,
	AkCallbackSerializer_Lock_mEC48171E191DCE3CD66C1B000928B4144A30231D,
	AkCallbackSerializer_Unlock_mB1F0AC33B3948350B8A97079001B22835F33DCE2,
	AkCallbackSerializer_SetLocalOutput_m5947A4D89D871B6032175146C77F3C5975683329,
	AkCallbackSerializer_AudioSourceChangeCallbackFunc_mD5D1B61D556B9627BB35A726F88A6C124C960A38,
	AkCallbackSerializer__ctor_m28D00C898D25AB7B791B943EA011B94E7891EF33,
	AkChannelConfig__ctor_mCB9D8545FB0EB39F7A3B7926DA2F186160ABBEE0,
	AkChannelConfig_getCPtr_mCD18E1D81542E4554CB2819E8CCB730C7BD9F777,
	AkChannelConfig_setCPtr_mF2ACA6B6DEC3054B1CFB6AF66B3FAC1AFB513B05,
	AkChannelConfig_Finalize_m22E7E632AAB667294045920B1E3A8F0CD9ECCC8A,
	AkChannelConfig_Dispose_m8B5C10DD4491301B934472EB0E5181B1FEB8874C,
	AkChannelConfig_set_uNumChannels_mE1C94DD489E951D5A37B52A34AB752CB927B64BC,
	AkChannelConfig_get_uNumChannels_mD661B80D5F0E81D0810EE7A6726EBE48EF1F8FA0,
	AkChannelConfig_set_eConfigType_mB87CBAB2AB6866D741E098E74655D9E9F61609FA,
	AkChannelConfig_get_eConfigType_mF0760A505103A4CE0EE59FCD96C50501E077DDA4,
	AkChannelConfig_set_uChannelMask_mEA95366FFED9E48BF800544BBF79D32060BB5332,
	AkChannelConfig_get_uChannelMask_mA4D3D601BBE03004A59DFF58F8E2BF71EEFD43E2,
	AkChannelConfig__ctor_m1622C6F1B99DADFADF488D3A94BD4C39797B5EFE,
	AkChannelConfig__ctor_m5418325A8F43ECB7F9C7D1FFB85C14FB8B417A56,
	AkChannelConfig_Clear_m9CBF41A0B612C48337A3F3C478ED2296A41207BB,
	AkChannelConfig_SetStandard_m3C85D2A71F53E4737FEA6BD191F692AB0C029080,
	AkChannelConfig_SetStandardOrAnonymous_m5567106262B79E505E6ABC1E339BC0E36C7E83AB,
	AkChannelConfig_SetAnonymous_m2F56048EE2B6B77A952A4A1C785040F7A74B1AD0,
	AkChannelConfig_SetAmbisonic_m5DAFE7C1A5DFA24BD3DE95BE2BE401C34101264B,
	AkChannelConfig_SetObject_m62F32DF06A87F008A667040049DD1C3D3BCDA8DE,
	AkChannelConfig_IsValid_m09179E49F1D8F0FC16F5660791BE070AF0554B42,
	AkChannelConfig_Serialize_m4CF64519C43A0D97DF228A3F67D1DBF4DF5633F5,
	AkChannelConfig_Deserialize_m6072124CB5511E9986CFF2D30022BC6B31CD2990,
	AkChannelConfig_RemoveLFE_m8C764FD85928D0AD590EC9401A11286161592BCB,
	AkChannelConfig_RemoveCenter_m5D804810D6D08647E6D77F0284CF242BF318DB10,
	AkChannelEmitter__ctor_mBE57C67A52B8252FE10158C1F0044992BC05B7F6,
	AkChannelEmitter_getCPtr_m61FB7714FF57B3C6FA45E28BB1A0126E3C26A3AA,
	AkChannelEmitter_setCPtr_mB5CA3C5FEF6E6589D03C4134F2735CD250157E45,
	AkChannelEmitter_Finalize_m9B0486ECB153553F0DA8E55BB9C7338D1324F048,
	AkChannelEmitter_Dispose_mC5E614BC8356D9E2284608DA7C5426859FF6FC5F,
	AkChannelEmitter_set_position_m67D313F65ADC57F9A84E535633163EF1305FF8B8,
	AkChannelEmitter_get_position_m56CEA579F882040EA1F4A75026A7F2F1D3F89B58,
	AkChannelEmitter_set_uInputChannels_m217B14136AFC98269E391EE9EC4B9DEC94C69D43,
	AkChannelEmitter_get_uInputChannels_m3001EC197707CB7AA7BFA71E1E4A67245CF5EA01,
	AkDeviceDescription__ctor_m06BF7180DF4E20D413798484BFAE53D3A96C3B88,
	AkDeviceDescription_getCPtr_m5932B18B957F94D0D167825631AA9BD39B9E7392,
	AkDeviceDescription_setCPtr_mB47AE9FC9C884EC8F9851CE7F0DB8EDA51706ECA,
	AkDeviceDescription_Finalize_m783CD6C73A858E8BE76D69F95716A776C24B36A1,
	AkDeviceDescription_Dispose_m402441508C6F4231FCB8BBEC1CAB0D6C0EC83381,
	AkDeviceDescription_set_idDevice_m445A879BCA83BC5761FA905742A3C9FED0329163,
	AkDeviceDescription_get_idDevice_m01D1AC997715D3DE8A55A76FD77CFBB5B2887A08,
	AkDeviceDescription_set_deviceName_m497F041D0539BA02ABBFDC18043DD3AC4BFFD7D5,
	AkDeviceDescription_get_deviceName_m7B611C7C6188F4E2DB87FBB4EEF689F543CE8CAC,
	AkDeviceDescription_set_deviceStateMask_m58933DD4EFF7ADC6ED23258441C33E6D66D36D71,
	AkDeviceDescription_get_deviceStateMask_m28B8C3F56A520DC1F286CC92A4738C0EF301AB17,
	AkDeviceDescription_set_isDefaultDevice_m5BE3BBFCBC7B290BF2EA0FB88DC750157C28218B,
	AkDeviceDescription_get_isDefaultDevice_m008664B7F7F6B94912C88E2F27E9D94F02A4A1D7,
	AkDeviceDescription_Clear_m90A24092F300BAFF60051A1C8EB8088D57FE3582,
	AkDeviceDescription_GetSizeOf_m13334BEAE39D8B122CC51EC2AE154912D54C2B25,
	AkDeviceDescription_Clone_m3B345714B62C8EEA4F0128E9D5F69F3C33A7B319,
	AkDeviceDescription__ctor_mA1F37A0D6201722EA12FDE7CEF7B07B7AF8F6B59,
	AkDeviceSettings__ctor_m775E6A5B47254363AFC57684B377CDC0E3233734,
	AkDeviceSettings_getCPtr_m18CD7B679D1959C299BCB21102EEB02872BBDE3A,
	AkDeviceSettings_setCPtr_mA8EED52D385487EADC38E17CDB8C5AE7550B829A,
	AkDeviceSettings_Finalize_m60AC346305ACD65B5D9E5B363C87E40F9F883B61,
	AkDeviceSettings_Dispose_m5F2C2BCBEB835B79D9E5B4144EF9FA71313EF27A,
	AkDeviceSettings_set_pIOMemory_m0676CD349254CA63CD728C21D049EDF3A6FBFA04,
	AkDeviceSettings_get_pIOMemory_m0A6F4B706BA320BE4C6666BC1FA07E092A6F6187,
	AkDeviceSettings_set_uIOMemorySize_mBCF53CD1D71E26759FCD742F232980B202D0F04F,
	AkDeviceSettings_get_uIOMemorySize_m4CE9FE4345BF1699AD527CD0988EA8E940770E92,
	AkDeviceSettings_set_uIOMemoryAlignment_mAE372FDE63D7AA24B5DF1E97A16854FD5DE2ADC9,
	AkDeviceSettings_get_uIOMemoryAlignment_m232AE7D769C52BDC376823C787073BB5A86D9E76,
	AkDeviceSettings_set_ePoolAttributes_mD5EF8B04E7D83FE16F6AE81D28368B9E3F2D38D8,
	AkDeviceSettings_get_ePoolAttributes_mFFDF74FC8786289AC6EF709FD1E724323C48C2C1,
	AkDeviceSettings_set_uGranularity_mDFCB31C61E587F3D5E3D960A350C5C2EE9C56509,
	AkDeviceSettings_get_uGranularity_m063846E4B7CD18B41EE87622B94767D0F09A8E71,
	AkDeviceSettings_set_uSchedulerTypeFlags_m8E881751B2BE680C5EFD12C57B97DD18B2EE6251,
	AkDeviceSettings_get_uSchedulerTypeFlags_mAB1DCCFA0B7DA24AAFD6AA8F80A41BD536C71F3A,
	AkDeviceSettings_set_threadProperties_m7380AABF5116568B251F8C9E3AA88B2630AA1163,
	AkDeviceSettings_get_threadProperties_mD6A5320E14917206B3139FB93DBE5A6CED5E7F45,
	AkDeviceSettings_set_fTargetAutoStmBufferLength_m8896CB456A85A4066D7CB7D7FBA5BEE4FBAB04AE,
	AkDeviceSettings_get_fTargetAutoStmBufferLength_m78D983D190826696963A47C524A552C840748273,
	AkDeviceSettings_set_uMaxConcurrentIO_mAD46F8AE20435451D1AD3ED373925CEE451E0D28,
	AkDeviceSettings_get_uMaxConcurrentIO_m8B7B6437DB6D11841FC977AB54C83BE49359DF5B,
	AkDeviceSettings_set_bUseStreamCache_m682F252739D007C6CF933B01BA2DC5BBC619E942,
	AkDeviceSettings_get_bUseStreamCache_mD66042296D11DE01E2796185B845744755AB0EA1,
	AkDeviceSettings_set_uMaxCachePinnedBytes_m9A64FDC211F5E96756E831F038F6EFE4D7D6128E,
	AkDeviceSettings_get_uMaxCachePinnedBytes_m123C0026E4068EB18ED3AD76563EA2A0FC35BA06,
	AkDiffractionPathInfo__ctor_m4C6CD3051B3BC5E96BE963A8957489BE51E26B33,
	AkDiffractionPathInfo_getCPtr_m0BE5C4FAC72ACA585BF4E53034845CC8A38561F9,
	AkDiffractionPathInfo_setCPtr_m2186FECFC92D9BBFD91E46F5C561BEDD2308D0F6,
	AkDiffractionPathInfo_Finalize_mECE17D8565D2299191372BAA5FE2BE601FAF6275,
	AkDiffractionPathInfo_Dispose_mA64DD78597168C168460591EFE088233D8093A77,
	AkDiffractionPathInfo_set_emitterPos_m1A7A8521C4CED2DEDE651CF4DFA3F1A142369C00,
	AkDiffractionPathInfo_get_emitterPos_m987B25DEE493870742A4BE16556CB6CD92D69897,
	AkDiffractionPathInfo_set_virtualPos_m142AB8DB5FAB8B6E1CDB03321DDDEB9EFC7D7329,
	AkDiffractionPathInfo_get_virtualPos_mE6A9284D90BBA6C14A3E63239460828CC39B3858,
	AkDiffractionPathInfo_set_nodeCount_m4F71AAE2118CCBCCACF08BA70CE8748EE24BC8F3,
	AkDiffractionPathInfo_get_nodeCount_m589B9B9690E393E5275DF61B4C55C45D7BD5FE78,
	AkDiffractionPathInfo_set_diffraction_m15FC4A7E6B831B7B05BBC106EB56CE2570C4D9F3,
	AkDiffractionPathInfo_get_diffraction_mB9334EB9A3CCD42DD53C2618ACD04414892AB926,
	AkDiffractionPathInfo_set_transmissionLoss_mCE0FEA84541994F315C577A31BC28949C31A8ADD,
	AkDiffractionPathInfo_get_transmissionLoss_m975EB493F92875E89C55D424155B8092FFABAC36,
	AkDiffractionPathInfo_set_totLength_mB3877052580307C030CF7DB5FA585EAA19453916,
	AkDiffractionPathInfo_get_totLength_m26460775F26319D6DAC12418F74A8F211027848D,
	AkDiffractionPathInfo_set_obstructionValue_mA9A60C13BA8D7023FA5183766344881BB10D449D,
	AkDiffractionPathInfo_get_obstructionValue_mDEC6E5D059085B26C0318B57D1F5E8C72DD76C80,
	AkDiffractionPathInfo_GetSizeOf_m7F89871E7BAA1DA2FFC637A399314B1ED8766008,
	AkDiffractionPathInfo_GetNodes_m42A20F9483BAD32A106F8D6B070C8EB4210698B5,
	AkDiffractionPathInfo_GetAngles_m76955570C05C7D02BB7516ECB5495B5B80562C30,
	AkDiffractionPathInfo_GetPortals_m1AA187E65A1CE758FF182169BC61231F0FA69A0F,
	AkDiffractionPathInfo_GetRooms_m7958D7567612F60F2C359C32D7C1165980CC1375,
	AkDiffractionPathInfo_Clone_mBBA3D76D31316F88CDC7407D3F989985F0416F20,
	AkDiffractionPathInfo__ctor_m13389FC12708DF339B781726D9208C42E2497B0E,
	AkDurationCallbackInfo__ctor_m14BD5BB7E5ABAF4156150D1C1132277B9E8B637C,
	AkDurationCallbackInfo_getCPtr_mE4F9C4735B8676AE23DD83DABE56BEBCBA099463,
	AkDurationCallbackInfo_setCPtr_m54AFBDB424B12D5E59EEC56384D55CEE65AEE749,
	AkDurationCallbackInfo_Finalize_mD382BE5D412F99467BA0413954A24DED6C8E3ECC,
	AkDurationCallbackInfo_Dispose_mEAE6AC7200E449771C906A6745BA6E850B0A0C35,
	AkDurationCallbackInfo_get_fDuration_m830E5F299DD0207D31797BAB53A9A4384EABA4F6,
	AkDurationCallbackInfo_get_fEstimatedDuration_m309CD6D65AA0299C965EF62F2A598A8C50E41A3D,
	AkDurationCallbackInfo_get_audioNodeID_m730FA702CD3028C3DC05599E3E94D4CEAC411613,
	AkDurationCallbackInfo_get_mediaID_mD3FEC0B8BA029E31E0A054A55C90ED3D3F8F34FF,
	AkDurationCallbackInfo_get_bStreaming_mF8125E1B99AF6A9023F42C3CE81D2CD339515197,
	AkDurationCallbackInfo__ctor_mBC9EB3501202B6A2951597333F097DF2DD8F3508,
	AkDynamicSequenceItemCallbackInfo__ctor_mE41286ABF799F3CEDC82BE69FBD84E5819C58156,
	AkDynamicSequenceItemCallbackInfo_getCPtr_mBF4BBB5FF93CC31BBAF1C1DE12751E10AD7AA33F,
	AkDynamicSequenceItemCallbackInfo_setCPtr_mB5635DB2C39BDC899E410FA425407EB75CC05688,
	AkDynamicSequenceItemCallbackInfo_Finalize_m721011A56AC5A36B5C89E6B60A8FF20B2C67B580,
	AkDynamicSequenceItemCallbackInfo_Dispose_m3F014506DBCBE024F4E577767A7B0F643D64B217,
	AkDynamicSequenceItemCallbackInfo_get_playingID_mD084DB2FFCE7C702FE2F0FBC988E3B064454F864,
	AkDynamicSequenceItemCallbackInfo_get_audioNodeID_m226854157CA328CF30EA8077DDDE33B9FE483DBE,
	AkDynamicSequenceItemCallbackInfo_get_pCustomInfo_m1AFBBB407058689BF58C9F7E360EEFEC46E826C0,
	AkDynamicSequenceItemCallbackInfo__ctor_m5D956097663677B2CD8F3DE2276021A018C0469B,
	AkEventCallbackInfo__ctor_m808146131B4EA8A6B7123668F6BC683D8C11B7B5,
	AkEventCallbackInfo_getCPtr_mAD468BF2120D9F023A73A42151ACB84E4D77D356,
	AkEventCallbackInfo_setCPtr_m22B20A3E3FA3135DC5B931B9A5EF41907C1EDCAB,
	AkEventCallbackInfo_Finalize_mD75F2F2FF539C6303EB469C6B50AA02991E77ECA,
	AkEventCallbackInfo_Dispose_mBAF74B91C8FBFA5CDBCC58C8C56A84255EC22587,
	AkEventCallbackInfo_get_playingID_mEABED67AEBC8FADD6EF98ED20D046002A8B1B5BB,
	AkEventCallbackInfo_get_eventID_m5CCF607DE8BFFFC37F450D8DE688E3EACCA5A47E,
	AkEventCallbackInfo__ctor_mB13B533A20F689C69DBD97815D05E11E5D18C408,
	AkExtent__ctor_mDC6345EBED671A436837E5B99F80826BAD17B9EF,
	AkExtent_getCPtr_m0A90B9AEC3ABC233D67921F3334B95D32CEEECAA,
	AkExtent_setCPtr_mE4DC624B37B455044C34184D6553C15DD8D0A0DB,
	AkExtent_Finalize_mFF0ACE8EEDF1D245CF8FDDFD26E651ED22CB141A,
	AkExtent_Dispose_m6B545D4A8FECCA28C1F040601C850CEE274CAA40,
	AkExtent__ctor_m72BFBAD1053EBF01DFEDD8654FA034327490A1C1,
	AkExtent__ctor_m6A9F34E38CA14D9AA5D5E8BA56D42EDDBD0E12C2,
	AkExtent_set_halfWidth_m16C0A7D9EB6325D940F8617509169A29670AA33C,
	AkExtent_get_halfWidth_m8D5DCD3C9ADB0F43DF0CAACF85835FB4FA64FD6B,
	AkExtent_set_halfHeight_m09AEC70C4AA4D077F862F6D37B8BF8A03D5588DD,
	AkExtent_get_halfHeight_m0DF0780077B74D2E0779DE0E68244B93697719F4,
	AkExtent_set_halfDepth_m1AFC8121D1034D1CA5F9B2B7D147B04CB14216A9,
	AkExtent_get_halfDepth_m9AB82140A8FBFE62454351E1E2ADB53B63236AD3,
	AkExternalSourceInfo__ctor_m99C6AE9E48A6657954037A12CABE4A80D7E321BD,
	AkExternalSourceInfo_getCPtr_m7C64848455C6483B4B1DE5032C2F02C89DD62C59,
	AkExternalSourceInfo_setCPtr_m346013D0361CA376E7B64DDCB5AB735E121FCB95,
	AkExternalSourceInfo_Finalize_m92420EBCAC01A4F77B3CAC8BF90289AD1D732C64,
	AkExternalSourceInfo_Dispose_m1EFB45EE1FC0CA4BB44CF1369BB34F39C4C2C3CD,
	AkExternalSourceInfo__ctor_mA391D63B19134A880C2044168EA004E89FB57DFD,
	AkExternalSourceInfo__ctor_m1A422B384CBBA373C12FBE1AC37E31FC2E5DBEBA,
	AkExternalSourceInfo__ctor_m2BD0C04C5F5FA35625662C013DCE042BEF677C56,
	AkExternalSourceInfo__ctor_m9F307AF3DF0525F70A01E7E7AAFF8041E6215C6F,
	AkExternalSourceInfo_Clear_m35B20D5768EE4698B2ECF402F2BE82559F2E1B05,
	AkExternalSourceInfo_Clone_mEB61F6F030F01668F1379A8B7622A2AF65F3E45A,
	AkExternalSourceInfo_GetSizeOf_mF7DDBAF35FC1895ABBCA2C38B61CEA6DFAB7B03E,
	AkExternalSourceInfo_set_iExternalSrcCookie_mBFC816EFFB92C7C6B92F5F7E269BB57605071D1E,
	AkExternalSourceInfo_get_iExternalSrcCookie_mF352A62C08064D780FBA38E428C2BA3AA7C9F734,
	AkExternalSourceInfo_set_idCodec_m1EF71662DEE575CC207944A2B5B4CAF09CDDC4F7,
	AkExternalSourceInfo_get_idCodec_m79D9995D089873D22F93EFDAA2536B752D61B9E1,
	AkExternalSourceInfo_set_szFile_m64AA98557C0E6A584C653CC4C18141E7F2401148,
	AkExternalSourceInfo_get_szFile_m583964EA5561807C15A3CE233BD65F5D3AF86E30,
	AkExternalSourceInfo_set_pInMemory_mC944A203E96743A4E7972CB0ACD47DFEB1E2FE99,
	AkExternalSourceInfo_get_pInMemory_m7E3F17FF8DA48B621C17B8C9A117C136C97D510F,
	AkExternalSourceInfo_set_uiMemorySize_mF5138D9ED9685CD2B22401E5EEB548DC504BC77C,
	AkExternalSourceInfo_get_uiMemorySize_m5D83C88E106D5F242CA96B545DC446AE798537DF,
	AkExternalSourceInfo_set_idFile_m296F81F8F318D8D77AB5618A0DB610538C699B04,
	AkExternalSourceInfo_get_idFile_m1C17022D73CD2AB0ED9278D842702505EF980B29,
	AkImageSourceParams__ctor_mAC7E00659C2F10FD544F56D8598654EB413BC4F8,
	AkImageSourceParams_getCPtr_m31DB2FCB1B928A49887A600155380DD8EB20E694,
	AkImageSourceParams_setCPtr_m729A3951A997667492B075C6665AB1B354722D4D,
	AkImageSourceParams_Finalize_mB81B30206FF25117FCDB0D1A7C1E7430F8BC5096,
	AkImageSourceParams_Dispose_m98E07E6B1D1640E2D98280074D4EC0B3B3DA2227,
	AkImageSourceParams__ctor_m0D27147FB1C23D1A82809BCECB62D734AE930BC7,
	AkImageSourceParams__ctor_mB6E3165B9838BD8E1D9D33A64A044186A3B9292D,
	AkImageSourceParams_set_sourcePosition_mA1DE8939EA87B5B8A1022C6226444F96D4258F6D,
	AkImageSourceParams_get_sourcePosition_m78A1F71BDDC4DA8F76DDEB30FC1B38AEDE93573B,
	AkImageSourceParams_set_fDistanceScalingFactor_m52527D670D660002549F1343B003E6D28CB02BA8,
	AkImageSourceParams_get_fDistanceScalingFactor_m8E68F9A9250C679C7E4ED2AEE1EC6AF33B51D989,
	AkImageSourceParams_set_fLevel_mDB504008930B6025200C04C94F7C92345C4DF3D4,
	AkImageSourceParams_get_fLevel_m28147BB825CBF5CFC566E8C9BBFCEA23829F7BC4,
	AkImageSourceParams_set_fDiffraction_m36978E477A52FCC2A138219FE75B88EA86153025,
	AkImageSourceParams_get_fDiffraction_mB968697B7BEE50A98C49DF8B1FCF294DB9FFA0E8,
	AkImageSourceParams_set_uDiffractionEmitterSide_mAEDA3BE278F9CE0F4FCED212B6CF5C47FBC2E727,
	AkImageSourceParams_get_uDiffractionEmitterSide_m2FD68E269CA15FD014C48E36C1089149E4CCA90D,
	AkImageSourceParams_set_uDiffractionListenerSide_m25953D6391A1D324D835F7760ED80E6055FB440C,
	AkImageSourceParams_get_uDiffractionListenerSide_m696D9C4CD07263DA3BDF5C3B63F60B85993B50DB,
	AkImageSourceSettings__ctor_m2AC71C56CB383A8E080CE331FFC496C270A494C0,
	AkImageSourceSettings_getCPtr_m5E551016ED5FA827C8E402FCA39ACA86B16980B2,
	AkImageSourceSettings_setCPtr_mCB2E291C53EA3558133798148300E27ABE4EB9A2,
	AkImageSourceSettings_Finalize_mDBF0D5462C82B376B7FF94CE1EBE2D7687486C83,
	AkImageSourceSettings_Dispose_mF4C3DC4417D4004CFF6B8A8719A8A727FBAF1493,
	AkImageSourceSettings__ctor_mEC375D456CA6D1530813D2687E9CA32A8770861C,
	AkImageSourceSettings__ctor_m5700D69929BE633D927957A6A0BBDBCB20245AF9,
	AkImageSourceSettings_SetOneTexture_m30F250846984D18F139C65CBBC8EF2BC5430D84D,
	AkImageSourceSettings_SetName_m6CEF2DC451E6E8569827B9F9119BC1F1085802A4,
	AkImageSourceSettings_set_params__mBE6A65ADA2F7EE58178BA34E47E350C43A4E5982,
	AkImageSourceSettings_get_params__m69C3C51534E3491A89504E2FC3EFAFF59FD3A759,
	AkInitSettings__ctor_mF5C4DAE2359237F2F186517982F884C700D0DC55,
	AkInitSettings_getCPtr_m53AFC738173CDD55A17BDA1D1BEA22995557D019,
	AkInitSettings_setCPtr_m319E79A8812EB66FE647E7A0250F27111D0F2171,
	AkInitSettings_Finalize_mEEEC1DA20BE38D9C01596E9D87BB151EFE5B433C,
	AkInitSettings_Dispose_m92EC70E3E0D3D9D4BD106B2370D0CE36F10ACAD4,
	AkInitSettings_set_uMaxNumPaths_m3F844CB63EE0AD41E375E60DD957544B81F8B9D3,
	AkInitSettings_get_uMaxNumPaths_mF4DF96126F4A2905ADC0924332D54C6E9DFC2BAE,
	AkInitSettings_set_uCommandQueueSize_m04188483C59F8D981A31659C48976E8DD317C09F,
	AkInitSettings_get_uCommandQueueSize_m7E59EA8C6B0D2E69BEDD1FF002722F286296E7A1,
	AkInitSettings_set_bEnableGameSyncPreparation_m42C02C6A00EE6DA7FEA684D5569D47C7F1287BA9,
	AkInitSettings_get_bEnableGameSyncPreparation_m486118B5892DC0714803C11DAFF2F59C2D111D34,
	AkInitSettings_set_uContinuousPlaybackLookAhead_mEBEACFA767377AEA9C43BF807AE451F8B03133E6,
	AkInitSettings_get_uContinuousPlaybackLookAhead_m92A5F3BA6B774795FB1D3A832E04EA301F54FAAD,
	AkInitSettings_set_uNumSamplesPerFrame_mAA0DFF7683F7F0B5E8F9687526ADA3A41D456DF9,
	AkInitSettings_get_uNumSamplesPerFrame_mEA08D318271B688226D0B1182701A7D54E68E8BF,
	AkInitSettings_set_uMonitorQueuePoolSize_m125555EA745D9249379BA72474B2A18A3D76FD53,
	AkInitSettings_get_uMonitorQueuePoolSize_mF6E6B2D806F2DAAC86011E4AEBFD1B0867606673,
	AkInitSettings_set_settingsMainOutput_mE8E47A34A71D053DBD9B19F39B660B0719094D03,
	AkInitSettings_get_settingsMainOutput_m99EF138993D72D548C443AE3EF641DE475402E24,
	AkInitSettings_set_uMaxHardwareTimeoutMs_m7EE90AE016E7F34D44D58ECCE92C57B0A65C9E4A,
	AkInitSettings_get_uMaxHardwareTimeoutMs_m4C8792D48F287CF84C5A7BD72F607D3E84288D27,
	AkInitSettings_set_bUseSoundBankMgrThread_m455A7051CD62D21015EA847927E7B23BF8742E47,
	AkInitSettings_get_bUseSoundBankMgrThread_mFC0F009D095798DC1B0A2AA2C9A11736872EFB19,
	AkInitSettings_set_bUseLEngineThread_mB65810A80D04A66D2A77D097911861E71BFE95D5,
	AkInitSettings_get_bUseLEngineThread_mF2158E53EEE217CBA7AC17796EF1BDAB29C102A2,
	AkInitSettings_set_szPluginDLLPath_mD21B225CDD2DED91D89BF360B546035E04764961,
	AkInitSettings_get_szPluginDLLPath_m055F970F7FDC77F02F60FBB82B35B276531708BC,
	AkInitSettings_set_eFloorPlane_m032D89DB9FADDA587BF158878891ED65DD856600,
	AkInitSettings_get_eFloorPlane_m809EE5A98AB33FADB407C0186EE37B28F705A87A,
	AkInitSettings_set_fGameUnitsToMeters_m3DF273E0BD550DD094B6D61033F88E0A5477AAEF,
	AkInitSettings_get_fGameUnitsToMeters_m7CD648470B24B8626047FA719DA92804A539F8BE,
	AkInitSettings_set_uBankReadBufferSize_mE9F13C77DEC68E55030DD050FB62B246EFCB7AE0,
	AkInitSettings_get_uBankReadBufferSize_mD7FE80B3456DBC4F6D763F6AFCE0E72AAEA72DF4,
	AkInitSettings_set_fDebugOutOfRangeLimit_mB319A4F79922FF5EBCB3702D44FEA5B70A82C189,
	AkInitSettings_get_fDebugOutOfRangeLimit_m71D6CDFCC1EF58698DDFC11CABC925B85B15F640,
	AkInitSettings_set_bDebugOutOfRangeCheckEnabled_mA34D50B76F9B4075C774666BCF8C6036743074A2,
	AkInitSettings_get_bDebugOutOfRangeCheckEnabled_m59C04367C7A769278B006ABF0338F200199B84CD,
	AkInitializationSettings__ctor_m6CBF904B928FA05E661E5252F22A249515A44626,
	AkInitializationSettings_getCPtr_m8E359B71164512FD12A2BA409DD1547A9DF2187D,
	AkInitializationSettings_setCPtr_m754B6CA2EAD60F9095F924DBDA70E0D29D6B267B,
	AkInitializationSettings_Finalize_m96861CCC56AB5912E87F9FB0B4CFD205CF966315,
	AkInitializationSettings_Dispose_m712B70CA2DDE850640D80D8981B5FF8F7722B98C,
	AkInitializationSettings__ctor_m23024BFFFF01FF565B2A24181B76FE93FD5DB9EA,
	AkInitializationSettings_set_streamMgrSettings_m79E9838E943176BFFCED075DBCA9C9C7DB1FD8A9,
	AkInitializationSettings_get_streamMgrSettings_mA7317DAD2BABFD60C3C030AD479D1C62243E4701,
	AkInitializationSettings_set_deviceSettings_m616AF154B9BE98172B802B0E8863DE8AE3BFE44E,
	AkInitializationSettings_get_deviceSettings_m8289907C7DAFE2BBD7B1CECA13CA3AAD09EE9354,
	AkInitializationSettings_set_initSettings_m0FC73305EE9FF79D94638F330968C0F39E74F090,
	AkInitializationSettings_get_initSettings_m08943885603F9E5B98CF6EE8059E089FFB785EA1,
	AkInitializationSettings_set_platformSettings_m3342F25CF4D0594B4338E4C11FE5B5314064DB0C,
	AkInitializationSettings_get_platformSettings_mDE1760C7772A8225DF7DC079D2217E4B57382EC4,
	AkInitializationSettings_set_musicSettings_mF08A196348BCCB65843422C90EF608D060E43E3C,
	AkInitializationSettings_get_musicSettings_mB765326E1A317D9FDBA39641122B9A583B0598EC,
	AkInitializationSettings_set_unityPlatformSpecificSettings_mE73FC5FDBB99C484FF7437FA295066751B1DE6AA,
	AkInitializationSettings_get_unityPlatformSpecificSettings_m46CAF63971A636F9339C42953F197909ECDAE6CF,
	AkInitializationSettings_set_useAsyncOpen_m25ED29D225AE8A6AAA9C8993EBC7E575794D70B0,
	AkInitializationSettings_get_useAsyncOpen_m09D01B3D04CC686BBD15A8590C050ABA33E61A98,
	AkIterator__ctor_m09F365F13CC620C70D7EB509D6662E8A93AD68E3,
	AkIterator_getCPtr_m4CDF29F2EEA84DB02DB73C3EC13CB0BE598DC5FB,
	AkIterator_setCPtr_m1F60CE74DDDD643486DA64EB833215FDE40EE634,
	AkIterator_Finalize_mD7E0B3A966C2D8CD4602C03EC453D877648259EB,
	AkIterator_Dispose_m9B985ECD92BD6CEF253C5130A7113B0E12F52D44,
	AkIterator_set_pItem_m5145D14C6912AA92BA004700AD6902FAB1FBC958,
	AkIterator_get_pItem_mE58CE379A5F57498B369790B95C54993540D767A,
	AkIterator_NextIter_m05FA16C2E69A784A3EBD8408A00E7A811F6E62A8,
	AkIterator_PrevIter_mC818F2094334BC375B1D9792B677B120615291F4,
	AkIterator_GetItem_mCB139AD5A9C0AFA3142D685A5470978380D125A9,
	AkIterator_IsEqualTo_m15E93ED663BED69B8AD08657D541CB9DE2B6F1BD,
	AkIterator_IsDifferentFrom_mFB052FC0CDF663141DAF53B5F19D744E9568C867,
	AkIterator__ctor_mDCC891036B47E29B80A07090A7224CCDC96E07D5,
	AkMIDIEvent__ctor_m2429E9823EDAB4F76CD8F81244551999CE9AF35A,
	AkMIDIEvent_getCPtr_m79E03337A1D43D991EF119DA21864B50EA3C7949,
	AkMIDIEvent_setCPtr_m6A9AA31FB8E0B261B0945BFBC921C0E6CAFB0CFA,
	AkMIDIEvent_Finalize_mEB1863E2CFEA093A9D546BAB0B1C1884CFBFC32B,
	AkMIDIEvent_Dispose_mC843DA875D22F5D5448692134BF61D1F0E28FDD4,
	AkMIDIEvent_set_byChan_m43F2DB46EEE7FF0421F0E586C365A31C65279CD6,
	AkMIDIEvent_get_byChan_m2F838957323FCEA77CFC35A2DFEFD65DAE3A6420,
	AkMIDIEvent_set_Gen_m8CAE193E342862DA4CA130302FF5338484B72226,
	AkMIDIEvent_get_Gen_m00BC2913B7C11F25C536D9F2A9A5FE5FBF937D8F,
	AkMIDIEvent_set_Cc_m3C209D0ABE5C0691CB447DA7DB8E222967F0A696,
	AkMIDIEvent_get_Cc_mA9D09B9F4AABA9D995CD2EDA3383F40C6BDEEED5,
	AkMIDIEvent_set_NoteOnOff_m9E8F67B81B3563CA4DB05FF9F0FB57791E1F28A1,
	AkMIDIEvent_get_NoteOnOff_mB2540E1FADAF3ED6406596F0C0B9CFE41C1A0886,
	AkMIDIEvent_set_PitchBend_mCD8EB0300504836A90F0D4B156162CBC19451AFE,
	AkMIDIEvent_get_PitchBend_m8056A2DB2913108DBA7E50AA25348B6DA94B5758,
	AkMIDIEvent_set_NoteAftertouch_mBBB4C225D9CE203A239835E577513ADA1F0FF343,
	AkMIDIEvent_get_NoteAftertouch_m0091950DF507EECA9651D9EB1B461830818483E1,
	AkMIDIEvent_set_ChanAftertouch_m7BC7ABED2E1727E910107FA91F9510E62C7AAEDB,
	AkMIDIEvent_get_ChanAftertouch_mF8E083DA50EC920D36DA583F85FCE099E9D886BA,
	AkMIDIEvent_set_ProgramChange_mAEF6F34174B4D1F8A559E4EFF5DABDEC3F6EC5B4,
	AkMIDIEvent_get_ProgramChange_m96DE2DAAA6AC931948AE8B371D86282C70AB6FE3,
	AkMIDIEvent_set_WwiseCmd_m195046F7B5221745182C02D87A619CCC341257C9,
	AkMIDIEvent_get_WwiseCmd_m80B88305B1FA65EA2A5F0A9E9A816793785A1EE2,
	AkMIDIEvent_set_byType_m455D47611FEA5D55BED0E3E747B0563833DD6FFD,
	AkMIDIEvent_get_byType_m1396067478A555B1E53EECA978B874D45B50D44C,
	AkMIDIEvent_set_byOnOffNote_mBE7538BE54E0FC59E1760AF3FDD2F3A9AA3CDCA1,
	AkMIDIEvent_get_byOnOffNote_m72AD01919CDC77FE2455FCE1A674A1A7AA206BF4,
	AkMIDIEvent_set_byVelocity_m11EAF9B44053146DC42616576E9FA29E527385E2,
	AkMIDIEvent_get_byVelocity_m3CC88689C6FF01F0D950C05ED2843E005D755CF5,
	AkMIDIEvent_set_byCc_m8D26F94B9937D93F5271C723F4AB932821321869,
	AkMIDIEvent_get_byCc_mC88C7095BF0B1C4DE5490572962CC4B4B4EDA571,
	AkMIDIEvent_set_byCcValue_mA0EF74100FB599FA90BB4D96F2D19A05973078BB,
	AkMIDIEvent_get_byCcValue_m8990541C7B0D1E5FBE67E243C84CAE2C1C69E163,
	AkMIDIEvent_set_byValueLsb_mE6CFC8E3DF52C79A4A84BBA4C9B9F0BB4B812ABC,
	AkMIDIEvent_get_byValueLsb_mF49A363DFC9D69193DEDA13AA730FDC187CF15B9,
	AkMIDIEvent_set_byValueMsb_mBCBF4E647C4B1F3B153CE832AE1130C6731316C5,
	AkMIDIEvent_get_byValueMsb_m606B7398D6CD30F1CCDB60A0741C6F575A7F2BD4,
	AkMIDIEvent_set_byAftertouchNote_m6241BC1EB151880B5F4DDCA9615B0DF325F39765,
	AkMIDIEvent_get_byAftertouchNote_m4931AE5361FC8239AEE849159EAC52D54424571F,
	AkMIDIEvent_set_byNoteAftertouchValue_m4A5CE36B428DB6D190F4C8B7C4596BA4629F16CA,
	AkMIDIEvent_get_byNoteAftertouchValue_m5D9F68A07A5E5B937EC7FE12A5E17B663ED2BC5A,
	AkMIDIEvent_set_byChanAftertouchValue_m5CCCCC25EB62C54CBF1C4BAA7DFAC3FE63D146FE,
	AkMIDIEvent_get_byChanAftertouchValue_mA1E3B5A2E23EBC380A17EB7F33E38DB4784A09BD,
	AkMIDIEvent_set_byProgramNum_m5916207481B15370C578E8304B24B7B09F0D690F,
	AkMIDIEvent_get_byProgramNum_m0FF5EC6B1C42051B779CE09F4672BE5E64252676,
	AkMIDIEvent_set_uCmd_mE75B708FC82C2DC9EB03DC63B50EA4BF89DA6CF9,
	AkMIDIEvent_get_uCmd_mBA82A0C04CDB92FA6A86B2DC5C72D946B24A3C77,
	AkMIDIEvent_set_uArg_m5B48CCB597F7A356B0B3B60496FEB1D4D7B02FC2,
	AkMIDIEvent_get_uArg_m6FBED906331B2746C3A976027164C5A09729EF64,
	AkMIDIEvent__ctor_m04EC9ACFF7FCBB7082C5AFEB5B37A2C321DA5CE7,
	AkMIDIEventCallbackInfo__ctor_mCC77C68428CD41EC578BCDC77EF642B0F76FF94C,
	AkMIDIEventCallbackInfo_getCPtr_m6310CADA62FB4A89E44A280C901A40A9D6CBB922,
	AkMIDIEventCallbackInfo_setCPtr_mF907FBD526D61B847EB2EA55294DFD695C4D2E95,
	AkMIDIEventCallbackInfo_Finalize_mBD75FC910EA8A62E20DEECC91260C98E195150E1,
	AkMIDIEventCallbackInfo_Dispose_m2F30BEF9F39324A9CF25B77E6D1ECAA78C2BF2A3,
	AkMIDIEventCallbackInfo_get_byChan_m5C11DFEDF0141CB07572AC9A84C697A1F0A23AD1,
	AkMIDIEventCallbackInfo_get_byParam1_m8AEAA7FB04A94595FE29F76E5D8531C2147851D8,
	AkMIDIEventCallbackInfo_get_byParam2_mDB2997E6EAA8706AE3A6A8C1955FD11C9AEF817F,
	AkMIDIEventCallbackInfo_get_byType_m78610B32354AE9E9734BA2FF474D7640465B0AD0,
	AkMIDIEventCallbackInfo_get_byOnOffNote_m6A21C94CE77C88682A51F03772413B4D0B3A4119,
	AkMIDIEventCallbackInfo_get_byVelocity_mD84AA2BEF14294CF82A5D2BCEC9D099F9DFA6146,
	AkMIDIEventCallbackInfo_get_byCc_m943F519B45E592F85BD9E7BA4DB79918D76B67EA,
	AkMIDIEventCallbackInfo_get_byCcValue_mD52B03D8A1DF970276B88C52842193F2CFB22034,
	AkMIDIEventCallbackInfo_get_byValueLsb_m54C2CCF80AF726795F69F49530A5E0E57DBB1E8C,
	AkMIDIEventCallbackInfo_get_byValueMsb_m59986163649109BBE828CA479D8DF522928C638A,
	AkMIDIEventCallbackInfo_get_byAftertouchNote_mC3C6D09436A7E4F5687A10510ACA5314F13F0E2F,
	AkMIDIEventCallbackInfo_get_byNoteAftertouchValue_mFE922D416950DFA1FC1270D942D2F9ECD92E7341,
	AkMIDIEventCallbackInfo_get_byChanAftertouchValue_m4BD234B670224839CE5648C303BA3A38F76D40AF,
	AkMIDIEventCallbackInfo_get_byProgramNum_m59C26FA1110B9F221FE4133210E23A2D8EC21C94,
	AkMIDIEventCallbackInfo__ctor_m430E59304554624DC7340300409BAC9E7616BF95,
	AkMIDIPost__ctor_mE3A9F6FB67919965C8C284537F0ECF1866B0D0B1,
	AkMIDIPost_getCPtr_m2645902933827C43AD19AC18029273230595D286,
	AkMIDIPost_setCPtr_mB6438CCC677646C0B3F5A1A9B8C21D3136FE9DD8,
	AkMIDIPost_Finalize_m5FC9B3B503E48520AA69320A0FD46B696CC96850,
	AkMIDIPost_Dispose_mF6B24D3101138082E1B3D27C3FBC32731FF2C7A0,
	AkMIDIPost_set_uOffset_m22912C02D1D34248ED3966C5A2C34716C29A77FF,
	AkMIDIPost_get_uOffset_m66C9CDEDE69F75E96474BABA5FFCF2CDB2C92E73,
	AkMIDIPost_PostOnEvent_m40AE53920D5B3AD771735FDBFEAB6C99873B4A33,
	AkMIDIPost_PostOnEvent_m6256923A53523E64C4F4F0E675D65A69E408A135,
	AkMIDIPost_PostOnEvent_m9CD4BFA71ABB2B194E40710F440CD05B1B2B1AE0,
	AkMIDIPost_PostOnEvent_m87B3A256A87B982FB89FA9470BCC89C04667BE53,
	AkMIDIPost_PostOnEvent_m4A9A779EF90B6F6E5961149A48D1B7564AF85AA6,
	AkMIDIPost_PostOnEvent_mDD58DC19FE7F8FA473B2604636B804F192D0ABB4,
	AkMIDIPost_PostOnEvent_m3A6F37AEF34EB96850D29F1EA5AEEFC3896609A2,
	AkMIDIPost_PostOnEvent_mF1799B409F9E1D286E9619A620A9801F97A10917,
	AkMIDIPost_Clone_m104429B9CF59FDD03A992CCA79A7C4F25768560E,
	AkMIDIPost_GetSizeOf_m41DAD94A9700391F59D5A3A12EA788E154123040,
	AkMIDIPost__ctor_m39846270986B43FE999860B209CE318036785D19,
	AkMarkerCallbackInfo__ctor_m0F8F2E2EAFB53DABADD5E2D21F3B892B19636CA5,
	AkMarkerCallbackInfo_getCPtr_m49A5CE9C641F04B87F3B8DD7791F1C8A44EA539B,
	AkMarkerCallbackInfo_setCPtr_m95C983BEB23B5CB8D628DDB637330FCB66424553,
	AkMarkerCallbackInfo_Finalize_mCE562CD710E2DA6883D3B4C378BB80478EA8601E,
	AkMarkerCallbackInfo_Dispose_m08989A9F3BB273C4319E93AFE2531747A366B649,
	AkMarkerCallbackInfo_get_uIdentifier_m56C8E938D75CBBDCAF2B5C08AB39828A7E592326,
	AkMarkerCallbackInfo_get_uPosition_m267DC25F4E09E13DB200B14CC648B7C1404B178F,
	AkMarkerCallbackInfo_get_strLabel_mA32112C949C692CCD451F5FE75FAD8033D4F35D1,
	AkMarkerCallbackInfo__ctor_m246B1ED9C838FFC4EBC809B96D4CA13135D4857F,
	AkMonitoringCallbackInfo__ctor_m19BF8DFCC52A8763BF0F9641FEBDC5A116856467,
	AkMonitoringCallbackInfo_getCPtr_m00C1336A27A3EBD1B55982ABCFF3DD124AFC2B94,
	AkMonitoringCallbackInfo_setCPtr_m4E33746A607EC6BAE626C771BA62DD8DBF1913DF,
	AkMonitoringCallbackInfo_Finalize_m546AFFED5C7E2FA7517FA0D5EC2016EFB87B149C,
	AkMonitoringCallbackInfo_Dispose_mD5FC9371F15B71E9279A2F4B83DBEE58A66B6242,
	AkMonitoringCallbackInfo_get_errorCode_mAD77F4C49EE1D0F9DE890C92C4EA559DEB2B083D,
	AkMonitoringCallbackInfo_get_errorLevel_mBD5DA1AAEF6C80EB2BDCB136A8BFF4B440CD1B18,
	AkMonitoringCallbackInfo_get_playingID_mD77CAD6F8BE2E5AD8D0EE58E6084F87037B2F2EA,
	AkMonitoringCallbackInfo_get_gameObjID_m8A9DED5C834C76337E75BE2402E149F681E917CF,
	AkMonitoringCallbackInfo_get_message_m086A9F21F6617B387485F4CCBD3C6421BFE9B821,
	AkMonitoringCallbackInfo__ctor_m9CC946E2AE120D373E4C7BFA1D60601421C6953A,
	AkMusicPlaylistCallbackInfo__ctor_m41A867A49422A234F1C595296B898CD09B67889E,
	AkMusicPlaylistCallbackInfo_getCPtr_m118BDECE9D6DB9AC6789B2094444FD65E71E524E,
	AkMusicPlaylistCallbackInfo_setCPtr_m037DB0EE5E234E9609F3628985BA232296053796,
	AkMusicPlaylistCallbackInfo_Finalize_m4A48ED5301D6723D96A70A9ACE914F4DF40736EA,
	AkMusicPlaylistCallbackInfo_Dispose_mA41E91439403748F677DC9BDB8ED6FC2E617A16A,
	AkMusicPlaylistCallbackInfo_get_playlistID_mA51E213B3BC6D9A92AE6AA5F310F86FA99A88C40,
	AkMusicPlaylistCallbackInfo_get_uNumPlaylistItems_m12B3069523C8B43298FC8075F010FE94694B5414,
	AkMusicPlaylistCallbackInfo_get_uPlaylistSelection_mBFDECB4AF0298A4A46FA48FD9F89B28269995540,
	AkMusicPlaylistCallbackInfo_get_uPlaylistItemDone_m70E0A6B129C683EB93059BF1540EA030287F6FA2,
	AkMusicPlaylistCallbackInfo__ctor_mE1C15A8CD248780B78992258EB161273973B9B5C,
	AkMusicSettings__ctor_m8AB5CDF0D9C3C232595E816AA8D65305BB3D3D10,
	AkMusicSettings_getCPtr_mF5CC926DB6082C5874185070E70755C9EA5925FC,
	AkMusicSettings_setCPtr_mB7CA4DB0DBCF66904295B6C0A8515FA06F03A037,
	AkMusicSettings_Finalize_m2A5D941C44485993D5B4EF913A749CFB47916DA3,
	AkMusicSettings_Dispose_m4124740EE43EAEF22FFB2ED7D45C1402290E87B6,
	AkMusicSettings_set_fStreamingLookAheadRatio_mB9ED31CC028609982811B59A9C3117F40D860156,
	AkMusicSettings_get_fStreamingLookAheadRatio_m0D092BD9D256CF3E38DDB2FF8F339F512A376B00,
	AkMusicSyncCallbackInfo__ctor_m1B851650BEB0212ED09EB6925B796034F5BE1174,
	AkMusicSyncCallbackInfo_getCPtr_m024D1192A2BE9B17552349C4ACDA7C22BC0F2696,
	AkMusicSyncCallbackInfo_setCPtr_m1A2D171AF908D436CB2365F6B8FEF3E54DFD8674,
	AkMusicSyncCallbackInfo_Finalize_m20000EAE0E37CDA082F9449D106112095B2378AC,
	AkMusicSyncCallbackInfo_Dispose_mCF45EF969E9765D6063FB4695E4E5D64EAD4DE39,
	AkMusicSyncCallbackInfo_get_playingID_m4C5A261742E57D3B2F58C0517746FEF6988F2588,
	AkMusicSyncCallbackInfo_get_segmentInfo_iCurrentPosition_m13D9593F0BE1C68A6EA2BB3E1CBFDB24A0DF2AF2,
	AkMusicSyncCallbackInfo_get_segmentInfo_iPreEntryDuration_m5FFA9D846AB074BFB18EEA163A7403D9434558FE,
	AkMusicSyncCallbackInfo_get_segmentInfo_iActiveDuration_m8C3EC58D1690B7CFBD1D314617C7D17E81032455,
	AkMusicSyncCallbackInfo_get_segmentInfo_iPostExitDuration_m331522F2AAD349A1F318E09FD1A375317EBBD446,
	AkMusicSyncCallbackInfo_get_segmentInfo_iRemainingLookAheadTime_mAFF0FD306DABC269D2B4FE0AC0B65429657C19B4,
	AkMusicSyncCallbackInfo_get_segmentInfo_fBeatDuration_m124FD91883DDDE9A62562ADE360D657C8A27B8BD,
	AkMusicSyncCallbackInfo_get_segmentInfo_fBarDuration_m7BF27650911F2817E41B8F85A9F6CBFDFC303450,
	AkMusicSyncCallbackInfo_get_segmentInfo_fGridDuration_m0D5255CB0ACE636DD01F2BC47BAF74631147F283,
	AkMusicSyncCallbackInfo_get_segmentInfo_fGridOffset_m1511349A96EF9270B8CE368E98A5F3AF0D85AF91,
	AkMusicSyncCallbackInfo_get_musicSyncType_mB6B873B8587474ED7BEC1623C431041F7EC59420,
	AkMusicSyncCallbackInfo_get_userCueName_mD3F76A73BB1CB12B1B9725EBB0611F56584230DF,
	AkMusicSyncCallbackInfo__ctor_m3E85EA55F4D73603641026965A27F198500EFB66,
	AkObjectInfo__ctor_mCE5EDE94A80E0454FEDF5D5DCBC6E3BC101AB929,
	AkObjectInfo_getCPtr_m0F55EE0D28B9FC78C361D87555AA029AF285D7D1,
	AkObjectInfo_setCPtr_m9038823F52B346165229069D8C6A79A35C6C0361,
	AkObjectInfo_Finalize_m96DD1202453EE5FBC7EE851E6F93BC810AF9A9DF,
	AkObjectInfo_Dispose_m294DD7BBF2DD9320E9A6F5430B0F5DE16870F6DB,
	AkObjectInfo_set_objID_mABAF64988353B9ECFC2043E3378696C4CBF61DDE,
	AkObjectInfo_get_objID_m7BD11D1EF3FED8B205253A49361B0A8559AD2D72,
	AkObjectInfo_set_parentID_m0FA6509B888496FA341A0EAF56FB05C9A218E2AB,
	AkObjectInfo_get_parentID_mB01DDE2B7C325C6A1631F70712512AB137CDF49D,
	AkObjectInfo_set_iDepth_mC2E1FAC3565B6037FD7D8C7D1F5032772E5499C3,
	AkObjectInfo_get_iDepth_mA2F49C28213AB4150D9EA3A421D50D125F77F611,
	AkObjectInfo_Clear_mC16209B1AFE6F6348977BF885B5AD99DCE0BBF19,
	AkObjectInfo_GetSizeOf_mDA596C1F0675A03D10E45FD72ACB28369BB3B8F9,
	AkObjectInfo_Clone_m13735FF3C6582CD4AB65F8BAE227576D14C7191A,
	AkObjectInfo__ctor_m071FAB0D84211977A17F8A52D843E240955D0280,
	AkObstructionOcclusionValues__ctor_mC767E62D54100FCD66B8C05D2CADEE19897466C3,
	AkObstructionOcclusionValues_getCPtr_m309A1D245D8829B2C3A1957EBA94C255223155E7,
	AkObstructionOcclusionValues_setCPtr_mF5E0BBB2E07A02EE030EA17422883D7B6C55FC8B,
	AkObstructionOcclusionValues_Finalize_mAB62C3153A7CD26F49BF75E40ECDF3C21966B1B6,
	AkObstructionOcclusionValues_Dispose_m601972A77CF2E69CFF360A84C9C661D83364E66C,
	AkObstructionOcclusionValues_set_occlusion_m9244588BCC19732AB43F0635B711E84AA428EAF3,
	AkObstructionOcclusionValues_get_occlusion_mE31FB65675EFDA59C99C60135AB089BF6675F026,
	AkObstructionOcclusionValues_set_obstruction_mD19BB96124A194EBFE59226EBE708E4AD5BD3A57,
	AkObstructionOcclusionValues_get_obstruction_m5546ED73392A3ABA8979B7E63A751DF514225309,
	AkObstructionOcclusionValues_Clear_m0A1088476B897FD97285185E248E206D57B357F5,
	AkObstructionOcclusionValues_GetSizeOf_m532BEBB849E87245B96BDA269B2C13886536E138,
	AkObstructionOcclusionValues_Clone_m6A570F4247666CB3DD8542C51ABB144AD2AFFC91,
	AkObstructionOcclusionValues__ctor_m5247D4ECDCCABF62D71DB9EDFBBF1CD8F961923D,
	AkOutputSettings__ctor_m94F6A987DE5CE11AEF2B0554061B615410087EFD,
	AkOutputSettings_getCPtr_m2B9DEC290ACF5E2D3B2F5B1AEFE65B1DC864A550,
	AkOutputSettings_setCPtr_m0DF074DC6D0C948698A3D12FE0364349EFF6892E,
	AkOutputSettings_Finalize_mCF499B454C5651D95BB7F65E5F7AA1450030F7E1,
	AkOutputSettings_Dispose_m4E98E5DE73BAB7BD2A8D9B6C1518E5481D74DAC4,
	AkOutputSettings__ctor_m0D702C118AD9BE970AA0853F5A6401E44DE41E48,
	AkOutputSettings__ctor_mB4F504389D225B58799FF6CBCC0A9B5EC947B2C4,
	AkOutputSettings__ctor_m09FC0A94AFD4343C9499B6A816A5705331BE646B,
	AkOutputSettings__ctor_m12ADFA61446E19203DD6037A1DF1652705C01F10,
	AkOutputSettings__ctor_mACDBF336CC49A3A367ACEF0EF74570FAFFB2079F,
	AkOutputSettings_set_audioDeviceShareset_m8C7B491066383092A581A542DA892517F507CF97,
	AkOutputSettings_get_audioDeviceShareset_m8F21357A81AF417450CFF62725050160E9A9B16D,
	AkOutputSettings_set_idDevice_mCE6412A4C4409E2A6D836F7DEBED0539E4F9CA9B,
	AkOutputSettings_get_idDevice_m209D285C0E9662472BD572BB7FE72FB45B473859,
	AkOutputSettings_set_ePanningRule_m0E99676034DD44CD04A8D2C8DC736C2280D3284C,
	AkOutputSettings_get_ePanningRule_mF0C091B7FEC05A69B95CB0E9019D78DFE8744924,
	AkOutputSettings_set_channelConfig_m5F784D9F7FD062F29CDFB0F0A4801A6FD58A6B5C,
	AkOutputSettings_get_channelConfig_m9502A0BEEA8558D9BCEBF5163758820BB399A741,
	AkPlaylist__ctor_mD0226CA32624E1BDA01AAF209C57A313A3D5AEE3,
	AkPlaylist_getCPtr_mFD08226E6D45C0E2D06B0762F727E1E169830D11,
	AkPlaylist_setCPtr_m468C888D576A54D6D388CEE1537406DB6DA06F43,
	AkPlaylist_Finalize_m52CCF78FFC75817CB469752BCD223814A003D53B,
	AkPlaylist_Dispose_mB26BFCBEDCD7A8CD34DBCECE09CF799BDB748577,
	AkPlaylist_Enqueue_m5CA62DE89A0C4BE46336E2306AA21EB72073CBAC,
	AkPlaylist_Enqueue_mBADFF3B679BA5AFEF8F766AE3E711B926C65A90B,
	AkPlaylist_Enqueue_m842C0B4DAF6F23FB835E7F3D530E646D4711F85F,
	AkPlaylist_Enqueue_m1535BA40E5D3553EBF3C9D1012CC210281EB7E3B,
	AkPlaylist_Enqueue_m00E5007C9F1FE774CAE9B86B8AC37203FB3F5C8B,
	AkPlaylist__ctor_m44251DFDC4ECE6C169D92C7ABF1FC1313A14D461,
	AkPlaylistArray__ctor_m0759B47BA9F1DC28C556960145A5BC3814FCA23A,
	AkPlaylistArray_getCPtr_mE6AF99C52066C23D9AB287201B2C318B74B60203,
	AkPlaylistArray_setCPtr_mC433C2F9AF53681A16573B0CBE32C773B881CCC3,
	AkPlaylistArray_Finalize_mF9083996CC7E8A8D2CBD1D50E1EFCC8F132F97C8,
	AkPlaylistArray_Dispose_m7C2D39317A378BE45E6C73382EA03E6D152FB3E0,
	AkPlaylistArray__ctor_mD02FE2DDB4E7A7D90878BDE3CA67497800428A6D,
	AkPlaylistArray_Begin_mC017D6D4CE157B3701625F2D9AE159C84A5BC773,
	AkPlaylistArray_End_mC72C28BE7561FA603475752BA5F2BE92F058BDDC,
	AkPlaylistArray_FindEx_m1F057428E445EEA23EF98C5226C78B5F1C524EA8,
	AkPlaylistArray_Erase_mDC84B985BE79EF8517507ECA1EB159950111B053,
	AkPlaylistArray_Erase_m3B4B063C2C3A6F1B64E481A8F8CA22345674BAB2,
	AkPlaylistArray_EraseSwap_m16F2770A9AECC5080A932404DE1B8D0A9D7899E9,
	AkPlaylistArray_EraseSwap_m68115D1272722DF0994B9B6079C0D6DF0C202D31,
	AkPlaylistArray_IsGrowingAllowed_mC52F132449AC4A31BDB7C3DD0C78A2912441A009,
	AkPlaylistArray_Reserve_mC318B4E3EEEB365BBFBE4E65E9C25FF2E6AAD90A,
	AkPlaylistArray_Reserved_mDC5B468B7F4013AD1371237BDFD61585B3F88085,
	AkPlaylistArray_Term_m2886D469B824B71ACC23F52DB8E021EE4CFEC679,
	AkPlaylistArray_Length_mBAF1739BE5919147FBEF092D5DD199CF6B4E1B25,
	AkPlaylistArray_Data_mE986D51527A505E0236943AF8FB46D3853F741AC,
	AkPlaylistArray_IsEmpty_m16D4C7E401C6B66CEA24889BA5A9331788AB0B88,
	AkPlaylistArray_Exists_mE63DAD1C6D51E3D8CCC16B0C1D8812E823E55E03,
	AkPlaylistArray_AddLast_mE0B04A5CE47C9B98466F85D0B57F83E5DD14F3CD,
	AkPlaylistArray_AddLast_m98F01E8835F1A9FB78B912C4BEAC0BA9E477ACCA,
	AkPlaylistArray_Last_m13DED1C1650BEF557BE703B9A713801B71827170,
	AkPlaylistArray_RemoveLast_m7470823E8C2CC0C027E742F477CE7BF049F70652,
	AkPlaylistArray_Remove_m3E419A3D0B95F910AA3D3D340FA38F93669DFE76,
	AkPlaylistArray_RemoveSwap_mEEB9982115602E0A54FECE3467ADE598123A8D11,
	AkPlaylistArray_RemoveAll_mC7E4F5FF99AF9A22D7B19762C5C6096D38556BC2,
	AkPlaylistArray_ItemAtIndex_m38699BD0B9E9D88EB3FDDCADFFB336E172261D3B,
	AkPlaylistArray_Insert_m5ECDEA3BD4F1F55085CA54F3EA1AF54887DCA37A,
	AkPlaylistArray_GrowArray_mBE360F4DB483F06A2A4F669EB512783E7F2C5915,
	AkPlaylistArray_GrowArray_m02214440EDB48B46940AA75B94C24D523500E928,
	AkPlaylistArray_Resize_m6502AD1A6141ADF2DE5243F864514BB37E67C78C,
	AkPlaylistArray_Transfer_m9345AE40160BCA596B01FB3178E7DDA63DDA6F34,
	AkPlaylistArray_Copy_mA1A0443FB71521F9BED511F243B740624155A749,
	AkPlaylistItem__ctor_m6CF9FCED0497CEEBB134D3D3FB68392C6AB0A883,
	AkPlaylistItem_getCPtr_m904B0CF53B67DF7F5E8641E328720A3C6DF61C26,
	AkPlaylistItem_setCPtr_mBEEDED36050ADFD2AAD3C8C6732831DC9385CDDD,
	AkPlaylistItem_Finalize_mB34CFFD4F7D8D15E72E2D0AF796DDC8E1CDBD6E6,
	AkPlaylistItem_Dispose_mB76B1832E5506A9A2C2517615E7DF16059611796,
	AkPlaylistItem__ctor_m520817A16B0A8200E712FD7B827EE3C9A74B68D2,
	AkPlaylistItem__ctor_mAE148F5012C40BBAE7BA3507FBDA80A1D93E3877,
	AkPlaylistItem_Assign_mA72EFB621DFEBD7783E2B717D674E03D01B79461,
	AkPlaylistItem_IsEqualTo_m57A86E834867AA88FDF4BAFA23DF9CDCF20FE29E,
	AkPlaylistItem_SetExternalSources_mEE05FB8D15A845A419A36B260D05B715134DECC2,
	AkPlaylistItem_set_audioNodeID_m55232347C8E19FA68FC877F4BD3096DBB7B5BD5D,
	AkPlaylistItem_get_audioNodeID_m5C684B722F699D8AA364A0DF5F9F16ABE83A7CA4,
	AkPlaylistItem_set_msDelay_mF7837BF8B97166AED4B4EAF2159FED9C905C2A7D,
	AkPlaylistItem_get_msDelay_m08790522F1A441E79A6690C3CE341C8E2FAB3641,
	AkPlaylistItem_set_pCustomInfo_mF10EE391BB63A7DA64DC63921A7BD7A745EAEA51,
	AkPlaylistItem_get_pCustomInfo_m347988D07006E24B74B46895D08AF6C0CDA7677F,
	AkPositioningData__ctor_m382B6977A4AB2F521971947B0ADBB8F3F84569BE,
	AkPositioningData_getCPtr_mE4866F7A10976A8369B9ACF57E53A54AF1D60D4E,
	AkPositioningData_setCPtr_m3CDDB1B7790E1A8ADC555804F056B74FEB07D13B,
	AkPositioningData_Finalize_mD190DB60FD9C8E86C06ECCC4D35E9FEFBE716A1A,
	AkPositioningData_Dispose_mD2658D2EF052AD50052C2F2126953E94117176B7,
	AkPositioningData_set_threeD_m639B0E1887E8A184723A79ADCB66DCD8563B49DC,
	AkPositioningData_get_threeD_m8B9BE39B5090C816B789B21ABDDDF660148D96A7,
	AkPositioningData_set_behavioral_m51C86D86D5B79B454A657AAA1A7B3BB8D3029E70,
	AkPositioningData_get_behavioral_m9DC77E9C3B463495A73CD7CD664ED48C964854D8,
	AkPositioningData__ctor_m2837A5A084DC0EC47E74D67C4FCCB2FD6A18E480,
	AkPositioningInfo__ctor_mF3A55D4ADA8A105617DBB1CA809615418C34997C,
	AkPositioningInfo_getCPtr_m1EB4A693753BDCB822FC6F6E72F2DEEC3456D493,
	AkPositioningInfo_setCPtr_m048EB48569F6AF27D75C3C530F0F5D6175269524,
	AkPositioningInfo_Finalize_m55292DB38C5A2A09F54B2D4D5A68902A3F5EF1F2,
	AkPositioningInfo_Dispose_m3AF4968F9880DC63CA60721EE32C7D183D23DE49,
	AkPositioningInfo_set_fCenterPct_mE811EA2BD163789A5997CC873E3643238B2E2DB2,
	AkPositioningInfo_get_fCenterPct_mEC61D36692E858F660258ADC3267B48B9FF1EB2D,
	AkPositioningInfo_set_pannerType_m7C00914F1D0CD93A177043456114B6710EA98106,
	AkPositioningInfo_get_pannerType_mD4A1B7FA9A4857C50AC72C7512ED628DF9CA232A,
	AkPositioningInfo_set_e3dPositioningType_m6CB19208E55074619A778790B1F60C1CAB04F583,
	AkPositioningInfo_get_e3dPositioningType_m996668167C41E7B49AA5B0BBD3839E8371B9B594,
	AkPositioningInfo_set_bHoldEmitterPosAndOrient_m1A9FF1E178D96711621FDFD9D477D6FEC98ED5BB,
	AkPositioningInfo_get_bHoldEmitterPosAndOrient_m56358BE54306E5C7EA2AF06791F1CB251C862F38,
	AkPositioningInfo_set_e3DSpatializationMode_m41370F6B0AB6E53A0E64C322EC868D414EA1B7AE,
	AkPositioningInfo_get_e3DSpatializationMode_mFC7EC296E74D68D6606DCD7CEEF7D40F16FFD5FD,
	AkPositioningInfo_set_bEnableAttenuation_m337F0341DD66BD43C2FC728ADBB522B9B8AAE0FB,
	AkPositioningInfo_get_bEnableAttenuation_m9B739DECB33AB05849F9FC238184B00E8F50292A,
	AkPositioningInfo_set_bUseConeAttenuation_mBE6C1050A468F3715B03A86E4473739D3B0AE0C1,
	AkPositioningInfo_get_bUseConeAttenuation_mBB43BD30D50CDD62D58E023E940D2087B71A1D56,
	AkPositioningInfo_set_fInnerAngle_mF039B0960158C135BFEDC47888641445E6A385DB,
	AkPositioningInfo_get_fInnerAngle_mC919D775F6AB2B98EA408AFC3D4A2DE81CCAEF88,
	AkPositioningInfo_set_fOuterAngle_m8F1E3F2BFCEFEC4FC4EBAF22F1DEB607745DFAF5,
	AkPositioningInfo_get_fOuterAngle_m72F086E3CD15C8CD436549F32E6BDEA5814F4A63,
	AkPositioningInfo_set_fConeMaxAttenuation_m1547C2C4A9D810F45776987FC647E30DA3CA0473,
	AkPositioningInfo_get_fConeMaxAttenuation_mDDCC51FE497991B280F6D00986C3EAAC90A5CA9F,
	AkPositioningInfo_set_LPFCone_m9145499B694484B98727E345312D151FF8AD4F83,
	AkPositioningInfo_get_LPFCone_mE67629EDD9CD73BD87A7E3BAF18562403AF17768,
	AkPositioningInfo_set_HPFCone_m6EDC1BEA46FAD67F75EF1F46ECC8F06E490117F2,
	AkPositioningInfo_get_HPFCone_m6ED5362AB0A28315CDF5667C0B217A1D108BE05B,
	AkPositioningInfo_set_fMaxDistance_m66084F52AAC77C532AC943A08F76F19BAE9E04E7,
	AkPositioningInfo_get_fMaxDistance_mF70257193D64B4BA82C3A19DCAB1B8A17E150CF9,
	AkPositioningInfo_set_fVolDryAtMaxDist_m0FF1AA3FE96162A182993AB8E0410F8047F77B3A,
	AkPositioningInfo_get_fVolDryAtMaxDist_m466124554A0E5BB0B1A7DA0636B554A31E230E15,
	AkPositioningInfo_set_fVolAuxGameDefAtMaxDist_m1024FE6B0AFC95A1BF586681831920BD8B057093,
	AkPositioningInfo_get_fVolAuxGameDefAtMaxDist_m9B07A6B4BECFE02387B71147646D70A25697AB49,
	AkPositioningInfo_set_fVolAuxUserDefAtMaxDist_mF3C168EDAAC19CA0EBA144182204E6CF250A5AA7,
	AkPositioningInfo_get_fVolAuxUserDefAtMaxDist_m1747E0AF3565FED83D12FD20A2C66184ADE72A46,
	AkPositioningInfo_set_LPFValueAtMaxDist_m54C7ED72EA4B5DD2A47D19DBF11C5B9276FF96AE,
	AkPositioningInfo_get_LPFValueAtMaxDist_m91C746F27380AB3ECC7D666CF305B1E565B2E71C,
	AkPositioningInfo_set_HPFValueAtMaxDist_mC1F9DB8536E83848AC65E4DB7C0872EDFD934868,
	AkPositioningInfo_get_HPFValueAtMaxDist_m14A222BDAE644FB47496530CA4F86EFFAC50ADBD,
	AkPositioningInfo__ctor_m7F9E18056344E7F1C4EE9FDE70F4526A7D63201A,
	AkRamp__ctor_m3FF2A1707945C9CF161967A81B264BC106CA3306,
	AkRamp_getCPtr_m45D872273A71AF96E4E137ECEDE28029C61A3091,
	AkRamp_setCPtr_m09A8E5D5B1EEE12132D84ED348AD028A017A1A20,
	AkRamp_Finalize_mFF2392CE0CDDD356BFE1A65CFDE57E6B12FD8A9E,
	AkRamp_Dispose_m131628278CD90939C2F6EB517C3F367355ACD14B,
	AkRamp__ctor_m529EEA4D3047E0D23CB26B929C178BB467A69992,
	AkRamp__ctor_m93AE55AF12DD86EAB21D1CAAD72DCBBEDC26FD29,
	AkRamp_set_fPrev_mA063AF173D60EDB4E1187222D216E9E1590B8B14,
	AkRamp_get_fPrev_mA0BC780B34A607DBCCE9674F9E299A5FE0D72861,
	AkRamp_set_fNext_mE9CAE211BBE45F7DB7020626B0844DBBF9814296,
	AkRamp_get_fNext_mB1D661A74AF3E9A27908E4C3561AC15464E2702B,
	AkReflectionPathInfo__ctor_mB63E1CD8087321E1EEDD009BD7A38A269D3195CF,
	AkReflectionPathInfo_getCPtr_mE7084FE3F7A89D86F02B0D6785C14E2407FE4291,
	AkReflectionPathInfo_setCPtr_mE721C90C49017A25166A4EDFFCFF34127161D113,
	AkReflectionPathInfo_Finalize_m6288011C7F78C5E03602F9045F84A571F63F4E78,
	AkReflectionPathInfo_Dispose_m7980991119F17D490F5B845AD84237D4E8C8D3DB,
	AkReflectionPathInfo_set_imageSource_m86BE4AA0CF4AC33FA37BC7F26958CF835630C9AF,
	AkReflectionPathInfo_get_imageSource_mEEB87AB5D687F8DD471A45D03C6C6D6878438BEE,
	AkReflectionPathInfo_set_numPathPoints_mD0C020863361E84A7C3846B04D5F8D238C806F95,
	AkReflectionPathInfo_get_numPathPoints_m7BCF03836D78ADF11A54433DB1140A37FE036C2F,
	AkReflectionPathInfo_set_numReflections_m2A9C03A50E4B5D8611BF8060BC0993C191DDFA92,
	AkReflectionPathInfo_get_numReflections_m31FE6771406B958FC297EB58AF552DC74D8ED3AA,
	AkReflectionPathInfo_set_level_m70327C7D790C8D1743FD33C6855F3C94870F292B,
	AkReflectionPathInfo_get_level_m6FAF7CBE5A6F4472993B723A232C8542F07F4976,
	AkReflectionPathInfo_set_isOccluded_mFEFF39D99FB67FD9FD39926A77D87C23D6CA399F,
	AkReflectionPathInfo_get_isOccluded_mF0D3952B217679DDE564A638FEBB29B689A59325,
	AkReflectionPathInfo_GetSizeOf_m0EEB68CD65D01C974CADEA47E6C06F2EBC3BF035,
	AkReflectionPathInfo_GetPathPoint_m543DB40337D1C5F297989752AB77A4DFDA07FBC8,
	AkReflectionPathInfo_GetAcousticSurface_m7B39C3C1098C53AD74AAF6F3E1DA6A031EBB0B69,
	AkReflectionPathInfo_GetDiffraction_m9CB7BEF28D21A24E8801C6DE876CC615F927D78F,
	AkReflectionPathInfo_Clone_m8A5619C3DF7B83296A7F2096DCF35A6900880386,
	AkReflectionPathInfo__ctor_m86B4488E6C855F22BF780BBEA80013C147028942,
	AkResourceMonitorDataSummary__ctor_m59EF9A275C7F27E43B4C314F7AC54EC9E873170E,
	AkResourceMonitorDataSummary_getCPtr_mE67D22BF7E72477CE32A7C403ED10EFA3CA95D00,
	AkResourceMonitorDataSummary_setCPtr_m60E5CD3151B065E28F7A647AF7A54C2A1167B15E,
	AkResourceMonitorDataSummary_Finalize_m28404386949BCB64FD9D994FA9B25F96CAC85EAD,
	AkResourceMonitorDataSummary_Dispose_mA5050EEF0926DD9B64F06C4A88719AAD15D7AF6C,
	AkResourceMonitorDataSummary_set_totalCPU_mCB785F0DAF2051C04B42BEC3FD7C3EECE5ADD2C2,
	AkResourceMonitorDataSummary_get_totalCPU_mF6E7F5AF81791965C990EEDE57D809E100614AD4,
	AkResourceMonitorDataSummary_set_pluginCPU_m32E0059DA823F968C581F67B12CC334ED33CF197,
	AkResourceMonitorDataSummary_get_pluginCPU_m7269A904417C69C43C3B1B162861E3DD738EBD2A,
	AkResourceMonitorDataSummary_set_physicalVoices_m2103FFC630F0BADA96A25AF4D3ED4B5BD1F00A76,
	AkResourceMonitorDataSummary_get_physicalVoices_mC2A2673C6F0E20FC2141371EC7B9871F974566BD,
	AkResourceMonitorDataSummary_set_virtualVoices_m2B9CD4B1A3A265A8E54AC755CEF645357CC09EF8,
	AkResourceMonitorDataSummary_get_virtualVoices_m0B063561D17DEE255245776257FE6E2C2A06E9E7,
	AkResourceMonitorDataSummary_set_totalVoices_mAF8BB437389A387B92690ABB30422A550EF458B6,
	AkResourceMonitorDataSummary_get_totalVoices_mE2C265533F8014266CCCB2CA7C4B94B23E434DD5,
	AkResourceMonitorDataSummary_set_nbActiveEvents_mEC3EABE86ABC537F8DE86A3077C183FB6B9E4A39,
	AkResourceMonitorDataSummary_get_nbActiveEvents_m4BA1961670AA7EDED320CB53600A2A8D771DE9D3,
	AkResourceMonitorDataSummary__ctor_m26D38808869AC1C63CC53FC50F282A9D92C14BF9,
	AkRoomParams__ctor_mC9E905DC3408059A38A6C3206352DDABE3E3981E,
	AkRoomParams_getCPtr_mF004C6DD82FF71EF27335950782AB98BEC766EA2,
	AkRoomParams_setCPtr_m526AC81A7DEA16E3FFEC7BCCFD987C1533B2B860,
	AkRoomParams_Finalize_m4BDEF557A43A4E3CB4525C0ECB9C7D14E0AC633D,
	AkRoomParams_Dispose_m504E98E1510BACA2206C989BBFD1B519208F39C5,
	AkRoomParams__ctor_m0AB869F8BCE06C89FE7D196E66CC5EEF3ED447FF,
	AkRoomParams__ctor_mCC754257A489C158FE7081DDDDAE11FBD834B904,
	AkRoomParams_set_Front_mF4DAFD1DB1828488BED1580442F5F72B94783F6C,
	AkRoomParams_get_Front_m0C8B5D4C659736AC282F150E6CA0F37B3C98C2F2,
	AkRoomParams_set_Up_mB4D6713A70AC1505B7435A1AD7D82A19337FA1EB,
	AkRoomParams_get_Up_m66B7F4BC389D8A7BE41AD635CD282C8D81B26E50,
	AkRoomParams_set_ReverbAuxBus_m835F821EE215A0A88F999984662A85ADB29523CA,
	AkRoomParams_get_ReverbAuxBus_mE78876F1138AE708E33F3B0B11B774DD9B01111B,
	AkRoomParams_set_ReverbLevel_m0A47F69EBC118F91886225FF0CA2A361F1392F85,
	AkRoomParams_get_ReverbLevel_m9F3270F5747D73E91DE9818ED54E9E580F33AF00,
	AkRoomParams_set_TransmissionLoss_mD472C1E730113CC08D7B5E5A23A1AD1103D4E1AC,
	AkRoomParams_get_TransmissionLoss_mEFDF49C6C063624C418A680D237FC3E6A21A4DD8,
	AkRoomParams_set_RoomGameObj_AuxSendLevelToSelf_m17626967746433B76783C1F7EB92B43856783F91,
	AkRoomParams_get_RoomGameObj_AuxSendLevelToSelf_mCB8B89F24892E7AC3E6C6595263E80F8C3C03327,
	AkRoomParams_set_RoomGameObj_KeepRegistered_m3FE97F6C172836DAED9614075AF0E6C755B2C262,
	AkRoomParams_get_RoomGameObj_KeepRegistered_mE34FFA7D8469054507C6EFF53F99FEC651DCBD01,
	AkSegmentInfo__ctor_m14176C30446456BA50502D4C9489E1F45D138582,
	AkSegmentInfo_getCPtr_m76067467B415A59DEADBD3F721E008F60A8C52C6,
	AkSegmentInfo_setCPtr_m406347FB3A4C872EFE8958A5D7AF834C1CAB9185,
	AkSegmentInfo_Finalize_m18247AC55C678A2D1417AC59F21AA5874E28D399,
	AkSegmentInfo_Dispose_mD54D958C43372E3297F170408AD4941019477E29,
	AkSegmentInfo_set_iCurrentPosition_m1AD96F327811304B878DB92C262FDA70D9140A9B,
	AkSegmentInfo_get_iCurrentPosition_mA3AACE1F7588701CBB7AFCE743B239E53629D5F5,
	AkSegmentInfo_set_iPreEntryDuration_m9206E9EC219DA9711AB8015AD23106674C01B146,
	AkSegmentInfo_get_iPreEntryDuration_m41041698DDCD6CBFA8AF7144C4EB1328FEE53582,
	AkSegmentInfo_set_iActiveDuration_mEBF354CA1E4EF296E92E35155A7A9589D93E067B,
	AkSegmentInfo_get_iActiveDuration_m8ECC61C145FCCD1B8BA3A84131AC3F6A1A7D0117,
	AkSegmentInfo_set_iPostExitDuration_mA5194506252B06E6611F98E65ED3708C59B06FEF,
	AkSegmentInfo_get_iPostExitDuration_m90B666FBF46F4FCF1B3B137A7E749E7AE833488E,
	AkSegmentInfo_set_iRemainingLookAheadTime_mF416A1D73E9D1801794C9F8F61D99A3FF6CDA1EB,
	AkSegmentInfo_get_iRemainingLookAheadTime_m62773B25FCC66E4611A9475982C2198FEB03D171,
	AkSegmentInfo_set_fBeatDuration_mC39E1C0D78E25FCB35A7FFFCB43E5939AB2CEAF3,
	AkSegmentInfo_get_fBeatDuration_mEAC65283557C7017A2E3355578060686B7BBA28C,
	AkSegmentInfo_set_fBarDuration_mADC0534D7AC7B04B674003062D744BF3561848DC,
	AkSegmentInfo_get_fBarDuration_mA2492856A6B608FAC9C3424AEAB9355EC3E0D6E1,
	AkSegmentInfo_set_fGridDuration_m352C4B2C2B28F865097073806F11DF5DC90F1AA6,
	AkSegmentInfo_get_fGridDuration_m8717610BCBA38EC45BA5ABA9154369F69AE74C03,
	AkSegmentInfo_set_fGridOffset_m048A94A531BE001F9C0703958FEF65D91BA81C09,
	AkSegmentInfo_get_fGridOffset_m5FBCCB4DB6EF7A5745495DFBFFC3017E826D648F,
	AkSegmentInfo__ctor_mD9754B7276B47CFD653135FF5BB04965DBB39C25,
	AkSerializedCallbackHeader__ctor_mD7FE279F1CACFCF2A392265FC4696FB478BBCA3B,
	AkSerializedCallbackHeader_getCPtr_m90BF79CE557EC41B8D49E56F91D33A76464FCD23,
	AkSerializedCallbackHeader_setCPtr_mA175B98EA0310FDF14DA4551C102DFF12BA56460,
	AkSerializedCallbackHeader_Finalize_m73F5C3C40F45F7B8B5BAC8AE161C87E0458492D5,
	AkSerializedCallbackHeader_Dispose_m6A2D4FC58227C613DEB75002960C580D9399AB07,
	AkSerializedCallbackHeader_get_pPackage_mCA96D390EB82EBD90292AAF399372CBC0D60C56C,
	AkSerializedCallbackHeader_get_eType_mD1A2E0317F0EE234BA00CC6EDEE479BF5C645BD9,
	AkSerializedCallbackHeader_GetData_mB542BCFFDA4DED93ACE5F98DE4AAD47CE8343CE2,
	AkSerializedCallbackHeader_get_pNext_m27525EB109C28898BCC7FF2564532536302EE71D,
	AkSerializedCallbackHeader__ctor_mB8EC07CB9238A0C5F066F9A54E0D5B0379F6C289,
	AkSourceSettings__ctor_mE4FA70D3678EE6ABA6A11901B56312A0E18EFBD9,
	AkSourceSettings_getCPtr_m7820771D19008FB0896E89C40B1C1F42DE80ED33,
	AkSourceSettings_setCPtr_m6A8D8829B7172AE70D3E1EC0EE5AED3DB80AF390,
	AkSourceSettings_Finalize_m0570A3D56B605C6C9171EDED0A9C8B1A5DA9F829,
	AkSourceSettings_Dispose_mE543B3A4BADBACAFEA0417683470EFC90FB3D01F,
	AkSourceSettings_set_sourceID_m6034C7D15D260D6173D96BFA86E63A46F0BC70EB,
	AkSourceSettings_get_sourceID_m16AEF0745BED9CD0DC99DC527927EDB40BE00390,
	AkSourceSettings_set_pMediaMemory_mAD5E8F1CA97729F5E14A59C9D2B3E61825C6688A,
	AkSourceSettings_get_pMediaMemory_m1FFB5ADFA5D96BDB09C56DBFB75897D0AD47D1BD,
	AkSourceSettings_set_uMediaSize_m2E1411207B7AB0BFADFF2213C48FC6F5CED96727,
	AkSourceSettings_get_uMediaSize_m51C4AF6462CFC74870167E3CE181F319F929271F,
	AkSourceSettings_Clear_mC4DB6124F322EAE9C3818ED9324C2A4BCBF9F705,
	AkSourceSettings_GetSizeOf_mE8DFC3716EBB5DF8ADBB47E4C7D350CC84D83EAC,
	AkSourceSettings_Clone_mE9F4C8978FBCE0F0A54551FF0D7EBB0556141668,
	AkSourceSettings__ctor_m4B8C5E03E2362A6B858D8F2230BC1EE08C29F541,
	AkSpatialAudioInitSettings__ctor_m18F6EB447C4F16A2EA131E1ECEAFE79B0ADF888E,
	AkSpatialAudioInitSettings_getCPtr_mC1DF9735A18AB5BD49E160CDDF7FB02562D8555C,
	AkSpatialAudioInitSettings_setCPtr_m9716AE3A8D8315920CEB69C60C0DCD214A552CCB,
	AkSpatialAudioInitSettings_Finalize_mD88BA1747521B9475971D2FF0F15753631F8EF34,
	AkSpatialAudioInitSettings_Dispose_m84D6AE8540D6FB2F7AA050C9775A5C5AD3AB65BE,
	AkSpatialAudioInitSettings__ctor_m763FBE831EF3E096164B6FF5D278125275656581,
	AkSpatialAudioInitSettings_set_uMaxSoundPropagationDepth_m2654ADEE6AC3B5654D06DCA68E85073E59AE6042,
	AkSpatialAudioInitSettings_get_uMaxSoundPropagationDepth_mB4096F4C67DE96C14477E7D4FF76C629F2B5BFC8,
	AkSpatialAudioInitSettings_set_fMovementThreshold_m3EBB1F9403311A4D16A8C06E7A2D162018A3A053,
	AkSpatialAudioInitSettings_get_fMovementThreshold_m8E40B556637EFD1CA01A148D16B2C44946C81749,
	AkSpatialAudioInitSettings_set_uNumberOfPrimaryRays_m5EF782B01F32CF2AD3A9E4F7226ACB5E1A331659,
	AkSpatialAudioInitSettings_get_uNumberOfPrimaryRays_m242FC4132778C6B7AD7955570BE57BB79D8D7B93,
	AkSpatialAudioInitSettings_set_uMaxReflectionOrder_m460964F899BB75932EFF4B1BEA3152F4F38C0AB0,
	AkSpatialAudioInitSettings_get_uMaxReflectionOrder_mFEF00D3580AC09C5857AB62B6C80328882610359,
	AkSpatialAudioInitSettings_set_fMaxPathLength_m70CE3F0FD470499DC90C90860CC748038912A85B,
	AkSpatialAudioInitSettings_get_fMaxPathLength_m2F4EB5A69D920CB1C9BA8802C0F465A45B379440,
	AkSpatialAudioInitSettings_set_fCPULimitPercentage_mDC38650EDE9AF110E0C7DF2F3D8FB3B7B37166FA,
	AkSpatialAudioInitSettings_get_fCPULimitPercentage_mAE87BBB598B79A6E92458960BEB1A37AD8FC51FA,
	AkSpatialAudioInitSettings_set_bEnableDiffractionOnReflection_m36A51F7B96AB456AD9C9D26BD25E4FE838B6D04F,
	AkSpatialAudioInitSettings_get_bEnableDiffractionOnReflection_mC0A3A68A903748FFEF4A5DEBE43460082C134B7F,
	AkSpatialAudioInitSettings_set_bEnableGeometricDiffractionAndTransmission_mFC8C52117F0CF07FFD7991203B20113D5F08F4CE,
	AkSpatialAudioInitSettings_get_bEnableGeometricDiffractionAndTransmission_m84D303E3D30012A1B20975611DDCD30E6E844702,
	AkSpatialAudioInitSettings_set_bCalcEmitterVirtualPosition_m16AE0286CD7984E9E3BF72C8B5795079D57010BE,
	AkSpatialAudioInitSettings_get_bCalcEmitterVirtualPosition_mEA7CF69CA3E11A284948542875FE40B3E3D8F108,
	AkSpatialAudioInitSettings_set_bUseObstruction_m28D90F5776B7115B948DA189A5414F3C8A64B2D9,
	AkSpatialAudioInitSettings_get_bUseObstruction_m7C3D5FA2D2E2862483B400F91489A1E9CFD3DF0D,
	AkSpatialAudioInitSettings_set_bUseOcclusion_m8ED71297470A804C1A1EBFF30850E4738A41CBD4,
	AkSpatialAudioInitSettings_get_bUseOcclusion_mBE2FF9B03C96EFB424FC0AD4FF508EA76218836A,
	AkStreamMgrSettings__ctor_m173FF7010F37289E25679D9FCDB5CABA9536C848,
	AkStreamMgrSettings_getCPtr_m50B56CDA673D153763C6ED773DEC2E8545B25983,
	AkStreamMgrSettings_setCPtr_mA1985F59D2208B3D2104B4456F42F859234E65B7,
	AkStreamMgrSettings_Finalize_m3DD6ADE30E703F8DE77FB1217C4A9DD391A47006,
	AkStreamMgrSettings_Dispose_m0AF10C7CAD9A549D40930A2DDEA168E3746DC4BB,
	AkTaskContext__ctor_mED566DFD9B67437B66D4C4C2D69ABE56EB0208F7,
	AkTaskContext_getCPtr_m3F7ED5FF7166CB48B6484B61D6176F9CE85670CF,
	AkTaskContext_setCPtr_mCD8E0C2FB5BC55D9835BF383C729229E328EC0F1,
	AkTaskContext_Finalize_m5A5A83EC977AA1FD4F1EC6967EEFF27373FABC7F,
	AkTaskContext_Dispose_m55137333F8C81F55243E4A9037A0916238E05A20,
	AkTaskContext_set_uIdxThread_m7971ECCB4154CD267AB5B5F999F7F9629F3A93E3,
	AkTaskContext_get_uIdxThread_mA3C7239C55D55FA7963FA3A93D3A206020E4510A,
	AkTaskContext__ctor_m90E92731BA689854816628A6217B03E76F7B20D2,
	AkTransform__ctor_m27233AF6CC1533254D198344514E5EEB3E6BFCE4,
	AkTransform_getCPtr_m385FC89C5AA97536D591E0E95753E73A85188A2E,
	AkTransform_setCPtr_m63942CED891633FDB35D831E0BDA21EB7F407FF7,
	AkTransform_Finalize_m8DB45BA7BEED066BFAEB15F6C60D4816B5B862D9,
	AkTransform_Dispose_mA5DFDBABC70CA67F09FEA8B8E37E38A9D64235BE,
	AkTransform_Position_m1F2877EAA623FC7692E3AEC9F0963701A77C9D4C,
	AkTransform_OrientationFront_mFB88AE7AB2BC09A3E93EB09012CD48E28ACE9794,
	AkTransform_OrientationTop_m0D17728773797399E740EAFE587FA629B3A1A960,
	AkTransform_Set_m6803CD84FC472C40011053F343EB3350F7C54672,
	AkTransform_Set_m06A4525F60A1C344194F00277A5D1A9DB6A52C51,
	AkTransform_SetPosition_m3E128635391ED0451C819E8635FEF074C94F09F8,
	AkTransform_SetPosition_mF2685AFD98DB121812FAFD64E4A7CBC3FB4EAC08,
	AkTransform_SetOrientation_m199D92FD83E98096DD38BE7E4981044C334FBCF7,
	AkTransform_SetOrientation_mF79CBB2DB768967252307C2E6B0495A248A3D51C,
	AkTransform__ctor_m0EF930A9A7EB2588B4C9B73865DF2D834A0F487B,
	AkTriangle__ctor_m9259B083C327267C67F45C5F2BE7071EB57E0CE9,
	AkTriangle_getCPtr_m06C64F2BAB865720CAD887BE111AA5043CAB81F2,
	AkTriangle_setCPtr_m60B86F0D118D13076FADEFC09A16E9F8DAF46D48,
	AkTriangle_Finalize_m63390660F16A4A8E04169C4581C38B6EC1202E10,
	AkTriangle_Dispose_mC8FC02238DFC050936D77F7E9A91150223907F2D,
	AkTriangle__ctor_m51802CA7A4BF0339A0A14331C9445BAA9941729E,
	AkTriangle__ctor_mC1135590F5032F5F21D518E5AC4A0E07A4F0E369,
	AkTriangle_set_point0_m0A4CAD0515C7410444C80B9A4EF535D4E5AA0749,
	AkTriangle_get_point0_mA893E90EE745ABAD47EF3C09751D20909A51ABEC,
	AkTriangle_set_point1_m189F0E744E2292DBC28C90310E12A81920A23DC2,
	AkTriangle_get_point1_m190A7769CD2A12E8575AD6D30B1C5303C8652717,
	AkTriangle_set_point2_mF689255BE07E51E5688B0C94A4A06D205A246265,
	AkTriangle_get_point2_mCC8E4731AC8ACB47F877244BA2B5AD19BACC7778,
	AkTriangle_set_surface_m25E0847348D849AC7BBEDB70AFC2365C36C70ACA,
	AkTriangle_get_surface_mAFFBDEAD7BEBE00797D9E051787EFA775FB4FC9A,
	AkTriangle_Clear_mE28F1A5D42DD4270DC1477D6125E25D27011416D,
	AkTriangle_GetSizeOf_m7FBD630BDD0ED6F7C8ECA03A74464E860505BFAA,
	AkTriangle_Clone_m7B0A36612F05AA0040C24E2F8790D749E18AED4F,
	AkCommunicationSettings__ctor_mBD6AFF45BBA6726EF5822E09BDEC485B1588A814,
	AkCommunicationSettings_getCPtr_mA681CD6239AB9709C591B271FF7150A2BABDAA63,
	AkCommunicationSettings_setCPtr_mA79684CEDAD3DE80B20B496D7A169714D5F4E3ED,
	AkCommunicationSettings_Finalize_mFDB896CF5CC94113D1F20EE3BCE67F1B3D1B86BD,
	AkCommunicationSettings_Dispose_mCBECCF1E50D33FC514186B0705C39A6DB045A65B,
	AkCommunicationSettings__ctor_mD02B5665A84BECB1FE5FB5F90BAA5C7D8F95217E,
	AkCommunicationSettings_set_uPoolSize_mAF46234F38AA624559E87F9AEB38AC3012883C82,
	AkCommunicationSettings_get_uPoolSize_m74007BFDD73B56E0764697A11112DF1F074348FB,
	AkCommunicationSettings_set_uDiscoveryBroadcastPort_mC5D817108BB4D0C6D9A1D9B5E6C0BACD19AEA11C,
	AkCommunicationSettings_get_uDiscoveryBroadcastPort_mACAC44C9D3BEE6BDCDFF0D82724F58E58E3C0482,
	AkCommunicationSettings_set_uCommandPort_mDA0D61EFAA006B63E75B098470D03D23B2A4DFBF,
	AkCommunicationSettings_get_uCommandPort_mA9393A3C4485A46C61ED71E12686C47211874587,
	AkCommunicationSettings_set_uNotificationPort_m396DD5C8BA47A8DEA43CAF3A0488F7DEA44ACD9B,
	AkCommunicationSettings_get_uNotificationPort_m5736D4E4CD1BC7AD4F57FF622C8E03A1D489F6DA,
	AkCommunicationSettings_set_commSystem_m1C23199126CBB5999337C9DA65D68D04D9CB18F3,
	AkCommunicationSettings_get_commSystem_m1168C7C37779FDD98FD95A9F2791E5F0BEC46FB7,
	AkCommunicationSettings_set_bInitSystemLib_m0AC7B7CC4BCD686FBA61956703EDEA08D6D47DAE,
	AkCommunicationSettings_get_bInitSystemLib_m70896BDB3C5EE15D8BDD1475C1C9AF6650C6E3A4,
	AkCommunicationSettings_set_szAppNetworkName_m3CE19FD889AD3C942C2B062F027080244FAB7205,
	AkCommunicationSettings_get_szAppNetworkName_m7C50585503E7D34EC069D55ED7386A7D390DFBFD,
	AkPlatformInitSettings__ctor_mDCBC09ACE2847E689801BE20BEFFA0A03DCAD876,
	AkPlatformInitSettings_getCPtr_m996BD96C413412D866319E1E8AB6108232BD42F9,
	AkPlatformInitSettings_setCPtr_m3103B37ACDA9B62E3F123E3690EE9D9F343B57C4,
	AkPlatformInitSettings_Finalize_mFF9EDAA7015D43549C4D77D0468A448114CA2CAB,
	AkPlatformInitSettings_Dispose_m4737E3FE5EB22B119DD56C182DFD7B30D1382FA2,
	AkPlatformInitSettings_set_threadLEngine_mCB88D15C5B9131DC41507150591AD3A62F3FD951,
	AkPlatformInitSettings_get_threadLEngine_m854E2A76ACED949F70CD9CCE79186AC9345F48E5,
	AkPlatformInitSettings_set_threadOutputMgr_mC46C839294CC73E9320D5D3ACA8406C875F36DF1,
	AkPlatformInitSettings_get_threadOutputMgr_mFF53F398E954D3527BFFC23813EFBB8F5BED1230,
	AkPlatformInitSettings_set_threadBankManager_m2567C493F9DE436D689E92AB2D9D7B4D7B58125E,
	AkPlatformInitSettings_get_threadBankManager_m86EF3F2A42AFF85FF7CB545BD0230CB2E9ACD2BC,
	AkPlatformInitSettings_set_threadMonitor_m078A8C62A7474E076FD21F7FEF7C544C55033099,
	AkPlatformInitSettings_get_threadMonitor_m6C430A78A064506787FA9D519CC5228945D003BA,
	AkPlatformInitSettings_set_uNumRefillsInVoice_m9ED1B6CB89781B9D2C95EB6AB82F4FAA7FBFB012,
	AkPlatformInitSettings_get_uNumRefillsInVoice_m521FD708D60427A0F13970C3E58DCC4F0B0FDED4,
	AkPlatformInitSettings_set_uSampleRate_mFBB91E39D3567FC3CBA2E9F7FBA86A6866883D87,
	AkPlatformInitSettings_get_uSampleRate_mA503DD8264AF7B55213B25D39A62D5CBED429CCA,
	AkPlatformInitSettings_set_bEnableAvxSupport_m7E688B4F43AD6321B1F8A0B013FDAD464E50157A,
	AkPlatformInitSettings_get_bEnableAvxSupport_mD9C15CB78E073A9B3881D07935893E2EB7173F75,
	AkPlatformInitSettings_set_uMaxSystemAudioObjects_m795A95878C920A6163E8118F85863E197BD4CF43,
	AkPlatformInitSettings_get_uMaxSystemAudioObjects_mF0B3B1BC3B28A610B04D7FB3C5FC1B5D87796379,
	AkSoundEnginePINVOKE__cctor_m3CDB4875B017F190F663E304A1140FECD458B8FE,
	AkSoundEnginePINVOKE_CSharp_AK_INVALID_PIPELINE_ID_get_mC1199E07D98D3DC35E0B3B773DAFC8CD97EC2CD0,
	AkSoundEnginePINVOKE_CSharp_AK_INVALID_AUDIO_OBJECT_ID_get_m83B8E0EDDDE40291D3383CF43C259AD3B5AC2194,
	AkSoundEnginePINVOKE_CSharp_AK_SOUNDBANK_VERSION_get_m8FEBC947AE5A86B7CE82C903A1AFAB2D53CBC13F,
	AkSoundEnginePINVOKE_CSharp_AkAudioSettings_uNumSamplesPerFrame_set_mB36C9FBC77AED95FFEE123936CC03D8BCD2259EE,
	AkSoundEnginePINVOKE_CSharp_AkAudioSettings_uNumSamplesPerFrame_get_m6D1C5B29F49332215D68C796305CB6A056C76EF3,
	AkSoundEnginePINVOKE_CSharp_AkAudioSettings_uNumSamplesPerSecond_set_mD85113F7A35C25FDD898CCA7B69802C9B16D67BA,
	AkSoundEnginePINVOKE_CSharp_AkAudioSettings_uNumSamplesPerSecond_get_mC6995733F185E04D3DF8B1B05769E9CBDC53232A,
	AkSoundEnginePINVOKE_CSharp_new_AkAudioSettings_m86E8D90E30C29FED086AB775AA24448CC7DBEC0A,
	AkSoundEnginePINVOKE_CSharp_delete_AkAudioSettings_mD7D1D14E0F651B8AC1EE06A48D3945544AF41392,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_idDevice_set_m314A02CD66362ED19ABFDD69A786044438BD1CFA,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_idDevice_get_m62A38BA34D4FDF4FB0B734C3BF716ACE80026FB4,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_deviceName_set_m150F02C7A30964E9B4FD8520FB6D02859FEFCFBC,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_deviceName_get_m6DFAB2A8A85661FB089E0D8F909D9BCB1D2C80E7,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_deviceStateMask_set_m39C8BCAF79691A0EE170887D87A2EAA3F87ABB4F,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_deviceStateMask_get_m4CD09341127C14607E17CD727713A1F319202431,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_isDefaultDevice_set_m5BD25BE79EBEF6EF918575A85EE75C5DFB8D33E3,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_isDefaultDevice_get_mB4996E093D453E7A0D83189E098F38374EFC0D20,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_Clear_mA23C79C38275A071003A056372EE933002B8BFEE,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_GetSizeOf_mB599867FC4C22DA1835E695CAC045D268F86DC5E,
	AkSoundEnginePINVOKE_CSharp_AkDeviceDescription_Clone_m04214C6CA5BB085F699D5950542271E7F7B5D7A1,
	AkSoundEnginePINVOKE_CSharp_new_AkDeviceDescription_m22C706816FF0D67763A1F47AAAF8E727ED34CE74,
	AkSoundEnginePINVOKE_CSharp_delete_AkDeviceDescription_mB3984BA77CF2303152D8BDA58F5F463523C29558,
	AkSoundEnginePINVOKE_CSharp_AkTransform_Position_mC609C435B13CB4E0A579ADDF68B23ABFC7FF80BE,
	AkSoundEnginePINVOKE_CSharp_AkTransform_OrientationFront_m25EFD830C42D34288B49C97AB7867CF45F4A73BE,
	AkSoundEnginePINVOKE_CSharp_AkTransform_OrientationTop_mE80DC52583AA9439B4FB84A6FFF5D91F482CAD93,
	AkSoundEnginePINVOKE_CSharp_AkTransform_Set__SWIG_0_m36E60BE4D3A4F1B0E745E456EC61E0F88CECE81D,
	AkSoundEnginePINVOKE_CSharp_AkTransform_Set__SWIG_1_mCB8F85DA07C3474DCAC3DCEE84E92F430F76AC46,
	AkSoundEnginePINVOKE_CSharp_AkTransform_SetPosition__SWIG_0_m4F463B805D08468079882BF2478033AA2E122F04,
	AkSoundEnginePINVOKE_CSharp_AkTransform_SetPosition__SWIG_1_mC3ABECBBFFAB8FFFD2A2E5C35BD2AD7D01B7BB2B,
	AkSoundEnginePINVOKE_CSharp_AkTransform_SetOrientation__SWIG_0_mAC63FDC2AB6D4730A352DEAF12B75145AEF06B7B,
	AkSoundEnginePINVOKE_CSharp_AkTransform_SetOrientation__SWIG_1_m534132CBF8669126804385E246C7499A8B636586,
	AkSoundEnginePINVOKE_CSharp_new_AkTransform_mC2A3B0C0A52A8C45E40283D764D280CF81E19C29,
	AkSoundEnginePINVOKE_CSharp_delete_AkTransform_mE37027733677C69FFB41D848B6EB3B54E592D773,
	AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_occlusion_set_m1429BBFE69017940FC7792E11CD192E38655B5F3,
	AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_occlusion_get_mA1356E1E241D76884BBC1F87DA60112EE3D4E5B6,
	AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_obstruction_set_m877D5FADBB18971D10632AE5CC2A06ADF4FEEFD2,
	AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_obstruction_get_mA186D9996D17454D7848DEC361C522FBB336ABF8,
	AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_Clear_m10FEFBAE8D3EA5C90706D838533E04A24938FBE8,
	AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_GetSizeOf_m614123407AEC0D0A9441CCAE553778C056887CD9,
	AkSoundEnginePINVOKE_CSharp_AkObstructionOcclusionValues_Clone_m554B03DA9E60B83D1001BF67BE41391BB62DAB7E,
	AkSoundEnginePINVOKE_CSharp_new_AkObstructionOcclusionValues_m0AA23D27BA65715E8D5419AD99F4B50ABBEAC60E,
	AkSoundEnginePINVOKE_CSharp_delete_AkObstructionOcclusionValues_m058F5CF44D8029B65A41181F15D602F172E1E5AB,
	AkSoundEnginePINVOKE_CSharp_AkChannelEmitter_position_set_mF8B4B9A21B2FE3F4545A51DE4129C661A86D5E79,
	AkSoundEnginePINVOKE_CSharp_AkChannelEmitter_position_get_m6FB71F01BAB59F5E7F1EFC6578465D2D4403A46B,
	AkSoundEnginePINVOKE_CSharp_AkChannelEmitter_uInputChannels_set_m2A8E9629CC40ECBB3CE69CAB3FD9A254B6D0F308,
	AkSoundEnginePINVOKE_CSharp_AkChannelEmitter_uInputChannels_get_m231F02478380AF0D0B61E90FEA3C0248C2B2F42A,
	AkSoundEnginePINVOKE_CSharp_delete_AkChannelEmitter_m92CABFE5796CAD460178C389B65448E8BDBBF192,
	AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_listenerID_set_mF33F4ECC0CD1846F468B1E23C5C07392944ADF86,
	AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_listenerID_get_mB974605D9F959141D228297977D7B06CF65D93F5,
	AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_auxBusID_set_mC93CAB5E7DC668B3CBF495778F2A46EDC3860372,
	AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_auxBusID_get_m48D9F7917CD8F0DA295A333E9F5A763BA7E1948F,
	AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_fControlValue_set_mB64A3B7AD457838BA142622DB6FE7152F5FD4862,
	AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_fControlValue_get_mF327FEC82F76AAA865E9554E767EA27F60DB69C6,
	AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_Set_mB7E3EE05EAAD73330FC4BD81806B2B125240EB50,
	AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_IsSame_m406BE7CB605D5842EE2E54B89C3F8B23DAA222BB,
	AkSoundEnginePINVOKE_CSharp_AkAuxSendValue_GetSizeOf_m6A772FD34FF68CACA5A6A0676BFE60BEF31B6580,
	AkSoundEnginePINVOKE_CSharp_delete_AkAuxSendValue_m0DA776811BA6D7623A428470FDF749A931EA248D,
	AkSoundEnginePINVOKE_CSharp_new_AkRamp__SWIG_0_mFB6443518A53FB1CC7954D9396B8FB07DCCD0FE5,
	AkSoundEnginePINVOKE_CSharp_new_AkRamp__SWIG_1_mCA1703C810CF0FFDC87E45126DB6E60BDB9A6236,
	AkSoundEnginePINVOKE_CSharp_AkRamp_fPrev_set_mA57A3545BEEA57B92C3C098DD2D5885D733D6F6A,
	AkSoundEnginePINVOKE_CSharp_AkRamp_fPrev_get_mB393EC0FF1AD741D0A5688440CE01B231D70CFCE,
	AkSoundEnginePINVOKE_CSharp_AkRamp_fNext_set_mC4F784865DE5B4A6558D990839A109CCF8AE50C2,
	AkSoundEnginePINVOKE_CSharp_AkRamp_fNext_get_m9DEE21F7072CF5823A1F61590468931DA2244D93,
	AkSoundEnginePINVOKE_CSharp_delete_AkRamp_mBB1191E67E33FB7FE9461A81E678CB0D2DE1E57D,
	AkSoundEnginePINVOKE_CSharp_AK_INT_get_m3B425C6F73456C124486DEFC56F946ADF27FF8FD,
	AkSoundEnginePINVOKE_CSharp_AK_FLOAT_get_mEC122811F6BC8056DD5B23C71C5579DCA1A2CA90,
	AkSoundEnginePINVOKE_CSharp_AK_INTERLEAVED_get_m868307F8BA3B8C4CD98220B2735D8475E8223BCC,
	AkSoundEnginePINVOKE_CSharp_AK_NONINTERLEAVED_get_mA919EA03A575A5B29822E64614B30019F529730E,
	AkSoundEnginePINVOKE_CSharp_AK_LE_NATIVE_BITSPERSAMPLE_get_m3DD8AFD591CEBCBB5CA92966B22AE251C6CFD851,
	AkSoundEnginePINVOKE_CSharp_AK_LE_NATIVE_SAMPLETYPE_get_m9B26F9221DA7B5AF830A5E78504EF677EC26D648,
	AkSoundEnginePINVOKE_CSharp_AK_LE_NATIVE_INTERLEAVE_get_mDED7CBD85CC806998E90EB9EB56EED2B7D43FC9E,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uSampleRate_set_m183FE3141AA58D976C7DE81A029D497E0217DE97,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uSampleRate_get_mC5BAE9D608C3F9041E5D383CCA982F2A6FC9B11E,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_channelConfig_set_m1B35F19449CA0C7B8BC827C038F1AA398FA4E079,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_channelConfig_get_mF40BFD6770D97223CBED076EE163A3B7C2EFFF62,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uBitsPerSample_set_mD303A3A4FC98A4C753B98C3D0AFAC9CB71CE85AE,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uBitsPerSample_get_mBCB3294207D9CAFBADB68B5608DF20B7D1F53A15,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uBlockAlign_set_m4B6AF07B622848630691294D3FF66BB4BB0104FA,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uBlockAlign_get_m3B323F0E270871BF0AB9858715B205CC4D22D83C,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uTypeID_set_m17ECC64A9ACE970170937CB2AAE0817630212BF5,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uTypeID_get_m56178D289B1A4C7FE7914F9EC97B166BF849E0C2,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uInterleaveID_set_m1B3DDAFF15653009DE517579F981448CFFF129B1,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_uInterleaveID_get_m122C003AE8A364B9E4410EC2DE9EB671807469AB,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetNumChannels_mDF268E2098D747BF4684EE6E989F4BB96E6EB090,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetBitsPerSample_m12F1128704D9771AC44005DC554C899F02EE6B74,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetBlockAlign_m8945F5258221C5334E24A3CA309E953E773C62CA,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetTypeID_m8E5B5D617603BA2454893805197ED6D772AEEF6B,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_GetInterleaveID_m89D9C35F06A45E4F2A948EBB976AD8D68E6876E7,
	AkSoundEnginePINVOKE_CSharp_AkAudioFormat_SetAll_mF32B1D4019A0B15FE0E7E0C06D74D394E06DF5FF,
	AkSoundEnginePINVOKE_CSharp_new_AkAudioFormat_mB893B87AB573D95C6A4E6BCE6F74A8FE3E877C7B,
	AkSoundEnginePINVOKE_CSharp_delete_AkAudioFormat_mE6B9D67F1074805A1973E908613696ADB3BCBF05,
	AkSoundEnginePINVOKE_CSharp_new_Ak3dData_mB672949CF43BA9507A6C3B8FE23F04C6B2C85A04,
	AkSoundEnginePINVOKE_CSharp_Ak3dData_xform_set_mEF7BB20DD6C3E75622A5BD01EA7617586EB173F4,
	AkSoundEnginePINVOKE_CSharp_Ak3dData_xform_get_mDE1F91C5AF1C0077D4E59C091B8E0FF1F06D071E,
	AkSoundEnginePINVOKE_CSharp_Ak3dData_spread_set_m7A4FA5F985F56AF49F20DE05931FDA2A8B117D08,
	AkSoundEnginePINVOKE_CSharp_Ak3dData_spread_get_m89D5663C7B3D009BEA4C6C957F5FE9ACE9A6BDA2,
	AkSoundEnginePINVOKE_CSharp_Ak3dData_focus_set_m6E6F8CA1F029EC09DD546C477EEFEF12E4228A00,
	AkSoundEnginePINVOKE_CSharp_Ak3dData_focus_get_m134C500D4615B0A93F454CD46F45C1E820D4F613,
	AkSoundEnginePINVOKE_CSharp_Ak3dData_uEmitterChannelMask_set_m0F5423456E54BBD4F31218D7CD83D1748C70BE11,
	AkSoundEnginePINVOKE_CSharp_Ak3dData_uEmitterChannelMask_get_m7D9045EB91DA2561EFCC25D69F1EEA0999802147,
	AkSoundEnginePINVOKE_CSharp_delete_Ak3dData_m64D2A1B5ED936423C33229E1C71DC8408AE8392B,
	AkSoundEnginePINVOKE_CSharp_new_AkBehavioralPositioningData_m2374C1C7E9EBEE4B5FD1700DFF50874C8FA28673,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_center_set_m770C86EF6A6C954E0B8393C30B570E5DC714BCA5,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_center_get_m50C7CFFADDA9A58D74378B89381F3C98B21C8091,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panLR_set_mA9A9CFDCE6F654B16BF5CF16AC5112986C6DC8C9,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panLR_get_m606A5A8148ADE490CF9A970ABFEAFC3799F05E40,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panBF_set_mF860D34AED6F9D0988771FC15784EB880A24C9C6,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panBF_get_mDDE82EA8757281A1129CDEE4F10529506E3E6A47,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panDU_set_mAD5900CD477BEBE8170C674A5924B89BA785E70B,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panDU_get_mC53F6C75294DEB1569765967DBCD6789DE7350A1,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panSpatMix_set_m33BAC00AFD84722DD59F40241EDC35D7EDA11183,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panSpatMix_get_m33204FE266CFD5370B014CFD2E4ECB0132AB4B37,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_spatMode_set_m917B6D3A2C3CE97370949D0F76397FC8B36984D8,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_spatMode_get_mC9BC076AFFAED68E14A69DEA2D8529BF4906CC44,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panType_set_m2329EA35B9E09C00E2F48B72AADA5C7871CF15CD,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_panType_get_mF961F102673625B8A5358946B1A2335A1F300E3A,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_enableHeightSpread_set_mC94772EE380BC915F638EDCF438B5EE6183E9DE7,
	AkSoundEnginePINVOKE_CSharp_AkBehavioralPositioningData_enableHeightSpread_get_mEAFC7DC8852E48FD357C6B26527B915DBC48B912,
	AkSoundEnginePINVOKE_CSharp_delete_AkBehavioralPositioningData_mF2CCFA57F29BC023CE8B32DE72667B196A338FD4,
	AkSoundEnginePINVOKE_CSharp_AkPositioningData_threeD_set_m3F0F2F7F321B6D124B11B584A07EDBE71681159C,
	AkSoundEnginePINVOKE_CSharp_AkPositioningData_threeD_get_mA5E1973D4C97012FADFD26D8916C2C4A5DDE1BEE,
	AkSoundEnginePINVOKE_CSharp_AkPositioningData_behavioral_set_mEEDC537227FA61464782C02276395A9C0DCE2E92,
	AkSoundEnginePINVOKE_CSharp_AkPositioningData_behavioral_get_mBA84AC6729DBCB14F9BDD108EED06B578C111AE1,
	AkSoundEnginePINVOKE_CSharp_new_AkPositioningData_m6956F7BC25D8B9CFC66A5B1C583539796D291B5C,
	AkSoundEnginePINVOKE_CSharp_delete_AkPositioningData_mD9596314842F4923F4F814CD164982B348856846,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_channelConfig_set_m60A4EC2F33A72678BFD51F034111586A7F711FED,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_channelConfig_get_m446E9A9DB70929064EA847DE24A361C062788AEF,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_uMaxSystemAudioObjects_set_m8ED393F0779E23884FBD1A5EF9C0B4E721296775,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_uMaxSystemAudioObjects_get_mC3E61D2CE4EF98C420D4A4900A0D2C37069F5826,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_uAvailableSystemAudioObjects_set_m7BA9F371BF9777509BE89F28E7D254C4338E97A6,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_uAvailableSystemAudioObjects_get_m7E1C581BE5F5E79802637850B5727C44926AFDAC,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_bPassthrough_set_m875E228A3F71CE7CF8B1E1200598F0417E4DA17D,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_bPassthrough_get_mE73B311C1196719985EF326C977A08ED405FF793,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_bMultiChannelObjects_set_m8B5F2C477EDC3B0F3AB39ADBECF1427C2BBA85D1,
	AkSoundEnginePINVOKE_CSharp_Ak3DAudioSinkCapabilities_bMultiChannelObjects_get_m9E63B2F5096D837A9A16240641DF142B20D55643,
	AkSoundEnginePINVOKE_CSharp_new_Ak3DAudioSinkCapabilities_mDE3B8EE0DC4FA22EEE47EAB4C5AAA563B6285FF0,
	AkSoundEnginePINVOKE_CSharp_delete_Ak3DAudioSinkCapabilities_mF40928449B385DC37428F7A23225EA068766CFA7,
	AkSoundEnginePINVOKE_CSharp_AkIterator_pItem_set_m3FAD6C8BC39A33E2C0BC7C4E7C1E218657C2003E,
	AkSoundEnginePINVOKE_CSharp_AkIterator_pItem_get_m0857CF5DE0275F7664E5B0B0A132FB8F13D9D5D5,
	AkSoundEnginePINVOKE_CSharp_AkIterator_NextIter_m29EE0296F290FEEC2C3EC31BFDCC9D8B0F509A59,
	AkSoundEnginePINVOKE_CSharp_AkIterator_PrevIter_m38F6D1DCD5F6EE0C8A58E11C85307B4E788053E9,
	AkSoundEnginePINVOKE_CSharp_AkIterator_GetItem_m977E140F5524D6E39965266F83CAEC8730795262,
	AkSoundEnginePINVOKE_CSharp_AkIterator_IsEqualTo_mE76B1D622D991CA468C685AAF37B8F0ABC37D989,
	AkSoundEnginePINVOKE_CSharp_AkIterator_IsDifferentFrom_mA2E42FF0A4518B0DAFC16044C4884261528F41BC,
	AkSoundEnginePINVOKE_CSharp_new_AkIterator_m209F010E6CF5DE74147E6FFA3F9BD0CC59462F85,
	AkSoundEnginePINVOKE_CSharp_delete_AkIterator_mB4D6DDA1E82F2AC04A47CE30553E8C249F493402,
	AkSoundEnginePINVOKE_CSharp_new_AkPlaylistItem__SWIG_0_m0706DFB942116604528CC82913B7ED28391E1351,
	AkSoundEnginePINVOKE_CSharp_new_AkPlaylistItem__SWIG_1_m61D61484F12EAA67EDEC303AE50BBECCAF48B2D0,
	AkSoundEnginePINVOKE_CSharp_delete_AkPlaylistItem_mC1C138D30CD1EC34D8D8A4BDB54816ED5AF91A76,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_Assign_mF8D5AC0ACFC802038267CA1ED3D2522CD8157D29,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_IsEqualTo_m80639ABBBF14D2848A07B6AF1A3B32E48860F5CE,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_SetExternalSources_mD2DE07035C1F2BE6BEF86352C6776F1855234E3A,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_audioNodeID_set_m6E344964CCDB06967B5EF382C7A1D18B244B1286,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_audioNodeID_get_m75EEDC060098E65806A6E6FC39E41311DF5A9457,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_msDelay_set_m5284276CE505739BC9AD67AE5897F118754C1A4A,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_msDelay_get_mB83FB0ED5CFD69163CA23538E831D6635F55EDC4,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_pCustomInfo_set_m81F94D3B0D685EDA850FE7B1855AB08AE8B9895D,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistItem_pCustomInfo_get_mBEA02F5EE9993AD425778B88EF223DD4F09E12C5,
	AkSoundEnginePINVOKE_CSharp_new_AkPlaylistArray_m73FAEE78BDD7FE40D1362BC8B4EC22B5AF96223D,
	AkSoundEnginePINVOKE_CSharp_delete_AkPlaylistArray_mF788C4137DFE32303C0AC8200D42BD20A15BE6DC,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Begin_mDE0BECD0C8687DD7875FF8B02105D27AC6CD9DA5,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_End_mB2F295D79C54DFF15F0CAE2DB36A3E2A967A10DC,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_FindEx_m3DCF45768C87778B4DF45CFFB28604C2D809CD9C,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Erase__SWIG_0_m31A3F9E57C795640E0CB637D355C30969FBCBEA9,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Erase__SWIG_1_m41099D1B22E63AFEEDE70714F6CA960B3D95B756,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_EraseSwap__SWIG_0_m09CD8812999456FD4267467FA27A19F6C04A3D50,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_EraseSwap__SWIG_1_m072CA8618344F0699619EA9F3D12853F14520DBA,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_IsGrowingAllowed_m2FAFBC444B742657F7A3EC519D19E90B711AF7A5,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Reserve_mE3611AC76F5D84208812F5867399DF4476E73DA1,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Reserved_m63D1593A78663EFB1FB5E74B51EDEC73154F864B,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Term_mC187F4887CAA70447D51C9A2736AE4F9A6770FCE,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Length_m7D1B13B3DA8EEFFCE861667C3E00E51D46BB89AF,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Data_m4FA10CA83AE519CE57247BFD5CA5970B48975032,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_IsEmpty_m97D4B1161D9A1D27BCD2112F52654D714F72E481,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Exists_m642CB4DED450C56AE46C26A82514DA4CA04BCABF,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_AddLast__SWIG_0_mEA700ED6FF3D3C7DF51BC25D8B35870967B8F0EE,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_AddLast__SWIG_1_mFC86828B5D7004C3A8AF3BC8DEA6ADBBF7A18999,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Last_m41593BEEF9685C809634FE30421A94A7FB7CE2BC,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_RemoveLast_m4CEED04269A58FEDCD0DBA197291E20840DB8D23,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Remove_mCCDEF80616CDBD7AFAAA442D6B159EA865BD1149,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_RemoveSwap_m03A89A785888456B6286CC0C8FA9F36F45052CCE,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_RemoveAll_mE6FE8987FDFACF1F38E86B256FA626DA01EE967A,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_ItemAtIndex_m014DCAEE27B2E8AFD7EE4393B014BD21D01820CB,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Insert_mA15424F01C49ABD7C8BC140396C3950D55018769,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_GrowArray__SWIG_0_m9C3C9BCB0088BD74BB92F5B74347C523C7A76F85,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_GrowArray__SWIG_1_m5ECF80EBD12EB877700766B5D00D2FC460D50B5B,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Resize_m70796A85E6306B0DADCD7FD7023A170ACAC402B9,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Transfer_mBF57B3610DCE2F022832A42928544952279649C3,
	AkSoundEnginePINVOKE_CSharp_AkPlaylistArray_Copy_mDA8BD377129C53D9D1A401FC8EE877BF79A57417,
	AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_0_m31F1EC41F62A3793DB303DE0DF667F5726940DD5,
	AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_1_mCA27D8A4D51F2C2026F4B0CB73937FBC6E06CFA6,
	AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_2_m669BCFC004879B1D028B5972C4A75CBF9D6D5270,
	AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_3_mA1F059D8570369A39095B402172B4B028A643AEE,
	AkSoundEnginePINVOKE_CSharp_AkPlaylist_Enqueue__SWIG_4_mA4067000DEAFEBB0564EFAD3610B710D2C82C96C,
	AkSoundEnginePINVOKE_CSharp_new_AkPlaylist_m8DC13485E2A99BB54BE5CD67CB0AB3E22EFBCFD0,
	AkSoundEnginePINVOKE_CSharp_delete_AkPlaylist_m6AF5457522C9A6CCD3209D5AFE7375D01A35750A,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceOpen__SWIG_0_m1F355066BD0A5D4FFCFC5F5A12D415535560374A,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceOpen__SWIG_1_mC15EFAD3A69A222AE13C88D1E3B63ECC54C19C9D,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceOpen__SWIG_2_m8233A45FB4C5741FFBF17CDDD70CC841BD44414F,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceClose_mC8B5F221A38AEA3AE217C356048F83CC6DA59C99,
	AkSoundEnginePINVOKE_CSharp_DynamicSequencePlay__SWIG_0_m69A365BD11C005C3F0382638D061189DBB7C6197,
	AkSoundEnginePINVOKE_CSharp_DynamicSequencePlay__SWIG_1_mC1419579D022A6D64D4A44EE9FBF7444A8FE6654,
	AkSoundEnginePINVOKE_CSharp_DynamicSequencePlay__SWIG_2_m583FA013DFFA41906EADAA64DC76B236D6CCFE42,
	AkSoundEnginePINVOKE_CSharp_DynamicSequencePause__SWIG_0_mA6623A8AD3840F762F2853866E33CA666BFD75EA,
	AkSoundEnginePINVOKE_CSharp_DynamicSequencePause__SWIG_1_m344C4C5008023432FF68E769AFBD8BC46C5E90C6,
	AkSoundEnginePINVOKE_CSharp_DynamicSequencePause__SWIG_2_m7ED416260F85C32E2ED495AB3051E38E81EAE10C,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceResume__SWIG_0_mD6AB009E546C4AA26748ADF3AEC51A12F7B68D65,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceResume__SWIG_1_m072D9BC66995A6B6997A1ACCAEE7C3BAE0EBBAF5,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceResume__SWIG_2_m99498189FD999E15A843E39F832D7AB0FBBD9B41,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceStop__SWIG_0_m0908A3DA11191C583CAC93C10A57DD66BF1615C6,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceStop__SWIG_1_m1B65C62E9E268290704D18EB68D701FC541AE2D6,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceStop__SWIG_2_m550D2347CFEFB6D59167F507C6CF88D6BA503A74,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceBreak_m43F1ADF041EB21C60DE6A32AD1C00FAA2C23E984,
	AkSoundEnginePINVOKE_CSharp_Seek__SWIG_0_mA3CA606BB82C615A676DE8FCDFE955F2E7F4DFD3,
	AkSoundEnginePINVOKE_CSharp_Seek__SWIG_1_mE1BF533AA61A43DBBF9144F8F18D8B7F1FFA3C31,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceGetPauseTimes_m09DA809BB9B84F582E233A09A09F02C346D6DBAA,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceLockPlaylist_m1526649355ABEC1212DF3ED6C5E8D9BED2031FE1,
	AkSoundEnginePINVOKE_CSharp_DynamicSequenceUnlockPlaylist_m79E10EA52AD38AED00BA01192A0E76F3954036A4,
	AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_0_mA218D47F9C42E30403F7386BE4C2C8D7B9EDDD45,
	AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_1_m276C31672DCF04B5FC97BBC8AECF755985924CAC,
	AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_2_m650A98ED0841E38C14F46A011BD1C4CD9C07514B,
	AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_3_m29A7965031F5217E4996ADEB4696AD6560457092,
	AkSoundEnginePINVOKE_CSharp_new_AkOutputSettings__SWIG_4_mEED05F2531388C2287F2DE93EA15F8938D181B44,
	AkSoundEnginePINVOKE_CSharp_AkOutputSettings_audioDeviceShareset_set_mA9C6ABDCD26078102FF007E194F88D5CD00C41AF,
	AkSoundEnginePINVOKE_CSharp_AkOutputSettings_audioDeviceShareset_get_mC96F312E493753659A215FD893C1B70DDD6C2B67,
	AkSoundEnginePINVOKE_CSharp_AkOutputSettings_idDevice_set_m12DDD7FBF2D513D65CEBECD828EFB4A522FBC77F,
	AkSoundEnginePINVOKE_CSharp_AkOutputSettings_idDevice_get_mEBC5A6237F2E5342A7E7461BB2CA1F52525F3703,
	AkSoundEnginePINVOKE_CSharp_AkOutputSettings_ePanningRule_set_mF51F096F6931D4BCF49B16A119BDE5813654DEF7,
	AkSoundEnginePINVOKE_CSharp_AkOutputSettings_ePanningRule_get_m449B0165358904B56E05559FD2A4D4673191A379,
	AkSoundEnginePINVOKE_CSharp_AkOutputSettings_channelConfig_set_m22B4B24755472AF1944BD370F76B37DB1A7111FD,
	AkSoundEnginePINVOKE_CSharp_AkOutputSettings_channelConfig_get_m374C10FBDF08C08574710A93532BAA33B18DEBB2,
	AkSoundEnginePINVOKE_CSharp_delete_AkOutputSettings_m0090E7732FCADFCA94E05F3D07651587DC0057D6,
	AkSoundEnginePINVOKE_CSharp_AkTaskContext_uIdxThread_set_m98A40716A31DFF1F94E19929D25BA7233BB32E0D,
	AkSoundEnginePINVOKE_CSharp_AkTaskContext_uIdxThread_get_m3FBFEF98FC93398C69984D2F37F0E372D4613CC5,
	AkSoundEnginePINVOKE_CSharp_new_AkTaskContext_m0A2FBD206B41FD7CA0AAF3F8C91BC5FB736D8AE9,
	AkSoundEnginePINVOKE_CSharp_delete_AkTaskContext_m28ACE0BD2747B94ECB0188651A52B05CB8A738D7,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMaxNumPaths_set_m1BDB25B03254EE33870EC40333174541243C16A9,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMaxNumPaths_get_m600485842BF380550FE93CB7B9B55ABAB62688BE,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uCommandQueueSize_set_m5EA87AD25C346A890A824C0CA00ACE1A0D0B05BD,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uCommandQueueSize_get_mDF1803B40831E31DE0F034E33CD9FD9AF87BED5A,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_bEnableGameSyncPreparation_set_mDD71643B3BCA366487352C270974B3F58F3BCFDC,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_bEnableGameSyncPreparation_get_m681DC66A972C85BD48EFA68309CE8E84AE9462F3,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uContinuousPlaybackLookAhead_set_mBE55AA1089694768E070B929F24D6099ED545DA3,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uContinuousPlaybackLookAhead_get_m89B98C37F7DE61CEFC5EB27924F8789A374D135A,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uNumSamplesPerFrame_set_m5D0DF3B5237B8AE4C78F5886DF18BECF1A6015E7,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uNumSamplesPerFrame_get_m20E13CBBEA5BDFE89E695952987C3772017A15B9,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMonitorQueuePoolSize_set_mED33768078F5D2B4816DA00F6CA7DD4FF41F90E9,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMonitorQueuePoolSize_get_m480D7755630C8E7263D05C04D8984227BCC671C3,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_settingsMainOutput_set_m8E7B95ABD2831E07EFA378CE9F2A1B921AA3ED7D,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_settingsMainOutput_get_mB3A69D85A76EC8EE106C3435A5E7891E46E76EA1,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMaxHardwareTimeoutMs_set_mC1216F8BE668EB9F46772F14A5BA6BD55B920D1B,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uMaxHardwareTimeoutMs_get_mA195A544D208448857149276CBD6E72E50E2BFC2,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_bUseSoundBankMgrThread_set_m09DE89FA4E7049C97F7A084B646D1EEE2898D258,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_bUseSoundBankMgrThread_get_m4548518F9D5B9E1BBC4FE12618BCA80BE5ECD139,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_bUseLEngineThread_set_m15633143705B06CF5248AA4D64C13D40FE703569,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_bUseLEngineThread_get_m6723F57F7285E6D3D8D74A1131BDED656DF5E01C,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_szPluginDLLPath_set_m885DFFF22919A6B148CF9326657AA4F23CE5A185,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_szPluginDLLPath_get_mF55A0C7D3BAAE505FF6864D9D891F79966096E0E,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_eFloorPlane_set_m5D28B0043C7E09C54826A9B5DC56B73C431C83CB,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_eFloorPlane_get_m5384F206F2C872932719A0F0FA4A8E0AECC05568,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_fGameUnitsToMeters_set_m2413ECB587C1A2A74547D1FE22A002945249BFF1,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_fGameUnitsToMeters_get_m1F69C51E0415D0BCF997F6345CAA6AC803E125A2,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uBankReadBufferSize_set_mF4578F5FCE3484FC694A1B0F936F079164A351F8,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_uBankReadBufferSize_get_m37410F7AE35CCAC8C2F018009AD92A9A37F05601,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_fDebugOutOfRangeLimit_set_m2910E271038EECA83A6D77EC4C8688C124CE30C8,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_fDebugOutOfRangeLimit_get_m64C11096D5D2FDEF53780F6D40A5F2875752D285,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_bDebugOutOfRangeCheckEnabled_set_m8AC50A7BD63E5B5685E4571D6FFA1199A9AAC272,
	AkSoundEnginePINVOKE_CSharp_AkInitSettings_bDebugOutOfRangeCheckEnabled_get_m9A784B8311C476581C07CD6B592C31B140A1284D,
	AkSoundEnginePINVOKE_CSharp_delete_AkInitSettings_m27CB4E78F8C9E18FC0CE8E436837A32A426EC972,
	AkSoundEnginePINVOKE_CSharp_AkSourceSettings_sourceID_set_mAD890B3751FF5E74A4653E6255B87F4D062AF281,
	AkSoundEnginePINVOKE_CSharp_AkSourceSettings_sourceID_get_mB763CE8E808CE676BE327CE1F5C7FCF7C8ACB450,
	AkSoundEnginePINVOKE_CSharp_AkSourceSettings_pMediaMemory_set_mCCA7E3B5E8F20FF39BD7F63F66CA214C254DC12E,
	AkSoundEnginePINVOKE_CSharp_AkSourceSettings_pMediaMemory_get_mD67E86C1337B55516CBFB23151E8FDF757EA5150,
	AkSoundEnginePINVOKE_CSharp_AkSourceSettings_uMediaSize_set_mA13532BEDE731D0CB1185A1ABB0CDABC4203A067,
	AkSoundEnginePINVOKE_CSharp_AkSourceSettings_uMediaSize_get_m56ED8F938B0394DE0FB0DB41ACB5CC604A4F2771,
	AkSoundEnginePINVOKE_CSharp_AkSourceSettings_Clear_m02E248B4172D71B0DB002B5C26317376A2429BFF,
	AkSoundEnginePINVOKE_CSharp_AkSourceSettings_GetSizeOf_m02D0A93C257EE23B752EA29786778C0EAFC3E7A2,
	AkSoundEnginePINVOKE_CSharp_AkSourceSettings_Clone_m8AD470DD6446312CDD28A8A930BDB7DFC84E51D2,
	AkSoundEnginePINVOKE_CSharp_new_AkSourceSettings_mE11367D5D14E0108AC61D1B155A881B5A00ADF79,
	AkSoundEnginePINVOKE_CSharp_delete_AkSourceSettings_m934F977AEB73E35426A9BB8D0BC4E734D36D3A31,
	AkSoundEnginePINVOKE_CSharp_IsInitialized_mE1ECBD46A83C16F914E12B6DDAEFB3F1C493D267,
	AkSoundEnginePINVOKE_CSharp_GetAudioSettings_m6F05727EBA048C28E8CB25B4174155ED9F65EF22,
	AkSoundEnginePINVOKE_CSharp_GetSpeakerConfiguration__SWIG_0_m7490CA296547BC9199F9F88FB0569B7C4937EE0A,
	AkSoundEnginePINVOKE_CSharp_GetSpeakerConfiguration__SWIG_1_m85066A6F2E5F56DE6A2ECF35E13AC5633B4660A9,
	AkSoundEnginePINVOKE_CSharp_GetOutputDeviceConfiguration_mB57FF4EE08BFE6F91A470BB6E2CC63B0627CCEB8,
	AkSoundEnginePINVOKE_CSharp_GetPanningRule__SWIG_0_mFD962009F85CAF40E902B9E40780D00E43D1AF7F,
	AkSoundEnginePINVOKE_CSharp_GetPanningRule__SWIG_1_m3312219EC4D406CA67E7D3F2AF5D818E0B3D662E,
	AkSoundEnginePINVOKE_CSharp_SetPanningRule__SWIG_0_mFD8E970C2B8710EBFFE9875E65D1A4676AD104F6,
	AkSoundEnginePINVOKE_CSharp_SetPanningRule__SWIG_1_m3024E08F128F70751ACC70FD86DBC4C74082D899,
	AkSoundEnginePINVOKE_CSharp_GetSpeakerAngles__SWIG_0_mB26E98FF61B129B1B47A4B6796DBE86CCACDDC73,
	AkSoundEnginePINVOKE_CSharp_GetSpeakerAngles__SWIG_1_mFF47D6BC9675BC0DDEF9DCAF45F1228005627D23,
	AkSoundEnginePINVOKE_CSharp_SetSpeakerAngles__SWIG_0_mFE520847B32911957E354CCBCC09171D1381FE3F,
	AkSoundEnginePINVOKE_CSharp_SetSpeakerAngles__SWIG_1_m2FEF1FE7547C0D79F02E036DD9F982D7232166CC,
	AkSoundEnginePINVOKE_CSharp_SetVolumeThreshold_mEE4DB005135BFFFE52B279900F9A946A321BB396,
	AkSoundEnginePINVOKE_CSharp_SetMaxNumVoicesLimit_mBF3800B3CBB85662FF3629009A21FAE488828983,
	AkSoundEnginePINVOKE_CSharp_RenderAudio__SWIG_0_m09F4C47B01A096AD0E822D9153CB3706EFED0C3D,
	AkSoundEnginePINVOKE_CSharp_RenderAudio__SWIG_1_m8E11221C93807893E011E9FDCC99BB57F28014F4,
	AkSoundEnginePINVOKE_CSharp_RegisterPluginDLL__SWIG_0_m7A4EC8760A256EE7D8016365560E16FDF0B56C40,
	AkSoundEnginePINVOKE_CSharp_RegisterPluginDLL__SWIG_1_m7F577B708326E2244B270792C268AE5AD2042937,
	AkSoundEnginePINVOKE_CSharp_GetIDFromString__SWIG_0_m4C9D9E377A3FADA5BCA73F8835E9E837004534DD,
	AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_0_m1A62532A467B4457FE1427583ADFA9B2ACEF636D,
	AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_1_m4724996CA00E3A233B87A52DEC4D0B42148C4C23,
	AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_2_mF23C56F203744AC4A968005737FE544045623F24,
	AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_3_m2F994B707BB0541A17FC1E5E579C7F7FD1D9B441,
	AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_4_mA544D4F4FA3E827F6A3863935B51D83E7B03C115,
	AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_5_mD2717A2E1C642E16DBA7F825C67DC2C766ACF710,
	AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_6_m312C30B85567C4A04C77AEFCFAC1F0B2E541C72E,
	AkSoundEnginePINVOKE_CSharp_PostEvent__SWIG_7_m2AD24E8F3DE7D5D5E6CC5F250DD75C382AF9CAB8,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_0_m587FF54BE03B90895EC2D6227FC598C3401BAE85,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_1_m84FBFE2B44A191AC3D2E7DA96AD78BB754801BC4,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_2_mCE07A652864596605A55841CC5885902BBBC3449,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_3_mCFD6749D1C9C8547A50B9D55E26816279D4BAC5C,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_4_m055142057D49971AF4C256055251FAF05E78A944,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_5_m31DDBB38A18A61176B630CAFE42D66086C5A1EA8,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_6_mBED1F819FA89DA400988DF633C259E2E8313A5A6,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_7_m497ADD90EFB814C88E784CC9F5699F8E01C5C422,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_8_m08928B5384ED4350F33C75C8B1C1ED015D66F3DA,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnEvent__SWIG_9_mE2B1F23E58C9049D0E419EE1EB07876D19FC3B51,
	AkSoundEnginePINVOKE_CSharp_PostMIDIOnEvent__SWIG_0_m35415AE2DAD2017D111F9F8D819AA42C841C430F,
	AkSoundEnginePINVOKE_CSharp_PostMIDIOnEvent__SWIG_1_mFCDABC1CBF9631688F91BF14935B5678918683DB,
	AkSoundEnginePINVOKE_CSharp_PostMIDIOnEvent__SWIG_2_m9E9D538A53E4822430CC965E6E6CA14107299610,
	AkSoundEnginePINVOKE_CSharp_PostMIDIOnEvent__SWIG_3_mD2D9A0E72D5CBF7F8FED06242E680B010E4DA253,
	AkSoundEnginePINVOKE_CSharp_StopMIDIOnEvent__SWIG_0_m471FCF518FFE02BC0D4DB8206E1AF1F6F3B1681C,
	AkSoundEnginePINVOKE_CSharp_StopMIDIOnEvent__SWIG_1_m02CDE09B4CF472E5ECA1F0B56C62EED1D4CFADDE,
	AkSoundEnginePINVOKE_CSharp_StopMIDIOnEvent__SWIG_2_mC8FFE4059845EBC333B1AEC660A315FC2D45C431,
	AkSoundEnginePINVOKE_CSharp_StopMIDIOnEvent__SWIG_3_mB4B0B92C82471C7D5DB4DF1B6C6274E40C19348E,
	AkSoundEnginePINVOKE_CSharp_PinEventInStreamCache__SWIG_0_mC480731B7BB6F2F8E11B0F75075063F5B4EB03D5,
	AkSoundEnginePINVOKE_CSharp_PinEventInStreamCache__SWIG_1_mCCEA05A87C1F23ADEC177EE2CF46202DE5DBD824,
	AkSoundEnginePINVOKE_CSharp_UnpinEventInStreamCache__SWIG_0_m82AB9C58544A2964F097653B9032F814FABB73B7,
	AkSoundEnginePINVOKE_CSharp_UnpinEventInStreamCache__SWIG_1_m2CDD264F6647D77ECAB7641FA5CB4F905297C11A,
	AkSoundEnginePINVOKE_CSharp_GetBufferStatusForPinnedEvent__SWIG_0_mA09076B04B836E99C595DE2180071A3067B296A0,
	AkSoundEnginePINVOKE_CSharp_GetBufferStatusForPinnedEvent__SWIG_1_mB5EBAA6BAD9515204B2E3A737E44FCCBA66AFB55,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_0_m8A74F6404FE746DB5E69511E7CE8E8790F3E4736,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_1_m4610B2A0E3A3B9441ED51A7D0CC2EF457FEC2BBD,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_2_m0DF8B0D5396D234C2E7E4C0C7E744358B2C7F46B,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_3_m9094CC1BB128003F9C995E39CEC7774456FBC581,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_4_mA38B24B7485253A0B1605167525C46AB55CE1084,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_5_m4D6FAAB63116A625AAB2DC907395ABAB137FAF67,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_9_mA08D48BF7341059E8BD5DC0096444CF5FD7F4322,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_10_m1AC0D0C9807F567FA34C96D35ADD199B5DC12208,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_11_m977C697D2867BC7C1488CBDAEC45C83B2942FAB3,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_12_m1C0C95044D1D0BB9B2C04001DD25743A0C74C160,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_13_mC6F90E01E137FEA375273D342E74FE26C64B164A,
	AkSoundEnginePINVOKE_CSharp_SeekOnEvent__SWIG_14_m2DFFE48865231926EE3FB809CB352038A9415E7F,
	AkSoundEnginePINVOKE_CSharp_CancelEventCallbackCookie_m435A745F70BE5A8E57BBDF10CAD73A972546FEE8,
	AkSoundEnginePINVOKE_CSharp_CancelEventCallbackGameObject_m82BE60BFE89FF7C1DE3BA2BA748489B83443265C,
	AkSoundEnginePINVOKE_CSharp_CancelEventCallback_mFF9619A5C69B19F4D6515A5F2554DD06A96E1B7B,
	AkSoundEnginePINVOKE_CSharp_GetSourcePlayPosition__SWIG_0_mC75357818A772CBBC11EBFF583ED1000B6146CA7,
	AkSoundEnginePINVOKE_CSharp_GetSourcePlayPosition__SWIG_1_m8B4509848CCC254675A9691E2789FCB2B31D9123,
	AkSoundEnginePINVOKE_CSharp_GetSourceStreamBuffering_m75898A4AA0FD52CA561092AE6CEF333B1EBEEF61,
	AkSoundEnginePINVOKE_CSharp_StopAll__SWIG_0_m65515A14551E4552EDC2DA234A7B967020AE2A64,
	AkSoundEnginePINVOKE_CSharp_StopAll__SWIG_1_m4010AAD2B17165852C71BF7D743ABCD99E4E816B,
	AkSoundEnginePINVOKE_CSharp_StopPlayingID__SWIG_0_m4594A3AFD28819D7368A5A90E78867BFF13065CB,
	AkSoundEnginePINVOKE_CSharp_StopPlayingID__SWIG_1_m7AD719F65E141249CD1E6C18C4C2D73B726CC2CD,
	AkSoundEnginePINVOKE_CSharp_StopPlayingID__SWIG_2_m33053BB2AD5133BE659881C59EB410B7ADDBB190,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnPlayingID__SWIG_0_mD789F38D3913C0D16F9336E28FA50323BA9DCC19,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnPlayingID__SWIG_1_mC61208E6B0CA6697FC628D31D5C092716AC20FBE,
	AkSoundEnginePINVOKE_CSharp_ExecuteActionOnPlayingID__SWIG_2_mD34CCABE09DA1E0AC42CA955C9746F5EB9074A07,
	AkSoundEnginePINVOKE_CSharp_SetRandomSeed_m0C76A4A026B73E7FA01A1F6517CE78343DF465BC,
	AkSoundEnginePINVOKE_CSharp_MuteBackgroundMusic_mBF42F5AD7F16D5B490E3D9943E6E397C61CD49AB,
	AkSoundEnginePINVOKE_CSharp_GetBackgroundMusicMute_m9C119901E915DF798FDECCDD66775D5912B6350E,
	AkSoundEnginePINVOKE_CSharp_SendPluginCustomGameData_mE2EE75A3465D41A468E46B7A0AFFA6F36FA2B936,
	AkSoundEnginePINVOKE_CSharp_UnregisterAllGameObj_m7ECCAB451F34749FFAAAA6AE4B8DD3D24148A6DD,
	AkSoundEnginePINVOKE_CSharp_SetMultiplePositions__SWIG_0_m80EEA40D1339BF2321C8695D73C36F4A3654B829,
	AkSoundEnginePINVOKE_CSharp_SetMultiplePositions__SWIG_1_m216AA880F1E7DCD806C4F96775163B41B6A28681,
	AkSoundEnginePINVOKE_CSharp_SetMultiplePositions__SWIG_2_m6486EF4A8BD7D458D577EAE68B662692495E3389,
	AkSoundEnginePINVOKE_CSharp_SetMultiplePositions__SWIG_3_mEFB04A335B96C9D7AEEAEC7E34B117B84CE6F82C,
	AkSoundEnginePINVOKE_CSharp_SetScalingFactor_m2A0159C50AE0B201CF2A054194888FEA456434B6,
	AkSoundEnginePINVOKE_CSharp_ClearBanks_m941F8C93545A9ADED3AB067B4BC5FF5AE987DD1A,
	AkSoundEnginePINVOKE_CSharp_SetBankLoadIOSettings_m3AAF107C4B146474F3DD114E83E2E115AB3DE8EC,
	AkSoundEnginePINVOKE_CSharp_LoadBank__SWIG_0_mF699A2F2BEEC6B1E372D5F534A513ACA7C641737,
	AkSoundEnginePINVOKE_CSharp_LoadBank__SWIG_2_mEBCB8D1401313CAB5AD208C0BD73783949FAD3B9,
	AkSoundEnginePINVOKE_CSharp_LoadBankMemoryView__SWIG_0_m1ADFBBFC4DBB40D90CCA68FD0C31B7C1725D7AF6,
	AkSoundEnginePINVOKE_CSharp_LoadBankMemoryCopy__SWIG_0_m6FAF64A75E39D241B9F525BE5FEC09AC52ED3B14,
	AkSoundEnginePINVOKE_CSharp_LoadBank__SWIG_3_m803188B80BEE5BD1A399DC6E8D737F00F3973DF5,
	AkSoundEnginePINVOKE_CSharp_LoadBank__SWIG_5_m35A31DA70E7EA028F43C149F1B8F4CE12BD6D29D,
	AkSoundEnginePINVOKE_CSharp_LoadBankMemoryView__SWIG_1_m370433FC10CBE08EAE9CC6EDBD6CAF8DF5FA5040,
	AkSoundEnginePINVOKE_CSharp_LoadBankMemoryCopy__SWIG_1_mAB068DFF02CB0B2B2BC1985051D624B117564150,
	AkSoundEnginePINVOKE_CSharp_UnloadBank__SWIG_0_mB3CBD182D4CB441830BBB468463D4CD87AFED15F,
	AkSoundEnginePINVOKE_CSharp_UnloadBank__SWIG_2_mD1201F99806B946C31EECD6B60DB4F7BA3DB88C0,
	AkSoundEnginePINVOKE_CSharp_UnloadBank__SWIG_3_mD44AFC5C0F2F51940F06E070074622785CE4311B,
	AkSoundEnginePINVOKE_CSharp_UnloadBank__SWIG_5_mC8CBCE9F15E22231FBFF58EA65C1026733FCB9EE,
	AkSoundEnginePINVOKE_CSharp_CancelBankCallbackCookie_m711F8303CCCB66A741BE721AB95B0B9885E2BCD7,
	AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_0_m07EE44E01D30F3E35977D48C76B8033E558B94D0,
	AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_1_mCDF5E73D12C99C499EA88F19C42A55981A55AFDE,
	AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_4_m330E4053347A75DBFD48F579618BC43C61F6F6F3,
	AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_5_m45B64FEC3624136C9108A7D42D3387568BF6CD43,
	AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_6_m009AEDB01EA9DCC95BEAC8D9CC8B6F95E285D740,
	AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_7_mAC5851342E7181301B124FF358FECE05E2DFBC59,
	AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_10_m5262B6F4365497663419109B1BB3E75A4E05BDF1,
	AkSoundEnginePINVOKE_CSharp_PrepareBank__SWIG_11_mCA612E1DD976C75D8C96DE64A258CD8BC6C11259,
	AkSoundEnginePINVOKE_CSharp_ClearPreparedEvents_m468E2C48731E42DFCCEBA31357F82036AF45F49C,
	AkSoundEnginePINVOKE_CSharp_PrepareEvent__SWIG_0_m0E785F24D0EFD6383E74962AAA83495773C8F9D4,
	AkSoundEnginePINVOKE_CSharp_PrepareEvent__SWIG_1_m82A1850E3B8E31BFF2C0C7C6065C7C3AE448031B,
	AkSoundEnginePINVOKE_CSharp_PrepareEvent__SWIG_2_m31AFE7F422FD3C8E826629A69A1F739308CDDBD4,
	AkSoundEnginePINVOKE_CSharp_PrepareEvent__SWIG_3_m161D4701E0F4F4FE0F1FC17008D37E88E6DB859B,
	AkSoundEnginePINVOKE_CSharp_SetMedia_m743B2FD153893E1DC71F3DCF1E36CCCDBFACD182,
	AkSoundEnginePINVOKE_CSharp_UnsetMedia_m3AB05EDDE4ADB56E78039C0EF6F2C2FBFFB3E29E,
	AkSoundEnginePINVOKE_CSharp_PrepareGameSyncs__SWIG_0_mCF9E64BE721959DA1F43C080155FC0DF261EEA03,
	AkSoundEnginePINVOKE_CSharp_PrepareGameSyncs__SWIG_1_m45AE09D50C723B8A922600AEDC6CC086436B646D,
	AkSoundEnginePINVOKE_CSharp_PrepareGameSyncs__SWIG_2_mA1C80FBCEA5F14836C3A3EA2BE1884B48685CA53,
	AkSoundEnginePINVOKE_CSharp_PrepareGameSyncs__SWIG_3_mDFF4A85DADB3909BC7CCB5AE9050F4F9CC01DE59,
	AkSoundEnginePINVOKE_CSharp_AddListener_m0B1DF95C83606BCE7B0DA9F4D1FAB19E407A4EAD,
	AkSoundEnginePINVOKE_CSharp_RemoveListener_m9CD214CD879F6EEE970F971247EC451D4B4F8625,
	AkSoundEnginePINVOKE_CSharp_AddDefaultListener_m091190D2F0F74577CB02FC0669CCC0306FD59059,
	AkSoundEnginePINVOKE_CSharp_RemoveDefaultListener_m4BC5FDE3AA52B33DA83126EF0FAA10731F48C270,
	AkSoundEnginePINVOKE_CSharp_ResetListenersToDefault_m830592B82770552B49CED798AEA8388E14B96A6C,
	AkSoundEnginePINVOKE_CSharp_SetListenerSpatialization__SWIG_0_mED83AE8BF07A5019F0AFB3C87AEC9AEE3BBD6642,
	AkSoundEnginePINVOKE_CSharp_SetListenerSpatialization__SWIG_1_m736945B107FBE36B8F8BB52C1207480DB8FA4820,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_0_mCA26E38B5CCAF872938C20E3A573C17C420D0ACC,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_1_m4C53E317DC503F7B6BFEA69CF4D75F15330BBA88,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_2_m8B8AAD6C4A02099219FA7400E2EF971001F45F0D,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_3_mA4217AC353993A00A64D215A3F41C67F9A5F1659,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_4_mED7B84D6C9152B553724D00E603C1FEACB94A908,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_5_mC45777606C709035028DBE493A7F427A3A23C172,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_6_mD4473DBB16F58E5D592324A798C1F3DB2A0DB82F,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_7_m05A30A70391EC4ABC1AB03ECD0DA95DA5A4046E3,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_8_m98E4C56A6F59D54460D6786F655AD06B6FE0EB08,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValue__SWIG_9_m67B46D3601BEC653A3B2401B0F8795C202D54E92,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_0_m793E1CFC88A85E679BAAFAA335E1FF981C6EB086,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_1_m2AB2ED1F74FCBE14F546C8A1CBA07FBC2B03026A,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_2_mAB60AAB895E2CA4DADA95B26B00D5182C2DABD9B,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_3_m3A087BC1DF81667A748FAE0766A51F576585B469,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_4_mC189F8FB9F7CF101AFB94F40A725C53A9AC12C8C,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_5_m47D8E38489B6CB9A4C11C033F7A3307484C724F4,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_6_m0301F94772263D9AF0920E599C21F932227A8884,
	AkSoundEnginePINVOKE_CSharp_SetRTPCValueByPlayingID__SWIG_7_mBA0F428281D485F3EB48EA24643D2F07512E9622,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_0_mCB8157A19966EDE97EDEF1D95E4D1C2A67083737,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_1_m5136481C732FC6819F817E9B8E831C24855FC326,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_2_mFB4CFCB47716A9A864866172CFE90553DEFED6E6,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_3_m969F44468D15C6CBA981E69743D19C4081E6CCF0,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_4_mB73CBB05E1CA1904769F1FCF8E98A998B8AC0AD9,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_5_m9AB87151CE5A6F698AF83D7A66111B684641B38E,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_6_m6151AD0E3AC59C20021FFE2EB2C74B322623A698,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_7_mA67C97FD5AA37C14E5785D8337D3FF8B88BE02E8,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_8_mC7816070649E74D36843289E7C6E12B086042561,
	AkSoundEnginePINVOKE_CSharp_ResetRTPCValue__SWIG_9_m9047E91A72E2CBAFFC696FA85D15C2E23C7F8B60,
	AkSoundEnginePINVOKE_CSharp_SetSwitch__SWIG_0_m0E1CC7DC62B7052692A726AF82CE0214B0191D34,
	AkSoundEnginePINVOKE_CSharp_SetSwitch__SWIG_1_m78ACB665638657B73F1068C67C09E2BC9B9B1B7E,
	AkSoundEnginePINVOKE_CSharp_PostTrigger__SWIG_0_mC510D2FA09DFAE69805CAF285A42140715E0BDE4,
	AkSoundEnginePINVOKE_CSharp_PostTrigger__SWIG_1_m517AAEBD77E21D4B05E30A013C4DA63C712FD1A1,
	AkSoundEnginePINVOKE_CSharp_SetState__SWIG_0_mBE4E03857B9F7121568449A48FA1610197CE73AB,
	AkSoundEnginePINVOKE_CSharp_SetState__SWIG_1_m8E69277B297538E9CF9A6085A1B132A4D29ADB0C,
	AkSoundEnginePINVOKE_CSharp_SetGameObjectAuxSendValues_mEC889A005505A3A40204C99CE602EB1FA4B0BA15,
	AkSoundEnginePINVOKE_CSharp_SetGameObjectOutputBusVolume_m5728B90FD48A873540A7A2DD1E411AE70F8AFC37,
	AkSoundEnginePINVOKE_CSharp_SetActorMixerEffect_mE6754EA0734463CB1C03A8AD743CB11E0777FDE7,
	AkSoundEnginePINVOKE_CSharp_SetBusEffect__SWIG_0_m55783EB360065E68147E20B7E7045C5B0CD4D787,
	AkSoundEnginePINVOKE_CSharp_SetBusEffect__SWIG_1_mFC8AEDEF6A5B7E88F40FBD26A7324C19C7B92FCE,
	AkSoundEnginePINVOKE_CSharp_SetOutputDeviceEffect_m5D40B5CE451FE4BACD4C04260910B0C3A6812412,
	AkSoundEnginePINVOKE_CSharp_SetMixer__SWIG_0_mACE44FDA22CE6DD69A0D8D5E6BB560D37EE34A7A,
	AkSoundEnginePINVOKE_CSharp_SetMixer__SWIG_1_mBD8124BDC416C06F98990A436A3BBAF5A652C71D,
	AkSoundEnginePINVOKE_CSharp_SetBusConfig__SWIG_0_m2F2C6D45B2BC28A9B8B61F25D23E38F88B611AFF,
	AkSoundEnginePINVOKE_CSharp_SetBusConfig__SWIG_1_m884EC6B814EF0F4A6D6E97B612C500F61B0BA059,
	AkSoundEnginePINVOKE_CSharp_SetObjectObstructionAndOcclusion_mA1811677DB0F992103B008EE04930D2CCD0CB840,
	AkSoundEnginePINVOKE_CSharp_SetMultipleObstructionAndOcclusion_m495D2231D3F1E06EF3579F2CF9D079C057F35286,
	AkSoundEnginePINVOKE_CSharp_StartOutputCapture_m1F0D0CE3DA938D1E7B2B4E9DFDCE7B69B3052A29,
	AkSoundEnginePINVOKE_CSharp_StopOutputCapture_mA2453F05A9DF771B2FA70C028FF2AE29C219D699,
	AkSoundEnginePINVOKE_CSharp_AddOutputCaptureMarker_m3D1DE8E2AA6B2906F7470631A0F26744959EDCA9,
	AkSoundEnginePINVOKE_CSharp_StartProfilerCapture_m99469F4FFB91CDBB5FB491592CC80A5D94A7423E,
	AkSoundEnginePINVOKE_CSharp_StopProfilerCapture_mA8506159EEC48F2D11D08537186D62519C433B49,
	AkSoundEnginePINVOKE_CSharp_RemoveOutput_mC13CD69859211808857E7F8FBB7A3C72839B137C,
	AkSoundEnginePINVOKE_CSharp_ReplaceOutput__SWIG_0_m5AF5F54F0A1CC2854267C31F9169F3F53664AA8F,
	AkSoundEnginePINVOKE_CSharp_ReplaceOutput__SWIG_1_mA97026DBD2AA7910C042BC786E1E22E4D497FA28,
	AkSoundEnginePINVOKE_CSharp_GetOutputID__SWIG_0_m693858935F0F5D19013A0FFB3FB2980FD6891FB5,
	AkSoundEnginePINVOKE_CSharp_GetOutputID__SWIG_1_m1F12261D38850E4CEB8D685F7F24FC63301B01AF,
	AkSoundEnginePINVOKE_CSharp_SetBusDevice__SWIG_0_m0D3CF561A0A2B362C19F087AE88750B760066413,
	AkSoundEnginePINVOKE_CSharp_SetBusDevice__SWIG_1_m68B8B224F8E93C2C254FA85A9782F6E0833FBA4F,
	AkSoundEnginePINVOKE_CSharp_GetDeviceList__SWIG_0_m876C9E2BFB9F46438DB49FC10E0F992D186BB73E,
	AkSoundEnginePINVOKE_CSharp_GetDeviceList__SWIG_1_mCCEAA8C4FD303EE4A2C666A61449B154FD3D2367,
	AkSoundEnginePINVOKE_CSharp_SetOutputVolume_m691C483D7E67EAA2C83EE465A67D0DD7602ED99F,
	AkSoundEnginePINVOKE_CSharp_GetDeviceSpatialAudioSupport_m85551E23267CABA5470122AEBB6E07E9096CAB2F,
	AkSoundEnginePINVOKE_CSharp_Suspend__SWIG_0_m7422AD9A5816131106FC64C8B86E907687F67F8B,
	AkSoundEnginePINVOKE_CSharp_Suspend__SWIG_1_m4406E7E60DC44C6449A916AD8A9B7CED4F1447D1,
	AkSoundEnginePINVOKE_CSharp_WakeupFromSuspend_m6B3640C66BB2F3853B344A56E4F01978BE8FE85B,
	AkSoundEnginePINVOKE_CSharp_GetBufferTick_m19A08B04A6FF8960BC47ABBB34E6090D8D75919F,
	AkSoundEnginePINVOKE_CSharp_GetSampleTick_m9D210EA755FEE492C84E5DE91E88FA38A5E586B9,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iCurrentPosition_set_m91EC79422DAA75EEB58273415CD609794FF9FB1A,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iCurrentPosition_get_mA3615745E3648831E758FF163063721CF7F7F0E4,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iPreEntryDuration_set_m43880323389E13D3BC5B02780664818481E99FC2,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iPreEntryDuration_get_mF73A06B43E5C0C1AB4579A5F6A42676070BCEF32,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iActiveDuration_set_m06606E1AC250119C2D59D4C7F98F05CDFED7E7C8,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iActiveDuration_get_m21A01114BC0C5699A3453BF8F99F7B28CA0DE469,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iPostExitDuration_set_m6C4A608E715D6EA285C22FF03F909FBAA2641DD0,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iPostExitDuration_get_mE51B30DB05AA7BD09A019FE99028EE89D56853DD,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iRemainingLookAheadTime_set_mD9D79EF5B030BDD1BE770DB7E1C2614F2AA485C6,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_iRemainingLookAheadTime_get_m2D1622D621B6516EF041781ECC606B30CCB10204,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fBeatDuration_set_m45B10AF51387D20ED92E11649D74A20C3A83790D,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fBeatDuration_get_m59547A975519C59A3D69830894F2553E752DD416,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fBarDuration_set_mE878EF699979116995B28EAC215CF363A934F389,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fBarDuration_get_m7A5A39D1584047F19E003391ADFCE6ADF106D28B,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fGridDuration_set_mC814B96D66820A7FDC23A1134FA7FFA3F22564C2,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fGridDuration_get_m31C9806D774E4E8FDB8ACA67185C1D458EB5A789,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fGridOffset_set_mF3BC012D0378D8F344019E7BDD116AB5FD6486E4,
	AkSoundEnginePINVOKE_CSharp_AkSegmentInfo_fGridOffset_get_mAAE830A2461B17247A61FAC5FD3D9BE68634CC61,
	AkSoundEnginePINVOKE_CSharp_new_AkSegmentInfo_m0C848C2A9CE299BC51D69FC4BE90DE3E31AA24D6,
	AkSoundEnginePINVOKE_CSharp_delete_AkSegmentInfo_mC0CBA51E55253B13C961EF8A208B07B8C741C874,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_totalCPU_set_mC43D385F2E2C1B12E482A665861C4B3F763ED149,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_totalCPU_get_mA5DC173B395F78440AD2AC3FD2560DB426219FCE,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_pluginCPU_set_m68AE5DA99C19957F261696F22FD835226AC3E4F1,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_pluginCPU_get_mBB0514BEEED26FC530EFF6E440E90D87D40B3892,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_physicalVoices_set_m66DD236A09142AD0E1D4D3B3F5D244F8AC2F60B9,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_physicalVoices_get_m13B5E33AF10B5847AF7551F4D77EBFB85340F358,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_virtualVoices_set_m68AD3838CACAE5BB424AB0D84D2B8A96D1D5611B,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_virtualVoices_get_m518C7F8AAD0A477DAC210B784B0B97A083B83AF6,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_totalVoices_set_m965E644EB394A6EFF8F4636E668F2178A17072E9,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_totalVoices_get_mA344E06316495A1CFC94CF8420022CFC0200BB17,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_nbActiveEvents_set_m7EA21625A923644376366285E834F5263BC5609D,
	AkSoundEnginePINVOKE_CSharp_AkResourceMonitorDataSummary_nbActiveEvents_get_m8357FD374E2A70820B85E69EA65BE233E67949E9,
	AkSoundEnginePINVOKE_CSharp_new_AkResourceMonitorDataSummary_mB0C66803B7F479D165868ADBCDC960D41BC70ED2,
	AkSoundEnginePINVOKE_CSharp_delete_AkResourceMonitorDataSummary_m348B99839A6A3376D25F563A04B97EE6CD4EEA54,
	AkSoundEnginePINVOKE_CSharp_AK_INVALID_MIDI_CHANNEL_get_mFD8C9666736FA229D5B56EF26B55C31E06DBEE77,
	AkSoundEnginePINVOKE_CSharp_AK_INVALID_MIDI_NOTE_get_m7B3F076D25285A2D00E5A0BC966BA3AFD70D2DC2,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byChan_set_m6431CAABA5ABBA862956BB98CC39D285967A2BB2,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byChan_get_m4FD141256C1BFA8D87D26461B5355030DE50A998,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tGen_byParam1_set_m47F4567CA94B010A9269A5FB70726549F4FCA59D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tGen_byParam1_get_m8659E3C1C2DA104F42A58CF49533B45E6E96D1C0,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tGen_byParam2_set_m2265096B5BBA8B7F70FCFE86D86450200B835F87,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tGen_byParam2_get_mF3E5584D8FB5985194975FC27AA4CF88ACD2B31D,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tGen_m582F6C3E67C5F0581A47C2A97755CF3F23178979,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tGen_m15AED6AD4B80BC9F9D66F1CB51152F25E92A466A,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteOnOff_byNote_set_mA7BBD46FE4D48ACA43C61B38970BA3295D96B3E2,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteOnOff_byNote_get_mE690DA0AF6FFF644EC966BC22D15008AB44F8975,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteOnOff_byVelocity_set_m9F1FF3BB31A45794BEC8968FD427F330F50C522D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteOnOff_byVelocity_get_m419CDF6E0D0DD4ADD93AF281DE25B085ECF9039D,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tNoteOnOff_m0F4E36C96AC372EB190A8477B435274BE7C82FD0,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tNoteOnOff_m1EF89B6645975841187EA8E9728DB31E5D618013,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tCc_byCc_set_m1B09E54D7B20E9ABD06EA02172C14B5D2E6C8A23,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tCc_byCc_get_m03F37E963FCFD948CA52CDD733349BEE3C010019,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tCc_byValue_set_mFA63082C54C98FB672823DBB5986603A8255707D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tCc_byValue_get_m9C69AD35C43074D10E18ECCC435C479A94C1AABB,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tCc_m49D994BC6571774A7A8980CC001579C11E2E75F6,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tCc_mD7D67567FC05CCECF214813A27D1E96D3EA7AA0B,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tPitchBend_byValueLsb_set_m82CFD0C22451B72B571669814F6F2C7D6DC74060,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tPitchBend_byValueLsb_get_m78C193510A40F97B4A8C50DB57721F19BBE6AFB3,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tPitchBend_byValueMsb_set_m7FA65CEC8589E924AE3CB25050DCC4BA9CD55C77,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tPitchBend_byValueMsb_get_m178DC1943AD786F920FD88A5553667B331EC960D,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tPitchBend_m902C47759F2FF8FE6BE77C3D539774C65B469A25,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tPitchBend_m63B1A2FA42938D97C12FBD3C38D12B36A95273A8,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteAftertouch_byNote_set_m69246B3F0D294E1CA22A6325415F8574C0BCA0D9,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteAftertouch_byNote_get_mA7F0D69E7860864E088A9F5FF992466506CFAB3A,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteAftertouch_byValue_set_m9D5ED60C6BF8E02D53E176D8514B2754D2E0E8B0,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tNoteAftertouch_byValue_get_m0BBBB9B4CA78742811F3634196C8C7B4F176C780,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tNoteAftertouch_m6472F96D0B16B72817F1A623BCDE7A4720AC2E14,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tNoteAftertouch_mAA422A986C29C88201035E6A6A89A6BEE1937C83,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tChanAftertouch_byValue_set_m10AF6188C42D02E245C82AD60B9FDDDAFB789334,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tChanAftertouch_byValue_get_mFBAC29B98A53DB5447D2620A273344424053FFF7,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tChanAftertouch_m33DF9C7B2541A25124CBEDB4CB7756E0D55E6249,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tChanAftertouch_m06EC370679B2A8B892A1A84C33095C5BDDA568D3,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tProgramChange_byProgramNum_set_mB83831FE1D830053A94D411B71C72BB7B5AC945D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tProgramChange_byProgramNum_get_mEC42D04326BA71579513DB201B67C76230C950E9,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tProgramChange_m451C55B8F2A3AAA6CAB371CFE44D4A001CD90A94,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tProgramChange_m90538AC4BF3B99FA29126E813992A8F7EADE2178,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tWwiseCmd_uCmd_set_mFF3A1884425FADBAB24CF01D8BEE2A9F4F6C9671,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tWwiseCmd_uCmd_get_m66840325018DE4974F9BF152477F606F43217C9D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tWwiseCmd_uArg_set_mF6004511726005CB7CB98DF2836C1503084662D8,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_tWwiseCmd_uArg_get_mBC513EF3C73EA51048047727F1A3403357E42000,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_tWwiseCmd_m2F21C14D49C5E1F1A633D90822B3317758E2AB9B,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_tWwiseCmd_m2CA58B051232CEA59BB9EEDEE4A50F1C9F645691,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_Gen_set_mCEC79C3F4E75EBF431F2C3674BBF9B0E912C5439,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_Gen_get_m8D9DD8F099CFFA8E287AF1413B35BA93DDB9A01B,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_Cc_set_mDD677681AE881E653A059A055B301BAB8C22C12D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_Cc_get_m01BF34BB5C27FF37DD39A88CAA615896EF070C41,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_NoteOnOff_set_mF1D1F7970DBE695231B1EB26A97EAB170EBA0E4E,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_NoteOnOff_get_mF3196BEEFB684E3D24CFF270845DD00025685017,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_PitchBend_set_m0DEEF071A0F21160924B73C5E51639ED1CD00615,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_PitchBend_get_m57D7085B81ED5A0AD3CD911DD55DBA8C82BF559D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_NoteAftertouch_set_m1FCAE5C24830465B27572DC562A4EA9386786E93,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_NoteAftertouch_get_m7AC179320954A3676B77CD1D03019E5A99A7DE21,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_ChanAftertouch_set_m0F69BA87D4E8D9F49D305E5B7D749F785BD6CE9D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_ChanAftertouch_get_mD1737283650474043A72A89EC4AB6AE77675DC25,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_ProgramChange_set_m0FCEA9D529D0C64BAF399250D52E71AE678BABD2,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_ProgramChange_get_m44E9A772298C51D1496918AF4EC3F075DD9BBDF1,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_WwiseCmd_set_m1D3F2E42E8CE923E8BAD2756968371B4B9AB78AA,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_WwiseCmd_get_m85B16070C6E2471639ED78447A350B6B9B6F2FFC,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byType_set_mEDDA6920CDA1FBC041C4A93F8CCDF995BB02E404,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byType_get_m3E8EFB8C01D9630A90FA6CBE1CA634BF09091DCC,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byOnOffNote_set_mF3D08D0DA53B38DDE9C48619D5D093BE86E88172,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byOnOffNote_get_m6433C26CFF47306E86130E740AD5DB40728BB6D0,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byVelocity_set_m948304DE8B91983B5023B24AB02A4C0F678BE72E,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byVelocity_get_m541CB2AF5B8F6D4D13639D21A1F466650B1691AB,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byCc_set_m1AD433EB10685B653D86160507D5E85FE6F569B1,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byCc_get_m6A4E1EB8C9440714BCC70BAA1AC2AEA579CE8F27,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byCcValue_set_m37C806A7DF7587745A644E2698858D84B5C9C878,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byCcValue_get_mA32C01BC72188C9DB2D4518B21F288B39185CA0D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byValueLsb_set_m9366A625D1E3B9455C981218F61C2FF92AA10B0D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byValueLsb_get_m9677D1863287C46074B48EF3E93E14CAF53AB149,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byValueMsb_set_mA6BC86D32F44D7C334B373B76CD18FFC1BF9B46C,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byValueMsb_get_m4C83A574E48D6383640DE61D01E892D7FDF2B181,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byAftertouchNote_set_m68557BC8443AB8BD6A2360AFE158660CB0F030BB,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byAftertouchNote_get_m5F89D34E0ACC5C177B651AA229A2F254BC290050,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byNoteAftertouchValue_set_m143B25861B1E02E528DAE2CF65F80AF287FD2D3C,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byNoteAftertouchValue_get_m3B050D127F9F7216FD912A7C8EC41E83B2E27305,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byChanAftertouchValue_set_m10CE2586B9D1B05B859696FAD1A220DB1F34E29C,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byChanAftertouchValue_get_m0F64C65DAA26A195F1A57B76C2BED9E3D8AEA46B,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byProgramNum_set_m96909F65B2BA318E2264CE241876DBE30AF3D380,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_byProgramNum_get_m36812EB66FE9A22EC771E45DA72FBDB10B623D6D,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_uCmd_set_m65392895A0F099C233FAC0CCEB19B20EF0C60D86,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_uCmd_get_mF260F11EC6FD426DE3086863A6D690E8C8630131,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_uArg_set_m19B5FC52F51B913FDAC7DAB33FB9D23F54D948DD,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEvent_uArg_get_mB7BC4DE252B163CCB6291B1136F5D3358E2A9532,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEvent_mC2F185382A955CF5369F31D4622316B1815F6AC2,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEvent_m1858A364C8352566E9643F97D3415B14D0B8D863,
	AkSoundEnginePINVOKE_CSharp_AkMIDIPost_uOffset_set_m0723579E2B93C6F72E174F5BD3D2269DE32BBBA7,
	AkSoundEnginePINVOKE_CSharp_AkMIDIPost_uOffset_get_m73BA68B3C26E879B976102B897483FC7FCF3CBC7,
	AkSoundEnginePINVOKE_CSharp_AkMIDIPost_PostOnEvent__SWIG_0_m1ACE59A0E96643B42D4837B954301450FF9FBBAC,
	AkSoundEnginePINVOKE_CSharp_AkMIDIPost_PostOnEvent__SWIG_1_m4010BF50F475C7FDF85F61E599EBEDC0585C3508,
	AkSoundEnginePINVOKE_CSharp_AkMIDIPost_PostOnEvent__SWIG_2_m51674819985E07DC467EAB8D83D60BA96A28CCC2,
	AkSoundEnginePINVOKE_CSharp_AkMIDIPost_PostOnEvent__SWIG_3_m3626C5B8FB1CBEF8D7627B0DBBB653227288D326,
	AkSoundEnginePINVOKE_CSharp_AkMIDIPost_Clone_m9480C58648CFD3D5F938C4A1EEFF030FF9A09440,
	AkSoundEnginePINVOKE_CSharp_AkMIDIPost_GetSizeOf_m518125F299A4142138D0804BC40D1BFD341A8CC6,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIPost_m1A487ED08A07DF01A4A81A71C7E6671CF7F781D2,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIPost_m2503E03269714B57527CEE4964FCD02BA1D78A06,
	AkSoundEnginePINVOKE_CSharp_AkMusicSettings_fStreamingLookAheadRatio_set_mBB62C196B0C2BC1FC415E855A63987FC1697037B,
	AkSoundEnginePINVOKE_CSharp_AkMusicSettings_fStreamingLookAheadRatio_get_m4583D4B60A06752AA12149757DBA19A65B446690,
	AkSoundEnginePINVOKE_CSharp_delete_AkMusicSettings_m5ED43223C2F35C105C0D7763B4C1052D0B4B0956,
	AkSoundEnginePINVOKE_CSharp_GetPlayingSegmentInfo__SWIG_0_m2A86888844D2FAAFE9C30E46B212638921104EEB,
	AkSoundEnginePINVOKE_CSharp_GetPlayingSegmentInfo__SWIG_1_m40DA1669D120EC95F0719FDCF5937ABB187A4E69,
	AkSoundEnginePINVOKE_CSharp_AkSerializedCallbackHeader_pPackage_get_m8E22B84CA3448326ED5177C8AE6857B70822E04F,
	AkSoundEnginePINVOKE_CSharp_AkSerializedCallbackHeader_eType_get_m620C0266DD937168D65509A16687BAD619B0B8E1,
	AkSoundEnginePINVOKE_CSharp_AkSerializedCallbackHeader_GetData_m83ED01869F6A73E32C43E70E4A0586B8CE4FD0D3,
	AkSoundEnginePINVOKE_CSharp_AkSerializedCallbackHeader_pNext_get_m9DEA157B79CA1F0C31593EE493AA44A1B4BD227B,
	AkSoundEnginePINVOKE_CSharp_new_AkSerializedCallbackHeader_m0A89EDA2DDB1CBF73497A1B43D65F8D78E632896,
	AkSoundEnginePINVOKE_CSharp_delete_AkSerializedCallbackHeader_m7F5F076CF97CBCCEEAF9E3BBEB8532347402D700,
	AkSoundEnginePINVOKE_CSharp_AkCallbackInfo_pCookie_get_mE5B4C90A8EBDF8C86798375D5C6B06EDE535F4CD,
	AkSoundEnginePINVOKE_CSharp_AkCallbackInfo_gameObjID_get_m3A8FF45DF937C8330B47C414F54AB9355D894389,
	AkSoundEnginePINVOKE_CSharp_new_AkCallbackInfo_mBDBA2F087B4730A6D52921E889EFBB2859F4E0D0,
	AkSoundEnginePINVOKE_CSharp_delete_AkCallbackInfo_mADD00F6FDAB1C5E6DA882DF3FA711C4948D90900,
	AkSoundEnginePINVOKE_CSharp_AkEventCallbackInfo_playingID_get_m28D2BDB39E211AE53C550CC0F96573B8057469B7,
	AkSoundEnginePINVOKE_CSharp_AkEventCallbackInfo_eventID_get_mE6F3D5912FDA0D85F11C9B368A5E762A3587F7BC,
	AkSoundEnginePINVOKE_CSharp_new_AkEventCallbackInfo_m93101C636CC55E54C896B93B3E03FAF40FE0F44E,
	AkSoundEnginePINVOKE_CSharp_delete_AkEventCallbackInfo_m343BB5A52A24501601C2836735504AAF24121344,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byChan_get_m1B4F1E3E3C232D8392CE49FA44C390D96E2F7B9B,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byParam1_get_m49794E96381C0BD30188441E3698BA80292965B0,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byParam2_get_m3DEC2B34C898FF6CCFF9A8548368B87C1A7621ED,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byType_get_mC4E4786F5ECA5CAC5101D3578BF752C2710E4E2C,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byOnOffNote_get_mEA2D3D2345599EB82C8031517938FB94AD5B99B7,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byVelocity_get_mA48C28793C291CAFFE2138BE36D8A87E15DA466F,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byCc_get_m2449EDC29D9C1907DC727E99600D0C5B542B5FBA,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byCcValue_get_mF939CD88F9DEA798829C568169B6F42FCAEC3FB0,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byValueLsb_get_m850F669976BB94A57B74B3AE13DD700C175B80CB,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byValueMsb_get_mDEB35FF64290467AFA8C508B3371A3863C7F5AD8,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byAftertouchNote_get_m487BCFCF1C2557530E05A4363ED7DB49E427C7F6,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byNoteAftertouchValue_get_m9B536B90442964D1D3DF308331FBF9AB5457AFD4,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byChanAftertouchValue_get_m6A406037AB7F5F850FA6B4BBE6BE7307BD9D4445,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_byProgramNum_get_mE33CDABE0DFA06DB7EF176747B7C68366139464B,
	AkSoundEnginePINVOKE_CSharp_new_AkMIDIEventCallbackInfo_mA6251508C2A0156D68D67BFB8E721DC7E743B200,
	AkSoundEnginePINVOKE_CSharp_delete_AkMIDIEventCallbackInfo_mCD8067CEA09D26AD46721A950A27958548CD322C,
	AkSoundEnginePINVOKE_CSharp_AkMarkerCallbackInfo_uIdentifier_get_mE8780FC2569C21F665F6475A84CDC3D8B3812837,
	AkSoundEnginePINVOKE_CSharp_AkMarkerCallbackInfo_uPosition_get_m1220D946B34E316CCF6DFF0329DEC39B7A115F8F,
	AkSoundEnginePINVOKE_CSharp_AkMarkerCallbackInfo_strLabel_get_m274CBA5B395BAE11273B33AFDCB7BA31D4E80A18,
	AkSoundEnginePINVOKE_CSharp_new_AkMarkerCallbackInfo_mC00EAB3A981456C8D2E0439E7DFC9CE52C8D5428,
	AkSoundEnginePINVOKE_CSharp_delete_AkMarkerCallbackInfo_mA94DE78D6EB1B5BA391A9C5E30FAE195E8A0CA53,
	AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_fDuration_get_m909B5C5AB572FED5AE6A2BB70816BAA6D8FAB0C4,
	AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_fEstimatedDuration_get_m8A2A54D9352C0BB44FBB59FC63AF5262D73141D8,
	AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_audioNodeID_get_m19C744140B2DB36428DCE784A2F907252320145B,
	AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_mediaID_get_m62A1FA8B61BE10A9E9DDC87A5934381AEEF5CF46,
	AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_bStreaming_get_m5F85E2F04634C2FBD7AA0F8B020DA093872051B9,
	AkSoundEnginePINVOKE_CSharp_new_AkDurationCallbackInfo_m358AB36682F59E5D5B7E035F3D9DB0A65311EA57,
	AkSoundEnginePINVOKE_CSharp_delete_AkDurationCallbackInfo_m7B262D4B4C2B95F1D9EC39DA4D5140FD816B629C,
	AkSoundEnginePINVOKE_CSharp_AkDynamicSequenceItemCallbackInfo_playingID_get_mFE0E5215666B10B00F3B161CB88F44EF4E49D716,
	AkSoundEnginePINVOKE_CSharp_AkDynamicSequenceItemCallbackInfo_audioNodeID_get_mA5AAFA924A84B4E67AB067EDB3A0818FD9FAEAC1,
	AkSoundEnginePINVOKE_CSharp_AkDynamicSequenceItemCallbackInfo_pCustomInfo_get_m5ED0203AA237741EBA28FE6A56413834202D3239,
	AkSoundEnginePINVOKE_CSharp_new_AkDynamicSequenceItemCallbackInfo_m80F372F0C3B9E239C6DC4326DC1210B68A8C4F48,
	AkSoundEnginePINVOKE_CSharp_delete_AkDynamicSequenceItemCallbackInfo_m3657EA8A6767DED2F192EE4829B0308DF1E6CE85,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_playingID_get_mA1FFF69F537254346C36EE6F8D49B19AEFDD971F,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iCurrentPosition_get_mC64DD077AEABF720B2E8BA96DB37B01B2E7FF20C,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iPreEntryDuration_get_mEE180386BC44FA394460758DA412D35D7B8CAF2E,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iActiveDuration_get_m26CF6D15A833EB9CC019D7CCD71356849EF63C0B,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iPostExitDuration_get_m6C52FE36C7BF37A451D1E3E678E6CC2722DE3B2C,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_iRemainingLookAheadTime_get_m2474CF688AA1B77F63650833CD91068A62680549,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_fBeatDuration_get_mB2D45332D2D6FB0B82D18B75261A482E667D6A55,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_fBarDuration_get_m02799AE5DE6587D9F1351727183551A1757257B0,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_fGridDuration_get_m13B8A7C8BAF0F26B8106B70208E761AE19131F5D,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_segmentInfo_fGridOffset_get_m86439010DFE7D9C1F0DFC95E4C07A053970B469D,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_musicSyncType_get_m61C460BE9A149C9692F97F1AB00C310E24B113F2,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_userCueName_get_mE5C6222341B4DF855A4D93E88DE63F6EBDAE6330,
	AkSoundEnginePINVOKE_CSharp_new_AkMusicSyncCallbackInfo_mFA75035E67106EF6C071657B763FEDBA6E6C5F08,
	AkSoundEnginePINVOKE_CSharp_delete_AkMusicSyncCallbackInfo_mAFB4F335BABEB3BE2C36C28353778192A73F9B32,
	AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_playlistID_get_m261930B60258C47E9428ADD099F9201AE7FC32DD,
	AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_uNumPlaylistItems_get_mA951B4E7B39E42E0FE684794F4EE000A0BE4CB92,
	AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_uPlaylistSelection_get_m0028098A0F5EEE65AA1EB2566BD7225B51D083E4,
	AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_uPlaylistItemDone_get_m35B9A7EDDBD88090E23F8738E7F4FFB0412548AD,
	AkSoundEnginePINVOKE_CSharp_new_AkMusicPlaylistCallbackInfo_m807EC56CEA99A66444DD4FB03280970931EC46EA,
	AkSoundEnginePINVOKE_CSharp_delete_AkMusicPlaylistCallbackInfo_mD05D6EEBDF8FCCCFDE76F0882D04F773F9BD45BE,
	AkSoundEnginePINVOKE_CSharp_AkBankCallbackInfo_bankID_get_mEF83E1CD9EB7FFB15C408C1F6D0CBB5436E267FE,
	AkSoundEnginePINVOKE_CSharp_AkBankCallbackInfo_inMemoryBankPtr_get_m9BE6C1B1A53B41551C30D3EC7A8AC3132F063E6F,
	AkSoundEnginePINVOKE_CSharp_AkBankCallbackInfo_loadResult_get_m3CC4D8E1E5D96B77252F6687F327D6A98CDD20D1,
	AkSoundEnginePINVOKE_CSharp_new_AkBankCallbackInfo_mE1C8B8D58CBF03195341E3B6276239DE84B82075,
	AkSoundEnginePINVOKE_CSharp_delete_AkBankCallbackInfo_mE83EAFE086D2F7315FC4D1275FD9B0966EB4A8DF,
	AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_errorCode_get_mFBBB32FEAB860BCA204D52FE8EC49055CA6FAFAD,
	AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_errorLevel_get_m626F75148B1D775C2AF700C99C3744D7343DAAD1,
	AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_playingID_get_mC31E6B3351E3D8279DC37E82E57329DF50F28B7E,
	AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_gameObjID_get_mBAF8F793BF95AC2377845B798FBBC741990294E6,
	AkSoundEnginePINVOKE_CSharp_AkMonitoringCallbackInfo_message_get_mF0BBD79DFA6C55B2DF55ABB293A93A97F3AEDACF,
	AkSoundEnginePINVOKE_CSharp_new_AkMonitoringCallbackInfo_mD06AEF1B39B7A5DF169D27E1BBD031FC546F1A8F,
	AkSoundEnginePINVOKE_CSharp_delete_AkMonitoringCallbackInfo_mA3C67C5AF90D4D352020BE44EDC8DA7C96F6CD0E,
	AkSoundEnginePINVOKE_CSharp_AkAudioInterruptionCallbackInfo_bEnterInterruption_get_mED181F6D5CD1B7609DBB745AE66272102E10E944,
	AkSoundEnginePINVOKE_CSharp_new_AkAudioInterruptionCallbackInfo_m1BE8C795C3E251D1FCD0F5683CCB2AFEDF179462,
	AkSoundEnginePINVOKE_CSharp_delete_AkAudioInterruptionCallbackInfo_m9B94C77D151AD71C0B08CB06582C6C6A8892F7D7,
	AkSoundEnginePINVOKE_CSharp_AkAudioSourceChangeCallbackInfo_bOtherAudioPlaying_get_m93AE2DBD1EC1C0083278ECBBB64AA3140C0A3BEB,
	AkSoundEnginePINVOKE_CSharp_new_AkAudioSourceChangeCallbackInfo_m4EAD31B5216E49FED68F19560D22F1FD044B7F07,
	AkSoundEnginePINVOKE_CSharp_delete_AkAudioSourceChangeCallbackInfo_m5D2C530EA08F331F7E36EBF0D8F0FE5533920851,
	AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_Init_m3C7B6B87ED929AA6DB3D3B8D9D6C31B19E3A2BFF,
	AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_Term_mF0171698CFE3CCF040E9AD3FDA61337EC5B4205F,
	AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_Lock_mF2341C3D62E6AC230E1F44D3AE71BBE2E9FD3A2E,
	AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_Unlock_mDC1339010C4F254C3E3585AB418FFD270FD95D2A,
	AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_SetLocalOutput_mB66048FFB5A6264CC8E78D941225FD24508F485B,
	AkSoundEnginePINVOKE_CSharp_AkCallbackSerializer_AudioSourceChangeCallbackFunc_m3A446B8FA6B77DFCC8222245E757322BBF077C4A,
	AkSoundEnginePINVOKE_CSharp_new_AkCallbackSerializer_mF84DB82CD6089C13DC9BB0EEE24C04C4E5C839E6,
	AkSoundEnginePINVOKE_CSharp_delete_AkCallbackSerializer_m278D8285E95264CA99FA36DDC28ADE10F3F786C2,
	AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_0_mC5E43ED1A61911C6BBB3205E784E615663DB3D80,
	AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_1_mD5202D476E3E7F9FF79F5AA3A5DDCF44FE98656F,
	AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_2_m84CBFCC1E5D6EE6B9AB8B2DD56EC29EF10D1B33B,
	AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_3_m927FF6AB9054B22B2852848CA383D8ED594DD05D,
	AkSoundEnginePINVOKE_CSharp_PostCode__SWIG_4_mC9B2F3F42C12CE06FC34C1ADA3D4A653690072F0,
	AkSoundEnginePINVOKE_CSharp_PostString__SWIG_0_m1479489703B2B1349A2CE97F8183A9E7FC643BC2,
	AkSoundEnginePINVOKE_CSharp_PostString__SWIG_1_mF366464D4D6A8C6D119E983E7E60D59D38CBA8B4,
	AkSoundEnginePINVOKE_CSharp_PostString__SWIG_2_m8C249D7651153DBBBC08BE8D3AD2F6FB09D3D2B9,
	AkSoundEnginePINVOKE_CSharp_PostString__SWIG_3_mF1C867EDDDECD637BE0A8037924692D5612B717F,
	AkSoundEnginePINVOKE_CSharp_PostString__SWIG_4_mCCE2A2562D4C285D93CCA3F9A8C13671A4EA6495,
	AkSoundEnginePINVOKE_CSharp_GetTimeStamp_m772FC717D04686CA270F3407EB98767E28806B5E,
	AkSoundEnginePINVOKE_CSharp_MonitorStreamMgrInit_m68317B41FB009CE07EBFC93B26C0F311CB84CCC5,
	AkSoundEnginePINVOKE_CSharp_MonitorStreamingDeviceInit_mF2BB3CB07C1E923D8C83C6CDE79A4451DB0DF037,
	AkSoundEnginePINVOKE_CSharp_MonitorStreamingDeviceDestroyed_m4FE8A1C8031D38CAA7F371089C5C0DEDEA2708D5,
	AkSoundEnginePINVOKE_CSharp_MonitorStreamMgrTerm_mBA5A54551A13D642222ADEDD37407AF58352432C,
	AkSoundEnginePINVOKE_CSharp_GetNumNonZeroBits_mB7FC6CFE390FC5E4ED9DEB9C2194538E400A241F,
	AkSoundEnginePINVOKE_CSharp_GetNextPowerOfTwo_m79662C048F357EB815C5BDEDBF76083F02223E4F,
	AkSoundEnginePINVOKE_CSharp_ROTL32_mBBC4670095BE5F0B9F4C275AC3FD9F7E1B2A587B,
	AkSoundEnginePINVOKE_CSharp_ROTL64_m490201DE6AA2EEC6EBD6575002C7FF661B2E1FCB,
	AkSoundEnginePINVOKE_CSharp_AkGetDefaultHighPriorityThreadProperties_m9E72CD34732D54FCF66C5636849419F05C482DC6,
	AkSoundEnginePINVOKE_CSharp_ResolveDialogueEvent__SWIG_0_mB108B761502D4357459C80FF4ECBB181B7E80989,
	AkSoundEnginePINVOKE_CSharp_ResolveDialogueEvent__SWIG_1_mC675A5C349E47353CEDE89FA2D837A1F0D995C23,
	AkSoundEnginePINVOKE_CSharp_GetDialogueEventCustomPropertyValue__SWIG_0_mA15F45A2973B43D132BDDB19B426DC20D36F6D9D,
	AkSoundEnginePINVOKE_CSharp_GetDialogueEventCustomPropertyValue__SWIG_1_m967CEE9A1B51E9B2411AEF0CA36FAB85546BE258,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fCenterPct_set_mA7C88FE401BC97ACEEA5A21A2B54E88128B74F64,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fCenterPct_get_mA34EF617E0E211C568BBC82808433DC9E09EE6E1,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_pannerType_set_m8B770E3C2EAB279ACBD3D2C7C00CA7F6B9EBC39D,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_pannerType_get_m4D8C209A73F46258812D55B51FA5F87F63BB6FA2,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_e3dPositioningType_set_mE122A56AC9200628C70C559A08AE8873A7BD849A,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_e3dPositioningType_get_mAC43745A85B812CEAF8727E5183EEE12AF22EC7C,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bHoldEmitterPosAndOrient_set_m61739BE3BB14E39508926C1CCF2FED5B91D53449,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bHoldEmitterPosAndOrient_get_m2DADB9D7F32968E6C196E4425883978258B65338,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_e3DSpatializationMode_set_m174D3BB8CD54E55190C891FBAF0C46FBA482A02B,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_e3DSpatializationMode_get_m6AE2927F60B8E03C099A8E689F375D43C0F9368C,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bEnableAttenuation_set_m42118CC31BD3498C99F3265FD19DE679FD488B53,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bEnableAttenuation_get_mBA0BE2BDD6B2DE1611D5710FE8346D7BF082C85F,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bUseConeAttenuation_set_m8E5B47924567A065C331F5517045A069DD11FB86,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_bUseConeAttenuation_get_mD3F14BD7FD7F428F875AF124BF6EAD6A1AB1E899,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fInnerAngle_set_mDF36C07A2A87ED7A3CAFD94C80664B6246F97F9E,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fInnerAngle_get_mC4876B838FCB9917B697AFA1C5D8274F6B9521CE,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fOuterAngle_set_m0FD82AC6656B20D9E2BEAFC9BE2B901004503BF9,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fOuterAngle_get_m6A7E7D40F32FEC07A28BAB5377647F4DB8E48B69,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fConeMaxAttenuation_set_m84D5430D1A01979F5D9DFD2B9C09DB1DD8D03801,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fConeMaxAttenuation_get_mE1570D943276969C242E552673B5F730865C5A02,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_LPFCone_set_m9EB186FC208BF1A755FD4362243BFBB145E2195A,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_LPFCone_get_m93B5FEF056F31354AEED103A3974F7C4F98489C3,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_HPFCone_set_mD03D463A1F0329441102D2631D8661A34ABF9267,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_HPFCone_get_m0E9EEC1FAF3BDA0086747F5CE5A39830CEF3F2B9,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fMaxDistance_set_m1EBE1FD34160C09E6060FA4C82A931BF87F3A36E,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fMaxDistance_get_mC9F2023C17C3549D5A69DFF5B8B73811D4151B5E,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolDryAtMaxDist_set_mB7EFFC03A89C08BC567B3C8A33C7B90F215CA622,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolDryAtMaxDist_get_m260DE814B6271245E802D63D1E76DA97DEE840A6,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolAuxGameDefAtMaxDist_set_m8EED39C41269F39D9B9D7DD20B42B15C0322D89B,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolAuxGameDefAtMaxDist_get_m0F785313D04C2BE2F5C591BF61BCD8F4022227BE,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolAuxUserDefAtMaxDist_set_m32264130F87187FAC72071BECF0C5B301177FA09,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_fVolAuxUserDefAtMaxDist_get_m33EF52DC5147A88C491AFCF7256F1360EEF523D4,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_LPFValueAtMaxDist_set_mAA3390C1053F0509CC71EC432D7E2417FF1359E9,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_LPFValueAtMaxDist_get_m7EDBC358EFCCC00B9827A4D2ED6AE28B016C6DCA,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_HPFValueAtMaxDist_set_mA801D79C8A35D73222AE53CF9B65E453932A1D2A,
	AkSoundEnginePINVOKE_CSharp_AkPositioningInfo_HPFValueAtMaxDist_get_m19071995DF542EB69A930858470E3731730AA6D7,
	AkSoundEnginePINVOKE_CSharp_new_AkPositioningInfo_mA319ACC1FFE5497EECF95F27A7B29F5F59E05FE1,
	AkSoundEnginePINVOKE_CSharp_delete_AkPositioningInfo_m328FCEAB409BE9EC3D19D35AEFE842C2C94DCC6C,
	AkSoundEnginePINVOKE_CSharp_AkObjectInfo_objID_set_mFDB67DA7E86442339DD53345623EB1DB6F413277,
	AkSoundEnginePINVOKE_CSharp_AkObjectInfo_objID_get_mB3AA85C9B50E7968EE0AC8346637FE4813A47ED1,
	AkSoundEnginePINVOKE_CSharp_AkObjectInfo_parentID_set_mD54DB58305065D1DC63DF66008E1E567A2B60960,
	AkSoundEnginePINVOKE_CSharp_AkObjectInfo_parentID_get_m00384DE821470FE80D3A77B245658188BF1AE3D2,
	AkSoundEnginePINVOKE_CSharp_AkObjectInfo_iDepth_set_m3AA94DFCE04F0F4C6A4A9D03AA5D519739BA7348,
	AkSoundEnginePINVOKE_CSharp_AkObjectInfo_iDepth_get_m3845EB8342F431B1E7404D8DF3943059D62C2D87,
	AkSoundEnginePINVOKE_CSharp_AkObjectInfo_Clear_m0337C80CA59E7DDF1E940CA55FE1B78FA2D89C5B,
	AkSoundEnginePINVOKE_CSharp_AkObjectInfo_GetSizeOf_m34258A7608E5568BE7AED7D556138E0EF37F472F,
	AkSoundEnginePINVOKE_CSharp_AkObjectInfo_Clone_mD0246C1517BA4A78503BDA8DCA078EE07F99F6FD,
	AkSoundEnginePINVOKE_CSharp_new_AkObjectInfo_mE3A23EBECEAB2021BE957AF6E69CA28674EA2F89,
	AkSoundEnginePINVOKE_CSharp_delete_AkObjectInfo_m285444E109DD8B0FD5EE6A6C1FF6370046453BB7,
	AkSoundEnginePINVOKE_CSharp_GetPosition_mC39BCD7A8D456C23F862A6D8060EEE908081F2ED,
	AkSoundEnginePINVOKE_CSharp_GetListenerPosition_m6614DBF7F8E88D7FCBBE21F5FE72715A0AE5B97B,
	AkSoundEnginePINVOKE_CSharp_GetRTPCValue__SWIG_0_m76576C86AD77E31B4079D67125F77E2492D20398,
	AkSoundEnginePINVOKE_CSharp_GetRTPCValue__SWIG_1_m3C1238F84D68BB1F521FE6AB27969BEE314EC157,
	AkSoundEnginePINVOKE_CSharp_GetSwitch__SWIG_0_m088536208719C3B462E1243845E97ED28830061C,
	AkSoundEnginePINVOKE_CSharp_GetSwitch__SWIG_1_m5E65011F8084B1E1F679A7E5D88D23C5B6716EAB,
	AkSoundEnginePINVOKE_CSharp_GetState__SWIG_0_m46F5C162BF4A449269B9A942A7ECCD33EE0004DB,
	AkSoundEnginePINVOKE_CSharp_GetState__SWIG_1_m6CEF665E33F314DC597223AAB6211DB0AF6E5E19,
	AkSoundEnginePINVOKE_CSharp_GetGameObjectAuxSendValues_mD90B4E205016417C5AA760ED12C9A9D33988493F,
	AkSoundEnginePINVOKE_CSharp_GetGameObjectDryLevelValue_mC1F1E854E09BFB9E72E719BAE3E296D0C379EAF7,
	AkSoundEnginePINVOKE_CSharp_GetObjectObstructionAndOcclusion_m23BB6CC46E2AD115804AAC01D3A8BD4BE0451FF3,
	AkSoundEnginePINVOKE_CSharp_QueryAudioObjectIDs__SWIG_0_mDB31A1FFFBDEE7FAF538C5FD8A79C639CE20A998,
	AkSoundEnginePINVOKE_CSharp_QueryAudioObjectIDs__SWIG_1_m07CCF5CAC3C23B4EAFEA04DADD2FC3BD36C3B7D5,
	AkSoundEnginePINVOKE_CSharp_GetPositioningInfo_m90D3A3B31E37EF1CB00C7A76D3BCD398CFF72AB7,
	AkSoundEnginePINVOKE_CSharp_GetIsGameObjectActive_m55613DE2C37683F29EB52BD4A0DDCC1B1219613E,
	AkSoundEnginePINVOKE_CSharp_GetMaxRadius_m7FF94E96ACBAD994AAD619DF6CE918D55D0E435F,
	AkSoundEnginePINVOKE_CSharp_GetEventIDFromPlayingID_m4C5B67D1639004BBA7E4196B644F4AD375726E71,
	AkSoundEnginePINVOKE_CSharp_GetGameObjectFromPlayingID_mDEC78DCBEFCDC80E6F9863A945D14BBFFA1F5305,
	AkSoundEnginePINVOKE_CSharp_GetPlayingIDsFromGameObject_m39B5DEF97C3920410E6E1F7D197DE7256E25D7EA,
	AkSoundEnginePINVOKE_CSharp_GetCustomPropertyValue__SWIG_0_mF6E4C2D7E4FB1EA829C0F7BFE7513DC606A23AAF,
	AkSoundEnginePINVOKE_CSharp_GetCustomPropertyValue__SWIG_1_mE456485F58561B1F1148085516160D5CC37D60BF,
	AkSoundEnginePINVOKE_CSharp_AK_SPEAKER_SETUP_FIX_LEFT_TO_CENTER_m850CFD5A66D6946FC98CB1305573B6DBA0F684F6,
	AkSoundEnginePINVOKE_CSharp_AK_SPEAKER_SETUP_FIX_REAR_TO_SIDE_mB5BB1F24224A9E90E7ED3CADB3ED50F2E7095EB2,
	AkSoundEnginePINVOKE_CSharp_AK_SPEAKER_SETUP_CONVERT_TO_SUPPORTED_m663CAB3AF095D4BC34D818E134330D841F8C63C5,
	AkSoundEnginePINVOKE_CSharp_ChannelMaskToNumChannels_m623FB2DFD860D62C08A614E4468504C853CF683B,
	AkSoundEnginePINVOKE_CSharp_ChannelMaskFromNumChannels_m3633CC1B01EC7C52A0B87B42E9CC226080898C1F,
	AkSoundEnginePINVOKE_CSharp_ChannelBitToIndex_mCB9A64AFA3FCF62008EB788F47D5238F492744D5,
	AkSoundEnginePINVOKE_CSharp_HasSurroundChannels_m733A02D081B2B0D905FD989C18A4D3E2874F7DAC,
	AkSoundEnginePINVOKE_CSharp_HasStrictlyOnePairOfSurroundChannels_m00C48FA757067D23B6F3013942179841AEDA5AC5,
	AkSoundEnginePINVOKE_CSharp_HasSideAndRearChannels_mF5A03E7D0C1EFC00FA25F91E21FC28D08FF5A9A2,
	AkSoundEnginePINVOKE_CSharp_HasHeightChannels_m46A4893ED73D1E2DA57887DDD6D3C2A5FC677072,
	AkSoundEnginePINVOKE_CSharp_BackToSideChannels_mD7BA9DD062575C60B601A9536B0E1F0440AB59D1,
	AkSoundEnginePINVOKE_CSharp_StdChannelIndexToDisplayIndex_m42D969B7F77B9CE9D920635EBF7A7212ED4CE9C7,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_uNumChannels_set_mB4DA8FB38024C684F31AAE57337B2663BBEF1A8C,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_uNumChannels_get_mB0F3FDE40932C5F25FB91EEF1D81FEDE41A1247C,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_eConfigType_set_m356AE8360470E856E4988232C0FAFE0D5B751261,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_eConfigType_get_mA33BA699C22CB4AFA569BD674A85933071F0954C,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_uChannelMask_set_m3413FCA33CE3F0B2DBFAC6ED8E20E08D9FA1F5EB,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_uChannelMask_get_m41300A21173D586584A0D1044F357F6E5651E1F5,
	AkSoundEnginePINVOKE_CSharp_new_AkChannelConfig__SWIG_0_m24897E360C4F9388502975F63AD73DD8CE4439F2,
	AkSoundEnginePINVOKE_CSharp_new_AkChannelConfig__SWIG_1_m9C129DB8C42043B320C291E57C6D17E2E97ACF64,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_Clear_mC6D1778DE625EDF94FBE7A331974EAE8AA56A25D,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetStandard_mBC5AC12D93479FB9751BD078E7BCBD375E306807,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetStandardOrAnonymous_m7F170DC697FA5DD5803DF88C4CD3058367EF578C,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetAnonymous_mCEBD41600AAF06563FD9F15E706E236FDD772F15,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetAmbisonic_m91F3D6BEE9AD409F0F0A1383ECA287293AD83049,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_SetObject_mA8A5CA1BD56AA109486CD181CCAC0BEE385C2D55,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_IsValid_mAA59DB0549429D720DDBD8A6B0A697E6A68C69D3,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_Serialize_m0B836F2F96C738765CCD011CBD5ECFF4F6DA558E,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_Deserialize_m5AF6760E273FAF6605BE3EC35FA845535265E1BA,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_RemoveLFE_mC598D3C8A11A22E4527D58E0380946C04F40AAB2,
	AkSoundEnginePINVOKE_CSharp_AkChannelConfig_RemoveCenter_m35336BB500314A79EDD8CB0C281E2E981013F50F,
	AkSoundEnginePINVOKE_CSharp_delete_AkChannelConfig_m9DB5C4CECBAC1BD5381FEEE89EE48BFAC338CEDA,
	AkSoundEnginePINVOKE_CSharp_new_AkImageSourceParams__SWIG_0_m03F047DDF379F73D0513AEDD0C8F10D61FED21C0,
	AkSoundEnginePINVOKE_CSharp_new_AkImageSourceParams__SWIG_1_mCD835F81C2C106C3215962A038189486F2F811D8,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_sourcePosition_set_m42BB6ECC162693EF1A07ACF883F50DD33F4794F5,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_sourcePosition_get_m73E680C873ED5444D717A141EEE905547BBC8866,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fDistanceScalingFactor_set_m5D5502220CF3658893FAF74A7C77AD212CCCCBD3,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fDistanceScalingFactor_get_m9DDB70C0D411B9E8D1FFE0ABCF9DF8C8D3BFCC8F,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fLevel_set_m216E7A9868B2C8D88557ADAC34F270B13ACF4B79,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fLevel_get_m326CD11846B10846067BC05BDE970E10A9BE64B9,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fDiffraction_set_m080BE0BCA57892468286828402F666BEC37BFA8E,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_fDiffraction_get_m0A977AF100EC17E66305A05A064BD74D635308D5,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_uDiffractionEmitterSide_set_m5DA39DDCD185C1BA2399E1F8A27D962E51D5A5F0,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_uDiffractionEmitterSide_get_m6AAC90318170AC21D6FB00FECBCB2C24D73A627D,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_uDiffractionListenerSide_set_mF53C68D9B07EBF6FB67DA84E6651B9FE5BA5B0F0,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceParams_uDiffractionListenerSide_get_mBE93C135752D3B8BA8D751600774DF874F2C8747,
	AkSoundEnginePINVOKE_CSharp_delete_AkImageSourceParams_mEBE7F5547A81E11E9E85A266B60ABCFE61B33797,
	AkSoundEnginePINVOKE_CSharp_kDefaultMaxPathLength_get_m398B35F49C6E7D10ADF35A8E46FB0CD49C4328F5,
	AkSoundEnginePINVOKE_CSharp_kDefaultDiffractionMaxEdges_get_m6E265261E260BE50EAF288276033880C3DE21C13,
	AkSoundEnginePINVOKE_CSharp_kDefaultDiffractionMaxPaths_get_m8E8483065ABBC9679054B19093004B747B827BF3,
	AkSoundEnginePINVOKE_CSharp_kMaxDiffraction_get_mFDD2E532255F4C5464A0F87BC4BC0B06FA36131C,
	AkSoundEnginePINVOKE_CSharp_kDiffractionMaxEdges_get_m756885408A7FBBAE539A312EBD81108FF3CF2C7C,
	AkSoundEnginePINVOKE_CSharp_kDiffractionMaxPaths_get_m965154082477C762D4AF2DFF489847A69EF78A74,
	AkSoundEnginePINVOKE_CSharp_kPortalToPortalDiffractionMaxPaths_get_mC888764C072834A41E9728569C4D3D0774B40170,
	AkSoundEnginePINVOKE_CSharp_new_AkSpatialAudioInitSettings_m29E15D5330E3531CC76573E6D1A02E1A7904E2DB,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uMaxSoundPropagationDepth_set_m1A7298FB213458A44EA960C4E42D09FBD48F78FF,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uMaxSoundPropagationDepth_get_mBC593B6840A1DA5906E1AA10A4C90683096DDF93,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fMovementThreshold_set_m32B47005F02A004CC4B002C19408415E15B2AA67,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fMovementThreshold_get_mB13E5AFCEEF0746DFEED6AF048B14FB2D9BD711E,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uNumberOfPrimaryRays_set_mE3CDCAF67B07B586C5953B6D4BEF57AD800D65CF,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uNumberOfPrimaryRays_get_m6C4B011AEB7A865BADAEC208C4E2166D15CB17EE,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uMaxReflectionOrder_set_mB65CA8E4C4433A290CE08E4A537F4A261FB11CAB,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_uMaxReflectionOrder_get_m01D2AFECBF9B1DB74A57A1A37D1BF25E43DDCE64,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fMaxPathLength_set_m7C5C5E1D2F5609254ECBB2D03A31F7D64442ABB2,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fMaxPathLength_get_m2E230F9029C7DB5E6E367FBBE0B4509425CC232D,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fCPULimitPercentage_set_m2F53E27C6D0934B31AA92C2535E653B00D5B556C,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_fCPULimitPercentage_get_mD98A958FEFDF8B6DCBC9E8A317F79D762866EF26,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bEnableDiffractionOnReflection_set_mBCB34454FAACA8281544BDA781D5D0FD029AB8CA,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bEnableDiffractionOnReflection_get_mB866EF496ED1813DD57BB88597CC107B36B2AC83,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bEnableGeometricDiffractionAndTransmission_set_mF9BDBC8DB3141368B8923EA443903B691184AD6F,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bEnableGeometricDiffractionAndTransmission_get_mFFC4C6FBAA331043E72BDC7E6950995CCC669691,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bCalcEmitterVirtualPosition_set_mC25CD67C4CC8A38C05D3105C9BDD09051E4A3202,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bCalcEmitterVirtualPosition_get_mD83EC7DB2FD2A90774B0CE58F49136887A486955,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bUseObstruction_set_mB38D0DEA92AE0D4E3FD7C1B30685C836483F663A,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bUseObstruction_get_mDE2C96F5187A73093C89B920FEB34F734E7DE5A8,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bUseOcclusion_set_m96178A3922A7571900F26093AA8480D1FD512F60,
	AkSoundEnginePINVOKE_CSharp_AkSpatialAudioInitSettings_bUseOcclusion_get_m1D6C367F89BA3A776C34177981F2BF2CD68FBB84,
	AkSoundEnginePINVOKE_CSharp_delete_AkSpatialAudioInitSettings_m9444AED8922099F8E916E2A93695AA23D0BBFF20,
	AkSoundEnginePINVOKE_CSharp_new_AkImageSourceSettings__SWIG_0_m66C0D0E8E98115DDB8FA43B4F5E7E6B4D388E945,
	AkSoundEnginePINVOKE_CSharp_new_AkImageSourceSettings__SWIG_1_mD55B0516D9550649912D72D2A3A1B6E69BFC310D,
	AkSoundEnginePINVOKE_CSharp_delete_AkImageSourceSettings_mFB8BB4478E4B9E8776C9AF9C8C70B80C98018777,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceSettings_SetOneTexture_mD2FF656F32F801C349F7328EAEBF5D61F2C25AE9,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceSettings_SetName_m4F9943373583D251C9374F84BF6EE375BB430A55,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceSettings_params__set_mF0CD88DE0E8AC7FF3CDC0F463695DFE714F55FC0,
	AkSoundEnginePINVOKE_CSharp_AkImageSourceSettings_params__get_mA14717004E08E1E2E4173A5B140C820591D75F8E,
	AkSoundEnginePINVOKE_CSharp_new_AkExtent__SWIG_0_m0E653D2B633EAFBC8814DAA5503CE4486F06132B,
	AkSoundEnginePINVOKE_CSharp_new_AkExtent__SWIG_1_mA6AD2ADE0EAC3EC1B1B4BBCDF59CE224EEC70507,
	AkSoundEnginePINVOKE_CSharp_AkExtent_halfWidth_set_m73AA7931A2673A6C6CBB7D1C842AC805DAC51E66,
	AkSoundEnginePINVOKE_CSharp_AkExtent_halfWidth_get_mDF1EDF435065595D3E1F35C5A19756AE2B3FD22D,
	AkSoundEnginePINVOKE_CSharp_AkExtent_halfHeight_set_mEC71DEC1C922A64BF20567AACE01D4199AACB58D,
	AkSoundEnginePINVOKE_CSharp_AkExtent_halfHeight_get_m0DFE579DFDF0ED60BF2C180C1A0030C82A486B3C,
	AkSoundEnginePINVOKE_CSharp_AkExtent_halfDepth_set_m79E8922045145C8D8BC8AD789C1EE728EF259558,
	AkSoundEnginePINVOKE_CSharp_AkExtent_halfDepth_get_m467FCFA7F4A875A15098BADADC6D7BB1406B7DA8,
	AkSoundEnginePINVOKE_CSharp_delete_AkExtent_mE57FDB779C0DF80C34C8D670EFAEFB56D76A1E71,
	AkSoundEnginePINVOKE_CSharp_new_AkTriangle__SWIG_0_m4E629B89867AC9A51899353485760B36740A0113,
	AkSoundEnginePINVOKE_CSharp_new_AkTriangle__SWIG_1_m4571276AABB70E12F28702D1E0BE05B34C189B12,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_point0_set_m27BA68A7C4DDF1614637770A4D3DB8279254D002,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_point0_get_m8484D01EC2DD2BB0502EFAB5EFAADC6CC1CB0D3F,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_point1_set_mC62371D03AA6B18ACF6E9D3E1CFFC19AE63AEF25,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_point1_get_m80E9706AFCCF924C23D9696FF4D58951577BB06D,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_point2_set_m1BE85B820B2B349BDBF00A6DF0A405BAB7391184,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_point2_get_m55B1FF16F098B17A1BE8DAE85C8F497862CA7CA0,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_surface_set_m5A72292CCD72AB24C144ED9698DC8FE173FE85E0,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_surface_get_m8A617C9B8442FA0CC7FA1E25AD3CE0A480DE3FCA,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_Clear_m10AF5416A9A7D19C9467CA1C9847C37B0358AB49,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_GetSizeOf_m7F5AE9B059445A7F1D1F28C1D5F2CEF5B8F5F238,
	AkSoundEnginePINVOKE_CSharp_AkTriangle_Clone_mD26A971387BC7039CF7B59890EB875258A62CF1F,
	AkSoundEnginePINVOKE_CSharp_delete_AkTriangle_m9B957C05F0AD1AF9A4C16405E4666F679FC4C851,
	AkSoundEnginePINVOKE_CSharp_new_AkAcousticSurface_m34106517C1334D836459BD736598118BDC39AED3,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_textureID_set_mC307A635235FDBBAED617A7D6DDF93E68D773B41,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_textureID_get_m6F34F0D7D172D1D065B7FF0D6A90BB98842F5CDF,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_transmissionLoss_set_mFD45A2C4E08AB06E164E8DB59F2C6778379605A4,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_transmissionLoss_get_m39953F871BA3E45953B8D432EC193720E04BF862,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_strName_set_m8C1ADFE9C4EA79C5620F9FEF4975E4304980AE7A,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_strName_get_m1C16B55C82E316E90F12D2BA7BF8BB49458577B2,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_Clear_m193357C604652192A7F733759BF1300179F844E5,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_DeleteName_m7BC8C8EA8DB7E0941471BE5A7AF5DF46BCDFA94B,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_GetSizeOf_m9034A17938D421388C2563C704E9AD91826F154F,
	AkSoundEnginePINVOKE_CSharp_AkAcousticSurface_Clone_m6AD430C5B86FC4098C76E0F1E11FF4D01EDFE5F6,
	AkSoundEnginePINVOKE_CSharp_delete_AkAcousticSurface_m378080FB838B70E0435DDF2CCA050DF05106136A,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_imageSource_set_m230F6A28F8EC07D67C8E4A46EE8263699D56F99C,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_imageSource_get_mC9C980B1443259F160236B8F80627DF609CD1610,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_numPathPoints_set_m425F780CD825D00FCB345BEAEF444669E31E4F25,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_numPathPoints_get_m51470E8BAC751937535FC34C2563958CA25CD06B,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_numReflections_set_mDEA1D964F3043F2F57D0DAB5938E831C2FB1E3B3,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_numReflections_get_mED5EC0012B98621F56309064DCB39DE6E13469AB,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_level_set_m1AFBC0D7ED1F18D6E0516EADACFCAECA487172CD,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_level_get_mB0F31693FACDDDD9E548A105955B50DAE270453B,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_isOccluded_set_m6D71C70D2C464DBED93AE32776806ABB05AB535B,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_isOccluded_get_mF75DEF0C3D9CBD4D49F4695A25E4C336C5E8A7CE,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_GetSizeOf_m3CDDF861E2E9D66B015930741A4BE959B8511E21,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_GetPathPoint_m535FB9AE5A2F4227F7C4D93CB8F8ACEC6AEE15C1,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_GetAcousticSurface_mE51C5523BE720957C84377502F1C86D495794788,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_GetDiffraction_m164ECCFDD5C7D1FE9D61AD6D71308CA96700EDA0,
	AkSoundEnginePINVOKE_CSharp_AkReflectionPathInfo_Clone_m067F448AF471765E71FD42BF08F1FE1EC24566AA,
	AkSoundEnginePINVOKE_CSharp_new_AkReflectionPathInfo_m65494A4F26DBD73BB727711CFE0B11FC5999F42D,
	AkSoundEnginePINVOKE_CSharp_delete_AkReflectionPathInfo_m0C2988F446DD2BBD856F152D2202469E2FCCB1F8,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_emitterPos_set_m8F98AD84FD768B9150D5E693559F1B265A860B69,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_emitterPos_get_mEAE8829D91A1A7739B757C6226B06C7434AC9507,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_virtualPos_set_m497B9E44D93ECC0356B6D5CA5366E1C21F1E2406,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_virtualPos_get_mBF5AB5EF70ED3C5655584F224C4A31C09195F159,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_nodeCount_set_mA0FDDC532EBE3E6B739BBA7EAADCE1C98BDC363D,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_nodeCount_get_m1B5C9E59B991D58C9EE04713A577865CBD5DCD7D,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_diffraction_set_mE5BCB9DADE5C4AC35FD197489922D25410D7E1F8,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_diffraction_get_m3D53606457791F70436D6A5CD103DDFC24A91B65,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_transmissionLoss_set_m15BAD3092E860198EA79AE1356C9129958E6682A,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_transmissionLoss_get_mD1A214494417BF1D95C40BC30304A99AF90858DC,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_totLength_set_m04276D01AF68DBCC5F9D0882383DCA0437D0AF83,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_totLength_get_m6C2F9EDA29BA5714903362C2C4660171B828BA37,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_obstructionValue_set_mC5829628F8353CE9B5C98C9B065E2F85E2B003F1,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_obstructionValue_get_m1255AF1A5A7A21D488DE23A48CC750BDAD91B187,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetSizeOf_mEE08A2EE805BDD5287BF346912B7D4BC6CFFE8BE,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetNodes_m57EEF11D548808F5F22F10701E3073BD500FF12E,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetAngles_m76737C6DB7F4E59363B6EFD85374AB769A00E7EA,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetPortals_m954A688F0B01D62CF5AEF389A10CFD7AF01764CE,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_GetRooms_mF2A8FDDE9D82E0A6F8094351F667EFDA701FAC04,
	AkSoundEnginePINVOKE_CSharp_AkDiffractionPathInfo_Clone_mEE9AA0C6D0A1E49221C8EB39A993D88E354D4FC9,
	AkSoundEnginePINVOKE_CSharp_new_AkDiffractionPathInfo_m1B4275043D1642E6A056B2CDA90370C3D0DE94B2,
	AkSoundEnginePINVOKE_CSharp_delete_AkDiffractionPathInfo_mFFF5CE398391C96B588CB6ED28516B9995854E15,
	AkSoundEnginePINVOKE_CSharp_new_AkRoomParams__SWIG_0_m78B2FC1011B980BAEF354FE14457BE946078DD37,
	AkSoundEnginePINVOKE_CSharp_new_AkRoomParams__SWIG_1_m21F304FAA8DFD8146850E85408C8DF2BF6018A50,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_Front_set_m7251CA3A7E70C087B0C0A30FBEC7668F1D80CCE1,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_Front_get_mFFF6425C85369748F4FCB621BF195F325E097142,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_Up_set_mD76FAF0A8F6F323E4EE6D8A4C1E1351BADE22293,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_Up_get_m6798495DE1105BC4C4E8CC70ABB0F967E58DBC78,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_ReverbAuxBus_set_mDF399BB46A3C8E7EB971458BF569BA6056C59427,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_ReverbAuxBus_get_m535BB5821C3827095A60ECCA4DD147D175083C7D,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_ReverbLevel_set_mD76F5621A27A98D0A06323A93FE8E90EAD9C2F70,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_ReverbLevel_get_m6DF005A7EEBE913E2788E408CEFC061E19276E9C,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_TransmissionLoss_set_m892D75009C11190EB5EA775126EC046D5646D4C6,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_TransmissionLoss_get_m18F4932B4CD23FEF3ECCFF240059C58FE0D36C26,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_RoomGameObj_AuxSendLevelToSelf_set_mA167FD0D67AA9191CEDDD529EB6687541ACE9620,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_RoomGameObj_AuxSendLevelToSelf_get_m7E198F0FB28A5FC5C3E80D5D1098E25347241CA0,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_RoomGameObj_KeepRegistered_set_mE183A0BCC4D5AB23A230809A1C97FD6F61026922,
	AkSoundEnginePINVOKE_CSharp_AkRoomParams_RoomGameObj_KeepRegistered_get_mF47172737BA2B457A7AFBAC100AC5AFD91E2A5B1,
	AkSoundEnginePINVOKE_CSharp_delete_AkRoomParams_m9063155289D000127FF03560F46508F55259263F,
	AkSoundEnginePINVOKE_CSharp_SetGameObjectRadius_mC16F81ECA0333B27145F4ED25FE87323DD1F8CF7,
	AkSoundEnginePINVOKE_CSharp_SetImageSource_m9EC0506CD4F2CF1C7C209617D91247C4D94BF1CC,
	AkSoundEnginePINVOKE_CSharp_RemoveImageSource_m902AED77F66B461CF5DD7571C38BA4B0FED7FF0E,
	AkSoundEnginePINVOKE_CSharp_ClearImageSources__SWIG_0_m2653BA51502D8EE387CECB20D8460B7A569F7847,
	AkSoundEnginePINVOKE_CSharp_ClearImageSources__SWIG_1_mFDBE8FC3C60AC067990409F7DBC2CC099B882F45,
	AkSoundEnginePINVOKE_CSharp_ClearImageSources__SWIG_2_mBA9C69842599D51FB13CBB058D4783E5BA42B597,
	AkSoundEnginePINVOKE_CSharp_RemoveGeometry_mFECCFB77B034397C85A4EFE412FD08C2245EB1F1,
	AkSoundEnginePINVOKE_CSharp_QueryReflectionPaths_mE3876F6E5583DD911326BD937C3324768D4BF52B,
	AkSoundEnginePINVOKE_CSharp_RemoveRoom_mFEEA7F4E05533961A884DC7F2FD918067B1D49F0,
	AkSoundEnginePINVOKE_CSharp_RemovePortal_mDAE5939072901E12F9A0283A8A2C4676D05C7127,
	AkSoundEnginePINVOKE_CSharp_SetGameObjectInRoom_mF7751850DCE44FE4396FEC5926860764DF765F78,
	AkSoundEnginePINVOKE_CSharp_SetReflectionsOrder_m9019509F48917A6B1C997169600278B0980D9DCE,
	AkSoundEnginePINVOKE_CSharp_SetNumberOfPrimaryRays_mF90068F26913A6FF916B1525C2F7399E826DB300,
	AkSoundEnginePINVOKE_CSharp_SetEarlyReflectionsAuxSend_m54CD0ECB1BDEEB6285286912965EFAAB9BDBD0E2,
	AkSoundEnginePINVOKE_CSharp_SetEarlyReflectionsVolume_m8071AC48FAA7D5EFA669EE775507D3A008FACD01,
	AkSoundEnginePINVOKE_CSharp_SetPortalObstructionAndOcclusion_m456275263529BB4CA4394135FE92896124CCC0F9,
	AkSoundEnginePINVOKE_CSharp_SetGameObjectToPortalObstruction_m54535828E1638B7BA462A65D1EE466BA26699657,
	AkSoundEnginePINVOKE_CSharp_SetPortalToPortalObstruction_mFAEA091AED27C764D4D03DFBCF49EC48DCDAC7AB,
	AkSoundEnginePINVOKE_CSharp_QueryWetDiffraction_m87EBC01C3E6BBD6CD2610C99CC593256AA1E78AE,
	AkSoundEnginePINVOKE_CSharp_QueryDiffractionPaths_m3040EBE4383503DDD4AEC18A1538C85BF5E9F995,
	AkSoundEnginePINVOKE_CSharp_ResetStochasticEngine_mED5DFD43653A58C0D70EED09DBF181B73153A689,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadLEngine_set_m710BFFE348A6DB283725F0A8D31CF01F8CE1BD4B,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadLEngine_get_m039C24850B5556B2A71A100E2FD69A3CA1D3FBB7,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadOutputMgr_set_m37AD985B460F5E415D2F80254F632EC4F3F88165,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadOutputMgr_get_mF9A492BF96FB079493A7E5B55F4155FA1ED340A4,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadBankManager_set_m3AA6D779D1B295C727A21D6C68AA9C5B416F8390,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadBankManager_get_m0AA459A52550A375FADD1935D8ED35E00F8C1CE0,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadMonitor_set_m6687CB75293A5264AB4584AB8303EF84BF0CE2FB,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_threadMonitor_get_m4AFD038B699572C101D9BD59C9D370148F17D700,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uNumRefillsInVoice_set_mAE7F42106DBCA83FC85A4DB4E60C56A415B342B7,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uNumRefillsInVoice_get_mD4DC6B7A4C437C429F309C8B618BB1807373F616,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uSampleRate_set_mE6E1F02B8E7BA695C3EF7B1B2E75B1EA0A48D62D,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uSampleRate_get_m1B56462B0399E8EDC97793E5B207AB09784C2C68,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_bEnableAvxSupport_set_m67420304379CE560C4440EDD423DF66C3F91AC04,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_bEnableAvxSupport_get_m4E584738FA406AD1B13BCF5B3D151C655421C68C,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uMaxSystemAudioObjects_set_m574F7B7E657BC0F62E07359CC735AD0338CAD06C,
	AkSoundEnginePINVOKE_CSharp_AkPlatformInitSettings_uMaxSystemAudioObjects_get_mC9E62D74DDC85DD4FDCAEA866C8D4781BDC9095E,
	AkSoundEnginePINVOKE_CSharp_delete_AkPlatformInitSettings_m5EAB08474F37BC8CE5F3B6E3C0E828A1D336520E,
	AkSoundEnginePINVOKE_CSharp_GetDeviceIDFromName_m9D82F6B0D4EEA2E63E2D8ABD90A7D8F12EDE869C,
	AkSoundEnginePINVOKE_CSharp_GetWindowsDeviceName__SWIG_0_mE31907AA3741ADA2BA44A54927B7D64710BA2DFD,
	AkSoundEnginePINVOKE_CSharp_GetWindowsDeviceName__SWIG_1_mC80D528EE642442B2AC6635775B5BCAF771E9D11,
	AkSoundEnginePINVOKE_CSharp_GetWindowsDeviceCount__SWIG_0_m9E7AC212252262B31544079C754E39B96F3ADE3C,
	AkSoundEnginePINVOKE_CSharp_GetWindowsDeviceCount__SWIG_1_m2CFD4361CB087E1AF1143FC877196113323C32D5,
	AkSoundEnginePINVOKE_CSharp_delete_AkStreamMgrSettings_m04A5203B27402CD330743098920811266791A567,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_pIOMemory_set_m8286D8A950E5559BB6A34C6CE43EA42100FAFD38,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_pIOMemory_get_m76B8BAE3920F799BB9FCD20AD5E150C8AE53C709,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uIOMemorySize_set_mF02C8D587A2B8F7DE60AB5A95633520732A5F0EB,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uIOMemorySize_get_mFDE9D83E4E8A1806707262B211BC77171689F797,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uIOMemoryAlignment_set_m4E6FE0647202A7D987B452CBF16244EFD2066FE7,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uIOMemoryAlignment_get_mE40CB89E46C9823AA4133A4988B29C1E482447FA,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_ePoolAttributes_set_m67AA40B995BD2819B46314681F82985D230C065A,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_ePoolAttributes_get_m9483A66E795BEA167B81EBAFAE4947F0F004A7E6,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uGranularity_set_m9E702C3E2D9A91831467F7B209893CF1257B3F72,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uGranularity_get_m3D81A1FEBEB558A771E6F7C87823A7BAE2CD8748,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uSchedulerTypeFlags_set_m59A6B9AF84D53735CE51D7514848FC4B419C38AC,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uSchedulerTypeFlags_get_mEF050078DFB527D3FB0977D2D9F4E0CBD9707D81,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_threadProperties_set_mC5786AA6990E71C7E3B8904FB0686A704B8FB634,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_threadProperties_get_mCF93A98668C8AE79E786A368091C4909E5DB09AF,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_fTargetAutoStmBufferLength_set_mF401CF54CDFD7E5E52C30FCF6F59B50D93FAA0D4,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_fTargetAutoStmBufferLength_get_mE98CDB72DDC1A3BC623584F4CA2F3BD41BB11180,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uMaxConcurrentIO_set_m8D8F47A8D1BDFE8F131D2D00D2A2CE35744BF738,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uMaxConcurrentIO_get_m30C435988A298EAAC42071046DB74BE6D5658B93,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_bUseStreamCache_set_m91C364145E5399DA337BD8A4FE13C0304D8BCAB5,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_bUseStreamCache_get_m753D97DF88D8C3E4BAA4C419BE7E69F77378093D,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uMaxCachePinnedBytes_set_m434F1ACDB833F7802AC42BABA38F396F2E5876A3,
	AkSoundEnginePINVOKE_CSharp_AkDeviceSettings_uMaxCachePinnedBytes_get_m497B96C4031D0039A04C3F418C84735ED8E560FD,
	AkSoundEnginePINVOKE_CSharp_delete_AkDeviceSettings_m95260F865973F418A7FB8E6FBF0405C254321197,
	AkSoundEnginePINVOKE_CSharp_AkThreadProperties_nPriority_set_mF726FABCBE045DBF9F361A9D48666D067FFF3AC1,
	AkSoundEnginePINVOKE_CSharp_AkThreadProperties_nPriority_get_mEE3A49683C9A0230B63EB3020F8E93BF6169F52F,
	AkSoundEnginePINVOKE_CSharp_AkThreadProperties_dwAffinityMask_set_mF08EDD4960BDA1736ED357E073A9D15A5C17E7E5,
	AkSoundEnginePINVOKE_CSharp_AkThreadProperties_dwAffinityMask_get_m2A3680AD21C66A5A6FBA6ACA16CB362F46D9B2B4,
	AkSoundEnginePINVOKE_CSharp_AkThreadProperties_uStackSize_set_mEF331699000F24EAB58AC459893FF46439DAB7C4,
	AkSoundEnginePINVOKE_CSharp_AkThreadProperties_uStackSize_get_m65133E15826735937DCD1AACEA63A0FC0C86ADA5,
	AkSoundEnginePINVOKE_CSharp_new_AkThreadProperties_mFFAFC88E17DA93E9CD11AD01CA704AF84725B3FE,
	AkSoundEnginePINVOKE_CSharp_delete_AkThreadProperties_m51D0C3AE9FC244344C96E552ABAC5BAA038A453F,
	AkSoundEnginePINVOKE_CSharp_SetErrorLogger__SWIG_0_m68384E32C4CBFD7903EA083542FD43653A90B217,
	AkSoundEnginePINVOKE_CSharp_SetErrorLogger__SWIG_1_mD7CF5BD29C515837CB916C970AA871E1DD40A3B8,
	AkSoundEnginePINVOKE_CSharp_SetAudioInputCallbacks_mAA8D3245B6079D1D9CE587AF583F62DEBE6D0A3E,
	AkSoundEnginePINVOKE_CSharp_delete_AkUnityPlatformSpecificSettings_m32BB0DA479787772FB49A633AB8DE06A2FD24CD1,
	AkSoundEnginePINVOKE_CSharp_new_AkCommunicationSettings_m6AF6E8060C2794E681F947FEEA9ADCD1B5B0BD61,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uPoolSize_set_mA4870B41E99D81958442C4A44AA829D533925D45,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uPoolSize_get_m34CCD5DD89C2F9B5783AA90152E62C62D9143BD4,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uDiscoveryBroadcastPort_set_mCC3E30CD7B847E11FAF5AA9AC0C772806A955568,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uDiscoveryBroadcastPort_get_m0E554924E0FA0564713739EFB9E855E04547B8DE,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uCommandPort_set_m1C3937D09F907F4B6861F158A80C6E07AA3695EF,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uCommandPort_get_mD8A6DDAF8C84EA1BC199E558B432D3654351C2B3,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uNotificationPort_set_m02359870647C731EFF76F03DC1F88FA6E4ACECFC,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_uNotificationPort_get_m680BB3440A859142F22956A4FFD9DF7CCA24C99B,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_commSystem_set_m0F6E9010D8C1F9C26B4553F84942B678FDB660C3,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_commSystem_get_m79365E910BCFED56C9A62D72256E53329A2A3291,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_bInitSystemLib_set_mCDCFE7E140EB93A457D85F735BF0826FD97D0A3E,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_bInitSystemLib_get_m11ED25B17BDC89D4FA4AE47EC969EC6A8C52BC2E,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_szAppNetworkName_set_m5C361481C871B3301C14D9B379E43997EA987416,
	AkSoundEnginePINVOKE_CSharp_AkCommunicationSettings_szAppNetworkName_get_m745758F2BCAE9E6EED09D3FD2534483CE2B4DC02,
	AkSoundEnginePINVOKE_CSharp_delete_AkCommunicationSettings_mEBB83365A3A19DA97085FCB8275AA6E34F4EB020,
	AkSoundEnginePINVOKE_CSharp_new_AkInitializationSettings_m0212DB5EFDD620A571EB74C9985E2A9FC5A98F99,
	AkSoundEnginePINVOKE_CSharp_delete_AkInitializationSettings_mE12A13A61F3A0A56DAC3F2F9779553EF7F898A97,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_streamMgrSettings_set_mB8B068C2512DD333251D11FC9202D172237DA673,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_streamMgrSettings_get_m8AB1D842D2803554043373DCC770A2744A2824A7,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_deviceSettings_set_m481A3198813883572CB71BC73C9056E33271ECC4,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_deviceSettings_get_mC8E89A1E43B6A372981B4199E66B0B47C0534D0A,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_initSettings_set_m44AAA3F99B90DA0F78642305BE4D1AD5686BC923,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_initSettings_get_m6FDB9E9DD58FF6D86CE7A7654BBA762829432569,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_platformSettings_set_mDFF03C61F46AD247CA99919502974D9756F78129,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_platformSettings_get_m995D39B22BDE6496DE27186D1542CE4E4C1707D0,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_musicSettings_set_mD51AC53481A4DE754A3F2F3C60302F36B196238E,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_musicSettings_get_m9B6C008BCCB4448AEA53135169F128EC4B80BA6E,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_unityPlatformSpecificSettings_set_m4B8C637D232E0E44BF7333F898B9BCAABFF47426,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_unityPlatformSpecificSettings_get_m67B7A327FC092DCEE503FE1FB5CCC981A6EB20A4,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_useAsyncOpen_set_mFF624DC0905F4299F0E27987E9CB08BFFDB8C7F0,
	AkSoundEnginePINVOKE_CSharp_AkInitializationSettings_useAsyncOpen_get_m341C38A0349784C82F6F89A657D0B994E1F73503,
	AkSoundEnginePINVOKE_CSharp_new_AkExternalSourceInfo__SWIG_0_m3EF33CA1520A68C6F9AA3EFB764D1D827395A88A,
	AkSoundEnginePINVOKE_CSharp_delete_AkExternalSourceInfo_m7C68034107F6E67EAC9BA412F51276F9AFEF1D8F,
	AkSoundEnginePINVOKE_CSharp_new_AkExternalSourceInfo__SWIG_1_mFDEF4FC85E8A909D59E083F350493BE2E0B05E7F,
	AkSoundEnginePINVOKE_CSharp_new_AkExternalSourceInfo__SWIG_2_m9E22C6556D5ADDE4FCF632DB4B051B315B3BDE57,
	AkSoundEnginePINVOKE_CSharp_new_AkExternalSourceInfo__SWIG_3_m97B9AD0DA0C13AA34D9FE31F1545694AFCD666E6,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_Clear_m2D4BF472DE807F7E0EB714935BCEBF5E87CD7E14,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_Clone_mDE25C1D520AF9E2C0B39A0692072A7BFA92B2759,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_GetSizeOf_mABA01B235D6D670FF24049CFD45B5D3227C7033B,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_iExternalSrcCookie_set_m5E2F66CEE3047302017C441AAA7CB35E8C207BC5,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_iExternalSrcCookie_get_mD477AF334E9FB18D5F35BED5A01D4A24AEDC33D0,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_idCodec_set_m72F3CB1C28119F257418E34264D175B337A8FD16,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_idCodec_get_mE122A04C220D43B060D506890D31FB940FD1298B,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_szFile_set_mB3118F243EE29E3120EA83F1B04EF3C2B726DD53,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_szFile_get_m52FC98B8225A6BE7E12E607064D53242AE01DACA,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_pInMemory_set_m26ED0D0DFC42F8259C4F12671E3F6C40F0DF0CFB,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_pInMemory_get_m5A4C9BC418DE7677C0082EA9825E3B634F5A5EA0,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_uiMemorySize_set_m76E0A49CEC84D42CD74153C161E615B7D8EB108B,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_uiMemorySize_get_m72060DF3038DDEA7362CB7CF0C4BD8C20B95A6FE,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_idFile_set_m20F61C9E416A13BA5DFEDCB60F533208785992D5,
	AkSoundEnginePINVOKE_CSharp_AkExternalSourceInfo_idFile_get_m9311AFDC0D4CD1DDFA21110FD096AEFBF73C3258,
	AkSoundEnginePINVOKE_CSharp_Init_mCA72E0E34A79850320826CD1DDAE665566D4D278,
	AkSoundEnginePINVOKE_CSharp_InitSpatialAudio_m3D652E3529941F79630C258219B366CFF507D1A5,
	AkSoundEnginePINVOKE_CSharp_InitCommunication_mD08CDFFD475A4590F07D2C64003DEB07FA302094,
	AkSoundEnginePINVOKE_CSharp_Term_mA1E44FF3B26A1BF0ACC8DEDA020915CDEEFF85AD,
	AkSoundEnginePINVOKE_CSharp_RegisterGameObjInternal_m71316D587F319943FEC530D9C6741B5D96194E37,
	AkSoundEnginePINVOKE_CSharp_UnregisterGameObjInternal_mF10321F56FD632B6042DFD06E78301975DF263DA,
	AkSoundEnginePINVOKE_CSharp_RegisterGameObjInternal_WithName_m1E6659FFA28CAB76BFEF5E3B89A5EF91685EC1BF,
	AkSoundEnginePINVOKE_CSharp_SetBasePath_m5A45603628E650AC75C27E20A99F7C994661AAFE,
	AkSoundEnginePINVOKE_CSharp_SetCurrentLanguage_mCA50FC85F97AED294864255689725514DEEC7AAA,
	AkSoundEnginePINVOKE_CSharp_LoadFilePackage_m6934F49AF4A0F492BA628C2E70F1CC13F1FCA081,
	AkSoundEnginePINVOKE_CSharp_AddBasePath_m75FE1EC9C77B62CCF7F04E43E67DA0390607DBD0,
	AkSoundEnginePINVOKE_CSharp_SetGameName_m564B8E316381AD09DB75B8AE0618F1F7707ECBE2,
	AkSoundEnginePINVOKE_CSharp_SetDecodedBankPath_mAF3195F1EAAFB65B9960A8DC24E5259F7F912DF2,
	AkSoundEnginePINVOKE_CSharp_LoadAndDecodeBank_m5F7136B76FE49441FE77B1BBE7EC3BD23778FDC9,
	AkSoundEnginePINVOKE_CSharp_LoadAndDecodeBankFromMemory_mEAC3F71F479D9644491A9E8AFE6D17D178ACBD8E,
	AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_0_m38B88A3EA476F6A4D0E2772512A976A55BCD534C,
	AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_1_m3E7606B76483D42BE01BC8DA9F2345FE75983FB8,
	AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_2_mD301F3964B413BA64EF1D8392BB1F303FC9F5305,
	AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_3_mBB886149EACA859B0E1790AAE05074D9E4ACA15C,
	AkSoundEnginePINVOKE_CSharp_GetCurrentLanguage_m1F1319E062F4E3E1C141282586AF956D3DCC8913,
	AkSoundEnginePINVOKE_CSharp_UnloadFilePackage_m1E1020A6C68D3156940DBBD507F6BBA1C3E391AE,
	AkSoundEnginePINVOKE_CSharp_UnloadAllFilePackages_mC7599F61A96DB355D029A9500D7B7B78DF52EA48,
	AkSoundEnginePINVOKE_CSharp_SetObjectPosition_m42C2CD41D5E766349C9BDB5EBA986AA47587D270,
	AkSoundEnginePINVOKE_CSharp_GetSourceMultiplePlayPositions__SWIG_0_mA8CEFBACD47549AEE90F82F938B890D804782B24,
	AkSoundEnginePINVOKE_CSharp_GetSourceMultiplePlayPositions__SWIG_1_m38873CD2D16A32228EBE9D4CE76863803B85F1F6,
	AkSoundEnginePINVOKE_CSharp_SetListeners_m272FAF7CC0CC72A6CDA6A4F01C4CE5451E30D967,
	AkSoundEnginePINVOKE_CSharp_SetDefaultListeners_mB40014804F991336EDE11782A85BA876006CA8F4,
	AkSoundEnginePINVOKE_CSharp_AddOutput__SWIG_0_m2575DED1E32E55187551201C1B1741AABC5DC6FC,
	AkSoundEnginePINVOKE_CSharp_AddOutput__SWIG_1_m61D2835EBC9497D181A46B067603C6DF2879D2CD,
	AkSoundEnginePINVOKE_CSharp_AddOutput__SWIG_2_m9218105968724275303DC3F0E35854AC45CA0EBE,
	AkSoundEnginePINVOKE_CSharp_AddOutput__SWIG_3_mA214BA3082FB81166926FA3873329CF1E3B32067,
	AkSoundEnginePINVOKE_CSharp_GetDefaultStreamSettings_m8C8B3B9B16D5B45FB2B9AFAD06D36674623F143C,
	AkSoundEnginePINVOKE_CSharp_GetDefaultDeviceSettings_m4FD0A580ECF94AE2D259B3E4AF6AE23BC4AB359F,
	AkSoundEnginePINVOKE_CSharp_GetDefaultMusicSettings_m26404C6FD2E2C3DDB33298E653C146210C9F0BD7,
	AkSoundEnginePINVOKE_CSharp_GetDefaultInitSettings_mE5BE839FA7DAF6C6BD0A42CAA42B640B6DE890E6,
	AkSoundEnginePINVOKE_CSharp_GetDefaultPlatformInitSettings_m6E51299D36934822341AABF0645F06D671536895,
	AkSoundEnginePINVOKE_CSharp_GetMajorMinorVersion_m29668FC17B0028AA0BC973817D3F5E01A4EBD5B8,
	AkSoundEnginePINVOKE_CSharp_GetSubminorBuildVersion_mE8C62F6FEF1E8154083D8A3A775F4E78124C88F6,
	AkSoundEnginePINVOKE_CSharp_StartResourceMonitoring_m8C6C468B5135AE21F907841E822FBFB0563B5E93,
	AkSoundEnginePINVOKE_CSharp_StopResourceMonitoring_m01D00EA06E51C17A0552D20FB4D3C6A3E756DEDC,
	AkSoundEnginePINVOKE_CSharp_GetResourceMonitorDataSummary_m9AC8D1F10682BE6785F0BB045D08672DCDA6D31C,
	AkSoundEnginePINVOKE_CSharp_SetRoomPortal_m8D8DF85B11D6019541CC499E9D7CE1A8B22A2BD7,
	AkSoundEnginePINVOKE_CSharp_SetRoom_mBE8D2179088554999E2514B50350952ABF84C6CA,
	AkSoundEnginePINVOKE_CSharp_RegisterSpatialAudioListener_m3C56A4FADC83779A4F6F47BE93EBF27CDB78FBC8,
	AkSoundEnginePINVOKE_CSharp_UnregisterSpatialAudioListener_m78E1FA6CF743264AAE9DB3CD4F18BA1D5E87ADEB,
	AkSoundEnginePINVOKE_CSharp_SetGeometry_m9C35BCB21E97641C0E1CAEFC5FBB45F704DDB65F,
	AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_4_m6D2FF5D956EADB64A80E4FDEFD2476F24ACE4816,
	AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_5_m98E7F6B36367D73940D5FBBA538E3CC266532A20,
	AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_6_m4E28BD26E96A393104A963D8F533BF9C59A73D3A,
	AkSoundEnginePINVOKE_CSharp_PostEventOnRoom__SWIG_7_m13A0037EBFA01558A9A8AE1978771B8D4633BCCD,
	AkSoundEnginePINVOKE_CSharp_AkPlaylist_SWIGUpcast_m6AEFA5A30ED8AC76E3F5B7C7A50E0DBE06127B56,
	AkSoundEnginePINVOKE_CSharp_AkMIDIPost_SWIGUpcast_m5A8944C6B7565ED0FF24BF32BE8AA6AA6AEBC2DA,
	AkSoundEnginePINVOKE_CSharp_AkEventCallbackInfo_SWIGUpcast_m1862D28D4EECC82E8BD279F11CB1CAC836052EF7,
	AkSoundEnginePINVOKE_CSharp_AkMIDIEventCallbackInfo_SWIGUpcast_mC5C9E688014D3E2C2735CAF748F9DF24D915AEAC,
	AkSoundEnginePINVOKE_CSharp_AkMarkerCallbackInfo_SWIGUpcast_mE6EFE30EFE41698181B6C24537747A9249D63A19,
	AkSoundEnginePINVOKE_CSharp_AkDurationCallbackInfo_SWIGUpcast_m8984C9C351F706BF44130F6070DF958E9F7E4896,
	AkSoundEnginePINVOKE_CSharp_AkDynamicSequenceItemCallbackInfo_SWIGUpcast_m7A4BE1F2C0F8FB1AF31212183E936B19AFF8CBBE,
	AkSoundEnginePINVOKE_CSharp_AkMusicSyncCallbackInfo_SWIGUpcast_m1FDA60723B08468276164561F00049A998101FBF,
	AkSoundEnginePINVOKE_CSharp_AkMusicPlaylistCallbackInfo_SWIGUpcast_mD93C3EE7D2A628E6BDEB366F93DB1383C36B8718,
	AkSoundEnginePINVOKE__ctor_m5EDA6A97C30248A81AE8403CC75D2BC1AEB25E7E,
	AkThreadProperties__ctor_m68FB5DD35372D5E59C55624B891F6C1069FCA63A,
	AkThreadProperties_getCPtr_mE179538CA24EC5EA946902A7BD6003FBE39512C4,
	AkThreadProperties_setCPtr_m6E2743DEAEC5A7EFD6AF639202449F555F8E02D3,
	AkThreadProperties_Finalize_m9462629FA8565D01840AB5B1C1C0DBBE3FAA52F4,
	AkThreadProperties_Dispose_mFB81FB3F1392DF9FF3DBEF3DD8B30766203ECCDD,
	AkThreadProperties_set_nPriority_mF425446CB56D86D6E12CE4A3762B939514E54E0E,
	AkThreadProperties_get_nPriority_mDEA865CFDFF8E199C96039E5C0EBF78D0B1004A8,
	AkThreadProperties_set_dwAffinityMask_m30B6B5F76B9B584C03F3457C5C1938FEE4B371F4,
	AkThreadProperties_get_dwAffinityMask_mB8C72F6955C8C5E7C1D60FEA27F775A00FC45647,
	AkThreadProperties_set_uStackSize_m43A99513848D580C1FC17684ED0B4726F0F7961B,
	AkThreadProperties_get_uStackSize_m4D1F327C1C760D2DDA9A5210457819BD61F6D77D,
	AkThreadProperties__ctor_mF18E611850AC8B66957F4DDE33424C0CA8C05D3E,
	AkUnityPlatformSpecificSettings__ctor_mF41C9776D3F48F0ACE9E52572ABE43E89E26E9D1,
	AkUnityPlatformSpecificSettings_getCPtr_mE3FA3A16724A5CE8AE44A026BC036BC0E332AC27,
	AkUnityPlatformSpecificSettings_setCPtr_mD1305B3E9CC81E9CF0E88F9D204EF86BEBB761C1,
	AkUnityPlatformSpecificSettings_Finalize_mB318CA860E8B6C8723C7026961D8F2B584668302,
	AkUnityPlatformSpecificSettings_Dispose_m22CC518233AAF8E090D453E925CDA864261784E5,
	AkAudioInputManager_PostAudioInputEvent_m3DACAD19669F1E935D6452EE2B5E726DF0B55A39,
	AkAudioInputManager_PostAudioInputEvent_m7DA318CBF68F49E058C094DD5BBEFD49923C29B4,
	AkAudioInputManager_InternalAudioSamplesDelegate_mCC8ACFBA434E55CA478271AC70312599C48729D8,
	AkAudioInputManager_InternalAudioFormatDelegate_mE65C58A009B2CCE12BF2D66527E4DBA94359AE2F,
	AkAudioInputManager_TryInitialize_m6152025586F44B67D0E11CC63B6EA4182A9A6469,
	AkAudioInputManager_AddPlayingID_m93C8EECFA27F42CC254C0027C5BC6195F38242A9,
	AkAudioInputManager_EventCallback_mFF401B177FC074D2DBD6F062B472112838ACFBFA,
	AkAudioInputManager__cctor_m0D6D922E7D4D3243DE40FFCF43C8911701368AE0,
	AkBankManager_DoUnloadBanks_m5A1C59BE48FF8D81A4C1F62BBAEA3E6E84A6477D,
	AkBankManager_Reset_mD18059D585802F4578BE52135D22C1968D499961,
	AkBankManager_ReloadAllBanks_mAECBEF2E4321CD8DCFD7EE650F69153DDD131E2C,
	AkBankManager_LoadInitBank_m520C83FABEE8871F69548C2099FBC176C1010B91,
	AkBankManager_UnloadInitBank_mA0EB0194C1B805BE7C32680B0F494DEAFF38F816,
	AkBankManager_LoadBank_m2FCDED8CCBE26E9012699F88428103CA152FFDB9,
	AkBankManager_LoadBankAsync_mB0619AEA4718877300B46F9110C9E96C1041A5D8,
	AkBankManager_UnloadBank_m9403088BE5722AE8633024748E68EA2B3542FB28,
	AkBankManager__cctor_m5F7502D173CAD5CFF49831283C70E7FA945E824C,
	AkBasePathGetter_GetPlatformName_m5B6056F1A006F5D49F680D0DA0586D1073D05BF4,
	AkBasePathGetter_get_LogWarnings_m5370B844E65A0C5FA7C717FEDB8662C6E926B8E5,
	AkBasePathGetter_set_LogWarnings_m52AC1ABC184B8130AB4B1C57B0E5C9E6D6A97D65,
	AkBasePathGetter_GetPlatformBasePath_m8A61E9AAD685D6C3D5372A5AEB53A84907A1FC45,
	AkBasePathGetter_EvaluateGamePaths_m6FC8522650BC981090205D45E0B9BDBC42AD3621,
	AkBasePathGetter_get_SoundBankBasePath_mFF37914305D82413A6C5E4C7BEC774971FBF37DC,
	AkBasePathGetter_set_SoundBankBasePath_mCBDB3C66B5841313F1DC37A9345A10A5D8EA8C16,
	AkBasePathGetter_get_PersistentDataPath_mA4694BE2FC23EEA6CE1C6A54D5CB2F4DD3F0C06D,
	AkBasePathGetter_set_PersistentDataPath_m5567799489F0E42B7D2371CAB357EA214DBDC11A,
	AkBasePathGetter_get_DecodedBankFullPath_mE1FBE73F6FD2318F7FE1D086375D1C6339C2318D,
	AkBasePathGetter_set_DecodedBankFullPath_m0AE2D4A3720FFA0E48F1CB4A3880DC3EA2A9D8F5,
	AkBasePathGetter__ctor_m55832DAC85D4A872CC404481281C9307D0F723EE,
	AkBasePathGetter__cctor_m8E0383BD80196D3007236E8BD5F3BCFA95217867,
	AkCallbackManager_get_IsLoggingEnabled_m747B56368C4A653CB85919E99FC1352C5372B349,
	AkCallbackManager_set_IsLoggingEnabled_mB3E093A8EFC5199C3FA0C8C3BEF3E851BC62125A,
	AkCallbackManager_RemoveEventCallback_m4904775CAC14A41BE5A819B12D1511DA1FA14D87,
	AkCallbackManager_RemoveEventCallbackCookie_m5759FC16D1B084B4B66695C480D2153567B4AF95,
	AkCallbackManager_RemoveBankCallback_m7728A8D046B1E8BFB5C18F80CB17170D72D92C18,
	AkCallbackManager_SetLastAddedPlayingID_m48467303044E493244505E875567C37617E33053,
	AkCallbackManager_Init_m3F3B56B493F15FC320D6A8C0AF23B0F81EA8C1FD,
	AkCallbackManager_Term_m72C2BC7F8410479B9991175247378E07FA57AD20,
	AkCallbackManager_SetMonitoringCallback_mACCE793124EFEE77BF7E1C0980DD6A30C15080C5,
	AkCallbackManager_SetBGMCallback_m0BBBE911E54745247F33E75A9A83121DF14181F7,
	AkCallbackManager_PostCallbacks_mD1DDCD4320730A9D510CD38DC6ECFEB930FF3F9F,
	AkCallbackManager__cctor_mA6744AE1AA229C05E3067DE7B2C99DE859F88B67,
	AkBasePlatformSettings_get_AkInitializationSettings_mF8DC5CCD8A11C78843814542E4C7F7E8CF365299,
	AkBasePlatformSettings_get_AkSpatialAudioInitSettings_mBC8B617C274C3429781243D47C76248D2C606B4D,
	AkBasePlatformSettings_get_CallbackManagerInitializationSettings_m2A28AC2C1A78C944BA969B28F861F5895FA26BEC,
	AkBasePlatformSettings_get_SoundBankPersistentDataPath_m325C39CD465D7363383AB38DD49BAC9C266F3FED,
	AkBasePlatformSettings_get_InitialLanguage_m5BE09F487A79A07C0E002E2E178A86B3351E9453,
	AkBasePlatformSettings_get_RenderDuringFocusLoss_mB20AC116B0555D0D4AE45E2528CB682EB173586E,
	AkBasePlatformSettings_get_SoundbankPath_m135AC92BE0A1715E568F6373F8DDD47E6DD18B32,
	AkBasePlatformSettings_get_AkCommunicationSettings_m3E06F499A7FB4554BC2F768F1F700146BC62414C,
	AkBasePlatformSettings_get_UseAsyncOpen_m91D8A83BD7556E9CC23019D7AD94D664D7BC8F8F,
	AkBasePlatformSettings__ctor_m11C22C7D79830B8858541CB9711A6CACC0A5A1CA,
	AkCommonOutputSettings_CopyTo_mBFC4B2D3A3780E6C5560F168607D9A515F0AF20F,
	AkCommonOutputSettings__ctor_m8E8483E9FA3E153308674BE84A190B3FEE965631,
	AkCommonUserSettings_GetPluginPath_m35131B8053333A7DAC9EBA011B56BD8ECC87001B,
	AkCommonUserSettings_CopyTo_m755F95E2953EE469529F53914C008AEDB9A90099,
	AkCommonUserSettings_CopyTo_m22E111D528FE6CB643832AD54B2A3D058CB55F02,
	AkCommonUserSettings_CopyTo_mBA2147CDA01F088919E470B631947AE3726C8452,
	AkCommonUserSettings_CopyTo_mD1238DDADE1198DDCBFE185D6A55AB5D3B549E8A,
	AkCommonUserSettings_SetSampleRate_m96F55180D65227D9D877BC9D68940A1CA5367C00,
	AkCommonUserSettings_CopyTo_m396F597D4DFC2C07BC008D108032F712FCD94390,
	AkCommonUserSettings_CopyTo_mBB89CD013082F60521429F68FACE5EFE98800036,
	AkCommonUserSettings_CopyTo_mF8171036EBD3BCB224D8666A598B06A2D826A95F,
	AkCommonUserSettings_Validate_mB418D5C6D89D226D77946A7CE8077958940D401E,
	AkCommonUserSettings__ctor_m593D8225F5CE79C4ED37EC23459735B911CC43C8,
	AkCommonAdvancedSettings_CopyTo_m2DE2246EABCD4AB5C30673AE4EA3D6B40624A0D0,
	AkCommonAdvancedSettings_CopyTo_m6EDDDD3C7A1E8507EF57550D4BAB8180FEEF5FD7,
	AkCommonAdvancedSettings_CopyTo_m010250A32CCD4FF7BDEF95953819E67C586BA805,
	AkCommonAdvancedSettings_CopyTo_mAB2693F2D3F70071CD816F64FBF2A6E35AD06286,
	AkCommonAdvancedSettings__ctor_m462DBC7E0D14B54C55783D18D1EC3E6B4DBD1A07,
	AkCommonCommSettings_CopyTo_m857E7F597EEC0217D7B4FF0DA3E8353DECC507A0,
	AkCommonCommSettings_Validate_m71E12AF8552FD41AD18057817C76F9BD627FE551,
	AkCommonCommSettings__ctor_m5FD6925417E746A998076939D3996425BD85F5C2,
	AkCommonCommSettings__cctor_m68E62D5BE7995925B8172E8697049F6307B49FE3,
	NULL,
	NULL,
	NULL,
	AkCommonPlatformSettings_get_AkInitializationSettings_m20AD5A940DD50BA40716BF8B1B921D25C1F27E5A,
	AkCommonPlatformSettings_get_AkSpatialAudioInitSettings_m458D2A3B0BA7FACC8C8D1A037B93CA68A604B086,
	AkCommonPlatformSettings_get_CallbackManagerInitializationSettings_mDB7719F782946466BA24F9D51166AAAA7B94784E,
	AkCommonPlatformSettings_get_InitialLanguage_mE611A9617BF895865869E9AA0775DD187A8A2A22,
	AkCommonPlatformSettings_get_SoundBankPersistentDataPath_m00B99FD30F5569B138648324D97D49C3AD5E7D8E,
	AkCommonPlatformSettings_get_RenderDuringFocusLoss_m873AD4FE9B86DDF19BC1BF9B774400A089A4088E,
	AkCommonPlatformSettings_get_SoundbankPath_m1038DF225B1B3EEFEE6C166B5E6EAAF4D73F923A,
	AkCommonPlatformSettings_get_UseAsyncOpen_m31C94249938FC5B8C5C927D8B1B91D6DDB6F2E25,
	AkCommonPlatformSettings_get_AkCommunicationSettings_m79DF1B391C4EC98150A1DAF29CF943CEA01EA162,
	AkCommonPlatformSettings__ctor_m6677F3BE8ED33C74C0A87E8A92F83F351C5151C2,
	AkEnumFlagAttribute__ctor_mB576291CEF8DDADB9F11862CE9EB6162606D626A,
	AkLogger__ctor_mFB694A090E52BDC67C4DDBB9CA7994A89F305BBD,
	AkLogger_get_Instance_mFAA1F4D1F73B3E58F1318E4F400BDDB3B4B4B111,
	AkLogger_Finalize_m39137B18876DBDA1B1DFD0FF5F052BE4FA6B9696,
	AkLogger_Init_m18A46EAD20BAE9AF7A1599CAD5BA57A9F4D135FA,
	AkLogger_WwiseInternalLogError_m74B4525C94A2B9D382CF3025E8B7AE1CBE92EA8A,
	AkLogger_Message_m215F343D0F5A090192D4EC152E7DA5862A78466B,
	AkLogger_Warning_mE93F27F246C4B6F4E807A1A5A2EBE1F7649D4EF7,
	AkLogger_Error_mE29B2156E521C9C134F92F937CFFD44A381608B8,
	AkLogger__cctor_m0A405E34989E06C75665F7BF26642E3501188AC7,
	AkShowOnlyAttribute__ctor_mBEF724F5E2DBE9829879733367E315763B21A0C5,
	AkUtilities_FixSlashes_mA0743D33CAC05020465751B0019718C69DF4E9C5,
	AkUtilities_FixSlashes_mB334E8159887FC2BA232AB25DCFC38B7571BF5AB,
	AkUtilities_GetPathInPackage_mA932A5B99B5773048356F649D3820433C3ABA34C,
	AkUtilities__ctor_mE963EE8469289270C6245C4D440B046B18FD9B95,
	AkVector_Zero_mFCAE57AE094FDE2AC58B7B9DA42B418C5836AFD7,
	AkVector_set_X_m6B3A9C5A7B395D3B65A94FBE82811ADE336CE437,
	AkVector_get_X_m2ECE56E65C77131BE9AEC5C3EA9F24E4E3A0F20E,
	AkVector_set_Y_m54129B134C34D2DA8E729062D3507791F9D1BA2D,
	AkVector_get_Y_m20BF983A1E113D50600FE308AA795D378B9F33E3,
	AkVector_set_Z_m2B4EF55114D6C4C7C580A1584962B0528E842A8B,
	AkVector_get_Z_m3BC08A869D45D3E00C75DFF05DAA32D0539F31AB,
	AkVector_op_Implicit_m2EA3A8F2DA43F97EEF626213FCA051CF587C2695,
	AkVector__ctor_m3EBFF473ECA73553A3413B2EA675638145DA9BBB,
	AkVertex_Zero_m9EADA834FB0956E15ACED8D0EF21AB58931797FF,
	AkVertex_set_X_m34B7C25FBD05F7C287663C6525B02BF1725CF48B,
	AkVertex_get_X_mDA0462C5A59588C2CA05C3610F233B5E3FF89144,
	AkVertex_set_Y_m300FDF1E5000A819872515F52E8C15482BC99B9D,
	AkVertex_get_Y_m4B629761B224C778A1222B031460C087DB0E6F7E,
	AkVertex_set_Z_m9BDB8CBBE1B2B1B14E87036A5A4468026C33D132,
	AkVertex_get_Z_mDB8C6082A12E70B1BEDEED47310A21891ABD79B0,
	AkVertex_op_Implicit_m551F2293DDF4D6A62B5531A5A9E770A0AB2B8E96,
	AkVertex__ctor_m2C3F33BCA3E6623D4B8FFB52DB1C2BAAF9C90B70,
	AkVertex__ctor_m318ABB5D37113E249747436197EB1630D6E7B525,
	AkVertex_Clear_m5CCC6157E7554BC3C1176DC3A35AB45834A39E05,
	AkVertex_GetSizeOf_m027E4C8CE2D36A9390CF2C368E23BD278A08323E,
	AkVertex_Clone_m40681415E2A8A76506117A7247C68A2F530A5E85,
	AkVertexArray__ctor_m2F2BF210C5C3B6750F16396821113BA793FB1987,
	AkVertexArray_get_StructureSize_m2550E15C5855E683E252BC8337F82E4B874C315E,
	AkVertexArray_CreateNewReferenceFromIntPtr_m5654D2FEB6F076A2B099C3EA858816B4F05FBEA7,
	AkVertexArray_CloneIntoReferenceFromIntPtr_m7F3A4D7CA6C1FFA51151BE50900B87E858D5B332,
	AkWwiseInitializationSettings_get_IsValid_mC25AC4417E256701AC45689504123E26FBC1B488,
	AkWwiseInitializationSettings_get_Count_m52BD1806B0C99740C92724849743852D7A52B1B6,
	AkWwiseInitializationSettings_GetUserSettings_m7E445567B7AA9E05A45444AE98EFFA2F0D6977F5,
	AkWwiseInitializationSettings_GetAdvancedSettings_m75BC8A846DD4B7CD8A18E0EBDDCFB7147252E9C5,
	AkWwiseInitializationSettings_GetCommsSettings_mE11B0655D91E5D44AECDE291DBF98185971F102C,
	AkWwiseInitializationSettings_get_Instance_m6E6FB63FA5E48DF5452447107F3363D57B7974D8,
	AkWwiseInitializationSettings_GetPlatformSettings_mC4936C945D36BE10EEA8546EB4FD20EADE3802AF,
	AkWwiseInitializationSettings_get_ActivePlatformSettings_m0B310444793AB12260C0FC8339EB7D82CE925C14,
	AkWwiseInitializationSettings_OnEnable_mDE6578AEBADCA5449BE8B069B1B91C33521491F4,
	AkWwiseInitializationSettings_InitializeSoundEngine_mD3E127DF97C7704A311BBE1B11F122CAE19A2E4B,
	AkWwiseInitializationSettings_LoadInitBank_mC6F30BC60D6D9CD98A0A3DA43E87BB73A3CB8EF7,
	AkWwiseInitializationSettings_ClearBanks_mC07824E6D1FA0679D69CDFCC867C4081C7117434,
	AkWwiseInitializationSettings_ResetBanks_mDA9BAA324B3FD9CBC9970769AB0D211423873B4E,
	AkWwiseInitializationSettings_ResetSoundEngine_m5F5F77BEDFD0D9143A6E212A648568560A248A74,
	AkWwiseInitializationSettings_TerminateSoundEngine_m0236F55ECF2973E4490DD05099865593E08E8A0D,
	AkWwiseInitializationSettings_SleepForMilliseconds_m7292C0FD27A810D44F5C3375D3DC5D4DD9CA9F9E,
	AkWwiseInitializationSettings__ctor_mF696F4D9DE9F2E0755944A483E6673959810ADFE,
	AkWwiseInitializationSettings__cctor_mBD1E8D0EE71CF82F28771D814DBCB19DF86405AD,
	AkAcousticSurfaceArray__ctor_mFB01E32E3367DB49C6BE86D9390A6692B6A719B9,
	AkAcousticSurfaceArray_get_StructureSize_mE6101C8DF3767C6F116341B6D4E66AEFD765150F,
	AkAcousticSurfaceArray_DefaultConstructAtIntPtr_m6BD558FBBAF254AE74B2E164E579D6C6ED253101,
	AkAcousticSurfaceArray_CreateNewReferenceFromIntPtr_m881A879B41F35DF16178D6373A665EE72FE096D3,
	AkAcousticSurfaceArray_CloneIntoReferenceFromIntPtr_mE9F99459B3E6FE4C66AE26D965B1F9F3E3DD519D,
	AkAuxSendArray__ctor_m2CC55DBE0CE4988F5B6221F2E4975C74DFA9DE4B,
	AkAuxSendArray_get_Item_mA0BCF03E5CAFDAD341C17B9D1F0B6F7B66FB59D9,
	AkAuxSendArray_get_isFull_m6C3C7E9938B4FF760F110701C83C493FFEBD19EE,
	AkAuxSendArray_Dispose_m5F8574B54A165EC206E91453AAD05907AB66C2A7,
	AkAuxSendArray_Finalize_m8BB0B410D23E99C8EE553FE96EC555ECB0E6A370,
	AkAuxSendArray_Reset_m82D457CD9D77A0F7E3481C5C4A003BC22077F07D,
	AkAuxSendArray_Add_mC8F9C0BACA0C54F85D47F9A14C4882FF2D93B003,
	AkAuxSendArray_Add_m0130263D8274B5A73B014595A7CE9FD6EDB790EA,
	AkAuxSendArray_Contains_m57C6986BA08D9A94649279E5D5597212E5ADECDA,
	AkAuxSendArray_Contains_m59668BE9FB75EC174A8481D42E0102640A7E556C,
	AkAuxSendArray_SetValues_mA58AC0E878ED32CFAD1665C8B64A84373A93D64B,
	AkAuxSendArray_GetValues_m44062710BD760F5947B97A55F2775BBF57898270,
	AkAuxSendArray_GetBuffer_m3A1829A42DA19A3ECBA04C1C5BF26BC421F95AEE,
	AkAuxSendArray_Count_m3B071A1EC18E11E1F31658988E65572E4207E385,
	AkAuxSendArray_GetObjectPtr_m304DFF898EA8A6699E7C608A6C831839ECE78CA9,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	AkChannelEmitterArray__ctor_m63B72D3DBB381CDA0DFB1677BD8E4D8AC2BCDA48,
	AkChannelEmitterArray_get_Count_mECFF4AB75A258C161EA9FBD3EDDB946AFF3244CF,
	AkChannelEmitterArray_set_Count_m1922B570DA1A40D8E7C87A92566E1BCDFC23D54A,
	AkChannelEmitterArray_Dispose_m36F114D62F3B238DC9534C6E2940DA4E7F442E70,
	AkChannelEmitterArray_Finalize_m2DB38CDE7CE2259449E5B66EF222E5BE499140B0,
	AkChannelEmitterArray_Reset_mD53F20CFDFD92963629533EF282735F895242796,
	AkChannelEmitterArray_Add_m47EFA9678BD96F657221DF5057A206B87E751986,
	AkDeviceDescriptionArray__ctor_m3DC91301ABAC77194D02AAAAA89D945E5FCDA734,
	AkDeviceDescriptionArray_get_StructureSize_mFB5B17D28324B689264FB2C657552537D4AF5C0C,
	AkDeviceDescriptionArray_DefaultConstructAtIntPtr_m365D24254CFB386E8BD9B9C75BE0C129E88D9904,
	AkDeviceDescriptionArray_CreateNewReferenceFromIntPtr_m7F2565E85AC6B55B49371F0AA061161C3746177B,
	AkDeviceDescriptionArray_CloneIntoReferenceFromIntPtr_m507146ED5FF33208419AB1159ED2D34E10F6D1B3,
	AkDiffractionPathInfoArray__ctor_m5870A0095AB3EB37BBE047914C651B69BDEA4B93,
	AkDiffractionPathInfoArray_get_StructureSize_mFC9D4E45C28D855E6CDD68DAD394CBCE671DE43A,
	AkDiffractionPathInfoArray_CreateNewReferenceFromIntPtr_mFAF76507F219F20D477F112764652A21CFD6B9AA,
	AkDiffractionPathInfoArray_CloneIntoReferenceFromIntPtr_mEAE294D36604AA64F562827D902CE6E7045A6694,
	AkExternalSourceInfoArray__ctor_m49432949AB060DE6F3DCE44D0E38B046C5273135,
	AkExternalSourceInfoArray_get_StructureSize_m9F8FC9ED4DBB6E31D04F8705C159D512EC12E86F,
	AkExternalSourceInfoArray_DefaultConstructAtIntPtr_m9898F8A9D889A6552F4EE4954CD826C726ED1567,
	AkExternalSourceInfoArray_ReleaseAllocatedMemoryFromReferenceAtIntPtr_m316DA1BFBDEBD18EEAF4296EE5A3F5310F8356E8,
	AkExternalSourceInfoArray_CreateNewReferenceFromIntPtr_m50B0A42A19B41AEEF24D4553EEF60A0E0AF4A70D,
	AkExternalSourceInfoArray_CloneIntoReferenceFromIntPtr_m5CF791D5962130F972DEE26F1EE0284371A0C813,
	AkMIDIPostArray__ctor_m42B1CEA21201A93C91DDD89E202EA7153FF73F86,
	AkMIDIPostArray_get_Item_m4B16DB53F8970AFE08031B126C5F913E42C437F3,
	AkMIDIPostArray_set_Item_mB38DF3927B096DE29F531461642C7E82F4B06AA6,
	AkMIDIPostArray_Finalize_m49E30F77C094B7BEF1F4481D42696C2701A7481F,
	AkMIDIPostArray_PostOnEvent_m66EC148F3ABCB245B84A636549488C4ACFF6FD4D,
	AkMIDIPostArray_PostOnEvent_mFA194E3A82334997EF5B4C7FFC44ED64668CBE79,
	AkMIDIPostArray_GetBuffer_mE90D18001F03BCB84107423C32CEDAB8FC0D9DB3,
	AkMIDIPostArray_Count_m404ACDFB587655E03A42837AED589ED9228BCF86,
	AkMIDIPostArray_GetObjectPtr_mEA27EC60CD0E4F5933B6E99D97F31096288292CF,
	AkObjectInfoArray__ctor_mE638E5B2551282C1DDFD1412908CBDAD48529B32,
	AkObjectInfoArray_get_StructureSize_mA6CE34433A5DF2210A7867125A24A50A6987E391,
	AkObjectInfoArray_DefaultConstructAtIntPtr_m4DA52E071AB2F8F50FDE23D64980A8F741ED376E,
	AkObjectInfoArray_CreateNewReferenceFromIntPtr_mD5E42F280B800F36EA8D44FDC794516EFC2D8EB4,
	AkObjectInfoArray_CloneIntoReferenceFromIntPtr_m9299C579512EFF3F873D7A4D4B1F64363DD3F54A,
	AkObstructionOcclusionValuesArray__ctor_m4F681ACDB369D85A25A2365D6B81A653118EDB78,
	AkObstructionOcclusionValuesArray_get_StructureSize_m47AB19A8E6FBFA7D8FB0B4BE3E88B64E7A750FD2,
	AkObstructionOcclusionValuesArray_DefaultConstructAtIntPtr_m943659761634AFA044564E73DB3B9BBC4CAA01C6,
	AkObstructionOcclusionValuesArray_CreateNewReferenceFromIntPtr_mBAE5CF74CC0700B1C2D776DF77A1B7E46E82C054,
	AkObstructionOcclusionValuesArray_CloneIntoReferenceFromIntPtr_m02C4ADC7608E9ECE549C50F07552CF55B973B2D1,
	AkPositionArray__ctor_mDBD619966527FE9A680E70FFA5DB806ABF6D0384,
	AkPositionArray_get_Count_m36D2BB7C64B6B913D5EF1E88F8374E079CDFB780,
	AkPositionArray_set_Count_mEA3274A0672D52D690E3443DDD332C5E72606A92,
	AkPositionArray_Dispose_mA7A51D8147C23C806BA0609E7D43FA71F39E0D86,
	AkPositionArray_Finalize_mB2FD5C94858BEEC95FC3EA052F070595550E22D8,
	AkPositionArray_Reset_mCBFB27259756774AD5955801D4BE7AF7F0B21CEC,
	AkPositionArray_Add_m92B7D8F91A43E0417FF5CC04776B1D470CDF91A4,
	AkReflectionPathInfoArray__ctor_m01635A85C9EE987415065062390F6D29DE4FCA95,
	AkReflectionPathInfoArray_get_StructureSize_mB54901CF97FA0D19C3944A744A0CFF76BEAF8732,
	AkReflectionPathInfoArray_CreateNewReferenceFromIntPtr_m33EF46DBAD88331306F282E716582D65D6E9C750,
	AkReflectionPathInfoArray_CloneIntoReferenceFromIntPtr_m00E59C43A8667C174134659A8A7AC1BE47ADE2B4,
	AkSourceSettingsArray__ctor_m6FA8739924BB2E8501DB32B1474AD33C486D8480,
	AkSourceSettingsArray_get_StructureSize_m5191F056647DCFAF521115AD2D4AEDEEFDA0144D,
	AkSourceSettingsArray_DefaultConstructAtIntPtr_mABE845681DFF04332364F42B5C00C4C00B094D51,
	AkSourceSettingsArray_CreateNewReferenceFromIntPtr_m73980A42690C971527ED3BC3A42E9BA22D93F868,
	AkSourceSettingsArray_CloneIntoReferenceFromIntPtr_m4F5E129B34788867E25563150D03A56BE315E544,
	AkTriangleArray__ctor_mFB8C29919EF377DA27A2D2C884822F691BEE00A3,
	AkTriangleArray_get_StructureSize_m62BC1DAC02180D51AA7F8EAA9009F5E6ACF674FA,
	AkTriangleArray_DefaultConstructAtIntPtr_m4F68267CAF24FF6FFC59BC3F9C00608D208A08E5,
	AkTriangleArray_CreateNewReferenceFromIntPtr_mC6A7291A09B5DDA03A65E9BB3D9E7EDF0663E7CA,
	AkTriangleArray_CloneIntoReferenceFromIntPtr_m247D08E75488EDF12ABBC9DA6594944C5425B240,
	AkMacSettings__ctor_mE0F543B25AF80416B555C41C4819D1E1EB968FBE,
	AkWindowsSettings_GetUserSettings_mCA039A4E7850B4519A51419BEA4DCF79DA77EAEB,
	AkWindowsSettings_GetAdvancedSettings_mA3A9F187A00EF0608EF42929028B296C79A1769B,
	AkWindowsSettings_GetCommsSettings_mCE2699401C92309886E167E42478BAFE0BF6FA27,
	AkWindowsSettings__ctor_mF108F8FBB74666C60128BFFD74CDC021DD6D9294,
	AutoObject__ctor_mB48CB2F40528061C9D44D21EEEEE765DAED76407,
	AutoObject_Finalize_mA227CA7A221B6EDC16E8F6E9C128973FEA7044CB,
	GameObjectHashFunction__ctor_mE328C3AAB1EBE1DF80C6A536406EBF65D8DF4933,
	GameObjectHashFunction_Invoke_m31ABA413190DE167D940BCFBA02278355BECF61C,
	GameObjectHashFunction_BeginInvoke_m44C28348EAE2EBAA88D3701B10603B5BC970ADD3,
	GameObjectHashFunction_EndInvoke_mDEA01AA6171097AA4A96CAF9A59961EB7F4869F1,
	tGen__ctor_mED34BE8A990C0E6240BDAC04BC23F41875330473,
	tGen_getCPtr_m54170BB5F74F1C863D9CB99B3DC59ADBB855BF9C,
	tGen_setCPtr_mAB7852F0FA11FF0E041A0E65EE45623E54D3D2FD,
	tGen_Finalize_m37D540E4D6423AA2B3C07E05E0DB0FC4EDDC1107,
	tGen_Dispose_m94F5978702922F44C8F9ADBD149749373C10B19F,
	tGen_set_byParam1_mA08AE2D401A0C46803252BA755A095153C4DF85E,
	tGen_get_byParam1_mCB50441CBDBE4D57C486EA10BF1829A0A466D302,
	tGen_set_byParam2_mA5E3666E4C5DF5048E189A6350B1AE16FAFFCFE3,
	tGen_get_byParam2_mB8B3881B9568E4F763277047E3050B0122927B48,
	tGen__ctor_m0CB778707388BA33C33C899982BE9B9E9CA32F70,
	tNoteOnOff__ctor_mF23EB7EA2679622A3A10B95212A8DB5D96F362CE,
	tNoteOnOff_getCPtr_m3B13CD49D75FF24CF36A1611C7E169DC247205A4,
	tNoteOnOff_setCPtr_m28E41CE03A56800D6C6029AC48463166814F2C50,
	tNoteOnOff_Finalize_m0046B44C2CC5EAE55690415231BA477547CB1DBD,
	tNoteOnOff_Dispose_mA754D5D64309A610606D4BD07C740256F2151299,
	tNoteOnOff_set_byNote_mE0D0913EAAB01A05F1DADF82814CD9DA340298E1,
	tNoteOnOff_get_byNote_m152BD0BC61BB62DA736D88C0DDAA244166E129E0,
	tNoteOnOff_set_byVelocity_m140620BB96A246DD69B5545180E75A1546846D6E,
	tNoteOnOff_get_byVelocity_m4F208DDADC70C64CB8F08E23A31EFF8912AD891D,
	tNoteOnOff__ctor_m5406A71A45F002C7A44D6DF2ABE31013A319111B,
	tCc__ctor_m19E9B9504668AD5C85E36F27841517664C938624,
	tCc_getCPtr_m616346F39B42CA61C6F886AB562F10E0D0F50AF8,
	tCc_setCPtr_m8F86AA5B0434CC6621ADC0E6B0ED37AEDEF7986E,
	tCc_Finalize_mC8F7BFFF8B9EA8E0BAA81B65AAD7FD2E62C84E9D,
	tCc_Dispose_m53DF723295194FB0E770AC4BCC16645A8CC2B2D0,
	tCc_set_byCc_m89CC06246354724EC3F12E359D5D5E6654E2A0C0,
	tCc_get_byCc_m109126C525D3EBDA51792654F9A8E2A672ADA5E8,
	tCc_set_byValue_m679439CA37E0D8E2439DED569AC0E7C59DBE7D13,
	tCc_get_byValue_m19E8B49C9E1AAB0297AF826E0571EA188287FD16,
	tCc__ctor_mD575E0AD96428A9C8EEBC374EAF1882244301FDB,
	tPitchBend__ctor_mA9332CDB7FDCCF50649A8C358A50B7F34498BB33,
	tPitchBend_getCPtr_m53CF450D3B6074F58D5ED25016259B3F56C1A26A,
	tPitchBend_setCPtr_m16DFBFA4A573FEB9525702FC7BCD7F2C79DEDDB9,
	tPitchBend_Finalize_mA3D48D6B394FDED23465F9FA9DFB5EF0D767720F,
	tPitchBend_Dispose_m51CE0BC17AD136D8BFCF2523553ECC219BCCF72E,
	tPitchBend_set_byValueLsb_m26CB84EEEA5703A61B03F2424D4F9454457AADAC,
	tPitchBend_get_byValueLsb_m9CEF30CB9830E99CC2F2F156D7AF6C696BAA8770,
	tPitchBend_set_byValueMsb_m1A82344C6B8C7AFC6D4CA6687B95DC76D8D98570,
	tPitchBend_get_byValueMsb_mE6537FA35FA55FEF2368873CBA439243C351B1C5,
	tPitchBend__ctor_m4C7E99A9AC201BBECB7153EE10934F87676C20EB,
	tNoteAftertouch__ctor_mA01146E6AFAB2F68174BECD9331B313E15E78606,
	tNoteAftertouch_getCPtr_m89E6DEAA4AB492A157EC457523AE95F0950B8BEE,
	tNoteAftertouch_setCPtr_m2B2100C113F76C79E8FF08720871D755EC1E8502,
	tNoteAftertouch_Finalize_m9AF707B720807406EE1FD7D938A8894E00C094D6,
	tNoteAftertouch_Dispose_m872964D9BDDD357D90974295C33F70AE22EB59ED,
	tNoteAftertouch_set_byNote_m89659F0D4537BF8E9E804DFA52872D674342A7AD,
	tNoteAftertouch_get_byNote_m39E6D08A7A036FB5FB6321ADA921FB96941E0504,
	tNoteAftertouch_set_byValue_mBF2496210FADD86D5D25F7E0E104979E552FA23C,
	tNoteAftertouch_get_byValue_m53AFBF2EE1D17145DF56A06505D451A7D0A1739A,
	tNoteAftertouch__ctor_mD881311D7B029B15D8C4989063B8B8A97F14ADFA,
	tChanAftertouch__ctor_m4748E89AE7C9461E623EF431B7601B21ABAC7416,
	tChanAftertouch_getCPtr_m670F05F12B28E91DDF08525A159F381DB4948A7A,
	tChanAftertouch_setCPtr_mE7174C46B057DE128D5068B2BC3C00F67D62F1B1,
	tChanAftertouch_Finalize_mF6CF2DB41A8C55798723BE03D68763DF72A8A08A,
	tChanAftertouch_Dispose_mE7C83E02A5DA22911D75659BC2E0CD991DDDA82E,
	tChanAftertouch_set_byValue_m8808EEFCDE8BCD50E2B1037E9CDBFEECBE61B043,
	tChanAftertouch_get_byValue_m16845A577A058ADF4DF94E1B8801C5297B5BB9CA,
	tChanAftertouch__ctor_m1FF5CDE95E52497142CC697DBEA2DC00837874ED,
	tProgramChange__ctor_mE7ECD6C6274549F29A7139735C24269FF1260AF6,
	tProgramChange_getCPtr_m7B6695E1F5D173D62B3662FE5D9AC5A80F97EE0F,
	tProgramChange_setCPtr_mB839E79887521F8F1FE14023524E1BF77DDE0CA6,
	tProgramChange_Finalize_m218DDFC425A4BB798355DF9E3E6DD1B308DE4917,
	tProgramChange_Dispose_mDFCD6A0A69D07139373BEB8681902E2937280F2D,
	tProgramChange_set_byProgramNum_m25421B107EED036CC273963AC2C508C597F4C818,
	tProgramChange_get_byProgramNum_mFDC7D2CB7F4568B1978C9565F5BEB1F8BB6CE73A,
	tProgramChange__ctor_m38FC93E25FF0975CC7D6CE52A29C9A3DE72D26F8,
	tWwiseCmd__ctor_m6AB93DEFE0F97076A5735F39F00D7488E52DF86A,
	tWwiseCmd_getCPtr_m43C0EA0E375D8F23520C182062971717FEE6DDC5,
	tWwiseCmd_setCPtr_mFAA62772A18E4BED6A0CDBA9163691039DE3EC23,
	tWwiseCmd_Finalize_mD6FACC185E1F4D63CC09628083D275C998154633,
	tWwiseCmd_Dispose_mAD9249FC2431CA0E8F88B22469B30CED25D8AC39,
	tWwiseCmd_set_uCmd_m8ACA3ADBE9258DDA033A48E8942197A93CD45286,
	tWwiseCmd_get_uCmd_m0728518543660A5265E92613A7CBFD22138D20BF,
	tWwiseCmd_set_uArg_mC7D8C5E6C8C5D241DBB11CA027A2C063FF2F1AE5,
	tWwiseCmd_get_uArg_mED202B570121975CFBC817F3DEBC1E9224D323BC,
	tWwiseCmd__ctor_m655E3D2DDFB0E988DBE0F7E21112882A8D2EF544,
	AudioFormatDelegate__ctor_m26D3A26D03E8BAF0BDDDF5F9709FA48BBF829DC4,
	AudioFormatDelegate_Invoke_m165C5B67766ED086A2075E152902777498E139B9,
	AudioFormatDelegate_BeginInvoke_mD6D5929BE3DA085EBC3DD37E1C2B7A83B360EBB9,
	AudioFormatDelegate_EndInvoke_mA2C9BE8D268B5C118A6A1B71B3E973482707C2E2,
	AudioFormatInteropDelegate__ctor_m65EEE5473BA3B8C96B6A615505449F2CCAF3FD5F,
	AudioFormatInteropDelegate_Invoke_m817CC4849CAA04868CA9AAECCD2BB562B788E666,
	AudioFormatInteropDelegate_BeginInvoke_m98A4E007881BCBC3BF38B8835340761275C74A28,
	AudioFormatInteropDelegate_EndInvoke_m192D595A22E8B3167DC59EE6773E1E0BF2C83B99,
	AudioSamplesDelegate__ctor_m943CEAECC1F04DDFBD92309E08AD2A1D7F1EB6BF,
	AudioSamplesDelegate_Invoke_m2C090ED478829D7AA4831BA5CBC612867B331115,
	AudioSamplesDelegate_BeginInvoke_m18B1C132E26001122A436A9915387FB9BD6FC12A,
	AudioSamplesDelegate_EndInvoke_m5D310A376BA706A597051AD3FBA12274FF88C194,
	AudioSamplesInteropDelegate__ctor_mDD33A5EDA4A6D9D24D55CA65328A12B3AD3B7E8A,
	AudioSamplesInteropDelegate_Invoke_m29A1F8B48F7D5723EF9C59EC9D0B8F49E0181322,
	AudioSamplesInteropDelegate_BeginInvoke_m2E81B7D3DFA8573EBC9DC0BCEA1A0772300D75FB,
	AudioSamplesInteropDelegate_EndInvoke_mB8AD9406E92C350DA400C78A521BC5AD73B20ECE,
	BankHandle__ctor_m6488C3A828926884ED9BB0D3CC0D2B435364B3E4,
	BankHandle_get_RefCount_mC89DD09927733FE654BDBFE6C4259206F3BF7374,
	BankHandle_set_RefCount_m618653EFF0B29CCE01CB3E46C97AF9ED1D8BC83B,
	BankHandle_DoLoadBank_mD6C1F9A110ECD8ACFAE14BB2BCEB251474D0EAFF,
	BankHandle_LoadBank_m74BBDA41D27E555AEDF1BA77F73D5D375F1A5E14,
	BankHandle_UnloadBank_m0D193B924C4D2738D8F58BC9357481D06B96A017,
	BankHandle_IncRef_m7598E53A3AC6CFB6D41484708B68E53ADC10FC4F,
	BankHandle_DecRef_m144AEE8F725BF475744F6596C1B20CDAEFE95CC2,
	BankHandle_LogLoadResult_mE51076B28F70049696BD63148DCE4E26E60A297E,
	AsyncBankHandle__ctor_mF5355FF8E5F66803D01F182298E0F46639E93F23,
	AsyncBankHandle_GlobalBankCallback_m3EEA16A9EF3A60EFD4888B93FADEFB290E749CBA,
	AsyncBankHandle_DoLoadBank_mC1FF07673F3EBC086E41F914668F38F3EA95A3E4,
	DecodableBankHandle__ctor_m03E4082DF88C58C05C7F0608EF031548C21EB80A,
	DecodableBankHandle_DoLoadBank_m4752EAD9215F2B3CADB0698788FD19CD00A07667,
	DecodableBankHandle_UnloadBank_mE35B06FF00428F25BAFC4B59448FB1A2B6D098A3,
	CustomPlatformNameGetter__ctor_m81AE2C4EA40997058EB8F41A2833071368C0F504,
	CustomPlatformNameGetter_Invoke_mBF1DA69B8FF7206236A1DF1C89BB002299EAA7E4,
	CustomPlatformNameGetter_BeginInvoke_m72FC27CDA13C2B836090C7DA781EC106B9AAC96C,
	CustomPlatformNameGetter_EndInvoke_mAFE496AFD14A619795898BF8C8DE5C07C63E5381,
	EventCallback__ctor_m8CEF34110B8FAB336F2211A3ED290453F048C6E2,
	EventCallback_Invoke_mC78B589037D5D279B1F9CA1E5516602C23C476EF,
	EventCallback_BeginInvoke_m112ADF53A6539ABBE34538A9175C2EC2825601CD,
	EventCallback_EndInvoke_mC57D01FF5211594182867390D728FE2A5BA1A871,
	MonitoringCallback__ctor_m6080A7E5C98F6A8BB6003E15F2CB2925A7DB69AE,
	MonitoringCallback_Invoke_m73E971D60180F1BB10302FFD2E85CC770956DD6E,
	MonitoringCallback_BeginInvoke_m16C17EA4029AAD77CE546F9557BA69DF18BE8833,
	MonitoringCallback_EndInvoke_mC6660AE307EF8521424BDC8082AED38BFCBAF868,
	BankCallback__ctor_m285B00D6B758CE1EFDFED2FFA3685D484551D2FC,
	BankCallback_Invoke_m911FAA6CB8664FF41419E07035C4693A77DEFC35,
	BankCallback_BeginInvoke_m5E407E173D7311B0B8F4E7DC608BB8E7174A0164,
	BankCallback_EndInvoke_mEC1618AB0A49B480CB8B10987258FDAA1F240A60,
	EventCallbackPackage_Create_mA60BD3579147DA80B1F38F846AE0957A70438237,
	EventCallbackPackage__ctor_m3964D3C93FA67EC6EE8994D4DB758F4E152896DD,
	BankCallbackPackage__ctor_mA28A09C45CCADA39EAC444D7AEFAA530E47C1AA4,
	BGMCallback__ctor_mB043BEBC921A9B833E78347A34CDA79A32010FB0,
	BGMCallback_Invoke_m696F74D61E8C4CF7AE4D81E09827EE72E7C59ECC,
	BGMCallback_BeginInvoke_m848CD222B52F203A38E2EFCAAFEA4ADFFE9BDC50,
	BGMCallback_EndInvoke_mCCE022726989B5E7B449AF3AFC45E9EB4CCFE15B,
	BGMCallbackPackage__ctor_m6D2BB11093ECC5103837F2E8918F180376E64F23,
	InitializationSettings__ctor_m5709E6CDC151DEF5941B51E3CAD0EF5AF22144FE,
	ChannelConfiguration_CopyTo_mC4554E23E9E8A46D9D9C1596CA3C6CEEEABF2103,
	ChannelConfiguration__ctor_m2FA0077E7E1FE35A24840D29D935DB7210005E28,
	SpatialAudioSettings__ctor_m75352F0F654CEB0DAC4C0407F5580FBF516B67C6,
	ErrorLoggerInteropDelegate__ctor_m6A7E9D58E8F714CF53556E3F7E223A7721A1FB76,
	ErrorLoggerInteropDelegate_Invoke_mE9AA83146B5D4D81685C1177D60FB0FB75B55A9D,
	ErrorLoggerInteropDelegate_BeginInvoke_mE1E657B5C467610DA01ADB99FF5BB87BA72626C3,
	ErrorLoggerInteropDelegate_EndInvoke_mFE261ECB10784FAC459D8D4097444F792158C533,
	ShortIDGenerator__cctor_mEB1B5ADFE7E54F75673C3BB9A4D46E0EC10B200D,
	ShortIDGenerator_get_HashSize_m467742C012DEE673CE0E6F9F5779481BC9546A1C,
	ShortIDGenerator_set_HashSize_mAE8B03DA9922587EEFD15F4C009E28AB2ED890D6,
	ShortIDGenerator_Compute_m6733604177C46DBF4E00A0823B7A52D4079752B9,
	ShortIDGenerator__ctor_mE06C6B14E01A529592C8118B3A433D7AEA92E445,
	PlatformSettings_IgnorePropertyValue_mE1A1D57046679532F1406D0A6A8748DD9FF057A1,
	PlatformSettings_IsPropertyIgnored_mE7DB819CBAF4582641B48D90F28EDF6E141EEC79,
	PlatformSettings__ctor_m9F38465A62E5ED8FB3DCD9CF044C36ACF871C16D,
	PlatformSettings_SetUseGlobalPropertyValue_m16DA3C574240EAC8F7E2A7C6F632D5E3A7EC9535,
	PlatformSettings_SetGlobalPropertyValues_m7E754C40D8DE0CC35EEA33DAEE04D8AE37B69C73,
	PlatformSettings_IsUsingGlobalPropertyValue_m35BCB13ED366A683D2385AA09D5F7E22F5C748B5,
	PlatformSettings_get_GlobalPropertyHashSet_m08A247C9C52836D003B5FD63ABFE1EF1C9899E9E,
	PlatformSettings_set_GlobalPropertyHashSet_m430574331E47C51C0AE9DEA55008AC7B43512483,
	CommonPlatformSettings_GetUserSettings_m724B6A6429EDBBB318C5E21E81C11CED6827E482,
	CommonPlatformSettings_GetAdvancedSettings_m0901B094DAB6C113FEDB0CDA9790A0A583FCA94B,
	CommonPlatformSettings_GetCommsSettings_mE5B68C83AE57BD6AE5EE37BA544B3D9B0A4DFB20,
	CommonPlatformSettings__ctor_m63AFE4F3130D2792C7A0C8F0488F9BB533089D6F,
	PlatformAdvancedSettings_CopyTo_m3EB0EFAD0D069B067EA2D00ADFDA259156F6D328,
	PlatformAdvancedSettings__ctor_mBBBF33AECD834ED49676D7F2EA3416BA9AFFA9FC,
};
static const int32_t s_InvokerIndices[3070] = 
{
	161,
	251,
	114,
	106,
	159,
	106,
	752,
	752,
	49,
	49,
	106,
	106,
	106,
	2009,
	2010,
	144,
	21,
	178,
	177,
	21,
	178,
	177,
	21,
	178,
	177,
	21,
	178,
	177,
	21,
	21,
	2011,
	2012,
	2013,
	43,
	21,
	49,
	94,
	217,
	4,
	2014,
	2015,
	484,
	2016,
	21,
	2017,
	1180,
	2018,
	2019,
	262,
	239,
	261,
	106,
	138,
	94,
	94,
	2020,
	2021,
	2022,
	2016,
	2023,
	2024,
	2025,
	2026,
	2027,
	2028,
	2029,
	2030,
	177,
	2031,
	2032,
	2033,
	2034,
	131,
	2035,
	2036,
	2037,
	2038,
	2039,
	2016,
	21,
	106,
	2040,
	2041,
	21,
	94,
	2013,
	1180,
	2042,
	2043,
	2039,
	2044,
	2045,
	2046,
	2047,
	2048,
	2049,
	2050,
	2051,
	2052,
	163,
	357,
	173,
	2053,
	146,
	2013,
	357,
	3,
	860,
	174,
	173,
	2054,
	860,
	174,
	173,
	832,
	49,
	2055,
	106,
	2056,
	2057,
	2056,
	2057,
	2058,
	106,
	2059,
	625,
	21,
	2060,
	2060,
	2061,
	2062,
	2063,
	2063,
	2064,
	2065,
	2066,
	2067,
	163,
	666,
	1025,
	178,
	177,
	2068,
	2069,
	2070,
	2071,
	106,
	666,
	666,
	2072,
	2072,
	131,
	131,
	2070,
	2073,
	2074,
	2075,
	2076,
	2076,
	144,
	144,
	144,
	2077,
	2078,
	2079,
	2080,
	2081,
	2082,
	2083,
	2084,
	2085,
	2086,
	2087,
	2088,
	2089,
	2090,
	2091,
	2092,
	2093,
	2094,
	2095,
	2096,
	2097,
	2098,
	2039,
	2016,
	21,
	2099,
	2100,
	2046,
	2026,
	94,
	2030,
	2101,
	2016,
	2026,
	177,
	138,
	2102,
	2103,
	178,
	178,
	570,
	2104,
	177,
	131,
	1025,
	138,
	2105,
	2106,
	94,
	106,
	94,
	94,
	106,
	144,
	2107,
	2026,
	2108,
	219,
	177,
	138,
	2109,
	2110,
	2058,
	21,
	261,
	106,
	106,
	106,
	159,
	49,
	49,
	2111,
	1025,
	2112,
	2113,
	2114,
	178,
	177,
	2115,
	2116,
	2117,
	570,
	131,
	106,
	163,
	566,
	173,
	3,
	21,
	21,
	177,
	428,
	163,
	667,
	666,
	2118,
	2118,
	2119,
	2119,
	2120,
	2121,
	2122,
	2107,
	146,
	625,
	2123,
	2124,
	2125,
	2110,
	2126,
	1025,
	251,
	276,
	21,
	268,
	2127,
	2118,
	2118,
	17,
	17,
	17,
	46,
	21,
	53,
	46,
	46,
	46,
	46,
	21,
	178,
	1381,
	106,
	106,
	1381,
	106,
	106,
	106,
	2128,
	2129,
	2030,
	2016,
	21,
	106,
	144,
	2130,
	144,
	144,
	2076,
	298,
	21,
	2131,
	2058,
	2128,
	2103,
	2103,
	2132,
	2130,
	106,
	94,
	2133,
	2134,
	21,
	106,
	163,
	3,
	137,
	94,
	94,
	94,
	3,
	144,
	144,
	2119,
	94,
	94,
	625,
	94,
	94,
	94,
	2135,
	2136,
	2023,
	2024,
	2025,
	2026,
	4,
	21,
	106,
	2137,
	2138,
	2139,
	2102,
	131,
	2140,
	2126,
	625,
	94,
	163,
	163,
	163,
	163,
	163,
	106,
	106,
	3,
	3,
	163,
	2141,
	2142,
	144,
	144,
	2143,
	2020,
	2021,
	2022,
	2016,
	18,
	18,
	160,
	163,
	160,
	94,
	138,
	94,
	4,
	138,
	2144,
	161,
	161,
	2145,
	2145,
	2146,
	2147,
	94,
	2148,
	2149,
	2072,
	1025,
	2150,
	2151,
	2152,
	138,
	2153,
	2154,
	2155,
	2156,
	491,
	489,
	2157,
	363,
	2158,
	1025,
	666,
	2159,
	2160,
	666,
	2161,
	2162,
	190,
	2163,
	2164,
	2165,
	2166,
	2167,
	2168,
	163,
	163,
	2169,
	2170,
	2171,
	2170,
	2171,
	2088,
	138,
	138,
	94,
	94,
	94,
	2172,
	2173,
	2174,
	2175,
	2176,
	2177,
	2178,
	2179,
	2180,
	2181,
	2182,
	667,
	666,
	1025,
	2183,
	191,
	190,
	138,
	2156,
	188,
	1025,
	138,
	190,
	2168,
	2184,
	2185,
	2186,
	2073,
	2187,
	2188,
	2189,
	187,
	138,
	138,
	2190,
	2191,
	2192,
	2193,
	2193,
	2193,
	2194,
	114,
	1742,
	2126,
	2195,
	2156,
	1025,
	2196,
	2026,
	131,
	2088,
	2196,
	94,
	94,
	138,
	2197,
	190,
	94,
	94,
	18,
	23,
	3,
	172,
	24,
	7,
	23,
	23,
	26,
	14,
	32,
	10,
	32,
	10,
	31,
	89,
	31,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	23,
	26,
	14,
	326,
	714,
	326,
	714,
	32,
	10,
	172,
	24,
	7,
	23,
	23,
	23,
	32,
	10,
	326,
	714,
	26,
	14,
	23,
	23,
	106,
	26,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	26,
	14,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	10,
	10,
	10,
	10,
	10,
	2198,
	23,
	172,
	24,
	7,
	23,
	23,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	32,
	10,
	23,
	172,
	24,
	7,
	23,
	23,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	208,
	182,
	32,
	10,
	326,
	714,
	2199,
	2200,
	1948,
	141,
	106,
	172,
	24,
	7,
	23,
	23,
	10,
	15,
	10,
	23,
	172,
	24,
	7,
	23,
	23,
	23,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	32,
	10,
	32,
	10,
	31,
	89,
	172,
	24,
	7,
	23,
	23,
	15,
	182,
	23,
	172,
	24,
	7,
	23,
	23,
	106,
	3,
	751,
	3,
	173,
	2201,
	23,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	32,
	10,
	32,
	10,
	23,
	129,
	23,
	32,
	129,
	32,
	32,
	23,
	89,
	10,
	32,
	14,
	14,
	172,
	24,
	7,
	23,
	23,
	26,
	14,
	32,
	10,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	26,
	14,
	32,
	10,
	31,
	89,
	23,
	106,
	26,
	23,
	172,
	24,
	7,
	23,
	23,
	7,
	15,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	26,
	14,
	326,
	714,
	32,
	10,
	31,
	89,
	32,
	10,
	172,
	24,
	7,
	23,
	23,
	1352,
	1351,
	26,
	14,
	32,
	10,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	106,
	2202,
	1471,
	183,
	183,
	26,
	23,
	172,
	24,
	7,
	23,
	23,
	714,
	714,
	10,
	10,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	10,
	10,
	15,
	23,
	172,
	24,
	7,
	23,
	23,
	10,
	10,
	23,
	172,
	24,
	7,
	23,
	23,
	23,
	1445,
	326,
	714,
	326,
	714,
	326,
	714,
	172,
	24,
	7,
	23,
	23,
	23,
	2203,
	35,
	38,
	23,
	26,
	106,
	32,
	10,
	32,
	10,
	26,
	14,
	7,
	15,
	32,
	10,
	32,
	10,
	172,
	24,
	7,
	23,
	23,
	23,
	2204,
	1352,
	1351,
	326,
	714,
	326,
	714,
	326,
	714,
	31,
	89,
	31,
	89,
	172,
	24,
	7,
	23,
	23,
	23,
	2204,
	32,
	26,
	26,
	14,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	32,
	10,
	31,
	89,
	32,
	10,
	32,
	10,
	32,
	10,
	26,
	14,
	32,
	10,
	31,
	89,
	31,
	89,
	26,
	14,
	32,
	10,
	326,
	714,
	32,
	10,
	326,
	714,
	31,
	89,
	172,
	24,
	7,
	23,
	23,
	23,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	31,
	89,
	172,
	24,
	7,
	23,
	23,
	26,
	14,
	14,
	14,
	14,
	9,
	9,
	23,
	172,
	24,
	7,
	23,
	23,
	31,
	89,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	32,
	10,
	31,
	89,
	31,
	89,
	32,
	10,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	593,
	247,
	32,
	10,
	23,
	172,
	24,
	7,
	23,
	23,
	89,
	89,
	89,
	10,
	89,
	89,
	10,
	89,
	89,
	89,
	89,
	89,
	89,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	208,
	182,
	2205,
	2206,
	2207,
	2208,
	2209,
	2210,
	2211,
	2212,
	26,
	106,
	23,
	172,
	24,
	7,
	23,
	23,
	10,
	10,
	14,
	23,
	172,
	24,
	7,
	23,
	23,
	10,
	10,
	10,
	182,
	14,
	23,
	172,
	24,
	7,
	23,
	23,
	10,
	10,
	10,
	10,
	23,
	172,
	24,
	7,
	23,
	23,
	326,
	714,
	172,
	24,
	7,
	23,
	23,
	10,
	10,
	10,
	10,
	10,
	10,
	714,
	714,
	714,
	714,
	10,
	14,
	23,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	32,
	10,
	32,
	10,
	23,
	106,
	26,
	23,
	172,
	24,
	7,
	23,
	23,
	326,
	714,
	326,
	714,
	23,
	106,
	26,
	23,
	172,
	24,
	7,
	23,
	23,
	23,
	2213,
	107,
	130,
	26,
	32,
	10,
	32,
	10,
	32,
	10,
	26,
	14,
	172,
	24,
	7,
	23,
	23,
	2214,
	2215,
	2216,
	56,
	37,
	23,
	172,
	24,
	7,
	23,
	23,
	23,
	14,
	14,
	28,
	28,
	32,
	28,
	32,
	89,
	37,
	10,
	23,
	10,
	14,
	89,
	28,
	14,
	28,
	14,
	23,
	112,
	112,
	23,
	34,
	34,
	89,
	30,
	30,
	26,
	112,
	172,
	24,
	7,
	23,
	23,
	23,
	26,
	28,
	9,
	1069,
	32,
	10,
	32,
	10,
	7,
	15,
	172,
	24,
	7,
	23,
	23,
	26,
	14,
	26,
	14,
	23,
	172,
	24,
	7,
	23,
	23,
	326,
	714,
	32,
	10,
	32,
	10,
	31,
	89,
	32,
	10,
	31,
	89,
	31,
	89,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	23,
	172,
	24,
	7,
	23,
	23,
	23,
	1316,
	326,
	714,
	326,
	714,
	172,
	24,
	7,
	23,
	23,
	1352,
	1351,
	32,
	10,
	32,
	10,
	326,
	714,
	31,
	89,
	106,
	2202,
	34,
	1471,
	26,
	23,
	172,
	24,
	7,
	23,
	23,
	326,
	714,
	326,
	714,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	23,
	172,
	24,
	7,
	23,
	23,
	23,
	26,
	1352,
	1351,
	1352,
	1351,
	32,
	10,
	326,
	714,
	326,
	714,
	326,
	714,
	31,
	89,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	326,
	714,
	326,
	714,
	326,
	714,
	326,
	714,
	23,
	172,
	24,
	7,
	23,
	23,
	15,
	10,
	15,
	14,
	23,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	7,
	15,
	32,
	10,
	23,
	106,
	26,
	23,
	172,
	24,
	7,
	23,
	23,
	23,
	32,
	10,
	326,
	714,
	32,
	10,
	32,
	10,
	326,
	714,
	326,
	714,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	172,
	24,
	7,
	23,
	23,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	23,
	172,
	24,
	7,
	23,
	23,
	1351,
	1351,
	1351,
	2217,
	2218,
	1352,
	1445,
	1349,
	2219,
	23,
	172,
	24,
	7,
	23,
	23,
	23,
	2220,
	593,
	247,
	593,
	247,
	593,
	247,
	593,
	247,
	23,
	106,
	26,
	172,
	24,
	7,
	23,
	23,
	23,
	32,
	10,
	593,
	247,
	593,
	247,
	593,
	247,
	32,
	10,
	31,
	89,
	26,
	14,
	172,
	24,
	7,
	23,
	23,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	593,
	247,
	32,
	10,
	31,
	89,
	32,
	10,
	3,
	106,
	159,
	106,
	992,
	164,
	992,
	164,
	751,
	25,
	992,
	164,
	1220,
	985,
	992,
	164,
	2221,
	580,
	25,
	106,
	2222,
	751,
	25,
	2223,
	2223,
	2223,
	2224,
	2225,
	2226,
	2227,
	2228,
	2229,
	751,
	25,
	2230,
	2231,
	2230,
	2231,
	25,
	106,
	2222,
	751,
	25,
	2222,
	985,
	992,
	164,
	25,
	2232,
	588,
	992,
	164,
	2230,
	2231,
	2233,
	2234,
	106,
	25,
	751,
	2235,
	2230,
	2231,
	2230,
	2231,
	25,
	752,
	752,
	49,
	49,
	106,
	106,
	106,
	992,
	164,
	2222,
	985,
	992,
	164,
	992,
	164,
	992,
	164,
	992,
	164,
	164,
	164,
	164,
	164,
	164,
	2236,
	751,
	25,
	751,
	2222,
	985,
	2230,
	2231,
	2230,
	2231,
	992,
	164,
	25,
	751,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	992,
	164,
	992,
	164,
	2221,
	580,
	25,
	2222,
	985,
	2222,
	985,
	751,
	25,
	2222,
	985,
	992,
	164,
	992,
	164,
	2221,
	580,
	2221,
	580,
	751,
	25,
	2222,
	985,
	985,
	985,
	985,
	585,
	585,
	751,
	25,
	751,
	985,
	25,
	1146,
	585,
	2237,
	992,
	164,
	992,
	164,
	2222,
	985,
	751,
	25,
	985,
	985,
	1146,
	1146,
	992,
	1146,
	992,
	580,
	2238,
	164,
	25,
	164,
	985,
	580,
	1146,
	985,
	1146,
	985,
	25,
	2239,
	2239,
	25,
	2240,
	2240,
	580,
	2241,
	2241,
	2222,
	2239,
	2242,
	2243,
	2244,
	2245,
	2238,
	751,
	25,
	2246,
	2247,
	144,
	21,
	178,
	177,
	21,
	178,
	177,
	21,
	178,
	177,
	21,
	178,
	177,
	21,
	21,
	2011,
	2012,
	2013,
	586,
	21,
	751,
	2248,
	2249,
	990,
	24,
	992,
	164,
	992,
	164,
	992,
	164,
	2222,
	985,
	25,
	992,
	164,
	751,
	25,
	992,
	164,
	992,
	164,
	2221,
	580,
	992,
	164,
	992,
	164,
	992,
	164,
	2222,
	985,
	992,
	164,
	2221,
	580,
	2221,
	580,
	1220,
	985,
	992,
	164,
	2230,
	2231,
	992,
	164,
	2230,
	2231,
	2221,
	580,
	25,
	992,
	164,
	2222,
	985,
	992,
	164,
	25,
	106,
	2222,
	751,
	25,
	49,
	164,
	587,
	751,
	2250,
	2015,
	484,
	2016,
	21,
	2017,
	1180,
	2018,
	2019,
	262,
	239,
	261,
	106,
	138,
	94,
	94,
	2251,
	2252,
	2253,
	2016,
	2254,
	2255,
	2256,
	2026,
	2027,
	2028,
	2029,
	2030,
	177,
	2031,
	2032,
	2033,
	2034,
	131,
	2257,
	2258,
	2259,
	2260,
	2039,
	2016,
	21,
	106,
	2040,
	2041,
	21,
	94,
	2013,
	1180,
	2042,
	2043,
	2039,
	2044,
	2045,
	2046,
	2047,
	2048,
	2049,
	2050,
	2051,
	2052,
	25,
	357,
	173,
	2053,
	146,
	2013,
	357,
	3,
	860,
	174,
	173,
	2054,
	860,
	174,
	173,
	832,
	49,
	2055,
	106,
	2261,
	2262,
	2261,
	2262,
	2058,
	106,
	2059,
	625,
	21,
	2060,
	2060,
	2263,
	2264,
	2265,
	2265,
	2064,
	2065,
	2266,
	2267,
	25,
	666,
	1025,
	178,
	177,
	2268,
	2269,
	2270,
	2271,
	106,
	2272,
	666,
	2273,
	2274,
	2238,
	2238,
	2275,
	2073,
	2276,
	2277,
	2076,
	2076,
	144,
	144,
	144,
	2278,
	2279,
	2079,
	2080,
	2081,
	2082,
	2083,
	2084,
	2085,
	2086,
	2087,
	2088,
	2089,
	2090,
	2091,
	2092,
	2093,
	2094,
	2095,
	2096,
	2097,
	2098,
	2039,
	2016,
	21,
	2099,
	2100,
	2046,
	2026,
	94,
	2030,
	2101,
	2016,
	2026,
	177,
	138,
	2280,
	2103,
	178,
	178,
	570,
	2104,
	177,
	131,
	2065,
	2064,
	2105,
	2281,
	94,
	106,
	94,
	94,
	106,
	144,
	2282,
	2283,
	2108,
	219,
	177,
	138,
	2284,
	2285,
	2058,
	21,
	261,
	106,
	106,
	106,
	159,
	992,
	164,
	992,
	164,
	992,
	164,
	992,
	164,
	992,
	164,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	751,
	25,
	2230,
	2231,
	2230,
	2231,
	992,
	164,
	992,
	164,
	992,
	164,
	992,
	164,
	751,
	25,
	49,
	49,
	2221,
	580,
	2221,
	580,
	2221,
	580,
	751,
	25,
	2221,
	580,
	2221,
	580,
	751,
	25,
	2221,
	580,
	2221,
	580,
	751,
	25,
	2221,
	580,
	2221,
	580,
	751,
	25,
	2221,
	580,
	2221,
	580,
	751,
	25,
	2221,
	580,
	751,
	25,
	2221,
	580,
	751,
	25,
	991,
	2286,
	992,
	164,
	751,
	25,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	992,
	164,
	2221,
	580,
	2221,
	580,
	992,
	164,
	2221,
	580,
	2221,
	580,
	2221,
	580,
	2221,
	580,
	2221,
	580,
	2221,
	580,
	2221,
	580,
	991,
	2286,
	992,
	164,
	751,
	25,
	2232,
	588,
	2287,
	2288,
	2289,
	2290,
	2222,
	106,
	751,
	25,
	2230,
	2231,
	25,
	2291,
	2065,
	985,
	164,
	985,
	985,
	751,
	25,
	985,
	588,
	751,
	25,
	164,
	164,
	751,
	25,
	580,
	580,
	580,
	164,
	580,
	580,
	164,
	580,
	580,
	580,
	580,
	580,
	580,
	580,
	751,
	25,
	164,
	164,
	985,
	751,
	25,
	2231,
	2231,
	164,
	164,
	580,
	751,
	25,
	164,
	164,
	985,
	751,
	25,
	164,
	164,
	164,
	164,
	164,
	164,
	2231,
	2231,
	2231,
	2231,
	164,
	985,
	751,
	25,
	164,
	164,
	164,
	164,
	751,
	25,
	164,
	985,
	164,
	751,
	25,
	164,
	164,
	164,
	588,
	985,
	751,
	25,
	580,
	751,
	25,
	580,
	751,
	25,
	106,
	3,
	751,
	3,
	173,
	2292,
	751,
	25,
	2112,
	2113,
	2114,
	178,
	177,
	2115,
	2116,
	2117,
	570,
	131,
	106,
	25,
	1690,
	173,
	3,
	21,
	21,
	177,
	428,
	25,
	667,
	666,
	2118,
	2118,
	2230,
	2231,
	992,
	164,
	992,
	164,
	2221,
	580,
	992,
	164,
	2221,
	580,
	2221,
	580,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	751,
	25,
	992,
	164,
	992,
	164,
	992,
	164,
	25,
	106,
	2222,
	751,
	25,
	2293,
	2293,
	2120,
	2121,
	2122,
	2107,
	146,
	625,
	2294,
	2124,
	2125,
	2285,
	2295,
	2065,
	251,
	276,
	21,
	268,
	2127,
	2118,
	2118,
	17,
	17,
	17,
	46,
	21,
	53,
	46,
	46,
	46,
	46,
	21,
	178,
	992,
	164,
	992,
	164,
	992,
	164,
	751,
	2296,
	25,
	992,
	2297,
	992,
	992,
	25,
	580,
	164,
	992,
	985,
	985,
	25,
	751,
	2298,
	2226,
	2223,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2221,
	580,
	2221,
	580,
	25,
	1381,
	106,
	106,
	1381,
	106,
	106,
	106,
	751,
	992,
	164,
	2230,
	2231,
	992,
	164,
	992,
	164,
	2230,
	2231,
	2230,
	2231,
	2221,
	580,
	2221,
	580,
	2221,
	580,
	2221,
	580,
	2221,
	580,
	25,
	751,
	2298,
	25,
	992,
	1220,
	2222,
	985,
	751,
	2299,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	25,
	751,
	2300,
	991,
	2286,
	991,
	2286,
	991,
	2286,
	991,
	2286,
	25,
	106,
	2222,
	25,
	751,
	992,
	164,
	2230,
	2231,
	1220,
	985,
	25,
	25,
	106,
	2222,
	25,
	2226,
	2223,
	992,
	164,
	992,
	164,
	2230,
	2231,
	2221,
	580,
	106,
	2301,
	2240,
	2302,
	2222,
	751,
	25,
	2226,
	2223,
	2222,
	985,
	992,
	164,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	106,
	2301,
	2302,
	2303,
	2303,
	2222,
	751,
	25,
	751,
	985,
	2226,
	2223,
	2226,
	2223,
	992,
	164,
	2230,
	2231,
	2230,
	2231,
	2230,
	2231,
	2221,
	580,
	25,
	2128,
	2304,
	2030,
	2016,
	21,
	106,
	144,
	2305,
	144,
	144,
	2076,
	298,
	21,
	2131,
	2058,
	2128,
	2103,
	2103,
	2132,
	2305,
	106,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	991,
	2286,
	992,
	164,
	2221,
	580,
	992,
	164,
	25,
	94,
	2306,
	2307,
	21,
	106,
	25,
	2222,
	985,
	992,
	164,
	992,
	164,
	992,
	164,
	992,
	164,
	992,
	164,
	2222,
	985,
	2230,
	2231,
	992,
	164,
	2221,
	580,
	992,
	164,
	25,
	992,
	164,
	992,
	164,
	992,
	164,
	751,
	25,
	163,
	3,
	137,
	25,
	751,
	992,
	164,
	991,
	2286,
	991,
	2286,
	991,
	2286,
	992,
	164,
	2221,
	580,
	1220,
	985,
	25,
	751,
	25,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2222,
	985,
	2221,
	580,
	751,
	25,
	2308,
	2309,
	2310,
	25,
	2222,
	106,
	992,
	164,
	992,
	164,
	1220,
	985,
	2222,
	985,
	992,
	164,
	992,
	164,
	164,
	164,
	164,
	3,
	144,
	144,
	2119,
	94,
	94,
	625,
	94,
	94,
	94,
	2135,
	2136,
	2254,
	2255,
	2256,
	2026,
	751,
	21,
	106,
	2137,
	2138,
	2139,
	2102,
	131,
	2311,
	2312,
	20,
	164,
	25,
	25,
	25,
	25,
	25,
	106,
	106,
	3,
	3,
	25,
	2313,
	2314,
	144,
	144,
	2315,
	2251,
	2252,
	2253,
	2016,
	985,
	985,
	985,
	985,
	985,
	985,
	985,
	985,
	985,
	23,
	172,
	24,
	7,
	23,
	23,
	32,
	10,
	32,
	10,
	32,
	10,
	23,
	172,
	24,
	7,
	23,
	23,
	2069,
	768,
	2316,
	1690,
	3,
	998,
	483,
	3,
	3,
	3,
	3,
	832,
	3,
	1900,
	137,
	163,
	3,
	4,
	49,
	832,
	4,
	3,
	4,
	163,
	4,
	163,
	4,
	163,
	23,
	3,
	49,
	832,
	173,
	163,
	163,
	173,
	163,
	3,
	566,
	137,
	106,
	3,
	14,
	14,
	14,
	14,
	14,
	89,
	14,
	14,
	89,
	23,
	26,
	23,
	4,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	23,
	23,
	26,
	26,
	26,
	26,
	23,
	26,
	23,
	23,
	3,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	89,
	14,
	89,
	14,
	23,
	26,
	23,
	4,
	23,
	23,
	163,
	163,
	163,
	163,
	3,
	23,
	2330,
	17,
	0,
	23,
	23,
	326,
	714,
	326,
	714,
	326,
	714,
	2331,
	23,
	23,
	326,
	714,
	326,
	714,
	326,
	714,
	2331,
	23,
	1445,
	23,
	106,
	26,
	32,
	10,
	979,
	1153,
	89,
	10,
	14,
	14,
	14,
	4,
	0,
	4,
	23,
	89,
	23,
	23,
	23,
	223,
	23,
	2332,
	23,
	3,
	32,
	10,
	7,
	979,
	1153,
	23,
	34,
	89,
	23,
	23,
	23,
	2333,
	1715,
	141,
	30,
	112,
	112,
	15,
	10,
	16,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	32,
	10,
	32,
	23,
	23,
	23,
	2334,
	32,
	10,
	7,
	979,
	1153,
	32,
	10,
	979,
	1153,
	32,
	10,
	7,
	7,
	979,
	1153,
	32,
	34,
	62,
	23,
	62,
	778,
	15,
	10,
	16,
	32,
	10,
	7,
	979,
	1153,
	32,
	10,
	7,
	979,
	1153,
	32,
	10,
	32,
	23,
	23,
	23,
	2217,
	32,
	10,
	979,
	1153,
	32,
	10,
	7,
	979,
	1153,
	32,
	10,
	7,
	979,
	1153,
	23,
	14,
	14,
	14,
	23,
	26,
	23,
	124,
	227,
	213,
	227,
	172,
	24,
	7,
	23,
	23,
	31,
	89,
	31,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	31,
	89,
	31,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	31,
	89,
	31,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	31,
	89,
	31,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	31,
	89,
	31,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	31,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	31,
	89,
	23,
	172,
	24,
	7,
	23,
	23,
	593,
	247,
	32,
	10,
	23,
	124,
	62,
	341,
	26,
	124,
	2317,
	2318,
	26,
	124,
	2319,
	2320,
	9,
	124,
	2321,
	2322,
	9,
	26,
	10,
	32,
	10,
	23,
	31,
	23,
	23,
	32,
	27,
	2323,
	10,
	443,
	10,
	31,
	124,
	6,
	1109,
	151,
	124,
	107,
	558,
	26,
	124,
	2324,
	2325,
	26,
	124,
	2326,
	2327,
	26,
	704,
	23,
	27,
	124,
	2328,
	2329,
	112,
	23,
	23,
	26,
	23,
	23,
	124,
	26,
	213,
	26,
	3,
	49,
	832,
	94,
	23,
	26,
	9,
	23,
	443,
	26,
	9,
	14,
	26,
	14,
	14,
	14,
	23,
	26,
	23,
};
static const Il2CppTokenIndexMethodTuple s_reversePInvokeIndices[3] = 
{
	{ 0x06000A65, 6,  (void**)&AkAudioInputManager_InternalAudioSamplesDelegate_mCC8ACFBA434E55CA478271AC70312599C48729D8_RuntimeMethod_var, 0 },
	{ 0x06000A66, 7,  (void**)&AkAudioInputManager_InternalAudioFormatDelegate_mE65C58A009B2CCE12BF2D66527E4DBA94359AE2F_RuntimeMethod_var, 0 },
	{ 0x06000ABF, 8,  (void**)&AkLogger_WwiseInternalLogError_m74B4525C94A2B9D382CF3025E8B7AE1CBE92EA8A_RuntimeMethod_var, 0 },
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x02000070, { 0, 9 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[9] = 
{
	{ (Il2CppRGCTXDataType)3, 20610 },
	{ (Il2CppRGCTXDataType)3, 20611 },
	{ (Il2CppRGCTXDataType)3, 20612 },
	{ (Il2CppRGCTXDataType)3, 20613 },
	{ (Il2CppRGCTXDataType)3, 20614 },
	{ (Il2CppRGCTXDataType)3, 20615 },
	{ (Il2CppRGCTXDataType)3, 20616 },
	{ (Il2CppRGCTXDataType)3, 20617 },
	{ (Il2CppRGCTXDataType)3, 20618 },
};
extern const Il2CppCodeGenModule g_AK_Wwise_Unity_APICodeGenModule;
const Il2CppCodeGenModule g_AK_Wwise_Unity_APICodeGenModule = 
{
	"AK.Wwise.Unity.API.dll",
	3070,
	s_methodPointers,
	s_InvokerIndices,
	3,
	s_reversePInvokeIndices,
	1,
	s_rgctxIndices,
	9,
	s_rgctxValues,
	NULL,
};
