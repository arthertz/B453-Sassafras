﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"

template <typename R>
struct InterfaceFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
struct InterfaceActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};

// AK.Wwise.BaseType
struct BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE;
// AK.Wwise.Event
struct Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F;
// AK.Wwise.RTPC
struct RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C;
// AkCallbackInfo
struct AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979;
// AkCallbackManager/EventCallback
struct EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561;
// AkDurationCallbackInfo
struct AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25;
// AkEventPlayable
struct AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA;
// AkEventPlayableBehavior
struct AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384;
// AkEventTrack
struct AkEventTrack_t6030D1051D1ACA190784CDB5D4C0461578F9E226;
// AkRTPCPlayable
struct AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C;
// AkRTPCPlayableBehaviour
struct AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075;
// AkRTPCTrack
struct AkRTPCTrack_t7AED5E0856187915E29DFFB53DE919F7EC9CFB74;
// AkTimelineEventPlayable
struct AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A;
// AkTimelineEventPlayableBehavior
struct AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844;
// AkTimelineEventTrack
struct AkTimelineEventTrack_t93130E623074A6BC6A9643A4434153816C60FB8D;
// AkTimelineRtpcPlayable
struct AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA;
// AkTimelineRtpcPlayableBehaviour
struct AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E;
// AkTimelineRtpcTrack
struct AkTimelineRtpcTrack_t24C4A29FFDA9C21457A11DF2EB1FE2812DF4D85C;
// System.Action`3<UnityEngine.Timeline.TimelineClip,UnityEngine.GameObject,UnityEngine.Playables.Playable>
struct Action_3_t3DEF6B983A6FD251CA5E86CED7441D9CF0A26209;
// System.Action`3<UnityEngine.Timeline.TrackAsset,UnityEngine.GameObject,UnityEngine.Playables.Playable>
struct Action_3_t08E03FF5D8187DCF3A2B450F10E005618E1956C1;
// System.AsyncCallback
struct AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4;
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2<System.Type,UnityEngine.Timeline.TrackBindingTypeAttribute>
struct Dictionary_2_t1B7E37FEB7F10BFB6B7320EF2FEC7B2CDE25C7E4;
// System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TimelineClip>
struct IEnumerable_1_tF659A953244FBB8F81B6A4F9CD67286607C3FD51;
// System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TrackAsset>
struct IEnumerable_1_t5E4794B9C0140D35E865840CCDBFC9FEF5E3EFB9;
// System.Collections.Generic.List`1<System.String>
struct List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3;
// System.Collections.Generic.List`1<UnityEngine.ScriptableObject>
struct List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF;
// System.Collections.Generic.List`1<UnityEngine.Timeline.IMarker>
struct List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC;
// System.Collections.Generic.List`1<UnityEngine.Timeline.TimelineClip>
struct List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA;
// System.Collections.Generic.List`1<UnityEngine.Timeline.TrackAsset>
struct List_1_t9EFBDDF9C4ED217F9B47075B2659634AF4988704;
// System.DelegateData
struct DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE;
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
// System.IAsyncResult
struct IAsyncResult_t8E194308510B375B42432981AE5E7488C458D598;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.String
struct String_t;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.AnimationClip
struct AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE;
// UnityEngine.AnimationCurve
struct AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C;
// UnityEngine.GameObject
struct GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F;
// UnityEngine.IExposedPropertyTable
struct IExposedPropertyTable_tBA6A5A41F6283C34744CA6EE8B7BE2F0679CF885;
// UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0;
// UnityEngine.Playables.PlayableAsset
struct PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD;
// UnityEngine.Playables.PlayableBehaviour
struct PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01;
// UnityEngine.Timeline.TimelineClip
struct TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB;
// UnityEngine.Timeline.TimelineClip[]
struct TimelineClipU5BU5D_tF91A3D5ECF00F61AAD13F3FCFE125B4F7FA5982E;
// UnityEngine.Timeline.TrackAsset
struct TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D;
// UnityEngine.Timeline.TrackAsset[]
struct TrackAssetU5BU5D_t064A662B3D4A13A5BAAB5D4CAD343DB1D2171EF5;
// WwiseEventReference
struct WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C;
// WwiseRtpcReference
struct WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E;

IL2CPP_EXTERN_C RuntimeClass* AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IEnumerable_1_tF659A953244FBB8F81B6A4F9CD67286607C3FD51_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IEnumerator_1_t4589C691232BC39AA49B633323A50B6AE60479C0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IEnumerator_t8789118187258CC88B77AFAC6315B5AF87D3E18A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Math_tFB388E53C7FDC6FCCF9A19ABF5A4E521FBD52E19_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C const RuntimeMethod* AkEventPlayableBehavior_CallbackHandler_m4013ACF017F9C05D622CFF482A6443167CC70066_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* AkTimelineEventPlayableBehavior_CallbackHandler_mB867C4F333A72B80AB7488785F419D0D518B9357_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ExposedReference_1_Resolve_m9FB7DD08C2FC3CA91FB22B8FD26763647838966B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* PlayableExtensions_GetPreviousTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_mC130F5DC9CA211F6E74092978A776E41476695DD_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* PlayableExtensions_SetInputCount_TisScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_mA8E2E4D605D78423DB070AC3DEAD58FF1EC81768_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* PlayableExtensions_SetInputCount_TisScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_m72C445E9F3D119051901CBC7B175A868F0F410EF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_Create_m0C1209813E5FE8A3908A07A94193CC3C6FC29756_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_Create_m59CEC9FB4154638ED596E64AD2D7BA87D3825FF4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_Create_m6EDD12B7BD86240B4CC3454532CC07C826603BB8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_Create_m7A54D906486B8C92680D138B9DB80F4BF06D95FF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_Create_mC5C205146F9478E15CFE24C9D68FB30F6779D7C8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_Create_mE8D356E1368B91006D6F66A1A066280BD1900F11_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_GetBehaviour_m4A0EE0982E042FF81F5DF187A039E63B83A90863_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_GetBehaviour_m6C5AA4AF673B74C88F047C8A555F75D2C172539B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_GetBehaviour_m78D32C6FED2A5C43A4812E314EA936DF34C97E72_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_GetBehaviour_mBB9A6506A045C46C979B2CB00455DEF36A8B8236_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_op_Implicit_m1CF6AF8A5E29CBAD2BE823B72646D7F4D292F4D9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_op_Implicit_m21D4A99D0E874E3E359EA0D880D8109296AFF222_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_op_Implicit_m4A760D65CA9E71CDCBD51F5326CF756C6469A917_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ScriptPlayable_1_op_Implicit_m52EBDBFDF6B21D71CEA48FB89BC92CDAF68851FD_RuntimeMethod_var;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_CallbackHandler_m4013ACF017F9C05D622CFF482A6443167CC70066_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_CheckForFadeInFadeOut_mAEE0E6FD3FA3A9F9DDA169F6A91A947836A5CA5D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_CheckForFadeOut_m4237D0A6569C78554DB3FB05EABDC0F021E1C876_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_GetProportionalTime_m55D607F02942EA64628CB143502ADEE5AA6C5E38_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_OnBehaviourPause_mC8D3DD00BDF5E2274D5A16CB9E8960247A033973_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_PostEvent_mFE27FB7B99751D0D2D60DC0B59AC336B824D07D7_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_PrepareFrame_m32EF4AB1E373025355F1C907EFD16A1AC715D6AF_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_ProcessFrame_m6D84D059A28B0B8038550C6A2F9438AA87D20092_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_RetriggerEvent_mEFDC6CDBCB432003FA8C89B99984FDB8F34AB1C0_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_SeekToTime_mD813E49C24A8D301C8C2100D162AE54F781E14EA_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_ShouldPlay_m0D795A2E75928584EB42A147B02E7B5739979FCF_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_TriggerFadeIn_m46D06E3EF21E0CD876E24C2C5C1C0DDC0D7829DB_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayableBehavior_TriggerFadeOut_mE96A5DA38440E3F69ED8170BA2D8757806B78ECF_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayable_CreatePlayable_mCA5F54473B58CC0F601088ACAD05598456ED1C20_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventPlayable__ctor_m2AD6F2A6F4F0FA118155CCBF8AEA78E705B1A5AC_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventTrack_CreateTrackMixer_m9FBEA3F95D5DBEB8DFCCD2BEA9E03BF61EACAF2E_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkEventTrack__ctor_m3B8FEC14B08485DE8E7CC56EACD0DEB3B6DF1293_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkRTPCPlayableBehaviour_ProcessFrame_m59978992305F269AB8ABAC94C30FD285EDF24F79_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkRTPCPlayable_CreatePlayable_mCF0F3EEE8C120847335BDE55FEF0D39DE78E3101_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkRTPCPlayable__ctor_m19990F03A3EADF7A8113EA3EC4FA762E0593664F_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkRTPCTrack_CreateTrackMixer_m4B759F47B57011D27ACDF2180591860207495701_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkRTPCTrack_OnValidate_m77A94880E80C5989DE497BA9C41D09E8F2E65B22_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkRTPCTrack__ctor_mF97FB82A99F18D11D1DB8830BF885A3D98274112_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkRTPCTrack_setPlayableProperties_mED078171919EA44228E367042940ACA6DE9A69EF_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_CallbackHandler_mB867C4F333A72B80AB7488785F419D0D518B9357_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_CheckForFadeInFadeOut_m0F701A1EF78E0E94A89ECAC700DF1BED77F025CD_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_CheckForFadeOut_mE4B19F2E4539E898615CDA6CB4DD5CD5C193D316_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_GetProportionalTime_m52FBF2A2547C3263133CDA715BB870A8DD8A9D77_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_OnBehaviourPause_mB53E2A02A95473167E05173659CD1AB6C5CA04CE_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_PostEvent_mE7DBE796B44E46703E212E79ED76B1D31761ED2C_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_PrepareFrame_m673592634E907774453B9719BD41418F9D69E799_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_ProcessFrame_m413118A62B87D79472AEF0D30856AFF663D6A4C6_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_RetriggerEvent_m7A9B9D27455C1824DEC3921F9D0326D8B156CAE2_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_SeekToTime_m97F34CBA9DF79E28A393710EBE06D5EAA1C938E7_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_ShouldPlay_m99F0C560CBA4A34FFE51A9DF5D04D71F77557EF2_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_TriggerFadeIn_mAF9E9008AD701FAD3F372AE1C3054F59A0714A56_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayableBehavior_TriggerFadeOut_m90EB244EBF6E02CD5C322D45BEB051356B6C31FC_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayable_CreatePlayable_m90CE33D9047496192EF851F340A65B1D55B85D1A_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventPlayable__ctor_m4C710B647727EFEB81066AFC5B15D93AB17C5029_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventTrack_CreateTrackMixer_mE3F815B775E279BC3EB52ADF9A4410A22C6D474D_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineEventTrack__ctor_m6A8944A8AE993C953903280CF96A13D6974D3D08_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineRtpcPlayableBehaviour_ProcessFrame_m4D4DE4F8F487113BA4AB0325E848254695B12859_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineRtpcPlayable_CreatePlayable_m38158F617A5B24DD3A97D2B62A43663BF8F0A284_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineRtpcPlayable__ctor_m658808552E2C6757AC654C6E35D712BD4276A9FF_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineRtpcTrack_CreateTrackMixer_m2C472F84E648753E136071CB95CBBCC47E256D86_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineRtpcTrack_OnValidate_m8B5FECFE2725498C8AB1ED9ACA1E1E984012F887_MetadataUsageId;
IL2CPP_EXTERN_C const uint32_t AkTimelineRtpcTrack__ctor_m176E15107078E586C295768D7200C8F9F0340922_MetadataUsageId;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t87C91374A8FB0EB38B06BBB88DEE4D8956F91D8E 
{
public:

public:
};


// System.Object


// AK.Wwise.BaseType
struct  BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE  : public RuntimeObject
{
public:
	// System.Int32 AK.Wwise.BaseType::idInternal
	int32_t ___idInternal_0;
	// System.Byte[] AK.Wwise.BaseType::valueGuidInternal
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___valueGuidInternal_1;

public:
	inline static int32_t get_offset_of_idInternal_0() { return static_cast<int32_t>(offsetof(BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE, ___idInternal_0)); }
	inline int32_t get_idInternal_0() const { return ___idInternal_0; }
	inline int32_t* get_address_of_idInternal_0() { return &___idInternal_0; }
	inline void set_idInternal_0(int32_t value)
	{
		___idInternal_0 = value;
	}

	inline static int32_t get_offset_of_valueGuidInternal_1() { return static_cast<int32_t>(offsetof(BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE, ___valueGuidInternal_1)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_valueGuidInternal_1() const { return ___valueGuidInternal_1; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_valueGuidInternal_1() { return &___valueGuidInternal_1; }
	inline void set_valueGuidInternal_1(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___valueGuidInternal_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___valueGuidInternal_1), (void*)value);
	}
};

struct Il2CppArrayBounds;

// System.Array


// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};

// UnityEngine.Playables.PlayableBehaviour
struct  PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01  : public RuntimeObject
{
public:

public:
};


// AK.Wwise.Event
struct  Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F  : public BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE
{
public:
	// WwiseEventReference AK.Wwise.Event::WwiseObjectReference
	WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C * ___WwiseObjectReference_2;
	// System.UInt32 AK.Wwise.Event::m_playingId
	uint32_t ___m_playingId_3;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_2() { return static_cast<int32_t>(offsetof(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F, ___WwiseObjectReference_2)); }
	inline WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C * get_WwiseObjectReference_2() const { return ___WwiseObjectReference_2; }
	inline WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C ** get_address_of_WwiseObjectReference_2() { return &___WwiseObjectReference_2; }
	inline void set_WwiseObjectReference_2(WwiseEventReference_t943B473AE40828D95A6B5A0FA34A0BC5D5CF861C * value)
	{
		___WwiseObjectReference_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_2), (void*)value);
	}

	inline static int32_t get_offset_of_m_playingId_3() { return static_cast<int32_t>(offsetof(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F, ___m_playingId_3)); }
	inline uint32_t get_m_playingId_3() const { return ___m_playingId_3; }
	inline uint32_t* get_address_of_m_playingId_3() { return &___m_playingId_3; }
	inline void set_m_playingId_3(uint32_t value)
	{
		___m_playingId_3 = value;
	}
};


// AK.Wwise.RTPC
struct  RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C  : public BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE
{
public:
	// WwiseRtpcReference AK.Wwise.RTPC::WwiseObjectReference
	WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E * ___WwiseObjectReference_2;

public:
	inline static int32_t get_offset_of_WwiseObjectReference_2() { return static_cast<int32_t>(offsetof(RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C, ___WwiseObjectReference_2)); }
	inline WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E * get_WwiseObjectReference_2() const { return ___WwiseObjectReference_2; }
	inline WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E ** get_address_of_WwiseObjectReference_2() { return &___WwiseObjectReference_2; }
	inline void set_WwiseObjectReference_2(WwiseRtpcReference_t03B8373B9BB7F10F5EE2F95FBFC09F2C54531B9E * value)
	{
		___WwiseObjectReference_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WwiseObjectReference_2), (void*)value);
	}
};


// AkRTPCPlayableBehaviour
struct  AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075  : public PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01
{
public:
	// System.Single AkRTPCPlayableBehaviour::RTPCValue
	float ___RTPCValue_0;
	// System.Boolean AkRTPCPlayableBehaviour::<setRTPCGlobally>k__BackingField
	bool ___U3CsetRTPCGloballyU3Ek__BackingField_1;
	// System.Boolean AkRTPCPlayableBehaviour::<overrideTrackObject>k__BackingField
	bool ___U3CoverrideTrackObjectU3Ek__BackingField_2;
	// UnityEngine.GameObject AkRTPCPlayableBehaviour::<rtpcObject>k__BackingField
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___U3CrtpcObjectU3Ek__BackingField_3;
	// AK.Wwise.RTPC AkRTPCPlayableBehaviour::<parameter>k__BackingField
	RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___U3CparameterU3Ek__BackingField_4;

public:
	inline static int32_t get_offset_of_RTPCValue_0() { return static_cast<int32_t>(offsetof(AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075, ___RTPCValue_0)); }
	inline float get_RTPCValue_0() const { return ___RTPCValue_0; }
	inline float* get_address_of_RTPCValue_0() { return &___RTPCValue_0; }
	inline void set_RTPCValue_0(float value)
	{
		___RTPCValue_0 = value;
	}

	inline static int32_t get_offset_of_U3CsetRTPCGloballyU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075, ___U3CsetRTPCGloballyU3Ek__BackingField_1)); }
	inline bool get_U3CsetRTPCGloballyU3Ek__BackingField_1() const { return ___U3CsetRTPCGloballyU3Ek__BackingField_1; }
	inline bool* get_address_of_U3CsetRTPCGloballyU3Ek__BackingField_1() { return &___U3CsetRTPCGloballyU3Ek__BackingField_1; }
	inline void set_U3CsetRTPCGloballyU3Ek__BackingField_1(bool value)
	{
		___U3CsetRTPCGloballyU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CoverrideTrackObjectU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075, ___U3CoverrideTrackObjectU3Ek__BackingField_2)); }
	inline bool get_U3CoverrideTrackObjectU3Ek__BackingField_2() const { return ___U3CoverrideTrackObjectU3Ek__BackingField_2; }
	inline bool* get_address_of_U3CoverrideTrackObjectU3Ek__BackingField_2() { return &___U3CoverrideTrackObjectU3Ek__BackingField_2; }
	inline void set_U3CoverrideTrackObjectU3Ek__BackingField_2(bool value)
	{
		___U3CoverrideTrackObjectU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CrtpcObjectU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075, ___U3CrtpcObjectU3Ek__BackingField_3)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_U3CrtpcObjectU3Ek__BackingField_3() const { return ___U3CrtpcObjectU3Ek__BackingField_3; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_U3CrtpcObjectU3Ek__BackingField_3() { return &___U3CrtpcObjectU3Ek__BackingField_3; }
	inline void set_U3CrtpcObjectU3Ek__BackingField_3(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___U3CrtpcObjectU3Ek__BackingField_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CrtpcObjectU3Ek__BackingField_3), (void*)value);
	}

	inline static int32_t get_offset_of_U3CparameterU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075, ___U3CparameterU3Ek__BackingField_4)); }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * get_U3CparameterU3Ek__BackingField_4() const { return ___U3CparameterU3Ek__BackingField_4; }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C ** get_address_of_U3CparameterU3Ek__BackingField_4() { return &___U3CparameterU3Ek__BackingField_4; }
	inline void set_U3CparameterU3Ek__BackingField_4(RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * value)
	{
		___U3CparameterU3Ek__BackingField_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CparameterU3Ek__BackingField_4), (void*)value);
	}
};


// AkTimelineRtpcPlayableBehaviour
struct  AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E  : public PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01
{
public:
	// System.Single AkTimelineRtpcPlayableBehaviour::value
	float ___value_0;
	// AK.Wwise.RTPC AkTimelineRtpcPlayableBehaviour::<RTPC>k__BackingField
	RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___U3CRTPCU3Ek__BackingField_1;
	// System.Boolean AkTimelineRtpcPlayableBehaviour::<setGlobally>k__BackingField
	bool ___U3CsetGloballyU3Ek__BackingField_2;
	// UnityEngine.GameObject AkTimelineRtpcPlayableBehaviour::<gameObject>k__BackingField
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___U3CgameObjectU3Ek__BackingField_3;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E, ___value_0)); }
	inline float get_value_0() const { return ___value_0; }
	inline float* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(float value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_U3CRTPCU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E, ___U3CRTPCU3Ek__BackingField_1)); }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * get_U3CRTPCU3Ek__BackingField_1() const { return ___U3CRTPCU3Ek__BackingField_1; }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C ** get_address_of_U3CRTPCU3Ek__BackingField_1() { return &___U3CRTPCU3Ek__BackingField_1; }
	inline void set_U3CRTPCU3Ek__BackingField_1(RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * value)
	{
		___U3CRTPCU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CRTPCU3Ek__BackingField_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CsetGloballyU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E, ___U3CsetGloballyU3Ek__BackingField_2)); }
	inline bool get_U3CsetGloballyU3Ek__BackingField_2() const { return ___U3CsetGloballyU3Ek__BackingField_2; }
	inline bool* get_address_of_U3CsetGloballyU3Ek__BackingField_2() { return &___U3CsetGloballyU3Ek__BackingField_2; }
	inline void set_U3CsetGloballyU3Ek__BackingField_2(bool value)
	{
		___U3CsetGloballyU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CgameObjectU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E, ___U3CgameObjectU3Ek__BackingField_3)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_U3CgameObjectU3Ek__BackingField_3() const { return ___U3CgameObjectU3Ek__BackingField_3; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_U3CgameObjectU3Ek__BackingField_3() { return &___U3CgameObjectU3Ek__BackingField_3; }
	inline void set_U3CgameObjectU3Ek__BackingField_3(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___U3CgameObjectU3Ek__BackingField_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CgameObjectU3Ek__BackingField_3), (void*)value);
	}
};


// System.Boolean
struct  Boolean_tB53F6830F670160873277339AA58F15CAED4399C 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TrueString_5), (void*)value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FalseString_6), (void*)value);
	}
};


// System.Double
struct  Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409, ___m_value_0)); }
	inline double get_m_value_0() const { return ___m_value_0; }
	inline double* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(double value)
	{
		___m_value_0 = value;
	}
};

struct Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409_StaticFields
{
public:
	// System.Double System.Double::NegativeZero
	double ___NegativeZero_7;

public:
	inline static int32_t get_offset_of_NegativeZero_7() { return static_cast<int32_t>(offsetof(Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409_StaticFields, ___NegativeZero_7)); }
	inline double get_NegativeZero_7() const { return ___NegativeZero_7; }
	inline double* get_address_of_NegativeZero_7() { return &___NegativeZero_7; }
	inline void set_NegativeZero_7(double value)
	{
		___NegativeZero_7 = value;
	}
};


// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};

// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};


// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// System.Nullable`1<System.Boolean>
struct  Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793 
{
public:
	// T System.Nullable`1::value
	bool ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793, ___value_0)); }
	inline bool get_value_0() const { return ___value_0; }
	inline bool* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(bool value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};


// System.Single
struct  Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};


// System.UInt32
struct  UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};


// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};


// UnityEngine.PropertyName
struct  PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529 
{
public:
	// System.Int32 UnityEngine.PropertyName::id
	int32_t ___id_0;

public:
	inline static int32_t get_offset_of_id_0() { return static_cast<int32_t>(offsetof(PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529, ___id_0)); }
	inline int32_t get_id_0() const { return ___id_0; }
	inline int32_t* get_address_of_id_0() { return &___id_0; }
	inline void set_id_0(int32_t value)
	{
		___id_0 = value;
	}
};


// UnityEngine.Timeline.DiscreteTime
struct  DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047 
{
public:
	// System.Int64 UnityEngine.Timeline.DiscreteTime::m_DiscreteTime
	int64_t ___m_DiscreteTime_2;

public:
	inline static int32_t get_offset_of_m_DiscreteTime_2() { return static_cast<int32_t>(offsetof(DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047, ___m_DiscreteTime_2)); }
	inline int64_t get_m_DiscreteTime_2() const { return ___m_DiscreteTime_2; }
	inline int64_t* get_address_of_m_DiscreteTime_2() { return &___m_DiscreteTime_2; }
	inline void set_m_DiscreteTime_2(int64_t value)
	{
		___m_DiscreteTime_2 = value;
	}
};

struct DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047_StaticFields
{
public:
	// UnityEngine.Timeline.DiscreteTime UnityEngine.Timeline.DiscreteTime::kMaxTime
	DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047  ___kMaxTime_1;

public:
	inline static int32_t get_offset_of_kMaxTime_1() { return static_cast<int32_t>(offsetof(DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047_StaticFields, ___kMaxTime_1)); }
	inline DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047  get_kMaxTime_1() const { return ___kMaxTime_1; }
	inline DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047 * get_address_of_kMaxTime_1() { return &___kMaxTime_1; }
	inline void set_kMaxTime_1(DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047  value)
	{
		___kMaxTime_1 = value;
	}
};


// UnityEngine.Timeline.MarkerList
struct  MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC 
{
public:
	// System.Collections.Generic.List`1<UnityEngine.ScriptableObject> UnityEngine.Timeline.MarkerList::m_Objects
	List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF * ___m_Objects_0;
	// System.Collections.Generic.List`1<UnityEngine.Timeline.IMarker> UnityEngine.Timeline.MarkerList::m_Cache
	List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * ___m_Cache_1;
	// System.Boolean UnityEngine.Timeline.MarkerList::m_CacheDirty
	bool ___m_CacheDirty_2;
	// System.Boolean UnityEngine.Timeline.MarkerList::m_HasNotifications
	bool ___m_HasNotifications_3;

public:
	inline static int32_t get_offset_of_m_Objects_0() { return static_cast<int32_t>(offsetof(MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC, ___m_Objects_0)); }
	inline List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF * get_m_Objects_0() const { return ___m_Objects_0; }
	inline List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF ** get_address_of_m_Objects_0() { return &___m_Objects_0; }
	inline void set_m_Objects_0(List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF * value)
	{
		___m_Objects_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Objects_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_Cache_1() { return static_cast<int32_t>(offsetof(MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC, ___m_Cache_1)); }
	inline List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * get_m_Cache_1() const { return ___m_Cache_1; }
	inline List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC ** get_address_of_m_Cache_1() { return &___m_Cache_1; }
	inline void set_m_Cache_1(List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * value)
	{
		___m_Cache_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Cache_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_CacheDirty_2() { return static_cast<int32_t>(offsetof(MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC, ___m_CacheDirty_2)); }
	inline bool get_m_CacheDirty_2() const { return ___m_CacheDirty_2; }
	inline bool* get_address_of_m_CacheDirty_2() { return &___m_CacheDirty_2; }
	inline void set_m_CacheDirty_2(bool value)
	{
		___m_CacheDirty_2 = value;
	}

	inline static int32_t get_offset_of_m_HasNotifications_3() { return static_cast<int32_t>(offsetof(MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC, ___m_HasNotifications_3)); }
	inline bool get_m_HasNotifications_3() const { return ___m_HasNotifications_3; }
	inline bool* get_address_of_m_HasNotifications_3() { return &___m_HasNotifications_3; }
	inline void set_m_HasNotifications_3(bool value)
	{
		___m_HasNotifications_3 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Timeline.MarkerList
struct MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC_marshaled_pinvoke
{
	List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF * ___m_Objects_0;
	List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * ___m_Cache_1;
	int32_t ___m_CacheDirty_2;
	int32_t ___m_HasNotifications_3;
};
// Native definition for COM marshalling of UnityEngine.Timeline.MarkerList
struct MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC_marshaled_com
{
	List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF * ___m_Objects_0;
	List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * ___m_Cache_1;
	int32_t ___m_CacheDirty_2;
	int32_t ___m_HasNotifications_3;
};

// UnityEngine.Timeline.TrackAsset_TransientBuildData
struct  TransientBuildData_t2CDF71634041677EC226311F30665780C2026744 
{
public:
	// System.Collections.Generic.List`1<UnityEngine.Timeline.TrackAsset> UnityEngine.Timeline.TrackAsset_TransientBuildData::trackList
	List_1_t9EFBDDF9C4ED217F9B47075B2659634AF4988704 * ___trackList_0;
	// System.Collections.Generic.List`1<UnityEngine.Timeline.TimelineClip> UnityEngine.Timeline.TrackAsset_TransientBuildData::clipList
	List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA * ___clipList_1;
	// System.Collections.Generic.List`1<UnityEngine.Timeline.IMarker> UnityEngine.Timeline.TrackAsset_TransientBuildData::markerList
	List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * ___markerList_2;

public:
	inline static int32_t get_offset_of_trackList_0() { return static_cast<int32_t>(offsetof(TransientBuildData_t2CDF71634041677EC226311F30665780C2026744, ___trackList_0)); }
	inline List_1_t9EFBDDF9C4ED217F9B47075B2659634AF4988704 * get_trackList_0() const { return ___trackList_0; }
	inline List_1_t9EFBDDF9C4ED217F9B47075B2659634AF4988704 ** get_address_of_trackList_0() { return &___trackList_0; }
	inline void set_trackList_0(List_1_t9EFBDDF9C4ED217F9B47075B2659634AF4988704 * value)
	{
		___trackList_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___trackList_0), (void*)value);
	}

	inline static int32_t get_offset_of_clipList_1() { return static_cast<int32_t>(offsetof(TransientBuildData_t2CDF71634041677EC226311F30665780C2026744, ___clipList_1)); }
	inline List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA * get_clipList_1() const { return ___clipList_1; }
	inline List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA ** get_address_of_clipList_1() { return &___clipList_1; }
	inline void set_clipList_1(List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA * value)
	{
		___clipList_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___clipList_1), (void*)value);
	}

	inline static int32_t get_offset_of_markerList_2() { return static_cast<int32_t>(offsetof(TransientBuildData_t2CDF71634041677EC226311F30665780C2026744, ___markerList_2)); }
	inline List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * get_markerList_2() const { return ___markerList_2; }
	inline List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC ** get_address_of_markerList_2() { return &___markerList_2; }
	inline void set_markerList_2(List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * value)
	{
		___markerList_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___markerList_2), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Timeline.TrackAsset/TransientBuildData
struct TransientBuildData_t2CDF71634041677EC226311F30665780C2026744_marshaled_pinvoke
{
	List_1_t9EFBDDF9C4ED217F9B47075B2659634AF4988704 * ___trackList_0;
	List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA * ___clipList_1;
	List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * ___markerList_2;
};
// Native definition for COM marshalling of UnityEngine.Timeline.TrackAsset/TransientBuildData
struct TransientBuildData_t2CDF71634041677EC226311F30665780C2026744_marshaled_com
{
	List_1_t9EFBDDF9C4ED217F9B47075B2659634AF4988704 * ___trackList_0;
	List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA * ___clipList_1;
	List_1_t1AED215F7BB55B002913F379B2D00119A92B8FBC * ___markerList_2;
};

// AKRESULT
struct  AKRESULT_tD4180A39C1C146D9D524C690593E626EAC82632D 
{
public:
	// System.Int32 AKRESULT::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AKRESULT_tD4180A39C1C146D9D524C690593E626EAC82632D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkActionOnEventType
struct  AkActionOnEventType_tF50137C5392E8FF66C92CD7FD8C10089C4B7FFDA 
{
public:
	// System.Int32 AkActionOnEventType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AkActionOnEventType_tF50137C5392E8FF66C92CD7FD8C10089C4B7FFDA, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkCallbackInfo
struct  AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979  : public RuntimeObject
{
public:
	// System.IntPtr AkCallbackInfo::swigCPtr
	intptr_t ___swigCPtr_0;
	// System.Boolean AkCallbackInfo::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979, ___swigCPtr_0)); }
	inline intptr_t get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline intptr_t* get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(intptr_t value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};


// AkCallbackType
struct  AkCallbackType_t12D54123FC89B09B3A0DDEDED73128E43067F76C 
{
public:
	// System.Int32 AkCallbackType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AkCallbackType_t12D54123FC89B09B3A0DDEDED73128E43067F76C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkCurveInterpolation
struct  AkCurveInterpolation_t8BCCF34DA2DE3EEC52EB0432F409094258841BA9 
{
public:
	// System.Int32 AkCurveInterpolation::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AkCurveInterpolation_t8BCCF34DA2DE3EEC52EB0432F409094258841BA9, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkEventPlayableBehavior_Actions
struct  Actions_tF79A3A4D3E83DACC27EE23D8822D9220CBBA55A3 
{
public:
	// System.Int32 AkEventPlayableBehavior_Actions::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Actions_tF79A3A4D3E83DACC27EE23D8822D9220CBBA55A3, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkTimelineEventPlayableBehavior_Actions
struct  Actions_t88D74F25217FFAEF9D7145292D3368706E1547B2 
{
public:
	// System.Int32 AkTimelineEventPlayableBehavior_Actions::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Actions_t88D74F25217FFAEF9D7145292D3368706E1547B2, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_target_2), (void*)value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___method_info_7), (void*)value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___original_method_info_8), (void*)value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * get_data_9() const { return ___data_9; }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___data_9), (void*)value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};

// UnityEngine.ExposedReference`1<System.Object>
struct  ExposedReference_1_t6A54AB83F72FCC7CB479D3F39F3CFC074284DF86 
{
public:
	// UnityEngine.PropertyName UnityEngine.ExposedReference`1::exposedName
	PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529  ___exposedName_0;
	// UnityEngine.Object UnityEngine.ExposedReference`1::defaultValue
	Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___defaultValue_1;

public:
	inline static int32_t get_offset_of_exposedName_0() { return static_cast<int32_t>(offsetof(ExposedReference_1_t6A54AB83F72FCC7CB479D3F39F3CFC074284DF86, ___exposedName_0)); }
	inline PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529  get_exposedName_0() const { return ___exposedName_0; }
	inline PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529 * get_address_of_exposedName_0() { return &___exposedName_0; }
	inline void set_exposedName_0(PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529  value)
	{
		___exposedName_0 = value;
	}

	inline static int32_t get_offset_of_defaultValue_1() { return static_cast<int32_t>(offsetof(ExposedReference_1_t6A54AB83F72FCC7CB479D3F39F3CFC074284DF86, ___defaultValue_1)); }
	inline Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * get_defaultValue_1() const { return ___defaultValue_1; }
	inline Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 ** get_address_of_defaultValue_1() { return &___defaultValue_1; }
	inline void set_defaultValue_1(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * value)
	{
		___defaultValue_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___defaultValue_1), (void*)value);
	}
};


// UnityEngine.ExposedReference`1<UnityEngine.GameObject>
struct  ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944 
{
public:
	// UnityEngine.PropertyName UnityEngine.ExposedReference`1::exposedName
	PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529  ___exposedName_0;
	// UnityEngine.Object UnityEngine.ExposedReference`1::defaultValue
	Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___defaultValue_1;

public:
	inline static int32_t get_offset_of_exposedName_0() { return static_cast<int32_t>(offsetof(ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944, ___exposedName_0)); }
	inline PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529  get_exposedName_0() const { return ___exposedName_0; }
	inline PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529 * get_address_of_exposedName_0() { return &___exposedName_0; }
	inline void set_exposedName_0(PropertyName_t75EB843FEA2EC372093479A35C24364D2DF98529  value)
	{
		___exposedName_0 = value;
	}

	inline static int32_t get_offset_of_defaultValue_1() { return static_cast<int32_t>(offsetof(ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944, ___defaultValue_1)); }
	inline Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * get_defaultValue_1() const { return ___defaultValue_1; }
	inline Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 ** get_address_of_defaultValue_1() { return &___defaultValue_1; }
	inline void set_defaultValue_1(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * value)
	{
		___defaultValue_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___defaultValue_1), (void*)value);
	}
};


// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// UnityEngine.Playables.FrameData_EvaluationType
struct  EvaluationType_t86C43C30A6771EA55B35597D98A30567AA4A6A5E 
{
public:
	// System.Int32 UnityEngine.Playables.FrameData_EvaluationType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(EvaluationType_t86C43C30A6771EA55B35597D98A30567AA4A6A5E, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.Playables.FrameData_Flags
struct  Flags_tC705783C7BC90E0953FD3B996C7900B58A452D69 
{
public:
	// System.Int32 UnityEngine.Playables.FrameData_Flags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Flags_tC705783C7BC90E0953FD3B996C7900B58A452D69, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.Playables.PlayableGraph
struct  PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA 
{
public:
	// System.IntPtr UnityEngine.Playables.PlayableGraph::m_Handle
	intptr_t ___m_Handle_0;
	// System.UInt32 UnityEngine.Playables.PlayableGraph::m_Version
	uint32_t ___m_Version_1;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA, ___m_Handle_0)); }
	inline intptr_t get_m_Handle_0() const { return ___m_Handle_0; }
	inline intptr_t* get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(intptr_t value)
	{
		___m_Handle_0 = value;
	}

	inline static int32_t get_offset_of_m_Version_1() { return static_cast<int32_t>(offsetof(PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA, ___m_Version_1)); }
	inline uint32_t get_m_Version_1() const { return ___m_Version_1; }
	inline uint32_t* get_address_of_m_Version_1() { return &___m_Version_1; }
	inline void set_m_Version_1(uint32_t value)
	{
		___m_Version_1 = value;
	}
};


// UnityEngine.Playables.PlayableHandle
struct  PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 
{
public:
	// System.IntPtr UnityEngine.Playables.PlayableHandle::m_Handle
	intptr_t ___m_Handle_0;
	// System.UInt32 UnityEngine.Playables.PlayableHandle::m_Version
	uint32_t ___m_Version_1;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182, ___m_Handle_0)); }
	inline intptr_t get_m_Handle_0() const { return ___m_Handle_0; }
	inline intptr_t* get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(intptr_t value)
	{
		___m_Handle_0 = value;
	}

	inline static int32_t get_offset_of_m_Version_1() { return static_cast<int32_t>(offsetof(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182, ___m_Version_1)); }
	inline uint32_t get_m_Version_1() const { return ___m_Version_1; }
	inline uint32_t* get_address_of_m_Version_1() { return &___m_Version_1; }
	inline void set_m_Version_1(uint32_t value)
	{
		___m_Version_1 = value;
	}
};

struct PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182_StaticFields
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.PlayableHandle::m_Null
	PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  ___m_Null_2;

public:
	inline static int32_t get_offset_of_m_Null_2() { return static_cast<int32_t>(offsetof(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182_StaticFields, ___m_Null_2)); }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  get_m_Null_2() const { return ___m_Null_2; }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 * get_address_of_m_Null_2() { return &___m_Null_2; }
	inline void set_m_Null_2(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  value)
	{
		___m_Null_2 = value;
	}
};


// UnityEngine.Playables.PlayableOutputHandle
struct  PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922 
{
public:
	// System.IntPtr UnityEngine.Playables.PlayableOutputHandle::m_Handle
	intptr_t ___m_Handle_0;
	// System.UInt32 UnityEngine.Playables.PlayableOutputHandle::m_Version
	uint32_t ___m_Version_1;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922, ___m_Handle_0)); }
	inline intptr_t get_m_Handle_0() const { return ___m_Handle_0; }
	inline intptr_t* get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(intptr_t value)
	{
		___m_Handle_0 = value;
	}

	inline static int32_t get_offset_of_m_Version_1() { return static_cast<int32_t>(offsetof(PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922, ___m_Version_1)); }
	inline uint32_t get_m_Version_1() const { return ___m_Version_1; }
	inline uint32_t* get_address_of_m_Version_1() { return &___m_Version_1; }
	inline void set_m_Version_1(uint32_t value)
	{
		___m_Version_1 = value;
	}
};

struct PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922_StaticFields
{
public:
	// UnityEngine.Playables.PlayableOutputHandle UnityEngine.Playables.PlayableOutputHandle::m_Null
	PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922  ___m_Null_2;

public:
	inline static int32_t get_offset_of_m_Null_2() { return static_cast<int32_t>(offsetof(PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922_StaticFields, ___m_Null_2)); }
	inline PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922  get_m_Null_2() const { return ___m_Null_2; }
	inline PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922 * get_address_of_m_Null_2() { return &___m_Null_2; }
	inline void set_m_Null_2(PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922  value)
	{
		___m_Null_2 = value;
	}
};


// UnityEngine.Timeline.ClipCaps
struct  ClipCaps_tF9AB6311CC5A0AA6908A88DCA53CB00208035E46 
{
public:
	// System.Int32 UnityEngine.Timeline.ClipCaps::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ClipCaps_tF9AB6311CC5A0AA6908A88DCA53CB00208035E46, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.Timeline.TimelineClip_BlendCurveMode
struct  BlendCurveMode_t68FF453F9C85DD1968A09AEA576C6173C648F6F1 
{
public:
	// System.Int32 UnityEngine.Timeline.TimelineClip_BlendCurveMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(BlendCurveMode_t68FF453F9C85DD1968A09AEA576C6173C648F6F1, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.Timeline.TimelineClip_ClipExtrapolation
struct  ClipExtrapolation_tC55410C9E61EC3868549509F094A83E2E8314783 
{
public:
	// System.Int32 UnityEngine.Timeline.TimelineClip_ClipExtrapolation::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ClipExtrapolation_tC55410C9E61EC3868549509F094A83E2E8314783, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// AkEventCallbackInfo
struct  AkEventCallbackInfo_t7CA1F9AE48D554FC01CC821754D6C211AB666F37  : public AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979
{
public:
	// System.IntPtr AkEventCallbackInfo::swigCPtr
	intptr_t ___swigCPtr_2;

public:
	inline static int32_t get_offset_of_swigCPtr_2() { return static_cast<int32_t>(offsetof(AkEventCallbackInfo_t7CA1F9AE48D554FC01CC821754D6C211AB666F37, ___swigCPtr_2)); }
	inline intptr_t get_swigCPtr_2() const { return ___swigCPtr_2; }
	inline intptr_t* get_address_of_swigCPtr_2() { return &___swigCPtr_2; }
	inline void set_swigCPtr_2(intptr_t value)
	{
		___swigCPtr_2 = value;
	}
};


// AkEventPlayableBehavior
struct  AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384  : public PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01
{
public:
	// System.Single AkEventPlayableBehavior::currentDuration
	float ___currentDuration_0;
	// System.Single AkEventPlayableBehavior::currentDurationProportion
	float ___currentDurationProportion_1;
	// System.Boolean AkEventPlayableBehavior::eventIsPlaying
	bool ___eventIsPlaying_2;
	// System.Boolean AkEventPlayableBehavior::fadeinTriggered
	bool ___fadeinTriggered_3;
	// System.Boolean AkEventPlayableBehavior::fadeoutTriggered
	bool ___fadeoutTriggered_4;
	// System.Single AkEventPlayableBehavior::previousEventStartTime
	float ___previousEventStartTime_5;
	// AkEventPlayableBehavior_Actions AkEventPlayableBehavior::requiredActions
	int32_t ___requiredActions_7;
	// AK.Wwise.Event AkEventPlayableBehavior::akEvent
	Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * ___akEvent_9;
	// System.Single AkEventPlayableBehavior::eventDurationMax
	float ___eventDurationMax_10;
	// System.Single AkEventPlayableBehavior::eventDurationMin
	float ___eventDurationMin_11;
	// System.Single AkEventPlayableBehavior::blendInDuration
	float ___blendInDuration_12;
	// System.Single AkEventPlayableBehavior::blendOutDuration
	float ___blendOutDuration_13;
	// System.Single AkEventPlayableBehavior::easeInDuration
	float ___easeInDuration_14;
	// System.Single AkEventPlayableBehavior::easeOutDuration
	float ___easeOutDuration_15;
	// AkCurveInterpolation AkEventPlayableBehavior::blendInCurve
	int32_t ___blendInCurve_16;
	// AkCurveInterpolation AkEventPlayableBehavior::blendOutCurve
	int32_t ___blendOutCurve_17;
	// UnityEngine.GameObject AkEventPlayableBehavior::eventObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___eventObject_18;
	// System.Boolean AkEventPlayableBehavior::retriggerEvent
	bool ___retriggerEvent_19;
	// System.Boolean AkEventPlayableBehavior::wasScrubbingAndRequiresRetrigger
	bool ___wasScrubbingAndRequiresRetrigger_20;
	// System.Boolean AkEventPlayableBehavior::StopEventAtClipEnd
	bool ___StopEventAtClipEnd_21;
	// System.Boolean AkEventPlayableBehavior::overrideTrackEmitterObject
	bool ___overrideTrackEmitterObject_22;

public:
	inline static int32_t get_offset_of_currentDuration_0() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___currentDuration_0)); }
	inline float get_currentDuration_0() const { return ___currentDuration_0; }
	inline float* get_address_of_currentDuration_0() { return &___currentDuration_0; }
	inline void set_currentDuration_0(float value)
	{
		___currentDuration_0 = value;
	}

	inline static int32_t get_offset_of_currentDurationProportion_1() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___currentDurationProportion_1)); }
	inline float get_currentDurationProportion_1() const { return ___currentDurationProportion_1; }
	inline float* get_address_of_currentDurationProportion_1() { return &___currentDurationProportion_1; }
	inline void set_currentDurationProportion_1(float value)
	{
		___currentDurationProportion_1 = value;
	}

	inline static int32_t get_offset_of_eventIsPlaying_2() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___eventIsPlaying_2)); }
	inline bool get_eventIsPlaying_2() const { return ___eventIsPlaying_2; }
	inline bool* get_address_of_eventIsPlaying_2() { return &___eventIsPlaying_2; }
	inline void set_eventIsPlaying_2(bool value)
	{
		___eventIsPlaying_2 = value;
	}

	inline static int32_t get_offset_of_fadeinTriggered_3() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___fadeinTriggered_3)); }
	inline bool get_fadeinTriggered_3() const { return ___fadeinTriggered_3; }
	inline bool* get_address_of_fadeinTriggered_3() { return &___fadeinTriggered_3; }
	inline void set_fadeinTriggered_3(bool value)
	{
		___fadeinTriggered_3 = value;
	}

	inline static int32_t get_offset_of_fadeoutTriggered_4() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___fadeoutTriggered_4)); }
	inline bool get_fadeoutTriggered_4() const { return ___fadeoutTriggered_4; }
	inline bool* get_address_of_fadeoutTriggered_4() { return &___fadeoutTriggered_4; }
	inline void set_fadeoutTriggered_4(bool value)
	{
		___fadeoutTriggered_4 = value;
	}

	inline static int32_t get_offset_of_previousEventStartTime_5() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___previousEventStartTime_5)); }
	inline float get_previousEventStartTime_5() const { return ___previousEventStartTime_5; }
	inline float* get_address_of_previousEventStartTime_5() { return &___previousEventStartTime_5; }
	inline void set_previousEventStartTime_5(float value)
	{
		___previousEventStartTime_5 = value;
	}

	inline static int32_t get_offset_of_requiredActions_7() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___requiredActions_7)); }
	inline int32_t get_requiredActions_7() const { return ___requiredActions_7; }
	inline int32_t* get_address_of_requiredActions_7() { return &___requiredActions_7; }
	inline void set_requiredActions_7(int32_t value)
	{
		___requiredActions_7 = value;
	}

	inline static int32_t get_offset_of_akEvent_9() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___akEvent_9)); }
	inline Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * get_akEvent_9() const { return ___akEvent_9; }
	inline Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F ** get_address_of_akEvent_9() { return &___akEvent_9; }
	inline void set_akEvent_9(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * value)
	{
		___akEvent_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___akEvent_9), (void*)value);
	}

	inline static int32_t get_offset_of_eventDurationMax_10() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___eventDurationMax_10)); }
	inline float get_eventDurationMax_10() const { return ___eventDurationMax_10; }
	inline float* get_address_of_eventDurationMax_10() { return &___eventDurationMax_10; }
	inline void set_eventDurationMax_10(float value)
	{
		___eventDurationMax_10 = value;
	}

	inline static int32_t get_offset_of_eventDurationMin_11() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___eventDurationMin_11)); }
	inline float get_eventDurationMin_11() const { return ___eventDurationMin_11; }
	inline float* get_address_of_eventDurationMin_11() { return &___eventDurationMin_11; }
	inline void set_eventDurationMin_11(float value)
	{
		___eventDurationMin_11 = value;
	}

	inline static int32_t get_offset_of_blendInDuration_12() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___blendInDuration_12)); }
	inline float get_blendInDuration_12() const { return ___blendInDuration_12; }
	inline float* get_address_of_blendInDuration_12() { return &___blendInDuration_12; }
	inline void set_blendInDuration_12(float value)
	{
		___blendInDuration_12 = value;
	}

	inline static int32_t get_offset_of_blendOutDuration_13() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___blendOutDuration_13)); }
	inline float get_blendOutDuration_13() const { return ___blendOutDuration_13; }
	inline float* get_address_of_blendOutDuration_13() { return &___blendOutDuration_13; }
	inline void set_blendOutDuration_13(float value)
	{
		___blendOutDuration_13 = value;
	}

	inline static int32_t get_offset_of_easeInDuration_14() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___easeInDuration_14)); }
	inline float get_easeInDuration_14() const { return ___easeInDuration_14; }
	inline float* get_address_of_easeInDuration_14() { return &___easeInDuration_14; }
	inline void set_easeInDuration_14(float value)
	{
		___easeInDuration_14 = value;
	}

	inline static int32_t get_offset_of_easeOutDuration_15() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___easeOutDuration_15)); }
	inline float get_easeOutDuration_15() const { return ___easeOutDuration_15; }
	inline float* get_address_of_easeOutDuration_15() { return &___easeOutDuration_15; }
	inline void set_easeOutDuration_15(float value)
	{
		___easeOutDuration_15 = value;
	}

	inline static int32_t get_offset_of_blendInCurve_16() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___blendInCurve_16)); }
	inline int32_t get_blendInCurve_16() const { return ___blendInCurve_16; }
	inline int32_t* get_address_of_blendInCurve_16() { return &___blendInCurve_16; }
	inline void set_blendInCurve_16(int32_t value)
	{
		___blendInCurve_16 = value;
	}

	inline static int32_t get_offset_of_blendOutCurve_17() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___blendOutCurve_17)); }
	inline int32_t get_blendOutCurve_17() const { return ___blendOutCurve_17; }
	inline int32_t* get_address_of_blendOutCurve_17() { return &___blendOutCurve_17; }
	inline void set_blendOutCurve_17(int32_t value)
	{
		___blendOutCurve_17 = value;
	}

	inline static int32_t get_offset_of_eventObject_18() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___eventObject_18)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_eventObject_18() const { return ___eventObject_18; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_eventObject_18() { return &___eventObject_18; }
	inline void set_eventObject_18(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___eventObject_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___eventObject_18), (void*)value);
	}

	inline static int32_t get_offset_of_retriggerEvent_19() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___retriggerEvent_19)); }
	inline bool get_retriggerEvent_19() const { return ___retriggerEvent_19; }
	inline bool* get_address_of_retriggerEvent_19() { return &___retriggerEvent_19; }
	inline void set_retriggerEvent_19(bool value)
	{
		___retriggerEvent_19 = value;
	}

	inline static int32_t get_offset_of_wasScrubbingAndRequiresRetrigger_20() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___wasScrubbingAndRequiresRetrigger_20)); }
	inline bool get_wasScrubbingAndRequiresRetrigger_20() const { return ___wasScrubbingAndRequiresRetrigger_20; }
	inline bool* get_address_of_wasScrubbingAndRequiresRetrigger_20() { return &___wasScrubbingAndRequiresRetrigger_20; }
	inline void set_wasScrubbingAndRequiresRetrigger_20(bool value)
	{
		___wasScrubbingAndRequiresRetrigger_20 = value;
	}

	inline static int32_t get_offset_of_StopEventAtClipEnd_21() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___StopEventAtClipEnd_21)); }
	inline bool get_StopEventAtClipEnd_21() const { return ___StopEventAtClipEnd_21; }
	inline bool* get_address_of_StopEventAtClipEnd_21() { return &___StopEventAtClipEnd_21; }
	inline void set_StopEventAtClipEnd_21(bool value)
	{
		___StopEventAtClipEnd_21 = value;
	}

	inline static int32_t get_offset_of_overrideTrackEmitterObject_22() { return static_cast<int32_t>(offsetof(AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384, ___overrideTrackEmitterObject_22)); }
	inline bool get_overrideTrackEmitterObject_22() const { return ___overrideTrackEmitterObject_22; }
	inline bool* get_address_of_overrideTrackEmitterObject_22() { return &___overrideTrackEmitterObject_22; }
	inline void set_overrideTrackEmitterObject_22(bool value)
	{
		___overrideTrackEmitterObject_22 = value;
	}
};


// AkTimelineEventPlayableBehavior
struct  AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844  : public PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01
{
public:
	// System.Single AkTimelineEventPlayableBehavior::currentDuration
	float ___currentDuration_0;
	// System.Single AkTimelineEventPlayableBehavior::currentDurationProportion
	float ___currentDurationProportion_1;
	// System.Boolean AkTimelineEventPlayableBehavior::eventIsPlaying
	bool ___eventIsPlaying_2;
	// System.Boolean AkTimelineEventPlayableBehavior::fadeinTriggered
	bool ___fadeinTriggered_3;
	// System.Boolean AkTimelineEventPlayableBehavior::fadeoutTriggered
	bool ___fadeoutTriggered_4;
	// System.Single AkTimelineEventPlayableBehavior::previousEventStartTime
	float ___previousEventStartTime_5;
	// AkTimelineEventPlayableBehavior_Actions AkTimelineEventPlayableBehavior::requiredActions
	int32_t ___requiredActions_7;
	// AK.Wwise.Event AkTimelineEventPlayableBehavior::akEvent
	Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * ___akEvent_9;
	// System.Single AkTimelineEventPlayableBehavior::eventDurationMax
	float ___eventDurationMax_10;
	// System.Single AkTimelineEventPlayableBehavior::eventDurationMin
	float ___eventDurationMin_11;
	// System.Single AkTimelineEventPlayableBehavior::blendInDuration
	float ___blendInDuration_12;
	// System.Single AkTimelineEventPlayableBehavior::blendOutDuration
	float ___blendOutDuration_13;
	// System.Single AkTimelineEventPlayableBehavior::easeInDuration
	float ___easeInDuration_14;
	// System.Single AkTimelineEventPlayableBehavior::easeOutDuration
	float ___easeOutDuration_15;
	// AkCurveInterpolation AkTimelineEventPlayableBehavior::blendInCurve
	int32_t ___blendInCurve_16;
	// AkCurveInterpolation AkTimelineEventPlayableBehavior::blendOutCurve
	int32_t ___blendOutCurve_17;
	// UnityEngine.GameObject AkTimelineEventPlayableBehavior::eventObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___eventObject_18;
	// System.Boolean AkTimelineEventPlayableBehavior::retriggerEvent
	bool ___retriggerEvent_19;
	// System.Boolean AkTimelineEventPlayableBehavior::wasScrubbingAndRequiresRetrigger
	bool ___wasScrubbingAndRequiresRetrigger_20;
	// System.Boolean AkTimelineEventPlayableBehavior::StopEventAtClipEnd
	bool ___StopEventAtClipEnd_21;

public:
	inline static int32_t get_offset_of_currentDuration_0() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___currentDuration_0)); }
	inline float get_currentDuration_0() const { return ___currentDuration_0; }
	inline float* get_address_of_currentDuration_0() { return &___currentDuration_0; }
	inline void set_currentDuration_0(float value)
	{
		___currentDuration_0 = value;
	}

	inline static int32_t get_offset_of_currentDurationProportion_1() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___currentDurationProportion_1)); }
	inline float get_currentDurationProportion_1() const { return ___currentDurationProportion_1; }
	inline float* get_address_of_currentDurationProportion_1() { return &___currentDurationProportion_1; }
	inline void set_currentDurationProportion_1(float value)
	{
		___currentDurationProportion_1 = value;
	}

	inline static int32_t get_offset_of_eventIsPlaying_2() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___eventIsPlaying_2)); }
	inline bool get_eventIsPlaying_2() const { return ___eventIsPlaying_2; }
	inline bool* get_address_of_eventIsPlaying_2() { return &___eventIsPlaying_2; }
	inline void set_eventIsPlaying_2(bool value)
	{
		___eventIsPlaying_2 = value;
	}

	inline static int32_t get_offset_of_fadeinTriggered_3() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___fadeinTriggered_3)); }
	inline bool get_fadeinTriggered_3() const { return ___fadeinTriggered_3; }
	inline bool* get_address_of_fadeinTriggered_3() { return &___fadeinTriggered_3; }
	inline void set_fadeinTriggered_3(bool value)
	{
		___fadeinTriggered_3 = value;
	}

	inline static int32_t get_offset_of_fadeoutTriggered_4() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___fadeoutTriggered_4)); }
	inline bool get_fadeoutTriggered_4() const { return ___fadeoutTriggered_4; }
	inline bool* get_address_of_fadeoutTriggered_4() { return &___fadeoutTriggered_4; }
	inline void set_fadeoutTriggered_4(bool value)
	{
		___fadeoutTriggered_4 = value;
	}

	inline static int32_t get_offset_of_previousEventStartTime_5() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___previousEventStartTime_5)); }
	inline float get_previousEventStartTime_5() const { return ___previousEventStartTime_5; }
	inline float* get_address_of_previousEventStartTime_5() { return &___previousEventStartTime_5; }
	inline void set_previousEventStartTime_5(float value)
	{
		___previousEventStartTime_5 = value;
	}

	inline static int32_t get_offset_of_requiredActions_7() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___requiredActions_7)); }
	inline int32_t get_requiredActions_7() const { return ___requiredActions_7; }
	inline int32_t* get_address_of_requiredActions_7() { return &___requiredActions_7; }
	inline void set_requiredActions_7(int32_t value)
	{
		___requiredActions_7 = value;
	}

	inline static int32_t get_offset_of_akEvent_9() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___akEvent_9)); }
	inline Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * get_akEvent_9() const { return ___akEvent_9; }
	inline Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F ** get_address_of_akEvent_9() { return &___akEvent_9; }
	inline void set_akEvent_9(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * value)
	{
		___akEvent_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___akEvent_9), (void*)value);
	}

	inline static int32_t get_offset_of_eventDurationMax_10() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___eventDurationMax_10)); }
	inline float get_eventDurationMax_10() const { return ___eventDurationMax_10; }
	inline float* get_address_of_eventDurationMax_10() { return &___eventDurationMax_10; }
	inline void set_eventDurationMax_10(float value)
	{
		___eventDurationMax_10 = value;
	}

	inline static int32_t get_offset_of_eventDurationMin_11() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___eventDurationMin_11)); }
	inline float get_eventDurationMin_11() const { return ___eventDurationMin_11; }
	inline float* get_address_of_eventDurationMin_11() { return &___eventDurationMin_11; }
	inline void set_eventDurationMin_11(float value)
	{
		___eventDurationMin_11 = value;
	}

	inline static int32_t get_offset_of_blendInDuration_12() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___blendInDuration_12)); }
	inline float get_blendInDuration_12() const { return ___blendInDuration_12; }
	inline float* get_address_of_blendInDuration_12() { return &___blendInDuration_12; }
	inline void set_blendInDuration_12(float value)
	{
		___blendInDuration_12 = value;
	}

	inline static int32_t get_offset_of_blendOutDuration_13() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___blendOutDuration_13)); }
	inline float get_blendOutDuration_13() const { return ___blendOutDuration_13; }
	inline float* get_address_of_blendOutDuration_13() { return &___blendOutDuration_13; }
	inline void set_blendOutDuration_13(float value)
	{
		___blendOutDuration_13 = value;
	}

	inline static int32_t get_offset_of_easeInDuration_14() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___easeInDuration_14)); }
	inline float get_easeInDuration_14() const { return ___easeInDuration_14; }
	inline float* get_address_of_easeInDuration_14() { return &___easeInDuration_14; }
	inline void set_easeInDuration_14(float value)
	{
		___easeInDuration_14 = value;
	}

	inline static int32_t get_offset_of_easeOutDuration_15() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___easeOutDuration_15)); }
	inline float get_easeOutDuration_15() const { return ___easeOutDuration_15; }
	inline float* get_address_of_easeOutDuration_15() { return &___easeOutDuration_15; }
	inline void set_easeOutDuration_15(float value)
	{
		___easeOutDuration_15 = value;
	}

	inline static int32_t get_offset_of_blendInCurve_16() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___blendInCurve_16)); }
	inline int32_t get_blendInCurve_16() const { return ___blendInCurve_16; }
	inline int32_t* get_address_of_blendInCurve_16() { return &___blendInCurve_16; }
	inline void set_blendInCurve_16(int32_t value)
	{
		___blendInCurve_16 = value;
	}

	inline static int32_t get_offset_of_blendOutCurve_17() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___blendOutCurve_17)); }
	inline int32_t get_blendOutCurve_17() const { return ___blendOutCurve_17; }
	inline int32_t* get_address_of_blendOutCurve_17() { return &___blendOutCurve_17; }
	inline void set_blendOutCurve_17(int32_t value)
	{
		___blendOutCurve_17 = value;
	}

	inline static int32_t get_offset_of_eventObject_18() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___eventObject_18)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_eventObject_18() const { return ___eventObject_18; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_eventObject_18() { return &___eventObject_18; }
	inline void set_eventObject_18(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___eventObject_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___eventObject_18), (void*)value);
	}

	inline static int32_t get_offset_of_retriggerEvent_19() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___retriggerEvent_19)); }
	inline bool get_retriggerEvent_19() const { return ___retriggerEvent_19; }
	inline bool* get_address_of_retriggerEvent_19() { return &___retriggerEvent_19; }
	inline void set_retriggerEvent_19(bool value)
	{
		___retriggerEvent_19 = value;
	}

	inline static int32_t get_offset_of_wasScrubbingAndRequiresRetrigger_20() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___wasScrubbingAndRequiresRetrigger_20)); }
	inline bool get_wasScrubbingAndRequiresRetrigger_20() const { return ___wasScrubbingAndRequiresRetrigger_20; }
	inline bool* get_address_of_wasScrubbingAndRequiresRetrigger_20() { return &___wasScrubbingAndRequiresRetrigger_20; }
	inline void set_wasScrubbingAndRequiresRetrigger_20(bool value)
	{
		___wasScrubbingAndRequiresRetrigger_20 = value;
	}

	inline static int32_t get_offset_of_StopEventAtClipEnd_21() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844, ___StopEventAtClipEnd_21)); }
	inline bool get_StopEventAtClipEnd_21() const { return ___StopEventAtClipEnd_21; }
	inline bool* get_address_of_StopEventAtClipEnd_21() { return &___StopEventAtClipEnd_21; }
	inline void set_StopEventAtClipEnd_21(bool value)
	{
		___StopEventAtClipEnd_21 = value;
	}
};


// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___delegates_11), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};

// UnityEngine.GameObject
struct  GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};


// UnityEngine.Playables.Playable
struct  Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.Playable::m_Handle
	PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0, ___m_Handle_0)); }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  value)
	{
		___m_Handle_0 = value;
	}
};

struct Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_StaticFields
{
public:
	// UnityEngine.Playables.Playable UnityEngine.Playables.Playable::m_NullPlayable
	Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___m_NullPlayable_1;

public:
	inline static int32_t get_offset_of_m_NullPlayable_1() { return static_cast<int32_t>(offsetof(Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_StaticFields, ___m_NullPlayable_1)); }
	inline Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  get_m_NullPlayable_1() const { return ___m_NullPlayable_1; }
	inline Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0 * get_address_of_m_NullPlayable_1() { return &___m_NullPlayable_1; }
	inline void set_m_NullPlayable_1(Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  value)
	{
		___m_NullPlayable_1 = value;
	}
};


// UnityEngine.Playables.PlayableOutput
struct  PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345 
{
public:
	// UnityEngine.Playables.PlayableOutputHandle UnityEngine.Playables.PlayableOutput::m_Handle
	PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345, ___m_Handle_0)); }
	inline PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableOutputHandle_t0D0C9D8ACC1A4061BD4EAEB61F3EE0357052F922  value)
	{
		___m_Handle_0 = value;
	}
};

struct PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345_StaticFields
{
public:
	// UnityEngine.Playables.PlayableOutput UnityEngine.Playables.PlayableOutput::m_NullPlayableOutput
	PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345  ___m_NullPlayableOutput_1;

public:
	inline static int32_t get_offset_of_m_NullPlayableOutput_1() { return static_cast<int32_t>(offsetof(PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345_StaticFields, ___m_NullPlayableOutput_1)); }
	inline PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345  get_m_NullPlayableOutput_1() const { return ___m_NullPlayableOutput_1; }
	inline PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345 * get_address_of_m_NullPlayableOutput_1() { return &___m_NullPlayableOutput_1; }
	inline void set_m_NullPlayableOutput_1(PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345  value)
	{
		___m_NullPlayableOutput_1 = value;
	}
};


// UnityEngine.Playables.ScriptPlayable`1<AkEventPlayableBehavior>
struct  ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.ScriptPlayable`1::m_Handle
	PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91, ___m_Handle_0)); }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  value)
	{
		___m_Handle_0 = value;
	}
};

struct ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_StaticFields
{
public:
	// UnityEngine.Playables.ScriptPlayable`1<T> UnityEngine.Playables.ScriptPlayable`1::m_NullPlayable
	ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  ___m_NullPlayable_1;

public:
	inline static int32_t get_offset_of_m_NullPlayable_1() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_StaticFields, ___m_NullPlayable_1)); }
	inline ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  get_m_NullPlayable_1() const { return ___m_NullPlayable_1; }
	inline ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91 * get_address_of_m_NullPlayable_1() { return &___m_NullPlayable_1; }
	inline void set_m_NullPlayable_1(ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  value)
	{
		___m_NullPlayable_1 = value;
	}
};


// UnityEngine.Playables.ScriptPlayable`1<AkRTPCPlayableBehaviour>
struct  ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.ScriptPlayable`1::m_Handle
	PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B, ___m_Handle_0)); }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  value)
	{
		___m_Handle_0 = value;
	}
};

struct ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B_StaticFields
{
public:
	// UnityEngine.Playables.ScriptPlayable`1<T> UnityEngine.Playables.ScriptPlayable`1::m_NullPlayable
	ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  ___m_NullPlayable_1;

public:
	inline static int32_t get_offset_of_m_NullPlayable_1() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B_StaticFields, ___m_NullPlayable_1)); }
	inline ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  get_m_NullPlayable_1() const { return ___m_NullPlayable_1; }
	inline ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B * get_address_of_m_NullPlayable_1() { return &___m_NullPlayable_1; }
	inline void set_m_NullPlayable_1(ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  value)
	{
		___m_NullPlayable_1 = value;
	}
};


// UnityEngine.Playables.ScriptPlayable`1<AkTimelineEventPlayableBehavior>
struct  ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.ScriptPlayable`1::m_Handle
	PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC, ___m_Handle_0)); }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  value)
	{
		___m_Handle_0 = value;
	}
};

struct ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_StaticFields
{
public:
	// UnityEngine.Playables.ScriptPlayable`1<T> UnityEngine.Playables.ScriptPlayable`1::m_NullPlayable
	ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  ___m_NullPlayable_1;

public:
	inline static int32_t get_offset_of_m_NullPlayable_1() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_StaticFields, ___m_NullPlayable_1)); }
	inline ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  get_m_NullPlayable_1() const { return ___m_NullPlayable_1; }
	inline ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC * get_address_of_m_NullPlayable_1() { return &___m_NullPlayable_1; }
	inline void set_m_NullPlayable_1(ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  value)
	{
		___m_NullPlayable_1 = value;
	}
};


// UnityEngine.Playables.ScriptPlayable`1<AkTimelineRtpcPlayableBehaviour>
struct  ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.ScriptPlayable`1::m_Handle
	PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F, ___m_Handle_0)); }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  value)
	{
		___m_Handle_0 = value;
	}
};

struct ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F_StaticFields
{
public:
	// UnityEngine.Playables.ScriptPlayable`1<T> UnityEngine.Playables.ScriptPlayable`1::m_NullPlayable
	ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  ___m_NullPlayable_1;

public:
	inline static int32_t get_offset_of_m_NullPlayable_1() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F_StaticFields, ___m_NullPlayable_1)); }
	inline ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  get_m_NullPlayable_1() const { return ___m_NullPlayable_1; }
	inline ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F * get_address_of_m_NullPlayable_1() { return &___m_NullPlayable_1; }
	inline void set_m_NullPlayable_1(ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  value)
	{
		___m_NullPlayable_1 = value;
	}
};


// UnityEngine.Playables.ScriptPlayable`1<System.Object>
struct  ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.ScriptPlayable`1::m_Handle
	PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C, ___m_Handle_0)); }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  value)
	{
		___m_Handle_0 = value;
	}
};

struct ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C_StaticFields
{
public:
	// UnityEngine.Playables.ScriptPlayable`1<T> UnityEngine.Playables.ScriptPlayable`1::m_NullPlayable
	ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C  ___m_NullPlayable_1;

public:
	inline static int32_t get_offset_of_m_NullPlayable_1() { return static_cast<int32_t>(offsetof(ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C_StaticFields, ___m_NullPlayable_1)); }
	inline ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C  get_m_NullPlayable_1() const { return ___m_NullPlayable_1; }
	inline ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C * get_address_of_m_NullPlayable_1() { return &___m_NullPlayable_1; }
	inline void set_m_NullPlayable_1(ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C  value)
	{
		___m_NullPlayable_1 = value;
	}
};


// UnityEngine.ScriptableObject
struct  ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_pinvoke : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_com : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
};

// UnityEngine.Timeline.TimelineClip
struct  TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB  : public RuntimeObject
{
public:
	// System.Int32 UnityEngine.Timeline.TimelineClip::m_Version
	int32_t ___m_Version_1;
	// System.Double UnityEngine.Timeline.TimelineClip::m_Start
	double ___m_Start_9;
	// System.Double UnityEngine.Timeline.TimelineClip::m_ClipIn
	double ___m_ClipIn_10;
	// UnityEngine.Object UnityEngine.Timeline.TimelineClip::m_Asset
	Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___m_Asset_11;
	// System.Double UnityEngine.Timeline.TimelineClip::m_Duration
	double ___m_Duration_12;
	// System.Double UnityEngine.Timeline.TimelineClip::m_TimeScale
	double ___m_TimeScale_13;
	// UnityEngine.Timeline.TrackAsset UnityEngine.Timeline.TimelineClip::m_ParentTrack
	TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D * ___m_ParentTrack_14;
	// System.Double UnityEngine.Timeline.TimelineClip::m_EaseInDuration
	double ___m_EaseInDuration_15;
	// System.Double UnityEngine.Timeline.TimelineClip::m_EaseOutDuration
	double ___m_EaseOutDuration_16;
	// System.Double UnityEngine.Timeline.TimelineClip::m_BlendInDuration
	double ___m_BlendInDuration_17;
	// System.Double UnityEngine.Timeline.TimelineClip::m_BlendOutDuration
	double ___m_BlendOutDuration_18;
	// UnityEngine.AnimationCurve UnityEngine.Timeline.TimelineClip::m_MixInCurve
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___m_MixInCurve_19;
	// UnityEngine.AnimationCurve UnityEngine.Timeline.TimelineClip::m_MixOutCurve
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___m_MixOutCurve_20;
	// UnityEngine.Timeline.TimelineClip_BlendCurveMode UnityEngine.Timeline.TimelineClip::m_BlendInCurveMode
	int32_t ___m_BlendInCurveMode_21;
	// UnityEngine.Timeline.TimelineClip_BlendCurveMode UnityEngine.Timeline.TimelineClip::m_BlendOutCurveMode
	int32_t ___m_BlendOutCurveMode_22;
	// System.Collections.Generic.List`1<System.String> UnityEngine.Timeline.TimelineClip::m_ExposedParameterNames
	List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * ___m_ExposedParameterNames_23;
	// UnityEngine.AnimationClip UnityEngine.Timeline.TimelineClip::m_AnimationCurves
	AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE * ___m_AnimationCurves_24;
	// System.Boolean UnityEngine.Timeline.TimelineClip::m_Recordable
	bool ___m_Recordable_25;
	// UnityEngine.Timeline.TimelineClip_ClipExtrapolation UnityEngine.Timeline.TimelineClip::m_PostExtrapolationMode
	int32_t ___m_PostExtrapolationMode_26;
	// UnityEngine.Timeline.TimelineClip_ClipExtrapolation UnityEngine.Timeline.TimelineClip::m_PreExtrapolationMode
	int32_t ___m_PreExtrapolationMode_27;
	// System.Double UnityEngine.Timeline.TimelineClip::m_PostExtrapolationTime
	double ___m_PostExtrapolationTime_28;
	// System.Double UnityEngine.Timeline.TimelineClip::m_PreExtrapolationTime
	double ___m_PreExtrapolationTime_29;
	// System.String UnityEngine.Timeline.TimelineClip::m_DisplayName
	String_t* ___m_DisplayName_30;

public:
	inline static int32_t get_offset_of_m_Version_1() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_Version_1)); }
	inline int32_t get_m_Version_1() const { return ___m_Version_1; }
	inline int32_t* get_address_of_m_Version_1() { return &___m_Version_1; }
	inline void set_m_Version_1(int32_t value)
	{
		___m_Version_1 = value;
	}

	inline static int32_t get_offset_of_m_Start_9() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_Start_9)); }
	inline double get_m_Start_9() const { return ___m_Start_9; }
	inline double* get_address_of_m_Start_9() { return &___m_Start_9; }
	inline void set_m_Start_9(double value)
	{
		___m_Start_9 = value;
	}

	inline static int32_t get_offset_of_m_ClipIn_10() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_ClipIn_10)); }
	inline double get_m_ClipIn_10() const { return ___m_ClipIn_10; }
	inline double* get_address_of_m_ClipIn_10() { return &___m_ClipIn_10; }
	inline void set_m_ClipIn_10(double value)
	{
		___m_ClipIn_10 = value;
	}

	inline static int32_t get_offset_of_m_Asset_11() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_Asset_11)); }
	inline Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * get_m_Asset_11() const { return ___m_Asset_11; }
	inline Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 ** get_address_of_m_Asset_11() { return &___m_Asset_11; }
	inline void set_m_Asset_11(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * value)
	{
		___m_Asset_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Asset_11), (void*)value);
	}

	inline static int32_t get_offset_of_m_Duration_12() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_Duration_12)); }
	inline double get_m_Duration_12() const { return ___m_Duration_12; }
	inline double* get_address_of_m_Duration_12() { return &___m_Duration_12; }
	inline void set_m_Duration_12(double value)
	{
		___m_Duration_12 = value;
	}

	inline static int32_t get_offset_of_m_TimeScale_13() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_TimeScale_13)); }
	inline double get_m_TimeScale_13() const { return ___m_TimeScale_13; }
	inline double* get_address_of_m_TimeScale_13() { return &___m_TimeScale_13; }
	inline void set_m_TimeScale_13(double value)
	{
		___m_TimeScale_13 = value;
	}

	inline static int32_t get_offset_of_m_ParentTrack_14() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_ParentTrack_14)); }
	inline TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D * get_m_ParentTrack_14() const { return ___m_ParentTrack_14; }
	inline TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D ** get_address_of_m_ParentTrack_14() { return &___m_ParentTrack_14; }
	inline void set_m_ParentTrack_14(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D * value)
	{
		___m_ParentTrack_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ParentTrack_14), (void*)value);
	}

	inline static int32_t get_offset_of_m_EaseInDuration_15() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_EaseInDuration_15)); }
	inline double get_m_EaseInDuration_15() const { return ___m_EaseInDuration_15; }
	inline double* get_address_of_m_EaseInDuration_15() { return &___m_EaseInDuration_15; }
	inline void set_m_EaseInDuration_15(double value)
	{
		___m_EaseInDuration_15 = value;
	}

	inline static int32_t get_offset_of_m_EaseOutDuration_16() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_EaseOutDuration_16)); }
	inline double get_m_EaseOutDuration_16() const { return ___m_EaseOutDuration_16; }
	inline double* get_address_of_m_EaseOutDuration_16() { return &___m_EaseOutDuration_16; }
	inline void set_m_EaseOutDuration_16(double value)
	{
		___m_EaseOutDuration_16 = value;
	}

	inline static int32_t get_offset_of_m_BlendInDuration_17() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_BlendInDuration_17)); }
	inline double get_m_BlendInDuration_17() const { return ___m_BlendInDuration_17; }
	inline double* get_address_of_m_BlendInDuration_17() { return &___m_BlendInDuration_17; }
	inline void set_m_BlendInDuration_17(double value)
	{
		___m_BlendInDuration_17 = value;
	}

	inline static int32_t get_offset_of_m_BlendOutDuration_18() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_BlendOutDuration_18)); }
	inline double get_m_BlendOutDuration_18() const { return ___m_BlendOutDuration_18; }
	inline double* get_address_of_m_BlendOutDuration_18() { return &___m_BlendOutDuration_18; }
	inline void set_m_BlendOutDuration_18(double value)
	{
		___m_BlendOutDuration_18 = value;
	}

	inline static int32_t get_offset_of_m_MixInCurve_19() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_MixInCurve_19)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_m_MixInCurve_19() const { return ___m_MixInCurve_19; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_m_MixInCurve_19() { return &___m_MixInCurve_19; }
	inline void set_m_MixInCurve_19(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___m_MixInCurve_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_MixInCurve_19), (void*)value);
	}

	inline static int32_t get_offset_of_m_MixOutCurve_20() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_MixOutCurve_20)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_m_MixOutCurve_20() const { return ___m_MixOutCurve_20; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_m_MixOutCurve_20() { return &___m_MixOutCurve_20; }
	inline void set_m_MixOutCurve_20(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___m_MixOutCurve_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_MixOutCurve_20), (void*)value);
	}

	inline static int32_t get_offset_of_m_BlendInCurveMode_21() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_BlendInCurveMode_21)); }
	inline int32_t get_m_BlendInCurveMode_21() const { return ___m_BlendInCurveMode_21; }
	inline int32_t* get_address_of_m_BlendInCurveMode_21() { return &___m_BlendInCurveMode_21; }
	inline void set_m_BlendInCurveMode_21(int32_t value)
	{
		___m_BlendInCurveMode_21 = value;
	}

	inline static int32_t get_offset_of_m_BlendOutCurveMode_22() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_BlendOutCurveMode_22)); }
	inline int32_t get_m_BlendOutCurveMode_22() const { return ___m_BlendOutCurveMode_22; }
	inline int32_t* get_address_of_m_BlendOutCurveMode_22() { return &___m_BlendOutCurveMode_22; }
	inline void set_m_BlendOutCurveMode_22(int32_t value)
	{
		___m_BlendOutCurveMode_22 = value;
	}

	inline static int32_t get_offset_of_m_ExposedParameterNames_23() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_ExposedParameterNames_23)); }
	inline List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * get_m_ExposedParameterNames_23() const { return ___m_ExposedParameterNames_23; }
	inline List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 ** get_address_of_m_ExposedParameterNames_23() { return &___m_ExposedParameterNames_23; }
	inline void set_m_ExposedParameterNames_23(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * value)
	{
		___m_ExposedParameterNames_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ExposedParameterNames_23), (void*)value);
	}

	inline static int32_t get_offset_of_m_AnimationCurves_24() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_AnimationCurves_24)); }
	inline AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE * get_m_AnimationCurves_24() const { return ___m_AnimationCurves_24; }
	inline AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE ** get_address_of_m_AnimationCurves_24() { return &___m_AnimationCurves_24; }
	inline void set_m_AnimationCurves_24(AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE * value)
	{
		___m_AnimationCurves_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_AnimationCurves_24), (void*)value);
	}

	inline static int32_t get_offset_of_m_Recordable_25() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_Recordable_25)); }
	inline bool get_m_Recordable_25() const { return ___m_Recordable_25; }
	inline bool* get_address_of_m_Recordable_25() { return &___m_Recordable_25; }
	inline void set_m_Recordable_25(bool value)
	{
		___m_Recordable_25 = value;
	}

	inline static int32_t get_offset_of_m_PostExtrapolationMode_26() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_PostExtrapolationMode_26)); }
	inline int32_t get_m_PostExtrapolationMode_26() const { return ___m_PostExtrapolationMode_26; }
	inline int32_t* get_address_of_m_PostExtrapolationMode_26() { return &___m_PostExtrapolationMode_26; }
	inline void set_m_PostExtrapolationMode_26(int32_t value)
	{
		___m_PostExtrapolationMode_26 = value;
	}

	inline static int32_t get_offset_of_m_PreExtrapolationMode_27() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_PreExtrapolationMode_27)); }
	inline int32_t get_m_PreExtrapolationMode_27() const { return ___m_PreExtrapolationMode_27; }
	inline int32_t* get_address_of_m_PreExtrapolationMode_27() { return &___m_PreExtrapolationMode_27; }
	inline void set_m_PreExtrapolationMode_27(int32_t value)
	{
		___m_PreExtrapolationMode_27 = value;
	}

	inline static int32_t get_offset_of_m_PostExtrapolationTime_28() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_PostExtrapolationTime_28)); }
	inline double get_m_PostExtrapolationTime_28() const { return ___m_PostExtrapolationTime_28; }
	inline double* get_address_of_m_PostExtrapolationTime_28() { return &___m_PostExtrapolationTime_28; }
	inline void set_m_PostExtrapolationTime_28(double value)
	{
		___m_PostExtrapolationTime_28 = value;
	}

	inline static int32_t get_offset_of_m_PreExtrapolationTime_29() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_PreExtrapolationTime_29)); }
	inline double get_m_PreExtrapolationTime_29() const { return ___m_PreExtrapolationTime_29; }
	inline double* get_address_of_m_PreExtrapolationTime_29() { return &___m_PreExtrapolationTime_29; }
	inline void set_m_PreExtrapolationTime_29(double value)
	{
		___m_PreExtrapolationTime_29 = value;
	}

	inline static int32_t get_offset_of_m_DisplayName_30() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB, ___m_DisplayName_30)); }
	inline String_t* get_m_DisplayName_30() const { return ___m_DisplayName_30; }
	inline String_t** get_address_of_m_DisplayName_30() { return &___m_DisplayName_30; }
	inline void set_m_DisplayName_30(String_t* value)
	{
		___m_DisplayName_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_DisplayName_30), (void*)value);
	}
};

struct TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB_StaticFields
{
public:
	// UnityEngine.Timeline.ClipCaps UnityEngine.Timeline.TimelineClip::kDefaultClipCaps
	int32_t ___kDefaultClipCaps_2;
	// System.Single UnityEngine.Timeline.TimelineClip::kDefaultClipDurationInSeconds
	float ___kDefaultClipDurationInSeconds_3;
	// System.Double UnityEngine.Timeline.TimelineClip::kTimeScaleMin
	double ___kTimeScaleMin_4;
	// System.Double UnityEngine.Timeline.TimelineClip::kTimeScaleMax
	double ___kTimeScaleMax_5;
	// System.String UnityEngine.Timeline.TimelineClip::kDefaultCurvesName
	String_t* ___kDefaultCurvesName_6;
	// System.Double UnityEngine.Timeline.TimelineClip::kMinDuration
	double ___kMinDuration_7;
	// System.Double UnityEngine.Timeline.TimelineClip::kMaxTimeValue
	double ___kMaxTimeValue_8;

public:
	inline static int32_t get_offset_of_kDefaultClipCaps_2() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB_StaticFields, ___kDefaultClipCaps_2)); }
	inline int32_t get_kDefaultClipCaps_2() const { return ___kDefaultClipCaps_2; }
	inline int32_t* get_address_of_kDefaultClipCaps_2() { return &___kDefaultClipCaps_2; }
	inline void set_kDefaultClipCaps_2(int32_t value)
	{
		___kDefaultClipCaps_2 = value;
	}

	inline static int32_t get_offset_of_kDefaultClipDurationInSeconds_3() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB_StaticFields, ___kDefaultClipDurationInSeconds_3)); }
	inline float get_kDefaultClipDurationInSeconds_3() const { return ___kDefaultClipDurationInSeconds_3; }
	inline float* get_address_of_kDefaultClipDurationInSeconds_3() { return &___kDefaultClipDurationInSeconds_3; }
	inline void set_kDefaultClipDurationInSeconds_3(float value)
	{
		___kDefaultClipDurationInSeconds_3 = value;
	}

	inline static int32_t get_offset_of_kTimeScaleMin_4() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB_StaticFields, ___kTimeScaleMin_4)); }
	inline double get_kTimeScaleMin_4() const { return ___kTimeScaleMin_4; }
	inline double* get_address_of_kTimeScaleMin_4() { return &___kTimeScaleMin_4; }
	inline void set_kTimeScaleMin_4(double value)
	{
		___kTimeScaleMin_4 = value;
	}

	inline static int32_t get_offset_of_kTimeScaleMax_5() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB_StaticFields, ___kTimeScaleMax_5)); }
	inline double get_kTimeScaleMax_5() const { return ___kTimeScaleMax_5; }
	inline double* get_address_of_kTimeScaleMax_5() { return &___kTimeScaleMax_5; }
	inline void set_kTimeScaleMax_5(double value)
	{
		___kTimeScaleMax_5 = value;
	}

	inline static int32_t get_offset_of_kDefaultCurvesName_6() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB_StaticFields, ___kDefaultCurvesName_6)); }
	inline String_t* get_kDefaultCurvesName_6() const { return ___kDefaultCurvesName_6; }
	inline String_t** get_address_of_kDefaultCurvesName_6() { return &___kDefaultCurvesName_6; }
	inline void set_kDefaultCurvesName_6(String_t* value)
	{
		___kDefaultCurvesName_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___kDefaultCurvesName_6), (void*)value);
	}

	inline static int32_t get_offset_of_kMinDuration_7() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB_StaticFields, ___kMinDuration_7)); }
	inline double get_kMinDuration_7() const { return ___kMinDuration_7; }
	inline double* get_address_of_kMinDuration_7() { return &___kMinDuration_7; }
	inline void set_kMinDuration_7(double value)
	{
		___kMinDuration_7 = value;
	}

	inline static int32_t get_offset_of_kMaxTimeValue_8() { return static_cast<int32_t>(offsetof(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB_StaticFields, ___kMaxTimeValue_8)); }
	inline double get_kMaxTimeValue_8() const { return ___kMaxTimeValue_8; }
	inline double* get_address_of_kMaxTimeValue_8() { return &___kMaxTimeValue_8; }
	inline void set_kMaxTimeValue_8(double value)
	{
		___kMaxTimeValue_8 = value;
	}
};


// AkCallbackManager_EventCallback
struct  EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561  : public MulticastDelegate_t
{
public:

public:
};


// AkDurationCallbackInfo
struct  AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25  : public AkEventCallbackInfo_t7CA1F9AE48D554FC01CC821754D6C211AB666F37
{
public:
	// System.IntPtr AkDurationCallbackInfo::swigCPtr
	intptr_t ___swigCPtr_3;

public:
	inline static int32_t get_offset_of_swigCPtr_3() { return static_cast<int32_t>(offsetof(AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25, ___swigCPtr_3)); }
	inline intptr_t get_swigCPtr_3() const { return ___swigCPtr_3; }
	inline intptr_t* get_address_of_swigCPtr_3() { return &___swigCPtr_3; }
	inline void set_swigCPtr_3(intptr_t value)
	{
		___swigCPtr_3 = value;
	}
};


// UnityEngine.Playables.FrameData
struct  FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E 
{
public:
	// System.UInt64 UnityEngine.Playables.FrameData::m_FrameID
	uint64_t ___m_FrameID_0;
	// System.Double UnityEngine.Playables.FrameData::m_DeltaTime
	double ___m_DeltaTime_1;
	// System.Single UnityEngine.Playables.FrameData::m_Weight
	float ___m_Weight_2;
	// System.Single UnityEngine.Playables.FrameData::m_EffectiveWeight
	float ___m_EffectiveWeight_3;
	// System.Double UnityEngine.Playables.FrameData::m_EffectiveParentDelay
	double ___m_EffectiveParentDelay_4;
	// System.Single UnityEngine.Playables.FrameData::m_EffectiveParentSpeed
	float ___m_EffectiveParentSpeed_5;
	// System.Single UnityEngine.Playables.FrameData::m_EffectiveSpeed
	float ___m_EffectiveSpeed_6;
	// UnityEngine.Playables.FrameData_Flags UnityEngine.Playables.FrameData::m_Flags
	int32_t ___m_Flags_7;
	// UnityEngine.Playables.PlayableOutput UnityEngine.Playables.FrameData::m_Output
	PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345  ___m_Output_8;

public:
	inline static int32_t get_offset_of_m_FrameID_0() { return static_cast<int32_t>(offsetof(FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E, ___m_FrameID_0)); }
	inline uint64_t get_m_FrameID_0() const { return ___m_FrameID_0; }
	inline uint64_t* get_address_of_m_FrameID_0() { return &___m_FrameID_0; }
	inline void set_m_FrameID_0(uint64_t value)
	{
		___m_FrameID_0 = value;
	}

	inline static int32_t get_offset_of_m_DeltaTime_1() { return static_cast<int32_t>(offsetof(FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E, ___m_DeltaTime_1)); }
	inline double get_m_DeltaTime_1() const { return ___m_DeltaTime_1; }
	inline double* get_address_of_m_DeltaTime_1() { return &___m_DeltaTime_1; }
	inline void set_m_DeltaTime_1(double value)
	{
		___m_DeltaTime_1 = value;
	}

	inline static int32_t get_offset_of_m_Weight_2() { return static_cast<int32_t>(offsetof(FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E, ___m_Weight_2)); }
	inline float get_m_Weight_2() const { return ___m_Weight_2; }
	inline float* get_address_of_m_Weight_2() { return &___m_Weight_2; }
	inline void set_m_Weight_2(float value)
	{
		___m_Weight_2 = value;
	}

	inline static int32_t get_offset_of_m_EffectiveWeight_3() { return static_cast<int32_t>(offsetof(FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E, ___m_EffectiveWeight_3)); }
	inline float get_m_EffectiveWeight_3() const { return ___m_EffectiveWeight_3; }
	inline float* get_address_of_m_EffectiveWeight_3() { return &___m_EffectiveWeight_3; }
	inline void set_m_EffectiveWeight_3(float value)
	{
		___m_EffectiveWeight_3 = value;
	}

	inline static int32_t get_offset_of_m_EffectiveParentDelay_4() { return static_cast<int32_t>(offsetof(FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E, ___m_EffectiveParentDelay_4)); }
	inline double get_m_EffectiveParentDelay_4() const { return ___m_EffectiveParentDelay_4; }
	inline double* get_address_of_m_EffectiveParentDelay_4() { return &___m_EffectiveParentDelay_4; }
	inline void set_m_EffectiveParentDelay_4(double value)
	{
		___m_EffectiveParentDelay_4 = value;
	}

	inline static int32_t get_offset_of_m_EffectiveParentSpeed_5() { return static_cast<int32_t>(offsetof(FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E, ___m_EffectiveParentSpeed_5)); }
	inline float get_m_EffectiveParentSpeed_5() const { return ___m_EffectiveParentSpeed_5; }
	inline float* get_address_of_m_EffectiveParentSpeed_5() { return &___m_EffectiveParentSpeed_5; }
	inline void set_m_EffectiveParentSpeed_5(float value)
	{
		___m_EffectiveParentSpeed_5 = value;
	}

	inline static int32_t get_offset_of_m_EffectiveSpeed_6() { return static_cast<int32_t>(offsetof(FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E, ___m_EffectiveSpeed_6)); }
	inline float get_m_EffectiveSpeed_6() const { return ___m_EffectiveSpeed_6; }
	inline float* get_address_of_m_EffectiveSpeed_6() { return &___m_EffectiveSpeed_6; }
	inline void set_m_EffectiveSpeed_6(float value)
	{
		___m_EffectiveSpeed_6 = value;
	}

	inline static int32_t get_offset_of_m_Flags_7() { return static_cast<int32_t>(offsetof(FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E, ___m_Flags_7)); }
	inline int32_t get_m_Flags_7() const { return ___m_Flags_7; }
	inline int32_t* get_address_of_m_Flags_7() { return &___m_Flags_7; }
	inline void set_m_Flags_7(int32_t value)
	{
		___m_Flags_7 = value;
	}

	inline static int32_t get_offset_of_m_Output_8() { return static_cast<int32_t>(offsetof(FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E, ___m_Output_8)); }
	inline PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345  get_m_Output_8() const { return ___m_Output_8; }
	inline PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345 * get_address_of_m_Output_8() { return &___m_Output_8; }
	inline void set_m_Output_8(PlayableOutput_t5E024C3D28C983782CD4FDB2FA5AD23998D21345  value)
	{
		___m_Output_8 = value;
	}
};


// UnityEngine.Playables.PlayableAsset
struct  PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:

public:
};


// AkEventPlayable
struct  AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA  : public PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD
{
public:
	// AK.Wwise.Event AkEventPlayable::akEvent
	Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * ___akEvent_4;
	// AkCurveInterpolation AkEventPlayable::blendInCurve
	int32_t ___blendInCurve_5;
	// AkCurveInterpolation AkEventPlayable::blendOutCurve
	int32_t ___blendOutCurve_6;
	// UnityEngine.ExposedReference`1<UnityEngine.GameObject> AkEventPlayable::emitterObjectRef
	ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944  ___emitterObjectRef_7;
	// System.Single AkEventPlayable::eventDurationMax
	float ___eventDurationMax_8;
	// System.Single AkEventPlayable::eventDurationMin
	float ___eventDurationMin_9;
	// UnityEngine.Timeline.TimelineClip AkEventPlayable::owningClip
	TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___owningClip_10;
	// System.Boolean AkEventPlayable::retriggerEvent
	bool ___retriggerEvent_11;
	// System.Boolean AkEventPlayable::UseWwiseEventDuration
	bool ___UseWwiseEventDuration_12;
	// System.Boolean AkEventPlayable::StopEventAtClipEnd
	bool ___StopEventAtClipEnd_13;

public:
	inline static int32_t get_offset_of_akEvent_4() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___akEvent_4)); }
	inline Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * get_akEvent_4() const { return ___akEvent_4; }
	inline Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F ** get_address_of_akEvent_4() { return &___akEvent_4; }
	inline void set_akEvent_4(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * value)
	{
		___akEvent_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___akEvent_4), (void*)value);
	}

	inline static int32_t get_offset_of_blendInCurve_5() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___blendInCurve_5)); }
	inline int32_t get_blendInCurve_5() const { return ___blendInCurve_5; }
	inline int32_t* get_address_of_blendInCurve_5() { return &___blendInCurve_5; }
	inline void set_blendInCurve_5(int32_t value)
	{
		___blendInCurve_5 = value;
	}

	inline static int32_t get_offset_of_blendOutCurve_6() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___blendOutCurve_6)); }
	inline int32_t get_blendOutCurve_6() const { return ___blendOutCurve_6; }
	inline int32_t* get_address_of_blendOutCurve_6() { return &___blendOutCurve_6; }
	inline void set_blendOutCurve_6(int32_t value)
	{
		___blendOutCurve_6 = value;
	}

	inline static int32_t get_offset_of_emitterObjectRef_7() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___emitterObjectRef_7)); }
	inline ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944  get_emitterObjectRef_7() const { return ___emitterObjectRef_7; }
	inline ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944 * get_address_of_emitterObjectRef_7() { return &___emitterObjectRef_7; }
	inline void set_emitterObjectRef_7(ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944  value)
	{
		___emitterObjectRef_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___emitterObjectRef_7))->___defaultValue_1), (void*)NULL);
	}

	inline static int32_t get_offset_of_eventDurationMax_8() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___eventDurationMax_8)); }
	inline float get_eventDurationMax_8() const { return ___eventDurationMax_8; }
	inline float* get_address_of_eventDurationMax_8() { return &___eventDurationMax_8; }
	inline void set_eventDurationMax_8(float value)
	{
		___eventDurationMax_8 = value;
	}

	inline static int32_t get_offset_of_eventDurationMin_9() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___eventDurationMin_9)); }
	inline float get_eventDurationMin_9() const { return ___eventDurationMin_9; }
	inline float* get_address_of_eventDurationMin_9() { return &___eventDurationMin_9; }
	inline void set_eventDurationMin_9(float value)
	{
		___eventDurationMin_9 = value;
	}

	inline static int32_t get_offset_of_owningClip_10() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___owningClip_10)); }
	inline TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * get_owningClip_10() const { return ___owningClip_10; }
	inline TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB ** get_address_of_owningClip_10() { return &___owningClip_10; }
	inline void set_owningClip_10(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * value)
	{
		___owningClip_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___owningClip_10), (void*)value);
	}

	inline static int32_t get_offset_of_retriggerEvent_11() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___retriggerEvent_11)); }
	inline bool get_retriggerEvent_11() const { return ___retriggerEvent_11; }
	inline bool* get_address_of_retriggerEvent_11() { return &___retriggerEvent_11; }
	inline void set_retriggerEvent_11(bool value)
	{
		___retriggerEvent_11 = value;
	}

	inline static int32_t get_offset_of_UseWwiseEventDuration_12() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___UseWwiseEventDuration_12)); }
	inline bool get_UseWwiseEventDuration_12() const { return ___UseWwiseEventDuration_12; }
	inline bool* get_address_of_UseWwiseEventDuration_12() { return &___UseWwiseEventDuration_12; }
	inline void set_UseWwiseEventDuration_12(bool value)
	{
		___UseWwiseEventDuration_12 = value;
	}

	inline static int32_t get_offset_of_StopEventAtClipEnd_13() { return static_cast<int32_t>(offsetof(AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA, ___StopEventAtClipEnd_13)); }
	inline bool get_StopEventAtClipEnd_13() const { return ___StopEventAtClipEnd_13; }
	inline bool* get_address_of_StopEventAtClipEnd_13() { return &___StopEventAtClipEnd_13; }
	inline void set_StopEventAtClipEnd_13(bool value)
	{
		___StopEventAtClipEnd_13 = value;
	}
};


// AkRTPCPlayable
struct  AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C  : public PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD
{
public:
	// System.Boolean AkRTPCPlayable::overrideTrackObject
	bool ___overrideTrackObject_4;
	// UnityEngine.ExposedReference`1<UnityEngine.GameObject> AkRTPCPlayable::RTPCObject
	ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944  ___RTPCObject_5;
	// System.Boolean AkRTPCPlayable::setRTPCGlobally
	bool ___setRTPCGlobally_6;
	// AkRTPCPlayableBehaviour AkRTPCPlayable::template
	AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * ___template_7;
	// AK.Wwise.RTPC AkRTPCPlayable::<Parameter>k__BackingField
	RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___U3CParameterU3Ek__BackingField_8;
	// UnityEngine.Timeline.TimelineClip AkRTPCPlayable::<OwningClip>k__BackingField
	TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___U3COwningClipU3Ek__BackingField_9;

public:
	inline static int32_t get_offset_of_overrideTrackObject_4() { return static_cast<int32_t>(offsetof(AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C, ___overrideTrackObject_4)); }
	inline bool get_overrideTrackObject_4() const { return ___overrideTrackObject_4; }
	inline bool* get_address_of_overrideTrackObject_4() { return &___overrideTrackObject_4; }
	inline void set_overrideTrackObject_4(bool value)
	{
		___overrideTrackObject_4 = value;
	}

	inline static int32_t get_offset_of_RTPCObject_5() { return static_cast<int32_t>(offsetof(AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C, ___RTPCObject_5)); }
	inline ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944  get_RTPCObject_5() const { return ___RTPCObject_5; }
	inline ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944 * get_address_of_RTPCObject_5() { return &___RTPCObject_5; }
	inline void set_RTPCObject_5(ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944  value)
	{
		___RTPCObject_5 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___RTPCObject_5))->___defaultValue_1), (void*)NULL);
	}

	inline static int32_t get_offset_of_setRTPCGlobally_6() { return static_cast<int32_t>(offsetof(AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C, ___setRTPCGlobally_6)); }
	inline bool get_setRTPCGlobally_6() const { return ___setRTPCGlobally_6; }
	inline bool* get_address_of_setRTPCGlobally_6() { return &___setRTPCGlobally_6; }
	inline void set_setRTPCGlobally_6(bool value)
	{
		___setRTPCGlobally_6 = value;
	}

	inline static int32_t get_offset_of_template_7() { return static_cast<int32_t>(offsetof(AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C, ___template_7)); }
	inline AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * get_template_7() const { return ___template_7; }
	inline AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 ** get_address_of_template_7() { return &___template_7; }
	inline void set_template_7(AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * value)
	{
		___template_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___template_7), (void*)value);
	}

	inline static int32_t get_offset_of_U3CParameterU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C, ___U3CParameterU3Ek__BackingField_8)); }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * get_U3CParameterU3Ek__BackingField_8() const { return ___U3CParameterU3Ek__BackingField_8; }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C ** get_address_of_U3CParameterU3Ek__BackingField_8() { return &___U3CParameterU3Ek__BackingField_8; }
	inline void set_U3CParameterU3Ek__BackingField_8(RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * value)
	{
		___U3CParameterU3Ek__BackingField_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CParameterU3Ek__BackingField_8), (void*)value);
	}

	inline static int32_t get_offset_of_U3COwningClipU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C, ___U3COwningClipU3Ek__BackingField_9)); }
	inline TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * get_U3COwningClipU3Ek__BackingField_9() const { return ___U3COwningClipU3Ek__BackingField_9; }
	inline TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB ** get_address_of_U3COwningClipU3Ek__BackingField_9() { return &___U3COwningClipU3Ek__BackingField_9; }
	inline void set_U3COwningClipU3Ek__BackingField_9(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * value)
	{
		___U3COwningClipU3Ek__BackingField_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3COwningClipU3Ek__BackingField_9), (void*)value);
	}
};


// AkTimelineEventPlayable
struct  AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A  : public PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD
{
public:
	// AK.Wwise.Event AkTimelineEventPlayable::akEvent
	Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * ___akEvent_4;
	// AkCurveInterpolation AkTimelineEventPlayable::blendInCurve
	int32_t ___blendInCurve_5;
	// AkCurveInterpolation AkTimelineEventPlayable::blendOutCurve
	int32_t ___blendOutCurve_6;
	// System.Single AkTimelineEventPlayable::eventDurationMax
	float ___eventDurationMax_7;
	// System.Single AkTimelineEventPlayable::eventDurationMin
	float ___eventDurationMin_8;
	// UnityEngine.Timeline.TimelineClip AkTimelineEventPlayable::owningClip
	TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___owningClip_9;
	// System.Boolean AkTimelineEventPlayable::retriggerEvent
	bool ___retriggerEvent_10;
	// System.Boolean AkTimelineEventPlayable::UseWwiseEventDuration
	bool ___UseWwiseEventDuration_11;
	// System.Boolean AkTimelineEventPlayable::StopEventAtClipEnd
	bool ___StopEventAtClipEnd_12;

public:
	inline static int32_t get_offset_of_akEvent_4() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A, ___akEvent_4)); }
	inline Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * get_akEvent_4() const { return ___akEvent_4; }
	inline Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F ** get_address_of_akEvent_4() { return &___akEvent_4; }
	inline void set_akEvent_4(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * value)
	{
		___akEvent_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___akEvent_4), (void*)value);
	}

	inline static int32_t get_offset_of_blendInCurve_5() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A, ___blendInCurve_5)); }
	inline int32_t get_blendInCurve_5() const { return ___blendInCurve_5; }
	inline int32_t* get_address_of_blendInCurve_5() { return &___blendInCurve_5; }
	inline void set_blendInCurve_5(int32_t value)
	{
		___blendInCurve_5 = value;
	}

	inline static int32_t get_offset_of_blendOutCurve_6() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A, ___blendOutCurve_6)); }
	inline int32_t get_blendOutCurve_6() const { return ___blendOutCurve_6; }
	inline int32_t* get_address_of_blendOutCurve_6() { return &___blendOutCurve_6; }
	inline void set_blendOutCurve_6(int32_t value)
	{
		___blendOutCurve_6 = value;
	}

	inline static int32_t get_offset_of_eventDurationMax_7() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A, ___eventDurationMax_7)); }
	inline float get_eventDurationMax_7() const { return ___eventDurationMax_7; }
	inline float* get_address_of_eventDurationMax_7() { return &___eventDurationMax_7; }
	inline void set_eventDurationMax_7(float value)
	{
		___eventDurationMax_7 = value;
	}

	inline static int32_t get_offset_of_eventDurationMin_8() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A, ___eventDurationMin_8)); }
	inline float get_eventDurationMin_8() const { return ___eventDurationMin_8; }
	inline float* get_address_of_eventDurationMin_8() { return &___eventDurationMin_8; }
	inline void set_eventDurationMin_8(float value)
	{
		___eventDurationMin_8 = value;
	}

	inline static int32_t get_offset_of_owningClip_9() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A, ___owningClip_9)); }
	inline TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * get_owningClip_9() const { return ___owningClip_9; }
	inline TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB ** get_address_of_owningClip_9() { return &___owningClip_9; }
	inline void set_owningClip_9(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * value)
	{
		___owningClip_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___owningClip_9), (void*)value);
	}

	inline static int32_t get_offset_of_retriggerEvent_10() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A, ___retriggerEvent_10)); }
	inline bool get_retriggerEvent_10() const { return ___retriggerEvent_10; }
	inline bool* get_address_of_retriggerEvent_10() { return &___retriggerEvent_10; }
	inline void set_retriggerEvent_10(bool value)
	{
		___retriggerEvent_10 = value;
	}

	inline static int32_t get_offset_of_UseWwiseEventDuration_11() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A, ___UseWwiseEventDuration_11)); }
	inline bool get_UseWwiseEventDuration_11() const { return ___UseWwiseEventDuration_11; }
	inline bool* get_address_of_UseWwiseEventDuration_11() { return &___UseWwiseEventDuration_11; }
	inline void set_UseWwiseEventDuration_11(bool value)
	{
		___UseWwiseEventDuration_11 = value;
	}

	inline static int32_t get_offset_of_StopEventAtClipEnd_12() { return static_cast<int32_t>(offsetof(AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A, ___StopEventAtClipEnd_12)); }
	inline bool get_StopEventAtClipEnd_12() const { return ___StopEventAtClipEnd_12; }
	inline bool* get_address_of_StopEventAtClipEnd_12() { return &___StopEventAtClipEnd_12; }
	inline void set_StopEventAtClipEnd_12(bool value)
	{
		___StopEventAtClipEnd_12 = value;
	}
};


// AkTimelineRtpcPlayable
struct  AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA  : public PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD
{
public:
	// AK.Wwise.RTPC AkTimelineRtpcPlayable::RTPC
	RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___RTPC_4;
	// System.Boolean AkTimelineRtpcPlayable::setGlobally
	bool ___setGlobally_5;
	// AkTimelineRtpcPlayableBehaviour AkTimelineRtpcPlayable::template
	AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * ___template_6;
	// UnityEngine.Timeline.TimelineClip AkTimelineRtpcPlayable::<owningClip>k__BackingField
	TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___U3CowningClipU3Ek__BackingField_7;

public:
	inline static int32_t get_offset_of_RTPC_4() { return static_cast<int32_t>(offsetof(AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA, ___RTPC_4)); }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * get_RTPC_4() const { return ___RTPC_4; }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C ** get_address_of_RTPC_4() { return &___RTPC_4; }
	inline void set_RTPC_4(RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * value)
	{
		___RTPC_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___RTPC_4), (void*)value);
	}

	inline static int32_t get_offset_of_setGlobally_5() { return static_cast<int32_t>(offsetof(AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA, ___setGlobally_5)); }
	inline bool get_setGlobally_5() const { return ___setGlobally_5; }
	inline bool* get_address_of_setGlobally_5() { return &___setGlobally_5; }
	inline void set_setGlobally_5(bool value)
	{
		___setGlobally_5 = value;
	}

	inline static int32_t get_offset_of_template_6() { return static_cast<int32_t>(offsetof(AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA, ___template_6)); }
	inline AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * get_template_6() const { return ___template_6; }
	inline AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E ** get_address_of_template_6() { return &___template_6; }
	inline void set_template_6(AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * value)
	{
		___template_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___template_6), (void*)value);
	}

	inline static int32_t get_offset_of_U3CowningClipU3Ek__BackingField_7() { return static_cast<int32_t>(offsetof(AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA, ___U3CowningClipU3Ek__BackingField_7)); }
	inline TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * get_U3CowningClipU3Ek__BackingField_7() const { return ___U3CowningClipU3Ek__BackingField_7; }
	inline TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB ** get_address_of_U3CowningClipU3Ek__BackingField_7() { return &___U3CowningClipU3Ek__BackingField_7; }
	inline void set_U3CowningClipU3Ek__BackingField_7(TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * value)
	{
		___U3CowningClipU3Ek__BackingField_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CowningClipU3Ek__BackingField_7), (void*)value);
	}
};


// UnityEngine.Timeline.TrackAsset
struct  TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D  : public PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD
{
public:
	// System.Int32 UnityEngine.Timeline.TrackAsset::m_Version
	int32_t ___m_Version_5;
	// UnityEngine.AnimationClip UnityEngine.Timeline.TrackAsset::m_AnimClip
	AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE * ___m_AnimClip_6;
	// System.Boolean UnityEngine.Timeline.TrackAsset::m_Locked
	bool ___m_Locked_11;
	// System.Boolean UnityEngine.Timeline.TrackAsset::m_Muted
	bool ___m_Muted_12;
	// System.String UnityEngine.Timeline.TrackAsset::m_CustomPlayableFullTypename
	String_t* ___m_CustomPlayableFullTypename_13;
	// UnityEngine.AnimationClip UnityEngine.Timeline.TrackAsset::m_Curves
	AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE * ___m_Curves_14;
	// UnityEngine.Playables.PlayableAsset UnityEngine.Timeline.TrackAsset::m_Parent
	PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD * ___m_Parent_15;
	// System.Collections.Generic.List`1<UnityEngine.ScriptableObject> UnityEngine.Timeline.TrackAsset::m_Children
	List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF * ___m_Children_16;
	// System.Int32 UnityEngine.Timeline.TrackAsset::m_ItemsHash
	int32_t ___m_ItemsHash_17;
	// UnityEngine.Timeline.TimelineClip[] UnityEngine.Timeline.TrackAsset::m_ClipsCache
	TimelineClipU5BU5D_tF91A3D5ECF00F61AAD13F3FCFE125B4F7FA5982E* ___m_ClipsCache_18;
	// UnityEngine.Timeline.DiscreteTime UnityEngine.Timeline.TrackAsset::m_Start
	DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047  ___m_Start_19;
	// UnityEngine.Timeline.DiscreteTime UnityEngine.Timeline.TrackAsset::m_End
	DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047  ___m_End_20;
	// System.Boolean UnityEngine.Timeline.TrackAsset::m_CacheSorted
	bool ___m_CacheSorted_21;
	// System.Nullable`1<System.Boolean> UnityEngine.Timeline.TrackAsset::m_SupportsNotifications
	Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  ___m_SupportsNotifications_22;
	// System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TrackAsset> UnityEngine.Timeline.TrackAsset::m_ChildTrackCache
	RuntimeObject* ___m_ChildTrackCache_24;
	// System.Collections.Generic.List`1<UnityEngine.Timeline.TimelineClip> UnityEngine.Timeline.TrackAsset::m_Clips
	List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA * ___m_Clips_26;
	// UnityEngine.Timeline.MarkerList UnityEngine.Timeline.TrackAsset::m_Markers
	MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC  ___m_Markers_27;

public:
	inline static int32_t get_offset_of_m_Version_5() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_Version_5)); }
	inline int32_t get_m_Version_5() const { return ___m_Version_5; }
	inline int32_t* get_address_of_m_Version_5() { return &___m_Version_5; }
	inline void set_m_Version_5(int32_t value)
	{
		___m_Version_5 = value;
	}

	inline static int32_t get_offset_of_m_AnimClip_6() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_AnimClip_6)); }
	inline AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE * get_m_AnimClip_6() const { return ___m_AnimClip_6; }
	inline AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE ** get_address_of_m_AnimClip_6() { return &___m_AnimClip_6; }
	inline void set_m_AnimClip_6(AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE * value)
	{
		___m_AnimClip_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_AnimClip_6), (void*)value);
	}

	inline static int32_t get_offset_of_m_Locked_11() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_Locked_11)); }
	inline bool get_m_Locked_11() const { return ___m_Locked_11; }
	inline bool* get_address_of_m_Locked_11() { return &___m_Locked_11; }
	inline void set_m_Locked_11(bool value)
	{
		___m_Locked_11 = value;
	}

	inline static int32_t get_offset_of_m_Muted_12() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_Muted_12)); }
	inline bool get_m_Muted_12() const { return ___m_Muted_12; }
	inline bool* get_address_of_m_Muted_12() { return &___m_Muted_12; }
	inline void set_m_Muted_12(bool value)
	{
		___m_Muted_12 = value;
	}

	inline static int32_t get_offset_of_m_CustomPlayableFullTypename_13() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_CustomPlayableFullTypename_13)); }
	inline String_t* get_m_CustomPlayableFullTypename_13() const { return ___m_CustomPlayableFullTypename_13; }
	inline String_t** get_address_of_m_CustomPlayableFullTypename_13() { return &___m_CustomPlayableFullTypename_13; }
	inline void set_m_CustomPlayableFullTypename_13(String_t* value)
	{
		___m_CustomPlayableFullTypename_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_CustomPlayableFullTypename_13), (void*)value);
	}

	inline static int32_t get_offset_of_m_Curves_14() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_Curves_14)); }
	inline AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE * get_m_Curves_14() const { return ___m_Curves_14; }
	inline AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE ** get_address_of_m_Curves_14() { return &___m_Curves_14; }
	inline void set_m_Curves_14(AnimationClip_t336CFC94F6275526DC0B9BEEF833D4D89D6DEDDE * value)
	{
		___m_Curves_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Curves_14), (void*)value);
	}

	inline static int32_t get_offset_of_m_Parent_15() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_Parent_15)); }
	inline PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD * get_m_Parent_15() const { return ___m_Parent_15; }
	inline PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD ** get_address_of_m_Parent_15() { return &___m_Parent_15; }
	inline void set_m_Parent_15(PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD * value)
	{
		___m_Parent_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Parent_15), (void*)value);
	}

	inline static int32_t get_offset_of_m_Children_16() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_Children_16)); }
	inline List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF * get_m_Children_16() const { return ___m_Children_16; }
	inline List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF ** get_address_of_m_Children_16() { return &___m_Children_16; }
	inline void set_m_Children_16(List_1_t41ED65DE2CE5065D598F08F2FA793FD1FF75A8AF * value)
	{
		___m_Children_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Children_16), (void*)value);
	}

	inline static int32_t get_offset_of_m_ItemsHash_17() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_ItemsHash_17)); }
	inline int32_t get_m_ItemsHash_17() const { return ___m_ItemsHash_17; }
	inline int32_t* get_address_of_m_ItemsHash_17() { return &___m_ItemsHash_17; }
	inline void set_m_ItemsHash_17(int32_t value)
	{
		___m_ItemsHash_17 = value;
	}

	inline static int32_t get_offset_of_m_ClipsCache_18() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_ClipsCache_18)); }
	inline TimelineClipU5BU5D_tF91A3D5ECF00F61AAD13F3FCFE125B4F7FA5982E* get_m_ClipsCache_18() const { return ___m_ClipsCache_18; }
	inline TimelineClipU5BU5D_tF91A3D5ECF00F61AAD13F3FCFE125B4F7FA5982E** get_address_of_m_ClipsCache_18() { return &___m_ClipsCache_18; }
	inline void set_m_ClipsCache_18(TimelineClipU5BU5D_tF91A3D5ECF00F61AAD13F3FCFE125B4F7FA5982E* value)
	{
		___m_ClipsCache_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ClipsCache_18), (void*)value);
	}

	inline static int32_t get_offset_of_m_Start_19() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_Start_19)); }
	inline DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047  get_m_Start_19() const { return ___m_Start_19; }
	inline DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047 * get_address_of_m_Start_19() { return &___m_Start_19; }
	inline void set_m_Start_19(DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047  value)
	{
		___m_Start_19 = value;
	}

	inline static int32_t get_offset_of_m_End_20() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_End_20)); }
	inline DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047  get_m_End_20() const { return ___m_End_20; }
	inline DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047 * get_address_of_m_End_20() { return &___m_End_20; }
	inline void set_m_End_20(DiscreteTime_t5CEF520F9662493C6516748140D71CE69D64B047  value)
	{
		___m_End_20 = value;
	}

	inline static int32_t get_offset_of_m_CacheSorted_21() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_CacheSorted_21)); }
	inline bool get_m_CacheSorted_21() const { return ___m_CacheSorted_21; }
	inline bool* get_address_of_m_CacheSorted_21() { return &___m_CacheSorted_21; }
	inline void set_m_CacheSorted_21(bool value)
	{
		___m_CacheSorted_21 = value;
	}

	inline static int32_t get_offset_of_m_SupportsNotifications_22() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_SupportsNotifications_22)); }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  get_m_SupportsNotifications_22() const { return ___m_SupportsNotifications_22; }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793 * get_address_of_m_SupportsNotifications_22() { return &___m_SupportsNotifications_22; }
	inline void set_m_SupportsNotifications_22(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  value)
	{
		___m_SupportsNotifications_22 = value;
	}

	inline static int32_t get_offset_of_m_ChildTrackCache_24() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_ChildTrackCache_24)); }
	inline RuntimeObject* get_m_ChildTrackCache_24() const { return ___m_ChildTrackCache_24; }
	inline RuntimeObject** get_address_of_m_ChildTrackCache_24() { return &___m_ChildTrackCache_24; }
	inline void set_m_ChildTrackCache_24(RuntimeObject* value)
	{
		___m_ChildTrackCache_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_ChildTrackCache_24), (void*)value);
	}

	inline static int32_t get_offset_of_m_Clips_26() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_Clips_26)); }
	inline List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA * get_m_Clips_26() const { return ___m_Clips_26; }
	inline List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA ** get_address_of_m_Clips_26() { return &___m_Clips_26; }
	inline void set_m_Clips_26(List_1_t6E4584A39B7BEEB659D9A568195C253D69ABAAEA * value)
	{
		___m_Clips_26 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Clips_26), (void*)value);
	}

	inline static int32_t get_offset_of_m_Markers_27() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D, ___m_Markers_27)); }
	inline MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC  get_m_Markers_27() const { return ___m_Markers_27; }
	inline MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC * get_address_of_m_Markers_27() { return &___m_Markers_27; }
	inline void set_m_Markers_27(MarkerList_t5DDEACDD8C5942DE4C9778F1CC77E5AB685832DC  value)
	{
		___m_Markers_27 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Markers_27))->___m_Objects_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___m_Markers_27))->___m_Cache_1), (void*)NULL);
		#endif
	}
};

struct TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_StaticFields
{
public:
	// UnityEngine.Timeline.TrackAsset_TransientBuildData UnityEngine.Timeline.TrackAsset::s_BuildData
	TransientBuildData_t2CDF71634041677EC226311F30665780C2026744  ___s_BuildData_7;
	// System.Action`3<UnityEngine.Timeline.TimelineClip,UnityEngine.GameObject,UnityEngine.Playables.Playable> UnityEngine.Timeline.TrackAsset::OnClipPlayableCreate
	Action_3_t3DEF6B983A6FD251CA5E86CED7441D9CF0A26209 * ___OnClipPlayableCreate_9;
	// System.Action`3<UnityEngine.Timeline.TrackAsset,UnityEngine.GameObject,UnityEngine.Playables.Playable> UnityEngine.Timeline.TrackAsset::OnTrackAnimationPlayableCreate
	Action_3_t08E03FF5D8187DCF3A2B450F10E005618E1956C1 * ___OnTrackAnimationPlayableCreate_10;
	// UnityEngine.Timeline.TrackAsset[] UnityEngine.Timeline.TrackAsset::s_EmptyCache
	TrackAssetU5BU5D_t064A662B3D4A13A5BAAB5D4CAD343DB1D2171EF5* ___s_EmptyCache_23;
	// System.Collections.Generic.Dictionary`2<System.Type,UnityEngine.Timeline.TrackBindingTypeAttribute> UnityEngine.Timeline.TrackAsset::s_TrackBindingTypeAttributeCache
	Dictionary_2_t1B7E37FEB7F10BFB6B7320EF2FEC7B2CDE25C7E4 * ___s_TrackBindingTypeAttributeCache_25;

public:
	inline static int32_t get_offset_of_s_BuildData_7() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_StaticFields, ___s_BuildData_7)); }
	inline TransientBuildData_t2CDF71634041677EC226311F30665780C2026744  get_s_BuildData_7() const { return ___s_BuildData_7; }
	inline TransientBuildData_t2CDF71634041677EC226311F30665780C2026744 * get_address_of_s_BuildData_7() { return &___s_BuildData_7; }
	inline void set_s_BuildData_7(TransientBuildData_t2CDF71634041677EC226311F30665780C2026744  value)
	{
		___s_BuildData_7 = value;
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_BuildData_7))->___trackList_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_BuildData_7))->___clipList_1), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&(((&___s_BuildData_7))->___markerList_2), (void*)NULL);
		#endif
	}

	inline static int32_t get_offset_of_OnClipPlayableCreate_9() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_StaticFields, ___OnClipPlayableCreate_9)); }
	inline Action_3_t3DEF6B983A6FD251CA5E86CED7441D9CF0A26209 * get_OnClipPlayableCreate_9() const { return ___OnClipPlayableCreate_9; }
	inline Action_3_t3DEF6B983A6FD251CA5E86CED7441D9CF0A26209 ** get_address_of_OnClipPlayableCreate_9() { return &___OnClipPlayableCreate_9; }
	inline void set_OnClipPlayableCreate_9(Action_3_t3DEF6B983A6FD251CA5E86CED7441D9CF0A26209 * value)
	{
		___OnClipPlayableCreate_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OnClipPlayableCreate_9), (void*)value);
	}

	inline static int32_t get_offset_of_OnTrackAnimationPlayableCreate_10() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_StaticFields, ___OnTrackAnimationPlayableCreate_10)); }
	inline Action_3_t08E03FF5D8187DCF3A2B450F10E005618E1956C1 * get_OnTrackAnimationPlayableCreate_10() const { return ___OnTrackAnimationPlayableCreate_10; }
	inline Action_3_t08E03FF5D8187DCF3A2B450F10E005618E1956C1 ** get_address_of_OnTrackAnimationPlayableCreate_10() { return &___OnTrackAnimationPlayableCreate_10; }
	inline void set_OnTrackAnimationPlayableCreate_10(Action_3_t08E03FF5D8187DCF3A2B450F10E005618E1956C1 * value)
	{
		___OnTrackAnimationPlayableCreate_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OnTrackAnimationPlayableCreate_10), (void*)value);
	}

	inline static int32_t get_offset_of_s_EmptyCache_23() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_StaticFields, ___s_EmptyCache_23)); }
	inline TrackAssetU5BU5D_t064A662B3D4A13A5BAAB5D4CAD343DB1D2171EF5* get_s_EmptyCache_23() const { return ___s_EmptyCache_23; }
	inline TrackAssetU5BU5D_t064A662B3D4A13A5BAAB5D4CAD343DB1D2171EF5** get_address_of_s_EmptyCache_23() { return &___s_EmptyCache_23; }
	inline void set_s_EmptyCache_23(TrackAssetU5BU5D_t064A662B3D4A13A5BAAB5D4CAD343DB1D2171EF5* value)
	{
		___s_EmptyCache_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_EmptyCache_23), (void*)value);
	}

	inline static int32_t get_offset_of_s_TrackBindingTypeAttributeCache_25() { return static_cast<int32_t>(offsetof(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_StaticFields, ___s_TrackBindingTypeAttributeCache_25)); }
	inline Dictionary_2_t1B7E37FEB7F10BFB6B7320EF2FEC7B2CDE25C7E4 * get_s_TrackBindingTypeAttributeCache_25() const { return ___s_TrackBindingTypeAttributeCache_25; }
	inline Dictionary_2_t1B7E37FEB7F10BFB6B7320EF2FEC7B2CDE25C7E4 ** get_address_of_s_TrackBindingTypeAttributeCache_25() { return &___s_TrackBindingTypeAttributeCache_25; }
	inline void set_s_TrackBindingTypeAttributeCache_25(Dictionary_2_t1B7E37FEB7F10BFB6B7320EF2FEC7B2CDE25C7E4 * value)
	{
		___s_TrackBindingTypeAttributeCache_25 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___s_TrackBindingTypeAttributeCache_25), (void*)value);
	}
};


// AkEventTrack
struct  AkEventTrack_t6030D1051D1ACA190784CDB5D4C0461578F9E226  : public TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D
{
public:

public:
};


// AkRTPCTrack
struct  AkRTPCTrack_t7AED5E0856187915E29DFFB53DE919F7EC9CFB74  : public TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D
{
public:
	// AK.Wwise.RTPC AkRTPCTrack::Parameter
	RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___Parameter_28;

public:
	inline static int32_t get_offset_of_Parameter_28() { return static_cast<int32_t>(offsetof(AkRTPCTrack_t7AED5E0856187915E29DFFB53DE919F7EC9CFB74, ___Parameter_28)); }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * get_Parameter_28() const { return ___Parameter_28; }
	inline RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C ** get_address_of_Parameter_28() { return &___Parameter_28; }
	inline void set_Parameter_28(RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * value)
	{
		___Parameter_28 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Parameter_28), (void*)value);
	}
};


// AkTimelineEventTrack
struct  AkTimelineEventTrack_t93130E623074A6BC6A9643A4434153816C60FB8D  : public TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D
{
public:

public:
};


// AkTimelineRtpcTrack
struct  AkTimelineRtpcTrack_t24C4A29FFDA9C21457A11DF2EB1FE2812DF4D85C  : public TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif


// UnityEngine.Playables.ScriptPlayable`1<!0> UnityEngine.Playables.ScriptPlayable`1<System.Object>::Create(UnityEngine.Playables.PlayableGraph,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C  ScriptPlayable_1_Create_mBE8425D4AF7A0A82F7EE4705CFA90D78548797A8_gshared (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, int32_t ___inputCount1, const RuntimeMethod* method);
// !0 UnityEngine.ExposedReference`1<System.Object>::Resolve(UnityEngine.IExposedPropertyTable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * ExposedReference_1_Resolve_mBBA492F672C2CF69CFA8999F11C1FBD967AFFD1F_gshared (ExposedReference_1_t6A54AB83F72FCC7CB479D3F39F3CFC074284DF86 * __this, RuntimeObject* ___resolver0, const RuntimeMethod* method);
// UnityEngine.Playables.Playable UnityEngine.Playables.ScriptPlayable`1<System.Object>::op_Implicit(UnityEngine.Playables.ScriptPlayable`1<!0>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ScriptPlayable_1_op_Implicit_mCAFBDEC4F98B94A0A6045DE2FBAE38B2707D7973_gshared (ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C  ___playable0, const RuntimeMethod* method);
// !0 UnityEngine.Playables.ScriptPlayable`1<System.Object>::GetBehaviour()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject * ScriptPlayable_1_GetBehaviour_m18F5C11A92B96501B55054208E95985D5C72F9B4_gshared (ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C * __this, const RuntimeMethod* method);
// System.Double UnityEngine.Playables.PlayableExtensions::GetTime<UnityEngine.Playables.Playable>(!!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_gshared (Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Double UnityEngine.Playables.PlayableExtensions::GetPreviousTime<UnityEngine.Playables.Playable>(!!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double PlayableExtensions_GetPreviousTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_mC130F5DC9CA211F6E74092978A776E41476695DD_gshared (Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Double UnityEngine.Playables.PlayableExtensions::GetDuration<UnityEngine.Playables.Playable>(!!0)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_gshared (Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void UnityEngine.Playables.PlayableExtensions::SetInputCount<UnityEngine.Playables.ScriptPlayable`1<System.Object>>(!!0,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayableExtensions_SetInputCount_TisScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C_m2774559EFF46341FD237D613631323E3DEC292C4_gshared (ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C  ___playable0, int32_t ___value1, const RuntimeMethod* method);
// UnityEngine.Playables.ScriptPlayable`1<!0> UnityEngine.Playables.ScriptPlayable`1<System.Object>::Create(UnityEngine.Playables.PlayableGraph,!0,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C  ScriptPlayable_1_Create_mF0ECFA76EEC27F6ED078BDD40138F6CEFCB46161_gshared (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, RuntimeObject * ___template1, int32_t ___inputCount2, const RuntimeMethod* method);

// UnityEngine.Playables.ScriptPlayable`1<!0> UnityEngine.Playables.ScriptPlayable`1<AkEventPlayableBehavior>::Create(UnityEngine.Playables.PlayableGraph,System.Int32)
inline ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  ScriptPlayable_1_Create_m7A54D906486B8C92680D138B9DB80F4BF06D95FF (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, int32_t ___inputCount1, const RuntimeMethod* method)
{
	return ((  ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  (*) (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA , int32_t, const RuntimeMethod*))ScriptPlayable_1_Create_mBE8425D4AF7A0A82F7EE4705CFA90D78548797A8_gshared)(___graph0, ___inputCount1, method);
}
// UnityEngine.IExposedPropertyTable UnityEngine.Playables.PlayableGraph::GetResolver()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* PlayableGraph_GetResolver_m52F92B131B65F7412D220BB853C562C5983E884E (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA * __this, const RuntimeMethod* method);
// !0 UnityEngine.ExposedReference`1<UnityEngine.GameObject>::Resolve(UnityEngine.IExposedPropertyTable)
inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ExposedReference_1_Resolve_m9FB7DD08C2FC3CA91FB22B8FD26763647838966B (ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944 * __this, RuntimeObject* ___resolver0, const RuntimeMethod* method)
{
	return ((  GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * (*) (ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944 *, RuntimeObject*, const RuntimeMethod*))ExposedReference_1_Resolve_mBBA492F672C2CF69CFA8999F11C1FBD967AFFD1F_gshared)(__this, ___resolver0, method);
}
// System.Boolean UnityEngine.Object::op_Equality(UnityEngine.Object,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Equality_mBC2401774F3BE33E8CF6F0A8148E66C95D6CFF1C (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___x0, Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___y1, const RuntimeMethod* method);
// UnityEngine.Playables.Playable UnityEngine.Playables.ScriptPlayable`1<AkEventPlayableBehavior>::op_Implicit(UnityEngine.Playables.ScriptPlayable`1<!0>)
inline Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ScriptPlayable_1_op_Implicit_m4A760D65CA9E71CDCBD51F5326CF756C6469A917 (ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  ___playable0, const RuntimeMethod* method)
{
	return ((  Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  (*) (ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91 , const RuntimeMethod*))ScriptPlayable_1_op_Implicit_mCAFBDEC4F98B94A0A6045DE2FBAE38B2707D7973_gshared)(___playable0, method);
}
// !0 UnityEngine.Playables.ScriptPlayable`1<AkEventPlayableBehavior>::GetBehaviour()
inline AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * ScriptPlayable_1_GetBehaviour_m78D32C6FED2A5C43A4812E314EA936DF34C97E72 (ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91 * __this, const RuntimeMethod* method)
{
	return ((  AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * (*) (ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91 *, const RuntimeMethod*))ScriptPlayable_1_GetBehaviour_m18F5C11A92B96501B55054208E95985D5C72F9B4_gshared)(__this, method);
}
// System.Double UnityEngine.Timeline.TimelineClip::get_easeInDuration()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double TimelineClip_get_easeInDuration_m86C28CFFB8EB583729B28F952FEACC3F28A24B08 (TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * __this, const RuntimeMethod* method);
// System.Double UnityEngine.Timeline.TimelineClip::get_easeOutDuration()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double TimelineClip_get_easeOutDuration_m7635A403CDFBDF310136765D38E894CACF775980 (TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * __this, const RuntimeMethod* method);
// System.Double UnityEngine.Timeline.TimelineClip::get_blendInDuration()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double TimelineClip_get_blendInDuration_m9BAD5A16030AC49404E40CD8188BDB1D6C886CAF (TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * __this, const RuntimeMethod* method);
// System.Double UnityEngine.Timeline.TimelineClip::get_blendOutDuration()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double TimelineClip_get_blendOutDuration_mCCD5E4EFD9381253CF3146BD01173251FA2266BC (TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.Object::op_Inequality(UnityEngine.Object,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1 (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___x0, Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___y1, const RuntimeMethod* method);
// System.Void AK.Wwise.Event::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event__ctor_mB99941177C1FF4FE4FDDD4185CB0C25681F4815D (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Playables.PlayableAsset::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayableAsset__ctor_m669F459CFACFE65873346E428F206C457B488167 (PlayableAsset_t28B670EFE526C0D383A1C5A5AE2A150424E989AD * __this, const RuntimeMethod* method);
// System.Single AkDurationCallbackInfo::get_fEstimatedDuration()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float AkDurationCallbackInfo_get_fEstimatedDuration_m309CD6D65AA0299C965EF62F2A598A8C50E41A3D (AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25 * __this, const RuntimeMethod* method);
// UnityEngine.Playables.FrameData/EvaluationType UnityEngine.Playables.FrameData::get_evaluationType()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FrameData_get_evaluationType_mF0F791BAF13A203A8D80AD4C1474599E1EED5EA4 (FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Playables.PlayableBehaviour::PrepareFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayableBehaviour_PrepareFrame_m0FC4368B39C1DBC6586E417C8505D1A8C49235E2 (PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, const RuntimeMethod* method);
// System.Boolean AkEventPlayableBehavior::ShouldPlay(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkEventPlayableBehavior_ShouldPlay_m0D795A2E75928584EB42A147B02E7B5739979FCF (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Boolean AkEventPlayableBehavior::IsScrubbing(UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkEventPlayableBehavior_IsScrubbing_m30BA7DE4C1AE99A700C0D74FE46A14CFA5A7E8E5 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info0, const RuntimeMethod* method);
// System.Void AkEventPlayableBehavior::CheckForFadeInFadeOut(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_CheckForFadeInFadeOut_mAEE0E6FD3FA3A9F9DDA169F6A91A947836A5CA5D (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Double UnityEngine.Playables.PlayableExtensions::GetTime<UnityEngine.Playables.Playable>(!!0)
inline double PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D (Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	return ((  double (*) (Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0 , const RuntimeMethod*))PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_gshared)(___playable0, method);
}
// System.Void AkEventPlayableBehavior::CheckForFadeOut(UnityEngine.Playables.Playable,System.Double)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_CheckForFadeOut_m4237D0A6569C78554DB3FB05EABDC0F021E1C876 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, double ___currentClipTime1, const RuntimeMethod* method);
// System.Void UnityEngine.Playables.PlayableBehaviour::OnBehaviourPlay(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayableBehaviour_OnBehaviourPlay_m4B44CD41A9CB3EA391BCB142FA3B9A80AFAFF820 (PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, const RuntimeMethod* method);
// System.Single AkEventPlayableBehavior::GetProportionalTime(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float AkEventPlayableBehavior_GetProportionalTime_m55D607F02942EA64628CB143502ADEE5AA6C5E38 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void UnityEngine.Playables.PlayableBehaviour::OnBehaviourPause(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayableBehaviour_OnBehaviourPause_mBC9C4536B30B413E248C96294F53CDABA2C1490C (PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, const RuntimeMethod* method);
// System.Void AkEventPlayableBehavior::StopEvent(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_StopEvent_m859E382FC1FB0FDBC6F7F444BFB12A13959528EF (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, int32_t ___transition0, const RuntimeMethod* method);
// System.Void UnityEngine.Playables.PlayableBehaviour::ProcessFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayableBehaviour_ProcessFrame_m32F9B265BB54D1A3A290E2709FDD0B873360B25A (PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, RuntimeObject * ___playerData2, const RuntimeMethod* method);
// System.Void AkEventPlayableBehavior::PlayEvent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_PlayEvent_m31FE7AB1B461F873F305551233377616202E5297 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, const RuntimeMethod* method);
// System.Single AkEventPlayableBehavior::SeekToTime(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float AkEventPlayableBehavior_SeekToTime_mD813E49C24A8D301C8C2100D162AE54F781E14EA (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void AkEventPlayableBehavior::RetriggerEvent(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_RetriggerEvent_mEFDC6CDBCB432003FA8C89B99984FDB8F34AB1C0 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void AkEventPlayableBehavior::TriggerFadeIn(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_TriggerFadeIn_m46D06E3EF21E0CD876E24C2C5C1C0DDC0D7829DB (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void AkEventPlayableBehavior::TriggerFadeOut(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_TriggerFadeOut_mE96A5DA38440E3F69ED8170BA2D8757806B78ECF (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Double UnityEngine.Playables.PlayableExtensions::GetPreviousTime<UnityEngine.Playables.Playable>(!!0)
inline double PlayableExtensions_GetPreviousTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_mC130F5DC9CA211F6E74092978A776E41476695DD (Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	return ((  double (*) (Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0 , const RuntimeMethod*))PlayableExtensions_GetPreviousTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_mC130F5DC9CA211F6E74092978A776E41476695DD_gshared)(___playable0, method);
}
// System.Double UnityEngine.Playables.PlayableExtensions::GetDuration<UnityEngine.Playables.Playable>(!!0)
inline double PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75 (Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	return ((  double (*) (Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0 , const RuntimeMethod*))PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_gshared)(___playable0, method);
}
// System.Single UnityEngine.Mathf::Max(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Mathf_Max_m670AE0EC1B09ED1A56FF9606B0F954670319CB65 (float ___a0, float ___b1, const RuntimeMethod* method);
// System.Void AK.Wwise.Event::ExecuteAction(UnityEngine.GameObject,AkActionOnEventType,System.Int32,AkCurveInterpolation)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, int32_t ___actionOnEventType1, int32_t ___transitionDuration2, int32_t ___curveInterpolation3, const RuntimeMethod* method);
// System.Void AK.Wwise.Event::Stop(UnityEngine.GameObject,System.Int32,AkCurveInterpolation)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Event_Stop_mF058FF1C69C98C1C87C1B2F517DBDBEAAE85D943 (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, int32_t ___transitionDuration1, int32_t ___curveInterpolation2, const RuntimeMethod* method);
// System.Void AkCallbackManager/EventCallback::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void EventCallback__ctor_m8CEF34110B8FAB336F2211A3ED290453F048C6E2 (EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method);
// System.UInt32 AK.Wwise.Event::Post(UnityEngine.GameObject,System.UInt32,AkCallbackManager/EventCallback,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t Event_Post_m975A00B31848012ACE9114D3FDB25CA0E630601D (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, uint32_t ___flags1, EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 * ___callback2, RuntimeObject * ___cookie3, const RuntimeMethod* method);
// System.Boolean AkEventPlayableBehavior::PostEvent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkEventPlayableBehavior_PostEvent_mFE27FB7B99751D0D2D60DC0B59AC336B824D07D7 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, const RuntimeMethod* method);
// System.UInt32 AK.Wwise.BaseType::get_Id()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A (BaseType_t1EA3255D738B4A44FAC08556A5A537D46C23C9DE * __this, const RuntimeMethod* method);
// AKRESULT AkSoundEngine::SeekOnEvent(System.UInt32,UnityEngine.GameObject,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkSoundEngine_SeekOnEvent_m5ABF68DD7A2149E6D7D4AE61D2F597E0B1F60574 (uint32_t ___in_eventID0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___in_gameObjectID1, float ___in_fPercent2, const RuntimeMethod* method);
// System.Void UnityEngine.Playables.PlayableBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlayableBehaviour__ctor_mE96A877D927BEEC8C9368A0673FEAD77A78C35EE (PlayableBehaviour_t5F4AA32E735199182CC5F57D426D27BE8ABA8F01 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Playables.PlayableExtensions::SetInputCount<UnityEngine.Playables.ScriptPlayable`1<AkEventPlayableBehavior>>(!!0,System.Int32)
inline void PlayableExtensions_SetInputCount_TisScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_mA8E2E4D605D78423DB070AC3DEAD58FF1EC81768 (ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  ___playable0, int32_t ___value1, const RuntimeMethod* method)
{
	((  void (*) (ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91 , int32_t, const RuntimeMethod*))PlayableExtensions_SetInputCount_TisScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C_m2774559EFF46341FD237D613631323E3DEC292C4_gshared)(___playable0, ___value1, method);
}
// System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TimelineClip> UnityEngine.Timeline.TrackAsset::GetClips()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* TrackAsset_GetClips_m2A53471D61EE6C84F42BE83D0E689691382FA172 (TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D * __this, const RuntimeMethod* method);
// UnityEngine.Object UnityEngine.Timeline.TimelineClip::get_asset()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * TimelineClip_get_asset_mCF4C0F2153BF18362958432960C87A24B5534245_inline (TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Timeline.TrackAsset::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TrackAsset__ctor_mB57EE24087931D858028EE79112A1FABDC95E5C6 (TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D * __this, const RuntimeMethod* method);
// UnityEngine.Playables.ScriptPlayable`1<!0> UnityEngine.Playables.ScriptPlayable`1<AkRTPCPlayableBehaviour>::Create(UnityEngine.Playables.PlayableGraph,!0,System.Int32)
inline ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  ScriptPlayable_1_Create_mE8D356E1368B91006D6F66A1A066280BD1900F11 (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * ___template1, int32_t ___inputCount2, const RuntimeMethod* method)
{
	return ((  ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  (*) (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA , AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 *, int32_t, const RuntimeMethod*))ScriptPlayable_1_Create_mF0ECFA76EEC27F6ED078BDD40138F6CEFCB46161_gshared)(___graph0, ___template1, ___inputCount2, method);
}
// !0 UnityEngine.Playables.ScriptPlayable`1<AkRTPCPlayableBehaviour>::GetBehaviour()
inline AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * ScriptPlayable_1_GetBehaviour_m6C5AA4AF673B74C88F047C8A555F75D2C172539B (ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B * __this, const RuntimeMethod* method)
{
	return ((  AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * (*) (ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B *, const RuntimeMethod*))ScriptPlayable_1_GetBehaviour_m18F5C11A92B96501B55054208E95985D5C72F9B4_gshared)(__this, method);
}
// System.Void AkRTPCPlayableBehaviour::set_overrideTrackObject(System.Boolean)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_overrideTrackObject_m8DF38D0A0F763DD5B549E2AAC92EE04614ACC73B_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void AkRTPCPlayableBehaviour::set_setRTPCGlobally(System.Boolean)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_setRTPCGlobally_mD76260F7F2F1F5E2372CE49E4FE26FDCCFE631F7_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, bool ___value0, const RuntimeMethod* method);
// System.Void AkRTPCPlayableBehaviour::set_rtpcObject(UnityEngine.GameObject)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_rtpcObject_m064CC1ADCDF87B23D01249F73FE85704F502BA34_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___value0, const RuntimeMethod* method);
// AK.Wwise.RTPC AkRTPCPlayable::get_Parameter()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * AkRTPCPlayable_get_Parameter_m2D38638222BA51B7DFAF565B8694C56D379B20F3_inline (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, const RuntimeMethod* method);
// System.Void AkRTPCPlayableBehaviour::set_parameter(AK.Wwise.RTPC)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_parameter_m6915EF2CBEE92F68DDA1126FC809432AAB995F7B_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___value0, const RuntimeMethod* method);
// UnityEngine.Playables.Playable UnityEngine.Playables.ScriptPlayable`1<AkRTPCPlayableBehaviour>::op_Implicit(UnityEngine.Playables.ScriptPlayable`1<!0>)
inline Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ScriptPlayable_1_op_Implicit_m21D4A99D0E874E3E359EA0D880D8109296AFF222 (ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  ___playable0, const RuntimeMethod* method)
{
	return ((  Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  (*) (ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B , const RuntimeMethod*))ScriptPlayable_1_op_Implicit_mCAFBDEC4F98B94A0A6045DE2FBAE38B2707D7973_gshared)(___playable0, method);
}
// System.Void AkRTPCPlayableBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour__ctor_m175798E277AC3BD3144B12EF06F4EC6B8217A16A (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method);
// AK.Wwise.RTPC AkRTPCPlayableBehaviour::get_parameter()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * AkRTPCPlayableBehaviour_get_parameter_m186376F0D552C0754F21097D49C0E4C81546892B_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method);
// System.Boolean AkRTPCPlayableBehaviour::get_overrideTrackObject()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool AkRTPCPlayableBehaviour_get_overrideTrackObject_mBCDF4A0A2FA5ED107088104035AC259CD94615A2_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method);
// System.Boolean AkRTPCPlayableBehaviour::get_setRTPCGlobally()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool AkRTPCPlayableBehaviour_get_setRTPCGlobally_mBF723B975C206CF59964725F4E2D887FA4C96C95_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method);
// UnityEngine.GameObject AkRTPCPlayableBehaviour::get_rtpcObject()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * AkRTPCPlayableBehaviour_get_rtpcObject_mF5DAB9C945515A7D7FE3A9743EC5A68851149359_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method);
// System.Void AK.Wwise.RTPC::SetGlobalValue(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RTPC_SetGlobalValue_mE95A5B940C8101349FA64E225E3D08233871C505 (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, float ___value0, const RuntimeMethod* method);
// System.Void AK.Wwise.RTPC::SetValue(UnityEngine.GameObject,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RTPC_SetValue_m1C344467FDED1786C71D410DBFCD5D03DCCD9AD5 (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject0, float ___value1, const RuntimeMethod* method);
// UnityEngine.Playables.ScriptPlayable`1<!0> UnityEngine.Playables.ScriptPlayable`1<AkRTPCPlayableBehaviour>::Create(UnityEngine.Playables.PlayableGraph,System.Int32)
inline ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  ScriptPlayable_1_Create_mC5C205146F9478E15CFE24C9D68FB30F6779D7C8 (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, int32_t ___inputCount1, const RuntimeMethod* method)
{
	return ((  ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  (*) (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA , int32_t, const RuntimeMethod*))ScriptPlayable_1_Create_mBE8425D4AF7A0A82F7EE4705CFA90D78548797A8_gshared)(___graph0, ___inputCount1, method);
}
// System.Void AkRTPCTrack::setPlayableProperties()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCTrack_setPlayableProperties_mED078171919EA44228E367042940ACA6DE9A69EF (AkRTPCTrack_t7AED5E0856187915E29DFFB53DE919F7EC9CFB74 * __this, const RuntimeMethod* method);
// System.Void AkRTPCPlayable::set_Parameter(AK.Wwise.RTPC)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayable_set_Parameter_m6FCF8273EB6C0879509D3D1E25E4856756D0A7E5_inline (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___value0, const RuntimeMethod* method);
// System.Void AkRTPCPlayable::set_OwningClip(UnityEngine.Timeline.TimelineClip)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayable_set_OwningClip_mED2FC6B983BDF1F35AB3A5D66833DDD0C5B865BB_inline (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___value0, const RuntimeMethod* method);
// UnityEngine.Playables.ScriptPlayable`1<!0> UnityEngine.Playables.ScriptPlayable`1<AkTimelineEventPlayableBehavior>::Create(UnityEngine.Playables.PlayableGraph,System.Int32)
inline ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  ScriptPlayable_1_Create_m0C1209813E5FE8A3908A07A94193CC3C6FC29756 (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, int32_t ___inputCount1, const RuntimeMethod* method)
{
	return ((  ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  (*) (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA , int32_t, const RuntimeMethod*))ScriptPlayable_1_Create_mBE8425D4AF7A0A82F7EE4705CFA90D78548797A8_gshared)(___graph0, ___inputCount1, method);
}
// UnityEngine.Playables.Playable UnityEngine.Playables.ScriptPlayable`1<AkTimelineEventPlayableBehavior>::op_Implicit(UnityEngine.Playables.ScriptPlayable`1<!0>)
inline Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ScriptPlayable_1_op_Implicit_m52EBDBFDF6B21D71CEA48FB89BC92CDAF68851FD (ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  ___playable0, const RuntimeMethod* method)
{
	return ((  Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  (*) (ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC , const RuntimeMethod*))ScriptPlayable_1_op_Implicit_mCAFBDEC4F98B94A0A6045DE2FBAE38B2707D7973_gshared)(___playable0, method);
}
// !0 UnityEngine.Playables.ScriptPlayable`1<AkTimelineEventPlayableBehavior>::GetBehaviour()
inline AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * ScriptPlayable_1_GetBehaviour_m4A0EE0982E042FF81F5DF187A039E63B83A90863 (ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC * __this, const RuntimeMethod* method)
{
	return ((  AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * (*) (ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC *, const RuntimeMethod*))ScriptPlayable_1_GetBehaviour_m18F5C11A92B96501B55054208E95985D5C72F9B4_gshared)(__this, method);
}
// System.Boolean AkTimelineEventPlayableBehavior::ShouldPlay(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkTimelineEventPlayableBehavior_ShouldPlay_m99F0C560CBA4A34FFE51A9DF5D04D71F77557EF2 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Boolean AkTimelineEventPlayableBehavior::IsScrubbing(UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkTimelineEventPlayableBehavior_IsScrubbing_mF483DA94E4F58AB10598906D95E9513A7B1A9419 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info0, const RuntimeMethod* method);
// System.Void AkTimelineEventPlayableBehavior::CheckForFadeInFadeOut(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_CheckForFadeInFadeOut_m0F701A1EF78E0E94A89ECAC700DF1BED77F025CD (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void AkTimelineEventPlayableBehavior::CheckForFadeOut(UnityEngine.Playables.Playable,System.Double)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_CheckForFadeOut_mE4B19F2E4539E898615CDA6CB4DD5CD5C193D316 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, double ___currentClipTime1, const RuntimeMethod* method);
// System.Single AkTimelineEventPlayableBehavior::GetProportionalTime(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float AkTimelineEventPlayableBehavior_GetProportionalTime_m52FBF2A2547C3263133CDA715BB870A8DD8A9D77 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void AkTimelineEventPlayableBehavior::StopEvent(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_StopEvent_m76B40E41ADA129808B8DF8D5701D69F031ED03FB (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, int32_t ___transition0, const RuntimeMethod* method);
// System.Void AkTimelineEventPlayableBehavior::PlayEvent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_PlayEvent_mED0A3AE5CF58B04026B73FB2BDB43E7B0299D5CD (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, const RuntimeMethod* method);
// System.Single AkTimelineEventPlayableBehavior::SeekToTime(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float AkTimelineEventPlayableBehavior_SeekToTime_m97F34CBA9DF79E28A393710EBE06D5EAA1C938E7 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void AkTimelineEventPlayableBehavior::RetriggerEvent(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_RetriggerEvent_m7A9B9D27455C1824DEC3921F9D0326D8B156CAE2 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void AkTimelineEventPlayableBehavior::TriggerFadeIn(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_TriggerFadeIn_mAF9E9008AD701FAD3F372AE1C3054F59A0714A56 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Void AkTimelineEventPlayableBehavior::TriggerFadeOut(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_TriggerFadeOut_m90EB244EBF6E02CD5C322D45BEB051356B6C31FC (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method);
// System.Boolean AkTimelineEventPlayableBehavior::PostEvent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkTimelineEventPlayableBehavior_PostEvent_mE7DBE796B44E46703E212E79ED76B1D31761ED2C (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Playables.PlayableExtensions::SetInputCount<UnityEngine.Playables.ScriptPlayable`1<AkTimelineEventPlayableBehavior>>(!!0,System.Int32)
inline void PlayableExtensions_SetInputCount_TisScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_m72C445E9F3D119051901CBC7B175A868F0F410EF (ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  ___playable0, int32_t ___value1, const RuntimeMethod* method)
{
	((  void (*) (ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC , int32_t, const RuntimeMethod*))PlayableExtensions_SetInputCount_TisScriptPlayable_1_t63661AF0CAE2B3B155608EFD5C3E712F0446136C_m2774559EFF46341FD237D613631323E3DEC292C4_gshared)(___playable0, ___value1, method);
}
// UnityEngine.Playables.ScriptPlayable`1<!0> UnityEngine.Playables.ScriptPlayable`1<AkTimelineRtpcPlayableBehaviour>::Create(UnityEngine.Playables.PlayableGraph,!0,System.Int32)
inline ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  ScriptPlayable_1_Create_m59CEC9FB4154638ED596E64AD2D7BA87D3825FF4 (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * ___template1, int32_t ___inputCount2, const RuntimeMethod* method)
{
	return ((  ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  (*) (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA , AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E *, int32_t, const RuntimeMethod*))ScriptPlayable_1_Create_mF0ECFA76EEC27F6ED078BDD40138F6CEFCB46161_gshared)(___graph0, ___template1, ___inputCount2, method);
}
// !0 UnityEngine.Playables.ScriptPlayable`1<AkTimelineRtpcPlayableBehaviour>::GetBehaviour()
inline AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * ScriptPlayable_1_GetBehaviour_mBB9A6506A045C46C979B2CB00455DEF36A8B8236 (ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F * __this, const RuntimeMethod* method)
{
	return ((  AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * (*) (ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F *, const RuntimeMethod*))ScriptPlayable_1_GetBehaviour_m18F5C11A92B96501B55054208E95985D5C72F9B4_gshared)(__this, method);
}
// System.Void AkTimelineRtpcPlayableBehaviour::set_RTPC(AK.Wwise.RTPC)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_set_RTPC_m266951A6E2AC14364383E32C41F18379112079AD_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___value0, const RuntimeMethod* method);
// System.Void AkTimelineRtpcPlayableBehaviour::set_setGlobally(System.Boolean)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_set_setGlobally_m885F5D0F80346DC21D56C1A7693D54E676D03DFE_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, bool ___value0, const RuntimeMethod* method);
// System.Void AkTimelineRtpcPlayableBehaviour::set_gameObject(UnityEngine.GameObject)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_set_gameObject_mE64DDF14D65AA4221C916A362D854390AB02653C_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___value0, const RuntimeMethod* method);
// UnityEngine.Playables.Playable UnityEngine.Playables.ScriptPlayable`1<AkTimelineRtpcPlayableBehaviour>::op_Implicit(UnityEngine.Playables.ScriptPlayable`1<!0>)
inline Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ScriptPlayable_1_op_Implicit_m1CF6AF8A5E29CBAD2BE823B72646D7F4D292F4D9 (ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  ___playable0, const RuntimeMethod* method)
{
	return ((  Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  (*) (ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F , const RuntimeMethod*))ScriptPlayable_1_op_Implicit_mCAFBDEC4F98B94A0A6045DE2FBAE38B2707D7973_gshared)(___playable0, method);
}
// System.Void AK.Wwise.RTPC::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RTPC__ctor_m7ECE0016601182CE16F80569BBD0F6E1C206803A (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * __this, const RuntimeMethod* method);
// System.Void AkTimelineRtpcPlayableBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour__ctor_mF1B7D8F25FAE1196AA4F5E2DD5D8F04B89D1DB4F (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method);
// AK.Wwise.RTPC AkTimelineRtpcPlayableBehaviour::get_RTPC()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * AkTimelineRtpcPlayableBehaviour_get_RTPC_m6F7A917B5A02F293BC59B0E39C428C3AF6C6ED34_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method);
// System.Boolean AkTimelineRtpcPlayableBehaviour::get_setGlobally()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool AkTimelineRtpcPlayableBehaviour_get_setGlobally_mFCE6782EF459AB9BD2B1C9ABF5FAB200CAE0FA90_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method);
// UnityEngine.GameObject AkTimelineRtpcPlayableBehaviour::get_gameObject()
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * AkTimelineRtpcPlayableBehaviour_get_gameObject_m9F80502C76AFF69F91CAD39D68CDED532987369E_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.Object::op_Implicit(UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534 (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * ___exists0, const RuntimeMethod* method);
// UnityEngine.Playables.ScriptPlayable`1<!0> UnityEngine.Playables.ScriptPlayable`1<AkTimelineRtpcPlayableBehaviour>::Create(UnityEngine.Playables.PlayableGraph,System.Int32)
inline ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  ScriptPlayable_1_Create_m6EDD12B7BD86240B4CC3454532CC07C826603BB8 (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, int32_t ___inputCount1, const RuntimeMethod* method)
{
	return ((  ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  (*) (PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA , int32_t, const RuntimeMethod*))ScriptPlayable_1_Create_mBE8425D4AF7A0A82F7EE4705CFA90D78548797A8_gshared)(___graph0, ___inputCount1, method);
}
// System.Void AkTimelineRtpcPlayable::set_owningClip(UnityEngine.Timeline.TimelineClip)
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayable_set_owningClip_m79D794A183DE5DF73FCAA031047D704FDD6B617E_inline (AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * __this, TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___value0, const RuntimeMethod* method);
// System.Void AkTimelineRtpcPlayable::SetupClipDisplay()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayable_SetupClipDisplay_mA1C3BBAB686C4C8BB005A7FB54643DC1A53D716C (AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * __this, const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Timeline.ClipCaps AkEventPlayable::UnityEngine.Timeline.ITimelineClipAsset.get_clipCaps()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkEventPlayable_UnityEngine_Timeline_ITimelineClipAsset_get_clipCaps_mDE4E35CDEFB66B35B5051240B012A4502E17802A (AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA * __this, const RuntimeMethod* method)
{
	{
		// get { return UnityEngine.Timeline.ClipCaps.Looping | UnityEngine.Timeline.ClipCaps.Blending; }
		return (int32_t)(((int32_t)17));
	}
}
// UnityEngine.Playables.Playable AkEventPlayable::CreatePlayable(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  AkEventPlayable_CreatePlayable_mCA5F54473B58CC0F601088ACAD05598456ED1C20 (AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA * __this, PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___owner1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayable_CreatePlayable_mCA5F54473B58CC0F601088ACAD05598456ED1C20_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  V_0;
	memset((&V_0), 0, sizeof(V_0));
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * V_1 = NULL;
	AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * V_2 = NULL;
	float V_3 = 0.0f;
	{
		// var playable = UnityEngine.Playables.ScriptPlayable<AkEventPlayableBehavior>.Create(graph);
		PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  L_0 = ___graph0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_il2cpp_TypeInfo_var);
		ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  L_1 = ScriptPlayable_1_Create_m7A54D906486B8C92680D138B9DB80F4BF06D95FF(L_0, 0, /*hidden argument*/ScriptPlayable_1_Create_m7A54D906486B8C92680D138B9DB80F4BF06D95FF_RuntimeMethod_var);
		V_0 = L_1;
		// var eventObject = emitterObjectRef.Resolve(graph.GetResolver());
		ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944 * L_2 = __this->get_address_of_emitterObjectRef_7();
		RuntimeObject* L_3 = PlayableGraph_GetResolver_m52F92B131B65F7412D220BB853C562C5983E884E((PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA *)(&___graph0), /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_4 = ExposedReference_1_Resolve_m9FB7DD08C2FC3CA91FB22B8FD26763647838966B((ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944 *)L_2, L_3, /*hidden argument*/ExposedReference_1_Resolve_m9FB7DD08C2FC3CA91FB22B8FD26763647838966B_RuntimeMethod_var);
		V_1 = L_4;
		// if (eventObject == null)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_5 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_6 = Object_op_Equality_mBC2401774F3BE33E8CF6F0A8148E66C95D6CFF1C(L_5, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0026;
		}
	}
	{
		// eventObject = owner;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_7 = ___owner1;
		V_1 = L_7;
	}

IL_0026:
	{
		// if (eventObject == null || akEvent == null)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_8 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_9 = Object_op_Equality_mBC2401774F3BE33E8CF6F0A8148E66C95D6CFF1C(L_8, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (L_9)
		{
			goto IL_0037;
		}
	}
	{
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_10 = __this->get_akEvent_4();
		if (L_10)
		{
			goto IL_003e;
		}
	}

IL_0037:
	{
		// return playable;
		ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  L_11 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_il2cpp_TypeInfo_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_12 = ScriptPlayable_1_op_Implicit_m4A760D65CA9E71CDCBD51F5326CF756C6469A917(L_11, /*hidden argument*/ScriptPlayable_1_op_Implicit_m4A760D65CA9E71CDCBD51F5326CF756C6469A917_RuntimeMethod_var);
		return L_12;
	}

IL_003e:
	{
		// var b = playable.GetBehaviour();
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_13 = ScriptPlayable_1_GetBehaviour_m78D32C6FED2A5C43A4812E314EA936DF34C97E72((ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91 *)(&V_0), /*hidden argument*/ScriptPlayable_1_GetBehaviour_m78D32C6FED2A5C43A4812E314EA936DF34C97E72_RuntimeMethod_var);
		V_2 = L_13;
		// b.akEvent = akEvent;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_14 = V_2;
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_15 = __this->get_akEvent_4();
		NullCheck(L_14);
		L_14->set_akEvent_9(L_15);
		// b.blendInCurve = blendInCurve;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_16 = V_2;
		int32_t L_17 = __this->get_blendInCurve_5();
		NullCheck(L_16);
		L_16->set_blendInCurve_16(L_17);
		// b.blendOutCurve = blendOutCurve;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_18 = V_2;
		int32_t L_19 = __this->get_blendOutCurve_6();
		NullCheck(L_18);
		L_18->set_blendOutCurve_17(L_19);
		// if (owningClip != null)
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_20 = __this->get_owningClip_10();
		if (!L_20)
		{
			goto IL_00bc;
		}
	}
	{
		// b.easeInDuration = (float)owningClip.easeInDuration;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_21 = V_2;
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_22 = __this->get_owningClip_10();
		NullCheck(L_22);
		double L_23 = TimelineClip_get_easeInDuration_m86C28CFFB8EB583729B28F952FEACC3F28A24B08(L_22, /*hidden argument*/NULL);
		NullCheck(L_21);
		L_21->set_easeInDuration_14((((float)((float)L_23))));
		// b.easeOutDuration = (float)owningClip.easeOutDuration;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_24 = V_2;
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_25 = __this->get_owningClip_10();
		NullCheck(L_25);
		double L_26 = TimelineClip_get_easeOutDuration_m7635A403CDFBDF310136765D38E894CACF775980(L_25, /*hidden argument*/NULL);
		NullCheck(L_24);
		L_24->set_easeOutDuration_15((((float)((float)L_26))));
		// b.blendInDuration = (float)owningClip.blendInDuration;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_27 = V_2;
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_28 = __this->get_owningClip_10();
		NullCheck(L_28);
		double L_29 = TimelineClip_get_blendInDuration_m9BAD5A16030AC49404E40CD8188BDB1D6C886CAF(L_28, /*hidden argument*/NULL);
		NullCheck(L_27);
		L_27->set_blendInDuration_12((((float)((float)L_29))));
		// b.blendOutDuration = (float)owningClip.blendOutDuration;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_30 = V_2;
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_31 = __this->get_owningClip_10();
		NullCheck(L_31);
		double L_32 = TimelineClip_get_blendOutDuration_mCCD5E4EFD9381253CF3146BD01173251FA2266BC(L_31, /*hidden argument*/NULL);
		NullCheck(L_30);
		L_30->set_blendOutDuration_13((((float)((float)L_32))));
		// }
		goto IL_00e2;
	}

IL_00bc:
	{
		// b.easeInDuration = b.easeOutDuration = b.blendInDuration = b.blendOutDuration = 0;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_33 = V_2;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_34 = V_2;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_35 = V_2;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_36 = V_2;
		float L_37 = (0.0f);
		V_3 = L_37;
		NullCheck(L_36);
		L_36->set_blendOutDuration_13(L_37);
		float L_38 = V_3;
		float L_39 = L_38;
		V_3 = L_39;
		NullCheck(L_35);
		L_35->set_blendInDuration_12(L_39);
		float L_40 = V_3;
		float L_41 = L_40;
		V_3 = L_41;
		NullCheck(L_34);
		L_34->set_easeOutDuration_15(L_41);
		float L_42 = V_3;
		NullCheck(L_33);
		L_33->set_easeInDuration_14(L_42);
	}

IL_00e2:
	{
		// b.retriggerEvent = retriggerEvent;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_43 = V_2;
		bool L_44 = __this->get_retriggerEvent_11();
		NullCheck(L_43);
		L_43->set_retriggerEvent_19(L_44);
		// b.StopEventAtClipEnd = StopEventAtClipEnd;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_45 = V_2;
		bool L_46 = __this->get_StopEventAtClipEnd_13();
		NullCheck(L_45);
		L_45->set_StopEventAtClipEnd_21(L_46);
		// b.eventObject = eventObject;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_47 = V_2;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_48 = V_1;
		NullCheck(L_47);
		L_47->set_eventObject_18(L_48);
		// b.overrideTrackEmitterObject = eventObject != null;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_49 = V_2;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_50 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_51 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_50, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		NullCheck(L_49);
		L_49->set_overrideTrackEmitterObject_22(L_51);
		// b.eventDurationMin = eventDurationMin;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_52 = V_2;
		float L_53 = __this->get_eventDurationMin_9();
		NullCheck(L_52);
		L_52->set_eventDurationMin_11(L_53);
		// b.eventDurationMax = eventDurationMax;
		AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * L_54 = V_2;
		float L_55 = __this->get_eventDurationMax_8();
		NullCheck(L_54);
		L_54->set_eventDurationMax_10(L_55);
		// return playable;
		ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  L_56 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_il2cpp_TypeInfo_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_57 = ScriptPlayable_1_op_Implicit_m4A760D65CA9E71CDCBD51F5326CF756C6469A917(L_56, /*hidden argument*/ScriptPlayable_1_op_Implicit_m4A760D65CA9E71CDCBD51F5326CF756C6469A917_RuntimeMethod_var);
		return L_57;
	}
}
// System.Void AkEventPlayable::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayable__ctor_m2AD6F2A6F4F0FA118155CCBF8AEA78E705B1A5AC (AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayable__ctor_m2AD6F2A6F4F0FA118155CCBF8AEA78E705B1A5AC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public AK.Wwise.Event akEvent = new AK.Wwise.Event();
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_0 = (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F *)il2cpp_codegen_object_new(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F_il2cpp_TypeInfo_var);
		Event__ctor_mB99941177C1FF4FE4FDDD4185CB0C25681F4815D(L_0, /*hidden argument*/NULL);
		__this->set_akEvent_4(L_0);
		// private AkCurveInterpolation blendInCurve = AkCurveInterpolation.AkCurveInterpolation_Linear;
		__this->set_blendInCurve_5(4);
		// private AkCurveInterpolation blendOutCurve = AkCurveInterpolation.AkCurveInterpolation_Linear;
		__this->set_blendOutCurve_6(4);
		// public float eventDurationMax = -1f;
		__this->set_eventDurationMax_8((-1.0f));
		// public float eventDurationMin = -1f;
		__this->set_eventDurationMin_9((-1.0f));
		// public bool UseWwiseEventDuration = true;
		__this->set_UseWwiseEventDuration_12((bool)1);
		// private bool StopEventAtClipEnd = true;
		__this->set_StopEventAtClipEnd_13((bool)1);
		PlayableAsset__ctor_m669F459CFACFE65873346E428F206C457B488167(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkEventPlayableBehavior::CallbackHandler(System.Object,AkCallbackType,AkCallbackInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_CallbackHandler_m4013ACF017F9C05D622CFF482A6443167CC70066 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, RuntimeObject * ___in_cookie0, int32_t ___in_type1, AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979 * ___in_info2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_CallbackHandler_m4013ACF017F9C05D622CFF482A6443167CC70066_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	float V_1 = 0.0f;
	{
		// if (in_type == AkCallbackType.AK_EndOfEvent)
		int32_t L_0 = ___in_type1;
		if ((!(((uint32_t)L_0) == ((uint32_t)1))))
		{
			goto IL_001e;
		}
	}
	{
		// eventIsPlaying = fadeinTriggered = fadeoutTriggered = false;
		int32_t L_1 = 0;
		V_0 = (bool)L_1;
		__this->set_fadeoutTriggered_4((bool)L_1);
		bool L_2 = V_0;
		bool L_3 = L_2;
		V_0 = L_3;
		__this->set_fadeinTriggered_3(L_3);
		bool L_4 = V_0;
		__this->set_eventIsPlaying_2(L_4);
		// }
		return;
	}

IL_001e:
	{
		// else if (in_type == AkCallbackType.AK_Duration)
		int32_t L_5 = ___in_type1;
		if ((!(((uint32_t)L_5) == ((uint32_t)8))))
		{
			goto IL_0042;
		}
	}
	{
		// var estimatedDuration = (in_info as AkDurationCallbackInfo).fEstimatedDuration;
		AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979 * L_6 = ___in_info2;
		NullCheck(((AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25 *)IsInstClass((RuntimeObject*)L_6, AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25_il2cpp_TypeInfo_var)));
		float L_7 = AkDurationCallbackInfo_get_fEstimatedDuration_m309CD6D65AA0299C965EF62F2A598A8C50E41A3D(((AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25 *)IsInstClass((RuntimeObject*)L_6, AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
		V_1 = L_7;
		// currentDuration = estimatedDuration * currentDurationProportion / 1000f;
		float L_8 = V_1;
		float L_9 = __this->get_currentDurationProportion_1();
		__this->set_currentDuration_0(((float)((float)((float)il2cpp_codegen_multiply((float)L_8, (float)L_9))/(float)(1000.0f))));
	}

IL_0042:
	{
		// }
		return;
	}
}
// System.Boolean AkEventPlayableBehavior::IsScrubbing(UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkEventPlayableBehavior_IsScrubbing_m30BA7DE4C1AE99A700C0D74FE46A14CFA5A7E8E5 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info0, const RuntimeMethod* method)
{
	{
		// return info.evaluationType == UnityEngine.Playables.FrameData.EvaluationType.Evaluate;
		int32_t L_0 = FrameData_get_evaluationType_mF0F791BAF13A203A8D80AD4C1474599E1EED5EA4((FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E *)(&___info0), /*hidden argument*/NULL);
		return (bool)((((int32_t)L_0) == ((int32_t)0))? 1 : 0);
	}
}
// System.Void AkEventPlayableBehavior::PrepareFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_PrepareFrame_m32EF4AB1E373025355F1C907EFD16A1AC715D6AF (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_PrepareFrame_m32EF4AB1E373025355F1C907EFD16A1AC715D6AF_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		// base.PrepareFrame(playable, info);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_1 = ___info1;
		PlayableBehaviour_PrepareFrame_m0FC4368B39C1DBC6586E417C8505D1A8C49235E2(__this, L_0, L_1, /*hidden argument*/NULL);
		// if (akEvent == null)
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_2 = __this->get_akEvent_9();
		if (L_2)
		{
			goto IL_0011;
		}
	}
	{
		// return;
		return;
	}

IL_0011:
	{
		// var shouldPlay = ShouldPlay(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_3 = ___playable0;
		bool L_4 = AkEventPlayableBehavior_ShouldPlay_m0D795A2E75928584EB42A147B02E7B5739979FCF(__this, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		// if (IsScrubbing(info) && shouldPlay)
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_5 = ___info1;
		bool L_6 = AkEventPlayableBehavior_IsScrubbing_m30BA7DE4C1AE99A700C0D74FE46A14CFA5A7E8E5(__this, L_5, /*hidden argument*/NULL);
		bool L_7 = V_0;
		if (!((int32_t)((int32_t)L_6&(int32_t)L_7)))
		{
			goto IL_0050;
		}
	}
	{
		// requiredActions |= Actions.Seek;
		int32_t L_8 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_8|(int32_t)8)));
		// if (!eventIsPlaying)
		bool L_9 = __this->get_eventIsPlaying_2();
		if (L_9)
		{
			goto IL_0085;
		}
	}
	{
		// requiredActions |= Actions.Playback | Actions.DelayedStop;
		int32_t L_10 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_10|(int32_t)5)));
		// CheckForFadeInFadeOut(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_11 = ___playable0;
		AkEventPlayableBehavior_CheckForFadeInFadeOut_mAEE0E6FD3FA3A9F9DDA169F6A91A947836A5CA5D(__this, L_11, /*hidden argument*/NULL);
		// }
		return;
	}

IL_0050:
	{
		// else if (!eventIsPlaying && (requiredActions & Actions.Playback) == 0)
		bool L_12 = __this->get_eventIsPlaying_2();
		if (L_12)
		{
			goto IL_0078;
		}
	}
	{
		int32_t L_13 = __this->get_requiredActions_7();
		if (((int32_t)((int32_t)L_13&(int32_t)1)))
		{
			goto IL_0078;
		}
	}
	{
		// requiredActions |= Actions.Retrigger;
		int32_t L_14 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_14|(int32_t)2)));
		// CheckForFadeInFadeOut(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_15 = ___playable0;
		AkEventPlayableBehavior_CheckForFadeInFadeOut_mAEE0E6FD3FA3A9F9DDA169F6A91A947836A5CA5D(__this, L_15, /*hidden argument*/NULL);
		// }
		return;
	}

IL_0078:
	{
		// CheckForFadeOut(playable, UnityEngine.Playables.PlayableExtensions.GetTime(playable));
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_16 = ___playable0;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_17 = ___playable0;
		double L_18 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_17, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		AkEventPlayableBehavior_CheckForFadeOut_m4237D0A6569C78554DB3FB05EABDC0F021E1C876(__this, L_16, L_18, /*hidden argument*/NULL);
	}

IL_0085:
	{
		// }
		return;
	}
}
// System.Void AkEventPlayableBehavior::OnBehaviourPlay(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_OnBehaviourPlay_m2724EE2E13B9DC5E24586051EC64C8E2E0F9E0F1 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, const RuntimeMethod* method)
{
	{
		// base.OnBehaviourPlay(playable, info);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_1 = ___info1;
		PlayableBehaviour_OnBehaviourPlay_m4B44CD41A9CB3EA391BCB142FA3B9A80AFAFF820(__this, L_0, L_1, /*hidden argument*/NULL);
		// if (akEvent == null)
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_2 = __this->get_akEvent_9();
		if (L_2)
		{
			goto IL_0011;
		}
	}
	{
		// return;
		return;
	}

IL_0011:
	{
		// var shouldPlay = ShouldPlay(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_3 = ___playable0;
		bool L_4 = AkEventPlayableBehavior_ShouldPlay_m0D795A2E75928584EB42A147B02E7B5739979FCF(__this, L_3, /*hidden argument*/NULL);
		// if (!shouldPlay)
		if (L_4)
		{
			goto IL_001b;
		}
	}
	{
		// return;
		return;
	}

IL_001b:
	{
		// requiredActions |= Actions.Playback;
		int32_t L_5 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_5|(int32_t)1)));
		// if (IsScrubbing(info))
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_6 = ___info1;
		bool L_7 = AkEventPlayableBehavior_IsScrubbing_m30BA7DE4C1AE99A700C0D74FE46A14CFA5A7E8E5(__this, L_6, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0049;
		}
	}
	{
		// wasScrubbingAndRequiresRetrigger = true;
		__this->set_wasScrubbingAndRequiresRetrigger_20((bool)1);
		// requiredActions |= Actions.DelayedStop;
		int32_t L_8 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_8|(int32_t)4)));
		// }
		goto IL_0065;
	}

IL_0049:
	{
		// else if (GetProportionalTime(playable) > alph)
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_9 = ___playable0;
		float L_10 = AkEventPlayableBehavior_GetProportionalTime_m55D607F02942EA64628CB143502ADEE5AA6C5E38(__this, L_9, /*hidden argument*/NULL);
		if ((!(((float)L_10) > ((float)(0.05f)))))
		{
			goto IL_0065;
		}
	}
	{
		// requiredActions |= Actions.Seek;
		int32_t L_11 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_11|(int32_t)8)));
	}

IL_0065:
	{
		// CheckForFadeInFadeOut(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_12 = ___playable0;
		AkEventPlayableBehavior_CheckForFadeInFadeOut_mAEE0E6FD3FA3A9F9DDA169F6A91A947836A5CA5D(__this, L_12, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void AkEventPlayableBehavior::OnBehaviourPause(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_OnBehaviourPause_mC8D3DD00BDF5E2274D5A16CB9E8960247A033973 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_OnBehaviourPause_mC8D3DD00BDF5E2274D5A16CB9E8960247A033973_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// wasScrubbingAndRequiresRetrigger = false;
		__this->set_wasScrubbingAndRequiresRetrigger_20((bool)0);
		// base.OnBehaviourPause(playable, info);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_1 = ___info1;
		PlayableBehaviour_OnBehaviourPause_mBC9C4536B30B413E248C96294F53CDABA2C1490C(__this, L_0, L_1, /*hidden argument*/NULL);
		// if (eventObject != null && akEvent != null && StopEventAtClipEnd)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_2 = __this->get_eventObject_18();
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_3 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_2, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0034;
		}
	}
	{
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_4 = __this->get_akEvent_9();
		if (!L_4)
		{
			goto IL_0034;
		}
	}
	{
		bool L_5 = __this->get_StopEventAtClipEnd_21();
		if (!L_5)
		{
			goto IL_0034;
		}
	}
	{
		// StopEvent();
		AkEventPlayableBehavior_StopEvent_m859E382FC1FB0FDBC6F7F444BFB12A13959528EF(__this, 0, /*hidden argument*/NULL);
	}

IL_0034:
	{
		// }
		return;
	}
}
// System.Void AkEventPlayableBehavior::ProcessFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_ProcessFrame_m6D84D059A28B0B8038550C6A2F9438AA87D20092 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, RuntimeObject * ___playerData2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_ProcessFrame_m6D84D059A28B0B8038550C6A2F9438AA87D20092_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * V_0 = NULL;
	{
		// base.ProcessFrame(playable, info, playerData);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_1 = ___info1;
		RuntimeObject * L_2 = ___playerData2;
		PlayableBehaviour_ProcessFrame_m32F9B265BB54D1A3A290E2709FDD0B873360B25A(__this, L_0, L_1, L_2, /*hidden argument*/NULL);
		// if (akEvent == null)
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_3 = __this->get_akEvent_9();
		if (L_3)
		{
			goto IL_0012;
		}
	}
	{
		// return;
		return;
	}

IL_0012:
	{
		// if (!overrideTrackEmitterObject)
		bool L_4 = __this->get_overrideTrackEmitterObject_22();
		if (L_4)
		{
			goto IL_0031;
		}
	}
	{
		// var obj = playerData as UnityEngine.GameObject;
		RuntimeObject * L_5 = ___playerData2;
		V_0 = ((GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F *)IsInstSealed((RuntimeObject*)L_5, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F_il2cpp_TypeInfo_var));
		// if (obj != null)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_6 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_7 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_6, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0031;
		}
	}
	{
		// eventObject = obj;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_8 = V_0;
		__this->set_eventObject_18(L_8);
	}

IL_0031:
	{
		// if (eventObject == null)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_9 = __this->get_eventObject_18();
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_10 = Object_op_Equality_mBC2401774F3BE33E8CF6F0A8148E66C95D6CFF1C(L_9, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_10)
		{
			goto IL_0040;
		}
	}
	{
		// return;
		return;
	}

IL_0040:
	{
		// if ((requiredActions & Actions.Playback) != 0)
		int32_t L_11 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_11&(int32_t)1)))
		{
			goto IL_0050;
		}
	}
	{
		// PlayEvent();
		AkEventPlayableBehavior_PlayEvent_m31FE7AB1B461F873F305551233377616202E5297(__this, /*hidden argument*/NULL);
	}

IL_0050:
	{
		// if ((requiredActions & Actions.Seek) != 0)
		int32_t L_12 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_12&(int32_t)8)))
		{
			goto IL_0062;
		}
	}
	{
		// SeekToTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_13 = ___playable0;
		AkEventPlayableBehavior_SeekToTime_mD813E49C24A8D301C8C2100D162AE54F781E14EA(__this, L_13, /*hidden argument*/NULL);
	}

IL_0062:
	{
		// if ((retriggerEvent || wasScrubbingAndRequiresRetrigger) && (requiredActions & Actions.Retrigger) != 0)
		bool L_14 = __this->get_retriggerEvent_19();
		if (L_14)
		{
			goto IL_0072;
		}
	}
	{
		bool L_15 = __this->get_wasScrubbingAndRequiresRetrigger_20();
		if (!L_15)
		{
			goto IL_0083;
		}
	}

IL_0072:
	{
		int32_t L_16 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_16&(int32_t)2)))
		{
			goto IL_0083;
		}
	}
	{
		// RetriggerEvent(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_17 = ___playable0;
		AkEventPlayableBehavior_RetriggerEvent_mEFDC6CDBCB432003FA8C89B99984FDB8F34AB1C0(__this, L_17, /*hidden argument*/NULL);
	}

IL_0083:
	{
		// if ((requiredActions & Actions.DelayedStop) != 0)
		int32_t L_18 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_18&(int32_t)4)))
		{
			goto IL_0095;
		}
	}
	{
		// StopEvent(scrubPlaybackLengthMs);
		AkEventPlayableBehavior_StopEvent_m859E382FC1FB0FDBC6F7F444BFB12A13959528EF(__this, ((int32_t)100), /*hidden argument*/NULL);
	}

IL_0095:
	{
		// if (!fadeinTriggered && (requiredActions & Actions.FadeIn) != 0)
		bool L_19 = __this->get_fadeinTriggered_3();
		if (L_19)
		{
			goto IL_00af;
		}
	}
	{
		int32_t L_20 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_20&(int32_t)((int32_t)16))))
		{
			goto IL_00af;
		}
	}
	{
		// TriggerFadeIn(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_21 = ___playable0;
		AkEventPlayableBehavior_TriggerFadeIn_m46D06E3EF21E0CD876E24C2C5C1C0DDC0D7829DB(__this, L_21, /*hidden argument*/NULL);
	}

IL_00af:
	{
		// if (!fadeoutTriggered && (requiredActions & Actions.FadeOut) != 0)
		bool L_22 = __this->get_fadeoutTriggered_4();
		if (L_22)
		{
			goto IL_00c9;
		}
	}
	{
		int32_t L_23 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_23&(int32_t)((int32_t)32))))
		{
			goto IL_00c9;
		}
	}
	{
		// TriggerFadeOut(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_24 = ___playable0;
		AkEventPlayableBehavior_TriggerFadeOut_mE96A5DA38440E3F69ED8170BA2D8757806B78ECF(__this, L_24, /*hidden argument*/NULL);
	}

IL_00c9:
	{
		// requiredActions = Actions.None;
		__this->set_requiredActions_7(0);
		// }
		return;
	}
}
// System.Boolean AkEventPlayableBehavior::ShouldPlay(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkEventPlayableBehavior_ShouldPlay_m0D795A2E75928584EB42A147B02E7B5739979FCF (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_ShouldPlay_m0D795A2E75928584EB42A147B02E7B5739979FCF_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	double V_1 = 0.0;
	float V_2 = 0.0f;
	float G_B11_0 = 0.0f;
	{
		// var previousTime = UnityEngine.Playables.PlayableExtensions.GetPreviousTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		double L_1 = PlayableExtensions_GetPreviousTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_mC130F5DC9CA211F6E74092978A776E41476695DD(L_0, /*hidden argument*/PlayableExtensions_GetPreviousTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_mC130F5DC9CA211F6E74092978A776E41476695DD_RuntimeMethod_var);
		V_0 = L_1;
		// var currentTime = UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_2 = ___playable0;
		double L_3 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_2, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		V_1 = L_3;
		// if (previousTime == 0.0 && System.Math.Abs(currentTime - previousTime) > 1.0)
		double L_4 = V_0;
		if ((!(((double)L_4) == ((double)(0.0)))))
		{
			goto IL_002f;
		}
	}
	{
		double L_5 = V_1;
		double L_6 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Math_tFB388E53C7FDC6FCCF9A19ABF5A4E521FBD52E19_il2cpp_TypeInfo_var);
		double L_7 = fabs(((double)il2cpp_codegen_subtract((double)L_5, (double)L_6)));
		if ((!(((double)L_7) > ((double)(1.0)))))
		{
			goto IL_002f;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_002f:
	{
		// if (retriggerEvent)
		bool L_8 = __this->get_retriggerEvent_19();
		if (!L_8)
		{
			goto IL_0039;
		}
	}
	{
		// return true;
		return (bool)1;
	}

IL_0039:
	{
		// if (eventDurationMax == eventDurationMin && eventDurationMin != -1f)
		float L_9 = __this->get_eventDurationMax_10();
		float L_10 = __this->get_eventDurationMin_11();
		if ((!(((float)L_9) == ((float)L_10))))
		{
			goto IL_005f;
		}
	}
	{
		float L_11 = __this->get_eventDurationMin_11();
		if ((((float)L_11) == ((float)(-1.0f))))
		{
			goto IL_005f;
		}
	}
	{
		// return currentTime < eventDurationMax;
		double L_12 = V_1;
		float L_13 = __this->get_eventDurationMax_10();
		return (bool)((((double)L_12) < ((double)(((double)((double)L_13)))))? 1 : 0);
	}

IL_005f:
	{
		// currentTime -= previousEventStartTime;
		double L_14 = V_1;
		float L_15 = __this->get_previousEventStartTime_5();
		V_1 = ((double)il2cpp_codegen_subtract((double)L_14, (double)(((double)((double)L_15)))));
		// var maxDuration = currentDuration == -1f ? (float)UnityEngine.Playables.PlayableExtensions.GetDuration(playable) : currentDuration;
		float L_16 = __this->get_currentDuration_0();
		if ((((float)L_16) == ((float)(-1.0f))))
		{
			goto IL_007e;
		}
	}
	{
		float L_17 = __this->get_currentDuration_0();
		G_B11_0 = L_17;
		goto IL_0085;
	}

IL_007e:
	{
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_18 = ___playable0;
		double L_19 = PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75(L_18, /*hidden argument*/PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_RuntimeMethod_var);
		G_B11_0 = (((float)((float)L_19)));
	}

IL_0085:
	{
		V_2 = G_B11_0;
		// return currentTime < maxDuration;
		double L_20 = V_1;
		float L_21 = V_2;
		return (bool)((((double)L_20) < ((double)(((double)((double)L_21)))))? 1 : 0);
	}
}
// System.Void AkEventPlayableBehavior::CheckForFadeInFadeOut(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_CheckForFadeInFadeOut_mAEE0E6FD3FA3A9F9DDA169F6A91A947836A5CA5D (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_CheckForFadeInFadeOut_mAEE0E6FD3FA3A9F9DDA169F6A91A947836A5CA5D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	{
		// var currentClipTime = UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		double L_1 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_0, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		V_0 = L_1;
		// if (blendInDuration > currentClipTime || easeInDuration > currentClipTime)
		float L_2 = __this->get_blendInDuration_12();
		double L_3 = V_0;
		if ((((double)(((double)((double)L_2)))) > ((double)L_3)))
		{
			goto IL_001b;
		}
	}
	{
		float L_4 = __this->get_easeInDuration_14();
		double L_5 = V_0;
		if ((!(((double)(((double)((double)L_4)))) > ((double)L_5))))
		{
			goto IL_002a;
		}
	}

IL_001b:
	{
		// requiredActions |= Actions.FadeIn;
		int32_t L_6 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_6|(int32_t)((int32_t)16))));
	}

IL_002a:
	{
		// CheckForFadeOut(playable, currentClipTime);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_7 = ___playable0;
		double L_8 = V_0;
		AkEventPlayableBehavior_CheckForFadeOut_m4237D0A6569C78554DB3FB05EABDC0F021E1C876(__this, L_7, L_8, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void AkEventPlayableBehavior::CheckForFadeOut(UnityEngine.Playables.Playable,System.Double)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_CheckForFadeOut_m4237D0A6569C78554DB3FB05EABDC0F021E1C876 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, double ___currentClipTime1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_CheckForFadeOut_m4237D0A6569C78554DB3FB05EABDC0F021E1C876_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	{
		// var timeLeft = UnityEngine.Playables.PlayableExtensions.GetDuration(playable) - currentClipTime;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		double L_1 = PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75(L_0, /*hidden argument*/PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_RuntimeMethod_var);
		double L_2 = ___currentClipTime1;
		V_0 = ((double)il2cpp_codegen_subtract((double)L_1, (double)L_2));
		// if (blendOutDuration >= timeLeft || easeOutDuration >= timeLeft)
		float L_3 = __this->get_blendOutDuration_13();
		double L_4 = V_0;
		if ((((double)(((double)((double)L_3)))) >= ((double)L_4)))
		{
			goto IL_001d;
		}
	}
	{
		float L_5 = __this->get_easeOutDuration_15();
		double L_6 = V_0;
		if ((!(((double)(((double)((double)L_5)))) >= ((double)L_6))))
		{
			goto IL_002c;
		}
	}

IL_001d:
	{
		// requiredActions |= Actions.FadeOut;
		int32_t L_7 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_7|(int32_t)((int32_t)32))));
	}

IL_002c:
	{
		// }
		return;
	}
}
// System.Void AkEventPlayableBehavior::TriggerFadeIn(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_TriggerFadeIn_m46D06E3EF21E0CD876E24C2C5C1C0DDC0D7829DB (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_TriggerFadeIn_m46D06E3EF21E0CD876E24C2C5C1C0DDC0D7829DB_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	double V_1 = 0.0;
	{
		// var currentClipTime = UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		double L_1 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_0, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		V_0 = L_1;
		// var fadeDuration = UnityEngine.Mathf.Max(easeInDuration, blendInDuration) - currentClipTime;
		float L_2 = __this->get_easeInDuration_14();
		float L_3 = __this->get_blendInDuration_12();
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		float L_4 = Mathf_Max_m670AE0EC1B09ED1A56FF9606B0F954670319CB65(L_2, L_3, /*hidden argument*/NULL);
		double L_5 = V_0;
		V_1 = ((double)il2cpp_codegen_subtract((double)(((double)((double)L_4))), (double)L_5));
		// if (fadeDuration > 0)
		double L_6 = V_1;
		if ((!(((double)L_6) > ((double)(0.0)))))
		{
			goto IL_006c;
		}
	}
	{
		// fadeinTriggered = true;
		__this->set_fadeinTriggered_3((bool)1);
		// akEvent.ExecuteAction(eventObject, AkActionOnEventType.AkActionOnEventType_Pause, 0, blendOutCurve);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_7 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_8 = __this->get_eventObject_18();
		int32_t L_9 = __this->get_blendOutCurve_17();
		NullCheck(L_7);
		Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE(L_7, L_8, 1, 0, L_9, /*hidden argument*/NULL);
		// akEvent.ExecuteAction(eventObject, AkActionOnEventType.AkActionOnEventType_Resume, (int)(fadeDuration * 1000), blendInCurve);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_10 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_11 = __this->get_eventObject_18();
		double L_12 = V_1;
		int32_t L_13 = __this->get_blendInCurve_16();
		NullCheck(L_10);
		Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE(L_10, L_11, 2, (((int32_t)((int32_t)((double)il2cpp_codegen_multiply((double)L_12, (double)(1000.0)))))), L_13, /*hidden argument*/NULL);
	}

IL_006c:
	{
		// }
		return;
	}
}
// System.Void AkEventPlayableBehavior::TriggerFadeOut(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_TriggerFadeOut_mE96A5DA38440E3F69ED8170BA2D8757806B78ECF (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_TriggerFadeOut_mE96A5DA38440E3F69ED8170BA2D8757806B78ECF_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	{
		// fadeoutTriggered = true;
		__this->set_fadeoutTriggered_4((bool)1);
		// var fadeDuration = UnityEngine.Playables.PlayableExtensions.GetDuration(playable) - UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		double L_1 = PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75(L_0, /*hidden argument*/PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_RuntimeMethod_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_2 = ___playable0;
		double L_3 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_2, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		V_0 = ((double)il2cpp_codegen_subtract((double)L_1, (double)L_3));
		// akEvent.ExecuteAction(eventObject, AkActionOnEventType.AkActionOnEventType_Stop, (int)(fadeDuration * 1000), blendOutCurve);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_4 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_5 = __this->get_eventObject_18();
		double L_6 = V_0;
		int32_t L_7 = __this->get_blendOutCurve_17();
		NullCheck(L_4);
		Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE(L_4, L_5, 0, (((int32_t)((int32_t)((double)il2cpp_codegen_multiply((double)L_6, (double)(1000.0)))))), L_7, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void AkEventPlayableBehavior::StopEvent(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_StopEvent_m859E382FC1FB0FDBC6F7F444BFB12A13959528EF (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, int32_t ___transition0, const RuntimeMethod* method)
{
	{
		// if (!eventIsPlaying)
		bool L_0 = __this->get_eventIsPlaying_2();
		if (L_0)
		{
			goto IL_0009;
		}
	}
	{
		// return;
		return;
	}

IL_0009:
	{
		// akEvent.Stop(eventObject, transition);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_1 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_2 = __this->get_eventObject_18();
		int32_t L_3 = ___transition0;
		NullCheck(L_1);
		Event_Stop_mF058FF1C69C98C1C87C1B2F517DBDBEAAE85D943(L_1, L_2, L_3, 4, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Boolean AkEventPlayableBehavior::PostEvent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkEventPlayableBehavior_PostEvent_mFE27FB7B99751D0D2D60DC0B59AC336B824D07D7 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_PostEvent_mFE27FB7B99751D0D2D60DC0B59AC336B824D07D7_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint32_t V_0 = 0;
	bool V_1 = false;
	{
		// fadeinTriggered = fadeoutTriggered = false;
		int32_t L_0 = 0;
		V_1 = (bool)L_0;
		__this->set_fadeoutTriggered_4((bool)L_0);
		bool L_1 = V_1;
		__this->set_fadeinTriggered_3(L_1);
		// playingID = akEvent.Post(eventObject, CallbackFlags, CallbackHandler, null);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_2 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_3 = __this->get_eventObject_18();
		EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 * L_4 = (EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 *)il2cpp_codegen_object_new(EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561_il2cpp_TypeInfo_var);
		EventCallback__ctor_m8CEF34110B8FAB336F2211A3ED290453F048C6E2(L_4, __this, (intptr_t)((intptr_t)AkEventPlayableBehavior_CallbackHandler_m4013ACF017F9C05D622CFF482A6443167CC70066_RuntimeMethod_var), /*hidden argument*/NULL);
		NullCheck(L_2);
		uint32_t L_5 = Event_Post_m975A00B31848012ACE9114D3FDB25CA0E630601D(L_2, L_3, ((int32_t)9), L_4, NULL, /*hidden argument*/NULL);
		V_0 = L_5;
		// eventIsPlaying = playingID != AkSoundEngine.AK_INVALID_PLAYING_ID;
		uint32_t L_6 = V_0;
		__this->set_eventIsPlaying_2((bool)((!(((uint32_t)L_6) <= ((uint32_t)0)))? 1 : 0));
		// return eventIsPlaying;
		bool L_7 = __this->get_eventIsPlaying_2();
		return L_7;
	}
}
// System.Void AkEventPlayableBehavior::PlayEvent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_PlayEvent_m31FE7AB1B461F873F305551233377616202E5297 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, const RuntimeMethod* method)
{
	{
		// if (!PostEvent())
		bool L_0 = AkEventPlayableBehavior_PostEvent_mFE27FB7B99751D0D2D60DC0B59AC336B824D07D7(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_0009;
		}
	}
	{
		// return;
		return;
	}

IL_0009:
	{
		// currentDurationProportion = 1f;
		__this->set_currentDurationProportion_1((1.0f));
		// previousEventStartTime = 0f;
		__this->set_previousEventStartTime_5((0.0f));
		// }
		return;
	}
}
// System.Void AkEventPlayableBehavior::RetriggerEvent(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior_RetriggerEvent_mEFDC6CDBCB432003FA8C89B99984FDB8F34AB1C0 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_RetriggerEvent_mEFDC6CDBCB432003FA8C89B99984FDB8F34AB1C0_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// wasScrubbingAndRequiresRetrigger = false;
		__this->set_wasScrubbingAndRequiresRetrigger_20((bool)0);
		// if (!PostEvent())
		bool L_0 = AkEventPlayableBehavior_PostEvent_mFE27FB7B99751D0D2D60DC0B59AC336B824D07D7(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_0010;
		}
	}
	{
		// return;
		return;
	}

IL_0010:
	{
		// currentDurationProportion = 1f - SeekToTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_1 = ___playable0;
		float L_2 = AkEventPlayableBehavior_SeekToTime_mD813E49C24A8D301C8C2100D162AE54F781E14EA(__this, L_1, /*hidden argument*/NULL);
		__this->set_currentDurationProportion_1(((float)il2cpp_codegen_subtract((float)(1.0f), (float)L_2)));
		// previousEventStartTime = (float)UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_3 = ___playable0;
		double L_4 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_3, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		__this->set_previousEventStartTime_5((((float)((float)L_4))));
		// }
		return;
	}
}
// System.Single AkEventPlayableBehavior::GetProportionalTime(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float AkEventPlayableBehavior_GetProportionalTime_m55D607F02942EA64628CB143502ADEE5AA6C5E38 (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_GetProportionalTime_m55D607F02942EA64628CB143502ADEE5AA6C5E38_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	float G_B5_0 = 0.0f;
	float G_B4_0 = 0.0f;
	float G_B6_0 = 0.0f;
	float G_B6_1 = 0.0f;
	{
		// if (eventDurationMax == eventDurationMin && eventDurationMin != -1f)
		float L_0 = __this->get_eventDurationMax_10();
		float L_1 = __this->get_eventDurationMin_11();
		if ((!(((float)L_0) == ((float)L_1))))
		{
			goto IL_0031;
		}
	}
	{
		float L_2 = __this->get_eventDurationMin_11();
		if ((((float)L_2) == ((float)(-1.0f))))
		{
			goto IL_0031;
		}
	}
	{
		// return (float)UnityEngine.Playables.PlayableExtensions.GetTime(playable) % eventDurationMax / eventDurationMax;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_3 = ___playable0;
		double L_4 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_3, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		float L_5 = __this->get_eventDurationMax_10();
		float L_6 = __this->get_eventDurationMax_10();
		return ((float)((float)(fmodf((((float)((float)L_4))), L_5))/(float)L_6));
	}

IL_0031:
	{
		// var currentTime = (float)UnityEngine.Playables.PlayableExtensions.GetTime(playable) - previousEventStartTime;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_7 = ___playable0;
		double L_8 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_7, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		float L_9 = __this->get_previousEventStartTime_5();
		// var maxDuration = currentDuration == -1f ? (float)UnityEngine.Playables.PlayableExtensions.GetDuration(playable) : currentDuration;
		float L_10 = __this->get_currentDuration_0();
		G_B4_0 = ((float)il2cpp_codegen_subtract((float)(((float)((float)L_8))), (float)L_9));
		if ((((float)L_10) == ((float)(-1.0f))))
		{
			G_B5_0 = ((float)il2cpp_codegen_subtract((float)(((float)((float)L_8))), (float)L_9));
			goto IL_0054;
		}
	}
	{
		float L_11 = __this->get_currentDuration_0();
		G_B6_0 = L_11;
		G_B6_1 = G_B4_0;
		goto IL_005b;
	}

IL_0054:
	{
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_12 = ___playable0;
		double L_13 = PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75(L_12, /*hidden argument*/PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_RuntimeMethod_var);
		G_B6_0 = (((float)((float)L_13)));
		G_B6_1 = G_B5_0;
	}

IL_005b:
	{
		V_0 = G_B6_0;
		// return currentTime % maxDuration / maxDuration;
		float L_14 = V_0;
		float L_15 = V_0;
		return ((float)((float)(fmodf(G_B6_1, L_14))/(float)L_15));
	}
}
// System.Single AkEventPlayableBehavior::SeekToTime(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float AkEventPlayableBehavior_SeekToTime_mD813E49C24A8D301C8C2100D162AE54F781E14EA (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventPlayableBehavior_SeekToTime_mD813E49C24A8D301C8C2100D162AE54F781E14EA_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	{
		// var proportionalTime = GetProportionalTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		float L_1 = AkEventPlayableBehavior_GetProportionalTime_m55D607F02942EA64628CB143502ADEE5AA6C5E38(__this, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		// if (proportionalTime >= 1f) 
		float L_2 = V_0;
		if ((!(((float)L_2) >= ((float)(1.0f)))))
		{
			goto IL_0016;
		}
	}
	{
		// return 1f;
		return (1.0f);
	}

IL_0016:
	{
		// if (eventIsPlaying)
		bool L_3 = __this->get_eventIsPlaying_2();
		if (!L_3)
		{
			goto IL_0036;
		}
	}
	{
		// AkSoundEngine.SeekOnEvent(akEvent.Id, eventObject, proportionalTime);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_4 = __this->get_akEvent_9();
		NullCheck(L_4);
		uint32_t L_5 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(L_4, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_6 = __this->get_eventObject_18();
		float L_7 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		AkSoundEngine_SeekOnEvent_m5ABF68DD7A2149E6D7D4AE61D2F597E0B1F60574(L_5, L_6, L_7, /*hidden argument*/NULL);
	}

IL_0036:
	{
		// return proportionalTime;
		float L_8 = V_0;
		return L_8;
	}
}
// System.Void AkEventPlayableBehavior::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventPlayableBehavior__ctor_m4636B3DE7B6568A8565C0AA48C3850BA287F697A (AkEventPlayableBehavior_t7B8204B8D973315FF5BBA980EE9BE08A504C4384 * __this, const RuntimeMethod* method)
{
	{
		// private float currentDuration = -1f;
		__this->set_currentDuration_0((-1.0f));
		// private float currentDurationProportion = 1f;
		__this->set_currentDurationProportion_1((1.0f));
		PlayableBehaviour__ctor_mE96A877D927BEEC8C9368A0673FEAD77A78C35EE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Playables.Playable AkEventTrack::CreateTrackMixer(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  AkEventTrack_CreateTrackMixer_m9FBEA3F95D5DBEB8DFCCD2BEA9E03BF61EACAF2E (AkEventTrack_t6030D1051D1ACA190784CDB5D4C0461578F9E226 * __this, PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___go1, int32_t ___inputCount2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventTrack_CreateTrackMixer_m9FBEA3F95D5DBEB8DFCCD2BEA9E03BF61EACAF2E_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  V_0;
	memset((&V_0), 0, sizeof(V_0));
	RuntimeObject* V_1 = NULL;
	TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * V_2 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		// var playable = UnityEngine.Playables.ScriptPlayable<AkEventPlayableBehavior>.Create(graph);
		PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  L_0 = ___graph0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_il2cpp_TypeInfo_var);
		ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  L_1 = ScriptPlayable_1_Create_m7A54D906486B8C92680D138B9DB80F4BF06D95FF(L_0, 0, /*hidden argument*/ScriptPlayable_1_Create_m7A54D906486B8C92680D138B9DB80F4BF06D95FF_RuntimeMethod_var);
		V_0 = L_1;
		// UnityEngine.Playables.PlayableExtensions.SetInputCount(playable, inputCount);
		ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  L_2 = V_0;
		int32_t L_3 = ___inputCount2;
		PlayableExtensions_SetInputCount_TisScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_mA8E2E4D605D78423DB070AC3DEAD58FF1EC81768(L_2, L_3, /*hidden argument*/PlayableExtensions_SetInputCount_TisScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_mA8E2E4D605D78423DB070AC3DEAD58FF1EC81768_RuntimeMethod_var);
		// var clips = GetClips();
		RuntimeObject* L_4 = TrackAsset_GetClips_m2A53471D61EE6C84F42BE83D0E689691382FA172(__this, /*hidden argument*/NULL);
		// foreach (var clip in clips)
		NullCheck(L_4);
		RuntimeObject* L_5 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TimelineClip>::GetEnumerator() */, IEnumerable_1_tF659A953244FBB8F81B6A4F9CD67286607C3FD51_il2cpp_TypeInfo_var, L_4);
		V_1 = L_5;
	}

IL_001b:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0035;
		}

IL_001d:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_6 = V_1;
			NullCheck(L_6);
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_7 = InterfaceFuncInvoker0< TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<UnityEngine.Timeline.TimelineClip>::get_Current() */, IEnumerator_1_t4589C691232BC39AA49B633323A50B6AE60479C0_il2cpp_TypeInfo_var, L_6);
			V_2 = L_7;
			// var akEventPlayable = clip.asset as AkEventPlayable;
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_8 = V_2;
			NullCheck(L_8);
			Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * L_9 = TimelineClip_get_asset_mCF4C0F2153BF18362958432960C87A24B5534245_inline(L_8, /*hidden argument*/NULL);
			// akEventPlayable.owningClip = clip;
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_10 = V_2;
			NullCheck(((AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA *)IsInstClass((RuntimeObject*)L_9, AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA_il2cpp_TypeInfo_var)));
			((AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA *)IsInstClass((RuntimeObject*)L_9, AkEventPlayable_t8291769A34A431D7169CDD8F1F6DDA58ED3745CA_il2cpp_TypeInfo_var))->set_owningClip_10(L_10);
		}

IL_0035:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_11 = V_1;
			NullCheck(L_11);
			bool L_12 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t8789118187258CC88B77AFAC6315B5AF87D3E18A_il2cpp_TypeInfo_var, L_11);
			if (L_12)
			{
				goto IL_001d;
			}
		}

IL_003d:
		{
			IL2CPP_LEAVE(0x49, FINALLY_003f);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_003f;
	}

FINALLY_003f:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_13 = V_1;
			if (!L_13)
			{
				goto IL_0048;
			}
		}

IL_0042:
		{
			RuntimeObject* L_14 = V_1;
			NullCheck(L_14);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_14);
		}

IL_0048:
		{
			IL2CPP_END_FINALLY(63)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(63)
	{
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
		IL2CPP_JUMP_TBL(0x49, IL_0049)
	}

IL_0049:
	{
		// return playable;
		ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91  L_15 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t6AF6BFCAB2B46EB5F0603D1B536F7895C63A7E91_il2cpp_TypeInfo_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_16 = ScriptPlayable_1_op_Implicit_m4A760D65CA9E71CDCBD51F5326CF756C6469A917(L_15, /*hidden argument*/ScriptPlayable_1_op_Implicit_m4A760D65CA9E71CDCBD51F5326CF756C6469A917_RuntimeMethod_var);
		return L_16;
	}
}
// System.Void AkEventTrack::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkEventTrack__ctor_m3B8FEC14B08485DE8E7CC56EACD0DEB3B6DF1293 (AkEventTrack_t6030D1051D1ACA190784CDB5D4C0461578F9E226 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkEventTrack__ctor_m3B8FEC14B08485DE8E7CC56EACD0DEB3B6DF1293_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_il2cpp_TypeInfo_var);
		TrackAsset__ctor_mB57EE24087931D858028EE79112A1FABDC95E5C6(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// AK.Wwise.RTPC AkRTPCPlayable::get_Parameter()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * AkRTPCPlayable_get_Parameter_m2D38638222BA51B7DFAF565B8694C56D379B20F3 (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC Parameter { get; set; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = __this->get_U3CParameterU3Ek__BackingField_8();
		return L_0;
	}
}
// System.Void AkRTPCPlayable::set_Parameter(AK.Wwise.RTPC)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayable_set_Parameter_m6FCF8273EB6C0879509D3D1E25E4856756D0A7E5 (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___value0, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC Parameter { get; set; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = ___value0;
		__this->set_U3CParameterU3Ek__BackingField_8(L_0);
		return;
	}
}
// UnityEngine.Timeline.TimelineClip AkRTPCPlayable::get_OwningClip()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * AkRTPCPlayable_get_OwningClip_mC1EBCD08E76059CEC0C5AD12FFE099176EFDB120 (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, const RuntimeMethod* method)
{
	{
		// public UnityEngine.Timeline.TimelineClip OwningClip { get; set; }
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_0 = __this->get_U3COwningClipU3Ek__BackingField_9();
		return L_0;
	}
}
// System.Void AkRTPCPlayable::set_OwningClip(UnityEngine.Timeline.TimelineClip)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayable_set_OwningClip_mED2FC6B983BDF1F35AB3A5D66833DDD0C5B865BB (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___value0, const RuntimeMethod* method)
{
	{
		// public UnityEngine.Timeline.TimelineClip OwningClip { get; set; }
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_0 = ___value0;
		__this->set_U3COwningClipU3Ek__BackingField_9(L_0);
		return;
	}
}
// UnityEngine.Timeline.ClipCaps AkRTPCPlayable::UnityEngine.Timeline.ITimelineClipAsset.get_clipCaps()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkRTPCPlayable_UnityEngine_Timeline_ITimelineClipAsset_get_clipCaps_m20866CCCEA5DD173525B4D7BDC217A261367F676 (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, const RuntimeMethod* method)
{
	{
		// get { return UnityEngine.Timeline.ClipCaps.Looping & UnityEngine.Timeline.ClipCaps.Extrapolation & UnityEngine.Timeline.ClipCaps.Blending; }
		return (int32_t)(0);
	}
}
// UnityEngine.Playables.Playable AkRTPCPlayable::CreatePlayable(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  AkRTPCPlayable_CreatePlayable_mCF0F3EEE8C120847335BDE55FEF0D39DE78E3101 (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___go1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkRTPCPlayable_CreatePlayable_mCF0F3EEE8C120847335BDE55FEF0D39DE78E3101_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * G_B2_0 = NULL;
	AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * G_B2_1 = NULL;
	AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * G_B1_0 = NULL;
	AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * G_B1_1 = NULL;
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * G_B3_0 = NULL;
	AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * G_B3_1 = NULL;
	AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * G_B3_2 = NULL;
	{
		// var playable = UnityEngine.Playables.ScriptPlayable<AkRTPCPlayableBehaviour>.Create(graph, template);
		PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  L_0 = ___graph0;
		AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * L_1 = __this->get_template_7();
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B_il2cpp_TypeInfo_var);
		ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  L_2 = ScriptPlayable_1_Create_mE8D356E1368B91006D6F66A1A066280BD1900F11(L_0, L_1, 0, /*hidden argument*/ScriptPlayable_1_Create_mE8D356E1368B91006D6F66A1A066280BD1900F11_RuntimeMethod_var);
		V_0 = L_2;
		// var b = playable.GetBehaviour();
		AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * L_3 = ScriptPlayable_1_GetBehaviour_m6C5AA4AF673B74C88F047C8A555F75D2C172539B((ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B *)(&V_0), /*hidden argument*/ScriptPlayable_1_GetBehaviour_m6C5AA4AF673B74C88F047C8A555F75D2C172539B_RuntimeMethod_var);
		// b.overrideTrackObject = overrideTrackObject;
		AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * L_4 = L_3;
		bool L_5 = __this->get_overrideTrackObject_4();
		NullCheck(L_4);
		AkRTPCPlayableBehaviour_set_overrideTrackObject_m8DF38D0A0F763DD5B549E2AAC92EE04614ACC73B_inline(L_4, L_5, /*hidden argument*/NULL);
		// b.setRTPCGlobally = setRTPCGlobally;
		AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * L_6 = L_4;
		bool L_7 = __this->get_setRTPCGlobally_6();
		NullCheck(L_6);
		AkRTPCPlayableBehaviour_set_setRTPCGlobally_mD76260F7F2F1F5E2372CE49E4FE26FDCCFE631F7_inline(L_6, L_7, /*hidden argument*/NULL);
		// b.rtpcObject = overrideTrackObject ? RTPCObject.Resolve(graph.GetResolver()) : go;
		AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * L_8 = L_6;
		bool L_9 = __this->get_overrideTrackObject_4();
		G_B1_0 = L_8;
		G_B1_1 = L_8;
		if (L_9)
		{
			G_B2_0 = L_8;
			G_B2_1 = L_8;
			goto IL_0039;
		}
	}
	{
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_10 = ___go1;
		G_B3_0 = L_10;
		G_B3_1 = G_B1_0;
		G_B3_2 = G_B1_1;
		goto IL_004b;
	}

IL_0039:
	{
		ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944 * L_11 = __this->get_address_of_RTPCObject_5();
		RuntimeObject* L_12 = PlayableGraph_GetResolver_m52F92B131B65F7412D220BB853C562C5983E884E((PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA *)(&___graph0), /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_13 = ExposedReference_1_Resolve_m9FB7DD08C2FC3CA91FB22B8FD26763647838966B((ExposedReference_1_t3693F23049BA00F20E2D8485D309C92C2DC84944 *)L_11, L_12, /*hidden argument*/ExposedReference_1_Resolve_m9FB7DD08C2FC3CA91FB22B8FD26763647838966B_RuntimeMethod_var);
		G_B3_0 = L_13;
		G_B3_1 = G_B2_0;
		G_B3_2 = G_B2_1;
	}

IL_004b:
	{
		NullCheck(G_B3_1);
		AkRTPCPlayableBehaviour_set_rtpcObject_m064CC1ADCDF87B23D01249F73FE85704F502BA34_inline(G_B3_1, G_B3_0, /*hidden argument*/NULL);
		// b.parameter = Parameter;
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_14 = AkRTPCPlayable_get_Parameter_m2D38638222BA51B7DFAF565B8694C56D379B20F3_inline(__this, /*hidden argument*/NULL);
		NullCheck(G_B3_2);
		AkRTPCPlayableBehaviour_set_parameter_m6915EF2CBEE92F68DDA1126FC809432AAB995F7B_inline(G_B3_2, L_14, /*hidden argument*/NULL);
		// return playable;
		ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  L_15 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B_il2cpp_TypeInfo_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_16 = ScriptPlayable_1_op_Implicit_m21D4A99D0E874E3E359EA0D880D8109296AFF222(L_15, /*hidden argument*/ScriptPlayable_1_op_Implicit_m21D4A99D0E874E3E359EA0D880D8109296AFF222_RuntimeMethod_var);
		return L_16;
	}
}
// System.Void AkRTPCPlayable::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayable__ctor_m19990F03A3EADF7A8113EA3EC4FA762E0593664F (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkRTPCPlayable__ctor_m19990F03A3EADF7A8113EA3EC4FA762E0593664F_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public AkRTPCPlayableBehaviour template = new AkRTPCPlayableBehaviour();
		AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * L_0 = (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 *)il2cpp_codegen_object_new(AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075_il2cpp_TypeInfo_var);
		AkRTPCPlayableBehaviour__ctor_m175798E277AC3BD3144B12EF06F4EC6B8217A16A(L_0, /*hidden argument*/NULL);
		__this->set_template_7(L_0);
		PlayableAsset__ctor_m669F459CFACFE65873346E428F206C457B488167(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkRTPCPlayableBehaviour::set_setRTPCGlobally(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_setRTPCGlobally_mD76260F7F2F1F5E2372CE49E4FE26FDCCFE631F7 (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// public bool setRTPCGlobally { set; private get; }
		bool L_0 = ___value0;
		__this->set_U3CsetRTPCGloballyU3Ek__BackingField_1(L_0);
		return;
	}
}
// System.Boolean AkRTPCPlayableBehaviour::get_setRTPCGlobally()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkRTPCPlayableBehaviour_get_setRTPCGlobally_mBF723B975C206CF59964725F4E2D887FA4C96C95 (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method)
{
	{
		// public bool setRTPCGlobally { set; private get; }
		bool L_0 = __this->get_U3CsetRTPCGloballyU3Ek__BackingField_1();
		return L_0;
	}
}
// System.Void AkRTPCPlayableBehaviour::set_overrideTrackObject(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_overrideTrackObject_m8DF38D0A0F763DD5B549E2AAC92EE04614ACC73B (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// public bool overrideTrackObject { set; private get; }
		bool L_0 = ___value0;
		__this->set_U3CoverrideTrackObjectU3Ek__BackingField_2(L_0);
		return;
	}
}
// System.Boolean AkRTPCPlayableBehaviour::get_overrideTrackObject()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkRTPCPlayableBehaviour_get_overrideTrackObject_mBCDF4A0A2FA5ED107088104035AC259CD94615A2 (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method)
{
	{
		// public bool overrideTrackObject { set; private get; }
		bool L_0 = __this->get_U3CoverrideTrackObjectU3Ek__BackingField_2();
		return L_0;
	}
}
// System.Void AkRTPCPlayableBehaviour::set_rtpcObject(UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_rtpcObject_m064CC1ADCDF87B23D01249F73FE85704F502BA34 (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___value0, const RuntimeMethod* method)
{
	{
		// public UnityEngine.GameObject rtpcObject { set; private get; }
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_0 = ___value0;
		__this->set_U3CrtpcObjectU3Ek__BackingField_3(L_0);
		return;
	}
}
// UnityEngine.GameObject AkRTPCPlayableBehaviour::get_rtpcObject()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * AkRTPCPlayableBehaviour_get_rtpcObject_mF5DAB9C945515A7D7FE3A9743EC5A68851149359 (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method)
{
	{
		// public UnityEngine.GameObject rtpcObject { set; private get; }
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_0 = __this->get_U3CrtpcObjectU3Ek__BackingField_3();
		return L_0;
	}
}
// System.Void AkRTPCPlayableBehaviour::set_parameter(AK.Wwise.RTPC)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_parameter_m6915EF2CBEE92F68DDA1126FC809432AAB995F7B (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___value0, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC parameter { set; private get; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = ___value0;
		__this->set_U3CparameterU3Ek__BackingField_4(L_0);
		return;
	}
}
// AK.Wwise.RTPC AkRTPCPlayableBehaviour::get_parameter()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * AkRTPCPlayableBehaviour_get_parameter_m186376F0D552C0754F21097D49C0E4C81546892B (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC parameter { set; private get; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = __this->get_U3CparameterU3Ek__BackingField_4();
		return L_0;
	}
}
// System.Void AkRTPCPlayableBehaviour::ProcessFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_ProcessFrame_m59978992305F269AB8ABAC94C30FD285EDF24F79 (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, RuntimeObject * ___playerData2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkRTPCPlayableBehaviour_ProcessFrame_m59978992305F269AB8ABAC94C30FD285EDF24F79_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * V_0 = NULL;
	{
		// if (parameter != null)
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = AkRTPCPlayableBehaviour_get_parameter_m186376F0D552C0754F21097D49C0E4C81546892B_inline(__this, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0067;
		}
	}
	{
		// if (!overrideTrackObject)
		bool L_1 = AkRTPCPlayableBehaviour_get_overrideTrackObject_mBCDF4A0A2FA5ED107088104035AC259CD94615A2_inline(__this, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_0027;
		}
	}
	{
		// var obj = playerData as UnityEngine.GameObject;
		RuntimeObject * L_2 = ___playerData2;
		V_0 = ((GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F *)IsInstSealed((RuntimeObject*)L_2, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F_il2cpp_TypeInfo_var));
		// if (obj != null)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_3 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_4 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_3, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_4)
		{
			goto IL_0027;
		}
	}
	{
		// rtpcObject = obj;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_5 = V_0;
		AkRTPCPlayableBehaviour_set_rtpcObject_m064CC1ADCDF87B23D01249F73FE85704F502BA34_inline(__this, L_5, /*hidden argument*/NULL);
	}

IL_0027:
	{
		// if (setRTPCGlobally || rtpcObject == null)
		bool L_6 = AkRTPCPlayableBehaviour_get_setRTPCGlobally_mBF723B975C206CF59964725F4E2D887FA4C96C95_inline(__this, /*hidden argument*/NULL);
		if (L_6)
		{
			goto IL_003d;
		}
	}
	{
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_7 = AkRTPCPlayableBehaviour_get_rtpcObject_mF5DAB9C945515A7D7FE3A9743EC5A68851149359_inline(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_8 = Object_op_Equality_mBC2401774F3BE33E8CF6F0A8148E66C95D6CFF1C(L_7, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_0050;
		}
	}

IL_003d:
	{
		// parameter.SetGlobalValue(RTPCValue);
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_9 = AkRTPCPlayableBehaviour_get_parameter_m186376F0D552C0754F21097D49C0E4C81546892B_inline(__this, /*hidden argument*/NULL);
		float L_10 = __this->get_RTPCValue_0();
		NullCheck(L_9);
		RTPC_SetGlobalValue_mE95A5B940C8101349FA64E225E3D08233871C505(L_9, L_10, /*hidden argument*/NULL);
		goto IL_0067;
	}

IL_0050:
	{
		// parameter.SetValue(rtpcObject, RTPCValue);
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_11 = AkRTPCPlayableBehaviour_get_parameter_m186376F0D552C0754F21097D49C0E4C81546892B_inline(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_12 = AkRTPCPlayableBehaviour_get_rtpcObject_mF5DAB9C945515A7D7FE3A9743EC5A68851149359_inline(__this, /*hidden argument*/NULL);
		float L_13 = __this->get_RTPCValue_0();
		NullCheck(L_11);
		RTPC_SetValue_m1C344467FDED1786C71D410DBFCD5D03DCCD9AD5(L_11, L_12, L_13, /*hidden argument*/NULL);
	}

IL_0067:
	{
		// base.ProcessFrame(playable, info, playerData);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_14 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_15 = ___info1;
		RuntimeObject * L_16 = ___playerData2;
		PlayableBehaviour_ProcessFrame_m32F9B265BB54D1A3A290E2709FDD0B873360B25A(__this, L_14, L_15, L_16, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void AkRTPCPlayableBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour__ctor_m175798E277AC3BD3144B12EF06F4EC6B8217A16A (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method)
{
	{
		PlayableBehaviour__ctor_mE96A877D927BEEC8C9368A0673FEAD77A78C35EE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Playables.Playable AkRTPCTrack::CreateTrackMixer(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  AkRTPCTrack_CreateTrackMixer_m4B759F47B57011D27ACDF2180591860207495701 (AkRTPCTrack_t7AED5E0856187915E29DFFB53DE919F7EC9CFB74 * __this, PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___go1, int32_t ___inputCount2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkRTPCTrack_CreateTrackMixer_m4B759F47B57011D27ACDF2180591860207495701_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// var playable = UnityEngine.Playables.ScriptPlayable<AkRTPCPlayableBehaviour>.Create(graph, inputCount);
		PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  L_0 = ___graph0;
		int32_t L_1 = ___inputCount2;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B_il2cpp_TypeInfo_var);
		ScriptPlayable_1_t726E9E665A4A3EABB415192E1416FD25CD77359B  L_2 = ScriptPlayable_1_Create_mC5C205146F9478E15CFE24C9D68FB30F6779D7C8(L_0, L_1, /*hidden argument*/ScriptPlayable_1_Create_mC5C205146F9478E15CFE24C9D68FB30F6779D7C8_RuntimeMethod_var);
		// setPlayableProperties();
		AkRTPCTrack_setPlayableProperties_mED078171919EA44228E367042940ACA6DE9A69EF(__this, /*hidden argument*/NULL);
		// return playable;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_3 = ScriptPlayable_1_op_Implicit_m21D4A99D0E874E3E359EA0D880D8109296AFF222(L_2, /*hidden argument*/ScriptPlayable_1_op_Implicit_m21D4A99D0E874E3E359EA0D880D8109296AFF222_RuntimeMethod_var);
		return L_3;
	}
}
// System.Void AkRTPCTrack::setPlayableProperties()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCTrack_setPlayableProperties_mED078171919EA44228E367042940ACA6DE9A69EF (AkRTPCTrack_t7AED5E0856187915E29DFFB53DE919F7EC9CFB74 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkRTPCTrack_setPlayableProperties_mED078171919EA44228E367042940ACA6DE9A69EF_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * V_1 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		// var clips = GetClips();
		RuntimeObject* L_0 = TrackAsset_GetClips_m2A53471D61EE6C84F42BE83D0E689691382FA172(__this, /*hidden argument*/NULL);
		// foreach (var clip in clips)
		NullCheck(L_0);
		RuntimeObject* L_1 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TimelineClip>::GetEnumerator() */, IEnumerable_1_tF659A953244FBB8F81B6A4F9CD67286607C3FD51_il2cpp_TypeInfo_var, L_0);
		V_0 = L_1;
	}

IL_000c:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0032;
		}

IL_000e:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_2 = V_0;
			NullCheck(L_2);
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_3 = InterfaceFuncInvoker0< TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<UnityEngine.Timeline.TimelineClip>::get_Current() */, IEnumerator_1_t4589C691232BC39AA49B633323A50B6AE60479C0_il2cpp_TypeInfo_var, L_2);
			V_1 = L_3;
			// var clipPlayable = (AkRTPCPlayable) clip.asset;
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_4 = V_1;
			NullCheck(L_4);
			Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * L_5 = TimelineClip_get_asset_mCF4C0F2153BF18362958432960C87A24B5534245_inline(L_4, /*hidden argument*/NULL);
			// clipPlayable.Parameter = Parameter;
			AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * L_6 = ((AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C *)CastclassClass((RuntimeObject*)L_5, AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C_il2cpp_TypeInfo_var));
			RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_7 = __this->get_Parameter_28();
			NullCheck(L_6);
			AkRTPCPlayable_set_Parameter_m6FCF8273EB6C0879509D3D1E25E4856756D0A7E5_inline(L_6, L_7, /*hidden argument*/NULL);
			// clipPlayable.OwningClip = clip;
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_8 = V_1;
			NullCheck(L_6);
			AkRTPCPlayable_set_OwningClip_mED2FC6B983BDF1F35AB3A5D66833DDD0C5B865BB_inline(L_6, L_8, /*hidden argument*/NULL);
		}

IL_0032:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_9 = V_0;
			NullCheck(L_9);
			bool L_10 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t8789118187258CC88B77AFAC6315B5AF87D3E18A_il2cpp_TypeInfo_var, L_9);
			if (L_10)
			{
				goto IL_000e;
			}
		}

IL_003a:
		{
			IL2CPP_LEAVE(0x46, FINALLY_003c);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_003c;
	}

FINALLY_003c:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_11 = V_0;
			if (!L_11)
			{
				goto IL_0045;
			}
		}

IL_003f:
		{
			RuntimeObject* L_12 = V_0;
			NullCheck(L_12);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_12);
		}

IL_0045:
		{
			IL2CPP_END_FINALLY(60)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(60)
	{
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
		IL2CPP_JUMP_TBL(0x46, IL_0046)
	}

IL_0046:
	{
		// }
		return;
	}
}
// System.Void AkRTPCTrack::OnValidate()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCTrack_OnValidate_m77A94880E80C5989DE497BA9C41D09E8F2E65B22 (AkRTPCTrack_t7AED5E0856187915E29DFFB53DE919F7EC9CFB74 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkRTPCTrack_OnValidate_m77A94880E80C5989DE497BA9C41D09E8F2E65B22_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		// var clips = GetClips();
		RuntimeObject* L_0 = TrackAsset_GetClips_m2A53471D61EE6C84F42BE83D0E689691382FA172(__this, /*hidden argument*/NULL);
		// foreach (var clip in clips)
		NullCheck(L_0);
		RuntimeObject* L_1 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TimelineClip>::GetEnumerator() */, IEnumerable_1_tF659A953244FBB8F81B6A4F9CD67286607C3FD51_il2cpp_TypeInfo_var, L_0);
		V_0 = L_1;
	}

IL_000c:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0029;
		}

IL_000e:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_2 = V_0;
			NullCheck(L_2);
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_3 = InterfaceFuncInvoker0< TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<UnityEngine.Timeline.TimelineClip>::get_Current() */, IEnumerator_1_t4589C691232BC39AA49B633323A50B6AE60479C0_il2cpp_TypeInfo_var, L_2);
			// var clipPlayable = (AkRTPCPlayable) clip.asset;
			NullCheck(L_3);
			Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * L_4 = TimelineClip_get_asset_mCF4C0F2153BF18362958432960C87A24B5534245_inline(L_3, /*hidden argument*/NULL);
			// clipPlayable.Parameter = Parameter;
			RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_5 = __this->get_Parameter_28();
			NullCheck(((AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C *)CastclassClass((RuntimeObject*)L_4, AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C_il2cpp_TypeInfo_var)));
			AkRTPCPlayable_set_Parameter_m6FCF8273EB6C0879509D3D1E25E4856756D0A7E5_inline(((AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C *)CastclassClass((RuntimeObject*)L_4, AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C_il2cpp_TypeInfo_var)), L_5, /*hidden argument*/NULL);
		}

IL_0029:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_6 = V_0;
			NullCheck(L_6);
			bool L_7 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t8789118187258CC88B77AFAC6315B5AF87D3E18A_il2cpp_TypeInfo_var, L_6);
			if (L_7)
			{
				goto IL_000e;
			}
		}

IL_0031:
		{
			IL2CPP_LEAVE(0x3D, FINALLY_0033);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_0033;
	}

FINALLY_0033:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_8 = V_0;
			if (!L_8)
			{
				goto IL_003c;
			}
		}

IL_0036:
		{
			RuntimeObject* L_9 = V_0;
			NullCheck(L_9);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_9);
		}

IL_003c:
		{
			IL2CPP_END_FINALLY(51)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(51)
	{
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
		IL2CPP_JUMP_TBL(0x3D, IL_003d)
	}

IL_003d:
	{
		// }
		return;
	}
}
// System.Void AkRTPCTrack::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkRTPCTrack__ctor_mF97FB82A99F18D11D1DB8830BF885A3D98274112 (AkRTPCTrack_t7AED5E0856187915E29DFFB53DE919F7EC9CFB74 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkRTPCTrack__ctor_mF97FB82A99F18D11D1DB8830BF885A3D98274112_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_il2cpp_TypeInfo_var);
		TrackAsset__ctor_mB57EE24087931D858028EE79112A1FABDC95E5C6(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Timeline.ClipCaps AkTimelineEventPlayable::UnityEngine.Timeline.ITimelineClipAsset.get_clipCaps()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkTimelineEventPlayable_UnityEngine_Timeline_ITimelineClipAsset_get_clipCaps_m2E599264823CDF36A097F07637C2B35DB11A8B20 (AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A * __this, const RuntimeMethod* method)
{
	{
		// get { return UnityEngine.Timeline.ClipCaps.Looping | UnityEngine.Timeline.ClipCaps.Blending; }
		return (int32_t)(((int32_t)17));
	}
}
// UnityEngine.Playables.Playable AkTimelineEventPlayable::CreatePlayable(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  AkTimelineEventPlayable_CreatePlayable_m90CE33D9047496192EF851F340A65B1D55B85D1A (AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A * __this, PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___owner1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayable_CreatePlayable_m90CE33D9047496192EF851F340A65B1D55B85D1A_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  V_0;
	memset((&V_0), 0, sizeof(V_0));
	AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * V_1 = NULL;
	float V_2 = 0.0f;
	{
		// var playable = UnityEngine.Playables.ScriptPlayable<AkTimelineEventPlayableBehavior>.Create(graph);
		PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  L_0 = ___graph0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_il2cpp_TypeInfo_var);
		ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  L_1 = ScriptPlayable_1_Create_m0C1209813E5FE8A3908A07A94193CC3C6FC29756(L_0, 0, /*hidden argument*/ScriptPlayable_1_Create_m0C1209813E5FE8A3908A07A94193CC3C6FC29756_RuntimeMethod_var);
		V_0 = L_1;
		// if (akEvent == null)
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_2 = __this->get_akEvent_4();
		if (L_2)
		{
			goto IL_0017;
		}
	}
	{
		// return playable;
		ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  L_3 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_il2cpp_TypeInfo_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_4 = ScriptPlayable_1_op_Implicit_m52EBDBFDF6B21D71CEA48FB89BC92CDAF68851FD(L_3, /*hidden argument*/ScriptPlayable_1_op_Implicit_m52EBDBFDF6B21D71CEA48FB89BC92CDAF68851FD_RuntimeMethod_var);
		return L_4;
	}

IL_0017:
	{
		// var b = playable.GetBehaviour();
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_5 = ScriptPlayable_1_GetBehaviour_m4A0EE0982E042FF81F5DF187A039E63B83A90863((ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC *)(&V_0), /*hidden argument*/ScriptPlayable_1_GetBehaviour_m4A0EE0982E042FF81F5DF187A039E63B83A90863_RuntimeMethod_var);
		V_1 = L_5;
		// b.akEvent = akEvent;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_6 = V_1;
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_7 = __this->get_akEvent_4();
		NullCheck(L_6);
		L_6->set_akEvent_9(L_7);
		// b.blendInCurve = blendInCurve;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_8 = V_1;
		int32_t L_9 = __this->get_blendInCurve_5();
		NullCheck(L_8);
		L_8->set_blendInCurve_16(L_9);
		// b.blendOutCurve = blendOutCurve;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_10 = V_1;
		int32_t L_11 = __this->get_blendOutCurve_6();
		NullCheck(L_10);
		L_10->set_blendOutCurve_17(L_11);
		// if (owningClip != null)
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_12 = __this->get_owningClip_9();
		if (!L_12)
		{
			goto IL_0095;
		}
	}
	{
		// b.easeInDuration = (float)owningClip.easeInDuration;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_13 = V_1;
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_14 = __this->get_owningClip_9();
		NullCheck(L_14);
		double L_15 = TimelineClip_get_easeInDuration_m86C28CFFB8EB583729B28F952FEACC3F28A24B08(L_14, /*hidden argument*/NULL);
		NullCheck(L_13);
		L_13->set_easeInDuration_14((((float)((float)L_15))));
		// b.easeOutDuration = (float)owningClip.easeOutDuration;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_16 = V_1;
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_17 = __this->get_owningClip_9();
		NullCheck(L_17);
		double L_18 = TimelineClip_get_easeOutDuration_m7635A403CDFBDF310136765D38E894CACF775980(L_17, /*hidden argument*/NULL);
		NullCheck(L_16);
		L_16->set_easeOutDuration_15((((float)((float)L_18))));
		// b.blendInDuration = (float)owningClip.blendInDuration;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_19 = V_1;
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_20 = __this->get_owningClip_9();
		NullCheck(L_20);
		double L_21 = TimelineClip_get_blendInDuration_m9BAD5A16030AC49404E40CD8188BDB1D6C886CAF(L_20, /*hidden argument*/NULL);
		NullCheck(L_19);
		L_19->set_blendInDuration_12((((float)((float)L_21))));
		// b.blendOutDuration = (float)owningClip.blendOutDuration;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_22 = V_1;
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_23 = __this->get_owningClip_9();
		NullCheck(L_23);
		double L_24 = TimelineClip_get_blendOutDuration_mCCD5E4EFD9381253CF3146BD01173251FA2266BC(L_23, /*hidden argument*/NULL);
		NullCheck(L_22);
		L_22->set_blendOutDuration_13((((float)((float)L_24))));
		// }
		goto IL_00bb;
	}

IL_0095:
	{
		// b.easeInDuration = b.easeOutDuration = b.blendInDuration = b.blendOutDuration = 0;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_25 = V_1;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_26 = V_1;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_27 = V_1;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_28 = V_1;
		float L_29 = (0.0f);
		V_2 = L_29;
		NullCheck(L_28);
		L_28->set_blendOutDuration_13(L_29);
		float L_30 = V_2;
		float L_31 = L_30;
		V_2 = L_31;
		NullCheck(L_27);
		L_27->set_blendInDuration_12(L_31);
		float L_32 = V_2;
		float L_33 = L_32;
		V_2 = L_33;
		NullCheck(L_26);
		L_26->set_easeOutDuration_15(L_33);
		float L_34 = V_2;
		NullCheck(L_25);
		L_25->set_easeInDuration_14(L_34);
	}

IL_00bb:
	{
		// b.retriggerEvent = retriggerEvent;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_35 = V_1;
		bool L_36 = __this->get_retriggerEvent_10();
		NullCheck(L_35);
		L_35->set_retriggerEvent_19(L_36);
		// b.StopEventAtClipEnd = StopEventAtClipEnd;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_37 = V_1;
		bool L_38 = __this->get_StopEventAtClipEnd_12();
		NullCheck(L_37);
		L_37->set_StopEventAtClipEnd_21(L_38);
		// b.eventObject = owner;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_39 = V_1;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_40 = ___owner1;
		NullCheck(L_39);
		L_39->set_eventObject_18(L_40);
		// b.eventDurationMin = eventDurationMin;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_41 = V_1;
		float L_42 = __this->get_eventDurationMin_8();
		NullCheck(L_41);
		L_41->set_eventDurationMin_11(L_42);
		// b.eventDurationMax = eventDurationMax;
		AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * L_43 = V_1;
		float L_44 = __this->get_eventDurationMax_7();
		NullCheck(L_43);
		L_43->set_eventDurationMax_10(L_44);
		// return playable;
		ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  L_45 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_il2cpp_TypeInfo_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_46 = ScriptPlayable_1_op_Implicit_m52EBDBFDF6B21D71CEA48FB89BC92CDAF68851FD(L_45, /*hidden argument*/ScriptPlayable_1_op_Implicit_m52EBDBFDF6B21D71CEA48FB89BC92CDAF68851FD_RuntimeMethod_var);
		return L_46;
	}
}
// System.Void AkTimelineEventPlayable::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayable__ctor_m4C710B647727EFEB81066AFC5B15D93AB17C5029 (AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayable__ctor_m4C710B647727EFEB81066AFC5B15D93AB17C5029_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public AK.Wwise.Event akEvent = new AK.Wwise.Event();
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_0 = (Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F *)il2cpp_codegen_object_new(Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F_il2cpp_TypeInfo_var);
		Event__ctor_mB99941177C1FF4FE4FDDD4185CB0C25681F4815D(L_0, /*hidden argument*/NULL);
		__this->set_akEvent_4(L_0);
		// private AkCurveInterpolation blendInCurve = AkCurveInterpolation.AkCurveInterpolation_Linear;
		__this->set_blendInCurve_5(4);
		// private AkCurveInterpolation blendOutCurve = AkCurveInterpolation.AkCurveInterpolation_Linear;
		__this->set_blendOutCurve_6(4);
		// public float eventDurationMax = -1f;
		__this->set_eventDurationMax_7((-1.0f));
		// public float eventDurationMin = -1f;
		__this->set_eventDurationMin_8((-1.0f));
		// public bool UseWwiseEventDuration = true;
		__this->set_UseWwiseEventDuration_11((bool)1);
		// private bool StopEventAtClipEnd = true;
		__this->set_StopEventAtClipEnd_12((bool)1);
		PlayableAsset__ctor_m669F459CFACFE65873346E428F206C457B488167(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkTimelineEventPlayableBehavior::CallbackHandler(System.Object,AkCallbackType,AkCallbackInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_CallbackHandler_mB867C4F333A72B80AB7488785F419D0D518B9357 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, RuntimeObject * ___in_cookie0, int32_t ___in_type1, AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979 * ___in_info2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_CallbackHandler_mB867C4F333A72B80AB7488785F419D0D518B9357_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	float V_1 = 0.0f;
	{
		// if (in_type == AkCallbackType.AK_EndOfEvent)
		int32_t L_0 = ___in_type1;
		if ((!(((uint32_t)L_0) == ((uint32_t)1))))
		{
			goto IL_001e;
		}
	}
	{
		// eventIsPlaying = fadeinTriggered = fadeoutTriggered = false;
		int32_t L_1 = 0;
		V_0 = (bool)L_1;
		__this->set_fadeoutTriggered_4((bool)L_1);
		bool L_2 = V_0;
		bool L_3 = L_2;
		V_0 = L_3;
		__this->set_fadeinTriggered_3(L_3);
		bool L_4 = V_0;
		__this->set_eventIsPlaying_2(L_4);
		// }
		return;
	}

IL_001e:
	{
		// else if (in_type == AkCallbackType.AK_Duration)
		int32_t L_5 = ___in_type1;
		if ((!(((uint32_t)L_5) == ((uint32_t)8))))
		{
			goto IL_0042;
		}
	}
	{
		// var estimatedDuration = (in_info as AkDurationCallbackInfo).fEstimatedDuration;
		AkCallbackInfo_t88F527C6BCFBDB71CCE6C8EBEC420DC207588979 * L_6 = ___in_info2;
		NullCheck(((AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25 *)IsInstClass((RuntimeObject*)L_6, AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25_il2cpp_TypeInfo_var)));
		float L_7 = AkDurationCallbackInfo_get_fEstimatedDuration_m309CD6D65AA0299C965EF62F2A598A8C50E41A3D(((AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25 *)IsInstClass((RuntimeObject*)L_6, AkDurationCallbackInfo_t1C648BBF65AC66CA84E7D45E11086C6A0964BB25_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
		V_1 = L_7;
		// currentDuration = estimatedDuration * currentDurationProportion / 1000f;
		float L_8 = V_1;
		float L_9 = __this->get_currentDurationProportion_1();
		__this->set_currentDuration_0(((float)((float)((float)il2cpp_codegen_multiply((float)L_8, (float)L_9))/(float)(1000.0f))));
	}

IL_0042:
	{
		// }
		return;
	}
}
// System.Boolean AkTimelineEventPlayableBehavior::IsScrubbing(UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkTimelineEventPlayableBehavior_IsScrubbing_mF483DA94E4F58AB10598906D95E9513A7B1A9419 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info0, const RuntimeMethod* method)
{
	{
		// return false;
		return (bool)0;
	}
}
// System.Void AkTimelineEventPlayableBehavior::PrepareFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_PrepareFrame_m673592634E907774453B9719BD41418F9D69E799 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_PrepareFrame_m673592634E907774453B9719BD41418F9D69E799_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		// base.PrepareFrame(playable, info);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_1 = ___info1;
		PlayableBehaviour_PrepareFrame_m0FC4368B39C1DBC6586E417C8505D1A8C49235E2(__this, L_0, L_1, /*hidden argument*/NULL);
		// if (akEvent == null)
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_2 = __this->get_akEvent_9();
		if (L_2)
		{
			goto IL_0011;
		}
	}
	{
		// return;
		return;
	}

IL_0011:
	{
		// var shouldPlay = ShouldPlay(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_3 = ___playable0;
		bool L_4 = AkTimelineEventPlayableBehavior_ShouldPlay_m99F0C560CBA4A34FFE51A9DF5D04D71F77557EF2(__this, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		// if (IsScrubbing(info) && shouldPlay)
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_5 = ___info1;
		bool L_6 = AkTimelineEventPlayableBehavior_IsScrubbing_mF483DA94E4F58AB10598906D95E9513A7B1A9419(__this, L_5, /*hidden argument*/NULL);
		bool L_7 = V_0;
		if (!((int32_t)((int32_t)L_6&(int32_t)L_7)))
		{
			goto IL_0050;
		}
	}
	{
		// requiredActions |= Actions.Seek;
		int32_t L_8 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_8|(int32_t)8)));
		// if (!eventIsPlaying)
		bool L_9 = __this->get_eventIsPlaying_2();
		if (L_9)
		{
			goto IL_0085;
		}
	}
	{
		// requiredActions |= Actions.Playback | Actions.DelayedStop;
		int32_t L_10 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_10|(int32_t)5)));
		// CheckForFadeInFadeOut(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_11 = ___playable0;
		AkTimelineEventPlayableBehavior_CheckForFadeInFadeOut_m0F701A1EF78E0E94A89ECAC700DF1BED77F025CD(__this, L_11, /*hidden argument*/NULL);
		// }
		return;
	}

IL_0050:
	{
		// else if (!eventIsPlaying && (requiredActions & Actions.Playback) == 0)
		bool L_12 = __this->get_eventIsPlaying_2();
		if (L_12)
		{
			goto IL_0078;
		}
	}
	{
		int32_t L_13 = __this->get_requiredActions_7();
		if (((int32_t)((int32_t)L_13&(int32_t)1)))
		{
			goto IL_0078;
		}
	}
	{
		// requiredActions |= Actions.Retrigger;
		int32_t L_14 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_14|(int32_t)2)));
		// CheckForFadeInFadeOut(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_15 = ___playable0;
		AkTimelineEventPlayableBehavior_CheckForFadeInFadeOut_m0F701A1EF78E0E94A89ECAC700DF1BED77F025CD(__this, L_15, /*hidden argument*/NULL);
		// }
		return;
	}

IL_0078:
	{
		// CheckForFadeOut(playable, UnityEngine.Playables.PlayableExtensions.GetTime(playable));
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_16 = ___playable0;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_17 = ___playable0;
		double L_18 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_17, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		AkTimelineEventPlayableBehavior_CheckForFadeOut_mE4B19F2E4539E898615CDA6CB4DD5CD5C193D316(__this, L_16, L_18, /*hidden argument*/NULL);
	}

IL_0085:
	{
		// }
		return;
	}
}
// System.Void AkTimelineEventPlayableBehavior::OnBehaviourPlay(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_OnBehaviourPlay_m0B5EFD21343FAEEEC02B561CA550EABA2CDD4F94 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, const RuntimeMethod* method)
{
	{
		// base.OnBehaviourPlay(playable, info);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_1 = ___info1;
		PlayableBehaviour_OnBehaviourPlay_m4B44CD41A9CB3EA391BCB142FA3B9A80AFAFF820(__this, L_0, L_1, /*hidden argument*/NULL);
		// if (akEvent == null)
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_2 = __this->get_akEvent_9();
		if (L_2)
		{
			goto IL_0011;
		}
	}
	{
		// return;
		return;
	}

IL_0011:
	{
		// var shouldPlay = ShouldPlay(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_3 = ___playable0;
		bool L_4 = AkTimelineEventPlayableBehavior_ShouldPlay_m99F0C560CBA4A34FFE51A9DF5D04D71F77557EF2(__this, L_3, /*hidden argument*/NULL);
		// if (!shouldPlay)
		if (L_4)
		{
			goto IL_001b;
		}
	}
	{
		// return;
		return;
	}

IL_001b:
	{
		// requiredActions |= Actions.Playback;
		int32_t L_5 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_5|(int32_t)1)));
		// if (IsScrubbing(info))
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_6 = ___info1;
		bool L_7 = AkTimelineEventPlayableBehavior_IsScrubbing_mF483DA94E4F58AB10598906D95E9513A7B1A9419(__this, L_6, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0049;
		}
	}
	{
		// wasScrubbingAndRequiresRetrigger = true;
		__this->set_wasScrubbingAndRequiresRetrigger_20((bool)1);
		// requiredActions |= Actions.DelayedStop;
		int32_t L_8 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_8|(int32_t)4)));
		// }
		goto IL_0065;
	}

IL_0049:
	{
		// else if (GetProportionalTime(playable) > alph)
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_9 = ___playable0;
		float L_10 = AkTimelineEventPlayableBehavior_GetProportionalTime_m52FBF2A2547C3263133CDA715BB870A8DD8A9D77(__this, L_9, /*hidden argument*/NULL);
		if ((!(((float)L_10) > ((float)(0.05f)))))
		{
			goto IL_0065;
		}
	}
	{
		// requiredActions |= Actions.Seek;
		int32_t L_11 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_11|(int32_t)8)));
	}

IL_0065:
	{
		// CheckForFadeInFadeOut(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_12 = ___playable0;
		AkTimelineEventPlayableBehavior_CheckForFadeInFadeOut_m0F701A1EF78E0E94A89ECAC700DF1BED77F025CD(__this, L_12, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void AkTimelineEventPlayableBehavior::OnBehaviourPause(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_OnBehaviourPause_mB53E2A02A95473167E05173659CD1AB6C5CA04CE (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_OnBehaviourPause_mB53E2A02A95473167E05173659CD1AB6C5CA04CE_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// wasScrubbingAndRequiresRetrigger = false;
		__this->set_wasScrubbingAndRequiresRetrigger_20((bool)0);
		// base.OnBehaviourPause(playable, info);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_1 = ___info1;
		PlayableBehaviour_OnBehaviourPause_mBC9C4536B30B413E248C96294F53CDABA2C1490C(__this, L_0, L_1, /*hidden argument*/NULL);
		// if (eventObject != null && akEvent != null && StopEventAtClipEnd)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_2 = __this->get_eventObject_18();
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_3 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_2, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0034;
		}
	}
	{
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_4 = __this->get_akEvent_9();
		if (!L_4)
		{
			goto IL_0034;
		}
	}
	{
		bool L_5 = __this->get_StopEventAtClipEnd_21();
		if (!L_5)
		{
			goto IL_0034;
		}
	}
	{
		// StopEvent();
		AkTimelineEventPlayableBehavior_StopEvent_m76B40E41ADA129808B8DF8D5701D69F031ED03FB(__this, 0, /*hidden argument*/NULL);
	}

IL_0034:
	{
		// }
		return;
	}
}
// System.Void AkTimelineEventPlayableBehavior::ProcessFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_ProcessFrame_m413118A62B87D79472AEF0D30856AFF663D6A4C6 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___info1, RuntimeObject * ___playerData2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_ProcessFrame_m413118A62B87D79472AEF0D30856AFF663D6A4C6_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * V_0 = NULL;
	{
		// base.ProcessFrame(playable, info, playerData);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_1 = ___info1;
		RuntimeObject * L_2 = ___playerData2;
		PlayableBehaviour_ProcessFrame_m32F9B265BB54D1A3A290E2709FDD0B873360B25A(__this, L_0, L_1, L_2, /*hidden argument*/NULL);
		// if (akEvent == null)
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_3 = __this->get_akEvent_9();
		if (L_3)
		{
			goto IL_0012;
		}
	}
	{
		// return;
		return;
	}

IL_0012:
	{
		// var obj = playerData as UnityEngine.GameObject;
		RuntimeObject * L_4 = ___playerData2;
		V_0 = ((GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F *)IsInstSealed((RuntimeObject*)L_4, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F_il2cpp_TypeInfo_var));
		// if (obj != null)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_6 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_5, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0029;
		}
	}
	{
		// eventObject = obj;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_7 = V_0;
		__this->set_eventObject_18(L_7);
	}

IL_0029:
	{
		// if (eventObject == null)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_8 = __this->get_eventObject_18();
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_9 = Object_op_Equality_mBC2401774F3BE33E8CF6F0A8148E66C95D6CFF1C(L_8, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_9)
		{
			goto IL_0038;
		}
	}
	{
		// return;
		return;
	}

IL_0038:
	{
		// if ((requiredActions & Actions.Playback) != 0)
		int32_t L_10 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_10&(int32_t)1)))
		{
			goto IL_0048;
		}
	}
	{
		// PlayEvent();
		AkTimelineEventPlayableBehavior_PlayEvent_mED0A3AE5CF58B04026B73FB2BDB43E7B0299D5CD(__this, /*hidden argument*/NULL);
	}

IL_0048:
	{
		// if ((requiredActions & Actions.Seek) != 0)
		int32_t L_11 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_11&(int32_t)8)))
		{
			goto IL_005a;
		}
	}
	{
		// SeekToTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_12 = ___playable0;
		AkTimelineEventPlayableBehavior_SeekToTime_m97F34CBA9DF79E28A393710EBE06D5EAA1C938E7(__this, L_12, /*hidden argument*/NULL);
	}

IL_005a:
	{
		// if ((retriggerEvent || wasScrubbingAndRequiresRetrigger) && (requiredActions & Actions.Retrigger) != 0)
		bool L_13 = __this->get_retriggerEvent_19();
		if (L_13)
		{
			goto IL_006a;
		}
	}
	{
		bool L_14 = __this->get_wasScrubbingAndRequiresRetrigger_20();
		if (!L_14)
		{
			goto IL_007b;
		}
	}

IL_006a:
	{
		int32_t L_15 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_15&(int32_t)2)))
		{
			goto IL_007b;
		}
	}
	{
		// RetriggerEvent(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_16 = ___playable0;
		AkTimelineEventPlayableBehavior_RetriggerEvent_m7A9B9D27455C1824DEC3921F9D0326D8B156CAE2(__this, L_16, /*hidden argument*/NULL);
	}

IL_007b:
	{
		// if ((requiredActions & Actions.DelayedStop) != 0)
		int32_t L_17 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_17&(int32_t)4)))
		{
			goto IL_008d;
		}
	}
	{
		// StopEvent(scrubPlaybackLengthMs);
		AkTimelineEventPlayableBehavior_StopEvent_m76B40E41ADA129808B8DF8D5701D69F031ED03FB(__this, ((int32_t)100), /*hidden argument*/NULL);
	}

IL_008d:
	{
		// if (!fadeinTriggered && (requiredActions & Actions.FadeIn) != 0)
		bool L_18 = __this->get_fadeinTriggered_3();
		if (L_18)
		{
			goto IL_00a7;
		}
	}
	{
		int32_t L_19 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_19&(int32_t)((int32_t)16))))
		{
			goto IL_00a7;
		}
	}
	{
		// TriggerFadeIn(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_20 = ___playable0;
		AkTimelineEventPlayableBehavior_TriggerFadeIn_mAF9E9008AD701FAD3F372AE1C3054F59A0714A56(__this, L_20, /*hidden argument*/NULL);
	}

IL_00a7:
	{
		// if (!fadeoutTriggered && (requiredActions & Actions.FadeOut) != 0)
		bool L_21 = __this->get_fadeoutTriggered_4();
		if (L_21)
		{
			goto IL_00c1;
		}
	}
	{
		int32_t L_22 = __this->get_requiredActions_7();
		if (!((int32_t)((int32_t)L_22&(int32_t)((int32_t)32))))
		{
			goto IL_00c1;
		}
	}
	{
		// TriggerFadeOut(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_23 = ___playable0;
		AkTimelineEventPlayableBehavior_TriggerFadeOut_m90EB244EBF6E02CD5C322D45BEB051356B6C31FC(__this, L_23, /*hidden argument*/NULL);
	}

IL_00c1:
	{
		// requiredActions = Actions.None;
		__this->set_requiredActions_7(0);
		// }
		return;
	}
}
// System.Boolean AkTimelineEventPlayableBehavior::ShouldPlay(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkTimelineEventPlayableBehavior_ShouldPlay_m99F0C560CBA4A34FFE51A9DF5D04D71F77557EF2 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_ShouldPlay_m99F0C560CBA4A34FFE51A9DF5D04D71F77557EF2_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	float V_1 = 0.0f;
	float G_B8_0 = 0.0f;
	{
		// var previousTime = UnityEngine.Playables.PlayableExtensions.GetPreviousTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		PlayableExtensions_GetPreviousTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_mC130F5DC9CA211F6E74092978A776E41476695DD(L_0, /*hidden argument*/PlayableExtensions_GetPreviousTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_mC130F5DC9CA211F6E74092978A776E41476695DD_RuntimeMethod_var);
		// var currentTime = UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_1 = ___playable0;
		double L_2 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_1, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		V_0 = L_2;
		// if (retriggerEvent)
		bool L_3 = __this->get_retriggerEvent_19();
		if (!L_3)
		{
			goto IL_0018;
		}
	}
	{
		// return true;
		return (bool)1;
	}

IL_0018:
	{
		// if (eventDurationMax == eventDurationMin && eventDurationMin != -1f)
		float L_4 = __this->get_eventDurationMax_10();
		float L_5 = __this->get_eventDurationMin_11();
		if ((!(((float)L_4) == ((float)L_5))))
		{
			goto IL_003e;
		}
	}
	{
		float L_6 = __this->get_eventDurationMin_11();
		if ((((float)L_6) == ((float)(-1.0f))))
		{
			goto IL_003e;
		}
	}
	{
		// return currentTime < eventDurationMax;
		double L_7 = V_0;
		float L_8 = __this->get_eventDurationMax_10();
		return (bool)((((double)L_7) < ((double)(((double)((double)L_8)))))? 1 : 0);
	}

IL_003e:
	{
		// currentTime -= previousEventStartTime;
		double L_9 = V_0;
		float L_10 = __this->get_previousEventStartTime_5();
		V_0 = ((double)il2cpp_codegen_subtract((double)L_9, (double)(((double)((double)L_10)))));
		// var maxDuration = currentDuration == -1f ? (float)UnityEngine.Playables.PlayableExtensions.GetDuration(playable) : currentDuration;
		float L_11 = __this->get_currentDuration_0();
		if ((((float)L_11) == ((float)(-1.0f))))
		{
			goto IL_005d;
		}
	}
	{
		float L_12 = __this->get_currentDuration_0();
		G_B8_0 = L_12;
		goto IL_0064;
	}

IL_005d:
	{
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_13 = ___playable0;
		double L_14 = PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75(L_13, /*hidden argument*/PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_RuntimeMethod_var);
		G_B8_0 = (((float)((float)L_14)));
	}

IL_0064:
	{
		V_1 = G_B8_0;
		// return currentTime < maxDuration;
		double L_15 = V_0;
		float L_16 = V_1;
		return (bool)((((double)L_15) < ((double)(((double)((double)L_16)))))? 1 : 0);
	}
}
// System.Void AkTimelineEventPlayableBehavior::CheckForFadeInFadeOut(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_CheckForFadeInFadeOut_m0F701A1EF78E0E94A89ECAC700DF1BED77F025CD (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_CheckForFadeInFadeOut_m0F701A1EF78E0E94A89ECAC700DF1BED77F025CD_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	{
		// var currentClipTime = UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		double L_1 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_0, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		V_0 = L_1;
		// if (blendInDuration > currentClipTime || easeInDuration > currentClipTime)
		float L_2 = __this->get_blendInDuration_12();
		double L_3 = V_0;
		if ((((double)(((double)((double)L_2)))) > ((double)L_3)))
		{
			goto IL_001b;
		}
	}
	{
		float L_4 = __this->get_easeInDuration_14();
		double L_5 = V_0;
		if ((!(((double)(((double)((double)L_4)))) > ((double)L_5))))
		{
			goto IL_002a;
		}
	}

IL_001b:
	{
		// requiredActions |= Actions.FadeIn;
		int32_t L_6 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_6|(int32_t)((int32_t)16))));
	}

IL_002a:
	{
		// CheckForFadeOut(playable, currentClipTime);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_7 = ___playable0;
		double L_8 = V_0;
		AkTimelineEventPlayableBehavior_CheckForFadeOut_mE4B19F2E4539E898615CDA6CB4DD5CD5C193D316(__this, L_7, L_8, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void AkTimelineEventPlayableBehavior::CheckForFadeOut(UnityEngine.Playables.Playable,System.Double)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_CheckForFadeOut_mE4B19F2E4539E898615CDA6CB4DD5CD5C193D316 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, double ___currentClipTime1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_CheckForFadeOut_mE4B19F2E4539E898615CDA6CB4DD5CD5C193D316_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	{
		// var timeLeft = UnityEngine.Playables.PlayableExtensions.GetDuration(playable) - currentClipTime;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		double L_1 = PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75(L_0, /*hidden argument*/PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_RuntimeMethod_var);
		double L_2 = ___currentClipTime1;
		V_0 = ((double)il2cpp_codegen_subtract((double)L_1, (double)L_2));
		// if (blendOutDuration >= timeLeft || easeOutDuration >= timeLeft)
		float L_3 = __this->get_blendOutDuration_13();
		double L_4 = V_0;
		if ((((double)(((double)((double)L_3)))) >= ((double)L_4)))
		{
			goto IL_001d;
		}
	}
	{
		float L_5 = __this->get_easeOutDuration_15();
		double L_6 = V_0;
		if ((!(((double)(((double)((double)L_5)))) >= ((double)L_6))))
		{
			goto IL_002c;
		}
	}

IL_001d:
	{
		// requiredActions |= Actions.FadeOut;
		int32_t L_7 = __this->get_requiredActions_7();
		__this->set_requiredActions_7(((int32_t)((int32_t)L_7|(int32_t)((int32_t)32))));
	}

IL_002c:
	{
		// }
		return;
	}
}
// System.Void AkTimelineEventPlayableBehavior::TriggerFadeIn(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_TriggerFadeIn_mAF9E9008AD701FAD3F372AE1C3054F59A0714A56 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_TriggerFadeIn_mAF9E9008AD701FAD3F372AE1C3054F59A0714A56_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	double V_1 = 0.0;
	{
		// var currentClipTime = UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		double L_1 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_0, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		V_0 = L_1;
		// var fadeDuration = UnityEngine.Mathf.Max(easeInDuration, blendInDuration) - currentClipTime;
		float L_2 = __this->get_easeInDuration_14();
		float L_3 = __this->get_blendInDuration_12();
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_tFBDE6467D269BFE410605C7D806FD9991D4A89CB_il2cpp_TypeInfo_var);
		float L_4 = Mathf_Max_m670AE0EC1B09ED1A56FF9606B0F954670319CB65(L_2, L_3, /*hidden argument*/NULL);
		double L_5 = V_0;
		V_1 = ((double)il2cpp_codegen_subtract((double)(((double)((double)L_4))), (double)L_5));
		// if (fadeDuration > 0)
		double L_6 = V_1;
		if ((!(((double)L_6) > ((double)(0.0)))))
		{
			goto IL_006c;
		}
	}
	{
		// fadeinTriggered = true;
		__this->set_fadeinTriggered_3((bool)1);
		// akEvent.ExecuteAction(eventObject, AkActionOnEventType.AkActionOnEventType_Pause, 0, blendOutCurve);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_7 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_8 = __this->get_eventObject_18();
		int32_t L_9 = __this->get_blendOutCurve_17();
		NullCheck(L_7);
		Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE(L_7, L_8, 1, 0, L_9, /*hidden argument*/NULL);
		// akEvent.ExecuteAction(eventObject, AkActionOnEventType.AkActionOnEventType_Resume, (int)(fadeDuration * 1000), blendInCurve);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_10 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_11 = __this->get_eventObject_18();
		double L_12 = V_1;
		int32_t L_13 = __this->get_blendInCurve_16();
		NullCheck(L_10);
		Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE(L_10, L_11, 2, (((int32_t)((int32_t)((double)il2cpp_codegen_multiply((double)L_12, (double)(1000.0)))))), L_13, /*hidden argument*/NULL);
	}

IL_006c:
	{
		// }
		return;
	}
}
// System.Void AkTimelineEventPlayableBehavior::TriggerFadeOut(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_TriggerFadeOut_m90EB244EBF6E02CD5C322D45BEB051356B6C31FC (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_TriggerFadeOut_m90EB244EBF6E02CD5C322D45BEB051356B6C31FC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	{
		// fadeoutTriggered = true;
		__this->set_fadeoutTriggered_4((bool)1);
		// var fadeDuration = UnityEngine.Playables.PlayableExtensions.GetDuration(playable) - UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		double L_1 = PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75(L_0, /*hidden argument*/PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_RuntimeMethod_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_2 = ___playable0;
		double L_3 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_2, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		V_0 = ((double)il2cpp_codegen_subtract((double)L_1, (double)L_3));
		// akEvent.ExecuteAction(eventObject, AkActionOnEventType.AkActionOnEventType_Stop, (int)(fadeDuration * 1000), blendOutCurve);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_4 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_5 = __this->get_eventObject_18();
		double L_6 = V_0;
		int32_t L_7 = __this->get_blendOutCurve_17();
		NullCheck(L_4);
		Event_ExecuteAction_mC4029F2DF76F1A50119FEE527A242D03068761AE(L_4, L_5, 0, (((int32_t)((int32_t)((double)il2cpp_codegen_multiply((double)L_6, (double)(1000.0)))))), L_7, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Void AkTimelineEventPlayableBehavior::StopEvent(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_StopEvent_m76B40E41ADA129808B8DF8D5701D69F031ED03FB (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, int32_t ___transition0, const RuntimeMethod* method)
{
	{
		// if (!eventIsPlaying)
		bool L_0 = __this->get_eventIsPlaying_2();
		if (L_0)
		{
			goto IL_0009;
		}
	}
	{
		// return;
		return;
	}

IL_0009:
	{
		// akEvent.Stop(eventObject, transition);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_1 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_2 = __this->get_eventObject_18();
		int32_t L_3 = ___transition0;
		NullCheck(L_1);
		Event_Stop_mF058FF1C69C98C1C87C1B2F517DBDBEAAE85D943(L_1, L_2, L_3, 4, /*hidden argument*/NULL);
		// }
		return;
	}
}
// System.Boolean AkTimelineEventPlayableBehavior::PostEvent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkTimelineEventPlayableBehavior_PostEvent_mE7DBE796B44E46703E212E79ED76B1D31761ED2C (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_PostEvent_mE7DBE796B44E46703E212E79ED76B1D31761ED2C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint32_t V_0 = 0;
	bool V_1 = false;
	{
		// fadeinTriggered = fadeoutTriggered = false;
		int32_t L_0 = 0;
		V_1 = (bool)L_0;
		__this->set_fadeoutTriggered_4((bool)L_0);
		bool L_1 = V_1;
		__this->set_fadeinTriggered_3(L_1);
		// playingID = akEvent.Post(eventObject, CallbackFlags, CallbackHandler, null);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_2 = __this->get_akEvent_9();
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_3 = __this->get_eventObject_18();
		EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 * L_4 = (EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561 *)il2cpp_codegen_object_new(EventCallback_t9877FDD3EE27B8ABD69FE558993F1FCC32C0F561_il2cpp_TypeInfo_var);
		EventCallback__ctor_m8CEF34110B8FAB336F2211A3ED290453F048C6E2(L_4, __this, (intptr_t)((intptr_t)AkTimelineEventPlayableBehavior_CallbackHandler_mB867C4F333A72B80AB7488785F419D0D518B9357_RuntimeMethod_var), /*hidden argument*/NULL);
		NullCheck(L_2);
		uint32_t L_5 = Event_Post_m975A00B31848012ACE9114D3FDB25CA0E630601D(L_2, L_3, ((int32_t)9), L_4, NULL, /*hidden argument*/NULL);
		V_0 = L_5;
		// eventIsPlaying = playingID != AkSoundEngine.AK_INVALID_PLAYING_ID;
		uint32_t L_6 = V_0;
		__this->set_eventIsPlaying_2((bool)((!(((uint32_t)L_6) <= ((uint32_t)0)))? 1 : 0));
		// return eventIsPlaying;
		bool L_7 = __this->get_eventIsPlaying_2();
		return L_7;
	}
}
// System.Void AkTimelineEventPlayableBehavior::PlayEvent()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_PlayEvent_mED0A3AE5CF58B04026B73FB2BDB43E7B0299D5CD (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, const RuntimeMethod* method)
{
	{
		// if (!PostEvent())
		bool L_0 = AkTimelineEventPlayableBehavior_PostEvent_mE7DBE796B44E46703E212E79ED76B1D31761ED2C(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_0009;
		}
	}
	{
		// return;
		return;
	}

IL_0009:
	{
		// currentDurationProportion = 1f;
		__this->set_currentDurationProportion_1((1.0f));
		// previousEventStartTime = 0f;
		__this->set_previousEventStartTime_5((0.0f));
		// }
		return;
	}
}
// System.Void AkTimelineEventPlayableBehavior::RetriggerEvent(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior_RetriggerEvent_m7A9B9D27455C1824DEC3921F9D0326D8B156CAE2 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_RetriggerEvent_m7A9B9D27455C1824DEC3921F9D0326D8B156CAE2_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// wasScrubbingAndRequiresRetrigger = false;
		__this->set_wasScrubbingAndRequiresRetrigger_20((bool)0);
		// if (!PostEvent())
		bool L_0 = AkTimelineEventPlayableBehavior_PostEvent_mE7DBE796B44E46703E212E79ED76B1D31761ED2C(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_0010;
		}
	}
	{
		// return;
		return;
	}

IL_0010:
	{
		// currentDurationProportion = 1f - SeekToTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_1 = ___playable0;
		float L_2 = AkTimelineEventPlayableBehavior_SeekToTime_m97F34CBA9DF79E28A393710EBE06D5EAA1C938E7(__this, L_1, /*hidden argument*/NULL);
		__this->set_currentDurationProportion_1(((float)il2cpp_codegen_subtract((float)(1.0f), (float)L_2)));
		// previousEventStartTime = (float)UnityEngine.Playables.PlayableExtensions.GetTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_3 = ___playable0;
		double L_4 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_3, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		__this->set_previousEventStartTime_5((((float)((float)L_4))));
		// }
		return;
	}
}
// System.Single AkTimelineEventPlayableBehavior::GetProportionalTime(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float AkTimelineEventPlayableBehavior_GetProportionalTime_m52FBF2A2547C3263133CDA715BB870A8DD8A9D77 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_GetProportionalTime_m52FBF2A2547C3263133CDA715BB870A8DD8A9D77_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	float G_B5_0 = 0.0f;
	float G_B4_0 = 0.0f;
	float G_B6_0 = 0.0f;
	float G_B6_1 = 0.0f;
	{
		// if (eventDurationMax == eventDurationMin && eventDurationMin != -1f)
		float L_0 = __this->get_eventDurationMax_10();
		float L_1 = __this->get_eventDurationMin_11();
		if ((!(((float)L_0) == ((float)L_1))))
		{
			goto IL_0031;
		}
	}
	{
		float L_2 = __this->get_eventDurationMin_11();
		if ((((float)L_2) == ((float)(-1.0f))))
		{
			goto IL_0031;
		}
	}
	{
		// return (float)UnityEngine.Playables.PlayableExtensions.GetTime(playable) % eventDurationMax / eventDurationMax;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_3 = ___playable0;
		double L_4 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_3, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		float L_5 = __this->get_eventDurationMax_10();
		float L_6 = __this->get_eventDurationMax_10();
		return ((float)((float)(fmodf((((float)((float)L_4))), L_5))/(float)L_6));
	}

IL_0031:
	{
		// var currentTime = (float)UnityEngine.Playables.PlayableExtensions.GetTime(playable) - previousEventStartTime;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_7 = ___playable0;
		double L_8 = PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D(L_7, /*hidden argument*/PlayableExtensions_GetTime_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m2B7F64DD20E0D9B18A3E60B1B0BB0056B7C6747D_RuntimeMethod_var);
		float L_9 = __this->get_previousEventStartTime_5();
		// var maxDuration = currentDuration == -1f ? (float)UnityEngine.Playables.PlayableExtensions.GetDuration(playable) : currentDuration;
		float L_10 = __this->get_currentDuration_0();
		G_B4_0 = ((float)il2cpp_codegen_subtract((float)(((float)((float)L_8))), (float)L_9));
		if ((((float)L_10) == ((float)(-1.0f))))
		{
			G_B5_0 = ((float)il2cpp_codegen_subtract((float)(((float)((float)L_8))), (float)L_9));
			goto IL_0054;
		}
	}
	{
		float L_11 = __this->get_currentDuration_0();
		G_B6_0 = L_11;
		G_B6_1 = G_B4_0;
		goto IL_005b;
	}

IL_0054:
	{
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_12 = ___playable0;
		double L_13 = PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75(L_12, /*hidden argument*/PlayableExtensions_GetDuration_TisPlayable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0_m3557C19B4048EF5C9E875572F0E47D5EFB8E8E75_RuntimeMethod_var);
		G_B6_0 = (((float)((float)L_13)));
		G_B6_1 = G_B5_0;
	}

IL_005b:
	{
		V_0 = G_B6_0;
		// return currentTime % maxDuration / maxDuration;
		float L_14 = V_0;
		float L_15 = V_0;
		return ((float)((float)(fmodf(G_B6_1, L_14))/(float)L_15));
	}
}
// System.Single AkTimelineEventPlayableBehavior::SeekToTime(UnityEngine.Playables.Playable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float AkTimelineEventPlayableBehavior_SeekToTime_m97F34CBA9DF79E28A393710EBE06D5EAA1C938E7 (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventPlayableBehavior_SeekToTime_m97F34CBA9DF79E28A393710EBE06D5EAA1C938E7_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	{
		// var proportionalTime = GetProportionalTime(playable);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		float L_1 = AkTimelineEventPlayableBehavior_GetProportionalTime_m52FBF2A2547C3263133CDA715BB870A8DD8A9D77(__this, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		// if (proportionalTime >= 1f) 
		float L_2 = V_0;
		if ((!(((float)L_2) >= ((float)(1.0f)))))
		{
			goto IL_0016;
		}
	}
	{
		// return 1f;
		return (1.0f);
	}

IL_0016:
	{
		// if (eventIsPlaying)
		bool L_3 = __this->get_eventIsPlaying_2();
		if (!L_3)
		{
			goto IL_0036;
		}
	}
	{
		// AkSoundEngine.SeekOnEvent(akEvent.Id, eventObject, proportionalTime);
		Event_tC9AC0657BB663AABD5779ADCD5C959D65502A70F * L_4 = __this->get_akEvent_9();
		NullCheck(L_4);
		uint32_t L_5 = BaseType_get_Id_mBB17C7E1040290FB19B655F35B827A5D65B18E0A(L_4, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_6 = __this->get_eventObject_18();
		float L_7 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AkSoundEngine_t5DB71141429E929DC3FADFF6DDC1FF5CBC52DF6A_il2cpp_TypeInfo_var);
		AkSoundEngine_SeekOnEvent_m5ABF68DD7A2149E6D7D4AE61D2F597E0B1F60574(L_5, L_6, L_7, /*hidden argument*/NULL);
	}

IL_0036:
	{
		// return proportionalTime;
		float L_8 = V_0;
		return L_8;
	}
}
// System.Void AkTimelineEventPlayableBehavior::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventPlayableBehavior__ctor_mFE6F1F30974519D16D0CC42EA6D890495128D84B (AkTimelineEventPlayableBehavior_tA4F56ED0C42F467C4A99BEF634F9073576817844 * __this, const RuntimeMethod* method)
{
	{
		// private float currentDuration = -1f;
		__this->set_currentDuration_0((-1.0f));
		// private float currentDurationProportion = 1f;
		__this->set_currentDurationProportion_1((1.0f));
		PlayableBehaviour__ctor_mE96A877D927BEEC8C9368A0673FEAD77A78C35EE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Playables.Playable AkTimelineEventTrack::CreateTrackMixer(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  AkTimelineEventTrack_CreateTrackMixer_mE3F815B775E279BC3EB52ADF9A4410A22C6D474D (AkTimelineEventTrack_t93130E623074A6BC6A9643A4434153816C60FB8D * __this, PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___go1, int32_t ___inputCount2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventTrack_CreateTrackMixer_mE3F815B775E279BC3EB52ADF9A4410A22C6D474D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  V_0;
	memset((&V_0), 0, sizeof(V_0));
	RuntimeObject* V_1 = NULL;
	TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * V_2 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		// var playable = UnityEngine.Playables.ScriptPlayable<AkTimelineEventPlayableBehavior>.Create(graph);
		PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  L_0 = ___graph0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_il2cpp_TypeInfo_var);
		ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  L_1 = ScriptPlayable_1_Create_m0C1209813E5FE8A3908A07A94193CC3C6FC29756(L_0, 0, /*hidden argument*/ScriptPlayable_1_Create_m0C1209813E5FE8A3908A07A94193CC3C6FC29756_RuntimeMethod_var);
		V_0 = L_1;
		// UnityEngine.Playables.PlayableExtensions.SetInputCount(playable, inputCount);
		ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  L_2 = V_0;
		int32_t L_3 = ___inputCount2;
		PlayableExtensions_SetInputCount_TisScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_m72C445E9F3D119051901CBC7B175A868F0F410EF(L_2, L_3, /*hidden argument*/PlayableExtensions_SetInputCount_TisScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_m72C445E9F3D119051901CBC7B175A868F0F410EF_RuntimeMethod_var);
		// var clips = GetClips();
		RuntimeObject* L_4 = TrackAsset_GetClips_m2A53471D61EE6C84F42BE83D0E689691382FA172(__this, /*hidden argument*/NULL);
		// foreach (var clip in clips)
		NullCheck(L_4);
		RuntimeObject* L_5 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TimelineClip>::GetEnumerator() */, IEnumerable_1_tF659A953244FBB8F81B6A4F9CD67286607C3FD51_il2cpp_TypeInfo_var, L_4);
		V_1 = L_5;
	}

IL_001b:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0035;
		}

IL_001d:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_6 = V_1;
			NullCheck(L_6);
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_7 = InterfaceFuncInvoker0< TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<UnityEngine.Timeline.TimelineClip>::get_Current() */, IEnumerator_1_t4589C691232BC39AA49B633323A50B6AE60479C0_il2cpp_TypeInfo_var, L_6);
			V_2 = L_7;
			// var eventPlayable = clip.asset as AkTimelineEventPlayable;
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_8 = V_2;
			NullCheck(L_8);
			Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * L_9 = TimelineClip_get_asset_mCF4C0F2153BF18362958432960C87A24B5534245_inline(L_8, /*hidden argument*/NULL);
			// eventPlayable.owningClip = clip;
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_10 = V_2;
			NullCheck(((AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A *)IsInstClass((RuntimeObject*)L_9, AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A_il2cpp_TypeInfo_var)));
			((AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A *)IsInstClass((RuntimeObject*)L_9, AkTimelineEventPlayable_tE20F4B037DE775775B34986645BE740F2BCD7D9A_il2cpp_TypeInfo_var))->set_owningClip_9(L_10);
		}

IL_0035:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_11 = V_1;
			NullCheck(L_11);
			bool L_12 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t8789118187258CC88B77AFAC6315B5AF87D3E18A_il2cpp_TypeInfo_var, L_11);
			if (L_12)
			{
				goto IL_001d;
			}
		}

IL_003d:
		{
			IL2CPP_LEAVE(0x49, FINALLY_003f);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_003f;
	}

FINALLY_003f:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_13 = V_1;
			if (!L_13)
			{
				goto IL_0048;
			}
		}

IL_0042:
		{
			RuntimeObject* L_14 = V_1;
			NullCheck(L_14);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_14);
		}

IL_0048:
		{
			IL2CPP_END_FINALLY(63)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(63)
	{
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
		IL2CPP_JUMP_TBL(0x49, IL_0049)
	}

IL_0049:
	{
		// return playable;
		ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC  L_15 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t7B051FA15B6A632C225D1905781CAAD80B4D44AC_il2cpp_TypeInfo_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_16 = ScriptPlayable_1_op_Implicit_m52EBDBFDF6B21D71CEA48FB89BC92CDAF68851FD(L_15, /*hidden argument*/ScriptPlayable_1_op_Implicit_m52EBDBFDF6B21D71CEA48FB89BC92CDAF68851FD_RuntimeMethod_var);
		return L_16;
	}
}
// System.Void AkTimelineEventTrack::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineEventTrack__ctor_m6A8944A8AE993C953903280CF96A13D6974D3D08 (AkTimelineEventTrack_t93130E623074A6BC6A9643A4434153816C60FB8D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineEventTrack__ctor_m6A8944A8AE993C953903280CF96A13D6974D3D08_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_il2cpp_TypeInfo_var);
		TrackAsset__ctor_mB57EE24087931D858028EE79112A1FABDC95E5C6(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkTimelineRtpcPlayable::SetupClipDisplay()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayable_SetupClipDisplay_mA1C3BBAB686C4C8BB005A7FB54643DC1A53D716C (AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * __this, const RuntimeMethod* method)
{
	{
		// }
		return;
	}
}
// UnityEngine.Timeline.TimelineClip AkTimelineRtpcPlayable::get_owningClip()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * AkTimelineRtpcPlayable_get_owningClip_m47AF53B01C113F3833FB785AF28DEB3A673AE6A1 (AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * __this, const RuntimeMethod* method)
{
	{
		// public UnityEngine.Timeline.TimelineClip owningClip { get; set; }
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_0 = __this->get_U3CowningClipU3Ek__BackingField_7();
		return L_0;
	}
}
// System.Void AkTimelineRtpcPlayable::set_owningClip(UnityEngine.Timeline.TimelineClip)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayable_set_owningClip_m79D794A183DE5DF73FCAA031047D704FDD6B617E (AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * __this, TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___value0, const RuntimeMethod* method)
{
	{
		// public UnityEngine.Timeline.TimelineClip owningClip { get; set; }
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_0 = ___value0;
		__this->set_U3CowningClipU3Ek__BackingField_7(L_0);
		return;
	}
}
// UnityEngine.Timeline.ClipCaps AkTimelineRtpcPlayable::UnityEngine.Timeline.ITimelineClipAsset.get_clipCaps()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AkTimelineRtpcPlayable_UnityEngine_Timeline_ITimelineClipAsset_get_clipCaps_m89AB26A77BF71C22AA0FDC1A7F502CEE4E114CF2 (AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * __this, const RuntimeMethod* method)
{
	{
		// get { return UnityEngine.Timeline.ClipCaps.Looping & UnityEngine.Timeline.ClipCaps.Extrapolation & UnityEngine.Timeline.ClipCaps.Blending; }
		return (int32_t)(0);
	}
}
// UnityEngine.Playables.Playable AkTimelineRtpcPlayable::CreatePlayable(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  AkTimelineRtpcPlayable_CreatePlayable_m38158F617A5B24DD3A97D2B62A43663BF8F0A284 (AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * __this, PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineRtpcPlayable_CreatePlayable_m38158F617A5B24DD3A97D2B62A43663BF8F0A284_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		// var playable = UnityEngine.Playables.ScriptPlayable<AkTimelineRtpcPlayableBehaviour>.Create(graph, template);
		PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  L_0 = ___graph0;
		AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * L_1 = __this->get_template_6();
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F_il2cpp_TypeInfo_var);
		ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  L_2 = ScriptPlayable_1_Create_m59CEC9FB4154638ED596E64AD2D7BA87D3825FF4(L_0, L_1, 0, /*hidden argument*/ScriptPlayable_1_Create_m59CEC9FB4154638ED596E64AD2D7BA87D3825FF4_RuntimeMethod_var);
		V_0 = L_2;
		// var b = playable.GetBehaviour();
		AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * L_3 = ScriptPlayable_1_GetBehaviour_mBB9A6506A045C46C979B2CB00455DEF36A8B8236((ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F *)(&V_0), /*hidden argument*/ScriptPlayable_1_GetBehaviour_mBB9A6506A045C46C979B2CB00455DEF36A8B8236_RuntimeMethod_var);
		// b.RTPC = RTPC;
		AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * L_4 = L_3;
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_5 = __this->get_RTPC_4();
		NullCheck(L_4);
		AkTimelineRtpcPlayableBehaviour_set_RTPC_m266951A6E2AC14364383E32C41F18379112079AD_inline(L_4, L_5, /*hidden argument*/NULL);
		// b.setGlobally = setGlobally;
		AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * L_6 = L_4;
		bool L_7 = __this->get_setGlobally_5();
		NullCheck(L_6);
		AkTimelineRtpcPlayableBehaviour_set_setGlobally_m885F5D0F80346DC21D56C1A7693D54E676D03DFE_inline(L_6, L_7, /*hidden argument*/NULL);
		// b.gameObject = gameObject;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_8 = ___gameObject1;
		NullCheck(L_6);
		AkTimelineRtpcPlayableBehaviour_set_gameObject_mE64DDF14D65AA4221C916A362D854390AB02653C_inline(L_6, L_8, /*hidden argument*/NULL);
		// return playable;
		ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  L_9 = V_0;
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_10 = ScriptPlayable_1_op_Implicit_m1CF6AF8A5E29CBAD2BE823B72646D7F4D292F4D9(L_9, /*hidden argument*/ScriptPlayable_1_op_Implicit_m1CF6AF8A5E29CBAD2BE823B72646D7F4D292F4D9_RuntimeMethod_var);
		return L_10;
	}
}
// System.Void AkTimelineRtpcPlayable::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayable__ctor_m658808552E2C6757AC654C6E35D712BD4276A9FF (AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineRtpcPlayable__ctor_m658808552E2C6757AC654C6E35D712BD4276A9FF_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public AK.Wwise.RTPC RTPC = new AK.Wwise.RTPC();
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = (RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C *)il2cpp_codegen_object_new(RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C_il2cpp_TypeInfo_var);
		RTPC__ctor_m7ECE0016601182CE16F80569BBD0F6E1C206803A(L_0, /*hidden argument*/NULL);
		__this->set_RTPC_4(L_0);
		// public AkTimelineRtpcPlayableBehaviour template = new AkTimelineRtpcPlayableBehaviour();
		AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * L_1 = (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E *)il2cpp_codegen_object_new(AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E_il2cpp_TypeInfo_var);
		AkTimelineRtpcPlayableBehaviour__ctor_mF1B7D8F25FAE1196AA4F5E2DD5D8F04B89D1DB4F(L_1, /*hidden argument*/NULL);
		__this->set_template_6(L_1);
		PlayableAsset__ctor_m669F459CFACFE65873346E428F206C457B488167(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AkTimelineRtpcPlayableBehaviour::set_RTPC(AK.Wwise.RTPC)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_set_RTPC_m266951A6E2AC14364383E32C41F18379112079AD (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___value0, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC RTPC { set; get; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = ___value0;
		__this->set_U3CRTPCU3Ek__BackingField_1(L_0);
		return;
	}
}
// AK.Wwise.RTPC AkTimelineRtpcPlayableBehaviour::get_RTPC()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * AkTimelineRtpcPlayableBehaviour_get_RTPC_m6F7A917B5A02F293BC59B0E39C428C3AF6C6ED34 (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC RTPC { set; get; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = __this->get_U3CRTPCU3Ek__BackingField_1();
		return L_0;
	}
}
// System.Void AkTimelineRtpcPlayableBehaviour::set_setGlobally(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_set_setGlobally_m885F5D0F80346DC21D56C1A7693D54E676D03DFE (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// public bool setGlobally { set; get; }
		bool L_0 = ___value0;
		__this->set_U3CsetGloballyU3Ek__BackingField_2(L_0);
		return;
	}
}
// System.Boolean AkTimelineRtpcPlayableBehaviour::get_setGlobally()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AkTimelineRtpcPlayableBehaviour_get_setGlobally_mFCE6782EF459AB9BD2B1C9ABF5FAB200CAE0FA90 (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method)
{
	{
		// public bool setGlobally { set; get; }
		bool L_0 = __this->get_U3CsetGloballyU3Ek__BackingField_2();
		return L_0;
	}
}
// System.Void AkTimelineRtpcPlayableBehaviour::set_gameObject(UnityEngine.GameObject)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_set_gameObject_mE64DDF14D65AA4221C916A362D854390AB02653C (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___value0, const RuntimeMethod* method)
{
	{
		// public UnityEngine.GameObject gameObject { set; get; }
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_0 = ___value0;
		__this->set_U3CgameObjectU3Ek__BackingField_3(L_0);
		return;
	}
}
// UnityEngine.GameObject AkTimelineRtpcPlayableBehaviour::get_gameObject()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * AkTimelineRtpcPlayableBehaviour_get_gameObject_m9F80502C76AFF69F91CAD39D68CDED532987369E (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method)
{
	{
		// public UnityEngine.GameObject gameObject { set; get; }
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_0 = __this->get_U3CgameObjectU3Ek__BackingField_3();
		return L_0;
	}
}
// System.Void AkTimelineRtpcPlayableBehaviour::ProcessFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_ProcessFrame_m4D4DE4F8F487113BA4AB0325E848254695B12859 (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  ___playable0, FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  ___frameData1, RuntimeObject * ___playerData2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineRtpcPlayableBehaviour_ProcessFrame_m4D4DE4F8F487113BA4AB0325E848254695B12859_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * V_0 = NULL;
	{
		// base.ProcessFrame(playable, frameData, playerData);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_0 = ___playable0;
		FrameData_t7CF1DA259799AC04363C4CA88947D4EB7E28B38E  L_1 = ___frameData1;
		RuntimeObject * L_2 = ___playerData2;
		PlayableBehaviour_ProcessFrame_m32F9B265BB54D1A3A290E2709FDD0B873360B25A(__this, L_0, L_1, L_2, /*hidden argument*/NULL);
		// if (RTPC == null)
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_3 = AkTimelineRtpcPlayableBehaviour_get_RTPC_m6F7A917B5A02F293BC59B0E39C428C3AF6C6ED34_inline(__this, /*hidden argument*/NULL);
		if (L_3)
		{
			goto IL_0012;
		}
	}
	{
		// return;
		return;
	}

IL_0012:
	{
		// var obj = playerData as UnityEngine.GameObject;
		RuntimeObject * L_4 = ___playerData2;
		V_0 = ((GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F *)IsInstSealed((RuntimeObject*)L_4, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F_il2cpp_TypeInfo_var));
		// if (obj != null)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_6 = Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1(L_5, (Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 *)NULL, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0029;
		}
	}
	{
		// gameObject = obj;
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_7 = V_0;
		AkTimelineRtpcPlayableBehaviour_set_gameObject_mE64DDF14D65AA4221C916A362D854390AB02653C_inline(__this, L_7, /*hidden argument*/NULL);
	}

IL_0029:
	{
		// if (setGlobally)
		bool L_8 = AkTimelineRtpcPlayableBehaviour_get_setGlobally_mFCE6782EF459AB9BD2B1C9ABF5FAB200CAE0FA90_inline(__this, /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_0043;
		}
	}
	{
		// RTPC.SetGlobalValue(value);
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_9 = AkTimelineRtpcPlayableBehaviour_get_RTPC_m6F7A917B5A02F293BC59B0E39C428C3AF6C6ED34_inline(__this, /*hidden argument*/NULL);
		float L_10 = __this->get_value_0();
		NullCheck(L_9);
		RTPC_SetGlobalValue_mE95A5B940C8101349FA64E225E3D08233871C505(L_9, L_10, /*hidden argument*/NULL);
		return;
	}

IL_0043:
	{
		// else if (gameObject)
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_11 = AkTimelineRtpcPlayableBehaviour_get_gameObject_m9F80502C76AFF69F91CAD39D68CDED532987369E_inline(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_il2cpp_TypeInfo_var);
		bool L_12 = Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534(L_11, /*hidden argument*/NULL);
		if (!L_12)
		{
			goto IL_0067;
		}
	}
	{
		// RTPC.SetValue(gameObject, value);
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_13 = AkTimelineRtpcPlayableBehaviour_get_RTPC_m6F7A917B5A02F293BC59B0E39C428C3AF6C6ED34_inline(__this, /*hidden argument*/NULL);
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_14 = AkTimelineRtpcPlayableBehaviour_get_gameObject_m9F80502C76AFF69F91CAD39D68CDED532987369E_inline(__this, /*hidden argument*/NULL);
		float L_15 = __this->get_value_0();
		NullCheck(L_13);
		RTPC_SetValue_m1C344467FDED1786C71D410DBFCD5D03DCCD9AD5(L_13, L_14, L_15, /*hidden argument*/NULL);
	}

IL_0067:
	{
		// }
		return;
	}
}
// System.Void AkTimelineRtpcPlayableBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour__ctor_mF1B7D8F25FAE1196AA4F5E2DD5D8F04B89D1DB4F (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method)
{
	{
		PlayableBehaviour__ctor_mE96A877D927BEEC8C9368A0673FEAD77A78C35EE(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Playables.Playable AkTimelineRtpcTrack::CreateTrackMixer(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  AkTimelineRtpcTrack_CreateTrackMixer_m2C472F84E648753E136071CB95CBBCC47E256D86 (AkTimelineRtpcTrack_t24C4A29FFDA9C21457A11DF2EB1FE2812DF4D85C * __this, PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  ___graph0, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___gameObject1, int32_t ___inputCount2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineRtpcTrack_CreateTrackMixer_m2C472F84E648753E136071CB95CBBCC47E256D86_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  V_0;
	memset((&V_0), 0, sizeof(V_0));
	RuntimeObject* V_1 = NULL;
	TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * V_2 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		// var playable = UnityEngine.Playables.ScriptPlayable<AkTimelineRtpcPlayableBehaviour>.Create(graph, inputCount);
		PlayableGraph_tEC38BBCA59BDD496F75037F220984D41339AB8BA  L_0 = ___graph0;
		int32_t L_1 = ___inputCount2;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F_il2cpp_TypeInfo_var);
		ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  L_2 = ScriptPlayable_1_Create_m6EDD12B7BD86240B4CC3454532CC07C826603BB8(L_0, L_1, /*hidden argument*/ScriptPlayable_1_Create_m6EDD12B7BD86240B4CC3454532CC07C826603BB8_RuntimeMethod_var);
		V_0 = L_2;
		// var clips = GetClips();
		RuntimeObject* L_3 = TrackAsset_GetClips_m2A53471D61EE6C84F42BE83D0E689691382FA172(__this, /*hidden argument*/NULL);
		// foreach (var clip in clips)
		NullCheck(L_3);
		RuntimeObject* L_4 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TimelineClip>::GetEnumerator() */, IEnumerable_1_tF659A953244FBB8F81B6A4F9CD67286607C3FD51_il2cpp_TypeInfo_var, L_3);
		V_1 = L_4;
	}

IL_0014:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0034;
		}

IL_0016:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_5 = V_1;
			NullCheck(L_5);
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_6 = InterfaceFuncInvoker0< TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<UnityEngine.Timeline.TimelineClip>::get_Current() */, IEnumerator_1_t4589C691232BC39AA49B633323A50B6AE60479C0_il2cpp_TypeInfo_var, L_5);
			V_2 = L_6;
			// var rtpcPlayable = (clip.asset as AkTimelineRtpcPlayable);
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_7 = V_2;
			NullCheck(L_7);
			Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * L_8 = TimelineClip_get_asset_mCF4C0F2153BF18362958432960C87A24B5534245_inline(L_7, /*hidden argument*/NULL);
			// rtpcPlayable.owningClip = clip;
			AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * L_9 = ((AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA *)IsInstClass((RuntimeObject*)L_8, AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA_il2cpp_TypeInfo_var));
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_10 = V_2;
			NullCheck(L_9);
			AkTimelineRtpcPlayable_set_owningClip_m79D794A183DE5DF73FCAA031047D704FDD6B617E_inline(L_9, L_10, /*hidden argument*/NULL);
			// rtpcPlayable.SetupClipDisplay();
			NullCheck(L_9);
			AkTimelineRtpcPlayable_SetupClipDisplay_mA1C3BBAB686C4C8BB005A7FB54643DC1A53D716C(L_9, /*hidden argument*/NULL);
		}

IL_0034:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_11 = V_1;
			NullCheck(L_11);
			bool L_12 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t8789118187258CC88B77AFAC6315B5AF87D3E18A_il2cpp_TypeInfo_var, L_11);
			if (L_12)
			{
				goto IL_0016;
			}
		}

IL_003c:
		{
			IL2CPP_LEAVE(0x48, FINALLY_003e);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_003e;
	}

FINALLY_003e:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_13 = V_1;
			if (!L_13)
			{
				goto IL_0047;
			}
		}

IL_0041:
		{
			RuntimeObject* L_14 = V_1;
			NullCheck(L_14);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_14);
		}

IL_0047:
		{
			IL2CPP_END_FINALLY(62)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(62)
	{
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
		IL2CPP_JUMP_TBL(0x48, IL_0048)
	}

IL_0048:
	{
		// return playable;
		ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F  L_15 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ScriptPlayable_1_t0DD5497FCADFA22B7E30CFD2164E56F7EE43644F_il2cpp_TypeInfo_var);
		Playable_t4ABB910C374FCAB6B926DA4D34A85857A59950D0  L_16 = ScriptPlayable_1_op_Implicit_m1CF6AF8A5E29CBAD2BE823B72646D7F4D292F4D9(L_15, /*hidden argument*/ScriptPlayable_1_op_Implicit_m1CF6AF8A5E29CBAD2BE823B72646D7F4D292F4D9_RuntimeMethod_var);
		return L_16;
	}
}
// System.Void AkTimelineRtpcTrack::OnValidate()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcTrack_OnValidate_m8B5FECFE2725498C8AB1ED9ACA1E1E984012F887 (AkTimelineRtpcTrack_t24C4A29FFDA9C21457A11DF2EB1FE2812DF4D85C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineRtpcTrack_OnValidate_m8B5FECFE2725498C8AB1ED9ACA1E1E984012F887_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		// var clips = GetClips();
		RuntimeObject* L_0 = TrackAsset_GetClips_m2A53471D61EE6C84F42BE83D0E689691382FA172(__this, /*hidden argument*/NULL);
		// foreach (var clip in clips)
		NullCheck(L_0);
		RuntimeObject* L_1 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<!0> System.Collections.Generic.IEnumerable`1<UnityEngine.Timeline.TimelineClip>::GetEnumerator() */, IEnumerable_1_tF659A953244FBB8F81B6A4F9CD67286607C3FD51_il2cpp_TypeInfo_var, L_0);
		V_0 = L_1;
	}

IL_000c:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0023;
		}

IL_000e:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_2 = V_0;
			NullCheck(L_2);
			TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_3 = InterfaceFuncInvoker0< TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * >::Invoke(0 /* !0 System.Collections.Generic.IEnumerator`1<UnityEngine.Timeline.TimelineClip>::get_Current() */, IEnumerator_1_t4589C691232BC39AA49B633323A50B6AE60479C0_il2cpp_TypeInfo_var, L_2);
			// (clip.asset as AkTimelineRtpcPlayable).SetupClipDisplay();
			NullCheck(L_3);
			Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * L_4 = TimelineClip_get_asset_mCF4C0F2153BF18362958432960C87A24B5534245_inline(L_3, /*hidden argument*/NULL);
			NullCheck(((AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA *)IsInstClass((RuntimeObject*)L_4, AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA_il2cpp_TypeInfo_var)));
			AkTimelineRtpcPlayable_SetupClipDisplay_mA1C3BBAB686C4C8BB005A7FB54643DC1A53D716C(((AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA *)IsInstClass((RuntimeObject*)L_4, AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
		}

IL_0023:
		{
			// foreach (var clip in clips)
			RuntimeObject* L_5 = V_0;
			NullCheck(L_5);
			bool L_6 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t8789118187258CC88B77AFAC6315B5AF87D3E18A_il2cpp_TypeInfo_var, L_5);
			if (L_6)
			{
				goto IL_000e;
			}
		}

IL_002b:
		{
			IL2CPP_LEAVE(0x37, FINALLY_002d);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_002d;
	}

FINALLY_002d:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_7 = V_0;
			if (!L_7)
			{
				goto IL_0036;
			}
		}

IL_0030:
		{
			RuntimeObject* L_8 = V_0;
			NullCheck(L_8);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_8);
		}

IL_0036:
		{
			IL2CPP_END_FINALLY(45)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(45)
	{
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
		IL2CPP_JUMP_TBL(0x37, IL_0037)
	}

IL_0037:
	{
		// }
		return;
	}
}
// System.Void AkTimelineRtpcTrack::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AkTimelineRtpcTrack__ctor_m176E15107078E586C295768D7200C8F9F0340922 (AkTimelineRtpcTrack_t24C4A29FFDA9C21457A11DF2EB1FE2812DF4D85C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AkTimelineRtpcTrack__ctor_m176E15107078E586C295768D7200C8F9F0340922_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(TrackAsset_tEC3A0C099449162C983BFF3C1A64084B2D3CDA9D_il2cpp_TypeInfo_var);
		TrackAsset__ctor_mB57EE24087931D858028EE79112A1FABDC95E5C6(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * TimelineClip_get_asset_mCF4C0F2153BF18362958432960C87A24B5534245_inline (TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * __this, const RuntimeMethod* method)
{
	{
		// get { return m_Asset; }
		Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0 * L_0 = __this->get_m_Asset_11();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_overrideTrackObject_m8DF38D0A0F763DD5B549E2AAC92EE04614ACC73B_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// public bool overrideTrackObject { set; private get; }
		bool L_0 = ___value0;
		__this->set_U3CoverrideTrackObjectU3Ek__BackingField_2(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_setRTPCGlobally_mD76260F7F2F1F5E2372CE49E4FE26FDCCFE631F7_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// public bool setRTPCGlobally { set; private get; }
		bool L_0 = ___value0;
		__this->set_U3CsetRTPCGloballyU3Ek__BackingField_1(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_rtpcObject_m064CC1ADCDF87B23D01249F73FE85704F502BA34_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___value0, const RuntimeMethod* method)
{
	{
		// public UnityEngine.GameObject rtpcObject { set; private get; }
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_0 = ___value0;
		__this->set_U3CrtpcObjectU3Ek__BackingField_3(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * AkRTPCPlayable_get_Parameter_m2D38638222BA51B7DFAF565B8694C56D379B20F3_inline (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC Parameter { get; set; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = __this->get_U3CParameterU3Ek__BackingField_8();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayableBehaviour_set_parameter_m6915EF2CBEE92F68DDA1126FC809432AAB995F7B_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___value0, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC parameter { set; private get; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = ___value0;
		__this->set_U3CparameterU3Ek__BackingField_4(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * AkRTPCPlayableBehaviour_get_parameter_m186376F0D552C0754F21097D49C0E4C81546892B_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC parameter { set; private get; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = __this->get_U3CparameterU3Ek__BackingField_4();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool AkRTPCPlayableBehaviour_get_overrideTrackObject_mBCDF4A0A2FA5ED107088104035AC259CD94615A2_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method)
{
	{
		// public bool overrideTrackObject { set; private get; }
		bool L_0 = __this->get_U3CoverrideTrackObjectU3Ek__BackingField_2();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool AkRTPCPlayableBehaviour_get_setRTPCGlobally_mBF723B975C206CF59964725F4E2D887FA4C96C95_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method)
{
	{
		// public bool setRTPCGlobally { set; private get; }
		bool L_0 = __this->get_U3CsetRTPCGloballyU3Ek__BackingField_1();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * AkRTPCPlayableBehaviour_get_rtpcObject_mF5DAB9C945515A7D7FE3A9743EC5A68851149359_inline (AkRTPCPlayableBehaviour_t3F71D4C6F23D6FA70AC6108A1400D7E03397B075 * __this, const RuntimeMethod* method)
{
	{
		// public UnityEngine.GameObject rtpcObject { set; private get; }
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_0 = __this->get_U3CrtpcObjectU3Ek__BackingField_3();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayable_set_Parameter_m6FCF8273EB6C0879509D3D1E25E4856756D0A7E5_inline (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___value0, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC Parameter { get; set; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = ___value0;
		__this->set_U3CParameterU3Ek__BackingField_8(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkRTPCPlayable_set_OwningClip_mED2FC6B983BDF1F35AB3A5D66833DDD0C5B865BB_inline (AkRTPCPlayable_t5BF3B8539957C161D67B17719716AD5B63DC123C * __this, TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___value0, const RuntimeMethod* method)
{
	{
		// public UnityEngine.Timeline.TimelineClip OwningClip { get; set; }
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_0 = ___value0;
		__this->set_U3COwningClipU3Ek__BackingField_9(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_set_RTPC_m266951A6E2AC14364383E32C41F18379112079AD_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * ___value0, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC RTPC { set; get; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = ___value0;
		__this->set_U3CRTPCU3Ek__BackingField_1(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_set_setGlobally_m885F5D0F80346DC21D56C1A7693D54E676D03DFE_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		// public bool setGlobally { set; get; }
		bool L_0 = ___value0;
		__this->set_U3CsetGloballyU3Ek__BackingField_2(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayableBehaviour_set_gameObject_mE64DDF14D65AA4221C916A362D854390AB02653C_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___value0, const RuntimeMethod* method)
{
	{
		// public UnityEngine.GameObject gameObject { set; get; }
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_0 = ___value0;
		__this->set_U3CgameObjectU3Ek__BackingField_3(L_0);
		return;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * AkTimelineRtpcPlayableBehaviour_get_RTPC_m6F7A917B5A02F293BC59B0E39C428C3AF6C6ED34_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method)
{
	{
		// public AK.Wwise.RTPC RTPC { set; get; }
		RTPC_t138DD759B48153A695904EAD2E692FCF62194F1C * L_0 = __this->get_U3CRTPCU3Ek__BackingField_1();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR bool AkTimelineRtpcPlayableBehaviour_get_setGlobally_mFCE6782EF459AB9BD2B1C9ABF5FAB200CAE0FA90_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method)
{
	{
		// public bool setGlobally { set; get; }
		bool L_0 = __this->get_U3CsetGloballyU3Ek__BackingField_2();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * AkTimelineRtpcPlayableBehaviour_get_gameObject_m9F80502C76AFF69F91CAD39D68CDED532987369E_inline (AkTimelineRtpcPlayableBehaviour_tB2349C6ADF9D4FF3041870AED2CAEB5C75F09E6E * __this, const RuntimeMethod* method)
{
	{
		// public UnityEngine.GameObject gameObject { set; get; }
		GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * L_0 = __this->get_U3CgameObjectU3Ek__BackingField_3();
		return L_0;
	}
}
IL2CPP_EXTERN_C inline  IL2CPP_METHOD_ATTR void AkTimelineRtpcPlayable_set_owningClip_m79D794A183DE5DF73FCAA031047D704FDD6B617E_inline (AkTimelineRtpcPlayable_t1AC5DE3F1476B226A72DCDD4A8F61977BB8842EA * __this, TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * ___value0, const RuntimeMethod* method)
{
	{
		// public UnityEngine.Timeline.TimelineClip owningClip { get; set; }
		TimelineClip_tE83BF10CBA35C71678866F5F3E8A05332ADAF5BB * L_0 = ___value0;
		__this->set_U3CowningClipU3Ek__BackingField_7(L_0);
		return;
	}
}
