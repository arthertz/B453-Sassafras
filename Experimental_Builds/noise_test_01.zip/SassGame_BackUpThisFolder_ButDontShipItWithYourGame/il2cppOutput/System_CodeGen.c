﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String SR::GetString(System.String,System.Object[])
extern void SR_GetString_m9548BD6DD52DFDB46372F211078AE57FA2401E39 (void);
// 0x00000002 System.String SR::GetString(System.Globalization.CultureInfo,System.String,System.Object[])
extern void SR_GetString_m9D671CBA422B18D15B8FF59B22DCCEB32E3D16E2 (void);
// 0x00000003 System.String SR::GetString(System.String)
extern void SR_GetString_m3FC710B15474A9B651DA02B303241B6D8B87E2A7 (void);
// 0x00000004 System.Boolean System.IriHelper::CheckIriUnicodeRange(System.Char,System.Boolean)
extern void IriHelper_CheckIriUnicodeRange_mA9BAAD6D244ADEE8986FDC0DFB3DFDA90C093A6C (void);
// 0x00000005 System.Boolean System.IriHelper::CheckIriUnicodeRange(System.Char,System.Char,System.Boolean&,System.Boolean)
extern void IriHelper_CheckIriUnicodeRange_m5ED29083C22062AEAB8B5787C9A27CFEEC397AD9 (void);
// 0x00000006 System.Boolean System.IriHelper::CheckIsReserved(System.Char,System.UriComponents)
extern void IriHelper_CheckIsReserved_m5C0A35BF0890852A3FC564618DB0836BBB6C0F1C (void);
// 0x00000007 System.String System.IriHelper::EscapeUnescapeIri(System.Char*,System.Int32,System.Int32,System.UriComponents)
extern void IriHelper_EscapeUnescapeIri_m6DE347247CE35DB4CE3129BEC2179F0095D69239 (void);
// 0x00000008 System.Boolean System.Uri::get_IsImplicitFile()
extern void Uri_get_IsImplicitFile_m048350CB1E9AB92599F1557680A5D3B5FDE7C35D (void);
// 0x00000009 System.Boolean System.Uri::get_IsUncOrDosPath()
extern void Uri_get_IsUncOrDosPath_mE372CA996BE5B29DD531D7C6DD1809E17441005E (void);
// 0x0000000A System.Boolean System.Uri::get_IsDosPath()
extern void Uri_get_IsDosPath_m89CA4E32381C529502E91872BC89BD18F5419D08 (void);
// 0x0000000B System.Boolean System.Uri::get_IsUncPath()
extern void Uri_get_IsUncPath_mD5EE84D5105BFB7D64E5C26B9549A67B720A7AE8 (void);
// 0x0000000C System.Uri_Flags System.Uri::get_HostType()
extern void Uri_get_HostType_mBB4EE8652EA19E2FB8C696302D5EBE82F358EC90 (void);
// 0x0000000D System.UriParser System.Uri::get_Syntax()
extern void Uri_get_Syntax_m3DB6A5D9E6FC3E0D0A63EA8A4527AF4106F9BD78 (void);
// 0x0000000E System.Boolean System.Uri::get_IsNotAbsoluteUri()
extern void Uri_get_IsNotAbsoluteUri_mF9706123EB027C6E9AB263B98CE58CF319A22919 (void);
// 0x0000000F System.Boolean System.Uri::IriParsingStatic(System.UriParser)
extern void Uri_IriParsingStatic_m39FC9677B4B9EFBADF814F2EEA58280F35A1D3E5 (void);
// 0x00000010 System.Boolean System.Uri::get_AllowIdn()
extern void Uri_get_AllowIdn_mF1833CB700E04D746D75428948BEBC70536E1941 (void);
// 0x00000011 System.Boolean System.Uri::AllowIdnStatic(System.UriParser,System.Uri_Flags)
extern void Uri_AllowIdnStatic_mFABD19611F334DF87EC3FF2B9A1FA061CAE3A5C5 (void);
// 0x00000012 System.Boolean System.Uri::IsIntranet(System.String)
extern void Uri_IsIntranet_mE98CA41B60FE0D4970737C8B7C81E5C63BFC07E1 (void);
// 0x00000013 System.Boolean System.Uri::get_UserDrivenParsing()
extern void Uri_get_UserDrivenParsing_mFF27964894B5C0432C37E425F319D6C915BCDC39 (void);
// 0x00000014 System.Void System.Uri::SetUserDrivenParsing()
extern void Uri_SetUserDrivenParsing_m0368CB47B9E9C35CB49B3F02DBE8DFED8756226B (void);
// 0x00000015 System.UInt16 System.Uri::get_SecuredPathIndex()
extern void Uri_get_SecuredPathIndex_mC59A2366D6F3667017F677351C4350C9541905AA (void);
// 0x00000016 System.Boolean System.Uri::NotAny(System.Uri_Flags)
extern void Uri_NotAny_mC5DC04B72B13D2997B055B9E41FCFEEC1CE5263D (void);
// 0x00000017 System.Boolean System.Uri::InFact(System.Uri_Flags)
extern void Uri_InFact_m4CE890C86FA34154A044516D2F3C9463389220D7 (void);
// 0x00000018 System.Boolean System.Uri::StaticNotAny(System.Uri_Flags,System.Uri_Flags)
extern void Uri_StaticNotAny_mC07A1201FBE032238FCFA96E9FB5D60AEDACCC5A (void);
// 0x00000019 System.Boolean System.Uri::StaticInFact(System.Uri_Flags,System.Uri_Flags)
extern void Uri_StaticInFact_m77BB2AE094534AFD7B9F68683C2A4356A75E39B8 (void);
// 0x0000001A System.Uri_UriInfo System.Uri::EnsureUriInfo()
extern void Uri_EnsureUriInfo_m4B46DF8611FA6D20D497D12D00544CFB466DCFA7 (void);
// 0x0000001B System.Void System.Uri::EnsureParseRemaining()
extern void Uri_EnsureParseRemaining_m33815B5767FAFADB762F7E39364E6432340F210B (void);
// 0x0000001C System.Void System.Uri::EnsureHostString(System.Boolean)
extern void Uri_EnsureHostString_m4BD63AA5A88CA09572A8A7CF3B2EDDE17EF9C720 (void);
// 0x0000001D System.Void System.Uri::.ctor(System.String)
extern void Uri__ctor_mBA69907A1D799CD12ED44B611985B25FE4C626A2 (void);
// 0x0000001E System.Void System.Uri::.ctor(System.String,System.UriKind)
extern void Uri__ctor_mA02DB222F4F35380DE2700D84F58EB42497FDDE4 (void);
// 0x0000001F System.Void System.Uri::.ctor(System.Uri,System.Uri)
extern void Uri__ctor_m42192656437FBEF1EEA8724D3EF2BB67DA0ED6BF (void);
// 0x00000020 System.ParsingError System.Uri::GetCombinedString(System.Uri,System.String,System.Boolean,System.String&)
extern void Uri_GetCombinedString_m7B95A90BC09E899CF41B0047E0B681FA7CEB8668 (void);
// 0x00000021 System.UriFormatException System.Uri::GetException(System.ParsingError)
extern void Uri_GetException_m2E833A8358C84BCF0397341160FADB1164290164 (void);
// 0x00000022 System.Void System.Uri::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Uri__ctor_m020E8051B3C0C9E60D8A868CBA0774B3FFB7C3FF (void);
// 0x00000023 System.Void System.Uri::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Uri_System_Runtime_Serialization_ISerializable_GetObjectData_mD4773E59427820077E86F2B298DA1386028DAC9C (void);
// 0x00000024 System.Void System.Uri::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Uri_GetObjectData_mC8CCD55C21CB624E369258E27A89F363F8271E68 (void);
// 0x00000025 System.String System.Uri::get_AbsoluteUri()
extern void Uri_get_AbsoluteUri_m4326730E572E7E3874021E802813EB6F49F7F99E (void);
// 0x00000026 System.Boolean System.Uri::get_IsUnc()
extern void Uri_get_IsUnc_m70B47E68BDAE06A7E5362DCE5AAD97C12119AB99 (void);
// 0x00000027 System.Boolean System.Uri::StaticIsFile(System.UriParser)
extern void Uri_StaticIsFile_mD270A5F6C8B59AAF6256B4565ABE5917ABA545E3 (void);
// 0x00000028 System.Object System.Uri::get_InitializeLock()
extern void Uri_get_InitializeLock_m45D6A11D14958E716715351E52207DCA808F00EE (void);
// 0x00000029 System.Void System.Uri::InitializeUriConfig()
extern void Uri_InitializeUriConfig_m1B2F98DF0BB1A48FEB328E9D8BF3C23B32196FE2 (void);
// 0x0000002A System.Int32 System.Uri::get_Port()
extern void Uri_get_Port_m4E64AB9B50CCC50E7B1F139D7AF1403FAF97147C (void);
// 0x0000002B System.String System.Uri::get_Scheme()
extern void Uri_get_Scheme_m14A8F0018D8AACADBEF39600A59944F33EE39187 (void);
// 0x0000002C System.Boolean System.Uri::get_OriginalStringSwitched()
extern void Uri_get_OriginalStringSwitched_m79E1C9F1C4E0ACCC85BB68841C167DDEA15CC72D (void);
// 0x0000002D System.String System.Uri::get_OriginalString()
extern void Uri_get_OriginalString_m56099E46276F0A52524347F1F46A2F88E948504F (void);
// 0x0000002E System.String System.Uri::get_DnsSafeHost()
extern void Uri_get_DnsSafeHost_mC2D93669288A9C05CC13EE5754CEBF2D74D04704 (void);
// 0x0000002F System.Boolean System.Uri::get_IsAbsoluteUri()
extern void Uri_get_IsAbsoluteUri_m8C189085F1C675DBC3148AA70C38074EC075D722 (void);
// 0x00000030 System.Boolean System.Uri::get_UserEscaped()
extern void Uri_get_UserEscaped_m8F29E9A593E84E66DD4AC06CBD5880B93A5F0307 (void);
// 0x00000031 System.Boolean System.Uri::IsGenDelim(System.Char)
extern void Uri_IsGenDelim_m376CCA5D00D019A69FD746C57D236A54EB9D3CF3 (void);
// 0x00000032 System.Boolean System.Uri::IsHexDigit(System.Char)
extern void Uri_IsHexDigit_m3B2881FA99F0B2197F8017E70C3AE6EBF9849836 (void);
// 0x00000033 System.Int32 System.Uri::FromHex(System.Char)
extern void Uri_FromHex_m9EAC76A5DBFED86532FF7E1BBD809176337A227B (void);
// 0x00000034 System.Int32 System.Uri::GetHashCode()
extern void Uri_GetHashCode_m06066B9059649A690C5B4DE58D32DF227933F515 (void);
// 0x00000035 System.String System.Uri::ToString()
extern void Uri_ToString_mB76863E11134B9635149E8E5F59AB75A74A760E2 (void);
// 0x00000036 System.Boolean System.Uri::op_Inequality(System.Uri,System.Uri)
extern void Uri_op_Inequality_m07015206F59460E87CDE2A8D303D5712E30A7F6B (void);
// 0x00000037 System.Boolean System.Uri::Equals(System.Object)
extern void Uri_Equals_m432A30F5E72A0F2B729AC051892BF9E1F4D26629 (void);
// 0x00000038 System.ParsingError System.Uri::ParseScheme(System.String,System.Uri_Flags&,System.UriParser&)
extern void Uri_ParseScheme_m61CAE16F1EC76725E5E0B23B09577F91BB223884 (void);
// 0x00000039 System.UriFormatException System.Uri::ParseMinimal()
extern void Uri_ParseMinimal_m35FCFE52F12315DA60733B807E7C0AB408C0A9CF (void);
// 0x0000003A System.ParsingError System.Uri::PrivateParseMinimal()
extern void Uri_PrivateParseMinimal_mE1DA461DDA053787906BBEC2BC2B3046B1B329F0 (void);
// 0x0000003B System.Void System.Uri::PrivateParseMinimalIri(System.String,System.UInt16)
extern void Uri_PrivateParseMinimalIri_m29F0CA367080586448C648332F59BED0096AB2D0 (void);
// 0x0000003C System.Void System.Uri::CreateUriInfo(System.Uri_Flags)
extern void Uri_CreateUriInfo_mC112D6E7002CA014AB6BEA878A66ECC46340FAAF (void);
// 0x0000003D System.Void System.Uri::CreateHostString()
extern void Uri_CreateHostString_m6FEC48641D3786D73B50D5DC792804C9A4D70C54 (void);
// 0x0000003E System.String System.Uri::CreateHostStringHelper(System.String,System.UInt16,System.UInt16,System.Uri_Flags&,System.String&)
extern void Uri_CreateHostStringHelper_m6C5EEA8BD2CDBCDD8A63FB74D3B801329EDE7BDD (void);
// 0x0000003F System.Void System.Uri::GetHostViaCustomSyntax()
extern void Uri_GetHostViaCustomSyntax_mD591A4A615803E70A03D7C75E7C114E4E460AED3 (void);
// 0x00000040 System.String System.Uri::GetParts(System.UriComponents,System.UriFormat)
extern void Uri_GetParts_mF5840DC010E6D420EB5A0722320EDAAEA2D0269F (void);
// 0x00000041 System.String System.Uri::GetEscapedParts(System.UriComponents)
extern void Uri_GetEscapedParts_m745615124808CB89A18D499988F4425F678938C4 (void);
// 0x00000042 System.String System.Uri::GetUnescapedParts(System.UriComponents,System.UriFormat)
extern void Uri_GetUnescapedParts_m051A75B5D2DDAE55F107457CA468EE9A2563FED3 (void);
// 0x00000043 System.String System.Uri::ReCreateParts(System.UriComponents,System.UInt16,System.UriFormat)
extern void Uri_ReCreateParts_mF50263ABC7D750E939B57BF61FA48A8762144FD7 (void);
// 0x00000044 System.String System.Uri::GetUriPartsFromUserString(System.UriComponents)
extern void Uri_GetUriPartsFromUserString_m95A7794F28625B6AFD514C08765C27CAAE4BD1B6 (void);
// 0x00000045 System.Void System.Uri::ParseRemaining()
extern void Uri_ParseRemaining_mBAE0F9850CD84965B3793B17444C677D77D58774 (void);
// 0x00000046 System.UInt16 System.Uri::ParseSchemeCheckImplicitFile(System.Char*,System.UInt16,System.ParsingError&,System.Uri_Flags&,System.UriParser&)
extern void Uri_ParseSchemeCheckImplicitFile_m92A658AE6C04E038058AD8E9581A41B06B6D6243 (void);
// 0x00000047 System.Boolean System.Uri::CheckKnownSchemes(System.Int64*,System.UInt16,System.UriParser&)
extern void Uri_CheckKnownSchemes_mCA95AE251E7C9208570543B446385BCF2C727E8D (void);
// 0x00000048 System.ParsingError System.Uri::CheckSchemeSyntax(System.Char*,System.UInt16,System.UriParser&)
extern void Uri_CheckSchemeSyntax_m1181D9BEA35D9D22852FD2FE815CABB267BA5A8F (void);
// 0x00000049 System.UInt16 System.Uri::CheckAuthorityHelper(System.Char*,System.UInt16,System.UInt16,System.ParsingError&,System.Uri_Flags&,System.UriParser,System.String&)
extern void Uri_CheckAuthorityHelper_m5046CE781115A54CAE3ACD2C03987F526A761387 (void);
// 0x0000004A System.Void System.Uri::CheckAuthorityHelperHandleDnsIri(System.Char*,System.UInt16,System.Int32,System.Int32,System.Boolean,System.Boolean,System.UriParser,System.String,System.Uri_Flags&,System.Boolean&,System.String&,System.ParsingError&)
extern void Uri_CheckAuthorityHelperHandleDnsIri_m366E36029D4C9A00C0F216055B15F5E4805AED28 (void);
// 0x0000004B System.Void System.Uri::CheckAuthorityHelperHandleAnyHostIri(System.Char*,System.Int32,System.Int32,System.Boolean,System.Boolean,System.UriParser,System.Uri_Flags&,System.String&,System.ParsingError&)
extern void Uri_CheckAuthorityHelperHandleAnyHostIri_m76FEA31E3FEDF3D1614987C6484ECF15022AE9D8 (void);
// 0x0000004C System.Void System.Uri::FindEndOfComponent(System.String,System.UInt16&,System.UInt16,System.Char)
extern void Uri_FindEndOfComponent_mF276ABD008291C1FDC4B433A2F274058D06D8A6B (void);
// 0x0000004D System.Void System.Uri::FindEndOfComponent(System.Char*,System.UInt16&,System.UInt16,System.Char)
extern void Uri_FindEndOfComponent_mDCDF860C405E9F31F7CFE9AFFE7C096812697AEF (void);
// 0x0000004E System.Uri_Check System.Uri::CheckCanonical(System.Char*,System.UInt16&,System.UInt16,System.Char)
extern void Uri_CheckCanonical_mED3910E55213D1DFEAA5B33079E3A89D369B10B6 (void);
// 0x0000004F System.Char[] System.Uri::GetCanonicalPath(System.Char[],System.Int32&,System.UriFormat)
extern void Uri_GetCanonicalPath_mDE02BFA56EDD09479DDB2A5A50F6DF5210CA73F2 (void);
// 0x00000050 System.Void System.Uri::UnescapeOnly(System.Char*,System.Int32,System.Int32&,System.Char,System.Char,System.Char)
extern void Uri_UnescapeOnly_mB8F87981CDD4CFBFCD97EE668FF281CE26453F21 (void);
// 0x00000051 System.Char[] System.Uri::Compress(System.Char[],System.UInt16,System.Int32&,System.UriParser)
extern void Uri_Compress_m02224082A9665F07D35AB6EB6E3198642F9E7BCF (void);
// 0x00000052 System.Int32 System.Uri::CalculateCaseInsensitiveHashCode(System.String)
extern void Uri_CalculateCaseInsensitiveHashCode_m634FFDF8FCD81DECCB87161B153D1093C0A6FCE4 (void);
// 0x00000053 System.String System.Uri::CombineUri(System.Uri,System.String,System.UriFormat)
extern void Uri_CombineUri_m77B7B8B856CF8100E51250247930963E7C544F91 (void);
// 0x00000054 System.Boolean System.Uri::IsLWS(System.Char)
extern void Uri_IsLWS_m7A9F3B969CCEE56B9F98E40F1903C737DA7DF0D6 (void);
// 0x00000055 System.Boolean System.Uri::IsAsciiLetter(System.Char)
extern void Uri_IsAsciiLetter_m93435A20DF4DEE153B87B26D07B9963F1BF4F373 (void);
// 0x00000056 System.Boolean System.Uri::IsAsciiLetterOrDigit(System.Char)
extern void Uri_IsAsciiLetterOrDigit_mEBA81E735141504B5804F0B3C94EC39B24AF8661 (void);
// 0x00000057 System.Boolean System.Uri::IsBidiControlCharacter(System.Char)
extern void Uri_IsBidiControlCharacter_mB14EA5816A434B7CE382EB9ACBD1432916EC341D (void);
// 0x00000058 System.String System.Uri::StripBidiControlCharacter(System.Char*,System.Int32,System.Int32)
extern void Uri_StripBidiControlCharacter_m49D782826401F99D943C1AD76A75125879FF332F (void);
// 0x00000059 System.Void System.Uri::CreateThis(System.String,System.Boolean,System.UriKind)
extern void Uri_CreateThis_mCB3DC849A426498E9CCD249850CBC69C9D67D864 (void);
// 0x0000005A System.Void System.Uri::InitializeUri(System.ParsingError,System.UriKind,System.UriFormatException&)
extern void Uri_InitializeUri_m5D99BD8533F3FAAD479B1193505B5B19B8C2F2DE (void);
// 0x0000005B System.Boolean System.Uri::CheckForConfigLoad(System.String)
extern void Uri_CheckForConfigLoad_m13002EFBBFD437183ED0A7FCBE5681C510996B0F (void);
// 0x0000005C System.Boolean System.Uri::CheckForUnicode(System.String)
extern void Uri_CheckForUnicode_m78E4938E82EE352BD5D8493AE0314224BC2543CD (void);
// 0x0000005D System.Boolean System.Uri::CheckForEscapedUnreserved(System.String)
extern void Uri_CheckForEscapedUnreserved_mFE708A44EC74C7E773B96B82CD9A5DF25EF97D4A (void);
// 0x0000005E System.Boolean System.Uri::TryCreate(System.String,System.UriKind,System.Uri&)
extern void Uri_TryCreate_mEEB6736FEDAF52AAE36ACC1EA1EC8CEBB7C52DAB (void);
// 0x0000005F System.String System.Uri::GetComponents(System.UriComponents,System.UriFormat)
extern void Uri_GetComponents_m0346CA8037531DE1FC630775E0BD1F5D1E7920B6 (void);
// 0x00000060 System.String System.Uri::UnescapeDataString(System.String)
extern void Uri_UnescapeDataString_mE1F40FC5CA3FF03DEE9EB01E3D8BD502D36A284D (void);
// 0x00000061 System.String System.Uri::EscapeUnescapeIri(System.String,System.Int32,System.Int32,System.UriComponents)
extern void Uri_EscapeUnescapeIri_mDE5E4BAE74E2C2373AD186732FEE7AD6E0EA7180 (void);
// 0x00000062 System.Void System.Uri::.ctor(System.Uri_Flags,System.UriParser,System.String)
extern void Uri__ctor_m4605489523A7A973459720C1BBE4039FD10557CD (void);
// 0x00000063 System.Uri System.Uri::CreateHelper(System.String,System.Boolean,System.UriKind,System.UriFormatException&)
extern void Uri_CreateHelper_m024137C47351CA9959E4AC66F9443AEEE87D89C0 (void);
// 0x00000064 System.Uri System.Uri::ResolveHelper(System.Uri,System.Uri,System.String&,System.Boolean&,System.UriFormatException&)
extern void Uri_ResolveHelper_mEDF1549C3E9AC1CF6177DCF93B17D574411916BC (void);
// 0x00000065 System.String System.Uri::GetRelativeSerializationString(System.UriFormat)
extern void Uri_GetRelativeSerializationString_m5D0CD02E255BB96532F056BB382CF7D74D62BE58 (void);
// 0x00000066 System.String System.Uri::GetComponentsHelper(System.UriComponents,System.UriFormat)
extern void Uri_GetComponentsHelper_m28B0D80FD94A40685C0F70652AB26755C457B2D3 (void);
// 0x00000067 System.Void System.Uri::CreateThisFromUri(System.Uri)
extern void Uri_CreateThisFromUri_m9A4AE7CD70F7EDE9154634057EBE600E74A5D544 (void);
// 0x00000068 System.Void System.Uri::.cctor()
extern void Uri__cctor_m2B8179039C09C64936CF8262E3EF4A7E7C2F90F2 (void);
// 0x00000069 System.Void System.Uri_UriInfo::.ctor()
extern void UriInfo__ctor_m24EFE7B4E03C9FFB8B797770D626680947C87D98 (void);
// 0x0000006A System.Void System.Uri_MoreInfo::.ctor()
extern void MoreInfo__ctor_mFE29F028646C12EDCAF7F0F78F9A85D52C10B83C (void);
// 0x0000006B System.Void System.UriFormatException::.ctor()
extern void UriFormatException__ctor_mBA5F8C423C09F600B1AF895521C892EA356CA424 (void);
// 0x0000006C System.Void System.UriFormatException::.ctor(System.String)
extern void UriFormatException__ctor_mE1D46962CC168EB07B59D1265F5734A8F587567D (void);
// 0x0000006D System.Void System.UriFormatException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void UriFormatException__ctor_mE7F5B073E9F9DB5F22536C54959BEB0D1E7DA1D5 (void);
// 0x0000006E System.Void System.UriFormatException::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_mED4C06AC35B7F94955ECC0D8F00383888C1127DC (void);
// 0x0000006F System.Char[] System.UriHelper::EscapeString(System.String,System.Int32,System.Int32,System.Char[],System.Int32&,System.Boolean,System.Char,System.Char,System.Char)
extern void UriHelper_EscapeString_mF0077A016F05127923308DF7E7E99BD7B9837E8B (void);
// 0x00000070 System.Char[] System.UriHelper::EnsureDestinationSize(System.Char*,System.Char[],System.Int32,System.Int16,System.Int16,System.Int32&,System.Int32)
extern void UriHelper_EnsureDestinationSize_m64F4907D0411AAAD1C05E0AD0D2EB120DCBA9217 (void);
// 0x00000071 System.Char[] System.UriHelper::UnescapeString(System.String,System.Int32,System.Int32,System.Char[],System.Int32&,System.Char,System.Char,System.Char,System.UnescapeMode,System.UriParser,System.Boolean)
extern void UriHelper_UnescapeString_mC172F713349E3D22985A92BC4F5B51D0BCEE61AF (void);
// 0x00000072 System.Char[] System.UriHelper::UnescapeString(System.Char*,System.Int32,System.Int32,System.Char[],System.Int32&,System.Char,System.Char,System.Char,System.UnescapeMode,System.UriParser,System.Boolean)
extern void UriHelper_UnescapeString_mD4815AEAF34E25D31AA4BB4A76B88055F0A49E89 (void);
// 0x00000073 System.Void System.UriHelper::MatchUTF8Sequence(System.Char*,System.Char[],System.Int32&,System.Char[],System.Int32,System.Byte[],System.Int32,System.Boolean,System.Boolean)
extern void UriHelper_MatchUTF8Sequence_m4835D9BB77C2701643B14D6FFD3D7057F8C9007F (void);
// 0x00000074 System.Void System.UriHelper::EscapeAsciiChar(System.Char,System.Char[],System.Int32&)
extern void UriHelper_EscapeAsciiChar_mFD7DE796BD53CBD2B1E73080FE0346D37F358902 (void);
// 0x00000075 System.Char System.UriHelper::EscapedAscii(System.Char,System.Char)
extern void UriHelper_EscapedAscii_m06D556717795E649EBBB30E4CBCF3D221C1FEB78 (void);
// 0x00000076 System.Boolean System.UriHelper::IsNotSafeForUnescape(System.Char)
extern void UriHelper_IsNotSafeForUnescape_m1D0461E7C5A3CFBD7A2A7F7322B66BC68CCE741D (void);
// 0x00000077 System.Boolean System.UriHelper::IsReservedUnreservedOrHash(System.Char)
extern void UriHelper_IsReservedUnreservedOrHash_m3D7256DABA7F540F8D379FC1D1C54F1C63E46059 (void);
// 0x00000078 System.Boolean System.UriHelper::IsUnreserved(System.Char)
extern void UriHelper_IsUnreserved_mAADC7DCEEA864AFB49311696ABBDD76811FAAE48 (void);
// 0x00000079 System.Boolean System.UriHelper::Is3986Unreserved(System.Char)
extern void UriHelper_Is3986Unreserved_m3799F2ADA8C63DDB4995F82B974C8EC1DEEBA76A (void);
// 0x0000007A System.Void System.UriHelper::.cctor()
extern void UriHelper__cctor_m9537B8AAAA1D6EF77D29A179EC79F5511C662F27 (void);
// 0x0000007B System.String System.UriParser::get_SchemeName()
extern void UriParser_get_SchemeName_mFC9EFD71512A64E640866792CCB7DAC5187DE9F1 (void);
// 0x0000007C System.Int32 System.UriParser::get_DefaultPort()
extern void UriParser_get_DefaultPort_m050510870CCD4DD08DF7E98E2AF3D616446AD99D (void);
// 0x0000007D System.UriParser System.UriParser::OnNewUri()
extern void UriParser_OnNewUri_m7D55337A7A9B6B67FB0AD7CA96F472751EF5A897 (void);
// 0x0000007E System.Void System.UriParser::InitializeAndValidate(System.Uri,System.UriFormatException&)
extern void UriParser_InitializeAndValidate_m3E31D86FEE445E313BB7141F760626301767A0E0 (void);
// 0x0000007F System.String System.UriParser::Resolve(System.Uri,System.Uri,System.UriFormatException&)
extern void UriParser_Resolve_mF21D3AA42AB1EC2B173617D76E4041EB3481D979 (void);
// 0x00000080 System.String System.UriParser::GetComponents(System.Uri,System.UriComponents,System.UriFormat)
extern void UriParser_GetComponents_m8A226F43638FA7CD135A651CDE3D4E475E8FC181 (void);
// 0x00000081 System.Boolean System.UriParser::get_ShouldUseLegacyV2Quirks()
extern void UriParser_get_ShouldUseLegacyV2Quirks_mD4C8DF67677ACCCC3B5E026099ECC0BDA24D96DD (void);
// 0x00000082 System.Void System.UriParser::.cctor()
extern void UriParser__cctor_m00C2855D5C8C07790C5627BBB90AC84A7E8B6BC2 (void);
// 0x00000083 System.UriSyntaxFlags System.UriParser::get_Flags()
extern void UriParser_get_Flags_mBCF4C3E94892F00B6E8856BFED1B650FB6A0C039 (void);
// 0x00000084 System.Boolean System.UriParser::NotAny(System.UriSyntaxFlags)
extern void UriParser_NotAny_mC998A35DC290F35FFAFFB6A8B66C7B881F2559D3 (void);
// 0x00000085 System.Boolean System.UriParser::InFact(System.UriSyntaxFlags)
extern void UriParser_InFact_mDD42FA932B6830D99AA04C2AE7875BA5067C86F3 (void);
// 0x00000086 System.Boolean System.UriParser::IsAllSet(System.UriSyntaxFlags)
extern void UriParser_IsAllSet_m74BEC412DC8AF3B1A33E11964EBB3164D9D8C77E (void);
// 0x00000087 System.Boolean System.UriParser::IsFullMatch(System.UriSyntaxFlags,System.UriSyntaxFlags)
extern void UriParser_IsFullMatch_m7B5F47A62FA721E550C5439FAA4C6AFAC34EB23E (void);
// 0x00000088 System.Void System.UriParser::.ctor(System.UriSyntaxFlags)
extern void UriParser__ctor_mAF168F2B88BC5301B722C1BAAD45E381FBA22E3D (void);
// 0x00000089 System.UriParser System.UriParser::FindOrFetchAsUnknownV1Syntax(System.String)
extern void UriParser_FindOrFetchAsUnknownV1Syntax_m3A57CA15FE27DC7982F186E8321B810B56EBD9AD (void);
// 0x0000008A System.Boolean System.UriParser::get_IsSimple()
extern void UriParser_get_IsSimple_mDDB03A5F6EEE6E92926A386655E5BBD553719B9C (void);
// 0x0000008B System.UriParser System.UriParser::InternalOnNewUri()
extern void UriParser_InternalOnNewUri_m7D55F5CD59A3B9BF57BC68F715A27CC1A44566CA (void);
// 0x0000008C System.Void System.UriParser::InternalValidate(System.Uri,System.UriFormatException&)
extern void UriParser_InternalValidate_mF2FEB0E76E48B621EB2058FBE7DCC6A42A1681E2 (void);
// 0x0000008D System.String System.UriParser::InternalResolve(System.Uri,System.Uri,System.UriFormatException&)
extern void UriParser_InternalResolve_m2A027789CB5105E32B09810E81810E8E35DD1F26 (void);
// 0x0000008E System.String System.UriParser::InternalGetComponents(System.Uri,System.UriComponents,System.UriFormat)
extern void UriParser_InternalGetComponents_mFD4B211C71E0506AE4E4E99D92ECAF1780CE4674 (void);
// 0x0000008F System.Void System.UriParser_BuiltInUriParser::.ctor(System.String,System.Int32,System.UriSyntaxFlags)
extern void BuiltInUriParser__ctor_m66250DC53CE01410149D46279D0B413FC1C5CA1C (void);
// 0x00000090 System.String System.DomainNameHelper::ParseCanonicalName(System.String,System.Int32,System.Int32,System.Boolean&)
extern void DomainNameHelper_ParseCanonicalName_mFE738FD1237E2D9D9A1B27BA73F58B1689D451E4 (void);
// 0x00000091 System.Boolean System.DomainNameHelper::IsValid(System.Char*,System.UInt16,System.Int32&,System.Boolean&,System.Boolean)
extern void DomainNameHelper_IsValid_mE9672A824F71E32116358C5FA029789855A4B461 (void);
// 0x00000092 System.Boolean System.DomainNameHelper::IsValidByIri(System.Char*,System.UInt16,System.Int32&,System.Boolean&,System.Boolean)
extern void DomainNameHelper_IsValidByIri_m13E2A6D9EBD42326C096F2423DBB0014763D47BF (void);
// 0x00000093 System.String System.DomainNameHelper::IdnEquivalent(System.Char*,System.Int32,System.Int32,System.Boolean&,System.Boolean&)
extern void DomainNameHelper_IdnEquivalent_m439593BAF7C6C801F577E7C27B0C4FBB1772E49F (void);
// 0x00000094 System.String System.DomainNameHelper::IdnEquivalent(System.Char*,System.Int32,System.Int32,System.Boolean&,System.String&)
extern void DomainNameHelper_IdnEquivalent_m459BFF3040F8E6BFE1CE1C6432A1343A2ECF2F57 (void);
// 0x00000095 System.Boolean System.DomainNameHelper::IsIdnAce(System.String,System.Int32)
extern void DomainNameHelper_IsIdnAce_m2231C778C4CCE141ACDC412737642CC365307445 (void);
// 0x00000096 System.Boolean System.DomainNameHelper::IsIdnAce(System.Char*,System.Int32)
extern void DomainNameHelper_IsIdnAce_m9193B7D824FC6965820FCE980FEE3E0B40EA94B8 (void);
// 0x00000097 System.String System.DomainNameHelper::UnicodeEquivalent(System.String,System.Char*,System.Int32,System.Int32)
extern void DomainNameHelper_UnicodeEquivalent_mA80E5FF3AD6AFBB9FC257ED1C4F0D31C8F0EFEC3 (void);
// 0x00000098 System.String System.DomainNameHelper::UnicodeEquivalent(System.Char*,System.Int32,System.Int32,System.Boolean&,System.Boolean&)
extern void DomainNameHelper_UnicodeEquivalent_mD5A7A659B82F1FBF7ABF30009117CFBF8BC4D55F (void);
// 0x00000099 System.Boolean System.DomainNameHelper::IsASCIILetterOrDigit(System.Char,System.Boolean&)
extern void DomainNameHelper_IsASCIILetterOrDigit_mD3B0B9BD4573FADEF6AC7330A5EC58C220455F01 (void);
// 0x0000009A System.Boolean System.DomainNameHelper::IsValidDomainLabelCharacter(System.Char,System.Boolean&)
extern void DomainNameHelper_IsValidDomainLabelCharacter_mF6DEB20D9D03A8728B1C58006C40D6603B7D61D1 (void);
// 0x0000009B System.String System.IPv4AddressHelper::ParseCanonicalName(System.String,System.Int32,System.Int32,System.Boolean&)
extern void IPv4AddressHelper_ParseCanonicalName_m2A8C35045CE02D6FC2C4251F239D1C0074E0E813 (void);
// 0x0000009C System.Int32 System.IPv4AddressHelper::ParseHostNumber(System.String,System.Int32,System.Int32)
extern void IPv4AddressHelper_ParseHostNumber_m798FB6828971F70775D1125565A1D1025C897F14 (void);
// 0x0000009D System.Boolean System.IPv4AddressHelper::IsValid(System.Char*,System.Int32,System.Int32&,System.Boolean,System.Boolean,System.Boolean)
extern void IPv4AddressHelper_IsValid_mD96D91E0F3830414F4601A4521E71DE832A45843 (void);
// 0x0000009E System.Boolean System.IPv4AddressHelper::IsValidCanonical(System.Char*,System.Int32,System.Int32&,System.Boolean,System.Boolean)
extern void IPv4AddressHelper_IsValidCanonical_mC27E31F1F043D68BC52719892D34EDDC7851B120 (void);
// 0x0000009F System.Int64 System.IPv4AddressHelper::ParseNonCanonical(System.Char*,System.Int32,System.Int32&,System.Boolean)
extern void IPv4AddressHelper_ParseNonCanonical_mDCD1CD7FB85C4FFBF3070B1435A0D632C1A7B97E (void);
// 0x000000A0 System.Boolean System.IPv4AddressHelper::Parse(System.String,System.Byte*,System.Int32,System.Int32)
extern void IPv4AddressHelper_Parse_m08110623FAC14806376148D7C16AB95A428EA6CF (void);
// 0x000000A1 System.Boolean System.IPv4AddressHelper::ParseCanonical(System.String,System.Byte*,System.Int32,System.Int32)
extern void IPv4AddressHelper_ParseCanonical_m9D4552558C934E373D188DDA0BC1D1DEF5A62C33 (void);
// 0x000000A2 System.String System.IPv6AddressHelper::ParseCanonicalName(System.String,System.Int32,System.Boolean&,System.String&)
extern void IPv6AddressHelper_ParseCanonicalName_m3944530A7B686031653F97824EF712424E0BEE14 (void);
// 0x000000A3 System.String System.IPv6AddressHelper::CreateCanonicalName(System.UInt16*)
extern void IPv6AddressHelper_CreateCanonicalName_m0B1C201DFADBEB58869E0BE8BFA967EEE64B096A (void);
// 0x000000A4 System.Collections.Generic.KeyValuePair`2<System.Int32,System.Int32> System.IPv6AddressHelper::FindCompressionRange(System.UInt16*)
extern void IPv6AddressHelper_FindCompressionRange_mE70B131DDA05D3059325246A5AB7F6029B6EF6BD (void);
// 0x000000A5 System.Boolean System.IPv6AddressHelper::ShouldHaveIpv4Embedded(System.UInt16*)
extern void IPv6AddressHelper_ShouldHaveIpv4Embedded_m262634E9099141536C00213C1CFC123665A641DE (void);
// 0x000000A6 System.Boolean System.IPv6AddressHelper::InternalIsValid(System.Char*,System.Int32,System.Int32&,System.Boolean)
extern void IPv6AddressHelper_InternalIsValid_m3BD7E7524455146D4464037DA3B65530E547AB7A (void);
// 0x000000A7 System.Boolean System.IPv6AddressHelper::IsValid(System.Char*,System.Int32,System.Int32&)
extern void IPv6AddressHelper_IsValid_m2383F1A867665B04A4F2B8D82FF2B62BE51C2289 (void);
// 0x000000A8 System.Boolean System.IPv6AddressHelper::Parse(System.String,System.UInt16*,System.Int32,System.String&)
extern void IPv6AddressHelper_Parse_m36CE2F56465C4F9F7791E80E954C7C0ECBD16DFB (void);
// 0x000000A9 System.String System.UncNameHelper::ParseCanonicalName(System.String,System.Int32,System.Int32,System.Boolean&)
extern void UncNameHelper_ParseCanonicalName_mCBE64015FD1B6B4829CEAA89625C1D44E280E37E (void);
// 0x000000AA System.Boolean System.UncNameHelper::IsValid(System.Char*,System.UInt16,System.Int32&,System.Boolean)
extern void UncNameHelper_IsValid_m4055361D79684EE7B098C055B2E9068EE06F1EF6 (void);
// 0x000000AB System.Void System.IOAsyncCallback::.ctor(System.Object,System.IntPtr)
extern void IOAsyncCallback__ctor_m1010BF5234B0ECC2FEB54105BA15B313633C1985 (void);
// 0x000000AC System.Void System.IOAsyncCallback::Invoke(System.IOAsyncResult)
extern void IOAsyncCallback_Invoke_mB95F7E7F0E8326CE5364A30F42FC1073B0AB2D8B (void);
// 0x000000AD System.IAsyncResult System.IOAsyncCallback::BeginInvoke(System.IOAsyncResult,System.AsyncCallback,System.Object)
extern void IOAsyncCallback_BeginInvoke_mB8CACF8990B91DF4A695E597CEBE4BA09354C32C (void);
// 0x000000AE System.Void System.IOAsyncCallback::EndInvoke(System.IAsyncResult)
extern void IOAsyncCallback_EndInvoke_m397237D5497A9029CC3FACE692D11BDC1558A727 (void);
// 0x000000AF System.Void System.UriTypeConverter::.ctor()
extern void UriTypeConverter__ctor_m1CAEEF1C615B28212B83C76D892938E0A77D3A64 (void);
// 0x000000B0 System.Void System.Text.RegularExpressions.Regex::.ctor()
extern void Regex__ctor_mFDE4B6A423C15AA60BF9FEC7D4D7DFD4657D7C6E (void);
// 0x000000B1 System.Void System.Text.RegularExpressions.Regex::.ctor(System.String)
extern void Regex__ctor_m2769A5BA7B7A835514F6C0E4D30FAD467C6B1B0C (void);
// 0x000000B2 System.Void System.Text.RegularExpressions.Regex::.ctor(System.String,System.Text.RegularExpressions.RegexOptions)
extern void Regex__ctor_mEF4515C4C44DF8BE410F388C82CC679D743FB5CD (void);
// 0x000000B3 System.Void System.Text.RegularExpressions.Regex::.ctor(System.String,System.Text.RegularExpressions.RegexOptions,System.TimeSpan,System.Boolean)
extern void Regex__ctor_m87918FB2A856E264A492D2A2B4B412BE4E2370BB (void);
// 0x000000B4 System.Void System.Text.RegularExpressions.Regex::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Regex__ctor_mF11825F6E24D7D780BD34C74C96392DEC3602A5D (void);
// 0x000000B5 System.Void System.Text.RegularExpressions.Regex::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Regex_System_Runtime_Serialization_ISerializable_GetObjectData_m95B0E2523A72DF6AC56DEA7CDA286F771E06B0FD (void);
// 0x000000B6 System.Void System.Text.RegularExpressions.Regex::ValidateMatchTimeout(System.TimeSpan)
extern void Regex_ValidateMatchTimeout_m71FE7188780DEAD57093B7345CCC50D0159218BE (void);
// 0x000000B7 System.TimeSpan System.Text.RegularExpressions.Regex::InitDefaultMatchTimeout()
extern void Regex_InitDefaultMatchTimeout_mC91736B02BD12B92CBD93C329E7A8233CD0B9DA4 (void);
// 0x000000B8 System.Text.RegularExpressions.RegexOptions System.Text.RegularExpressions.Regex::get_Options()
extern void Regex_get_Options_m823A30690EEA63798DB8497F3E9CF062412B8653 (void);
// 0x000000B9 System.TimeSpan System.Text.RegularExpressions.Regex::get_MatchTimeout()
extern void Regex_get_MatchTimeout_mD484D1CF0B6BF8516A08991D1387761CAE2340D6 (void);
// 0x000000BA System.Boolean System.Text.RegularExpressions.Regex::get_RightToLeft()
extern void Regex_get_RightToLeft_m546BF531C94563A11427CD24367525462CDB4509 (void);
// 0x000000BB System.String System.Text.RegularExpressions.Regex::ToString()
extern void Regex_ToString_mF967EF5E8BD74C3692379B8436AB8D3C5963FA75 (void);
// 0x000000BC System.Text.RegularExpressions.Match System.Text.RegularExpressions.Regex::Match(System.String,System.Int32)
extern void Regex_Match_mA36A33D32F895CE84957DC7DA82E2CD45EF19EEA (void);
// 0x000000BD System.String System.Text.RegularExpressions.Regex::Replace(System.String,System.String,System.String)
extern void Regex_Replace_mB4E5642068CF8B6DFA3C3C6E21E8AD33AED12223 (void);
// 0x000000BE System.String System.Text.RegularExpressions.Regex::Replace(System.String,System.String,System.String,System.Text.RegularExpressions.RegexOptions,System.TimeSpan)
extern void Regex_Replace_mD7649C6657458BEAA6B18E2BEB158ECA320A4609 (void);
// 0x000000BF System.String System.Text.RegularExpressions.Regex::Replace(System.String,System.String)
extern void Regex_Replace_m57129CA8DD318E87C364526DCF0157AD7A4933CB (void);
// 0x000000C0 System.String System.Text.RegularExpressions.Regex::Replace(System.String,System.String,System.Int32,System.Int32)
extern void Regex_Replace_mF5075A8D78C9AD734DBE740479A6C1F7F9078D73 (void);
// 0x000000C1 System.Void System.Text.RegularExpressions.Regex::InitializeReferences()
extern void Regex_InitializeReferences_m2CD000C1AFAA8B214F32D989C7D116B684A31840 (void);
// 0x000000C2 System.Text.RegularExpressions.Match System.Text.RegularExpressions.Regex::Run(System.Boolean,System.Int32,System.String,System.Int32,System.Int32,System.Int32)
extern void Regex_Run_m74FB5EF178DF43F88B9058B94939F557479B93FC (void);
// 0x000000C3 System.Text.RegularExpressions.CachedCodeEntry System.Text.RegularExpressions.Regex::LookupCachedAndUpdate(System.String)
extern void Regex_LookupCachedAndUpdate_m88CA03797C5ED796BD5E1319DF6B1B6B6FCE6C0D (void);
// 0x000000C4 System.Text.RegularExpressions.CachedCodeEntry System.Text.RegularExpressions.Regex::CacheCode(System.String)
extern void Regex_CacheCode_m68F93FF3B918776D190D4DB807A3323691C77F0A (void);
// 0x000000C5 System.Boolean System.Text.RegularExpressions.Regex::UseOptionR()
extern void Regex_UseOptionR_m84945EDBEDCD61DBCEB691C929CA28F4B0AF4B49 (void);
// 0x000000C6 System.Boolean System.Text.RegularExpressions.Regex::UseOptionInvariant()
extern void Regex_UseOptionInvariant_m0CA185DBDB15932BB8A8B4F53EB8ACECEC006566 (void);
// 0x000000C7 System.Void System.Text.RegularExpressions.Regex::.cctor()
extern void Regex__cctor_m86CE9B8D0FF5F2B54D4FF27D2213A1E6917477DF (void);
// 0x000000C8 System.Void System.Text.RegularExpressions.CachedCodeEntry::.ctor(System.String,System.Collections.Hashtable,System.String[],System.Text.RegularExpressions.RegexCode,System.Collections.Hashtable,System.Int32,System.Text.RegularExpressions.ExclusiveReference,System.Text.RegularExpressions.SharedReference)
extern void CachedCodeEntry__ctor_m78BCA6060E7D83B172F998AF60D17FB41BE703B8 (void);
// 0x000000C9 System.Object System.Text.RegularExpressions.ExclusiveReference::Get()
extern void ExclusiveReference_Get_mE79B077388AFBD19A4524E630701783E7DCE61E4 (void);
// 0x000000CA System.Void System.Text.RegularExpressions.ExclusiveReference::Release(System.Object)
extern void ExclusiveReference_Release_m9A1577138872106EA54A04EA4AB77F710CEDE336 (void);
// 0x000000CB System.Void System.Text.RegularExpressions.ExclusiveReference::.ctor()
extern void ExclusiveReference__ctor_m0427943C75CBB283EF26034339E3D412A080B5D7 (void);
// 0x000000CC System.Object System.Text.RegularExpressions.SharedReference::Get()
extern void SharedReference_Get_m4133101195827AC22016F903F8F945C249E4FCA1 (void);
// 0x000000CD System.Void System.Text.RegularExpressions.SharedReference::Cache(System.Object)
extern void SharedReference_Cache_mEFA6A88B206EAFEAD6222E239A03BD6E4B244430 (void);
// 0x000000CE System.Void System.Text.RegularExpressions.SharedReference::.ctor()
extern void SharedReference__ctor_m48E749BC646BEC89282B8F336325D42DE48CFC81 (void);
// 0x000000CF System.Void System.Text.RegularExpressions.RegexBoyerMoore::.ctor(System.String,System.Boolean,System.Boolean,System.Globalization.CultureInfo)
extern void RegexBoyerMoore__ctor_m39674FB18BB75DD891AAE3781FDA0CCDDEBC2F8C (void);
// 0x000000D0 System.Boolean System.Text.RegularExpressions.RegexBoyerMoore::MatchPattern(System.String,System.Int32)
extern void RegexBoyerMoore_MatchPattern_m41D57E11972B2142649662886DA145AFE396F602 (void);
// 0x000000D1 System.Boolean System.Text.RegularExpressions.RegexBoyerMoore::IsMatch(System.String,System.Int32,System.Int32,System.Int32)
extern void RegexBoyerMoore_IsMatch_m820D06ED51C062451AFAF22682D2EB06C8DFABD9 (void);
// 0x000000D2 System.Int32 System.Text.RegularExpressions.RegexBoyerMoore::Scan(System.String,System.Int32,System.Int32,System.Int32)
extern void RegexBoyerMoore_Scan_m204A42056131A694B6D31FC69563355788CABD67 (void);
// 0x000000D3 System.String System.Text.RegularExpressions.RegexBoyerMoore::ToString()
extern void RegexBoyerMoore_ToString_mB0A62E68E8A3CAC5CE3AC45E1C54FA72DFB626F6 (void);
// 0x000000D4 System.Void System.Text.RegularExpressions.Capture::.ctor(System.String,System.Int32,System.Int32)
extern void Capture__ctor_m6CC8A5385C7BD6B8AE63F9812293EC3252A65B3B (void);
// 0x000000D5 System.Int32 System.Text.RegularExpressions.Capture::get_Index()
extern void Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31 (void);
// 0x000000D6 System.Int32 System.Text.RegularExpressions.Capture::get_Length()
extern void Capture_get_Length_mB41E1D86823156F57D3FE0B9F31BF3C6DD3D3C94 (void);
// 0x000000D7 System.String System.Text.RegularExpressions.Capture::get_Value()
extern void Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C (void);
// 0x000000D8 System.String System.Text.RegularExpressions.Capture::ToString()
extern void Capture_ToString_mD49A28CAD5727E8F629643EDE0C6BAB476BA639E (void);
// 0x000000D9 System.String System.Text.RegularExpressions.Capture::GetOriginalString()
extern void Capture_GetOriginalString_m35D3CD7902B7BC29E00AD043D8784FFE4E67539F (void);
// 0x000000DA System.String System.Text.RegularExpressions.Capture::GetLeftSubstring()
extern void Capture_GetLeftSubstring_mF82C23C9E17F3F048605955F76B9D69C3E82FCD7 (void);
// 0x000000DB System.String System.Text.RegularExpressions.Capture::GetRightSubstring()
extern void Capture_GetRightSubstring_m1A17502FFAE73FC4D35540716DB2311717267D5E (void);
// 0x000000DC System.Void System.Text.RegularExpressions.Capture::.ctor()
extern void Capture__ctor_m3ED807279C93FFCE8BE4EAF447DA01E62EF93D7B (void);
// 0x000000DD System.Void System.Text.RegularExpressions.RegexCharClass::.cctor()
extern void RegexCharClass__cctor_m5170E52D9864BA712125FB33F309FE9E37869EA8 (void);
// 0x000000DE System.Void System.Text.RegularExpressions.RegexCharClass::.ctor()
extern void RegexCharClass__ctor_mAA44510F3E5001A8612355B4FFB718D9DDC74264 (void);
// 0x000000DF System.Void System.Text.RegularExpressions.RegexCharClass::.ctor(System.Boolean,System.Collections.Generic.List`1<System.Text.RegularExpressions.RegexCharClass_SingleRange>,System.Text.StringBuilder,System.Text.RegularExpressions.RegexCharClass)
extern void RegexCharClass__ctor_mB05A6CC8015C5D545C639682454A524DE7E2EA97 (void);
// 0x000000E0 System.Boolean System.Text.RegularExpressions.RegexCharClass::get_CanMerge()
extern void RegexCharClass_get_CanMerge_mC27A4CF83CFBEF3741A3DB4F99ABA6DE76B57837 (void);
// 0x000000E1 System.Void System.Text.RegularExpressions.RegexCharClass::set_Negate(System.Boolean)
extern void RegexCharClass_set_Negate_mEB8659D83748A4DF28CDDFC3AC573A6504385E09 (void);
// 0x000000E2 System.Void System.Text.RegularExpressions.RegexCharClass::AddChar(System.Char)
extern void RegexCharClass_AddChar_m4C4BFD42572978A9F98ADE75BE3811593957A9E3 (void);
// 0x000000E3 System.Void System.Text.RegularExpressions.RegexCharClass::AddCharClass(System.Text.RegularExpressions.RegexCharClass)
extern void RegexCharClass_AddCharClass_m0E5DD1105844AFB7CE45B5C801304B5C803FB5CA (void);
// 0x000000E4 System.Void System.Text.RegularExpressions.RegexCharClass::AddSet(System.String)
extern void RegexCharClass_AddSet_mFFDE070E770BE967173D630AD50010C3397F7B97 (void);
// 0x000000E5 System.Void System.Text.RegularExpressions.RegexCharClass::AddSubtraction(System.Text.RegularExpressions.RegexCharClass)
extern void RegexCharClass_AddSubtraction_m17E538235B02A1435BD43D4FE4501DA67AA35145 (void);
// 0x000000E6 System.Void System.Text.RegularExpressions.RegexCharClass::AddRange(System.Char,System.Char)
extern void RegexCharClass_AddRange_mCFE9B670B3EBB13A5CDB694B1D1D6B1C0249D110 (void);
// 0x000000E7 System.Void System.Text.RegularExpressions.RegexCharClass::AddCategoryFromName(System.String,System.Boolean,System.Boolean,System.String)
extern void RegexCharClass_AddCategoryFromName_m9AD2D607E1E34A52CBC26FC38D468905C43A9202 (void);
// 0x000000E8 System.Void System.Text.RegularExpressions.RegexCharClass::AddCategory(System.String)
extern void RegexCharClass_AddCategory_m6A4625370DA8927DF5342275CB1F6155FC2BA255 (void);
// 0x000000E9 System.Void System.Text.RegularExpressions.RegexCharClass::AddLowercase(System.Globalization.CultureInfo)
extern void RegexCharClass_AddLowercase_m01C1B11EB0B82E065276C7ECF60725886F59A07A (void);
// 0x000000EA System.Void System.Text.RegularExpressions.RegexCharClass::AddLowercaseRange(System.Char,System.Char,System.Globalization.CultureInfo)
extern void RegexCharClass_AddLowercaseRange_mCDDE9661C9C300DFEB51A8FE36E2F790E3E75D75 (void);
// 0x000000EB System.Void System.Text.RegularExpressions.RegexCharClass::AddWord(System.Boolean,System.Boolean)
extern void RegexCharClass_AddWord_m1D2553B878162B32B0548536AE4C3EE673041CA0 (void);
// 0x000000EC System.Void System.Text.RegularExpressions.RegexCharClass::AddSpace(System.Boolean,System.Boolean)
extern void RegexCharClass_AddSpace_mC6557749D96EBD114BCB133D14887A29304196D8 (void);
// 0x000000ED System.Void System.Text.RegularExpressions.RegexCharClass::AddDigit(System.Boolean,System.Boolean,System.String)
extern void RegexCharClass_AddDigit_mC4DE43D884E575729BB2E575DA5552989368F6B3 (void);
// 0x000000EE System.Char System.Text.RegularExpressions.RegexCharClass::SingletonChar(System.String)
extern void RegexCharClass_SingletonChar_m01C15732FAD399460FF5BB449B8177A77CAB1DB9 (void);
// 0x000000EF System.Boolean System.Text.RegularExpressions.RegexCharClass::IsMergeable(System.String)
extern void RegexCharClass_IsMergeable_mB9A0CD8306728BAFA5460C7FD748A2A7AD4BA448 (void);
// 0x000000F0 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsEmpty(System.String)
extern void RegexCharClass_IsEmpty_mAD6C63FE25C4CF3E52A20185418925D12C4C07CF (void);
// 0x000000F1 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsSingleton(System.String)
extern void RegexCharClass_IsSingleton_m89D3E8460B0E7020DB0ABA607AC2F76FB9A34F1A (void);
// 0x000000F2 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsSingletonInverse(System.String)
extern void RegexCharClass_IsSingletonInverse_m3E75D541C85AD842B9EB80705D6869EDB3F6928D (void);
// 0x000000F3 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsSubtraction(System.String)
extern void RegexCharClass_IsSubtraction_m3C9EF97AFE7E4BCC24A2DF10834BF62279D7EE26 (void);
// 0x000000F4 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsNegated(System.String)
extern void RegexCharClass_IsNegated_m9CEDECE7EDA98ACD502E75783CA631A719DBC675 (void);
// 0x000000F5 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsECMAWordChar(System.Char)
extern void RegexCharClass_IsECMAWordChar_m6E7FC296DB816D89E3D6CF8672DCE6DFC519D741 (void);
// 0x000000F6 System.Boolean System.Text.RegularExpressions.RegexCharClass::IsWordChar(System.Char)
extern void RegexCharClass_IsWordChar_m2DF03D32DAB403138E397CB05F45D37BD50EB18C (void);
// 0x000000F7 System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInClass(System.Char,System.String)
extern void RegexCharClass_CharInClass_m194AAA57BBBD30E78E70255D6F53FAFDB785EC0E (void);
// 0x000000F8 System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInClassRecursive(System.Char,System.String,System.Int32)
extern void RegexCharClass_CharInClassRecursive_m5560DBADE1463FDEC38643C72CDF2FD5B3F69A5F (void);
// 0x000000F9 System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInClassInternal(System.Char,System.String,System.Int32,System.Int32,System.Int32)
extern void RegexCharClass_CharInClassInternal_m5D1634F64092E4BD9EB6427447F952983211A760 (void);
// 0x000000FA System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInCategory(System.Char,System.String,System.Int32,System.Int32,System.Int32)
extern void RegexCharClass_CharInCategory_mCDE20DF783F8D4E4403EC7F00F9C12E34D86C2DD (void);
// 0x000000FB System.Boolean System.Text.RegularExpressions.RegexCharClass::CharInCategoryGroup(System.Char,System.Globalization.UnicodeCategory,System.String,System.Int32&)
extern void RegexCharClass_CharInCategoryGroup_m28E498004F5EA6445C83F1B8EB4A776C210D30C5 (void);
// 0x000000FC System.String System.Text.RegularExpressions.RegexCharClass::NegateCategory(System.String)
extern void RegexCharClass_NegateCategory_mF2E03FFFE79E427F39D9368013A334F5BD118E13 (void);
// 0x000000FD System.Text.RegularExpressions.RegexCharClass System.Text.RegularExpressions.RegexCharClass::Parse(System.String)
extern void RegexCharClass_Parse_mBC3780FFF0DDFB62CA2085746618E6C256E8D86C (void);
// 0x000000FE System.Text.RegularExpressions.RegexCharClass System.Text.RegularExpressions.RegexCharClass::ParseRecursive(System.String,System.Int32)
extern void RegexCharClass_ParseRecursive_mF7E7DD4EB594C9C30A60E72CD3CFD4EC1D822CF5 (void);
// 0x000000FF System.Int32 System.Text.RegularExpressions.RegexCharClass::RangeCount()
extern void RegexCharClass_RangeCount_mEACBB4BD08CE18A9C4F0C433A7D6C5726F563E2E (void);
// 0x00000100 System.String System.Text.RegularExpressions.RegexCharClass::ToStringClass()
extern void RegexCharClass_ToStringClass_m7A760D96732A03D46C4060064B3FC58349D2B4D5 (void);
// 0x00000101 System.Text.RegularExpressions.RegexCharClass_SingleRange System.Text.RegularExpressions.RegexCharClass::GetRangeAt(System.Int32)
extern void RegexCharClass_GetRangeAt_mE563FF8072DD9B4E1179F55416CCD7FC4EB2C4FC (void);
// 0x00000102 System.Void System.Text.RegularExpressions.RegexCharClass::Canonicalize()
extern void RegexCharClass_Canonicalize_m44EEFB16DB02E73C1E7280D15DAE98E50F4D6FA4 (void);
// 0x00000103 System.String System.Text.RegularExpressions.RegexCharClass::SetFromProperty(System.String,System.Boolean,System.String)
extern void RegexCharClass_SetFromProperty_mA33170AF599765B5FDE8611BED646A850FB2330E (void);
// 0x00000104 System.Void System.Text.RegularExpressions.RegexCharClass_LowerCaseMapping::.ctor(System.Char,System.Char,System.Int32,System.Int32)
extern void LowerCaseMapping__ctor_m881B66875631FF0DD253696FE56313A9E3F24187_AdjustorThunk (void);
// 0x00000105 System.Int32 System.Text.RegularExpressions.RegexCharClass_SingleRangeComparer::Compare(System.Text.RegularExpressions.RegexCharClass_SingleRange,System.Text.RegularExpressions.RegexCharClass_SingleRange)
extern void SingleRangeComparer_Compare_mF2CAD555BAC4D9CBF6A8F90D829CB528BD7BCCC9 (void);
// 0x00000106 System.Void System.Text.RegularExpressions.RegexCharClass_SingleRangeComparer::.ctor()
extern void SingleRangeComparer__ctor_m9E44BF07F0F0C9E565E0BA050C1A26F496226BAD (void);
// 0x00000107 System.Void System.Text.RegularExpressions.RegexCharClass_SingleRange::.ctor(System.Char,System.Char)
extern void SingleRange__ctor_m4674722AFC97A111D2466AE2050C2E4E6E57303E (void);
// 0x00000108 System.Void System.Text.RegularExpressions.RegexCode::.ctor(System.Int32[],System.Collections.Generic.List`1<System.String>,System.Int32,System.Collections.Hashtable,System.Int32,System.Text.RegularExpressions.RegexBoyerMoore,System.Text.RegularExpressions.RegexPrefix,System.Int32,System.Boolean)
extern void RegexCode__ctor_mBCB059D3E98AEA211794E89DDF99193231F298CA (void);
// 0x00000109 System.Boolean System.Text.RegularExpressions.RegexCode::OpcodeBacktracks(System.Int32)
extern void RegexCode_OpcodeBacktracks_mDA23B91B55FE4991B168BF8E18F6DDDC7667B882 (void);
// 0x0000010A System.Text.RegularExpressions.RegexPrefix System.Text.RegularExpressions.RegexFCD::FirstChars(System.Text.RegularExpressions.RegexTree)
extern void RegexFCD_FirstChars_mC60DC5CA9A078998CB55594436AB9CBFD86478FB (void);
// 0x0000010B System.Text.RegularExpressions.RegexPrefix System.Text.RegularExpressions.RegexFCD::Prefix(System.Text.RegularExpressions.RegexTree)
extern void RegexFCD_Prefix_m50B30C508C6745832FD3A76B2169462455C1A28E (void);
// 0x0000010C System.Int32 System.Text.RegularExpressions.RegexFCD::Anchors(System.Text.RegularExpressions.RegexTree)
extern void RegexFCD_Anchors_m562FA644F10503074714E0F58A2A00F9F727D75E (void);
// 0x0000010D System.Int32 System.Text.RegularExpressions.RegexFCD::AnchorFromType(System.Int32)
extern void RegexFCD_AnchorFromType_m4B458E2C589633A43F9324C14F9192EF68F80A14 (void);
// 0x0000010E System.Void System.Text.RegularExpressions.RegexFCD::.ctor()
extern void RegexFCD__ctor_mFC6A3309CAFA8C3C2B94094AD443738823388A3B (void);
// 0x0000010F System.Void System.Text.RegularExpressions.RegexFCD::PushInt(System.Int32)
extern void RegexFCD_PushInt_m63817D3969DF7BD31B7C93D43EE45C4AF539868F (void);
// 0x00000110 System.Boolean System.Text.RegularExpressions.RegexFCD::IntIsEmpty()
extern void RegexFCD_IntIsEmpty_mE825A8A0DF9D5BA6618357ABBA93421D4099AAEB (void);
// 0x00000111 System.Int32 System.Text.RegularExpressions.RegexFCD::PopInt()
extern void RegexFCD_PopInt_m1E4B64F2F6DDBCB7495E673540CF25FDD4D01B7E (void);
// 0x00000112 System.Void System.Text.RegularExpressions.RegexFCD::PushFC(System.Text.RegularExpressions.RegexFC)
extern void RegexFCD_PushFC_mBE154E351E7C49FFFC26E603B4672136D91479C7 (void);
// 0x00000113 System.Boolean System.Text.RegularExpressions.RegexFCD::FCIsEmpty()
extern void RegexFCD_FCIsEmpty_m57FDE5D4E352620B7773AD54B286531CA21FCDAD (void);
// 0x00000114 System.Text.RegularExpressions.RegexFC System.Text.RegularExpressions.RegexFCD::PopFC()
extern void RegexFCD_PopFC_m987A35E9ADF69335799EDEEB12C2CD3A3F40FB6E (void);
// 0x00000115 System.Text.RegularExpressions.RegexFC System.Text.RegularExpressions.RegexFCD::TopFC()
extern void RegexFCD_TopFC_m26ED21621830CF30FDA46AE8D7F3AC9F50DE416F (void);
// 0x00000116 System.Text.RegularExpressions.RegexFC System.Text.RegularExpressions.RegexFCD::RegexFCFromRegexTree(System.Text.RegularExpressions.RegexTree)
extern void RegexFCD_RegexFCFromRegexTree_mA85E74765529D05113116C73EC397E832D81D0BC (void);
// 0x00000117 System.Void System.Text.RegularExpressions.RegexFCD::SkipChild()
extern void RegexFCD_SkipChild_m661F5D339305B97A37D855240A0B9AF500FE03F6 (void);
// 0x00000118 System.Void System.Text.RegularExpressions.RegexFCD::CalculateFC(System.Int32,System.Text.RegularExpressions.RegexNode,System.Int32)
extern void RegexFCD_CalculateFC_m2267FAA6BCA80275E21DC9A0BAF90BBC85204BD8 (void);
// 0x00000119 System.Void System.Text.RegularExpressions.RegexFC::.ctor(System.Boolean)
extern void RegexFC__ctor_m354E8197215F3EE9097B69E783B744365A38EF20 (void);
// 0x0000011A System.Void System.Text.RegularExpressions.RegexFC::.ctor(System.Char,System.Boolean,System.Boolean,System.Boolean)
extern void RegexFC__ctor_m023D08ED0365AE9AAC539333B4390A8052C59229 (void);
// 0x0000011B System.Void System.Text.RegularExpressions.RegexFC::.ctor(System.String,System.Boolean,System.Boolean)
extern void RegexFC__ctor_mDCBBCCC1BB476741943D7F9AD88731B1DCA0C1B5 (void);
// 0x0000011C System.Boolean System.Text.RegularExpressions.RegexFC::AddFC(System.Text.RegularExpressions.RegexFC,System.Boolean)
extern void RegexFC_AddFC_m5B05CD1D7700817843366EC1DF728977EDD4D11E (void);
// 0x0000011D System.String System.Text.RegularExpressions.RegexFC::GetFirstChars(System.Globalization.CultureInfo)
extern void RegexFC_GetFirstChars_m7252E826F9A5BC1842A5A255BAC5A36EE8DADAF5 (void);
// 0x0000011E System.Boolean System.Text.RegularExpressions.RegexFC::IsCaseInsensitive()
extern void RegexFC_IsCaseInsensitive_mD87B0C49AAEBB61215F09A9C5ABF8CCB8B5AB64E (void);
// 0x0000011F System.Void System.Text.RegularExpressions.RegexPrefix::.ctor(System.String,System.Boolean)
extern void RegexPrefix__ctor_m93489A4FF55425A15BF5390E77EE0B84F6F9364C (void);
// 0x00000120 System.String System.Text.RegularExpressions.RegexPrefix::get_Prefix()
extern void RegexPrefix_get_Prefix_m7137EC6CA5B857F49946E2EAEA19784040D430CF (void);
// 0x00000121 System.Boolean System.Text.RegularExpressions.RegexPrefix::get_CaseInsensitive()
extern void RegexPrefix_get_CaseInsensitive_m76E04480FA9FFAE4C5031CA12F4AE9A2576212C0 (void);
// 0x00000122 System.Text.RegularExpressions.RegexPrefix System.Text.RegularExpressions.RegexPrefix::get_Empty()
extern void RegexPrefix_get_Empty_mAD10DECDBC7C51F9ACF5C02E3191874252DF9B8B (void);
// 0x00000123 System.Void System.Text.RegularExpressions.RegexPrefix::.cctor()
extern void RegexPrefix__cctor_mCDCE7EDB98AFB119EE0281D37F7BC019AD28773D (void);
// 0x00000124 System.Void System.Text.RegularExpressions.Group::.ctor(System.String,System.Int32[],System.Int32,System.String)
extern void Group__ctor_mECF4574592517D363C35ADC07F9D6F7E7DE6B4F6 (void);
// 0x00000125 System.Boolean System.Text.RegularExpressions.Group::get_Success()
extern void Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521 (void);
// 0x00000126 System.Void System.Text.RegularExpressions.Group::.cctor()
extern void Group__cctor_m213E26F039439904671CFD5DAF5D85B47D5CBE68 (void);
// 0x00000127 System.Void System.Text.RegularExpressions.Group::.ctor()
extern void Group__ctor_mDCB3D51B8A672B342F452177D42D6D3F2F9BA91A (void);
// 0x00000128 System.Void System.Text.RegularExpressions.RegexInterpreter::.ctor(System.Text.RegularExpressions.RegexCode,System.Globalization.CultureInfo)
extern void RegexInterpreter__ctor_m7B9BA594CF5F338B2E257EDADC2481826BF4C6BB (void);
// 0x00000129 System.Void System.Text.RegularExpressions.RegexInterpreter::InitTrackCount()
extern void RegexInterpreter_InitTrackCount_mD93771C3D75617898528698E29AD09B7EA5EE24B (void);
// 0x0000012A System.Void System.Text.RegularExpressions.RegexInterpreter::Advance()
extern void RegexInterpreter_Advance_mCD1A51680CD0318DDF6D104DE8C722FCCC468CCA (void);
// 0x0000012B System.Void System.Text.RegularExpressions.RegexInterpreter::Advance(System.Int32)
extern void RegexInterpreter_Advance_m779870D7E1FA3580492E2E8B75E2805613525AF7 (void);
// 0x0000012C System.Void System.Text.RegularExpressions.RegexInterpreter::Goto(System.Int32)
extern void RegexInterpreter_Goto_m438DE9CE790DF0757383C91126DEA68C6B0DADFE (void);
// 0x0000012D System.Void System.Text.RegularExpressions.RegexInterpreter::Textto(System.Int32)
extern void RegexInterpreter_Textto_m6CE60A7C8FA9F9CEECD26BD6025F055EB64887AA (void);
// 0x0000012E System.Void System.Text.RegularExpressions.RegexInterpreter::Trackto(System.Int32)
extern void RegexInterpreter_Trackto_m0C7B05A7385BE3F9BB096FE28DC22942A9F96783 (void);
// 0x0000012F System.Int32 System.Text.RegularExpressions.RegexInterpreter::Textstart()
extern void RegexInterpreter_Textstart_mE71CFC006954F38B9EB6CD85BCC0867E63BF0894 (void);
// 0x00000130 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Textpos()
extern void RegexInterpreter_Textpos_mC66F0DE729E76EDA0BEEA7B1ABEE369BA6C81D5B (void);
// 0x00000131 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Trackpos()
extern void RegexInterpreter_Trackpos_m472ADA4F5E1D07E71896E42714DFB723CB016842 (void);
// 0x00000132 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush()
extern void RegexInterpreter_TrackPush_m5A8B9F863211AAEC7E5FAD14ECDDAFDE3059210D (void);
// 0x00000133 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush(System.Int32)
extern void RegexInterpreter_TrackPush_mB2AF47E651D2A3853A719EFB908C30D27EC2FF5F (void);
// 0x00000134 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush(System.Int32,System.Int32)
extern void RegexInterpreter_TrackPush_m3EA36B28D636D1C617F85CEA57650344B562A38F (void);
// 0x00000135 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush(System.Int32,System.Int32,System.Int32)
extern void RegexInterpreter_TrackPush_mBCAADB1DF177D91DC9AA4518DCDB3AAF7D6C0E15 (void);
// 0x00000136 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush2(System.Int32)
extern void RegexInterpreter_TrackPush2_m4EBCF8B183717311AEE3FAA6AD6FAF1F08B14F77 (void);
// 0x00000137 System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPush2(System.Int32,System.Int32)
extern void RegexInterpreter_TrackPush2_mD591F73FDDF69084636E0834BCCD530B057898FF (void);
// 0x00000138 System.Void System.Text.RegularExpressions.RegexInterpreter::Backtrack()
extern void RegexInterpreter_Backtrack_m46612DE84F898D1656DE30F3BA86E93209E279E1 (void);
// 0x00000139 System.Void System.Text.RegularExpressions.RegexInterpreter::SetOperator(System.Int32)
extern void RegexInterpreter_SetOperator_m5B633C33EE4CD85364E7C60003ACE8EA93FDAC91 (void);
// 0x0000013A System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPop()
extern void RegexInterpreter_TrackPop_m84B55BE8F346693942045E937174EC8C1AE91F08 (void);
// 0x0000013B System.Void System.Text.RegularExpressions.RegexInterpreter::TrackPop(System.Int32)
extern void RegexInterpreter_TrackPop_m73AB2E002DB92E231B62510861277320F76BEEED (void);
// 0x0000013C System.Int32 System.Text.RegularExpressions.RegexInterpreter::TrackPeek()
extern void RegexInterpreter_TrackPeek_m4EF7918CC0F10FFF7E73C1C9D13E74D1D8D13318 (void);
// 0x0000013D System.Int32 System.Text.RegularExpressions.RegexInterpreter::TrackPeek(System.Int32)
extern void RegexInterpreter_TrackPeek_mEECF3E94E7823A68474C691F695D71087729553C (void);
// 0x0000013E System.Void System.Text.RegularExpressions.RegexInterpreter::StackPush(System.Int32)
extern void RegexInterpreter_StackPush_mC28C3F8B3C811C4DCA6CD312F7F487206C871E55 (void);
// 0x0000013F System.Void System.Text.RegularExpressions.RegexInterpreter::StackPush(System.Int32,System.Int32)
extern void RegexInterpreter_StackPush_m911FF20379BF912884E7F98BB59CFB6C51AA1861 (void);
// 0x00000140 System.Void System.Text.RegularExpressions.RegexInterpreter::StackPop()
extern void RegexInterpreter_StackPop_mD057CA7B190ED8FBD33C6CE48E1F28E4B09FC4F2 (void);
// 0x00000141 System.Void System.Text.RegularExpressions.RegexInterpreter::StackPop(System.Int32)
extern void RegexInterpreter_StackPop_m90FC35FD76D9B63851ECFD641DAA08B1B58C7B91 (void);
// 0x00000142 System.Int32 System.Text.RegularExpressions.RegexInterpreter::StackPeek()
extern void RegexInterpreter_StackPeek_m08C28311048F6B075379EE46B924FC211BA48EC6 (void);
// 0x00000143 System.Int32 System.Text.RegularExpressions.RegexInterpreter::StackPeek(System.Int32)
extern void RegexInterpreter_StackPeek_m308DE22A8E1AF524319E7F1D5A94DBFEC37700ED (void);
// 0x00000144 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Operator()
extern void RegexInterpreter_Operator_m4DE2EAA1744D15294F2767D5217F753FE74FAC0B (void);
// 0x00000145 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Operand(System.Int32)
extern void RegexInterpreter_Operand_m1ACB9C398C9C7ADF8DA58824877B99F08F181526 (void);
// 0x00000146 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Leftchars()
extern void RegexInterpreter_Leftchars_m3A200CD41FFE8C89CCB85B3CC7A367E32C5988D1 (void);
// 0x00000147 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Rightchars()
extern void RegexInterpreter_Rightchars_m3DB37A53D6C3DC3311C9EA020690CC0824959D30 (void);
// 0x00000148 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Bump()
extern void RegexInterpreter_Bump_mC33CB8A0CC0DF1C69F11115BD225D2D8B63F8753 (void);
// 0x00000149 System.Int32 System.Text.RegularExpressions.RegexInterpreter::Forwardchars()
extern void RegexInterpreter_Forwardchars_mE5E437E285604CDC60551C112F7B2CEF7297F4ED (void);
// 0x0000014A System.Char System.Text.RegularExpressions.RegexInterpreter::Forwardcharnext()
extern void RegexInterpreter_Forwardcharnext_mD2C6694CC31BC75D3E20C511D1004D28AAE1390F (void);
// 0x0000014B System.Boolean System.Text.RegularExpressions.RegexInterpreter::Stringmatch(System.String)
extern void RegexInterpreter_Stringmatch_m543BC6834400A925D2603AE6FBB47944694AFDF1 (void);
// 0x0000014C System.Boolean System.Text.RegularExpressions.RegexInterpreter::Refmatch(System.Int32,System.Int32)
extern void RegexInterpreter_Refmatch_m52369ADBF64E25A9EEEBE216939454EBB8D8E138 (void);
// 0x0000014D System.Void System.Text.RegularExpressions.RegexInterpreter::Backwardnext()
extern void RegexInterpreter_Backwardnext_mD10CE2A9E229D0655EF01565DB39C902654D00CD (void);
// 0x0000014E System.Char System.Text.RegularExpressions.RegexInterpreter::CharAt(System.Int32)
extern void RegexInterpreter_CharAt_mAE2AF6D293F53C2D8961C2D0C145BC3ADF6EC105 (void);
// 0x0000014F System.Boolean System.Text.RegularExpressions.RegexInterpreter::FindFirstChar()
extern void RegexInterpreter_FindFirstChar_m95CDB0ECB99F7850479D951A5F32BB6B19B91F44 (void);
// 0x00000150 System.Void System.Text.RegularExpressions.RegexInterpreter::Go()
extern void RegexInterpreter_Go_mBE9DEAECBD68F60DDFE2BB5A8C24CF92A1FB503A (void);
// 0x00000151 System.Text.RegularExpressions.Match System.Text.RegularExpressions.Match::get_Empty()
extern void Match_get_Empty_m5D3AE3D0580F06ED901EE69FCCED6AF44715528F (void);
// 0x00000152 System.Void System.Text.RegularExpressions.Match::.ctor(System.Text.RegularExpressions.Regex,System.Int32,System.String,System.Int32,System.Int32,System.Int32)
extern void Match__ctor_m08A8262ACD89C9E47AA7168D0F2CC6E3338855D7 (void);
// 0x00000153 System.Void System.Text.RegularExpressions.Match::Reset(System.Text.RegularExpressions.Regex,System.String,System.Int32,System.Int32,System.Int32)
extern void Match_Reset_m9EDCC3689E8A5A57A644946AEC3E41C1901C7DAF (void);
// 0x00000154 System.Text.RegularExpressions.Match System.Text.RegularExpressions.Match::NextMatch()
extern void Match_NextMatch_mA9BB438B4D7DE12D45A73720C063CFFF15FE596D (void);
// 0x00000155 System.String System.Text.RegularExpressions.Match::GroupToStringImpl(System.Int32)
extern void Match_GroupToStringImpl_m933A6494C68E43C8CE37F64FA298ECBCF6F3C4AE (void);
// 0x00000156 System.String System.Text.RegularExpressions.Match::LastGroupToStringImpl()
extern void Match_LastGroupToStringImpl_m92EDBD078D266F78252C71C35E1693105CDA3825 (void);
// 0x00000157 System.Void System.Text.RegularExpressions.Match::AddMatch(System.Int32,System.Int32,System.Int32)
extern void Match_AddMatch_m3C9178A7D6F8175A7628E4BE579FD209B7C7650A (void);
// 0x00000158 System.Void System.Text.RegularExpressions.Match::BalanceMatch(System.Int32)
extern void Match_BalanceMatch_mCC0EC358E4C33191B896226512FE8F086EFEA4CF (void);
// 0x00000159 System.Void System.Text.RegularExpressions.Match::RemoveMatch(System.Int32)
extern void Match_RemoveMatch_m6268C01D537F0BACB7DD707E11FA873C3E1918C7 (void);
// 0x0000015A System.Boolean System.Text.RegularExpressions.Match::IsMatched(System.Int32)
extern void Match_IsMatched_m7686CA418F588EC198A82DE287326C46F4CBDD5F (void);
// 0x0000015B System.Int32 System.Text.RegularExpressions.Match::MatchIndex(System.Int32)
extern void Match_MatchIndex_mA39CA9F84C3872675CB9C76EC342EFB30A2B5DA0 (void);
// 0x0000015C System.Int32 System.Text.RegularExpressions.Match::MatchLength(System.Int32)
extern void Match_MatchLength_m25492EACF56E8211FEEC4856F93D7A19D30A984F (void);
// 0x0000015D System.Void System.Text.RegularExpressions.Match::Tidy(System.Int32)
extern void Match_Tidy_m88B2494631267F8CF7E90F3305F713550ED39CE8 (void);
// 0x0000015E System.Void System.Text.RegularExpressions.Match::.cctor()
extern void Match__cctor_m9158A9D469720E89CD9004B65F55EEEF5E330C0E (void);
// 0x0000015F System.Void System.Text.RegularExpressions.Match::.ctor()
extern void Match__ctor_m38BC8AD7EEFA99C6FC25587D6FE56450FA849E0C (void);
// 0x00000160 System.Void System.Text.RegularExpressions.MatchSparse::.ctor(System.Text.RegularExpressions.Regex,System.Collections.Hashtable,System.Int32,System.String,System.Int32,System.Int32,System.Int32)
extern void MatchSparse__ctor_mEA523FCAF96D8A81401D3ED010CACE4463CCE811 (void);
// 0x00000161 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::.ctor(System.String,System.String,System.TimeSpan)
extern void RegexMatchTimeoutException__ctor_mCCDB413A8F68D924B276B8FED2744E81BE4C89AF (void);
// 0x00000162 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::.ctor()
extern void RegexMatchTimeoutException__ctor_m4EFD030442FEEC81E59AB8CDF35D603A5D551058 (void);
// 0x00000163 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void RegexMatchTimeoutException__ctor_m554FE8CFA7F42483517F11948A61E4D3C9F44D07 (void);
// 0x00000164 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void RegexMatchTimeoutException_System_Runtime_Serialization_ISerializable_GetObjectData_m78FACBA38C002E195A507A32CDAB768D8DBC93E7 (void);
// 0x00000165 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::Init()
extern void RegexMatchTimeoutException_Init_m09AF601CC7369F2D7E1300B166517FE7D20EB6F1 (void);
// 0x00000166 System.Void System.Text.RegularExpressions.RegexMatchTimeoutException::Init(System.String,System.String,System.TimeSpan)
extern void RegexMatchTimeoutException_Init_m0F165C7170A46724458C06DA5EC05536D8CB95B7 (void);
// 0x00000167 System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions)
extern void RegexNode__ctor_m29676E9646F598C827F25E906EEB6EA14A6FD5DB (void);
// 0x00000168 System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions,System.Char)
extern void RegexNode__ctor_m92FB70D6C28D7E021A2A1ACBAD583461AB014F11 (void);
// 0x00000169 System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions,System.String)
extern void RegexNode__ctor_m89ACB97FB7FE8B38C0D69F0F2445A7916BC67D85 (void);
// 0x0000016A System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions,System.Int32)
extern void RegexNode__ctor_mAE76BA90AA85F205CB0CC6799F06D1AD85A49F64 (void);
// 0x0000016B System.Void System.Text.RegularExpressions.RegexNode::.ctor(System.Int32,System.Text.RegularExpressions.RegexOptions,System.Int32,System.Int32)
extern void RegexNode__ctor_m0EFEB707603B3C667626117E09A7EED58BBEC6D4 (void);
// 0x0000016C System.Boolean System.Text.RegularExpressions.RegexNode::UseOptionR()
extern void RegexNode_UseOptionR_mB931929BBD1D89F8B263AA846C1665775096713E (void);
// 0x0000016D System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReverseLeft()
extern void RegexNode_ReverseLeft_m994638E4886D007B9B29BC23EA3C8D76A92099FD (void);
// 0x0000016E System.Void System.Text.RegularExpressions.RegexNode::MakeRep(System.Int32,System.Int32,System.Int32)
extern void RegexNode_MakeRep_mC310B028FBE3BD5EB80F83E4E05B891ADEE45C22 (void);
// 0x0000016F System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::Reduce()
extern void RegexNode_Reduce_mE9E22C30C296E328ABC7EDC9C52F18059FAE27C1 (void);
// 0x00000170 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::StripEnation(System.Int32)
extern void RegexNode_StripEnation_mE19E0A57BCE0D0BF47F51A5103C08FCC7BB9E24F (void);
// 0x00000171 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceGroup()
extern void RegexNode_ReduceGroup_m069FA93D4F88006F18473E647069B349683B9204 (void);
// 0x00000172 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceRep()
extern void RegexNode_ReduceRep_m726F03D9E2420F276A37777942B66D15CA73F77E (void);
// 0x00000173 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceSet()
extern void RegexNode_ReduceSet_m912F4A0DFF694EB14DE520599369A811C2E9D10D (void);
// 0x00000174 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceAlternation()
extern void RegexNode_ReduceAlternation_m60EECC172A975620A5118D14D6ECF8B846ECED9F (void);
// 0x00000175 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::ReduceConcatenation()
extern void RegexNode_ReduceConcatenation_m4BE1B6DBBC0F4BAB9A3873414B5EE77D825AD53B (void);
// 0x00000176 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::MakeQuantifier(System.Boolean,System.Int32,System.Int32)
extern void RegexNode_MakeQuantifier_m1332537AA6BCCCD68A3E59EA7994CCFE69A19444 (void);
// 0x00000177 System.Void System.Text.RegularExpressions.RegexNode::AddChild(System.Text.RegularExpressions.RegexNode)
extern void RegexNode_AddChild_m734A86A25E6074316FAC566F7D127253F7B71703 (void);
// 0x00000178 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexNode::Child(System.Int32)
extern void RegexNode_Child_m5AA4FFDDCCFA22FE70BA0F236F19A963AEF72079 (void);
// 0x00000179 System.Int32 System.Text.RegularExpressions.RegexNode::ChildCount()
extern void RegexNode_ChildCount_m23B6965575DB0DBC1D90212820DEA144FCB06996 (void);
// 0x0000017A System.Int32 System.Text.RegularExpressions.RegexNode::Type()
extern void RegexNode_Type_mFA1C2F11F3487BB1BCBA7F58FFB7975EC18E9CD4 (void);
// 0x0000017B System.Text.RegularExpressions.RegexTree System.Text.RegularExpressions.RegexParser::Parse(System.String,System.Text.RegularExpressions.RegexOptions)
extern void RegexParser_Parse_mD206BB554B6087ED35C5F744D72A93A07721D789 (void);
// 0x0000017C System.Text.RegularExpressions.RegexReplacement System.Text.RegularExpressions.RegexParser::ParseReplacement(System.String,System.Collections.Hashtable,System.Int32,System.Collections.Hashtable,System.Text.RegularExpressions.RegexOptions)
extern void RegexParser_ParseReplacement_m13F769D7F27406A5E080C5E69F273758CBF37948 (void);
// 0x0000017D System.Void System.Text.RegularExpressions.RegexParser::.ctor(System.Globalization.CultureInfo)
extern void RegexParser__ctor_mC69D13B4FC323EE77392251139C5F2C456171310 (void);
// 0x0000017E System.Void System.Text.RegularExpressions.RegexParser::SetPattern(System.String)
extern void RegexParser_SetPattern_m4B385D83A9680A1B2707EBCA8659B6E12EDD5E46 (void);
// 0x0000017F System.Void System.Text.RegularExpressions.RegexParser::Reset(System.Text.RegularExpressions.RegexOptions)
extern void RegexParser_Reset_mEC49D1DCEBC555768D2FB90DA42374F1C547E328 (void);
// 0x00000180 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanRegex()
extern void RegexParser_ScanRegex_m62049A6C66D6D8CDD795B9C740283D1EC85126DB (void);
// 0x00000181 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanReplacement()
extern void RegexParser_ScanReplacement_m25F626A8546B29D06850DE337D58892567E11033 (void);
// 0x00000182 System.Text.RegularExpressions.RegexCharClass System.Text.RegularExpressions.RegexParser::ScanCharClass(System.Boolean)
extern void RegexParser_ScanCharClass_mF775DA8BFD214C64BC3D91E07436543717976DC4 (void);
// 0x00000183 System.Text.RegularExpressions.RegexCharClass System.Text.RegularExpressions.RegexParser::ScanCharClass(System.Boolean,System.Boolean)
extern void RegexParser_ScanCharClass_mFE669B1C9CB6652157D9E8DAEE5B924C581AE81F (void);
// 0x00000184 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanGroupOpen()
extern void RegexParser_ScanGroupOpen_mA4918ACA08C7E4C945197BBE4EF734AF5B35096C (void);
// 0x00000185 System.Void System.Text.RegularExpressions.RegexParser::ScanBlank()
extern void RegexParser_ScanBlank_m99BA3097E182DE425BE0137BAFDD0218F0DF360D (void);
// 0x00000186 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanBackslash()
extern void RegexParser_ScanBackslash_m45E9E0ABDB7DF70F58850B48905DE9DE026EA64C (void);
// 0x00000187 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanBasicBackslash()
extern void RegexParser_ScanBasicBackslash_m5F438E56ACBE272622D39D4208B2D5ED536DD7B8 (void);
// 0x00000188 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::ScanDollar()
extern void RegexParser_ScanDollar_m55F746009E6BFDA1A1A9A7CCA941EA247D984ED7 (void);
// 0x00000189 System.String System.Text.RegularExpressions.RegexParser::ScanCapname()
extern void RegexParser_ScanCapname_m1D4DB4E5DA312CBCA841391F729CC626DC657D85 (void);
// 0x0000018A System.Char System.Text.RegularExpressions.RegexParser::ScanOctal()
extern void RegexParser_ScanOctal_mCF3925D06CBBA1DD0CB60199F59991D099430C3A (void);
// 0x0000018B System.Int32 System.Text.RegularExpressions.RegexParser::ScanDecimal()
extern void RegexParser_ScanDecimal_mE966D2C7F357215A52F88120F40A37707C1AB33A (void);
// 0x0000018C System.Char System.Text.RegularExpressions.RegexParser::ScanHex(System.Int32)
extern void RegexParser_ScanHex_m296FC19218F8186D2C1B630DF9F138CFB195625E (void);
// 0x0000018D System.Int32 System.Text.RegularExpressions.RegexParser::HexDigit(System.Char)
extern void RegexParser_HexDigit_m4BAEE94B2077B96A4B1D56C459EFB2B1938E1174 (void);
// 0x0000018E System.Char System.Text.RegularExpressions.RegexParser::ScanControl()
extern void RegexParser_ScanControl_m244F59DA2B0711D154B7D68CCB5765390C65B5B8 (void);
// 0x0000018F System.Boolean System.Text.RegularExpressions.RegexParser::IsOnlyTopOption(System.Text.RegularExpressions.RegexOptions)
extern void RegexParser_IsOnlyTopOption_m66FE256A81BBD173C96B90EE9EBE9721F9ED16A1 (void);
// 0x00000190 System.Void System.Text.RegularExpressions.RegexParser::ScanOptions()
extern void RegexParser_ScanOptions_m5CD283C15179190846762B90F78F0A87E7495537 (void);
// 0x00000191 System.Char System.Text.RegularExpressions.RegexParser::ScanCharEscape()
extern void RegexParser_ScanCharEscape_mF8821EE73F3F8A5D4267642F6E4F0A666FA5E7A6 (void);
// 0x00000192 System.String System.Text.RegularExpressions.RegexParser::ParseProperty()
extern void RegexParser_ParseProperty_m69C638E755F0A5C1A2BC8E08827E6124889C2CEF (void);
// 0x00000193 System.Int32 System.Text.RegularExpressions.RegexParser::TypeFromCode(System.Char)
extern void RegexParser_TypeFromCode_m0969E0D233AC767039B0A333901F47A22BABE0E8 (void);
// 0x00000194 System.Text.RegularExpressions.RegexOptions System.Text.RegularExpressions.RegexParser::OptionFromCode(System.Char)
extern void RegexParser_OptionFromCode_m6BCD10574DF5E08599B5F7FC8E947E3DC69EE151 (void);
// 0x00000195 System.Void System.Text.RegularExpressions.RegexParser::CountCaptures()
extern void RegexParser_CountCaptures_m5255DE4B24B8D9BA7B2A2A7A1FD79A67B36F4634 (void);
// 0x00000196 System.Void System.Text.RegularExpressions.RegexParser::NoteCaptureSlot(System.Int32,System.Int32)
extern void RegexParser_NoteCaptureSlot_m8B2D20B819C86E427837C879CCA72B9BCD1C4AA8 (void);
// 0x00000197 System.Void System.Text.RegularExpressions.RegexParser::NoteCaptureName(System.String,System.Int32)
extern void RegexParser_NoteCaptureName_m96A5301077C4C6554E993A2266EA40B690F455C4 (void);
// 0x00000198 System.Void System.Text.RegularExpressions.RegexParser::NoteCaptures(System.Collections.Hashtable,System.Int32,System.Collections.Hashtable)
extern void RegexParser_NoteCaptures_m984EFFB499AA60257CB3BE40718EB78DFA7D30FD (void);
// 0x00000199 System.Void System.Text.RegularExpressions.RegexParser::AssignNameSlots()
extern void RegexParser_AssignNameSlots_m168605CD3A6D6AAA52AFFDB13BE3D5DFAC3FE94B (void);
// 0x0000019A System.Int32 System.Text.RegularExpressions.RegexParser::CaptureSlotFromName(System.String)
extern void RegexParser_CaptureSlotFromName_mE3FD1D57EB29D4C7A0E4029E4D4785297798EE43 (void);
// 0x0000019B System.Boolean System.Text.RegularExpressions.RegexParser::IsCaptureSlot(System.Int32)
extern void RegexParser_IsCaptureSlot_m80540BE449D9B98B2B159CD5169F7AA6DB63CB80 (void);
// 0x0000019C System.Boolean System.Text.RegularExpressions.RegexParser::IsCaptureName(System.String)
extern void RegexParser_IsCaptureName_mBFB85B16ED80CA59452491B4C3278C77ADCA1FDF (void);
// 0x0000019D System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionN()
extern void RegexParser_UseOptionN_mE9C62585222B2D99D295708E4486C952973F35D5 (void);
// 0x0000019E System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionI()
extern void RegexParser_UseOptionI_mFA3B59BD8A6F61626E20F8FE909A23289E694263 (void);
// 0x0000019F System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionM()
extern void RegexParser_UseOptionM_mDE945B2DE782D12A5013D408F4FFBCABEC48C63D (void);
// 0x000001A0 System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionS()
extern void RegexParser_UseOptionS_mE96EEA754E1EEEF658AAF73885D048342D1D200E (void);
// 0x000001A1 System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionX()
extern void RegexParser_UseOptionX_mD63DEED6741AEA0B3F6CC4239712A4B2EF690810 (void);
// 0x000001A2 System.Boolean System.Text.RegularExpressions.RegexParser::UseOptionE()
extern void RegexParser_UseOptionE_mC171EEF863E091591BAD771F16B72D742F044096 (void);
// 0x000001A3 System.Boolean System.Text.RegularExpressions.RegexParser::IsSpecial(System.Char)
extern void RegexParser_IsSpecial_mFF68456E944ACAF048B4F96F5758FFDD1D5E7DCD (void);
// 0x000001A4 System.Boolean System.Text.RegularExpressions.RegexParser::IsStopperX(System.Char)
extern void RegexParser_IsStopperX_m0BCF2DB4B0E1324C9109C8BFD486FC5DBA8DC646 (void);
// 0x000001A5 System.Boolean System.Text.RegularExpressions.RegexParser::IsQuantifier(System.Char)
extern void RegexParser_IsQuantifier_mE0620E30A63AD0C0DB9550A52A4A7D0BB4BC3A31 (void);
// 0x000001A6 System.Boolean System.Text.RegularExpressions.RegexParser::IsTrueQuantifier()
extern void RegexParser_IsTrueQuantifier_m4AA95A9CE7CD78600E8D525ECA5A095984FBC63F (void);
// 0x000001A7 System.Boolean System.Text.RegularExpressions.RegexParser::IsSpace(System.Char)
extern void RegexParser_IsSpace_m1E41FA7DD1FB93BF9220530CA91B35EF08879F30 (void);
// 0x000001A8 System.Void System.Text.RegularExpressions.RegexParser::AddConcatenate(System.Int32,System.Int32,System.Boolean)
extern void RegexParser_AddConcatenate_m3743C87DFCD1784A949BFDCE9443845CCD630A5D (void);
// 0x000001A9 System.Void System.Text.RegularExpressions.RegexParser::PushGroup()
extern void RegexParser_PushGroup_m6F4246ECA3A6F29DA096C3B41D97652427E3175E (void);
// 0x000001AA System.Void System.Text.RegularExpressions.RegexParser::PopGroup()
extern void RegexParser_PopGroup_m43AB1FB84E11D8DFF6C5D38B9CAD324E5425DD74 (void);
// 0x000001AB System.Boolean System.Text.RegularExpressions.RegexParser::EmptyStack()
extern void RegexParser_EmptyStack_mB65B33DCF98A5967407B7C6A07F8799681202BE5 (void);
// 0x000001AC System.Void System.Text.RegularExpressions.RegexParser::StartGroup(System.Text.RegularExpressions.RegexNode)
extern void RegexParser_StartGroup_m36A6C0ED245D844CD2E630160994C3F2D7CCA994 (void);
// 0x000001AD System.Void System.Text.RegularExpressions.RegexParser::AddAlternate()
extern void RegexParser_AddAlternate_mDBDEEF8180738DE0D31CC05B0E223EFF0D66939B (void);
// 0x000001AE System.Void System.Text.RegularExpressions.RegexParser::AddConcatenate()
extern void RegexParser_AddConcatenate_mF80F14978ED6626A8F8E5F37AEB3B946A01192C1 (void);
// 0x000001AF System.Void System.Text.RegularExpressions.RegexParser::AddConcatenate(System.Boolean,System.Int32,System.Int32)
extern void RegexParser_AddConcatenate_m81CC39ED404E571347F0E97650F3BEB14639B1B0 (void);
// 0x000001B0 System.Text.RegularExpressions.RegexNode System.Text.RegularExpressions.RegexParser::Unit()
extern void RegexParser_Unit_mEAEEAC39DBE372DC762644F49E6E163CA37EA34E (void);
// 0x000001B1 System.Void System.Text.RegularExpressions.RegexParser::AddUnitOne(System.Char)
extern void RegexParser_AddUnitOne_m72DFA82092408E9C63544126093D98390E0C2145 (void);
// 0x000001B2 System.Void System.Text.RegularExpressions.RegexParser::AddUnitNotone(System.Char)
extern void RegexParser_AddUnitNotone_mAA142A94BB7B6A358BA36A3920DB139382889749 (void);
// 0x000001B3 System.Void System.Text.RegularExpressions.RegexParser::AddUnitSet(System.String)
extern void RegexParser_AddUnitSet_m024168548909EA2DF649E6194D60135312ADF5B3 (void);
// 0x000001B4 System.Void System.Text.RegularExpressions.RegexParser::AddUnitNode(System.Text.RegularExpressions.RegexNode)
extern void RegexParser_AddUnitNode_m6EE11A898128A169E41A5C7B38B1F3DD314FB304 (void);
// 0x000001B5 System.Void System.Text.RegularExpressions.RegexParser::AddUnitType(System.Int32)
extern void RegexParser_AddUnitType_m1ECB4025CA3B580F051CF6891D9C96922CA2FA7A (void);
// 0x000001B6 System.Void System.Text.RegularExpressions.RegexParser::AddGroup()
extern void RegexParser_AddGroup_m54BBB919E4D4AD05EFECBC3ECBE46FC4A90569EA (void);
// 0x000001B7 System.Void System.Text.RegularExpressions.RegexParser::PushOptions()
extern void RegexParser_PushOptions_m2034533961B704CBFA0F97BD4A54CB7269F0D88A (void);
// 0x000001B8 System.Void System.Text.RegularExpressions.RegexParser::PopOptions()
extern void RegexParser_PopOptions_mA18691037302741375A44BD8BDC9387DFB07B676 (void);
// 0x000001B9 System.Boolean System.Text.RegularExpressions.RegexParser::EmptyOptionsStack()
extern void RegexParser_EmptyOptionsStack_m5FCB7AF81ACB5C91A73231C9F0AA0DFB32067A45 (void);
// 0x000001BA System.Void System.Text.RegularExpressions.RegexParser::PopKeepOptions()
extern void RegexParser_PopKeepOptions_m8ACBCD324BAF7269F90AEB3CF901B666524658FA (void);
// 0x000001BB System.ArgumentException System.Text.RegularExpressions.RegexParser::MakeException(System.String)
extern void RegexParser_MakeException_m6D521D75808E2CD4255A68DC3456EAF2A88F2874 (void);
// 0x000001BC System.Int32 System.Text.RegularExpressions.RegexParser::Textpos()
extern void RegexParser_Textpos_m36658DED82367E05DF4333E68A666FEEBC3DAC07 (void);
// 0x000001BD System.Void System.Text.RegularExpressions.RegexParser::Textto(System.Int32)
extern void RegexParser_Textto_m5C8BAB13E35429238EA9A5F13D5A5A580D0DD3AC (void);
// 0x000001BE System.Char System.Text.RegularExpressions.RegexParser::MoveRightGetChar()
extern void RegexParser_MoveRightGetChar_m3CF088DE129BADB346CCEEF1D547E2D260BC894A (void);
// 0x000001BF System.Void System.Text.RegularExpressions.RegexParser::MoveRight()
extern void RegexParser_MoveRight_m6F0A1C10AE9EA183F04A9E06B62B2B53648688AC (void);
// 0x000001C0 System.Void System.Text.RegularExpressions.RegexParser::MoveRight(System.Int32)
extern void RegexParser_MoveRight_m7D1D27C901CAB81BCF60803E22FBDF2DEEC6CC51 (void);
// 0x000001C1 System.Void System.Text.RegularExpressions.RegexParser::MoveLeft()
extern void RegexParser_MoveLeft_m1BC035A4EA49F4168093B2AB0EEAB2653CB04033 (void);
// 0x000001C2 System.Char System.Text.RegularExpressions.RegexParser::CharAt(System.Int32)
extern void RegexParser_CharAt_m08DBAE0DFD788548F74E061031B7221154F96A77 (void);
// 0x000001C3 System.Char System.Text.RegularExpressions.RegexParser::RightChar()
extern void RegexParser_RightChar_m9E231199A8E5EA994AA1746FC5E977AF3823FDEB (void);
// 0x000001C4 System.Char System.Text.RegularExpressions.RegexParser::RightChar(System.Int32)
extern void RegexParser_RightChar_m246E9E1F8D0A4A8E485C23E233CD3915C23739D8 (void);
// 0x000001C5 System.Int32 System.Text.RegularExpressions.RegexParser::CharsRight()
extern void RegexParser_CharsRight_m318662CFE3223C3FA5E921D376409B4E1B28F9B4 (void);
// 0x000001C6 System.Void System.Text.RegularExpressions.RegexParser::.cctor()
extern void RegexParser__cctor_mF468AF3C5916BA72C579CBD41A73D2DAD004F0EE (void);
// 0x000001C7 System.Void System.Text.RegularExpressions.RegexReplacement::.ctor(System.String,System.Text.RegularExpressions.RegexNode,System.Collections.Hashtable)
extern void RegexReplacement__ctor_m380FB887FB6FC62BB1DF59D01A859EB813FD670A (void);
// 0x000001C8 System.Void System.Text.RegularExpressions.RegexReplacement::ReplacementImpl(System.Text.StringBuilder,System.Text.RegularExpressions.Match)
extern void RegexReplacement_ReplacementImpl_mA3F4702CCE8307AB25F3565FE9A3F6B6643591CE (void);
// 0x000001C9 System.Void System.Text.RegularExpressions.RegexReplacement::ReplacementImplRTL(System.Collections.Generic.List`1<System.String>,System.Text.RegularExpressions.Match)
extern void RegexReplacement_ReplacementImplRTL_m16AF2466D4C7112191A74EB9CD21C9B7A0405913 (void);
// 0x000001CA System.String System.Text.RegularExpressions.RegexReplacement::get_Pattern()
extern void RegexReplacement_get_Pattern_m1F4A81BA1F012141DF3B358167025DE0072E1A72 (void);
// 0x000001CB System.String System.Text.RegularExpressions.RegexReplacement::Replace(System.Text.RegularExpressions.Regex,System.String,System.Int32,System.Int32)
extern void RegexReplacement_Replace_m470485F90D044CA2879155BA72E5283C928E4343 (void);
// 0x000001CC System.Void System.Text.RegularExpressions.RegexRunner::.ctor()
extern void RegexRunner__ctor_mC04D94995556E71E813F8420C8A4EC0B66404550 (void);
// 0x000001CD System.Text.RegularExpressions.Match System.Text.RegularExpressions.RegexRunner::Scan(System.Text.RegularExpressions.Regex,System.String,System.Int32,System.Int32,System.Int32,System.Int32,System.Boolean,System.TimeSpan)
extern void RegexRunner_Scan_m1C3B1B034601773D510A4D2DEC337635A540BE31 (void);
// 0x000001CE System.Void System.Text.RegularExpressions.RegexRunner::StartTimeoutWatch()
extern void RegexRunner_StartTimeoutWatch_m257FBE0C72761082A11D275954C6A1343EB13301 (void);
// 0x000001CF System.Void System.Text.RegularExpressions.RegexRunner::CheckTimeout()
extern void RegexRunner_CheckTimeout_m52486A9CE7B6EA4C83BB60FB200196AF0EE5687B (void);
// 0x000001D0 System.Void System.Text.RegularExpressions.RegexRunner::DoCheckTimeout()
extern void RegexRunner_DoCheckTimeout_mCDAA40848A2F8AAD70928FFD8A6C08FF2D9E72A3 (void);
// 0x000001D1 System.Void System.Text.RegularExpressions.RegexRunner::Go()
// 0x000001D2 System.Boolean System.Text.RegularExpressions.RegexRunner::FindFirstChar()
// 0x000001D3 System.Void System.Text.RegularExpressions.RegexRunner::InitTrackCount()
// 0x000001D4 System.Void System.Text.RegularExpressions.RegexRunner::InitMatch()
extern void RegexRunner_InitMatch_mF9CD772D4A8E12F89B4785324CD6939ABAE89AD4 (void);
// 0x000001D5 System.Text.RegularExpressions.Match System.Text.RegularExpressions.RegexRunner::TidyMatch(System.Boolean)
extern void RegexRunner_TidyMatch_m61A8AE20E505F2055B276EB020EB0B804ED2D924 (void);
// 0x000001D6 System.Void System.Text.RegularExpressions.RegexRunner::EnsureStorage()
extern void RegexRunner_EnsureStorage_m6BC13F773B014E2875CCD9A83E4093A77AA1053C (void);
// 0x000001D7 System.Boolean System.Text.RegularExpressions.RegexRunner::IsBoundary(System.Int32,System.Int32,System.Int32)
extern void RegexRunner_IsBoundary_m6C846E11790EC61A9E75A24230E1477913DB3441 (void);
// 0x000001D8 System.Boolean System.Text.RegularExpressions.RegexRunner::IsECMABoundary(System.Int32,System.Int32,System.Int32)
extern void RegexRunner_IsECMABoundary_m35C5F5DDC7C2F0E57EBA2E9D9892A88EDAEE4B97 (void);
// 0x000001D9 System.Void System.Text.RegularExpressions.RegexRunner::DoubleTrack()
extern void RegexRunner_DoubleTrack_m057C14C51F137222469C6526406B0E1069747618 (void);
// 0x000001DA System.Void System.Text.RegularExpressions.RegexRunner::DoubleStack()
extern void RegexRunner_DoubleStack_m8969F05F9E086EAA194DCBD2F137778239918925 (void);
// 0x000001DB System.Void System.Text.RegularExpressions.RegexRunner::DoubleCrawl()
extern void RegexRunner_DoubleCrawl_mF0425849E5E3C2BA5E9009CED7DE245C8CA0F7CC (void);
// 0x000001DC System.Void System.Text.RegularExpressions.RegexRunner::Crawl(System.Int32)
extern void RegexRunner_Crawl_m655A5D262056F7E13F0645CE5611AE65E83D97DB (void);
// 0x000001DD System.Int32 System.Text.RegularExpressions.RegexRunner::Popcrawl()
extern void RegexRunner_Popcrawl_mD8C76E2C584E6908F4BB11E055B97581F0CF7268 (void);
// 0x000001DE System.Int32 System.Text.RegularExpressions.RegexRunner::Crawlpos()
extern void RegexRunner_Crawlpos_m26A92CA69EF0C65BC7389834A12AD331538D064D (void);
// 0x000001DF System.Void System.Text.RegularExpressions.RegexRunner::Capture(System.Int32,System.Int32,System.Int32)
extern void RegexRunner_Capture_mE34CB0D3351BCC69F6FDE6CDEA763B93C5E92642 (void);
// 0x000001E0 System.Void System.Text.RegularExpressions.RegexRunner::TransferCapture(System.Int32,System.Int32,System.Int32,System.Int32)
extern void RegexRunner_TransferCapture_m4F01B5A96647BC3FD338ACF6D509741D80FEC837 (void);
// 0x000001E1 System.Void System.Text.RegularExpressions.RegexRunner::Uncapture()
extern void RegexRunner_Uncapture_mA7163C77BE1683E508821AB251F33FB7520CE3F8 (void);
// 0x000001E2 System.Boolean System.Text.RegularExpressions.RegexRunner::IsMatched(System.Int32)
extern void RegexRunner_IsMatched_mD7F580AA0533D5C4BC41D18824FA74BE16EAE7A3 (void);
// 0x000001E3 System.Int32 System.Text.RegularExpressions.RegexRunner::MatchIndex(System.Int32)
extern void RegexRunner_MatchIndex_mA8EEC418C65572A82720F5D16BAC99224CF0251A (void);
// 0x000001E4 System.Int32 System.Text.RegularExpressions.RegexRunner::MatchLength(System.Int32)
extern void RegexRunner_MatchLength_m06FA694D5EFE42F89C25C8599BBE86C7726DB2C6 (void);
// 0x000001E5 System.Text.RegularExpressions.RegexRunner System.Text.RegularExpressions.RegexRunnerFactory::CreateInstance()
// 0x000001E6 System.Void System.Text.RegularExpressions.RegexTree::.ctor(System.Text.RegularExpressions.RegexNode,System.Collections.Hashtable,System.Int32[],System.Int32,System.Collections.Hashtable,System.String[],System.Text.RegularExpressions.RegexOptions)
extern void RegexTree__ctor_m5B10D5149928B35CE397472028EE327669C211DA (void);
// 0x000001E7 System.Text.RegularExpressions.RegexCode System.Text.RegularExpressions.RegexWriter::Write(System.Text.RegularExpressions.RegexTree)
extern void RegexWriter_Write_m57CF8209EF566CD40F9146C74DF889C8AA06E061 (void);
// 0x000001E8 System.Void System.Text.RegularExpressions.RegexWriter::.ctor()
extern void RegexWriter__ctor_m63A858FAE36A8640812DFF917751C1E215A2AE82 (void);
// 0x000001E9 System.Void System.Text.RegularExpressions.RegexWriter::PushInt(System.Int32)
extern void RegexWriter_PushInt_mFBC85956A26FEBC66244C8DFC881106D85DD2C1D (void);
// 0x000001EA System.Boolean System.Text.RegularExpressions.RegexWriter::EmptyStack()
extern void RegexWriter_EmptyStack_mB0C109FA21F5CFD16A34438BA1CC1CE8BED91E7C (void);
// 0x000001EB System.Int32 System.Text.RegularExpressions.RegexWriter::PopInt()
extern void RegexWriter_PopInt_m8885F9428571674EC224D6BBC93570B1B4671713 (void);
// 0x000001EC System.Int32 System.Text.RegularExpressions.RegexWriter::CurPos()
extern void RegexWriter_CurPos_mEA105879492A4B415FA8AC25B29AA49153F83C18 (void);
// 0x000001ED System.Void System.Text.RegularExpressions.RegexWriter::PatchJump(System.Int32,System.Int32)
extern void RegexWriter_PatchJump_m6C0A440142E7AC772AD4AF7DF5D8291B6CA6D7D2 (void);
// 0x000001EE System.Void System.Text.RegularExpressions.RegexWriter::Emit(System.Int32)
extern void RegexWriter_Emit_mDC0B76CE49A6DE83DD2D169236BCD516AE9263EF (void);
// 0x000001EF System.Void System.Text.RegularExpressions.RegexWriter::Emit(System.Int32,System.Int32)
extern void RegexWriter_Emit_m6B0ACB44155A07161060838F483D555E7EF6ACED (void);
// 0x000001F0 System.Void System.Text.RegularExpressions.RegexWriter::Emit(System.Int32,System.Int32,System.Int32)
extern void RegexWriter_Emit_m7C1D08F071C805F13DBF7684AEC3F2F7E748C497 (void);
// 0x000001F1 System.Int32 System.Text.RegularExpressions.RegexWriter::StringCode(System.String)
extern void RegexWriter_StringCode_m6AA17FFEBDD5E155004F05A78CF13B0D8E901158 (void);
// 0x000001F2 System.ArgumentException System.Text.RegularExpressions.RegexWriter::MakeException(System.String)
extern void RegexWriter_MakeException_m443C4CFA99AE06710D1E1BFA3D6EB9737AE70F17 (void);
// 0x000001F3 System.Int32 System.Text.RegularExpressions.RegexWriter::MapCapnum(System.Int32)
extern void RegexWriter_MapCapnum_m6AFE8BED80960BAA522EAA873D535C9D5AD4B811 (void);
// 0x000001F4 System.Text.RegularExpressions.RegexCode System.Text.RegularExpressions.RegexWriter::RegexCodeFromRegexTree(System.Text.RegularExpressions.RegexTree)
extern void RegexWriter_RegexCodeFromRegexTree_mAC489A29C00688CA929661BC394F1C4CF997CFC5 (void);
// 0x000001F5 System.Void System.Text.RegularExpressions.RegexWriter::EmitFragment(System.Int32,System.Text.RegularExpressions.RegexNode,System.Int32)
extern void RegexWriter_EmitFragment_mEFDD8EA3A65320222CF4EA8A52B33C687EE0C5AC (void);
// 0x000001F6 System.Int64 System.Diagnostics.Stopwatch::GetTimestamp()
extern void Stopwatch_GetTimestamp_m7A4B2D144D880343DB783326F36F6996C1D1A1CA (void);
// 0x000001F7 System.Void System.Diagnostics.Stopwatch::.ctor()
extern void Stopwatch__ctor_mA301E9A9D03758CBE09171E0C140CCD06BC9F860 (void);
// 0x000001F8 System.TimeSpan System.Diagnostics.Stopwatch::get_Elapsed()
extern void Stopwatch_get_Elapsed_m6735B32BFB466FC4F52112AC3493D37404D184BB (void);
// 0x000001F9 System.Int64 System.Diagnostics.Stopwatch::get_ElapsedMilliseconds()
extern void Stopwatch_get_ElapsedMilliseconds_mE39424FB61C885BCFCC4B583C58A8630C3AD8177 (void);
// 0x000001FA System.Int64 System.Diagnostics.Stopwatch::get_ElapsedTicks()
extern void Stopwatch_get_ElapsedTicks_mABB4710231090C75F057E90A29C71C553077A901 (void);
// 0x000001FB System.Void System.Diagnostics.Stopwatch::Start()
extern void Stopwatch_Start_mF61332B96D7753ADA18366A29E22E2A92E25739A (void);
// 0x000001FC System.Void System.Diagnostics.Stopwatch::.cctor()
extern void Stopwatch__cctor_m137C0B2E7182FAEA6E030CD1EDC909E5A3F7A064 (void);
// 0x000001FD System.Void System.ComponentModel.ArrayConverter::.ctor()
extern void ArrayConverter__ctor_m831D145364A55A155BC896935367961A476D53B7 (void);
// 0x000001FE System.Void System.ComponentModel.BooleanConverter::.ctor()
extern void BooleanConverter__ctor_m8293C29BCB7B90516FFE978C6295C0378C1BFEE4 (void);
// 0x000001FF System.Void System.ComponentModel.CollectionConverter::.ctor()
extern void CollectionConverter__ctor_m86DBE477F4462418329C5CFB45C86A9420F852E7 (void);
// 0x00000200 System.Void System.ComponentModel.DecimalConverter::.ctor()
extern void DecimalConverter__ctor_mB015B3871CF834D0C5D8290C9FD15509249921E7 (void);
// 0x00000201 System.Void System.ComponentModel.DoubleConverter::.ctor()
extern void DoubleConverter__ctor_m419F1E782FFBC765D22792D76E56D54FC94E6AEB (void);
// 0x00000202 System.Void System.ComponentModel.EditorBrowsableAttribute::.ctor(System.ComponentModel.EditorBrowsableState)
extern void EditorBrowsableAttribute__ctor_mACDE45DF0DCAA6E923120D6AEC45422AEF958C2E (void);
// 0x00000203 System.Boolean System.ComponentModel.EditorBrowsableAttribute::Equals(System.Object)
extern void EditorBrowsableAttribute_Equals_m6F5EF9CC298CBDC862CBCA5187379A79635726FA (void);
// 0x00000204 System.Int32 System.ComponentModel.EditorBrowsableAttribute::GetHashCode()
extern void EditorBrowsableAttribute_GetHashCode_m74229847CE44E771F282E2E73FFC4DE55771A1B6 (void);
// 0x00000205 System.Void System.ComponentModel.EnumConverter::.ctor(System.Type)
extern void EnumConverter__ctor_mBA8B2E210D061A3CF86950F6D797E911A2E3C774 (void);
// 0x00000206 System.Void System.ComponentModel.Int16Converter::.ctor()
extern void Int16Converter__ctor_mD4D022096E6FB9FFDB84D879E31177A892DD072D (void);
// 0x00000207 System.Void System.ComponentModel.Int32Converter::.ctor()
extern void Int32Converter__ctor_m1CD79AE5880FDE2EC91F1D67E567AAA3618D19B9 (void);
// 0x00000208 System.Void System.ComponentModel.Int64Converter::.ctor()
extern void Int64Converter__ctor_mE4DC71A97EF110B854F22A48AB0F0D3792B53A74 (void);
// 0x00000209 System.Void System.ComponentModel.SingleConverter::.ctor()
extern void SingleConverter__ctor_m8EA7D412C3EE9A9522E7592774DD46EBC6118AA8 (void);
// 0x0000020A System.Void System.ComponentModel.StringConverter::.ctor()
extern void StringConverter__ctor_m2718AC00691AF4A3AF8A8D64896BE3B5D58658B2 (void);
// 0x0000020B System.Void System.ComponentModel.TimeSpanConverter::.ctor()
extern void TimeSpanConverter__ctor_m28E7294174F979EF86FEF9511474B0AB9431217B (void);
// 0x0000020C System.Void System.ComponentModel.TypeConverter::.ctor()
extern void TypeConverter__ctor_m7F8A006E775CCB83A8ACB042B296E48B0AE501CD (void);
// 0x0000020D System.Void System.ComponentModel.TypeConverterAttribute::.ctor()
extern void TypeConverterAttribute__ctor_mD0795A29B6FD59978CAAC6DAF3AC7EC564C519A5 (void);
// 0x0000020E System.Void System.ComponentModel.TypeConverterAttribute::.ctor(System.Type)
extern void TypeConverterAttribute__ctor_m52D4E66A914F1A04F2F10A7131A701670225D41C (void);
// 0x0000020F System.String System.ComponentModel.TypeConverterAttribute::get_ConverterTypeName()
extern void TypeConverterAttribute_get_ConverterTypeName_m883941C77E14FC5B4A3E32DD8F59F11739D5D6D8 (void);
// 0x00000210 System.Boolean System.ComponentModel.TypeConverterAttribute::Equals(System.Object)
extern void TypeConverterAttribute_Equals_mDA74DFC28CC7ABC315407EDD1AAC14531C5F6AC4 (void);
// 0x00000211 System.Int32 System.ComponentModel.TypeConverterAttribute::GetHashCode()
extern void TypeConverterAttribute_GetHashCode_m35874D49724DA3F72C6C2575FD595A711A659DAA (void);
// 0x00000212 System.Void System.ComponentModel.TypeConverterAttribute::.cctor()
extern void TypeConverterAttribute__cctor_mB1A775F56A5933A17CF349BD466B0CCE66B1078A (void);
// 0x00000213 System.Void System.ComponentModel.Win32Exception::.ctor()
extern void Win32Exception__ctor_mC03E215A1695ED64DDC50F4BE9F59966974DF759 (void);
// 0x00000214 System.Void System.ComponentModel.Win32Exception::.ctor(System.Int32)
extern void Win32Exception__ctor_m2BEA755F6AA536ADDDF07D83BD8297F02584F714 (void);
// 0x00000215 System.Void System.ComponentModel.Win32Exception::.ctor(System.Int32,System.String)
extern void Win32Exception__ctor_m94A043EE26097BBFE0ED22FD4EBEA357F142EFE6 (void);
// 0x00000216 System.Void System.ComponentModel.Win32Exception::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Win32Exception__ctor_mC7ADDE9D2FEE4E17432F63C24EF1D872380094DB (void);
// 0x00000217 System.Void System.ComponentModel.Win32Exception::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Win32Exception_GetObjectData_m7CD0D7A0806E4A9D8E78ADCBC616700379AB79E8 (void);
// 0x00000218 System.String System.ComponentModel.Win32Exception::GetErrorMessage(System.Int32)
extern void Win32Exception_GetErrorMessage_m6085687D868718B45289CB6AF6EDCB7F89D7350D (void);
// 0x00000219 System.Void System.ComponentModel.Win32Exception::InitializeErrorMessages()
extern void Win32Exception_InitializeErrorMessages_m4FE6F56C1C2CCB3F6468F0F9F5AD6E1B08673438 (void);
// 0x0000021A System.Void System.ComponentModel.Win32Exception::.cctor()
extern void Win32Exception__cctor_m800CD9D0B3E3253B79A19B6646A7D28B29C3FC52 (void);
// 0x0000021B System.Void System.ComponentModel.BaseNumberConverter::.ctor()
extern void BaseNumberConverter__ctor_mD78E1C7E1F8A977BC7AD33DB0C1E5E32C60E8E83 (void);
// 0x0000021C System.Void System.Security.Cryptography.Oid::.ctor(System.String)
extern void Oid__ctor_m45F49EB1ABFD4F3EB0FC9729C76FF83995752743 (void);
// 0x0000021D System.Void System.Security.Cryptography.Oid::.ctor(System.String,System.Security.Cryptography.OidGroup,System.Boolean)
extern void Oid__ctor_m67437A59D4E75ABF6E40D503F57F81199546E5EC (void);
// 0x0000021E System.Void System.Security.Cryptography.Oid::.ctor(System.String,System.String)
extern void Oid__ctor_m0656E1FC1A7E7BBF694A568DDDF8BE4AFA544985 (void);
// 0x0000021F System.Void System.Security.Cryptography.Oid::.ctor(System.Security.Cryptography.Oid)
extern void Oid__ctor_mA7AFE14DF30B47447BFFC9E41B37B8DB46C9D079 (void);
// 0x00000220 System.String System.Security.Cryptography.Oid::get_Value()
extern void Oid_get_Value_mFE18BDFF095DD5A6643F4FEC3E57846716F37F05 (void);
// 0x00000221 System.Void System.Security.Cryptography.Oid::set_Value(System.String)
extern void Oid_set_Value_m304CEF248379566701402100FA015EAC640C033F (void);
// 0x00000222 System.Void System.Security.Cryptography.OidCollection::.ctor()
extern void OidCollection__ctor_m99B93BB5B35BF7A395CFB7F8B155DFA8DD734800 (void);
// 0x00000223 System.Int32 System.Security.Cryptography.OidCollection::Add(System.Security.Cryptography.Oid)
extern void OidCollection_Add_m1FF686421A22A86F8296259D99DA38E02B8BBF5C (void);
// 0x00000224 System.Security.Cryptography.Oid System.Security.Cryptography.OidCollection::get_Item(System.Int32)
extern void OidCollection_get_Item_mB37F923F4714BFE0DF44E8EE4A1A5EA1F3EBB1D9 (void);
// 0x00000225 System.Int32 System.Security.Cryptography.OidCollection::get_Count()
extern void OidCollection_get_Count_m6AC0709CDD68451F4CAC942CE94A5A97F3C294B2 (void);
// 0x00000226 System.Collections.IEnumerator System.Security.Cryptography.OidCollection::System.Collections.IEnumerable.GetEnumerator()
extern void OidCollection_System_Collections_IEnumerable_GetEnumerator_m3FD3A96DFF93BD88A3B28E35A4DEF57AF25ECB30 (void);
// 0x00000227 System.Void System.Security.Cryptography.OidCollection::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
extern void OidCollection_System_Collections_ICollection_CopyTo_mE508CB1FD9E56CCFE5A4BDD5251D815BF78AC5A9 (void);
// 0x00000228 System.Void System.Security.Cryptography.OidEnumerator::.ctor(System.Security.Cryptography.OidCollection)
extern void OidEnumerator__ctor_mCA4FBC8408E2B04FD0A524E256E284E8A44E0797 (void);
// 0x00000229 System.Object System.Security.Cryptography.OidEnumerator::System.Collections.IEnumerator.get_Current()
extern void OidEnumerator_System_Collections_IEnumerator_get_Current_mF11B1F886842EA79EDB215BD5106D0C4C65EBE53 (void);
// 0x0000022A System.Boolean System.Security.Cryptography.OidEnumerator::MoveNext()
extern void OidEnumerator_MoveNext_m073D94D5D3254D53DF53429ACAD0AA9BD682221D (void);
// 0x0000022B System.Void System.Security.Cryptography.OidEnumerator::Reset()
extern void OidEnumerator_Reset_m5006C3B1283711E2BDDEA6C25FDF93BBB900195E (void);
// 0x0000022C System.String System.Security.Cryptography.CAPI::CryptFindOIDInfoNameFromKey(System.String,System.Security.Cryptography.OidGroup)
extern void CAPI_CryptFindOIDInfoNameFromKey_mA2FD2F391E133E586BC8B827DD916613B590E698 (void);
// 0x0000022D System.String System.Security.Cryptography.CAPI::CryptFindOIDInfoKeyFromName(System.String,System.Security.Cryptography.OidGroup)
extern void CAPI_CryptFindOIDInfoKeyFromName_m7809CD491D913D58FA1B996B835A0A91C413E9DB (void);
// 0x0000022E System.Void System.Security.Cryptography.AsnEncodedData::.ctor()
extern void AsnEncodedData__ctor_mED24E9D1F11942741819652302C0531D18C39BE6 (void);
// 0x0000022F System.Void System.Security.Cryptography.AsnEncodedData::set_Oid(System.Security.Cryptography.Oid)
extern void AsnEncodedData_set_Oid_m91E38503AAFD8E6FD98970D94FD43E7A738242A6 (void);
// 0x00000230 System.Byte[] System.Security.Cryptography.AsnEncodedData::get_RawData()
extern void AsnEncodedData_get_RawData_mB9F8281A96011161C67EB3A9208E26C423B187EC (void);
// 0x00000231 System.Void System.Security.Cryptography.AsnEncodedData::set_RawData(System.Byte[])
extern void AsnEncodedData_set_RawData_mD7FE2383373A6AF578A4983999D677B58BD6B4EC (void);
// 0x00000232 System.Void System.Security.Cryptography.AsnEncodedData::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void AsnEncodedData_CopyFrom_m3937C7ACC425960B8E48B7D2EB50E9417A7CD4B7 (void);
// 0x00000233 System.String System.Security.Cryptography.AsnEncodedData::ToString(System.Boolean)
extern void AsnEncodedData_ToString_m502785F2F8B4D1EBDF5CEE612FD8D0C2044390D7 (void);
// 0x00000234 System.String System.Security.Cryptography.AsnEncodedData::Default(System.Boolean)
extern void AsnEncodedData_Default_mEEA94BA253ED1B8A719466A8152A5333E0E3FF07 (void);
// 0x00000235 System.String System.Security.Cryptography.AsnEncodedData::BasicConstraintsExtension(System.Boolean)
extern void AsnEncodedData_BasicConstraintsExtension_m64D690A2456E16AF39F6F0784CE74BC9533BB182 (void);
// 0x00000236 System.String System.Security.Cryptography.AsnEncodedData::EnhancedKeyUsageExtension(System.Boolean)
extern void AsnEncodedData_EnhancedKeyUsageExtension_mE04DC17ACCBF3850AFBA454D9937EC4713CC5058 (void);
// 0x00000237 System.String System.Security.Cryptography.AsnEncodedData::KeyUsageExtension(System.Boolean)
extern void AsnEncodedData_KeyUsageExtension_m4EE74EA5C4A3C0B72C50DEB22A537812997AF590 (void);
// 0x00000238 System.String System.Security.Cryptography.AsnEncodedData::SubjectKeyIdentifierExtension(System.Boolean)
extern void AsnEncodedData_SubjectKeyIdentifierExtension_m261D32E7AE226499BA8AD3FBE24FC0E71C9DEB76 (void);
// 0x00000239 System.String System.Security.Cryptography.AsnEncodedData::SubjectAltName(System.Boolean)
extern void AsnEncodedData_SubjectAltName_m94FE55170A872B3174D5C495A27AD09F3BACAF49 (void);
// 0x0000023A System.String System.Security.Cryptography.AsnEncodedData::NetscapeCertType(System.Boolean)
extern void AsnEncodedData_NetscapeCertType_m9191830C380BEC39DBE09065B2A4134193EA92D4 (void);
// 0x0000023B System.String System.Security.Cryptography.X509Certificates.X509Utils::FindOidInfo(System.UInt32,System.String,System.Security.Cryptography.OidGroup)
extern void X509Utils_FindOidInfo_mE43E0522988511319B8B9F69AF7D0A10B4AE8FA2 (void);
// 0x0000023C System.String System.Security.Cryptography.X509Certificates.X509Utils::FindOidInfoWithFallback(System.UInt32,System.String,System.Security.Cryptography.OidGroup)
extern void X509Utils_FindOidInfoWithFallback_m98443176879ABC2054619D4AA491FE086D406950 (void);
// 0x0000023D System.Security.Cryptography.AsnEncodedData System.Security.Cryptography.X509Certificates.PublicKey::get_EncodedKeyValue()
extern void PublicKey_get_EncodedKeyValue_m4BD0975B491E89FFE2A75C1ACDEB1DCCAF586D4F (void);
// 0x0000023E System.Security.Cryptography.AsnEncodedData System.Security.Cryptography.X509Certificates.PublicKey::get_EncodedParameters()
extern void PublicKey_get_EncodedParameters_m629FF8D7E4EEDED96BC455B7B953DC5A46D26F4F (void);
// 0x0000023F System.Security.Cryptography.Oid System.Security.Cryptography.X509Certificates.PublicKey::get_Oid()
extern void PublicKey_get_Oid_mB0AD65FDF84716726D5C7756E5B50CEAD1E4C2AE (void);
// 0x00000240 System.Void System.Security.Cryptography.X509Certificates.PublicKey::.cctor()
extern void PublicKey__cctor_m9F739A93AE91AE86889835AAE256410F4DB808CC (void);
// 0x00000241 System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::.ctor()
extern void X509BasicConstraintsExtension__ctor_m1D3F45762EB686500D2195886AD26FF84E5F4B3C (void);
// 0x00000242 System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509BasicConstraintsExtension__ctor_mEED7AECEE911DF6CE692301F8F6F6B197DC05729 (void);
// 0x00000243 System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::.ctor(System.Boolean,System.Boolean,System.Int32,System.Boolean)
extern void X509BasicConstraintsExtension__ctor_mD08FE3682F4B2EA23450C6609360F45656495780 (void);
// 0x00000244 System.Boolean System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::get_CertificateAuthority()
extern void X509BasicConstraintsExtension_get_CertificateAuthority_m282E5D9E7640A06AF2CE06A0FA374571F25BAB6F (void);
// 0x00000245 System.Boolean System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::get_HasPathLengthConstraint()
extern void X509BasicConstraintsExtension_get_HasPathLengthConstraint_m463A8B4DF4BEB46A9353309AA5EF3EAA2F7A4D42 (void);
// 0x00000246 System.Int32 System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::get_PathLengthConstraint()
extern void X509BasicConstraintsExtension_get_PathLengthConstraint_m93EF2B2BA6D6AD72DE59D98EB0E40DDD2AB3B49F (void);
// 0x00000247 System.Void System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509BasicConstraintsExtension_CopyFrom_mE64F232FB7DF702DCDB6692537B8F1010AA316DC (void);
// 0x00000248 System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::Decode(System.Byte[])
extern void X509BasicConstraintsExtension_Decode_m40A688DD3A933B24A3E9EFE505299F70AFF32E81 (void);
// 0x00000249 System.Byte[] System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::Encode()
extern void X509BasicConstraintsExtension_Encode_m04068558E7AF843C57A8BA9C39E251B7B37A1CDF (void);
// 0x0000024A System.String System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension::ToString(System.Boolean)
extern void X509BasicConstraintsExtension_ToString_m75957B2B18A84645897676F0DAC473F022848336 (void);
// 0x0000024B System.Void System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509EnhancedKeyUsageExtension__ctor_mC91E46E79086AAFCD611FB3A223797D20BA9C1C2 (void);
// 0x0000024C System.Void System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509EnhancedKeyUsageExtension_CopyFrom_mC206A056C8C59401AA01F8C935DDE27D7E34D96A (void);
// 0x0000024D System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::Decode(System.Byte[])
extern void X509EnhancedKeyUsageExtension_Decode_m1865B86FE190237641C00804A058BF56F125183D (void);
// 0x0000024E System.String System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension::ToString(System.Boolean)
extern void X509EnhancedKeyUsageExtension_ToString_m99085514587961F4AB1CA3FB82E5223801475818 (void);
// 0x0000024F System.Void System.Security.Cryptography.X509Certificates.X509Extension::.ctor()
extern void X509Extension__ctor_m75C6A788965E9C797F3D47DEFEC366EC2F69F384 (void);
// 0x00000250 System.Boolean System.Security.Cryptography.X509Certificates.X509Extension::get_Critical()
extern void X509Extension_get_Critical_m8F4D4C2F0ECBE5CB4C9998CE3E56D5040E2EEBE2 (void);
// 0x00000251 System.Void System.Security.Cryptography.X509Certificates.X509Extension::set_Critical(System.Boolean)
extern void X509Extension_set_Critical_mA2B424FF17DE53E01E586015DD1C742773B060B4 (void);
// 0x00000252 System.Void System.Security.Cryptography.X509Certificates.X509Extension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509Extension_CopyFrom_m03B3EAD99E076090F01D26FF483E827397903A02 (void);
// 0x00000253 System.String System.Security.Cryptography.X509Certificates.X509Extension::FormatUnkownData(System.Byte[])
extern void X509Extension_FormatUnkownData_mE5BAB7DB56CE215EB704A7E4E6866EBECA18F90A (void);
// 0x00000254 System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::.ctor()
extern void X509KeyUsageExtension__ctor_mCCDDE2A55EF78832C8117C680FB264CE91893A99 (void);
// 0x00000255 System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509KeyUsageExtension__ctor_mA9DDAD17EA38ABB83CD6CC9A353A0667A9EAC018 (void);
// 0x00000256 System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::.ctor(System.Security.Cryptography.X509Certificates.X509KeyUsageFlags,System.Boolean)
extern void X509KeyUsageExtension__ctor_mBC544E9444992C7883638DB0B4607945F33E7426 (void);
// 0x00000257 System.Security.Cryptography.X509Certificates.X509KeyUsageFlags System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::get_KeyUsages()
extern void X509KeyUsageExtension_get_KeyUsages_m9544DC0FAAD02C53D6C649E1831176CB54EFE505 (void);
// 0x00000258 System.Void System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509KeyUsageExtension_CopyFrom_m8DA1FA691943CBD4B94E45096E83FC5EA9EEEA3F (void);
// 0x00000259 System.Security.Cryptography.X509Certificates.X509KeyUsageFlags System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::GetValidFlags(System.Security.Cryptography.X509Certificates.X509KeyUsageFlags)
extern void X509KeyUsageExtension_GetValidFlags_m7946BD756F14B17D707EE12E7D82878531D115EB (void);
// 0x0000025A System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::Decode(System.Byte[])
extern void X509KeyUsageExtension_Decode_mDE97A425A199661D89FE252A75C8644D4280F1B2 (void);
// 0x0000025B System.Byte[] System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::Encode()
extern void X509KeyUsageExtension_Encode_mBBF95E13B1FE1A0507FD692F770D6E98A68E3360 (void);
// 0x0000025C System.String System.Security.Cryptography.X509Certificates.X509KeyUsageExtension::ToString(System.Boolean)
extern void X509KeyUsageExtension_ToString_m4455C1B31C62530B930CFADE55DC0E77C60C7EFC (void);
// 0x0000025D System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor()
extern void X509SubjectKeyIdentifierExtension__ctor_mD586705C293A9C27B5B57BF9CF1D8EAD84864B29 (void);
// 0x0000025E System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Security.Cryptography.AsnEncodedData,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m45218EE7D32231FA6C44A40FEC2E5052162012D6 (void);
// 0x0000025F System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Byte[],System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m182458124147FFEE402584E6415C2EA407B59C5B (void);
// 0x00000260 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.String,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m95DD08883D5E284C15820274737324063C4E4432 (void);
// 0x00000261 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Security.Cryptography.X509Certificates.PublicKey,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_m98571FC543622A4BD3EA7788BB132348D9E0A3E3 (void);
// 0x00000262 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::.ctor(System.Security.Cryptography.X509Certificates.PublicKey,System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierHashAlgorithm,System.Boolean)
extern void X509SubjectKeyIdentifierExtension__ctor_mF692F46CE97CB60AF86C1A74E709E8276B7D9AB1 (void);
// 0x00000263 System.String System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::get_SubjectKeyIdentifier()
extern void X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m3480A14D8377B6C2D220F99D37AB8B13BEFE76FF (void);
// 0x00000264 System.Void System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::CopyFrom(System.Security.Cryptography.AsnEncodedData)
extern void X509SubjectKeyIdentifierExtension_CopyFrom_m45E7EB4E976E4759046077C79FBC4A820C9A95EC (void);
// 0x00000265 System.Byte System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::FromHexChar(System.Char)
extern void X509SubjectKeyIdentifierExtension_FromHexChar_m7BDBE176CD85DCA3193FECF78D6CF15E349121BC (void);
// 0x00000266 System.Byte System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::FromHexChars(System.Char,System.Char)
extern void X509SubjectKeyIdentifierExtension_FromHexChars_mB2D3EBC7E627D44254A82E5628A2079C1DB24C38 (void);
// 0x00000267 System.Byte[] System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::FromHex(System.String)
extern void X509SubjectKeyIdentifierExtension_FromHex_m654E8BB1D2F9D8C878EF854D7933C6EA825F272B (void);
// 0x00000268 System.Security.Cryptography.AsnDecodeStatus System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::Decode(System.Byte[])
extern void X509SubjectKeyIdentifierExtension_Decode_m6EB136D7525F3DFB9FA93F8B3653D2F6FA3B72D1 (void);
// 0x00000269 System.Byte[] System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::Encode()
extern void X509SubjectKeyIdentifierExtension_Encode_m11C84A3DCE621526C1FC282E214001D70937D6BD (void);
// 0x0000026A System.String System.Security.Cryptography.X509Certificates.X509SubjectKeyIdentifierExtension::ToString(System.Boolean)
extern void X509SubjectKeyIdentifierExtension_ToString_mB22086D5277B22093240BB9841D32D9008D26AFA (void);
// 0x0000026B System.Void System.Net.EndPoint::.ctor()
extern void EndPoint__ctor_mFCD3A4BB994F59D40A3A94A6F1DEC4A731CC8776 (void);
// 0x0000026C System.Void System.Net.IPAddress::.ctor(System.Int64)
extern void IPAddress__ctor_mFD0AF2F6A282D1158DF3C34EF2E63B73814E7748 (void);
// 0x0000026D System.Void System.Net.IPAddress::.ctor(System.Byte[],System.Int64)
extern void IPAddress__ctor_m373D3930BEEA00EC628E98C5A13AE9BE2B2CEC84 (void);
// 0x0000026E System.Void System.Net.IPAddress::.ctor(System.Int32)
extern void IPAddress__ctor_mCC321EEDA0750DA97447EB60529BCBCB4EA0249D (void);
// 0x0000026F System.Int64 System.Net.IPAddress::get_ScopeId()
extern void IPAddress_get_ScopeId_m941461DEBDECCD858F8D3165F3CA366A318064D9 (void);
// 0x00000270 System.String System.Net.IPAddress::ToString()
extern void IPAddress_ToString_m0CAEDDAF2A42F23EB1BE3BB353ABE741486710BF (void);
// 0x00000271 System.Boolean System.Net.IPAddress::Equals(System.Object,System.Boolean)
extern void IPAddress_Equals_mADA54686760DE75E2C31B8651224FFEB019316D6 (void);
// 0x00000272 System.Boolean System.Net.IPAddress::Equals(System.Object)
extern void IPAddress_Equals_mB38BAC1A15885A3181507BC9FD4E8F5765FA6678 (void);
// 0x00000273 System.Int32 System.Net.IPAddress::GetHashCode()
extern void IPAddress_GetHashCode_m36CE850AFAAD382A29B7D72844989A3105565D7C (void);
// 0x00000274 System.Void System.Net.IPAddress::.cctor()
extern void IPAddress__cctor_m4DF372012DF900E7BB489931296D0BFE4EBD4AEA (void);
// 0x00000275 System.Void System.Net.IPv6AddressFormatter::.ctor(System.UInt16[],System.Int64)
extern void IPv6AddressFormatter__ctor_m94725668992E78AA0D75E1C072E8A567E9C34497_AdjustorThunk (void);
// 0x00000276 System.UInt16 System.Net.IPv6AddressFormatter::SwapUShort(System.UInt16)
extern void IPv6AddressFormatter_SwapUShort_m6B7BA905E96BB0889C580EE25F3614C7A4A9164C (void);
// 0x00000277 System.UInt32 System.Net.IPv6AddressFormatter::AsIPv4Int()
extern void IPv6AddressFormatter_AsIPv4Int_m94B06C695C45C85A90F95CAAF4430772EFC16C4F_AdjustorThunk (void);
// 0x00000278 System.Boolean System.Net.IPv6AddressFormatter::IsIPv4Compatible()
extern void IPv6AddressFormatter_IsIPv4Compatible_mDC05432DB57ED01219A35BD1B712E589A527A5FC_AdjustorThunk (void);
// 0x00000279 System.Boolean System.Net.IPv6AddressFormatter::IsIPv4Mapped()
extern void IPv6AddressFormatter_IsIPv4Mapped_m0BEBB1DE4A773028D3091D8321106BE92519A127_AdjustorThunk (void);
// 0x0000027A System.String System.Net.IPv6AddressFormatter::ToString()
extern void IPv6AddressFormatter_ToString_mBBBF9A3ABB56F52589BD211DD827015066076C8F_AdjustorThunk (void);
// 0x0000027B System.Int32 System.Net.Sockets.SocketException::WSAGetLastError_internal()
extern void SocketException_WSAGetLastError_internal_m18F05CF8D9CE2435225A4215ED757D8D98716FC3 (void);
// 0x0000027C System.Void System.Net.Sockets.SocketException::.ctor()
extern void SocketException__ctor_mB16B95B2752EAD626C88A5230C1A8FEB7CF632CA (void);
// 0x0000027D System.Void System.Net.Sockets.SocketException::.ctor(System.Net.Sockets.SocketError)
extern void SocketException__ctor_m2687C4EFA4D012280C5D19B89D8D01F97B6A2F1A (void);
// 0x0000027E System.Void System.Net.Sockets.SocketException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void SocketException__ctor_m4C36461DF98089890FBF01908A4AAD301CABE071 (void);
// 0x0000027F System.String System.Net.Sockets.SocketException::get_Message()
extern void SocketException_get_Message_m50B9DF4BB6F3B20F650E2F965B3DD654C8970378 (void);
// 0x00000280 System.Void System.Collections.Generic.LinkedList`1::.ctor()
// 0x00000281 System.Void System.Collections.Generic.LinkedList`1::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x00000282 System.Int32 System.Collections.Generic.LinkedList`1::get_Count()
// 0x00000283 System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedList`1::get_First()
// 0x00000284 System.Boolean System.Collections.Generic.LinkedList`1::System.Collections.Generic.ICollection<T>.get_IsReadOnly()
// 0x00000285 System.Void System.Collections.Generic.LinkedList`1::System.Collections.Generic.ICollection<T>.Add(T)
// 0x00000286 System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedList`1::AddFirst(T)
// 0x00000287 System.Void System.Collections.Generic.LinkedList`1::AddFirst(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000288 System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedList`1::AddLast(T)
// 0x00000289 System.Void System.Collections.Generic.LinkedList`1::Clear()
// 0x0000028A System.Boolean System.Collections.Generic.LinkedList`1::Contains(T)
// 0x0000028B System.Void System.Collections.Generic.LinkedList`1::CopyTo(T[],System.Int32)
// 0x0000028C System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedList`1::Find(T)
// 0x0000028D System.Collections.Generic.LinkedList`1_Enumerator<T> System.Collections.Generic.LinkedList`1::GetEnumerator()
// 0x0000028E System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.LinkedList`1::System.Collections.Generic.IEnumerable<T>.GetEnumerator()
// 0x0000028F System.Boolean System.Collections.Generic.LinkedList`1::Remove(T)
// 0x00000290 System.Void System.Collections.Generic.LinkedList`1::Remove(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000291 System.Void System.Collections.Generic.LinkedList`1::RemoveLast()
// 0x00000292 System.Void System.Collections.Generic.LinkedList`1::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x00000293 System.Void System.Collections.Generic.LinkedList`1::OnDeserialization(System.Object)
// 0x00000294 System.Void System.Collections.Generic.LinkedList`1::InternalInsertNodeBefore(System.Collections.Generic.LinkedListNode`1<T>,System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000295 System.Void System.Collections.Generic.LinkedList`1::InternalInsertNodeToEmptyList(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000296 System.Void System.Collections.Generic.LinkedList`1::InternalRemoveNode(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000297 System.Void System.Collections.Generic.LinkedList`1::ValidateNewNode(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000298 System.Void System.Collections.Generic.LinkedList`1::ValidateNode(System.Collections.Generic.LinkedListNode`1<T>)
// 0x00000299 System.Void System.Collections.Generic.LinkedList`1::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
// 0x0000029A System.Collections.IEnumerator System.Collections.Generic.LinkedList`1::System.Collections.IEnumerable.GetEnumerator()
// 0x0000029B System.Void System.Collections.Generic.LinkedList`1_Enumerator::.ctor(System.Collections.Generic.LinkedList`1<T>)
// 0x0000029C System.Void System.Collections.Generic.LinkedList`1_Enumerator::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x0000029D T System.Collections.Generic.LinkedList`1_Enumerator::get_Current()
// 0x0000029E System.Object System.Collections.Generic.LinkedList`1_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x0000029F System.Boolean System.Collections.Generic.LinkedList`1_Enumerator::MoveNext()
// 0x000002A0 System.Void System.Collections.Generic.LinkedList`1_Enumerator::System.Collections.IEnumerator.Reset()
// 0x000002A1 System.Void System.Collections.Generic.LinkedList`1_Enumerator::Dispose()
// 0x000002A2 System.Void System.Collections.Generic.LinkedList`1_Enumerator::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
// 0x000002A3 System.Void System.Collections.Generic.LinkedList`1_Enumerator::System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(System.Object)
// 0x000002A4 System.Void System.Collections.Generic.LinkedListNode`1::.ctor(System.Collections.Generic.LinkedList`1<T>,T)
// 0x000002A5 System.Collections.Generic.LinkedListNode`1<T> System.Collections.Generic.LinkedListNode`1::get_Next()
// 0x000002A6 T System.Collections.Generic.LinkedListNode`1::get_Value()
// 0x000002A7 System.Void System.Collections.Generic.LinkedListNode`1::Invalidate()
// 0x000002A8 System.Void System.Collections.Generic.Queue`1::.ctor()
// 0x000002A9 System.Int32 System.Collections.Generic.Queue`1::get_Count()
// 0x000002AA System.Void System.Collections.Generic.Queue`1::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
// 0x000002AB System.Void System.Collections.Generic.Queue`1::Enqueue(T)
// 0x000002AC System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.Queue`1::System.Collections.Generic.IEnumerable<T>.GetEnumerator()
// 0x000002AD System.Collections.IEnumerator System.Collections.Generic.Queue`1::System.Collections.IEnumerable.GetEnumerator()
// 0x000002AE T System.Collections.Generic.Queue`1::Dequeue()
// 0x000002AF System.Void System.Collections.Generic.Queue`1::SetCapacity(System.Int32)
// 0x000002B0 System.Void System.Collections.Generic.Queue`1::MoveNext(System.Int32&)
// 0x000002B1 System.Void System.Collections.Generic.Queue`1::ThrowForEmptyQueue()
// 0x000002B2 System.Void System.Collections.Generic.Queue`1_Enumerator::.ctor(System.Collections.Generic.Queue`1<T>)
// 0x000002B3 System.Void System.Collections.Generic.Queue`1_Enumerator::Dispose()
// 0x000002B4 System.Boolean System.Collections.Generic.Queue`1_Enumerator::MoveNext()
// 0x000002B5 T System.Collections.Generic.Queue`1_Enumerator::get_Current()
// 0x000002B6 System.Void System.Collections.Generic.Queue`1_Enumerator::ThrowEnumerationNotStartedOrEnded()
// 0x000002B7 System.Object System.Collections.Generic.Queue`1_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x000002B8 System.Void System.Collections.Generic.Queue`1_Enumerator::System.Collections.IEnumerator.Reset()
// 0x000002B9 System.Void System.Collections.Generic.Stack`1::.ctor()
// 0x000002BA System.Int32 System.Collections.Generic.Stack`1::get_Count()
// 0x000002BB System.Void System.Collections.Generic.Stack`1::System.Collections.ICollection.CopyTo(System.Array,System.Int32)
// 0x000002BC System.Collections.Generic.Stack`1_Enumerator<T> System.Collections.Generic.Stack`1::GetEnumerator()
// 0x000002BD System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.Stack`1::System.Collections.Generic.IEnumerable<T>.GetEnumerator()
// 0x000002BE System.Collections.IEnumerator System.Collections.Generic.Stack`1::System.Collections.IEnumerable.GetEnumerator()
// 0x000002BF T System.Collections.Generic.Stack`1::Peek()
// 0x000002C0 T System.Collections.Generic.Stack`1::Pop()
// 0x000002C1 System.Void System.Collections.Generic.Stack`1::Push(T)
// 0x000002C2 System.Void System.Collections.Generic.Stack`1::ThrowForEmptyStack()
// 0x000002C3 System.Void System.Collections.Generic.Stack`1_Enumerator::.ctor(System.Collections.Generic.Stack`1<T>)
// 0x000002C4 System.Void System.Collections.Generic.Stack`1_Enumerator::Dispose()
// 0x000002C5 System.Boolean System.Collections.Generic.Stack`1_Enumerator::MoveNext()
// 0x000002C6 T System.Collections.Generic.Stack`1_Enumerator::get_Current()
// 0x000002C7 System.Void System.Collections.Generic.Stack`1_Enumerator::ThrowEnumerationNotStartedOrEnded()
// 0x000002C8 System.Object System.Collections.Generic.Stack`1_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x000002C9 System.Void System.Collections.Generic.Stack`1_Enumerator::System.Collections.IEnumerator.Reset()
// 0x000002CA System.UInt32 <PrivateImplementationDetails>::ComputeStringHash(System.String)
extern void U3CPrivateImplementationDetailsU3E_ComputeStringHash_m7C7DB27BC4297A74A96AC53E1EDD3E7415DFB874 (void);
// 0x000002CB System.Void System.Net.Configuration.BypassElementCollection::.ctor()
extern void BypassElementCollection__ctor_m867AF1FE6DBB2768AA199F45039C3E2641A9627A (void);
// 0x000002CC System.Void System.Net.Configuration.ConnectionManagementElementCollection::.ctor()
extern void ConnectionManagementElementCollection__ctor_mA29AB3A62411F032C5EF86B16E7633A386000C7B (void);
// 0x000002CD System.Void System.Net.Configuration.ConnectionManagementSection::.ctor()
extern void ConnectionManagementSection__ctor_m1112C1BE1A9466BBCDD5C2ED20E80CDE03B46CA4 (void);
// 0x000002CE System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.ConnectionManagementSection::get_Properties()
extern void ConnectionManagementSection_get_Properties_m1737189D2D78E81728CFF1CCCEB99E1FFFEA3F19 (void);
// 0x000002CF System.Void System.Net.Configuration.DefaultProxySection::.ctor()
extern void DefaultProxySection__ctor_m41EADE87065B61EDF32F67D2E62F04946886DAF6 (void);
// 0x000002D0 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.DefaultProxySection::get_Properties()
extern void DefaultProxySection_get_Properties_m6F70EC02D977EB16F86354188A72DC87A8959555 (void);
// 0x000002D1 System.Void System.Net.Configuration.DefaultProxySection::Reset(System.Configuration.ConfigurationElement)
extern void DefaultProxySection_Reset_m54AC9323047B1FB38795C9F466C1C01192F75276 (void);
// 0x000002D2 System.Void System.Net.Configuration.ProxyElement::.ctor()
extern void ProxyElement__ctor_mAFD852231DF0231726E41911409CB2725BE990AC (void);
// 0x000002D3 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.ProxyElement::get_Properties()
extern void ProxyElement_get_Properties_m8A3EE4A3EEF2571DE4768730CEF4107331490377 (void);
// 0x000002D4 System.Void System.Net.Configuration.HttpWebRequestElement::.ctor()
extern void HttpWebRequestElement__ctor_mE3A4CA43FCC72E10B6C7B4920F429C028765E233 (void);
// 0x000002D5 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.HttpWebRequestElement::get_Properties()
extern void HttpWebRequestElement_get_Properties_m531EDF2F56823100C47A9EEE1575143E5EB5463C (void);
// 0x000002D6 System.Void System.Net.Configuration.Ipv6Element::.ctor()
extern void Ipv6Element__ctor_m3F7DF39E6E51517E1429BAE43FA782BF3AF17965 (void);
// 0x000002D7 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.Ipv6Element::get_Properties()
extern void Ipv6Element_get_Properties_m156008D7E5279C50DE4CEDB6D4D3CEDAF2ACF8DC (void);
// 0x000002D8 System.Void System.Net.Configuration.NetSectionGroup::.ctor()
extern void NetSectionGroup__ctor_m566D7C9466957BCE3B8FE2D0EA2582CC2F95F269 (void);
// 0x000002D9 System.Void System.Net.Configuration.SettingsSection::.ctor()
extern void SettingsSection__ctor_mC5F3D29EDC94D87B0B0542DE3702795441AC3005 (void);
// 0x000002DA System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.SettingsSection::get_Properties()
extern void SettingsSection_get_Properties_m1ABB76DEC7441CFEDD4E7EDF99B8F5C258101254 (void);
// 0x000002DB System.Void System.Net.Configuration.PerformanceCountersElement::.ctor()
extern void PerformanceCountersElement__ctor_m5A090222699B48BEB5FCC743198613FA8D081083 (void);
// 0x000002DC System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.PerformanceCountersElement::get_Properties()
extern void PerformanceCountersElement_get_Properties_m3C7B73AC6E5F5E92426D7DC091A2ECE5CFCD9FD0 (void);
// 0x000002DD System.Void System.Net.Configuration.ServicePointManagerElement::.ctor()
extern void ServicePointManagerElement__ctor_m61B031714F8498D467B5A0958EE62F73E0C58EB7 (void);
// 0x000002DE System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.ServicePointManagerElement::get_Properties()
extern void ServicePointManagerElement_get_Properties_mC1C586246B4FE10AC90622A0CC6A5936D501B677 (void);
// 0x000002DF System.Void System.Net.Configuration.SocketElement::.ctor()
extern void SocketElement__ctor_m428B7094399223FFB9A5B62BF9D8CEA18A00A4C3 (void);
// 0x000002E0 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.SocketElement::get_Properties()
extern void SocketElement_get_Properties_m9CF8E9B1A9B41B7EC24A4F91CE2E8ECBF317426A (void);
// 0x000002E1 System.Void System.Net.Configuration.WebProxyScriptElement::.ctor()
extern void WebProxyScriptElement__ctor_mC8AF875E80D96B18AA387148009AE1C630D83591 (void);
// 0x000002E2 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.WebProxyScriptElement::get_Properties()
extern void WebProxyScriptElement_get_Properties_m8AD25399F804B2D22BC8312102EBC28A0CAE6E26 (void);
// 0x000002E3 System.Void System.Net.Configuration.WebRequestModulesSection::.ctor()
extern void WebRequestModulesSection__ctor_m0CAB6F207E3B29D65AEA38A6AC191873E3000F02 (void);
// 0x000002E4 System.Configuration.ConfigurationPropertyCollection System.Net.Configuration.WebRequestModulesSection::get_Properties()
extern void WebRequestModulesSection_get_Properties_m909A3E4C4A61BFCC9D09F397D9314E5F74F3FE44 (void);
// 0x000002E5 System.Void System.Net.Configuration.WebRequestModuleElementCollection::.ctor()
extern void WebRequestModuleElementCollection__ctor_m8B880B0EAE7CEF1CB79CD264A9B6D62AB6A22961 (void);
// 0x000002E6 System.Void System.Diagnostics.DiagnosticsConfigurationHandler::.ctor()
extern void DiagnosticsConfigurationHandler__ctor_m185BC74B0225A3E16EEB4164923931B79AAA0CF0 (void);
// 0x000002E7 System.Object System.Diagnostics.DiagnosticsConfigurationHandler::Create(System.Object,System.Object,System.Xml.XmlNode)
extern void DiagnosticsConfigurationHandler_Create_mCC7EF5B43B6913E2429B37EC5923202EBB20AA96 (void);
// 0x000002E8 System.Void Unity.ThrowStub::ThrowNotSupportedException()
extern void ThrowStub_ThrowNotSupportedException_mF1DE187697F740D8C18B8966BBEB276878CD86FD (void);
static Il2CppMethodPointer s_methodPointers[744] = 
{
	SR_GetString_m9548BD6DD52DFDB46372F211078AE57FA2401E39,
	SR_GetString_m9D671CBA422B18D15B8FF59B22DCCEB32E3D16E2,
	SR_GetString_m3FC710B15474A9B651DA02B303241B6D8B87E2A7,
	IriHelper_CheckIriUnicodeRange_mA9BAAD6D244ADEE8986FDC0DFB3DFDA90C093A6C,
	IriHelper_CheckIriUnicodeRange_m5ED29083C22062AEAB8B5787C9A27CFEEC397AD9,
	IriHelper_CheckIsReserved_m5C0A35BF0890852A3FC564618DB0836BBB6C0F1C,
	IriHelper_EscapeUnescapeIri_m6DE347247CE35DB4CE3129BEC2179F0095D69239,
	Uri_get_IsImplicitFile_m048350CB1E9AB92599F1557680A5D3B5FDE7C35D,
	Uri_get_IsUncOrDosPath_mE372CA996BE5B29DD531D7C6DD1809E17441005E,
	Uri_get_IsDosPath_m89CA4E32381C529502E91872BC89BD18F5419D08,
	Uri_get_IsUncPath_mD5EE84D5105BFB7D64E5C26B9549A67B720A7AE8,
	Uri_get_HostType_mBB4EE8652EA19E2FB8C696302D5EBE82F358EC90,
	Uri_get_Syntax_m3DB6A5D9E6FC3E0D0A63EA8A4527AF4106F9BD78,
	Uri_get_IsNotAbsoluteUri_mF9706123EB027C6E9AB263B98CE58CF319A22919,
	Uri_IriParsingStatic_m39FC9677B4B9EFBADF814F2EEA58280F35A1D3E5,
	Uri_get_AllowIdn_mF1833CB700E04D746D75428948BEBC70536E1941,
	Uri_AllowIdnStatic_mFABD19611F334DF87EC3FF2B9A1FA061CAE3A5C5,
	Uri_IsIntranet_mE98CA41B60FE0D4970737C8B7C81E5C63BFC07E1,
	Uri_get_UserDrivenParsing_mFF27964894B5C0432C37E425F319D6C915BCDC39,
	Uri_SetUserDrivenParsing_m0368CB47B9E9C35CB49B3F02DBE8DFED8756226B,
	Uri_get_SecuredPathIndex_mC59A2366D6F3667017F677351C4350C9541905AA,
	Uri_NotAny_mC5DC04B72B13D2997B055B9E41FCFEEC1CE5263D,
	Uri_InFact_m4CE890C86FA34154A044516D2F3C9463389220D7,
	Uri_StaticNotAny_mC07A1201FBE032238FCFA96E9FB5D60AEDACCC5A,
	Uri_StaticInFact_m77BB2AE094534AFD7B9F68683C2A4356A75E39B8,
	Uri_EnsureUriInfo_m4B46DF8611FA6D20D497D12D00544CFB466DCFA7,
	Uri_EnsureParseRemaining_m33815B5767FAFADB762F7E39364E6432340F210B,
	Uri_EnsureHostString_m4BD63AA5A88CA09572A8A7CF3B2EDDE17EF9C720,
	Uri__ctor_mBA69907A1D799CD12ED44B611985B25FE4C626A2,
	Uri__ctor_mA02DB222F4F35380DE2700D84F58EB42497FDDE4,
	Uri__ctor_m42192656437FBEF1EEA8724D3EF2BB67DA0ED6BF,
	Uri_GetCombinedString_m7B95A90BC09E899CF41B0047E0B681FA7CEB8668,
	Uri_GetException_m2E833A8358C84BCF0397341160FADB1164290164,
	Uri__ctor_m020E8051B3C0C9E60D8A868CBA0774B3FFB7C3FF,
	Uri_System_Runtime_Serialization_ISerializable_GetObjectData_mD4773E59427820077E86F2B298DA1386028DAC9C,
	Uri_GetObjectData_mC8CCD55C21CB624E369258E27A89F363F8271E68,
	Uri_get_AbsoluteUri_m4326730E572E7E3874021E802813EB6F49F7F99E,
	Uri_get_IsUnc_m70B47E68BDAE06A7E5362DCE5AAD97C12119AB99,
	Uri_StaticIsFile_mD270A5F6C8B59AAF6256B4565ABE5917ABA545E3,
	Uri_get_InitializeLock_m45D6A11D14958E716715351E52207DCA808F00EE,
	Uri_InitializeUriConfig_m1B2F98DF0BB1A48FEB328E9D8BF3C23B32196FE2,
	Uri_get_Port_m4E64AB9B50CCC50E7B1F139D7AF1403FAF97147C,
	Uri_get_Scheme_m14A8F0018D8AACADBEF39600A59944F33EE39187,
	Uri_get_OriginalStringSwitched_m79E1C9F1C4E0ACCC85BB68841C167DDEA15CC72D,
	Uri_get_OriginalString_m56099E46276F0A52524347F1F46A2F88E948504F,
	Uri_get_DnsSafeHost_mC2D93669288A9C05CC13EE5754CEBF2D74D04704,
	Uri_get_IsAbsoluteUri_m8C189085F1C675DBC3148AA70C38074EC075D722,
	Uri_get_UserEscaped_m8F29E9A593E84E66DD4AC06CBD5880B93A5F0307,
	Uri_IsGenDelim_m376CCA5D00D019A69FD746C57D236A54EB9D3CF3,
	Uri_IsHexDigit_m3B2881FA99F0B2197F8017E70C3AE6EBF9849836,
	Uri_FromHex_m9EAC76A5DBFED86532FF7E1BBD809176337A227B,
	Uri_GetHashCode_m06066B9059649A690C5B4DE58D32DF227933F515,
	Uri_ToString_mB76863E11134B9635149E8E5F59AB75A74A760E2,
	Uri_op_Inequality_m07015206F59460E87CDE2A8D303D5712E30A7F6B,
	Uri_Equals_m432A30F5E72A0F2B729AC051892BF9E1F4D26629,
	Uri_ParseScheme_m61CAE16F1EC76725E5E0B23B09577F91BB223884,
	Uri_ParseMinimal_m35FCFE52F12315DA60733B807E7C0AB408C0A9CF,
	Uri_PrivateParseMinimal_mE1DA461DDA053787906BBEC2BC2B3046B1B329F0,
	Uri_PrivateParseMinimalIri_m29F0CA367080586448C648332F59BED0096AB2D0,
	Uri_CreateUriInfo_mC112D6E7002CA014AB6BEA878A66ECC46340FAAF,
	Uri_CreateHostString_m6FEC48641D3786D73B50D5DC792804C9A4D70C54,
	Uri_CreateHostStringHelper_m6C5EEA8BD2CDBCDD8A63FB74D3B801329EDE7BDD,
	Uri_GetHostViaCustomSyntax_mD591A4A615803E70A03D7C75E7C114E4E460AED3,
	Uri_GetParts_mF5840DC010E6D420EB5A0722320EDAAEA2D0269F,
	Uri_GetEscapedParts_m745615124808CB89A18D499988F4425F678938C4,
	Uri_GetUnescapedParts_m051A75B5D2DDAE55F107457CA468EE9A2563FED3,
	Uri_ReCreateParts_mF50263ABC7D750E939B57BF61FA48A8762144FD7,
	Uri_GetUriPartsFromUserString_m95A7794F28625B6AFD514C08765C27CAAE4BD1B6,
	Uri_ParseRemaining_mBAE0F9850CD84965B3793B17444C677D77D58774,
	Uri_ParseSchemeCheckImplicitFile_m92A658AE6C04E038058AD8E9581A41B06B6D6243,
	Uri_CheckKnownSchemes_mCA95AE251E7C9208570543B446385BCF2C727E8D,
	Uri_CheckSchemeSyntax_m1181D9BEA35D9D22852FD2FE815CABB267BA5A8F,
	Uri_CheckAuthorityHelper_m5046CE781115A54CAE3ACD2C03987F526A761387,
	Uri_CheckAuthorityHelperHandleDnsIri_m366E36029D4C9A00C0F216055B15F5E4805AED28,
	Uri_CheckAuthorityHelperHandleAnyHostIri_m76FEA31E3FEDF3D1614987C6484ECF15022AE9D8,
	Uri_FindEndOfComponent_mF276ABD008291C1FDC4B433A2F274058D06D8A6B,
	Uri_FindEndOfComponent_mDCDF860C405E9F31F7CFE9AFFE7C096812697AEF,
	Uri_CheckCanonical_mED3910E55213D1DFEAA5B33079E3A89D369B10B6,
	Uri_GetCanonicalPath_mDE02BFA56EDD09479DDB2A5A50F6DF5210CA73F2,
	Uri_UnescapeOnly_mB8F87981CDD4CFBFCD97EE668FF281CE26453F21,
	Uri_Compress_m02224082A9665F07D35AB6EB6E3198642F9E7BCF,
	Uri_CalculateCaseInsensitiveHashCode_m634FFDF8FCD81DECCB87161B153D1093C0A6FCE4,
	Uri_CombineUri_m77B7B8B856CF8100E51250247930963E7C544F91,
	Uri_IsLWS_m7A9F3B969CCEE56B9F98E40F1903C737DA7DF0D6,
	Uri_IsAsciiLetter_m93435A20DF4DEE153B87B26D07B9963F1BF4F373,
	Uri_IsAsciiLetterOrDigit_mEBA81E735141504B5804F0B3C94EC39B24AF8661,
	Uri_IsBidiControlCharacter_mB14EA5816A434B7CE382EB9ACBD1432916EC341D,
	Uri_StripBidiControlCharacter_m49D782826401F99D943C1AD76A75125879FF332F,
	Uri_CreateThis_mCB3DC849A426498E9CCD249850CBC69C9D67D864,
	Uri_InitializeUri_m5D99BD8533F3FAAD479B1193505B5B19B8C2F2DE,
	Uri_CheckForConfigLoad_m13002EFBBFD437183ED0A7FCBE5681C510996B0F,
	Uri_CheckForUnicode_m78E4938E82EE352BD5D8493AE0314224BC2543CD,
	Uri_CheckForEscapedUnreserved_mFE708A44EC74C7E773B96B82CD9A5DF25EF97D4A,
	Uri_TryCreate_mEEB6736FEDAF52AAE36ACC1EA1EC8CEBB7C52DAB,
	Uri_GetComponents_m0346CA8037531DE1FC630775E0BD1F5D1E7920B6,
	Uri_UnescapeDataString_mE1F40FC5CA3FF03DEE9EB01E3D8BD502D36A284D,
	Uri_EscapeUnescapeIri_mDE5E4BAE74E2C2373AD186732FEE7AD6E0EA7180,
	Uri__ctor_m4605489523A7A973459720C1BBE4039FD10557CD,
	Uri_CreateHelper_m024137C47351CA9959E4AC66F9443AEEE87D89C0,
	Uri_ResolveHelper_mEDF1549C3E9AC1CF6177DCF93B17D574411916BC,
	Uri_GetRelativeSerializationString_m5D0CD02E255BB96532F056BB382CF7D74D62BE58,
	Uri_GetComponentsHelper_m28B0D80FD94A40685C0F70652AB26755C457B2D3,
	Uri_CreateThisFromUri_m9A4AE7CD70F7EDE9154634057EBE600E74A5D544,
	Uri__cctor_m2B8179039C09C64936CF8262E3EF4A7E7C2F90F2,
	UriInfo__ctor_m24EFE7B4E03C9FFB8B797770D626680947C87D98,
	MoreInfo__ctor_mFE29F028646C12EDCAF7F0F78F9A85D52C10B83C,
	UriFormatException__ctor_mBA5F8C423C09F600B1AF895521C892EA356CA424,
	UriFormatException__ctor_mE1D46962CC168EB07B59D1265F5734A8F587567D,
	UriFormatException__ctor_mE7F5B073E9F9DB5F22536C54959BEB0D1E7DA1D5,
	UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_mED4C06AC35B7F94955ECC0D8F00383888C1127DC,
	UriHelper_EscapeString_mF0077A016F05127923308DF7E7E99BD7B9837E8B,
	UriHelper_EnsureDestinationSize_m64F4907D0411AAAD1C05E0AD0D2EB120DCBA9217,
	UriHelper_UnescapeString_mC172F713349E3D22985A92BC4F5B51D0BCEE61AF,
	UriHelper_UnescapeString_mD4815AEAF34E25D31AA4BB4A76B88055F0A49E89,
	UriHelper_MatchUTF8Sequence_m4835D9BB77C2701643B14D6FFD3D7057F8C9007F,
	UriHelper_EscapeAsciiChar_mFD7DE796BD53CBD2B1E73080FE0346D37F358902,
	UriHelper_EscapedAscii_m06D556717795E649EBBB30E4CBCF3D221C1FEB78,
	UriHelper_IsNotSafeForUnescape_m1D0461E7C5A3CFBD7A2A7F7322B66BC68CCE741D,
	UriHelper_IsReservedUnreservedOrHash_m3D7256DABA7F540F8D379FC1D1C54F1C63E46059,
	UriHelper_IsUnreserved_mAADC7DCEEA864AFB49311696ABBDD76811FAAE48,
	UriHelper_Is3986Unreserved_m3799F2ADA8C63DDB4995F82B974C8EC1DEEBA76A,
	UriHelper__cctor_m9537B8AAAA1D6EF77D29A179EC79F5511C662F27,
	UriParser_get_SchemeName_mFC9EFD71512A64E640866792CCB7DAC5187DE9F1,
	UriParser_get_DefaultPort_m050510870CCD4DD08DF7E98E2AF3D616446AD99D,
	UriParser_OnNewUri_m7D55337A7A9B6B67FB0AD7CA96F472751EF5A897,
	UriParser_InitializeAndValidate_m3E31D86FEE445E313BB7141F760626301767A0E0,
	UriParser_Resolve_mF21D3AA42AB1EC2B173617D76E4041EB3481D979,
	UriParser_GetComponents_m8A226F43638FA7CD135A651CDE3D4E475E8FC181,
	UriParser_get_ShouldUseLegacyV2Quirks_mD4C8DF67677ACCCC3B5E026099ECC0BDA24D96DD,
	UriParser__cctor_m00C2855D5C8C07790C5627BBB90AC84A7E8B6BC2,
	UriParser_get_Flags_mBCF4C3E94892F00B6E8856BFED1B650FB6A0C039,
	UriParser_NotAny_mC998A35DC290F35FFAFFB6A8B66C7B881F2559D3,
	UriParser_InFact_mDD42FA932B6830D99AA04C2AE7875BA5067C86F3,
	UriParser_IsAllSet_m74BEC412DC8AF3B1A33E11964EBB3164D9D8C77E,
	UriParser_IsFullMatch_m7B5F47A62FA721E550C5439FAA4C6AFAC34EB23E,
	UriParser__ctor_mAF168F2B88BC5301B722C1BAAD45E381FBA22E3D,
	UriParser_FindOrFetchAsUnknownV1Syntax_m3A57CA15FE27DC7982F186E8321B810B56EBD9AD,
	UriParser_get_IsSimple_mDDB03A5F6EEE6E92926A386655E5BBD553719B9C,
	UriParser_InternalOnNewUri_m7D55F5CD59A3B9BF57BC68F715A27CC1A44566CA,
	UriParser_InternalValidate_mF2FEB0E76E48B621EB2058FBE7DCC6A42A1681E2,
	UriParser_InternalResolve_m2A027789CB5105E32B09810E81810E8E35DD1F26,
	UriParser_InternalGetComponents_mFD4B211C71E0506AE4E4E99D92ECAF1780CE4674,
	BuiltInUriParser__ctor_m66250DC53CE01410149D46279D0B413FC1C5CA1C,
	DomainNameHelper_ParseCanonicalName_mFE738FD1237E2D9D9A1B27BA73F58B1689D451E4,
	DomainNameHelper_IsValid_mE9672A824F71E32116358C5FA029789855A4B461,
	DomainNameHelper_IsValidByIri_m13E2A6D9EBD42326C096F2423DBB0014763D47BF,
	DomainNameHelper_IdnEquivalent_m439593BAF7C6C801F577E7C27B0C4FBB1772E49F,
	DomainNameHelper_IdnEquivalent_m459BFF3040F8E6BFE1CE1C6432A1343A2ECF2F57,
	DomainNameHelper_IsIdnAce_m2231C778C4CCE141ACDC412737642CC365307445,
	DomainNameHelper_IsIdnAce_m9193B7D824FC6965820FCE980FEE3E0B40EA94B8,
	DomainNameHelper_UnicodeEquivalent_mA80E5FF3AD6AFBB9FC257ED1C4F0D31C8F0EFEC3,
	DomainNameHelper_UnicodeEquivalent_mD5A7A659B82F1FBF7ABF30009117CFBF8BC4D55F,
	DomainNameHelper_IsASCIILetterOrDigit_mD3B0B9BD4573FADEF6AC7330A5EC58C220455F01,
	DomainNameHelper_IsValidDomainLabelCharacter_mF6DEB20D9D03A8728B1C58006C40D6603B7D61D1,
	IPv4AddressHelper_ParseCanonicalName_m2A8C35045CE02D6FC2C4251F239D1C0074E0E813,
	IPv4AddressHelper_ParseHostNumber_m798FB6828971F70775D1125565A1D1025C897F14,
	IPv4AddressHelper_IsValid_mD96D91E0F3830414F4601A4521E71DE832A45843,
	IPv4AddressHelper_IsValidCanonical_mC27E31F1F043D68BC52719892D34EDDC7851B120,
	IPv4AddressHelper_ParseNonCanonical_mDCD1CD7FB85C4FFBF3070B1435A0D632C1A7B97E,
	IPv4AddressHelper_Parse_m08110623FAC14806376148D7C16AB95A428EA6CF,
	IPv4AddressHelper_ParseCanonical_m9D4552558C934E373D188DDA0BC1D1DEF5A62C33,
	IPv6AddressHelper_ParseCanonicalName_m3944530A7B686031653F97824EF712424E0BEE14,
	IPv6AddressHelper_CreateCanonicalName_m0B1C201DFADBEB58869E0BE8BFA967EEE64B096A,
	IPv6AddressHelper_FindCompressionRange_mE70B131DDA05D3059325246A5AB7F6029B6EF6BD,
	IPv6AddressHelper_ShouldHaveIpv4Embedded_m262634E9099141536C00213C1CFC123665A641DE,
	IPv6AddressHelper_InternalIsValid_m3BD7E7524455146D4464037DA3B65530E547AB7A,
	IPv6AddressHelper_IsValid_m2383F1A867665B04A4F2B8D82FF2B62BE51C2289,
	IPv6AddressHelper_Parse_m36CE2F56465C4F9F7791E80E954C7C0ECBD16DFB,
	UncNameHelper_ParseCanonicalName_mCBE64015FD1B6B4829CEAA89625C1D44E280E37E,
	UncNameHelper_IsValid_m4055361D79684EE7B098C055B2E9068EE06F1EF6,
	IOAsyncCallback__ctor_m1010BF5234B0ECC2FEB54105BA15B313633C1985,
	IOAsyncCallback_Invoke_mB95F7E7F0E8326CE5364A30F42FC1073B0AB2D8B,
	IOAsyncCallback_BeginInvoke_mB8CACF8990B91DF4A695E597CEBE4BA09354C32C,
	IOAsyncCallback_EndInvoke_m397237D5497A9029CC3FACE692D11BDC1558A727,
	UriTypeConverter__ctor_m1CAEEF1C615B28212B83C76D892938E0A77D3A64,
	Regex__ctor_mFDE4B6A423C15AA60BF9FEC7D4D7DFD4657D7C6E,
	Regex__ctor_m2769A5BA7B7A835514F6C0E4D30FAD467C6B1B0C,
	Regex__ctor_mEF4515C4C44DF8BE410F388C82CC679D743FB5CD,
	Regex__ctor_m87918FB2A856E264A492D2A2B4B412BE4E2370BB,
	Regex__ctor_mF11825F6E24D7D780BD34C74C96392DEC3602A5D,
	Regex_System_Runtime_Serialization_ISerializable_GetObjectData_m95B0E2523A72DF6AC56DEA7CDA286F771E06B0FD,
	Regex_ValidateMatchTimeout_m71FE7188780DEAD57093B7345CCC50D0159218BE,
	Regex_InitDefaultMatchTimeout_mC91736B02BD12B92CBD93C329E7A8233CD0B9DA4,
	Regex_get_Options_m823A30690EEA63798DB8497F3E9CF062412B8653,
	Regex_get_MatchTimeout_mD484D1CF0B6BF8516A08991D1387761CAE2340D6,
	Regex_get_RightToLeft_m546BF531C94563A11427CD24367525462CDB4509,
	Regex_ToString_mF967EF5E8BD74C3692379B8436AB8D3C5963FA75,
	Regex_Match_mA36A33D32F895CE84957DC7DA82E2CD45EF19EEA,
	Regex_Replace_mB4E5642068CF8B6DFA3C3C6E21E8AD33AED12223,
	Regex_Replace_mD7649C6657458BEAA6B18E2BEB158ECA320A4609,
	Regex_Replace_m57129CA8DD318E87C364526DCF0157AD7A4933CB,
	Regex_Replace_mF5075A8D78C9AD734DBE740479A6C1F7F9078D73,
	Regex_InitializeReferences_m2CD000C1AFAA8B214F32D989C7D116B684A31840,
	Regex_Run_m74FB5EF178DF43F88B9058B94939F557479B93FC,
	Regex_LookupCachedAndUpdate_m88CA03797C5ED796BD5E1319DF6B1B6B6FCE6C0D,
	Regex_CacheCode_m68F93FF3B918776D190D4DB807A3323691C77F0A,
	Regex_UseOptionR_m84945EDBEDCD61DBCEB691C929CA28F4B0AF4B49,
	Regex_UseOptionInvariant_m0CA185DBDB15932BB8A8B4F53EB8ACECEC006566,
	Regex__cctor_m86CE9B8D0FF5F2B54D4FF27D2213A1E6917477DF,
	CachedCodeEntry__ctor_m78BCA6060E7D83B172F998AF60D17FB41BE703B8,
	ExclusiveReference_Get_mE79B077388AFBD19A4524E630701783E7DCE61E4,
	ExclusiveReference_Release_m9A1577138872106EA54A04EA4AB77F710CEDE336,
	ExclusiveReference__ctor_m0427943C75CBB283EF26034339E3D412A080B5D7,
	SharedReference_Get_m4133101195827AC22016F903F8F945C249E4FCA1,
	SharedReference_Cache_mEFA6A88B206EAFEAD6222E239A03BD6E4B244430,
	SharedReference__ctor_m48E749BC646BEC89282B8F336325D42DE48CFC81,
	RegexBoyerMoore__ctor_m39674FB18BB75DD891AAE3781FDA0CCDDEBC2F8C,
	RegexBoyerMoore_MatchPattern_m41D57E11972B2142649662886DA145AFE396F602,
	RegexBoyerMoore_IsMatch_m820D06ED51C062451AFAF22682D2EB06C8DFABD9,
	RegexBoyerMoore_Scan_m204A42056131A694B6D31FC69563355788CABD67,
	RegexBoyerMoore_ToString_mB0A62E68E8A3CAC5CE3AC45E1C54FA72DFB626F6,
	Capture__ctor_m6CC8A5385C7BD6B8AE63F9812293EC3252A65B3B,
	Capture_get_Index_m46BE6FFC6E8474F55B0504269903F287C45C4B31,
	Capture_get_Length_mB41E1D86823156F57D3FE0B9F31BF3C6DD3D3C94,
	Capture_get_Value_m8F739B7E4E173814B0890ECFEA37194D592BE91C,
	Capture_ToString_mD49A28CAD5727E8F629643EDE0C6BAB476BA639E,
	Capture_GetOriginalString_m35D3CD7902B7BC29E00AD043D8784FFE4E67539F,
	Capture_GetLeftSubstring_mF82C23C9E17F3F048605955F76B9D69C3E82FCD7,
	Capture_GetRightSubstring_m1A17502FFAE73FC4D35540716DB2311717267D5E,
	Capture__ctor_m3ED807279C93FFCE8BE4EAF447DA01E62EF93D7B,
	RegexCharClass__cctor_m5170E52D9864BA712125FB33F309FE9E37869EA8,
	RegexCharClass__ctor_mAA44510F3E5001A8612355B4FFB718D9DDC74264,
	RegexCharClass__ctor_mB05A6CC8015C5D545C639682454A524DE7E2EA97,
	RegexCharClass_get_CanMerge_mC27A4CF83CFBEF3741A3DB4F99ABA6DE76B57837,
	RegexCharClass_set_Negate_mEB8659D83748A4DF28CDDFC3AC573A6504385E09,
	RegexCharClass_AddChar_m4C4BFD42572978A9F98ADE75BE3811593957A9E3,
	RegexCharClass_AddCharClass_m0E5DD1105844AFB7CE45B5C801304B5C803FB5CA,
	RegexCharClass_AddSet_mFFDE070E770BE967173D630AD50010C3397F7B97,
	RegexCharClass_AddSubtraction_m17E538235B02A1435BD43D4FE4501DA67AA35145,
	RegexCharClass_AddRange_mCFE9B670B3EBB13A5CDB694B1D1D6B1C0249D110,
	RegexCharClass_AddCategoryFromName_m9AD2D607E1E34A52CBC26FC38D468905C43A9202,
	RegexCharClass_AddCategory_m6A4625370DA8927DF5342275CB1F6155FC2BA255,
	RegexCharClass_AddLowercase_m01C1B11EB0B82E065276C7ECF60725886F59A07A,
	RegexCharClass_AddLowercaseRange_mCDDE9661C9C300DFEB51A8FE36E2F790E3E75D75,
	RegexCharClass_AddWord_m1D2553B878162B32B0548536AE4C3EE673041CA0,
	RegexCharClass_AddSpace_mC6557749D96EBD114BCB133D14887A29304196D8,
	RegexCharClass_AddDigit_mC4DE43D884E575729BB2E575DA5552989368F6B3,
	RegexCharClass_SingletonChar_m01C15732FAD399460FF5BB449B8177A77CAB1DB9,
	RegexCharClass_IsMergeable_mB9A0CD8306728BAFA5460C7FD748A2A7AD4BA448,
	RegexCharClass_IsEmpty_mAD6C63FE25C4CF3E52A20185418925D12C4C07CF,
	RegexCharClass_IsSingleton_m89D3E8460B0E7020DB0ABA607AC2F76FB9A34F1A,
	RegexCharClass_IsSingletonInverse_m3E75D541C85AD842B9EB80705D6869EDB3F6928D,
	RegexCharClass_IsSubtraction_m3C9EF97AFE7E4BCC24A2DF10834BF62279D7EE26,
	RegexCharClass_IsNegated_m9CEDECE7EDA98ACD502E75783CA631A719DBC675,
	RegexCharClass_IsECMAWordChar_m6E7FC296DB816D89E3D6CF8672DCE6DFC519D741,
	RegexCharClass_IsWordChar_m2DF03D32DAB403138E397CB05F45D37BD50EB18C,
	RegexCharClass_CharInClass_m194AAA57BBBD30E78E70255D6F53FAFDB785EC0E,
	RegexCharClass_CharInClassRecursive_m5560DBADE1463FDEC38643C72CDF2FD5B3F69A5F,
	RegexCharClass_CharInClassInternal_m5D1634F64092E4BD9EB6427447F952983211A760,
	RegexCharClass_CharInCategory_mCDE20DF783F8D4E4403EC7F00F9C12E34D86C2DD,
	RegexCharClass_CharInCategoryGroup_m28E498004F5EA6445C83F1B8EB4A776C210D30C5,
	RegexCharClass_NegateCategory_mF2E03FFFE79E427F39D9368013A334F5BD118E13,
	RegexCharClass_Parse_mBC3780FFF0DDFB62CA2085746618E6C256E8D86C,
	RegexCharClass_ParseRecursive_mF7E7DD4EB594C9C30A60E72CD3CFD4EC1D822CF5,
	RegexCharClass_RangeCount_mEACBB4BD08CE18A9C4F0C433A7D6C5726F563E2E,
	RegexCharClass_ToStringClass_m7A760D96732A03D46C4060064B3FC58349D2B4D5,
	RegexCharClass_GetRangeAt_mE563FF8072DD9B4E1179F55416CCD7FC4EB2C4FC,
	RegexCharClass_Canonicalize_m44EEFB16DB02E73C1E7280D15DAE98E50F4D6FA4,
	RegexCharClass_SetFromProperty_mA33170AF599765B5FDE8611BED646A850FB2330E,
	LowerCaseMapping__ctor_m881B66875631FF0DD253696FE56313A9E3F24187_AdjustorThunk,
	SingleRangeComparer_Compare_mF2CAD555BAC4D9CBF6A8F90D829CB528BD7BCCC9,
	SingleRangeComparer__ctor_m9E44BF07F0F0C9E565E0BA050C1A26F496226BAD,
	SingleRange__ctor_m4674722AFC97A111D2466AE2050C2E4E6E57303E,
	RegexCode__ctor_mBCB059D3E98AEA211794E89DDF99193231F298CA,
	RegexCode_OpcodeBacktracks_mDA23B91B55FE4991B168BF8E18F6DDDC7667B882,
	RegexFCD_FirstChars_mC60DC5CA9A078998CB55594436AB9CBFD86478FB,
	RegexFCD_Prefix_m50B30C508C6745832FD3A76B2169462455C1A28E,
	RegexFCD_Anchors_m562FA644F10503074714E0F58A2A00F9F727D75E,
	RegexFCD_AnchorFromType_m4B458E2C589633A43F9324C14F9192EF68F80A14,
	RegexFCD__ctor_mFC6A3309CAFA8C3C2B94094AD443738823388A3B,
	RegexFCD_PushInt_m63817D3969DF7BD31B7C93D43EE45C4AF539868F,
	RegexFCD_IntIsEmpty_mE825A8A0DF9D5BA6618357ABBA93421D4099AAEB,
	RegexFCD_PopInt_m1E4B64F2F6DDBCB7495E673540CF25FDD4D01B7E,
	RegexFCD_PushFC_mBE154E351E7C49FFFC26E603B4672136D91479C7,
	RegexFCD_FCIsEmpty_m57FDE5D4E352620B7773AD54B286531CA21FCDAD,
	RegexFCD_PopFC_m987A35E9ADF69335799EDEEB12C2CD3A3F40FB6E,
	RegexFCD_TopFC_m26ED21621830CF30FDA46AE8D7F3AC9F50DE416F,
	RegexFCD_RegexFCFromRegexTree_mA85E74765529D05113116C73EC397E832D81D0BC,
	RegexFCD_SkipChild_m661F5D339305B97A37D855240A0B9AF500FE03F6,
	RegexFCD_CalculateFC_m2267FAA6BCA80275E21DC9A0BAF90BBC85204BD8,
	RegexFC__ctor_m354E8197215F3EE9097B69E783B744365A38EF20,
	RegexFC__ctor_m023D08ED0365AE9AAC539333B4390A8052C59229,
	RegexFC__ctor_mDCBBCCC1BB476741943D7F9AD88731B1DCA0C1B5,
	RegexFC_AddFC_m5B05CD1D7700817843366EC1DF728977EDD4D11E,
	RegexFC_GetFirstChars_m7252E826F9A5BC1842A5A255BAC5A36EE8DADAF5,
	RegexFC_IsCaseInsensitive_mD87B0C49AAEBB61215F09A9C5ABF8CCB8B5AB64E,
	RegexPrefix__ctor_m93489A4FF55425A15BF5390E77EE0B84F6F9364C,
	RegexPrefix_get_Prefix_m7137EC6CA5B857F49946E2EAEA19784040D430CF,
	RegexPrefix_get_CaseInsensitive_m76E04480FA9FFAE4C5031CA12F4AE9A2576212C0,
	RegexPrefix_get_Empty_mAD10DECDBC7C51F9ACF5C02E3191874252DF9B8B,
	RegexPrefix__cctor_mCDCE7EDB98AFB119EE0281D37F7BC019AD28773D,
	Group__ctor_mECF4574592517D363C35ADC07F9D6F7E7DE6B4F6,
	Group_get_Success_m91D00749B3C9D2030B72C6DA3AF2B3BA48F22521,
	Group__cctor_m213E26F039439904671CFD5DAF5D85B47D5CBE68,
	Group__ctor_mDCB3D51B8A672B342F452177D42D6D3F2F9BA91A,
	RegexInterpreter__ctor_m7B9BA594CF5F338B2E257EDADC2481826BF4C6BB,
	RegexInterpreter_InitTrackCount_mD93771C3D75617898528698E29AD09B7EA5EE24B,
	RegexInterpreter_Advance_mCD1A51680CD0318DDF6D104DE8C722FCCC468CCA,
	RegexInterpreter_Advance_m779870D7E1FA3580492E2E8B75E2805613525AF7,
	RegexInterpreter_Goto_m438DE9CE790DF0757383C91126DEA68C6B0DADFE,
	RegexInterpreter_Textto_m6CE60A7C8FA9F9CEECD26BD6025F055EB64887AA,
	RegexInterpreter_Trackto_m0C7B05A7385BE3F9BB096FE28DC22942A9F96783,
	RegexInterpreter_Textstart_mE71CFC006954F38B9EB6CD85BCC0867E63BF0894,
	RegexInterpreter_Textpos_mC66F0DE729E76EDA0BEEA7B1ABEE369BA6C81D5B,
	RegexInterpreter_Trackpos_m472ADA4F5E1D07E71896E42714DFB723CB016842,
	RegexInterpreter_TrackPush_m5A8B9F863211AAEC7E5FAD14ECDDAFDE3059210D,
	RegexInterpreter_TrackPush_mB2AF47E651D2A3853A719EFB908C30D27EC2FF5F,
	RegexInterpreter_TrackPush_m3EA36B28D636D1C617F85CEA57650344B562A38F,
	RegexInterpreter_TrackPush_mBCAADB1DF177D91DC9AA4518DCDB3AAF7D6C0E15,
	RegexInterpreter_TrackPush2_m4EBCF8B183717311AEE3FAA6AD6FAF1F08B14F77,
	RegexInterpreter_TrackPush2_mD591F73FDDF69084636E0834BCCD530B057898FF,
	RegexInterpreter_Backtrack_m46612DE84F898D1656DE30F3BA86E93209E279E1,
	RegexInterpreter_SetOperator_m5B633C33EE4CD85364E7C60003ACE8EA93FDAC91,
	RegexInterpreter_TrackPop_m84B55BE8F346693942045E937174EC8C1AE91F08,
	RegexInterpreter_TrackPop_m73AB2E002DB92E231B62510861277320F76BEEED,
	RegexInterpreter_TrackPeek_m4EF7918CC0F10FFF7E73C1C9D13E74D1D8D13318,
	RegexInterpreter_TrackPeek_mEECF3E94E7823A68474C691F695D71087729553C,
	RegexInterpreter_StackPush_mC28C3F8B3C811C4DCA6CD312F7F487206C871E55,
	RegexInterpreter_StackPush_m911FF20379BF912884E7F98BB59CFB6C51AA1861,
	RegexInterpreter_StackPop_mD057CA7B190ED8FBD33C6CE48E1F28E4B09FC4F2,
	RegexInterpreter_StackPop_m90FC35FD76D9B63851ECFD641DAA08B1B58C7B91,
	RegexInterpreter_StackPeek_m08C28311048F6B075379EE46B924FC211BA48EC6,
	RegexInterpreter_StackPeek_m308DE22A8E1AF524319E7F1D5A94DBFEC37700ED,
	RegexInterpreter_Operator_m4DE2EAA1744D15294F2767D5217F753FE74FAC0B,
	RegexInterpreter_Operand_m1ACB9C398C9C7ADF8DA58824877B99F08F181526,
	RegexInterpreter_Leftchars_m3A200CD41FFE8C89CCB85B3CC7A367E32C5988D1,
	RegexInterpreter_Rightchars_m3DB37A53D6C3DC3311C9EA020690CC0824959D30,
	RegexInterpreter_Bump_mC33CB8A0CC0DF1C69F11115BD225D2D8B63F8753,
	RegexInterpreter_Forwardchars_mE5E437E285604CDC60551C112F7B2CEF7297F4ED,
	RegexInterpreter_Forwardcharnext_mD2C6694CC31BC75D3E20C511D1004D28AAE1390F,
	RegexInterpreter_Stringmatch_m543BC6834400A925D2603AE6FBB47944694AFDF1,
	RegexInterpreter_Refmatch_m52369ADBF64E25A9EEEBE216939454EBB8D8E138,
	RegexInterpreter_Backwardnext_mD10CE2A9E229D0655EF01565DB39C902654D00CD,
	RegexInterpreter_CharAt_mAE2AF6D293F53C2D8961C2D0C145BC3ADF6EC105,
	RegexInterpreter_FindFirstChar_m95CDB0ECB99F7850479D951A5F32BB6B19B91F44,
	RegexInterpreter_Go_mBE9DEAECBD68F60DDFE2BB5A8C24CF92A1FB503A,
	Match_get_Empty_m5D3AE3D0580F06ED901EE69FCCED6AF44715528F,
	Match__ctor_m08A8262ACD89C9E47AA7168D0F2CC6E3338855D7,
	Match_Reset_m9EDCC3689E8A5A57A644946AEC3E41C1901C7DAF,
	Match_NextMatch_mA9BB438B4D7DE12D45A73720C063CFFF15FE596D,
	Match_GroupToStringImpl_m933A6494C68E43C8CE37F64FA298ECBCF6F3C4AE,
	Match_LastGroupToStringImpl_m92EDBD078D266F78252C71C35E1693105CDA3825,
	Match_AddMatch_m3C9178A7D6F8175A7628E4BE579FD209B7C7650A,
	Match_BalanceMatch_mCC0EC358E4C33191B896226512FE8F086EFEA4CF,
	Match_RemoveMatch_m6268C01D537F0BACB7DD707E11FA873C3E1918C7,
	Match_IsMatched_m7686CA418F588EC198A82DE287326C46F4CBDD5F,
	Match_MatchIndex_mA39CA9F84C3872675CB9C76EC342EFB30A2B5DA0,
	Match_MatchLength_m25492EACF56E8211FEEC4856F93D7A19D30A984F,
	Match_Tidy_m88B2494631267F8CF7E90F3305F713550ED39CE8,
	Match__cctor_m9158A9D469720E89CD9004B65F55EEEF5E330C0E,
	Match__ctor_m38BC8AD7EEFA99C6FC25587D6FE56450FA849E0C,
	MatchSparse__ctor_mEA523FCAF96D8A81401D3ED010CACE4463CCE811,
	RegexMatchTimeoutException__ctor_mCCDB413A8F68D924B276B8FED2744E81BE4C89AF,
	RegexMatchTimeoutException__ctor_m4EFD030442FEEC81E59AB8CDF35D603A5D551058,
	RegexMatchTimeoutException__ctor_m554FE8CFA7F42483517F11948A61E4D3C9F44D07,
	RegexMatchTimeoutException_System_Runtime_Serialization_ISerializable_GetObjectData_m78FACBA38C002E195A507A32CDAB768D8DBC93E7,
	RegexMatchTimeoutException_Init_m09AF601CC7369F2D7E1300B166517FE7D20EB6F1,
	RegexMatchTimeoutException_Init_m0F165C7170A46724458C06DA5EC05536D8CB95B7,
	RegexNode__ctor_m29676E9646F598C827F25E906EEB6EA14A6FD5DB,
	RegexNode__ctor_m92FB70D6C28D7E021A2A1ACBAD583461AB014F11,
	RegexNode__ctor_m89ACB97FB7FE8B38C0D69F0F2445A7916BC67D85,
	RegexNode__ctor_mAE76BA90AA85F205CB0CC6799F06D1AD85A49F64,
	RegexNode__ctor_m0EFEB707603B3C667626117E09A7EED58BBEC6D4,
	RegexNode_UseOptionR_mB931929BBD1D89F8B263AA846C1665775096713E,
	RegexNode_ReverseLeft_m994638E4886D007B9B29BC23EA3C8D76A92099FD,
	RegexNode_MakeRep_mC310B028FBE3BD5EB80F83E4E05B891ADEE45C22,
	RegexNode_Reduce_mE9E22C30C296E328ABC7EDC9C52F18059FAE27C1,
	RegexNode_StripEnation_mE19E0A57BCE0D0BF47F51A5103C08FCC7BB9E24F,
	RegexNode_ReduceGroup_m069FA93D4F88006F18473E647069B349683B9204,
	RegexNode_ReduceRep_m726F03D9E2420F276A37777942B66D15CA73F77E,
	RegexNode_ReduceSet_m912F4A0DFF694EB14DE520599369A811C2E9D10D,
	RegexNode_ReduceAlternation_m60EECC172A975620A5118D14D6ECF8B846ECED9F,
	RegexNode_ReduceConcatenation_m4BE1B6DBBC0F4BAB9A3873414B5EE77D825AD53B,
	RegexNode_MakeQuantifier_m1332537AA6BCCCD68A3E59EA7994CCFE69A19444,
	RegexNode_AddChild_m734A86A25E6074316FAC566F7D127253F7B71703,
	RegexNode_Child_m5AA4FFDDCCFA22FE70BA0F236F19A963AEF72079,
	RegexNode_ChildCount_m23B6965575DB0DBC1D90212820DEA144FCB06996,
	RegexNode_Type_mFA1C2F11F3487BB1BCBA7F58FFB7975EC18E9CD4,
	RegexParser_Parse_mD206BB554B6087ED35C5F744D72A93A07721D789,
	RegexParser_ParseReplacement_m13F769D7F27406A5E080C5E69F273758CBF37948,
	RegexParser__ctor_mC69D13B4FC323EE77392251139C5F2C456171310,
	RegexParser_SetPattern_m4B385D83A9680A1B2707EBCA8659B6E12EDD5E46,
	RegexParser_Reset_mEC49D1DCEBC555768D2FB90DA42374F1C547E328,
	RegexParser_ScanRegex_m62049A6C66D6D8CDD795B9C740283D1EC85126DB,
	RegexParser_ScanReplacement_m25F626A8546B29D06850DE337D58892567E11033,
	RegexParser_ScanCharClass_mF775DA8BFD214C64BC3D91E07436543717976DC4,
	RegexParser_ScanCharClass_mFE669B1C9CB6652157D9E8DAEE5B924C581AE81F,
	RegexParser_ScanGroupOpen_mA4918ACA08C7E4C945197BBE4EF734AF5B35096C,
	RegexParser_ScanBlank_m99BA3097E182DE425BE0137BAFDD0218F0DF360D,
	RegexParser_ScanBackslash_m45E9E0ABDB7DF70F58850B48905DE9DE026EA64C,
	RegexParser_ScanBasicBackslash_m5F438E56ACBE272622D39D4208B2D5ED536DD7B8,
	RegexParser_ScanDollar_m55F746009E6BFDA1A1A9A7CCA941EA247D984ED7,
	RegexParser_ScanCapname_m1D4DB4E5DA312CBCA841391F729CC626DC657D85,
	RegexParser_ScanOctal_mCF3925D06CBBA1DD0CB60199F59991D099430C3A,
	RegexParser_ScanDecimal_mE966D2C7F357215A52F88120F40A37707C1AB33A,
	RegexParser_ScanHex_m296FC19218F8186D2C1B630DF9F138CFB195625E,
	RegexParser_HexDigit_m4BAEE94B2077B96A4B1D56C459EFB2B1938E1174,
	RegexParser_ScanControl_m244F59DA2B0711D154B7D68CCB5765390C65B5B8,
	RegexParser_IsOnlyTopOption_m66FE256A81BBD173C96B90EE9EBE9721F9ED16A1,
	RegexParser_ScanOptions_m5CD283C15179190846762B90F78F0A87E7495537,
	RegexParser_ScanCharEscape_mF8821EE73F3F8A5D4267642F6E4F0A666FA5E7A6,
	RegexParser_ParseProperty_m69C638E755F0A5C1A2BC8E08827E6124889C2CEF,
	RegexParser_TypeFromCode_m0969E0D233AC767039B0A333901F47A22BABE0E8,
	RegexParser_OptionFromCode_m6BCD10574DF5E08599B5F7FC8E947E3DC69EE151,
	RegexParser_CountCaptures_m5255DE4B24B8D9BA7B2A2A7A1FD79A67B36F4634,
	RegexParser_NoteCaptureSlot_m8B2D20B819C86E427837C879CCA72B9BCD1C4AA8,
	RegexParser_NoteCaptureName_m96A5301077C4C6554E993A2266EA40B690F455C4,
	RegexParser_NoteCaptures_m984EFFB499AA60257CB3BE40718EB78DFA7D30FD,
	RegexParser_AssignNameSlots_m168605CD3A6D6AAA52AFFDB13BE3D5DFAC3FE94B,
	RegexParser_CaptureSlotFromName_mE3FD1D57EB29D4C7A0E4029E4D4785297798EE43,
	RegexParser_IsCaptureSlot_m80540BE449D9B98B2B159CD5169F7AA6DB63CB80,
	RegexParser_IsCaptureName_mBFB85B16ED80CA59452491B4C3278C77ADCA1FDF,
	RegexParser_UseOptionN_mE9C62585222B2D99D295708E4486C952973F35D5,
	RegexParser_UseOptionI_mFA3B59BD8A6F61626E20F8FE909A23289E694263,
	RegexParser_UseOptionM_mDE945B2DE782D12A5013D408F4FFBCABEC48C63D,
	RegexParser_UseOptionS_mE96EEA754E1EEEF658AAF73885D048342D1D200E,
	RegexParser_UseOptionX_mD63DEED6741AEA0B3F6CC4239712A4B2EF690810,
	RegexParser_UseOptionE_mC171EEF863E091591BAD771F16B72D742F044096,
	RegexParser_IsSpecial_mFF68456E944ACAF048B4F96F5758FFDD1D5E7DCD,
	RegexParser_IsStopperX_m0BCF2DB4B0E1324C9109C8BFD486FC5DBA8DC646,
	RegexParser_IsQuantifier_mE0620E30A63AD0C0DB9550A52A4A7D0BB4BC3A31,
	RegexParser_IsTrueQuantifier_m4AA95A9CE7CD78600E8D525ECA5A095984FBC63F,
	RegexParser_IsSpace_m1E41FA7DD1FB93BF9220530CA91B35EF08879F30,
	RegexParser_AddConcatenate_m3743C87DFCD1784A949BFDCE9443845CCD630A5D,
	RegexParser_PushGroup_m6F4246ECA3A6F29DA096C3B41D97652427E3175E,
	RegexParser_PopGroup_m43AB1FB84E11D8DFF6C5D38B9CAD324E5425DD74,
	RegexParser_EmptyStack_mB65B33DCF98A5967407B7C6A07F8799681202BE5,
	RegexParser_StartGroup_m36A6C0ED245D844CD2E630160994C3F2D7CCA994,
	RegexParser_AddAlternate_mDBDEEF8180738DE0D31CC05B0E223EFF0D66939B,
	RegexParser_AddConcatenate_mF80F14978ED6626A8F8E5F37AEB3B946A01192C1,
	RegexParser_AddConcatenate_m81CC39ED404E571347F0E97650F3BEB14639B1B0,
	RegexParser_Unit_mEAEEAC39DBE372DC762644F49E6E163CA37EA34E,
	RegexParser_AddUnitOne_m72DFA82092408E9C63544126093D98390E0C2145,
	RegexParser_AddUnitNotone_mAA142A94BB7B6A358BA36A3920DB139382889749,
	RegexParser_AddUnitSet_m024168548909EA2DF649E6194D60135312ADF5B3,
	RegexParser_AddUnitNode_m6EE11A898128A169E41A5C7B38B1F3DD314FB304,
	RegexParser_AddUnitType_m1ECB4025CA3B580F051CF6891D9C96922CA2FA7A,
	RegexParser_AddGroup_m54BBB919E4D4AD05EFECBC3ECBE46FC4A90569EA,
	RegexParser_PushOptions_m2034533961B704CBFA0F97BD4A54CB7269F0D88A,
	RegexParser_PopOptions_mA18691037302741375A44BD8BDC9387DFB07B676,
	RegexParser_EmptyOptionsStack_m5FCB7AF81ACB5C91A73231C9F0AA0DFB32067A45,
	RegexParser_PopKeepOptions_m8ACBCD324BAF7269F90AEB3CF901B666524658FA,
	RegexParser_MakeException_m6D521D75808E2CD4255A68DC3456EAF2A88F2874,
	RegexParser_Textpos_m36658DED82367E05DF4333E68A666FEEBC3DAC07,
	RegexParser_Textto_m5C8BAB13E35429238EA9A5F13D5A5A580D0DD3AC,
	RegexParser_MoveRightGetChar_m3CF088DE129BADB346CCEEF1D547E2D260BC894A,
	RegexParser_MoveRight_m6F0A1C10AE9EA183F04A9E06B62B2B53648688AC,
	RegexParser_MoveRight_m7D1D27C901CAB81BCF60803E22FBDF2DEEC6CC51,
	RegexParser_MoveLeft_m1BC035A4EA49F4168093B2AB0EEAB2653CB04033,
	RegexParser_CharAt_m08DBAE0DFD788548F74E061031B7221154F96A77,
	RegexParser_RightChar_m9E231199A8E5EA994AA1746FC5E977AF3823FDEB,
	RegexParser_RightChar_m246E9E1F8D0A4A8E485C23E233CD3915C23739D8,
	RegexParser_CharsRight_m318662CFE3223C3FA5E921D376409B4E1B28F9B4,
	RegexParser__cctor_mF468AF3C5916BA72C579CBD41A73D2DAD004F0EE,
	RegexReplacement__ctor_m380FB887FB6FC62BB1DF59D01A859EB813FD670A,
	RegexReplacement_ReplacementImpl_mA3F4702CCE8307AB25F3565FE9A3F6B6643591CE,
	RegexReplacement_ReplacementImplRTL_m16AF2466D4C7112191A74EB9CD21C9B7A0405913,
	RegexReplacement_get_Pattern_m1F4A81BA1F012141DF3B358167025DE0072E1A72,
	RegexReplacement_Replace_m470485F90D044CA2879155BA72E5283C928E4343,
	RegexRunner__ctor_mC04D94995556E71E813F8420C8A4EC0B66404550,
	RegexRunner_Scan_m1C3B1B034601773D510A4D2DEC337635A540BE31,
	RegexRunner_StartTimeoutWatch_m257FBE0C72761082A11D275954C6A1343EB13301,
	RegexRunner_CheckTimeout_m52486A9CE7B6EA4C83BB60FB200196AF0EE5687B,
	RegexRunner_DoCheckTimeout_mCDAA40848A2F8AAD70928FFD8A6C08FF2D9E72A3,
	NULL,
	NULL,
	NULL,
	RegexRunner_InitMatch_mF9CD772D4A8E12F89B4785324CD6939ABAE89AD4,
	RegexRunner_TidyMatch_m61A8AE20E505F2055B276EB020EB0B804ED2D924,
	RegexRunner_EnsureStorage_m6BC13F773B014E2875CCD9A83E4093A77AA1053C,
	RegexRunner_IsBoundary_m6C846E11790EC61A9E75A24230E1477913DB3441,
	RegexRunner_IsECMABoundary_m35C5F5DDC7C2F0E57EBA2E9D9892A88EDAEE4B97,
	RegexRunner_DoubleTrack_m057C14C51F137222469C6526406B0E1069747618,
	RegexRunner_DoubleStack_m8969F05F9E086EAA194DCBD2F137778239918925,
	RegexRunner_DoubleCrawl_mF0425849E5E3C2BA5E9009CED7DE245C8CA0F7CC,
	RegexRunner_Crawl_m655A5D262056F7E13F0645CE5611AE65E83D97DB,
	RegexRunner_Popcrawl_mD8C76E2C584E6908F4BB11E055B97581F0CF7268,
	RegexRunner_Crawlpos_m26A92CA69EF0C65BC7389834A12AD331538D064D,
	RegexRunner_Capture_mE34CB0D3351BCC69F6FDE6CDEA763B93C5E92642,
	RegexRunner_TransferCapture_m4F01B5A96647BC3FD338ACF6D509741D80FEC837,
	RegexRunner_Uncapture_mA7163C77BE1683E508821AB251F33FB7520CE3F8,
	RegexRunner_IsMatched_mD7F580AA0533D5C4BC41D18824FA74BE16EAE7A3,
	RegexRunner_MatchIndex_mA8EEC418C65572A82720F5D16BAC99224CF0251A,
	RegexRunner_MatchLength_m06FA694D5EFE42F89C25C8599BBE86C7726DB2C6,
	NULL,
	RegexTree__ctor_m5B10D5149928B35CE397472028EE327669C211DA,
	RegexWriter_Write_m57CF8209EF566CD40F9146C74DF889C8AA06E061,
	RegexWriter__ctor_m63A858FAE36A8640812DFF917751C1E215A2AE82,
	RegexWriter_PushInt_mFBC85956A26FEBC66244C8DFC881106D85DD2C1D,
	RegexWriter_EmptyStack_mB0C109FA21F5CFD16A34438BA1CC1CE8BED91E7C,
	RegexWriter_PopInt_m8885F9428571674EC224D6BBC93570B1B4671713,
	RegexWriter_CurPos_mEA105879492A4B415FA8AC25B29AA49153F83C18,
	RegexWriter_PatchJump_m6C0A440142E7AC772AD4AF7DF5D8291B6CA6D7D2,
	RegexWriter_Emit_mDC0B76CE49A6DE83DD2D169236BCD516AE9263EF,
	RegexWriter_Emit_m6B0ACB44155A07161060838F483D555E7EF6ACED,
	RegexWriter_Emit_m7C1D08F071C805F13DBF7684AEC3F2F7E748C497,
	RegexWriter_StringCode_m6AA17FFEBDD5E155004F05A78CF13B0D8E901158,
	RegexWriter_MakeException_m443C4CFA99AE06710D1E1BFA3D6EB9737AE70F17,
	RegexWriter_MapCapnum_m6AFE8BED80960BAA522EAA873D535C9D5AD4B811,
	RegexWriter_RegexCodeFromRegexTree_mAC489A29C00688CA929661BC394F1C4CF997CFC5,
	RegexWriter_EmitFragment_mEFDD8EA3A65320222CF4EA8A52B33C687EE0C5AC,
	Stopwatch_GetTimestamp_m7A4B2D144D880343DB783326F36F6996C1D1A1CA,
	Stopwatch__ctor_mA301E9A9D03758CBE09171E0C140CCD06BC9F860,
	Stopwatch_get_Elapsed_m6735B32BFB466FC4F52112AC3493D37404D184BB,
	Stopwatch_get_ElapsedMilliseconds_mE39424FB61C885BCFCC4B583C58A8630C3AD8177,
	Stopwatch_get_ElapsedTicks_mABB4710231090C75F057E90A29C71C553077A901,
	Stopwatch_Start_mF61332B96D7753ADA18366A29E22E2A92E25739A,
	Stopwatch__cctor_m137C0B2E7182FAEA6E030CD1EDC909E5A3F7A064,
	ArrayConverter__ctor_m831D145364A55A155BC896935367961A476D53B7,
	BooleanConverter__ctor_m8293C29BCB7B90516FFE978C6295C0378C1BFEE4,
	CollectionConverter__ctor_m86DBE477F4462418329C5CFB45C86A9420F852E7,
	DecimalConverter__ctor_mB015B3871CF834D0C5D8290C9FD15509249921E7,
	DoubleConverter__ctor_m419F1E782FFBC765D22792D76E56D54FC94E6AEB,
	EditorBrowsableAttribute__ctor_mACDE45DF0DCAA6E923120D6AEC45422AEF958C2E,
	EditorBrowsableAttribute_Equals_m6F5EF9CC298CBDC862CBCA5187379A79635726FA,
	EditorBrowsableAttribute_GetHashCode_m74229847CE44E771F282E2E73FFC4DE55771A1B6,
	EnumConverter__ctor_mBA8B2E210D061A3CF86950F6D797E911A2E3C774,
	Int16Converter__ctor_mD4D022096E6FB9FFDB84D879E31177A892DD072D,
	Int32Converter__ctor_m1CD79AE5880FDE2EC91F1D67E567AAA3618D19B9,
	Int64Converter__ctor_mE4DC71A97EF110B854F22A48AB0F0D3792B53A74,
	SingleConverter__ctor_m8EA7D412C3EE9A9522E7592774DD46EBC6118AA8,
	StringConverter__ctor_m2718AC00691AF4A3AF8A8D64896BE3B5D58658B2,
	TimeSpanConverter__ctor_m28E7294174F979EF86FEF9511474B0AB9431217B,
	TypeConverter__ctor_m7F8A006E775CCB83A8ACB042B296E48B0AE501CD,
	TypeConverterAttribute__ctor_mD0795A29B6FD59978CAAC6DAF3AC7EC564C519A5,
	TypeConverterAttribute__ctor_m52D4E66A914F1A04F2F10A7131A701670225D41C,
	TypeConverterAttribute_get_ConverterTypeName_m883941C77E14FC5B4A3E32DD8F59F11739D5D6D8,
	TypeConverterAttribute_Equals_mDA74DFC28CC7ABC315407EDD1AAC14531C5F6AC4,
	TypeConverterAttribute_GetHashCode_m35874D49724DA3F72C6C2575FD595A711A659DAA,
	TypeConverterAttribute__cctor_mB1A775F56A5933A17CF349BD466B0CCE66B1078A,
	Win32Exception__ctor_mC03E215A1695ED64DDC50F4BE9F59966974DF759,
	Win32Exception__ctor_m2BEA755F6AA536ADDDF07D83BD8297F02584F714,
	Win32Exception__ctor_m94A043EE26097BBFE0ED22FD4EBEA357F142EFE6,
	Win32Exception__ctor_mC7ADDE9D2FEE4E17432F63C24EF1D872380094DB,
	Win32Exception_GetObjectData_m7CD0D7A0806E4A9D8E78ADCBC616700379AB79E8,
	Win32Exception_GetErrorMessage_m6085687D868718B45289CB6AF6EDCB7F89D7350D,
	Win32Exception_InitializeErrorMessages_m4FE6F56C1C2CCB3F6468F0F9F5AD6E1B08673438,
	Win32Exception__cctor_m800CD9D0B3E3253B79A19B6646A7D28B29C3FC52,
	BaseNumberConverter__ctor_mD78E1C7E1F8A977BC7AD33DB0C1E5E32C60E8E83,
	Oid__ctor_m45F49EB1ABFD4F3EB0FC9729C76FF83995752743,
	Oid__ctor_m67437A59D4E75ABF6E40D503F57F81199546E5EC,
	Oid__ctor_m0656E1FC1A7E7BBF694A568DDDF8BE4AFA544985,
	Oid__ctor_mA7AFE14DF30B47447BFFC9E41B37B8DB46C9D079,
	Oid_get_Value_mFE18BDFF095DD5A6643F4FEC3E57846716F37F05,
	Oid_set_Value_m304CEF248379566701402100FA015EAC640C033F,
	OidCollection__ctor_m99B93BB5B35BF7A395CFB7F8B155DFA8DD734800,
	OidCollection_Add_m1FF686421A22A86F8296259D99DA38E02B8BBF5C,
	OidCollection_get_Item_mB37F923F4714BFE0DF44E8EE4A1A5EA1F3EBB1D9,
	OidCollection_get_Count_m6AC0709CDD68451F4CAC942CE94A5A97F3C294B2,
	OidCollection_System_Collections_IEnumerable_GetEnumerator_m3FD3A96DFF93BD88A3B28E35A4DEF57AF25ECB30,
	OidCollection_System_Collections_ICollection_CopyTo_mE508CB1FD9E56CCFE5A4BDD5251D815BF78AC5A9,
	OidEnumerator__ctor_mCA4FBC8408E2B04FD0A524E256E284E8A44E0797,
	OidEnumerator_System_Collections_IEnumerator_get_Current_mF11B1F886842EA79EDB215BD5106D0C4C65EBE53,
	OidEnumerator_MoveNext_m073D94D5D3254D53DF53429ACAD0AA9BD682221D,
	OidEnumerator_Reset_m5006C3B1283711E2BDDEA6C25FDF93BBB900195E,
	CAPI_CryptFindOIDInfoNameFromKey_mA2FD2F391E133E586BC8B827DD916613B590E698,
	CAPI_CryptFindOIDInfoKeyFromName_m7809CD491D913D58FA1B996B835A0A91C413E9DB,
	AsnEncodedData__ctor_mED24E9D1F11942741819652302C0531D18C39BE6,
	AsnEncodedData_set_Oid_m91E38503AAFD8E6FD98970D94FD43E7A738242A6,
	AsnEncodedData_get_RawData_mB9F8281A96011161C67EB3A9208E26C423B187EC,
	AsnEncodedData_set_RawData_mD7FE2383373A6AF578A4983999D677B58BD6B4EC,
	AsnEncodedData_CopyFrom_m3937C7ACC425960B8E48B7D2EB50E9417A7CD4B7,
	AsnEncodedData_ToString_m502785F2F8B4D1EBDF5CEE612FD8D0C2044390D7,
	AsnEncodedData_Default_mEEA94BA253ED1B8A719466A8152A5333E0E3FF07,
	AsnEncodedData_BasicConstraintsExtension_m64D690A2456E16AF39F6F0784CE74BC9533BB182,
	AsnEncodedData_EnhancedKeyUsageExtension_mE04DC17ACCBF3850AFBA454D9937EC4713CC5058,
	AsnEncodedData_KeyUsageExtension_m4EE74EA5C4A3C0B72C50DEB22A537812997AF590,
	AsnEncodedData_SubjectKeyIdentifierExtension_m261D32E7AE226499BA8AD3FBE24FC0E71C9DEB76,
	AsnEncodedData_SubjectAltName_m94FE55170A872B3174D5C495A27AD09F3BACAF49,
	AsnEncodedData_NetscapeCertType_m9191830C380BEC39DBE09065B2A4134193EA92D4,
	X509Utils_FindOidInfo_mE43E0522988511319B8B9F69AF7D0A10B4AE8FA2,
	X509Utils_FindOidInfoWithFallback_m98443176879ABC2054619D4AA491FE086D406950,
	PublicKey_get_EncodedKeyValue_m4BD0975B491E89FFE2A75C1ACDEB1DCCAF586D4F,
	PublicKey_get_EncodedParameters_m629FF8D7E4EEDED96BC455B7B953DC5A46D26F4F,
	PublicKey_get_Oid_mB0AD65FDF84716726D5C7756E5B50CEAD1E4C2AE,
	PublicKey__cctor_m9F739A93AE91AE86889835AAE256410F4DB808CC,
	X509BasicConstraintsExtension__ctor_m1D3F45762EB686500D2195886AD26FF84E5F4B3C,
	X509BasicConstraintsExtension__ctor_mEED7AECEE911DF6CE692301F8F6F6B197DC05729,
	X509BasicConstraintsExtension__ctor_mD08FE3682F4B2EA23450C6609360F45656495780,
	X509BasicConstraintsExtension_get_CertificateAuthority_m282E5D9E7640A06AF2CE06A0FA374571F25BAB6F,
	X509BasicConstraintsExtension_get_HasPathLengthConstraint_m463A8B4DF4BEB46A9353309AA5EF3EAA2F7A4D42,
	X509BasicConstraintsExtension_get_PathLengthConstraint_m93EF2B2BA6D6AD72DE59D98EB0E40DDD2AB3B49F,
	X509BasicConstraintsExtension_CopyFrom_mE64F232FB7DF702DCDB6692537B8F1010AA316DC,
	X509BasicConstraintsExtension_Decode_m40A688DD3A933B24A3E9EFE505299F70AFF32E81,
	X509BasicConstraintsExtension_Encode_m04068558E7AF843C57A8BA9C39E251B7B37A1CDF,
	X509BasicConstraintsExtension_ToString_m75957B2B18A84645897676F0DAC473F022848336,
	X509EnhancedKeyUsageExtension__ctor_mC91E46E79086AAFCD611FB3A223797D20BA9C1C2,
	X509EnhancedKeyUsageExtension_CopyFrom_mC206A056C8C59401AA01F8C935DDE27D7E34D96A,
	X509EnhancedKeyUsageExtension_Decode_m1865B86FE190237641C00804A058BF56F125183D,
	X509EnhancedKeyUsageExtension_ToString_m99085514587961F4AB1CA3FB82E5223801475818,
	X509Extension__ctor_m75C6A788965E9C797F3D47DEFEC366EC2F69F384,
	X509Extension_get_Critical_m8F4D4C2F0ECBE5CB4C9998CE3E56D5040E2EEBE2,
	X509Extension_set_Critical_mA2B424FF17DE53E01E586015DD1C742773B060B4,
	X509Extension_CopyFrom_m03B3EAD99E076090F01D26FF483E827397903A02,
	X509Extension_FormatUnkownData_mE5BAB7DB56CE215EB704A7E4E6866EBECA18F90A,
	X509KeyUsageExtension__ctor_mCCDDE2A55EF78832C8117C680FB264CE91893A99,
	X509KeyUsageExtension__ctor_mA9DDAD17EA38ABB83CD6CC9A353A0667A9EAC018,
	X509KeyUsageExtension__ctor_mBC544E9444992C7883638DB0B4607945F33E7426,
	X509KeyUsageExtension_get_KeyUsages_m9544DC0FAAD02C53D6C649E1831176CB54EFE505,
	X509KeyUsageExtension_CopyFrom_m8DA1FA691943CBD4B94E45096E83FC5EA9EEEA3F,
	X509KeyUsageExtension_GetValidFlags_m7946BD756F14B17D707EE12E7D82878531D115EB,
	X509KeyUsageExtension_Decode_mDE97A425A199661D89FE252A75C8644D4280F1B2,
	X509KeyUsageExtension_Encode_mBBF95E13B1FE1A0507FD692F770D6E98A68E3360,
	X509KeyUsageExtension_ToString_m4455C1B31C62530B930CFADE55DC0E77C60C7EFC,
	X509SubjectKeyIdentifierExtension__ctor_mD586705C293A9C27B5B57BF9CF1D8EAD84864B29,
	X509SubjectKeyIdentifierExtension__ctor_m45218EE7D32231FA6C44A40FEC2E5052162012D6,
	X509SubjectKeyIdentifierExtension__ctor_m182458124147FFEE402584E6415C2EA407B59C5B,
	X509SubjectKeyIdentifierExtension__ctor_m95DD08883D5E284C15820274737324063C4E4432,
	X509SubjectKeyIdentifierExtension__ctor_m98571FC543622A4BD3EA7788BB132348D9E0A3E3,
	X509SubjectKeyIdentifierExtension__ctor_mF692F46CE97CB60AF86C1A74E709E8276B7D9AB1,
	X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m3480A14D8377B6C2D220F99D37AB8B13BEFE76FF,
	X509SubjectKeyIdentifierExtension_CopyFrom_m45E7EB4E976E4759046077C79FBC4A820C9A95EC,
	X509SubjectKeyIdentifierExtension_FromHexChar_m7BDBE176CD85DCA3193FECF78D6CF15E349121BC,
	X509SubjectKeyIdentifierExtension_FromHexChars_mB2D3EBC7E627D44254A82E5628A2079C1DB24C38,
	X509SubjectKeyIdentifierExtension_FromHex_m654E8BB1D2F9D8C878EF854D7933C6EA825F272B,
	X509SubjectKeyIdentifierExtension_Decode_m6EB136D7525F3DFB9FA93F8B3653D2F6FA3B72D1,
	X509SubjectKeyIdentifierExtension_Encode_m11C84A3DCE621526C1FC282E214001D70937D6BD,
	X509SubjectKeyIdentifierExtension_ToString_mB22086D5277B22093240BB9841D32D9008D26AFA,
	EndPoint__ctor_mFCD3A4BB994F59D40A3A94A6F1DEC4A731CC8776,
	IPAddress__ctor_mFD0AF2F6A282D1158DF3C34EF2E63B73814E7748,
	IPAddress__ctor_m373D3930BEEA00EC628E98C5A13AE9BE2B2CEC84,
	IPAddress__ctor_mCC321EEDA0750DA97447EB60529BCBCB4EA0249D,
	IPAddress_get_ScopeId_m941461DEBDECCD858F8D3165F3CA366A318064D9,
	IPAddress_ToString_m0CAEDDAF2A42F23EB1BE3BB353ABE741486710BF,
	IPAddress_Equals_mADA54686760DE75E2C31B8651224FFEB019316D6,
	IPAddress_Equals_mB38BAC1A15885A3181507BC9FD4E8F5765FA6678,
	IPAddress_GetHashCode_m36CE850AFAAD382A29B7D72844989A3105565D7C,
	IPAddress__cctor_m4DF372012DF900E7BB489931296D0BFE4EBD4AEA,
	IPv6AddressFormatter__ctor_m94725668992E78AA0D75E1C072E8A567E9C34497_AdjustorThunk,
	IPv6AddressFormatter_SwapUShort_m6B7BA905E96BB0889C580EE25F3614C7A4A9164C,
	IPv6AddressFormatter_AsIPv4Int_m94B06C695C45C85A90F95CAAF4430772EFC16C4F_AdjustorThunk,
	IPv6AddressFormatter_IsIPv4Compatible_mDC05432DB57ED01219A35BD1B712E589A527A5FC_AdjustorThunk,
	IPv6AddressFormatter_IsIPv4Mapped_m0BEBB1DE4A773028D3091D8321106BE92519A127_AdjustorThunk,
	IPv6AddressFormatter_ToString_mBBBF9A3ABB56F52589BD211DD827015066076C8F_AdjustorThunk,
	SocketException_WSAGetLastError_internal_m18F05CF8D9CE2435225A4215ED757D8D98716FC3,
	SocketException__ctor_mB16B95B2752EAD626C88A5230C1A8FEB7CF632CA,
	SocketException__ctor_m2687C4EFA4D012280C5D19B89D8D01F97B6A2F1A,
	SocketException__ctor_m4C36461DF98089890FBF01908A4AAD301CABE071,
	SocketException_get_Message_m50B9DF4BB6F3B20F650E2F965B3DD654C8970378,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CPrivateImplementationDetailsU3E_ComputeStringHash_m7C7DB27BC4297A74A96AC53E1EDD3E7415DFB874,
	BypassElementCollection__ctor_m867AF1FE6DBB2768AA199F45039C3E2641A9627A,
	ConnectionManagementElementCollection__ctor_mA29AB3A62411F032C5EF86B16E7633A386000C7B,
	ConnectionManagementSection__ctor_m1112C1BE1A9466BBCDD5C2ED20E80CDE03B46CA4,
	ConnectionManagementSection_get_Properties_m1737189D2D78E81728CFF1CCCEB99E1FFFEA3F19,
	DefaultProxySection__ctor_m41EADE87065B61EDF32F67D2E62F04946886DAF6,
	DefaultProxySection_get_Properties_m6F70EC02D977EB16F86354188A72DC87A8959555,
	DefaultProxySection_Reset_m54AC9323047B1FB38795C9F466C1C01192F75276,
	ProxyElement__ctor_mAFD852231DF0231726E41911409CB2725BE990AC,
	ProxyElement_get_Properties_m8A3EE4A3EEF2571DE4768730CEF4107331490377,
	HttpWebRequestElement__ctor_mE3A4CA43FCC72E10B6C7B4920F429C028765E233,
	HttpWebRequestElement_get_Properties_m531EDF2F56823100C47A9EEE1575143E5EB5463C,
	Ipv6Element__ctor_m3F7DF39E6E51517E1429BAE43FA782BF3AF17965,
	Ipv6Element_get_Properties_m156008D7E5279C50DE4CEDB6D4D3CEDAF2ACF8DC,
	NetSectionGroup__ctor_m566D7C9466957BCE3B8FE2D0EA2582CC2F95F269,
	SettingsSection__ctor_mC5F3D29EDC94D87B0B0542DE3702795441AC3005,
	SettingsSection_get_Properties_m1ABB76DEC7441CFEDD4E7EDF99B8F5C258101254,
	PerformanceCountersElement__ctor_m5A090222699B48BEB5FCC743198613FA8D081083,
	PerformanceCountersElement_get_Properties_m3C7B73AC6E5F5E92426D7DC091A2ECE5CFCD9FD0,
	ServicePointManagerElement__ctor_m61B031714F8498D467B5A0958EE62F73E0C58EB7,
	ServicePointManagerElement_get_Properties_mC1C586246B4FE10AC90622A0CC6A5936D501B677,
	SocketElement__ctor_m428B7094399223FFB9A5B62BF9D8CEA18A00A4C3,
	SocketElement_get_Properties_m9CF8E9B1A9B41B7EC24A4F91CE2E8ECBF317426A,
	WebProxyScriptElement__ctor_mC8AF875E80D96B18AA387148009AE1C630D83591,
	WebProxyScriptElement_get_Properties_m8AD25399F804B2D22BC8312102EBC28A0CAE6E26,
	WebRequestModulesSection__ctor_m0CAB6F207E3B29D65AEA38A6AC191873E3000F02,
	WebRequestModulesSection_get_Properties_m909A3E4C4A61BFCC9D09F397D9314E5F74F3FE44,
	WebRequestModuleElementCollection__ctor_m8B880B0EAE7CEF1CB79CD264A9B6D62AB6A22961,
	DiagnosticsConfigurationHandler__ctor_m185BC74B0225A3E16EEB4164923931B79AAA0CF0,
	DiagnosticsConfigurationHandler_Create_mCC7EF5B43B6913E2429B37EC5923202EBB20AA96,
	ThrowStub_ThrowNotSupportedException_mF1DE187697F740D8C18B8966BBEB276878CD86FD,
};
static const int32_t s_InvokerIndices[744] = 
{
	1,
	2,
	0,
	1013,
	1014,
	1015,
	1016,
	114,
	114,
	114,
	114,
	145,
	14,
	114,
	94,
	114,
	1017,
	9,
	114,
	23,
	215,
	387,
	387,
	1018,
	1018,
	14,
	23,
	31,
	26,
	140,
	27,
	1019,
	43,
	173,
	173,
	173,
	14,
	114,
	94,
	4,
	3,
	10,
	14,
	114,
	14,
	14,
	114,
	114,
	48,
	48,
	206,
	10,
	14,
	111,
	9,
	1020,
	14,
	10,
	860,
	174,
	23,
	1021,
	23,
	163,
	34,
	163,
	1022,
	34,
	23,
	1023,
	1024,
	1025,
	1026,
	1027,
	1028,
	1029,
	1030,
	1031,
	1032,
	1033,
	1034,
	95,
	507,
	48,
	48,
	48,
	48,
	1035,
	1036,
	775,
	9,
	9,
	9,
	374,
	163,
	0,
	59,
	864,
	1037,
	1038,
	34,
	163,
	26,
	3,
	23,
	23,
	23,
	26,
	173,
	173,
	1039,
	1040,
	1041,
	1042,
	1043,
	1044,
	1045,
	48,
	48,
	48,
	48,
	3,
	14,
	10,
	14,
	587,
	641,
	54,
	49,
	3,
	10,
	30,
	30,
	30,
	52,
	32,
	0,
	114,
	14,
	587,
	641,
	54,
	35,
	1046,
	1047,
	1047,
	1048,
	1048,
	212,
	352,
	1049,
	1048,
	1050,
	1050,
	1046,
	537,
	1051,
	1052,
	1053,
	1054,
	1054,
	1055,
	88,
	1056,
	344,
	1057,
	346,
	1058,
	1046,
	1059,
	102,
	26,
	179,
	26,
	23,
	23,
	26,
	140,
	1060,
	173,
	173,
	914,
	913,
	10,
	286,
	114,
	14,
	58,
	2,
	1061,
	113,
	443,
	23,
	1062,
	0,
	28,
	114,
	114,
	3,
	1063,
	14,
	26,
	23,
	14,
	26,
	23,
	1064,
	440,
	1065,
	459,
	14,
	35,
	10,
	10,
	14,
	14,
	14,
	14,
	14,
	23,
	3,
	23,
	1066,
	114,
	31,
	560,
	26,
	26,
	26,
	1067,
	1064,
	26,
	26,
	1068,
	42,
	42,
	1069,
	209,
	94,
	94,
	94,
	94,
	94,
	94,
	48,
	48,
	1070,
	1071,
	1072,
	1072,
	1073,
	0,
	0,
	167,
	10,
	14,
	34,
	23,
	1074,
	1075,
	41,
	23,
	1067,
	1076,
	46,
	0,
	0,
	95,
	21,
	23,
	32,
	114,
	10,
	26,
	114,
	14,
	14,
	28,
	23,
	744,
	31,
	1077,
	753,
	428,
	28,
	114,
	406,
	14,
	114,
	4,
	3,
	1078,
	114,
	3,
	23,
	27,
	23,
	23,
	32,
	32,
	32,
	32,
	10,
	10,
	10,
	23,
	32,
	172,
	38,
	32,
	172,
	23,
	32,
	23,
	32,
	10,
	37,
	32,
	172,
	23,
	32,
	10,
	37,
	10,
	37,
	10,
	10,
	10,
	10,
	215,
	9,
	52,
	23,
	371,
	114,
	23,
	4,
	1079,
	1080,
	14,
	34,
	14,
	38,
	32,
	32,
	30,
	37,
	37,
	32,
	3,
	23,
	1081,
	1082,
	23,
	173,
	173,
	23,
	1082,
	172,
	1083,
	569,
	38,
	300,
	114,
	14,
	38,
	14,
	34,
	14,
	14,
	14,
	14,
	14,
	1084,
	26,
	34,
	10,
	10,
	167,
	1085,
	26,
	26,
	32,
	14,
	14,
	326,
	327,
	14,
	23,
	14,
	14,
	14,
	14,
	215,
	10,
	371,
	206,
	215,
	30,
	23,
	215,
	14,
	208,
	206,
	23,
	172,
	140,
	687,
	23,
	116,
	30,
	9,
	114,
	114,
	114,
	114,
	114,
	114,
	48,
	48,
	48,
	114,
	48,
	1086,
	23,
	23,
	114,
	26,
	23,
	23,
	1087,
	14,
	560,
	560,
	26,
	26,
	32,
	23,
	23,
	23,
	114,
	23,
	28,
	10,
	32,
	215,
	23,
	32,
	23,
	371,
	215,
	371,
	10,
	3,
	171,
	27,
	27,
	14,
	443,
	23,
	1088,
	23,
	23,
	23,
	23,
	114,
	23,
	23,
	326,
	23,
	723,
	723,
	23,
	23,
	23,
	32,
	10,
	10,
	38,
	300,
	23,
	30,
	37,
	37,
	14,
	1089,
	0,
	23,
	32,
	114,
	10,
	10,
	172,
	32,
	172,
	38,
	116,
	28,
	37,
	28,
	744,
	118,
	23,
	286,
	145,
	145,
	23,
	3,
	23,
	23,
	23,
	23,
	23,
	32,
	9,
	10,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	9,
	10,
	3,
	23,
	32,
	62,
	173,
	173,
	43,
	3,
	3,
	23,
	26,
	316,
	27,
	26,
	14,
	26,
	23,
	116,
	34,
	10,
	14,
	140,
	26,
	14,
	114,
	23,
	167,
	167,
	23,
	26,
	14,
	26,
	26,
	326,
	326,
	326,
	326,
	326,
	326,
	326,
	326,
	1090,
	1090,
	14,
	14,
	14,
	3,
	23,
	406,
	1091,
	114,
	114,
	10,
	26,
	116,
	14,
	326,
	406,
	26,
	116,
	326,
	23,
	114,
	31,
	26,
	28,
	23,
	406,
	591,
	10,
	26,
	37,
	116,
	14,
	326,
	23,
	406,
	406,
	406,
	406,
	316,
	14,
	26,
	48,
	213,
	0,
	116,
	14,
	326,
	23,
	174,
	144,
	32,
	145,
	14,
	428,
	9,
	10,
	3,
	144,
	211,
	10,
	114,
	114,
	14,
	131,
	23,
	32,
	173,
	14,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	95,
	23,
	23,
	23,
	14,
	23,
	14,
	26,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	14,
	23,
	23,
	179,
	3,
};
static const Il2CppTokenRangePair s_rgctxIndices[6] = 
{
	{ 0x02000065, { 0, 23 } },
	{ 0x02000066, { 23, 2 } },
	{ 0x02000068, { 25, 8 } },
	{ 0x02000069, { 33, 3 } },
	{ 0x0200006B, { 36, 6 } },
	{ 0x0200006C, { 42, 3 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[45] = 
{
	{ (Il2CppRGCTXDataType)3, 17070 },
	{ (Il2CppRGCTXDataType)2, 15773 },
	{ (Il2CppRGCTXDataType)3, 17071 },
	{ (Il2CppRGCTXDataType)3, 17072 },
	{ (Il2CppRGCTXDataType)3, 17073 },
	{ (Il2CppRGCTXDataType)3, 17074 },
	{ (Il2CppRGCTXDataType)3, 17075 },
	{ (Il2CppRGCTXDataType)3, 17076 },
	{ (Il2CppRGCTXDataType)3, 17077 },
	{ (Il2CppRGCTXDataType)3, 17078 },
	{ (Il2CppRGCTXDataType)3, 17079 },
	{ (Il2CppRGCTXDataType)2, 21343 },
	{ (Il2CppRGCTXDataType)2, 15774 },
	{ (Il2CppRGCTXDataType)3, 17080 },
	{ (Il2CppRGCTXDataType)2, 15776 },
	{ (Il2CppRGCTXDataType)3, 17081 },
	{ (Il2CppRGCTXDataType)3, 17082 },
	{ (Il2CppRGCTXDataType)3, 17083 },
	{ (Il2CppRGCTXDataType)3, 17084 },
	{ (Il2CppRGCTXDataType)2, 15775 },
	{ (Il2CppRGCTXDataType)3, 17085 },
	{ (Il2CppRGCTXDataType)1, 15775 },
	{ (Il2CppRGCTXDataType)2, 15775 },
	{ (Il2CppRGCTXDataType)3, 17086 },
	{ (Il2CppRGCTXDataType)2, 15782 },
	{ (Il2CppRGCTXDataType)3, 17087 },
	{ (Il2CppRGCTXDataType)3, 17088 },
	{ (Il2CppRGCTXDataType)3, 17089 },
	{ (Il2CppRGCTXDataType)2, 21344 },
	{ (Il2CppRGCTXDataType)3, 17090 },
	{ (Il2CppRGCTXDataType)3, 17091 },
	{ (Il2CppRGCTXDataType)3, 17092 },
	{ (Il2CppRGCTXDataType)2, 21345 },
	{ (Il2CppRGCTXDataType)3, 17093 },
	{ (Il2CppRGCTXDataType)3, 17094 },
	{ (Il2CppRGCTXDataType)2, 15808 },
	{ (Il2CppRGCTXDataType)3, 17095 },
	{ (Il2CppRGCTXDataType)2, 15819 },
	{ (Il2CppRGCTXDataType)3, 17096 },
	{ (Il2CppRGCTXDataType)3, 17097 },
	{ (Il2CppRGCTXDataType)3, 17098 },
	{ (Il2CppRGCTXDataType)3, 17099 },
	{ (Il2CppRGCTXDataType)3, 17100 },
	{ (Il2CppRGCTXDataType)3, 17101 },
	{ (Il2CppRGCTXDataType)2, 15826 },
};
extern const Il2CppCodeGenModule g_SystemCodeGenModule;
const Il2CppCodeGenModule g_SystemCodeGenModule = 
{
	"System.dll",
	744,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	6,
	s_rgctxIndices,
	45,
	s_rgctxValues,
	NULL,
};
